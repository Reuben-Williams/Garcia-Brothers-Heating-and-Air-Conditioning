import { parsePhoneNumberFromString, type CountryCode } from "libphonenumber-js";
import validator from "validator";

export const CONTACT_IDENTITY_KINDS = Object.freeze(["email", "phone", "external"] as const);
export type ContactIdentityKind = (typeof CONTACT_IDENTITY_KINDS)[number];
export type AcceptedPhoneRegion = "US" | "CA";

export type IdentityNormalizationResult =
  | { readonly ok: true; readonly value: string }
  | { readonly ok: false; readonly code: "invalid_email" | "invalid_phone" };

export function normalizeEmailIdentity(input: string): IdentityNormalizationResult {
  const candidate = input.trim();
  if (!candidate || /[^\x00-\x7f]/.test(candidate) || !validator.isEmail(candidate, { allow_utf8_local_part: false })) {
    return { ok: false, code: "invalid_email" };
  }
  return { ok: true, value: candidate.toLowerCase() };
}

export function normalizePhoneIdentity(input: string, region: AcceptedPhoneRegion): IdentityNormalizationResult {
  const candidate = input.trim();
  if (!candidate || /(?:\bext\.?|\bx)\s*\d+/i.test(candidate)) return { ok: false, code: "invalid_phone" };
  const parsed = parsePhoneNumberFromString(candidate, region as CountryCode);
  if (!parsed?.isValid() || parsed.country !== region || parsed.ext) return { ok: false, code: "invalid_phone" };
  return { ok: true, value: parsed.number };
}

export interface ContactIdentity {
  readonly id: string;
  readonly siteId: string;
  readonly contactId: string;
  readonly kind: ContactIdentityKind;
  readonly normalizedValue: string;
  readonly verified: boolean;
  readonly source: string;
  readonly createdAt: string;
}

export interface UpsertContactIdentityCommand {
  readonly siteId: string;
  readonly contactId: string;
  readonly kind: ContactIdentityKind;
  readonly normalizedValue: string;
  readonly verified: boolean;
  readonly source: string;
  readonly idempotencyKey: string;
}

export interface ContactIdentityRepository {
  findExact(siteId: string, kind: Exclude<ContactIdentityKind, "external">, normalizedValue: string): Promise<ContactIdentity | null>;
  listForContact(siteId: string, contactId: string): Promise<readonly ContactIdentity[]>;
  append(input: UpsertContactIdentityCommand): Promise<ContactIdentity>;
}

export type IdentityMatchResult =
  | { readonly kind: "new_identity" }
  | { readonly kind: "exact_contact"; readonly contactId: string; readonly matchedIdentityKinds: readonly ("email" | "phone")[] }
  | { readonly kind: "identity_conflict"; readonly matchedContactIds: readonly [string, string] }
  | { readonly kind: "review_suggested"; readonly evidence: readonly string[] };

export function resolveIdentityMatch(input: {
  readonly emailContactId?: string;
  readonly phoneContactId?: string;
  readonly reviewEvidence?: readonly string[];
}): IdentityMatchResult {
  if (input.emailContactId && input.phoneContactId && input.emailContactId !== input.phoneContactId) {
    return { kind: "identity_conflict", matchedContactIds: [input.emailContactId, input.phoneContactId] };
  }
  const contactId = input.emailContactId ?? input.phoneContactId;
  if (contactId) {
    const matchedIdentityKinds: ("email" | "phone")[] = [];
    if (input.emailContactId) matchedIdentityKinds.push("email");
    if (input.phoneContactId) matchedIdentityKinds.push("phone");
    return { kind: "exact_contact", contactId, matchedIdentityKinds };
  }
  if (input.reviewEvidence?.length) {
    return { kind: "review_suggested", evidence: [...input.reviewEvidence] };
  }
  return { kind: "new_identity" };
}
