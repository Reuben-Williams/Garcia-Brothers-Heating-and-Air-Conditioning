import type {
  AppliedOrConflict,
  OperationActor,
  VersionedCommandContext,
} from "./operations.js";
import type {
  DataExport,
  DataExportRepository,
  DeletionRequest,
  DeletionRequestRepository,
  RequestDataExportCommand,
  RequestDeletionCommand,
} from "./privacy-jobs.js";

export type PrivacyServiceErrorCode =
  | "not_authorized"
  | "fresh_session_required"
  | "not_found"
  | "invalid_state"
  | "legal_hold"
  | "export_expired";

export class PrivacyServiceError extends Error {
  readonly code: PrivacyServiceErrorCode;

  constructor(code: PrivacyServiceErrorCode) {
    super(code);
    this.name = "PrivacyServiceError";
    this.code = code;
  }
}

export interface DataExportAuthorization {
  readonly canExport: boolean;
  readonly freshSession: boolean;
}

export interface DataExportDownloadAuthorization {
  readonly canExport: boolean;
  readonly isOwner: boolean;
}

export interface DataExportLease {
  readonly export: DataExport;
  readonly workerId: string;
  readonly leaseToken: string;
  readonly leaseExpiresAt: string;
}

export interface LeaseDataExportCommand {
  readonly siteId: string;
  readonly exportId: string;
  readonly workerId: string;
  readonly leaseSeconds: number;
}

export interface CompleteDataExportCommand {
  readonly siteId: string;
  readonly exportId: string;
  readonly workerId: string;
  readonly leaseToken: string;
  readonly expectedVersion: number;
  readonly artifactReference: string;
  readonly expiresAt: string;
}

export interface ExpireDataExportCommand {
  readonly siteId: string;
  readonly exportId: string;
  readonly expectedVersion: number;
}

export interface AuthorizeDataExportDownloadQuery {
  readonly siteId: string;
  readonly exportId: string;
  readonly actor: OperationActor;
}

export interface DataExportDownload {
  readonly url: string;
  readonly expiresAt: string;
}

export interface DataExportServiceRepository extends DataExportRepository {
  lease(input: LeaseDataExportCommand): Promise<DataExportLease | null>;
  complete(input: CompleteDataExportCommand): Promise<AppliedOrConflict<DataExport>>;
  expire(input: ExpireDataExportCommand): Promise<AppliedOrConflict<DataExport>>;
  createDownloadAuthorization(input: AuthorizeDataExportDownloadQuery): Promise<DataExportDownload>;
}

export interface DataExportService {
  request(input: RequestDataExportCommand, authorization: DataExportAuthorization): Promise<DataExport>;
  lease(input: LeaseDataExportCommand): Promise<DataExportLease | null>;
  complete(input: CompleteDataExportCommand): Promise<AppliedOrConflict<DataExport>>;
  expire(input: ExpireDataExportCommand): Promise<AppliedOrConflict<DataExport>>;
  authorizeDownload(
    input: AuthorizeDataExportDownloadQuery,
    authorization: DataExportDownloadAuthorization,
  ): Promise<DataExportDownload>;
}

export function createDataExportService(
  repository: DataExportServiceRepository,
  now: () => string = () => new Date().toISOString(),
): DataExportService {
  return {
    async request(input, authorization) {
      if (!authorization.canExport) throw new PrivacyServiceError("not_authorized");
      if (!authorization.freshSession) throw new PrivacyServiceError("fresh_session_required");
      if (input.actor.type !== "member") throw new PrivacyServiceError("not_authorized");
      return repository.request(input);
    },
    lease(input) {
      return repository.lease(input);
    },
    complete(input) {
      return repository.complete(input);
    },
    expire(input) {
      return repository.expire(input);
    },
    async authorizeDownload(input, authorization) {
      if (!authorization.canExport || input.actor.type !== "member") {
        throw new PrivacyServiceError("not_authorized");
      }
      const record = await repository.get(input.siteId, input.exportId);
      if (!record || record.siteId !== input.siteId) throw new PrivacyServiceError("not_found");
      if (!authorization.isOwner && record.requestedBy !== input.actor.id) {
        throw new PrivacyServiceError("not_authorized");
      }
      if (record.status !== "completed") throw new PrivacyServiceError("invalid_state");
      if (!record.expiresAt || Date.parse(record.expiresAt) <= Date.parse(now())) {
        throw new PrivacyServiceError("export_expired");
      }
      return repository.createDownloadAuthorization(input);
    },
  };
}

export interface OwnerAuthorization {
  readonly isOwner: boolean;
}

export interface ReviewDeletionRequestCommand extends VersionedCommandContext {
  readonly requestId: string;
  readonly decision: "approve" | "reject";
}

export interface DeletionRequestService {
  request(input: RequestDeletionCommand, authorization: OwnerAuthorization): Promise<DeletionRequest>;
  review(
    input: ReviewDeletionRequestCommand,
    authorization: OwnerAuthorization,
  ): Promise<AppliedOrConflict<DeletionRequest>>;
}

export function createDeletionRequestService(
  repository: DeletionRequestRepository,
): DeletionRequestService {
  return {
    async request(input, authorization) {
      if (!authorization.isOwner || input.actor.type !== "member") {
        throw new PrivacyServiceError("not_authorized");
      }
      return repository.request(input);
    },
    async review(input, authorization) {
      if (!authorization.isOwner || input.actor.type !== "member") {
        throw new PrivacyServiceError("not_authorized");
      }
      const record = await repository.get(input.siteId, input.requestId);
      if (!record || record.siteId !== input.siteId) throw new PrivacyServiceError("not_found");
      if (record.status !== "requested") throw new PrivacyServiceError("invalid_state");
      if (input.decision === "approve" && record.legalHold) throw new PrivacyServiceError("legal_hold");
      return repository.transition({
        siteId: input.siteId,
        actor: input.actor,
        idempotencyKey: input.idempotencyKey,
        expectedVersion: input.expectedVersion,
        requestId: input.requestId,
        to: input.decision === "approve" ? "approved" : "rejected",
      });
    },
  };
}
