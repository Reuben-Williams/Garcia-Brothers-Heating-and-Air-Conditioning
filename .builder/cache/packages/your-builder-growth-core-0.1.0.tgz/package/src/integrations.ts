import type { AppliedOrConflict, CommandContext, VersionedCommandContext } from "./operations.js";

export type SecretReferenceStore = "vault" | "provider";

export interface SecretReference {
  readonly store: SecretReferenceStore;
  readonly referenceId: string;
}

export interface RegisterIntegrationCommand extends CommandContext {
  readonly provider: string;
  readonly capabilities: readonly string[];
  readonly secretReference: SecretReference;
}

export interface ResolvedIntegration {
  readonly integrationId: string;
  readonly provider: string;
  readonly secretReference: SecretReference;
  readonly version: number;
}

export type IntegrationHealthStatus = "connected" | "degraded" | "disconnected";

export interface IntegrationHealth {
  readonly status: IntegrationHealthStatus;
  readonly reasonCode?: string;
}

export interface DisconnectIntegrationCommand extends VersionedCommandContext {
  readonly integrationId: string;
  readonly reason: string;
}

export interface IntegrationTransition {
  readonly siteId: string;
  readonly integrationId: string;
  readonly status: "disconnected";
  readonly version: number;
}

export interface IntegrationRegistry {
  register(input: RegisterIntegrationCommand): Promise<string>;
  resolve(siteId: string, capability: string): Promise<ResolvedIntegration | null>;
  checkHealth(siteId: string, integrationId: string): Promise<IntegrationHealth>;
  disconnect(input: DisconnectIntegrationCommand): Promise<AppliedOrConflict<IntegrationTransition>>;
}
