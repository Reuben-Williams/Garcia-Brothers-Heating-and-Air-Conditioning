import type {
  InAppNotification,
  InAppNotificationRepository,
  MarkInAppNotificationReadCommand,
} from "./notifications.js";

const PREVIEW_BY_EVENT_TYPE: Readonly<Record<string, string>> = Object.freeze({
  "lead.created": "A new lead is ready for review.",
  "lead.assigned": "A lead was assigned to you.",
  "lead.status_changed": "A lead status was updated.",
  "task.assigned": "A task was assigned to you.",
  "task.due": "A task is due soon.",
  "submission.received": "A new submission is ready for review.",
});

export interface NotifyInAppCommand {
  readonly siteId: string;
  readonly recipientMemberId: string;
  readonly eventType: string;
  readonly relatedType: InAppNotification["relatedType"];
  readonly relatedId: string;
  readonly idempotencyKey: string;
}

export interface InAppNotificationService {
  notify(input: NotifyInAppCommand): Promise<InAppNotification>;
  markRead(input: MarkInAppNotificationReadCommand): Promise<InAppNotification>;
}

export function createInAppNotificationService(
  repository: InAppNotificationRepository,
): InAppNotificationService {
  return {
    notify(input) {
      const knownEvent = Object.hasOwn(PREVIEW_BY_EVENT_TYPE, input.eventType);
      return repository.create({
        ...input,
        eventType: knownEvent ? input.eventType : "activity.updated",
        previewText: knownEvent
          ? PREVIEW_BY_EVENT_TYPE[input.eventType]!
          : "Activity requires your attention.",
      });
    },
    markRead(input) {
      return repository.markRead(input);
    },
  };
}
