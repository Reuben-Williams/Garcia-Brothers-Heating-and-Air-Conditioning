import type {
  AppliedOrConflict,
  CommandContext,
  OperationActor,
  ReadonlyJsonObject,
  VersionedCommandContext,
} from "./operations.js";

export interface SiteScopedRecord {
  readonly id: string;
  readonly siteId: string;
  readonly createdAt: string;
  readonly updatedAt: string;
  readonly version: number;
}

export interface Contact extends SiteScopedRecord {
  readonly displayName: string;
  readonly email?: string;
  readonly phone?: string;
  readonly lifecycleState?: "active" | "inactive" | "merged" | "deleted";
  readonly preferredContactMethod?: "email" | "phone" | "none";
  readonly serviceAreaZip?: string;
}

export interface ContactMatch {
  readonly contactId: string;
  readonly confidence: "exact" | "review";
  readonly reasons: readonly string[];
}

export interface ContactMergeProposal {
  readonly sourceId: string;
  readonly targetId: string;
  readonly conflicts: readonly string[];
}

export interface CreateContactCommand extends CommandContext {
  readonly displayName: string;
  readonly email?: string;
  readonly phone?: string;
}

export interface ContactUpdatePatch {
  readonly displayName?: string;
  readonly email?: string | null;
  readonly phone?: string | null;
}

export interface UpdateContactCommand extends VersionedCommandContext {
  readonly contactId: string;
  readonly patch: ContactUpdatePatch;
}

export interface ExecuteContactMergeCommand extends CommandContext {
  readonly sourceId: string;
  readonly targetId: string;
  readonly expectedSourceVersion: number;
  readonly expectedTargetVersion: number;
}

export interface ExportContactRecordQuery {
  readonly siteId: string;
  readonly contactId: string;
  readonly actor: OperationActor;
  readonly purpose: string;
}

export interface PseudonymizeContactRecordCommand extends VersionedCommandContext {
  readonly contactId: string;
}

export interface ContactRepository {
  create(input: CreateContactCommand): Promise<Contact>;
  match(
    siteId: string,
    identity: { readonly email?: string; readonly phone?: string },
  ): Promise<readonly ContactMatch[]>;
  get(siteId: string, contactId: string): Promise<Contact | null>;
  update(input: UpdateContactCommand): Promise<AppliedOrConflict<Contact>>;
  proposeMerge(siteId: string, sourceId: string, targetId: string): Promise<ContactMergeProposal>;
  executeReviewedMerge(input: ExecuteContactMergeCommand): Promise<AppliedOrConflict<Contact>>;
  exportContactRecord(input: ExportContactRecordQuery): Promise<ReadonlyJsonObject>;
  pseudonymizeContactRecord(input: PseudonymizeContactRecordCommand): Promise<AppliedOrConflict<Contact>>;
}
