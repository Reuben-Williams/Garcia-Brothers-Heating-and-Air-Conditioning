import type { AppliedOrConflict, CommandContext, VersionedCommandContext } from "./operations.js";

export type TaskStatus = "open" | "assigned" | "completed" | "cancelled";
export type TaskPriority = "low" | "normal" | "high" | "urgent";
export interface AuthorizationParent { readonly type: "lead" | "customer" | "task"; readonly id: string; }

export interface TaskSummary {
  readonly id: string;
  readonly siteId: string;
  readonly relatedType: string;
  readonly relatedId: string;
  readonly title: string;
  readonly status: TaskStatus;
  readonly priority?: TaskPriority;
  readonly dueAt?: string;
  readonly authorizationParents?: readonly AuthorizationParent[];
  readonly assigneeId?: string;
  readonly version: number;
}

export interface CreateTaskCommand extends CommandContext {
  readonly relatedType: string;
  readonly relatedId: string;
  readonly title: string;
  readonly assigneeId?: string;
  readonly priority?: TaskPriority;
  readonly dueAt?: string;
  readonly authorizationParents: readonly AuthorizationParent[];
  readonly selfAssignmentIntent: boolean;
}

export interface AssignTaskCommand extends VersionedCommandContext {
  readonly taskId: string;
  readonly assigneeId: string;
}

export interface CompleteTaskCommand extends VersionedCommandContext {
  readonly taskId: string;
  readonly completedAt: string;
}

export interface CancelTaskCommand extends VersionedCommandContext {
  readonly taskId: string;
  readonly reason: string;
}

export interface TaskRepository {
  create(input: CreateTaskCommand): Promise<TaskSummary>;
  assign(input: AssignTaskCommand): Promise<AppliedOrConflict<TaskSummary>>;
  complete(input: CompleteTaskCommand): Promise<AppliedOrConflict<TaskSummary>>;
  cancel(input: CancelTaskCommand): Promise<AppliedOrConflict<TaskSummary>>;
  listByRelatedRecord(siteId: string, relatedType: string, relatedId: string): Promise<readonly TaskSummary[]>;
}
