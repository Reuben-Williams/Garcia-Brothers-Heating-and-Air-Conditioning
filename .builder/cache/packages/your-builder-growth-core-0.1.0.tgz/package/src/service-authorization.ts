import type { MemberOperationActor, OperationActor } from "./operations.js";

export type GrowthAuthorizationScope = "site" | "assigned";

export type GrowthServiceErrorCode =
  | "invalid_filter"
  | "invalid_request"
  | "not_authorized";

export class GrowthServiceError extends Error {
  readonly code: GrowthServiceErrorCode;

  constructor(code: GrowthServiceErrorCode) {
    super(code);
    this.name = "GrowthServiceError";
    this.code = code;
  }
}

export interface ScopedGrowthAuthorization {
  readonly allowed: boolean;
  readonly scope: GrowthAuthorizationScope;
}

export function requireGrowthMember(actor: OperationActor): MemberOperationActor {
  if (actor.type !== "member" || !actor.id.trim()) {
    throw new GrowthServiceError("not_authorized");
  }
  return actor;
}

export function requireAllowed(
  authorization: ScopedGrowthAuthorization,
  requiredScope?: GrowthAuthorizationScope,
): GrowthAuthorizationScope {
  if (!authorization.allowed || (requiredScope && authorization.scope !== requiredScope)) {
    throw new GrowthServiceError("not_authorized");
  }
  return authorization.scope;
}

export function requireBoundedText(
  value: string,
  minimum: number,
  maximum: number,
): string {
  const normalized = value.trim();
  if (normalized.length < minimum || normalized.length > maximum || normalized.includes("\0")) {
    throw new GrowthServiceError("invalid_request");
  }
  return normalized;
}

export function requireExpectedVersion(expectedVersion: number): void {
  if (!Number.isInteger(expectedVersion) || expectedVersion < 0) {
    throw new GrowthServiceError("invalid_request");
  }
}
