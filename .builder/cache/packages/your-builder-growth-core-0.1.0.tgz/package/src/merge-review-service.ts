import type { Contact, ContactRepository } from "./contacts.js";
import type { AppliedOrConflict, VersionedCommandContext } from "./operations.js";
import type {
  ContactMergeSuggestion,
  MergeReviewRepository,
} from "./privacy-jobs.js";

export interface MergeReviewServiceRepository extends MergeReviewRepository {
  get(siteId: string, suggestionId: string): Promise<ContactMergeSuggestion | null>;
}

export interface MergeReviewAuthorization {
  readonly canReview: boolean;
}

export interface ReviewMergeSuggestionCommand extends VersionedCommandContext {
  readonly suggestionId: string;
  readonly decision: "accept" | "reject";
}

export interface ExecuteAcceptedMergeCommand {
  readonly siteId: string;
  readonly actor: VersionedCommandContext["actor"];
  readonly idempotencyKey: string;
  readonly suggestionId: string;
  readonly sourceId: string;
  readonly targetId: string;
  readonly expectedSourceVersion: number;
  readonly expectedTargetVersion: number;
}

export type MergeReviewErrorCode =
  | "not_authorized"
  | "not_found"
  | "invalid_state"
  | "review_not_accepted"
  | "candidate_mismatch";

export class MergeReviewError extends Error {
  readonly code: MergeReviewErrorCode;

  constructor(code: MergeReviewErrorCode) {
    super(code);
    this.name = "MergeReviewError";
    this.code = code;
  }
}

export interface MergeReviewService {
  review(
    input: ReviewMergeSuggestionCommand,
    authorization: MergeReviewAuthorization,
  ): Promise<AppliedOrConflict<ContactMergeSuggestion>>;
  executeAccepted(
    input: ExecuteAcceptedMergeCommand,
    authorization: MergeReviewAuthorization,
  ): Promise<AppliedOrConflict<Contact>>;
}

function requireReviewer(actorType: string, authorization: MergeReviewAuthorization): void {
  if (!authorization.canReview || actorType !== "member") {
    throw new MergeReviewError("not_authorized");
  }
}

export function createMergeReviewService(dependencies: {
  readonly reviews: MergeReviewServiceRepository;
  readonly contacts: ContactRepository;
}): MergeReviewService {
  return {
    async review(input, authorization) {
      requireReviewer(input.actor.type, authorization);
      const suggestion = await dependencies.reviews.get(input.siteId, input.suggestionId);
      if (!suggestion || suggestion.siteId !== input.siteId) throw new MergeReviewError("not_found");
      if (suggestion.state !== "suggested") throw new MergeReviewError("invalid_state");
      return dependencies.reviews.disposition({
        siteId: input.siteId,
        actor: input.actor,
        idempotencyKey: input.idempotencyKey,
        expectedVersion: input.expectedVersion,
        suggestionId: input.suggestionId,
        state: input.decision === "accept" ? "accepted" : "rejected",
      });
    },
    async executeAccepted(input, authorization) {
      requireReviewer(input.actor.type, authorization);
      const suggestion = await dependencies.reviews.get(input.siteId, input.suggestionId);
      if (!suggestion || suggestion.siteId !== input.siteId) throw new MergeReviewError("not_found");
      if (suggestion.state !== "accepted") throw new MergeReviewError("review_not_accepted");
      const candidates = new Set(suggestion.candidateContactIds);
      if (input.sourceId === input.targetId || !candidates.has(input.sourceId) || !candidates.has(input.targetId)) {
        throw new MergeReviewError("candidate_mismatch");
      }
      return dependencies.contacts.executeReviewedMerge({
        siteId: input.siteId,
        actor: input.actor,
        idempotencyKey: input.idempotencyKey,
        sourceId: input.sourceId,
        targetId: input.targetId,
        expectedSourceVersion: input.expectedSourceVersion,
        expectedTargetVersion: input.expectedTargetVersion,
      });
    },
  };
}
