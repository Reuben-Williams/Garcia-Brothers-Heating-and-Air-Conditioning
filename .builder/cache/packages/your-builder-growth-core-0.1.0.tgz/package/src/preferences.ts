import type { AppliedOrConflict, CommandContext, VersionedCommandContext } from "./operations.js";

export interface ContactPreference {
  readonly id: string;
  readonly siteId: string;
  readonly contactId: string;
  readonly key: string;
  readonly value: string;
  readonly version: number;
  readonly updatedAt: string;
}

export interface SetContactPreferenceCommand extends CommandContext {
  readonly contactId: string;
  readonly key: string;
  readonly value: string;
}

export interface ClearContactPreferenceCommand extends VersionedCommandContext {
  readonly preferenceId: string;
}

export interface ContactPreferenceRepository {
  list(siteId: string, contactId: string): Promise<readonly ContactPreference[]>;
  set(input: SetContactPreferenceCommand): Promise<ContactPreference>;
  clear(input: ClearContactPreferenceCommand): Promise<AppliedOrConflict<ContactPreference>>;
}
