import type { AppliedOrConflict, OperationActor } from "./operations.js";
import type {
  ClearContactPreferenceCommand,
  ContactPreference,
  SetContactPreferenceCommand,
} from "./preferences.js";
import type {
  AddSuppressionCommand,
  ReconcileProviderSuppressionCommand,
  RetainSuppressionEvidenceCommand,
  SuppressionChannel,
  SuppressionEvaluation,
  SuppressionRecord,
} from "./suppressions.js";
import {
  GrowthServiceError,
  requireAllowed,
  requireBoundedText,
  requireExpectedVersion,
  requireGrowthMember,
  type GrowthAuthorizationScope,
  type ScopedGrowthAuthorization,
} from "./service-authorization.js";

export interface ContactPreferenceAuthorizationQuery {
  readonly siteId: string;
  readonly actor: OperationActor;
  readonly action: "read" | "set" | "clear";
  readonly contactId?: string;
  readonly preferenceId?: string;
}

export interface ContactPreferenceServiceRepository {
  /** Rechecks site membership, scope, contact ownership, and versions transactionally. */
  listAuthorized(input: {
    readonly siteId: string;
    readonly contactId: string;
    readonly memberId: string;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<readonly ContactPreference[]>;
  setAuthorized(input: {
    readonly command: SetContactPreferenceCommand;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<ContactPreference>;
  clearAuthorized(input: {
    readonly command: ClearContactPreferenceCommand;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<AppliedOrConflict<ContactPreference>>;
}

export interface ContactPreferenceService {
  list(input: {
    readonly siteId: string;
    readonly actor: OperationActor;
    readonly contactId: string;
  }): Promise<readonly ContactPreference[]>;
  set(input: SetContactPreferenceCommand): Promise<ContactPreference>;
  clear(input: ClearContactPreferenceCommand): Promise<AppliedOrConflict<ContactPreference>>;
}

const PREFERENCE_KEY_PATTERN = /^[a-z][a-z0-9_.-]{0,63}$/;

export function createContactPreferenceService(dependencies: {
  readonly repository: ContactPreferenceServiceRepository;
  readonly authorize: (
    input: ContactPreferenceAuthorizationQuery,
  ) => Promise<ScopedGrowthAuthorization>;
}): ContactPreferenceService {
  return {
    async list(input) {
      const member = requireGrowthMember(input.actor);
      requireBoundedText(input.contactId, 1, 128);
      const scope = requireAllowed(await dependencies.authorize({
        siteId: input.siteId,
        actor: input.actor,
        action: "read",
        contactId: input.contactId,
      }));
      return dependencies.repository.listAuthorized({
        siteId: input.siteId,
        contactId: input.contactId,
        memberId: member.id,
        scope,
      });
    },
    async set(command) {
      requireGrowthMember(command.actor);
      if (!PREFERENCE_KEY_PATTERN.test(command.key)) {
        throw new GrowthServiceError("invalid_request");
      }
      requireBoundedText(command.value, 0, 500);
      const scope = requireAllowed(await dependencies.authorize({
        siteId: command.siteId,
        actor: command.actor,
        action: "set",
        contactId: command.contactId,
      }));
      return dependencies.repository.setAuthorized({ command, scope });
    },
    async clear(command) {
      requireGrowthMember(command.actor);
      requireExpectedVersion(command.expectedVersion);
      const scope = requireAllowed(await dependencies.authorize({
        siteId: command.siteId,
        actor: command.actor,
        action: "clear",
        preferenceId: command.preferenceId,
      }));
      return dependencies.repository.clearAuthorized({ command, scope });
    },
  };
}

export interface SuppressionAuthorizationQuery {
  readonly siteId: string;
  readonly actor: OperationActor;
  readonly action: "add" | "evaluate" | "reconcile" | "retain";
  readonly suppressionId?: string;
}

export interface SuppressionServiceRepository {
  /** Rechecks site capability, scope, provider identity, and versions transactionally. */
  addAuthorized(input: {
    readonly command: AddSuppressionCommand;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<SuppressionRecord>;
  evaluateAuthorized(input: {
    readonly siteId: string;
    readonly memberId: string;
    readonly channel: SuppressionChannel;
    readonly normalizedDestinationHash: string;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<SuppressionEvaluation>;
  reconcileAuthorized(input: {
    readonly command: ReconcileProviderSuppressionCommand;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<SuppressionRecord>;
  retainAuthorized(input: {
    readonly command: RetainSuppressionEvidenceCommand;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<AppliedOrConflict<SuppressionRecord>>;
}

export interface SuppressionService {
  add(command: AddSuppressionCommand): Promise<SuppressionRecord>;
  evaluate(input: {
    readonly siteId: string;
    readonly actor: OperationActor;
    readonly channel: SuppressionChannel;
    readonly normalizedDestinationHash: string;
  }): Promise<SuppressionEvaluation>;
  reconcileProviderFact(command: ReconcileProviderSuppressionCommand): Promise<SuppressionRecord>;
  retainPreventionEvidence(
    command: RetainSuppressionEvidenceCommand,
  ): Promise<AppliedOrConflict<SuppressionRecord>>;
}

const HASH_PATTERN = /^[a-f0-9]{64}$/;

function validateSuppressionFields(input: {
  readonly normalizedDestinationHash: string;
  readonly reasonCode: string;
  readonly source: string;
}): void {
  if (!HASH_PATTERN.test(input.normalizedDestinationHash)) {
    throw new GrowthServiceError("invalid_request");
  }
  requireBoundedText(input.reasonCode, 1, 100);
  requireBoundedText(input.source, 1, 160);
}

export function createSuppressionService(dependencies: {
  readonly repository: SuppressionServiceRepository;
  readonly authorize: (input: SuppressionAuthorizationQuery) => Promise<ScopedGrowthAuthorization>;
}): SuppressionService {
  return {
    async add(command) {
      requireGrowthMember(command.actor);
      validateSuppressionFields(command);
      const scope = requireAllowed(await dependencies.authorize({
        siteId: command.siteId,
        actor: command.actor,
        action: "add",
      }), "site");
      return dependencies.repository.addAuthorized({ command, scope });
    },
    async evaluate(input) {
      const member = requireGrowthMember(input.actor);
      if (!HASH_PATTERN.test(input.normalizedDestinationHash)) {
        throw new GrowthServiceError("invalid_request");
      }
      const scope = requireAllowed(await dependencies.authorize({
        siteId: input.siteId,
        actor: input.actor,
        action: "evaluate",
      }));
      return dependencies.repository.evaluateAuthorized({
        siteId: input.siteId,
        memberId: member.id,
        channel: input.channel,
        normalizedDestinationHash: input.normalizedDestinationHash,
        scope,
      });
    },
    async reconcileProviderFact(command) {
      if (command.actor.type !== "provider" && command.actor.type !== "system") {
        throw new GrowthServiceError("not_authorized");
      }
      validateSuppressionFields(command);
      requireBoundedText(command.provider, 1, 100);
      requireBoundedText(command.providerEventId, 1, 200);
      const scope = requireAllowed(await dependencies.authorize({
        siteId: command.siteId,
        actor: command.actor,
        action: "reconcile",
      }), "site");
      return dependencies.repository.reconcileAuthorized({ command, scope });
    },
    async retainPreventionEvidence(command) {
      requireGrowthMember(command.actor);
      requireExpectedVersion(command.expectedVersion);
      requireBoundedText(command.source, 1, 160);
      const scope = requireAllowed(await dependencies.authorize({
        siteId: command.siteId,
        actor: command.actor,
        action: "retain",
        suppressionId: command.suppressionId,
      }), "site");
      return dependencies.repository.retainAuthorized({ command, scope });
    },
  };
}
