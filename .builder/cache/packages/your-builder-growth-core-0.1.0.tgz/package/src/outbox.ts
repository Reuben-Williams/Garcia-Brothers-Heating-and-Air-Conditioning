import type {
  CommandContext,
  LeaseResult,
  OutboxLeaseResourceIdentity,
  ReadonlyJsonObject,
} from "./operations.js";

export const GROWTH_OUTBOX_SCHEMA_VERSION = 1 as const;

export interface GrowthOutboxMetadata {
  readonly schemaVersion: typeof GROWTH_OUTBOX_SCHEMA_VERSION;
  readonly topic: `growth.${string}`;
  readonly aggregateType: string;
  readonly aggregateId: string;
  readonly aggregateVersion: number;
  readonly correlationId: string;
  readonly causationId?: string;
}

export interface EnqueueOutboxCommand extends CommandContext {
  readonly eventId: string;
  readonly destination: string;
  readonly payload: ReadonlyJsonObject;
}

export interface EnqueueGrowthOutboxCommand extends EnqueueOutboxCommand, GrowthOutboxMetadata {}

export interface ClaimOutboxCommand {
  readonly siteId: string;
  readonly workerId: string;
  readonly now: string;
  readonly leaseSeconds: number;
}

export interface ClaimedOutboxRecord {
  readonly siteId: string;
  readonly outboxId: string;
  readonly eventId: string;
  readonly destination: string;
  readonly payload: ReadonlyJsonObject;
  readonly idempotencyKey: string;
  readonly workerId: string;
  readonly leaseToken: string;
  readonly leaseExpiresAt: string;
  readonly attempt: number;
}

export interface OutboxLeaseFence {
  readonly siteId: string;
  readonly outboxId: string;
  readonly workerId: string;
  readonly leaseToken: string;
  readonly leaseExpiresAt: string;
  readonly attempt: number;
}

export interface CompleteOutboxCommand {
  readonly lease: OutboxLeaseFence;
  readonly resultCode: string;
}

export interface FailOutboxCommand {
  readonly lease: OutboxLeaseFence;
  readonly errorCode: string;
  readonly retryAt?: string;
}

export interface OutboxTransition {
  readonly siteId: string;
  readonly outboxId: string;
  readonly status: "completed" | "failed";
  readonly attempt: number;
  readonly retryAt?: string;
}

export interface OutboxRepository {
  enqueue(input: EnqueueOutboxCommand): Promise<string>;
  claim(input: ClaimOutboxCommand): Promise<ClaimedOutboxRecord | null>;
  complete(input: CompleteOutboxCommand): Promise<LeaseResult<OutboxTransition, OutboxLeaseResourceIdentity>>;
  fail(input: FailOutboxCommand): Promise<LeaseResult<OutboxTransition, OutboxLeaseResourceIdentity>>;
}
