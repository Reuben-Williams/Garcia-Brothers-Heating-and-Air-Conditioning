import type { AppliedOrConflict, VersionedCommandContext } from "./operations.js";

export const ASSIGNABLE_GROWTH_RECORD_TYPES = Object.freeze(["lead", "customer", "task"] as const);
export type AssignableGrowthRecordType = (typeof ASSIGNABLE_GROWTH_RECORD_TYPES)[number];
export type RecordAssignmentState = "active" | "ended";

export interface RecordAssignment {
  readonly id: string;
  readonly siteId: string;
  readonly recordType: AssignableGrowthRecordType;
  readonly recordId: string;
  readonly memberId: string;
  readonly state: RecordAssignmentState;
  readonly version: number;
  readonly assignedAt: string;
  readonly endedAt?: string;
}

export interface SetRecordAssignmentCommand extends VersionedCommandContext {
  readonly recordType: AssignableGrowthRecordType;
  readonly recordId: string;
  readonly memberId: string;
}

export interface EndRecordAssignmentCommand extends VersionedCommandContext {
  readonly assignmentId: string;
  readonly reason: string;
}

export interface RecordAssignmentRepository {
  list(siteId: string, recordType: AssignableGrowthRecordType, recordId: string): Promise<readonly RecordAssignment[]>;
  set(input: SetRecordAssignmentCommand): Promise<AppliedOrConflict<RecordAssignment>>;
  end(input: EndRecordAssignmentCommand): Promise<AppliedOrConflict<RecordAssignment>>;
}
