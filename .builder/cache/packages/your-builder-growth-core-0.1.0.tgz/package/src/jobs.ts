import type {
  AppliedOrConflict,
  CommandContext,
  JobLeaseResourceIdentity,
  LeaseResult,
  ReadonlyJsonObject,
  VersionedCommandContext,
} from "./operations.js";

export type DurableJobStatus =
  | "scheduled"
  | "leased"
  | "paused"
  | "completed"
  | "failed"
  | "dead_letter"
  | "cancelled";

export type JobScheduleSource = "manual" | "automation" | "integration" | "system";

export interface ScheduleJobCommand extends CommandContext {
  readonly kind: string;
  readonly runAt: string;
  readonly payload: ReadonlyJsonObject;
  readonly source: JobScheduleSource;
}

export interface LeaseJobCommand {
  readonly siteId: string;
  readonly workerId: string;
  readonly now: string;
  readonly leaseSeconds: number;
}

export interface JobLeaseFence {
  readonly siteId: string;
  readonly jobId: string;
  readonly workerId: string;
  readonly leaseToken: string;
  readonly leaseExpiresAt: string;
  readonly attempt: number;
  readonly version: number;
}

export interface LeasedJobRecord extends JobLeaseFence {
  readonly kind: string;
  readonly payload: ReadonlyJsonObject;
  readonly runAt: string;
}

export interface RenewJobLeaseCommand {
  readonly lease: JobLeaseFence;
  readonly now: string;
  readonly leaseSeconds: number;
}

export interface PauseJobCommand extends VersionedCommandContext {
  readonly jobId: string;
  readonly reason: string;
}

export interface ResumeJobCommand extends VersionedCommandContext {
  readonly jobId: string;
  readonly now: string;
}

export interface CancelJobCommand extends VersionedCommandContext {
  readonly jobId: string;
  readonly reason: string;
}

export interface JobTransition {
  readonly siteId: string;
  readonly jobId: string;
  readonly status: DurableJobStatus;
  readonly version: number;
}

export interface CompleteJobCommand {
  readonly lease: JobLeaseFence;
  readonly result: ReadonlyJsonObject;
}

export interface FailJobCommand {
  readonly lease: JobLeaseFence;
  readonly errorCode: string;
  readonly retryAt?: string;
}

export interface DeadLetterJobCommand {
  readonly lease: JobLeaseFence;
  readonly errorCode: string;
}

export interface JobRepository {
  schedule(input: ScheduleJobCommand): Promise<string>;
  lease(input: LeaseJobCommand): Promise<LeasedJobRecord | null>;
  renew(input: RenewJobLeaseCommand): Promise<LeaseResult<LeasedJobRecord, JobLeaseResourceIdentity>>;
  pause(input: PauseJobCommand): Promise<AppliedOrConflict<JobTransition>>;
  resume(input: ResumeJobCommand): Promise<AppliedOrConflict<JobTransition>>;
  cancel(input: CancelJobCommand): Promise<AppliedOrConflict<JobTransition>>;
  complete(input: CompleteJobCommand): Promise<LeaseResult<JobTransition, JobLeaseResourceIdentity>>;
  fail(input: FailJobCommand): Promise<LeaseResult<JobTransition, JobLeaseResourceIdentity>>;
  deadLetter(input: DeadLetterJobCommand): Promise<LeaseResult<JobTransition, JobLeaseResourceIdentity>>;
}
