export const GROWTH_CORE_CONTRACT_VERSION = 1 as const;
export * from "./identity-matching-service.js";
export * from "./merge-review-service.js";
export * from "./notification-service.js";
export * from "./privacy-service.js";
export * from "./contact-settings-service.js";
export * from "./service-authorization.js";
export * from "./shared-operation-services.js";
export * from "./tag-saved-view-service.js";

export * from "./assignments.js";
export * from "./identities.js";
export * from "./notifications.js";
export * from "./preferences.js";
export * from "./privacy-jobs.js";
export * from "./saved-views.js";
export * from "./tags.js";

export type {
  AppliedOrConflict,
  AppliedResult,
  CommandContext,
  JobLeaseResourceIdentity,
  JsonPrimitive,
  JsonValue,
  LeaseAppliedResult,
  LeaseConflict,
  LeaseConflictReason,
  LeaseExpiredConflict,
  LeaseReplayResult,
  LeaseResourceIdentity,
  LeaseResult,
  LeaseStaleTokenConflict,
  LeaseVersionConflict,
  LeaseWorkerMismatchConflict,
  MemberOperationActor,
  OperationActor,
  OperationActorType,
  OutboxLeaseResourceIdentity,
  ProviderOperationActor,
  ReadonlyJsonObject,
  SystemOperationActor,
  VersionConflict,
  VersionedCommandContext,
  VisitorOperationActor,
} from "./operations.js";
export type {
  Contact,
  ContactMatch,
  ContactMergeProposal,
  ContactRepository,
  ContactUpdatePatch,
  CreateContactCommand,
  ExecuteContactMergeCommand,
  ExportContactRecordQuery,
  PseudonymizeContactRecordCommand,
  SiteScopedRecord,
  UpdateContactCommand,
} from "./contacts.js";
export type {
  ConsentChannel,
  ConsentEvaluation,
  ConsentEvidenceLocator,
  ConsentEvidenceReference,
  ConsentExplanation,
  ConsentService,
  ConsentStatus,
  CustomerConsentProjection,
  EvaluateConsentQuery,
  ExplainConsentQuery,
  RecordConsentEvidenceCommand,
  RevokeConsentCommand,
} from "./consent.js";
export type {
  AddSuppressionCommand,
  ReconcileProviderSuppressionCommand,
  RetainSuppressionEvidenceCommand,
  SuppressionChannel,
  SuppressionEvaluation,
  SuppressionRecord,
  SuppressionRepository,
} from "./suppressions.js";
export type {
  AssignTaskCommand,
  CancelTaskCommand,
  CompleteTaskCommand,
  CreateTaskCommand,
  AuthorizationParent,
  TaskPriority,
  TaskRepository,
  TaskStatus,
  TaskSummary,
} from "./tasks.js";
export type {
  IntegrationServiceEventOrigin,
  ManualServiceEventActor,
  ManualServiceEventOrigin,
  RecordServiceEventCommand,
  ServiceEvent,
  ServiceEventKind,
  ServiceEventOrigin,
  ServiceEventRepository,
} from "./service-events.js";
export { SERVICE_EVENT_KINDS } from "./service-events.js";
export type {
  AppendDomainEventCommand,
  DomainEventEnvelope,
  DomainEventStore,
} from "./domain-events.js";
export type {
  ClaimedOutboxRecord,
  ClaimOutboxCommand,
  CompleteOutboxCommand,
  EnqueueOutboxCommand,
  EnqueueGrowthOutboxCommand,
  GrowthOutboxMetadata,
  FailOutboxCommand,
  OutboxLeaseFence,
  OutboxRepository,
  OutboxTransition,
} from "./outbox.js";
export { GROWTH_OUTBOX_SCHEMA_VERSION } from "./outbox.js";
export type {
  CancelJobCommand,
  CompleteJobCommand,
  DeadLetterJobCommand,
  DurableJobStatus,
  FailJobCommand,
  JobRepository,
  JobLeaseFence,
  JobScheduleSource,
  JobTransition,
  LeaseJobCommand,
  LeasedJobRecord,
  PauseJobCommand,
  RenewJobLeaseCommand,
  ResumeJobCommand,
  ScheduleJobCommand,
} from "./jobs.js";
export type {
  DisconnectIntegrationCommand,
  IntegrationHealth,
  IntegrationHealthStatus,
  IntegrationRegistry,
  IntegrationTransition,
  RegisterIntegrationCommand,
  ResolvedIntegration,
  SecretReference,
  SecretReferenceStore,
} from "./integrations.js";
