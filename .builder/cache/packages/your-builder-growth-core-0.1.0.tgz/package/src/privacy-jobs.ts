import type { AppliedOrConflict, CommandContext, ReadonlyJsonObject, VersionedCommandContext } from "./operations.js";

export type DataExportStatus = "requested" | "processing" | "completed" | "failed" | "expired";
export type DeletionRequestStatus = "requested" | "approved" | "rejected" | "processing" | "completed" | "failed";

export interface DataExport {
  readonly id: string;
  readonly siteId: string;
  readonly requestedBy: string;
  readonly scope: "leads" | "customers" | "base_submissions" | "portable_bundle";
  readonly filters: ReadonlyJsonObject;
  readonly status: DataExportStatus;
  readonly expiresAt?: string;
  readonly version: number;
  readonly createdAt: string;
}

export interface RequestDataExportCommand extends CommandContext {
  readonly scope: DataExport["scope"];
  readonly filters: ReadonlyJsonObject;
}

export interface DataExportRepository {
  request(input: RequestDataExportCommand): Promise<DataExport>;
  get(siteId: string, exportId: string): Promise<DataExport | null>;
  transition(input: VersionedCommandContext & { readonly exportId: string; readonly to: DataExportStatus }): Promise<AppliedOrConflict<DataExport>>;
}

export interface DeletionRequest {
  readonly id: string;
  readonly siteId: string;
  readonly requestedBy: string;
  readonly targetType: "customer" | "site";
  readonly targetId: string;
  readonly legalHold: boolean;
  readonly status: DeletionRequestStatus;
  readonly version: number;
  readonly createdAt: string;
}

export interface RequestDeletionCommand extends CommandContext {
  readonly targetType: DeletionRequest["targetType"];
  readonly targetId: string;
  readonly reason: string;
}

export interface DeletionRequestRepository {
  request(input: RequestDeletionCommand): Promise<DeletionRequest>;
  get(siteId: string, requestId: string): Promise<DeletionRequest | null>;
  transition(input: VersionedCommandContext & { readonly requestId: string; readonly to: DeletionRequestStatus }): Promise<AppliedOrConflict<DeletionRequest>>;
}

export interface ContactMergeSuggestion {
  readonly id: string;
  readonly siteId: string;
  readonly candidateContactIds: readonly [string, string];
  readonly evidence: readonly string[];
  readonly confidence: "low" | "medium" | "high";
  readonly state: "suggested" | "accepted" | "rejected";
  readonly version: number;
}

export interface ContactAlias {
  readonly id: string;
  readonly siteId: string;
  readonly sourceContactId: string;
  readonly canonicalContactId: string;
  readonly mergeSuggestionId: string;
  readonly createdAt: string;
}

export interface MergeReviewRepository {
  suggest(input: CommandContext & Omit<ContactMergeSuggestion, "id" | "state" | "version">): Promise<ContactMergeSuggestion>;
  disposition(input: VersionedCommandContext & { readonly suggestionId: string; readonly state: "accepted" | "rejected" }): Promise<AppliedOrConflict<ContactMergeSuggestion>>;
  listAliases(siteId: string, canonicalContactId: string): Promise<readonly ContactAlias[]>;
}
