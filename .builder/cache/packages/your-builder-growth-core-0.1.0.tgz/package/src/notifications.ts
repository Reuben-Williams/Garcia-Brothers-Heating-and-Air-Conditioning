export interface InAppNotification {
  readonly id: string;
  readonly siteId: string;
  readonly recipientMemberId: string;
  readonly eventType: string;
  readonly relatedType: "lead" | "customer" | "task" | "submission" | "site";
  readonly relatedId: string;
  readonly previewText: string;
  readonly createdAt: string;
  readonly readAt?: string;
}

export interface CreateInAppNotificationCommand {
  readonly siteId: string;
  readonly recipientMemberId: string;
  readonly eventType: string;
  readonly relatedType: InAppNotification["relatedType"];
  readonly relatedId: string;
  readonly previewText: string;
  readonly idempotencyKey: string;
}

export interface MarkInAppNotificationReadCommand {
  readonly siteId: string;
  readonly notificationId: string;
  readonly recipientMemberId: string;
  readonly readAt: string;
  readonly idempotencyKey: string;
}

export interface InAppNotificationRepository {
  create(input: CreateInAppNotificationCommand): Promise<InAppNotification>;
  listForRecipient(siteId: string, recipientMemberId: string, limit: number, cursor?: string): Promise<readonly InAppNotification[]>;
  markRead(input: MarkInAppNotificationReadCommand): Promise<InAppNotification>;
}
