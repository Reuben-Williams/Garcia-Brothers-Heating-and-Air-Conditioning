import type { AppliedOrConflict, OperationActor, VersionedCommandContext } from "./operations.js";
import type {
  SavedView,
  SavedViewDomain,
  SaveViewCommand,
} from "./saved-views.js";
import { validateSavedViewFilter } from "./saved-views.js";
import type {
  ArchiveTagCommand,
  CreateTagCommand,
  GrowthTag,
  LinkTagCommand,
  TagLink,
  UnlinkTagCommand,
} from "./tags.js";
import {
  GrowthServiceError,
  requireAllowed,
  requireBoundedText,
  requireExpectedVersion,
  requireGrowthMember,
  type GrowthAuthorizationScope,
  type ScopedGrowthAuthorization,
} from "./service-authorization.js";

export interface TagAuthorizationQuery {
  readonly siteId: string;
  readonly actor: OperationActor;
  readonly action: "create" | "archive" | "list" | "link" | "unlink";
  readonly recordType?: "customer" | "lead";
  readonly recordId?: string;
}

export interface TagServiceRepository {
  /** Rechecks definitions, target records, site scope, assignment, and versions transactionally. */
  createAuthorized(input: { readonly command: CreateTagCommand; readonly scope: GrowthAuthorizationScope }): Promise<GrowthTag>;
  archiveAuthorized(input: { readonly command: ArchiveTagCommand; readonly scope: GrowthAuthorizationScope }): Promise<AppliedOrConflict<GrowthTag>>;
  listAuthorized(input: { readonly siteId: string; readonly memberId: string; readonly scope: GrowthAuthorizationScope }): Promise<readonly GrowthTag[]>;
  linkAuthorized(input: { readonly command: LinkTagCommand; readonly scope: GrowthAuthorizationScope }): Promise<TagLink>;
  unlinkAuthorized(input: { readonly command: UnlinkTagCommand; readonly scope: GrowthAuthorizationScope }): Promise<void>;
}

export interface TagService {
  create(command: CreateTagCommand): Promise<GrowthTag>;
  archive(command: ArchiveTagCommand): Promise<AppliedOrConflict<GrowthTag>>;
  list(input: { readonly siteId: string; readonly actor: OperationActor }): Promise<readonly GrowthTag[]>;
  link(command: LinkTagCommand): Promise<TagLink>;
  unlink(command: UnlinkTagCommand): Promise<void>;
}

export function createTagService(dependencies: {
  readonly repository: TagServiceRepository;
  readonly authorize: (input: TagAuthorizationQuery) => Promise<ScopedGrowthAuthorization>;
}): TagService {
  async function authorize(
    input: TagAuthorizationQuery,
    requiredScope?: GrowthAuthorizationScope,
  ): Promise<GrowthAuthorizationScope> {
    return requireAllowed(await dependencies.authorize(input), requiredScope);
  }

  return {
    async create(command) {
      requireGrowthMember(command.actor);
      requireBoundedText(command.label, 1, 100);
      if (command.color !== undefined) requireBoundedText(command.color, 1, 32);
      const scope = await authorize({ siteId: command.siteId, actor: command.actor, action: "create" }, "site");
      return dependencies.repository.createAuthorized({ command, scope });
    },
    async archive(command) {
      requireGrowthMember(command.actor);
      requireExpectedVersion(command.expectedVersion);
      const scope = await authorize({ siteId: command.siteId, actor: command.actor, action: "archive" }, "site");
      return dependencies.repository.archiveAuthorized({ command, scope });
    },
    async list(input) {
      const member = requireGrowthMember(input.actor);
      const scope = await authorize({ siteId: input.siteId, actor: input.actor, action: "list" });
      return dependencies.repository.listAuthorized({ siteId: input.siteId, memberId: member.id, scope });
    },
    async link(command) {
      requireGrowthMember(command.actor);
      requireBoundedText(command.recordId, 1, 128);
      const scope = await authorize({
        siteId: command.siteId,
        actor: command.actor,
        action: "link",
        recordType: command.recordType,
        recordId: command.recordId,
      });
      return dependencies.repository.linkAuthorized({ command, scope });
    },
    async unlink(command) {
      requireGrowthMember(command.actor);
      const scope = await authorize({ siteId: command.siteId, actor: command.actor, action: "unlink" });
      return dependencies.repository.unlinkAuthorized({ command, scope });
    },
  };
}

export interface SavedViewAuthorization extends ScopedGrowthAuthorization {
  readonly canShare: boolean;
}

export interface SavedViewAuthorizationQuery {
  readonly siteId: string;
  readonly actor: OperationActor;
  readonly action: "list" | "save" | "remove";
  readonly domain?: SavedViewDomain;
  readonly viewId?: string;
}

export type RemoveSavedViewCommand = VersionedCommandContext & { readonly viewId: string };

export interface SavedViewServiceRepository {
  /** Rechecks membership, ownership, sharing capability, scope, and versions transactionally. */
  listAuthorized(input: {
    readonly siteId: string;
    readonly memberId: string;
    readonly domain: SavedViewDomain;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<readonly SavedView[]>;
  saveAuthorized(input: {
    readonly command: SaveViewCommand;
    readonly ownerMemberId: string;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<AppliedOrConflict<SavedView>>;
  removeAuthorized(input: {
    readonly command: RemoveSavedViewCommand;
    readonly ownerMemberId: string;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<AppliedOrConflict<SavedView>>;
}

export interface SavedViewService {
  list(input: {
    readonly siteId: string;
    readonly actor: OperationActor;
    readonly domain: SavedViewDomain;
  }): Promise<readonly SavedView[]>;
  save(command: SaveViewCommand): Promise<AppliedOrConflict<SavedView>>;
  remove(command: RemoveSavedViewCommand): Promise<AppliedOrConflict<SavedView>>;
}

export function createSavedViewService(dependencies: {
  readonly repository: SavedViewServiceRepository;
  readonly allowedFields: Readonly<Record<SavedViewDomain, readonly string[]>>;
  readonly authorize: (input: SavedViewAuthorizationQuery) => Promise<SavedViewAuthorization>;
}): SavedViewService {
  return {
    async list(input) {
      const member = requireGrowthMember(input.actor);
      const authorization = await dependencies.authorize({
        siteId: input.siteId,
        actor: input.actor,
        action: "list",
        domain: input.domain,
      });
      const scope = requireAllowed(authorization);
      return dependencies.repository.listAuthorized({
        siteId: input.siteId,
        memberId: member.id,
        domain: input.domain,
        scope,
      });
    },
    async save(command) {
      const member = requireGrowthMember(command.actor);
      requireExpectedVersion(command.expectedVersion);
      requireBoundedText(command.name, 1, 100);
      const validation = validateSavedViewFilter(command.filter, dependencies.allowedFields[command.domain]);
      if (!validation.ok) throw new GrowthServiceError("invalid_filter");
      const authorization = await dependencies.authorize({
        siteId: command.siteId,
        actor: command.actor,
        action: "save",
        domain: command.domain,
        ...(command.viewId ? { viewId: command.viewId } : {}),
      });
      const scope = requireAllowed(authorization);
      if (command.shared && (!authorization.canShare || scope !== "site")) {
        throw new GrowthServiceError("not_authorized");
      }
      return dependencies.repository.saveAuthorized({ command, ownerMemberId: member.id, scope });
    },
    async remove(command) {
      const member = requireGrowthMember(command.actor);
      requireExpectedVersion(command.expectedVersion);
      const authorization = await dependencies.authorize({
        siteId: command.siteId,
        actor: command.actor,
        action: "remove",
        viewId: command.viewId,
      });
      const scope = requireAllowed(authorization);
      return dependencies.repository.removeAuthorized({ command, ownerMemberId: member.id, scope });
    },
  };
}
