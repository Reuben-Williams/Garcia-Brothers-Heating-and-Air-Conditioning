import type { AppliedOrConflict, OperationActor, ReadonlyJsonObject } from "./operations.js";

export interface DomainEventEnvelope<Payload extends ReadonlyJsonObject = ReadonlyJsonObject> {
  readonly id: string;
  readonly schemaVersion: number;
  readonly siteId: string;
  readonly type: string;
  readonly occurredAt: string;
  readonly actor: OperationActor;
  readonly correlationId: string;
  readonly causationId?: string;
  readonly aggregateType: string;
  readonly aggregateId: string;
  readonly aggregateVersion: number;
  readonly payload: Payload;
}

export interface AppendDomainEventCommand<Payload extends ReadonlyJsonObject = ReadonlyJsonObject> {
  readonly event: DomainEventEnvelope<Payload>;
  readonly expectedAggregateVersion: number;
  readonly idempotencyIdentity: "event.id";
}

export interface DomainEventStore {
  append<Payload extends ReadonlyJsonObject>(
    input: AppendDomainEventCommand<Payload>,
  ): Promise<AppliedOrConflict<DomainEventEnvelope<Payload>>>;
  read(siteId: string, eventId: string): Promise<DomainEventEnvelope | null>;
}
