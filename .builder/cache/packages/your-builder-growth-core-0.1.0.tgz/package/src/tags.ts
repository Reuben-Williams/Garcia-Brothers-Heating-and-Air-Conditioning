import type { AppliedOrConflict, CommandContext, VersionedCommandContext } from "./operations.js";

export interface GrowthTag {
  readonly id: string;
  readonly siteId: string;
  readonly label: string;
  readonly color?: string;
  readonly archived: boolean;
  readonly version: number;
}

export interface TagLink {
  readonly id: string;
  readonly siteId: string;
  readonly tagId: string;
  readonly recordType: "customer" | "lead";
  readonly recordId: string;
  readonly createdAt: string;
}

export interface CreateTagCommand extends CommandContext { readonly label: string; readonly color?: string; }
export interface ArchiveTagCommand extends VersionedCommandContext { readonly tagId: string; }
export interface LinkTagCommand extends CommandContext { readonly tagId: string; readonly recordType: "customer" | "lead"; readonly recordId: string; }
export interface UnlinkTagCommand extends CommandContext { readonly tagLinkId: string; }

export interface TagRepository {
  create(input: CreateTagCommand): Promise<GrowthTag>;
  archive(input: ArchiveTagCommand): Promise<AppliedOrConflict<GrowthTag>>;
  list(siteId: string): Promise<readonly GrowthTag[]>;
  link(input: LinkTagCommand): Promise<TagLink>;
  unlink(input: UnlinkTagCommand): Promise<void>;
}
