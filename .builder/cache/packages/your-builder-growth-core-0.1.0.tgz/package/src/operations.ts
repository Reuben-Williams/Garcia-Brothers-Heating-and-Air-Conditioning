export type JsonPrimitive = string | number | boolean | null;

export type JsonValue = JsonPrimitive | ReadonlyJsonObject | readonly JsonValue[];

export interface ReadonlyJsonObject {
  readonly [key: string]: JsonValue;
}

export type OperationActorType = "member" | "visitor" | "system" | "provider";

export interface MemberOperationActor {
  readonly type: "member";
  readonly id: string;
}

export interface ProviderOperationActor {
  readonly type: "provider";
  readonly id: string;
}

export interface VisitorOperationActor {
  readonly type: "visitor";
  readonly id?: string;
}

export interface SystemOperationActor {
  readonly type: "system";
  readonly id?: string;
}

export type OperationActor =
  | MemberOperationActor
  | ProviderOperationActor
  | VisitorOperationActor
  | SystemOperationActor;

export interface CommandContext {
  readonly siteId: string;
  readonly actor: OperationActor;
  readonly idempotencyKey: string;
}

export interface VersionedCommandContext extends CommandContext {
  readonly expectedVersion: number;
}

export interface VersionConflict {
  readonly status: "conflict";
  readonly reason: "version_conflict";
  readonly resourceType: string;
  readonly resourceId: string;
  readonly expectedVersion: number;
  readonly actualVersion: number;
}

export interface AppliedResult<Value> {
  readonly status: "applied";
  readonly value: Value;
}

export type AppliedOrConflict<Value> = AppliedResult<Value> | VersionConflict;

export type LeaseConflictReason = "expired" | "stale_token" | "worker_mismatch" | "version_conflict";

export interface JobLeaseResourceIdentity {
  readonly resourceType: "job";
  readonly siteId: string;
  readonly jobId: string;
}

export interface OutboxLeaseResourceIdentity {
  readonly resourceType: "outbox";
  readonly siteId: string;
  readonly outboxId: string;
}

export type LeaseResourceIdentity = JobLeaseResourceIdentity | OutboxLeaseResourceIdentity;

export interface LeaseAppliedResult<
  Value,
  Resource extends LeaseResourceIdentity = LeaseResourceIdentity,
> {
  readonly status: "applied";
  readonly resource: Resource;
  readonly value: Value;
}

export interface LeaseReplayResult<
  Value,
  Resource extends LeaseResourceIdentity = LeaseResourceIdentity,
> {
  readonly status: "replayed";
  readonly replayReason: "same_fence";
  readonly resource: Resource;
  readonly workerId: string;
  readonly leaseToken: string;
  readonly attempt: number;
  readonly value: Value;
}

export interface LeaseExpiredConflict<
  Resource extends LeaseResourceIdentity = LeaseResourceIdentity,
> {
  readonly status: "conflict";
  readonly reason: "expired";
  readonly resource: Resource;
  readonly leaseExpiresAt: string;
  readonly observedAt: string;
}

export interface LeaseStaleTokenConflict<
  Resource extends LeaseResourceIdentity = LeaseResourceIdentity,
> {
  readonly status: "conflict";
  readonly reason: "stale_token";
  readonly resource: Resource;
  readonly providedLeaseToken: string;
}

export interface LeaseWorkerMismatchConflict<
  Resource extends LeaseResourceIdentity = LeaseResourceIdentity,
> {
  readonly status: "conflict";
  readonly reason: "worker_mismatch";
  readonly resource: Resource;
  readonly providedWorkerId: string;
  readonly leasedWorkerId: string;
}

export interface LeaseVersionConflict<
  Resource extends LeaseResourceIdentity = LeaseResourceIdentity,
> {
  readonly status: "conflict";
  readonly reason: "version_conflict";
  readonly resource: Resource;
  readonly expectedVersion: number;
  readonly actualVersion: number;
}

export type LeaseConflict<Resource extends LeaseResourceIdentity = LeaseResourceIdentity> =
  | LeaseExpiredConflict<Resource>
  | LeaseStaleTokenConflict<Resource>
  | LeaseWorkerMismatchConflict<Resource>
  | LeaseVersionConflict<Resource>;

export type LeaseResult<
  Value,
  Resource extends LeaseResourceIdentity = LeaseResourceIdentity,
> = LeaseAppliedResult<Value, Resource> | LeaseReplayResult<Value, Resource> | LeaseConflict<Resource>;
