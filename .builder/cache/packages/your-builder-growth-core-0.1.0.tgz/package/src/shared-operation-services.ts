import type {
  EndRecordAssignmentCommand,
  RecordAssignment,
  SetRecordAssignmentCommand,
  AssignableGrowthRecordType,
} from "./assignments.js";
import type { AppliedOrConflict, OperationActor } from "./operations.js";
import type { RecordServiceEventCommand, ServiceEvent } from "./service-events.js";
import type {
  AssignTaskCommand,
  AuthorizationParent,
  CancelTaskCommand,
  CompleteTaskCommand,
  CreateTaskCommand,
  TaskSummary,
} from "./tasks.js";
import {
  GrowthServiceError,
  requireAllowed,
  requireBoundedText,
  requireExpectedVersion,
  requireGrowthMember,
  type GrowthAuthorizationScope,
  type ScopedGrowthAuthorization,
} from "./service-authorization.js";

export interface SharedOperationAuthorizationQuery {
  readonly siteId: string;
  readonly actor: OperationActor;
  readonly resource: "assignment" | "task" | "service_event";
  readonly action: string;
  readonly recordType?: string;
  readonly recordId?: string;
}

export type SharedOperationAuthorizer = (
  input: SharedOperationAuthorizationQuery,
) => Promise<ScopedGrowthAuthorization>;

export interface ScopedAssignmentRepository {
  /** Rechecks site membership, assignment scope, target membership, and versions transactionally. */
  listAuthorized(input: {
    readonly siteId: string;
    readonly memberId: string;
    readonly recordType: AssignableGrowthRecordType;
    readonly recordId: string;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<readonly RecordAssignment[]>;
  setAuthorized(input: { readonly command: SetRecordAssignmentCommand; readonly scope: GrowthAuthorizationScope }): Promise<AppliedOrConflict<RecordAssignment>>;
  endAuthorized(input: { readonly command: EndRecordAssignmentCommand; readonly scope: GrowthAuthorizationScope }): Promise<AppliedOrConflict<RecordAssignment>>;
}

export function createRecordAssignmentService(dependencies: {
  readonly repository: ScopedAssignmentRepository;
  readonly authorize: SharedOperationAuthorizer;
}) {
  return {
    async list(input: {
      readonly siteId: string;
      readonly actor: OperationActor;
      readonly recordType: AssignableGrowthRecordType;
      readonly recordId: string;
    }): Promise<readonly RecordAssignment[]> {
      const member = requireGrowthMember(input.actor);
      const scope = requireAllowed(await dependencies.authorize({
        siteId: input.siteId,
        actor: input.actor,
        resource: "assignment",
        action: "list",
        recordType: input.recordType,
        recordId: input.recordId,
      }));
      return dependencies.repository.listAuthorized({
        siteId: input.siteId,
        memberId: member.id,
        recordType: input.recordType,
        recordId: input.recordId,
        scope,
      });
    },
    async set(command: SetRecordAssignmentCommand): Promise<AppliedOrConflict<RecordAssignment>> {
      requireGrowthMember(command.actor);
      requireExpectedVersion(command.expectedVersion);
      const scope = requireAllowed(await dependencies.authorize({
        siteId: command.siteId,
        actor: command.actor,
        resource: "assignment",
        action: "set",
        recordType: command.recordType,
        recordId: command.recordId,
      }));
      return dependencies.repository.setAuthorized({ command, scope });
    },
    async end(command: EndRecordAssignmentCommand): Promise<AppliedOrConflict<RecordAssignment>> {
      requireGrowthMember(command.actor);
      requireExpectedVersion(command.expectedVersion);
      requireBoundedText(command.reason, 1, 500);
      const scope = requireAllowed(await dependencies.authorize({
        siteId: command.siteId,
        actor: command.actor,
        resource: "assignment",
        action: "end",
      }));
      return dependencies.repository.endAuthorized({ command, scope });
    },
  };
}

export interface ExpectedAuthorizationParentVersion extends AuthorizationParent {
  readonly expectedVersion: number;
}

export interface CreateScopedTaskCommand extends CreateTaskCommand {
  readonly expectedParentVersions: readonly ExpectedAuthorizationParentVersion[];
}

export interface ScopedTaskRepository {
  /** Rechecks every authorization parent, site/assigned scope, assignee, and version transactionally. */
  createAuthorized(input: { readonly command: CreateScopedTaskCommand; readonly scope: GrowthAuthorizationScope }): Promise<TaskSummary>;
  assignAuthorized(input: { readonly command: AssignTaskCommand; readonly scope: GrowthAuthorizationScope }): Promise<AppliedOrConflict<TaskSummary>>;
  completeAuthorized(input: { readonly command: CompleteTaskCommand; readonly scope: GrowthAuthorizationScope }): Promise<AppliedOrConflict<TaskSummary>>;
  cancelAuthorized(input: { readonly command: CancelTaskCommand; readonly scope: GrowthAuthorizationScope }): Promise<AppliedOrConflict<TaskSummary>>;
}

function validateTaskParents(command: CreateScopedTaskCommand): void {
  if (
    command.authorizationParents.length === 0 ||
    command.authorizationParents.length > 10 ||
    command.expectedParentVersions.length !== command.authorizationParents.length
  ) {
    throw new GrowthServiceError("invalid_request");
  }
  for (const parent of command.authorizationParents) {
    const matches = command.expectedParentVersions.filter(
      candidate => candidate.type === parent.type && candidate.id === parent.id,
    );
    if (matches.length !== 1) throw new GrowthServiceError("invalid_request");
    requireExpectedVersion(matches[0]!.expectedVersion);
  }
}

export function createTaskOrchestrationService(dependencies: {
  readonly repository: ScopedTaskRepository;
  readonly authorize: SharedOperationAuthorizer;
}) {
  async function mutationScope(
    command: { readonly siteId: string; readonly actor: OperationActor },
    action: string,
    recordId?: string,
  ): Promise<GrowthAuthorizationScope> {
    requireGrowthMember(command.actor);
    return requireAllowed(await dependencies.authorize({
      siteId: command.siteId,
      actor: command.actor,
      resource: "task",
      action,
      ...(recordId ? { recordId } : {}),
    }));
  }

  return {
    async create(command: CreateScopedTaskCommand): Promise<TaskSummary> {
      requireGrowthMember(command.actor);
      requireBoundedText(command.title, 1, 200);
      validateTaskParents(command);
      const scope = await mutationScope(command, "create", command.relatedId);
      return dependencies.repository.createAuthorized({ command, scope });
    },
    async assign(command: AssignTaskCommand): Promise<AppliedOrConflict<TaskSummary>> {
      requireExpectedVersion(command.expectedVersion);
      const scope = await mutationScope(command, "assign", command.taskId);
      return dependencies.repository.assignAuthorized({ command, scope });
    },
    async complete(command: CompleteTaskCommand): Promise<AppliedOrConflict<TaskSummary>> {
      requireExpectedVersion(command.expectedVersion);
      const scope = await mutationScope(command, "complete", command.taskId);
      return dependencies.repository.completeAuthorized({ command, scope });
    },
    async cancel(command: CancelTaskCommand): Promise<AppliedOrConflict<TaskSummary>> {
      requireExpectedVersion(command.expectedVersion);
      requireBoundedText(command.reason, 1, 500);
      const scope = await mutationScope(command, "cancel", command.taskId);
      return dependencies.repository.cancelAuthorized({ command, scope });
    },
  };
}

export interface RecordScopedServiceEventCommand extends RecordServiceEventCommand {
  readonly expectedContactVersion: number;
  readonly expectedLeadVersion?: number;
}

export interface ScopedServiceEventRepository {
  /** Rechecks event parents, site/assigned scope, correlation identity, and versions transactionally. */
  recordAuthorized(input: {
    readonly command: RecordScopedServiceEventCommand;
    readonly scope: GrowthAuthorizationScope;
  }): Promise<ServiceEvent>;
}

export function createServiceEventOrchestrationService(dependencies: {
  readonly repository: ScopedServiceEventRepository;
  readonly authorize: SharedOperationAuthorizer;
}) {
  return {
    async record(command: RecordScopedServiceEventCommand): Promise<ServiceEvent> {
      const actor: OperationActor = command.origin.type === "manual"
        ? command.origin.actor
        : { type: "provider", id: command.origin.integrationId };
      if (command.origin.type === "manual" && actor.type === "member") {
        requireGrowthMember(actor);
      } else if (command.origin.type === "manual" && actor.type !== "system") {
        throw new GrowthServiceError("not_authorized");
      }
      requireExpectedVersion(command.expectedContactVersion);
      if ((command.leadId === undefined) !== (command.expectedLeadVersion === undefined)) {
        throw new GrowthServiceError("invalid_request");
      }
      if (command.expectedLeadVersion !== undefined) requireExpectedVersion(command.expectedLeadVersion);
      requireBoundedText(command.correlationId, 1, 200);
      const scope = requireAllowed(await dependencies.authorize({
        siteId: command.siteId,
        actor,
        resource: "service_event",
        action: "record",
        recordType: command.leadId ? "lead" : "customer",
        recordId: command.leadId ?? command.contactId,
      }));
      return dependencies.repository.recordAuthorized({ command, scope });
    },
  };
}
