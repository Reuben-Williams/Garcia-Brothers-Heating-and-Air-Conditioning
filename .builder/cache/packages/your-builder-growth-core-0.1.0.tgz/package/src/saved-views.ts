import type { AppliedOrConflict, JsonValue, VersionedCommandContext } from "./operations.js";

export const SAVED_VIEW_FILTER_OPERATORS = Object.freeze([
  "equals",
  "not_equals",
  "in",
  "contains",
  "before",
  "after",
  "is_empty",
] as const);
export type SavedViewFilterOperator = (typeof SAVED_VIEW_FILTER_OPERATORS)[number];
export type SavedViewDomain = "leads" | "customers" | "base_submissions";

export interface SavedViewFilterClause {
  readonly field: string;
  readonly operator: SavedViewFilterOperator;
  readonly value?: JsonValue;
}

export interface SavedViewFilterAst {
  readonly version: 1;
  readonly conjunction: "all" | "any";
  readonly clauses: readonly SavedViewFilterClause[];
}

export interface SavedView {
  readonly id: string;
  readonly siteId: string;
  readonly ownerMemberId: string;
  readonly domain: SavedViewDomain;
  readonly name: string;
  readonly shared: boolean;
  readonly filter: SavedViewFilterAst;
  readonly version: number;
  readonly updatedAt: string;
}

export interface SaveViewCommand extends VersionedCommandContext {
  readonly viewId?: string;
  readonly domain: SavedViewDomain;
  readonly name: string;
  readonly shared: boolean;
  readonly filter: SavedViewFilterAst;
}

export interface SavedViewRepository {
  list(siteId: string, memberId: string, domain: SavedViewDomain): Promise<readonly SavedView[]>;
  save(input: SaveViewCommand): Promise<AppliedOrConflict<SavedView>>;
  remove(input: VersionedCommandContext & { readonly viewId: string }): Promise<AppliedOrConflict<SavedView>>;
}

export type SavedViewFilterValidation =
  | { readonly ok: true; readonly value: SavedViewFilterAst }
  | { readonly ok: false; readonly code: "too_many_clauses" | "invalid_field" | "invalid_operator" };

export function validateSavedViewFilter(
  filter: SavedViewFilterAst,
  allowedFields: readonly string[],
): SavedViewFilterValidation {
  if (filter.clauses.length > 20) return { ok: false, code: "too_many_clauses" };
  for (const clause of filter.clauses) {
    if (!allowedFields.includes(clause.field)) return { ok: false, code: "invalid_field" };
    if (!(SAVED_VIEW_FILTER_OPERATORS as readonly string[]).includes(clause.operator)) {
      return { ok: false, code: "invalid_operator" };
    }
  }
  return { ok: true, value: filter };
}
