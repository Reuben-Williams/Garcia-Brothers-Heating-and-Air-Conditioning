import type {
  AppliedOrConflict,
  CommandContext,
  OperationActor,
  VersionedCommandContext,
} from "./operations.js";

export type SuppressionChannel = "email" | "sms";

export interface SuppressionRecord {
  readonly id: string;
  readonly siteId: string;
  readonly channel: SuppressionChannel;
  readonly normalizedDestinationHash: string;
  readonly reasonCode: string;
  readonly source: string;
  readonly retainedForPrevention: boolean;
  readonly version: number;
}

export interface AddSuppressionCommand extends CommandContext {
  readonly channel: SuppressionChannel;
  readonly normalizedDestinationHash: string;
  readonly reasonCode: string;
  readonly source: string;
}

export interface SuppressionEvaluation {
  readonly suppressed: boolean;
  readonly reasonCode?: string;
  readonly suppressionId?: string;
}

export interface ReconcileProviderSuppressionCommand {
  readonly siteId: string;
  readonly actor: OperationActor;
  readonly provider: string;
  readonly providerEventId: string;
  readonly idempotencyIdentity: "providerEventId";
  readonly channel: SuppressionChannel;
  readonly normalizedDestinationHash: string;
  readonly reasonCode: string;
  readonly source: string;
}

export interface RetainSuppressionEvidenceCommand extends VersionedCommandContext {
  readonly suppressionId: string;
  readonly source: string;
}

export interface SuppressionRepository {
  add(input: AddSuppressionCommand): Promise<SuppressionRecord>;
  evaluate(
    siteId: string,
    channel: SuppressionChannel,
    normalizedDestinationHash: string,
  ): Promise<SuppressionEvaluation>;
  reconcileProviderFact(input: ReconcileProviderSuppressionCommand): Promise<SuppressionRecord>;
  retainPreventionEvidence(
    input: RetainSuppressionEvidenceCommand,
  ): Promise<AppliedOrConflict<SuppressionRecord>>;
}
