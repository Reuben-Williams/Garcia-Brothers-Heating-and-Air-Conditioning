import type { CommandContext } from "./operations.js";

export type ConsentChannel = "email" | "sms";
export type ConsentStatus = "granted" | "denied";

export interface ConsentEvidenceReference {
  readonly system: string;
  readonly referenceId: string;
}

export type ConsentEvidenceLocator =
  | {
      readonly evidenceReference: ConsentEvidenceReference;
      readonly evidenceDigest?: string;
    }
  | {
      readonly evidenceReference?: never;
      readonly evidenceDigest: string;
    };

export type RecordConsentEvidenceCommand = CommandContext &
  ConsentEvidenceLocator & {
    readonly contactId: string;
    readonly channel: ConsentChannel;
    readonly purpose: string;
    readonly status: ConsentStatus;
    readonly source: string;
    readonly occurredAt: string;
    readonly policyVersion: string;
  };

export interface EvaluateConsentQuery {
  readonly siteId: string;
  readonly contactId: string;
  readonly channel: ConsentChannel;
  readonly purpose: string;
  readonly at: string;
}

export interface RevokeConsentCommand extends CommandContext {
  readonly contactId: string;
  readonly channel: ConsentChannel;
  readonly purpose: string;
  readonly occurredAt: string;
  readonly source: string;
}

export interface ExplainConsentQuery extends EvaluateConsentQuery {}

export interface ConsentEvaluation {
  readonly allowed: boolean;
  readonly reasonCode: string;
  readonly evidenceId?: string;
}

export interface CustomerConsentProjection {
  readonly id: string;
  readonly siteId: string;
  readonly contactId: string;
  readonly baseConsentEvidenceId: string;
  readonly channel: ConsentChannel;
  readonly purpose: string;
  readonly status: ConsentStatus;
  readonly capturedAt: string;
  readonly revokedAt?: string;
}

export interface ConsentExplanation {
  readonly code: string;
  readonly message: string;
  readonly evidenceId?: string;
}

export interface ConsentService {
  recordEvidence(input: RecordConsentEvidenceCommand): Promise<string>;
  evaluate(input: EvaluateConsentQuery): Promise<ConsentEvaluation>;
  revoke(input: RevokeConsentCommand): Promise<void>;
  explain(input: ExplainConsentQuery): Promise<readonly ConsentExplanation[]>;
}
