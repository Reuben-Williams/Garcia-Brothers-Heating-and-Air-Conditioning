import type { MemberOperationActor, SystemOperationActor } from "./operations.js";

export type ServiceEventKind =
  | "estimate.sent"
  | "estimate.accepted"
  | "estimate.declined"
  | "appointment.scheduled"
  | "appointment.rescheduled"
  | "appointment.cancelled"
  | "appointment.completed";

export const SERVICE_EVENT_KINDS = Object.freeze([
  "estimate.sent",
  "estimate.accepted",
  "estimate.declined",
  "appointment.scheduled",
  "appointment.rescheduled",
  "appointment.cancelled",
  "appointment.completed",
] as const satisfies readonly ServiceEventKind[]);

export type ManualServiceEventActor = MemberOperationActor | SystemOperationActor;

export interface ManualServiceEventOrigin {
  readonly type: "manual";
  readonly actor: ManualServiceEventActor;
}

export interface IntegrationServiceEventOrigin {
  readonly type: "integration";
  readonly integrationId: string;
  readonly providerEventId: string;
}

export type ServiceEventOrigin = ManualServiceEventOrigin | IntegrationServiceEventOrigin;

export interface ServiceEvent {
  readonly id: string;
  readonly siteId: string;
  readonly contactId: string;
  readonly leadId?: string;
  readonly kind: ServiceEventKind;
  readonly purpose?: "estimate" | "service";
  readonly scheduledAt?: string;
  readonly origin: ServiceEventOrigin;
  readonly occurredAt: string;
  readonly correlationId: string;
  readonly replacesEventId?: string;
}

export interface RecordServiceEventCommand {
  readonly siteId: string;
  readonly contactId: string;
  readonly leadId?: string;
  readonly kind: ServiceEventKind;
  readonly purpose?: "estimate" | "service";
  readonly scheduledAt?: string;
  readonly origin: ServiceEventOrigin;
  readonly occurredAt: string;
  readonly correlationId: string;
  readonly replacesEventId?: string;
  readonly idempotencyKey: string;
}

export interface ServiceEventRepository {
  record(input: RecordServiceEventCommand): Promise<ServiceEvent>;
  list(siteId: string, contactId: string): Promise<readonly ServiceEvent[]>;
}
