import type { ContactRepository } from "./contacts.js";
import {
  normalizeEmailIdentity,
  normalizePhoneIdentity,
  resolveIdentityMatch,
  type AcceptedPhoneRegion,
  type ContactIdentityRepository,
  type IdentityMatchResult,
} from "./identities.js";

export type IdentityReviewEvidence = "name" | "zip" | "address";

export interface IdentityReviewEvidenceQuery {
  readonly siteId: string;
  readonly displayName?: string;
  readonly serviceAreaZip?: string;
  readonly serviceAddress?: string;
}

export interface IdentityReviewEvidenceProvider {
  find(input: IdentityReviewEvidenceQuery): Promise<readonly IdentityReviewEvidence[]>;
}

export interface IdentityMatchingInput extends IdentityReviewEvidenceQuery {
  readonly email?: string;
  readonly phone?: string;
  readonly phoneRegion?: AcceptedPhoneRegion;
}

export interface IdentityMatchingService {
  match(input: IdentityMatchingInput): Promise<IdentityMatchResult>;
}

export type IdentityMatchingErrorCode =
  | "invalid_email"
  | "invalid_phone"
  | "repository_inconsistent";

export class IdentityMatchingError extends Error {
  readonly code: IdentityMatchingErrorCode;

  constructor(code: IdentityMatchingErrorCode) {
    super(code);
    this.name = "IdentityMatchingError";
    this.code = code;
  }
}

export interface IdentityMatchingDependencies {
  readonly identities: ContactIdentityRepository;
  readonly contacts: ContactRepository;
  readonly reviewEvidence?: IdentityReviewEvidenceProvider;
}

const REVIEW_EVIDENCE_ORDER: readonly IdentityReviewEvidence[] = ["name", "zip", "address"];

export function createIdentityMatchingService(
  dependencies: IdentityMatchingDependencies,
): IdentityMatchingService {
  return {
    async match(input) {
      const email = input.email === undefined ? undefined : normalizeEmailIdentity(input.email);
      if (email && !email.ok) throw new IdentityMatchingError(email.code);

      const phone = input.phone === undefined
        ? undefined
        : normalizePhoneIdentity(input.phone, input.phoneRegion ?? "US");
      if (phone && !phone.ok) throw new IdentityMatchingError(phone.code);

      const [emailIdentity, phoneIdentity] = await Promise.all([
        email?.ok ? dependencies.identities.findExact(input.siteId, "email", email.value) : null,
        phone?.ok ? dependencies.identities.findExact(input.siteId, "phone", phone.value) : null,
      ]);

      const contactIds = [...new Set([emailIdentity?.contactId, phoneIdentity?.contactId].filter(
        (value): value is string => value !== undefined,
      ))];
      const contacts = await Promise.all(contactIds.map((contactId) => dependencies.contacts.get(input.siteId, contactId)));
      if (contacts.some((contact, index) => !contact || contact.siteId !== input.siteId || contact.id !== contactIds[index])) {
        throw new IdentityMatchingError("repository_inconsistent");
      }

      if (contactIds.length > 0) {
        return resolveIdentityMatch({
          emailContactId: emailIdentity?.contactId,
          phoneContactId: phoneIdentity?.contactId,
        });
      }

      const foundEvidence = await dependencies.reviewEvidence?.find({
        siteId: input.siteId,
        displayName: input.displayName,
        serviceAreaZip: input.serviceAreaZip,
        serviceAddress: input.serviceAddress,
      });
      const evidence = REVIEW_EVIDENCE_ORDER.filter((value) => foundEvidence?.includes(value));
      return resolveIdentityMatch({ reviewEvidence: evidence });
    },
  };
}
