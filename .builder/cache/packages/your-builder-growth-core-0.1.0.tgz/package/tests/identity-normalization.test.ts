import { describe, expect, it } from "vitest";
import {
  normalizeEmailIdentity,
  normalizePhoneIdentity,
  resolveIdentityMatch,
} from "../src/index.js";

describe("identity normalization", () => {
  it.each([
    [" Person+tag@Example.COM ", "person+tag@example.com"],
    ["\u00a0first.last@example.com\u2003", "first.last@example.com"],
  ])("normalizes valid ASCII email without provider rewriting", (input, expected) => {
    expect(normalizeEmailIdentity(input)).toEqual({ ok: true, value: expected });
  });

  it.each(["", "not-an-email", "josé@example.com", "person@localhost", "a b@example.com"])(
    "rejects invalid email %s",
    (input) => expect(normalizeEmailIdentity(input)).toEqual({ ok: false, code: "invalid_email" }),
  );

  it.each([
    ["(302) 555-0123", "US", "+13025550123"],
    ["416 555 0123", "CA", "+14165550123"],
    ["\u00a0+1 302 555 0123\u2003", "US", "+13025550123"],
  ] as const)("normalizes %s in %s to E.164", (input, region, expected) => {
    expect(normalizePhoneIdentity(input, region)).toEqual({ ok: true, value: expected });
  });

  it.each(["", "555", "+44 20 7946 0958", "(302) 555-0123 ext 4", "302-555-0123 x4"])(
    "rejects malformed, out-of-region, or extended phone %s",
    (input) => expect(normalizePhoneIdentity(input, "US")).toEqual({ ok: false, code: "invalid_phone" }),
  );

  it("returns exhaustive exact, conflict, new, and review outcomes without auto-merging", () => {
    expect(resolveIdentityMatch({ emailContactId: "c1", phoneContactId: "c1" })).toEqual({
      kind: "exact_contact",
      contactId: "c1",
      matchedIdentityKinds: ["email", "phone"],
    });
    expect(resolveIdentityMatch({ emailContactId: "c1", phoneContactId: "c2" })).toEqual({
      kind: "identity_conflict",
      matchedContactIds: ["c1", "c2"],
    });
    expect(resolveIdentityMatch({ reviewEvidence: ["name", "zip"] })).toEqual({
      kind: "review_suggested",
      evidence: ["name", "zip"],
    });
    expect(resolveIdentityMatch({})).toEqual({ kind: "new_identity" });
  });
});
