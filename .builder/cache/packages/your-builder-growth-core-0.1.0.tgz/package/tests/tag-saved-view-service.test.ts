import { describe, expect, it, vi } from "vitest";
import type {
  GrowthTag,
  SavedView,
  SavedViewServiceRepository,
  TagLink,
  TagServiceRepository,
} from "../src/index.js";
import {
  createSavedViewService,
  createTagService,
  GrowthServiceError,
} from "../src/index.js";

const actor = { type: "member" as const, id: "member-1" };
const tag: GrowthTag = { id: "tag-1", siteId: "site-1", label: "Priority", archived: false, version: 1 };
const tagLink = (recordType: "customer" | "lead"): TagLink => ({
  id: `link-${recordType}`, siteId: "site-1", tagId: "tag-1", recordType, recordId: `${recordType}-1`,
  createdAt: "2026-07-18T00:00:00.000Z",
});

describe("tag service", () => {
  it("limits tag definitions to site scope but links both customers and leads at assigned scope", async () => {
    const repository: TagServiceRepository = {
      createAuthorized: vi.fn(async () => tag),
      archiveAuthorized: vi.fn(async () => ({ status: "applied" as const, value: { ...tag, archived: true, version: 2 } })),
      listAuthorized: vi.fn(async () => [tag]),
      linkAuthorized: vi.fn(async ({ command }) => tagLink(command.recordType)),
      unlinkAuthorized: vi.fn(async () => undefined),
    };
    const assigned = createTagService({ repository, authorize: vi.fn(async () => ({ allowed: true as const, scope: "assigned" as const })) });

    await expect(assigned.create({ siteId: "site-1", actor, idempotencyKey: "tag-create", label: "Priority" }))
      .rejects.toEqual(expect.objectContaining<Partial<GrowthServiceError>>({ code: "not_authorized" }));
    for (const recordType of ["customer", "lead"] as const) {
      await expect(assigned.link({
        siteId: "site-1", actor, idempotencyKey: `link-${recordType}`, tagId: "tag-1", recordType, recordId: `${recordType}-1`,
      })).resolves.toMatchObject({ recordType });
    }
    expect(repository.linkAuthorized).toHaveBeenNthCalledWith(1, expect.objectContaining({ scope: "assigned", command: expect.objectContaining({ recordType: "customer" }) }));
    expect(repository.linkAuthorized).toHaveBeenNthCalledWith(2, expect.objectContaining({ scope: "assigned", command: expect.objectContaining({ recordType: "lead" }) }));
  });
});

const privateView: SavedView = {
  id: "view-1", siteId: "site-1", ownerMemberId: actor.id, domain: "customers", name: "Heating",
  shared: false, filter: { version: 1, conjunction: "all", clauses: [{ field: "service_area_zip", operator: "equals", value: "07105" }] },
  version: 1, updatedAt: "2026-07-18T00:00:00.000Z",
};

describe("saved view service", () => {
  it("validates filters and permits assigned members to save only private owned views", async () => {
    const repository: SavedViewServiceRepository = {
      listAuthorized: vi.fn(async () => [privateView]),
      saveAuthorized: vi.fn(async () => ({ status: "applied" as const, value: privateView })),
      removeAuthorized: vi.fn(async () => ({ status: "applied" as const, value: privateView })),
    };
    const service = createSavedViewService({
      repository,
      allowedFields: { customers: ["service_area_zip"], leads: ["status"], base_submissions: ["classification"] },
      authorize: vi.fn(async () => ({ allowed: true as const, canShare: false, scope: "assigned" as const })),
    });
    const command = {
      siteId: "site-1", actor, idempotencyKey: "view-1", expectedVersion: 0, domain: "customers" as const,
      name: "Heating", shared: false, filter: privateView.filter,
    };

    await expect(service.save(command)).resolves.toMatchObject({ status: "applied" });
    expect(repository.saveAuthorized).toHaveBeenCalledWith({ command, ownerMemberId: actor.id, scope: "assigned" });
    await expect(service.save({ ...command, shared: true }))
      .rejects.toEqual(expect.objectContaining<Partial<GrowthServiceError>>({ code: "not_authorized" }));
    await expect(service.save({ ...command, filter: { ...command.filter, clauses: [{ field: "raw_sql", operator: "equals" }] } }))
      .rejects.toEqual(expect.objectContaining<Partial<GrowthServiceError>>({ code: "invalid_filter" }));
  });
});
