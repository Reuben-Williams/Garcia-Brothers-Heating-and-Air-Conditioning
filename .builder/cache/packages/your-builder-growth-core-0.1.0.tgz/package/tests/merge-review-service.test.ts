import { describe, expect, it, vi } from "vitest";
import type {
  Contact,
  ContactMergeSuggestion,
  ContactRepository,
  MergeReviewServiceRepository,
} from "../src/index.js";
import { createMergeReviewService, MergeReviewError } from "../src/index.js";

const actor = { type: "member" as const, id: "manager-1" };
const suggestion = (state: ContactMergeSuggestion["state"] = "suggested"): ContactMergeSuggestion => ({
  id: "suggestion-1",
  siteId: "site-1",
  candidateContactIds: ["contact-source", "contact-target"],
  evidence: ["name", "zip"],
  confidence: "medium",
  state,
  version: state === "suggested" ? 1 : 2,
});

const mergedContact: Contact = {
  id: "contact-target",
  siteId: "site-1",
  displayName: "Merged customer",
  version: 4,
  createdAt: "2026-07-18T00:00:00.000Z",
  updatedAt: "2026-07-18T01:00:00.000Z",
};

function createRepositories(state: ContactMergeSuggestion["state"] = "suggested") {
  const reviews: MergeReviewServiceRepository = {
    suggest: vi.fn(async () => suggestion()),
    get: vi.fn(async () => suggestion(state)),
    disposition: vi.fn(async (input) => ({
      status: "applied" as const,
      value: suggestion(input.state),
    })),
    listAliases: vi.fn(async () => []),
  };
  const contacts: ContactRepository = {
    create: vi.fn(async () => { throw new Error("not used"); }),
    match: vi.fn(async () => []),
    get: vi.fn(async () => null),
    update: vi.fn(async () => { throw new Error("not used"); }),
    proposeMerge: vi.fn(async () => { throw new Error("not used"); }),
    executeReviewedMerge: vi.fn(async () => ({ status: "applied" as const, value: mergedContact })),
    exportContactRecord: vi.fn(async () => ({})),
    pseudonymizeContactRecord: vi.fn(async () => { throw new Error("not used"); }),
  };
  return { reviews, contacts };
}

describe("merge review service", () => {
  it("requires site-wide review authority and only dispositions the suggestion", async () => {
    const repositories = createRepositories();
    const service = createMergeReviewService(repositories);
    const command = {
      siteId: "site-1",
      actor,
      idempotencyKey: "review-1",
      expectedVersion: 1,
      suggestionId: "suggestion-1",
      decision: "accept" as const,
    };

    await expect(service.review(command, { canReview: false }))
      .rejects.toEqual(expect.objectContaining<Partial<MergeReviewError>>({ code: "not_authorized" }));
    await expect(service.review(command, { canReview: true })).resolves.toMatchObject({
      status: "applied",
      value: { state: "accepted" },
    });
    expect(repositories.contacts.executeReviewedMerge).not.toHaveBeenCalled();
  });

  it("executes a merge only after accepted review and with both contact versions", async () => {
    const pending = createRepositories("suggested");
    const accepted = createRepositories("accepted");
    const command = {
      siteId: "site-1",
      actor,
      idempotencyKey: "merge-1",
      suggestionId: "suggestion-1",
      sourceId: "contact-source",
      targetId: "contact-target",
      expectedSourceVersion: 2,
      expectedTargetVersion: 3,
    };

    await expect(createMergeReviewService(pending).executeAccepted(command, { canReview: true }))
      .rejects.toEqual(expect.objectContaining<Partial<MergeReviewError>>({ code: "review_not_accepted" }));
    await expect(createMergeReviewService(accepted).executeAccepted(command, { canReview: true }))
      .resolves.toEqual({ status: "applied", value: mergedContact });
    expect(accepted.contacts.executeReviewedMerge).toHaveBeenCalledWith(expect.objectContaining({
      expectedSourceVersion: 2,
      expectedTargetVersion: 3,
    }));
  });
});
