import { describe, expect, expectTypeOf, it } from "vitest";
import type {
  ContactIdentityRepository,
  ContactPreferenceRepository,
  DataExportRepository,
  DeletionRequestRepository,
  InAppNotificationRepository,
  MergeReviewRepository,
  RecordAssignmentRepository,
  SavedViewRepository,
  TagRepository,
  TaskRepository,
} from "../src/index.js";
import {
  ASSIGNABLE_GROWTH_RECORD_TYPES,
  SAVED_VIEW_FILTER_OPERATORS,
} from "../src/index.js";

const notImplemented = async (): Promise<never> => {
  throw new Error("typed contract double");
};

const typedRepositoryDoubles = [
  { findExact: notImplemented, listForContact: notImplemented, append: notImplemented } satisfies ContactIdentityRepository,
  { create: notImplemented, archive: notImplemented, list: notImplemented, link: notImplemented, unlink: notImplemented } satisfies TagRepository,
  { list: notImplemented, set: notImplemented, clear: notImplemented } satisfies ContactPreferenceRepository,
  { list: notImplemented, set: notImplemented, end: notImplemented } satisfies RecordAssignmentRepository,
  { create: notImplemented, listForRecipient: notImplemented, markRead: notImplemented } satisfies InAppNotificationRepository,
  { list: notImplemented, save: notImplemented, remove: notImplemented } satisfies SavedViewRepository,
  { suggest: notImplemented, disposition: notImplemented, listAliases: notImplemented } satisfies MergeReviewRepository,
  { request: notImplemented, get: notImplemented, transition: notImplemented } satisfies DataExportRepository,
  { request: notImplemented, get: notImplemented, transition: notImplemented } satisfies DeletionRequestRepository,
  {
    create: notImplemented,
    assign: notImplemented,
    complete: notImplemented,
    cancel: notImplemented,
    listByRelatedRecord: notImplemented,
  } satisfies TaskRepository,
];

describe("shared growth record contracts", () => {
  it("freezes assignment resources and validated filter operators", () => {
    expect(ASSIGNABLE_GROWTH_RECORD_TYPES).toEqual(["lead", "customer", "task"]);
    expect(SAVED_VIEW_FILTER_OPERATORS).toEqual([
      "equals",
      "not_equals",
      "in",
      "contains",
      "before",
      "after",
      "is_empty",
    ]);
  });

  it("requires repositories for identities, tags, preferences, assignment, notifications, views, merge, and privacy", () => {
    expectTypeOf<ContactIdentityRepository>().toBeObject();
    expectTypeOf<TagRepository>().toBeObject();
    expectTypeOf<ContactPreferenceRepository>().toBeObject();
    expectTypeOf<RecordAssignmentRepository>().toBeObject();
    expectTypeOf<InAppNotificationRepository>().toBeObject();
    expectTypeOf<SavedViewRepository>().toBeObject();
    expectTypeOf<MergeReviewRepository>().toBeObject();
    expectTypeOf<DataExportRepository>().toBeObject();
    expectTypeOf<DeletionRequestRepository>().toBeObject();
    expectTypeOf<Parameters<TaskRepository["create"]>[0]>().toMatchTypeOf<{
      authorizationParents: readonly { type: "lead" | "customer" | "task"; id: string }[];
      selfAssignmentIntent: boolean;
    }>();
    expect(typedRepositoryDoubles).toHaveLength(10);
  });

  it("keeps service-event and outbox metadata additive", async () => {
    const core = await import("../src/index.js");
    expect(core.SERVICE_EVENT_KINDS).toEqual([
      "estimate.sent",
      "estimate.accepted",
      "estimate.declined",
      "appointment.scheduled",
      "appointment.rescheduled",
      "appointment.cancelled",
      "appointment.completed",
    ]);
    expect(core.GROWTH_OUTBOX_SCHEMA_VERSION).toBe(1);
  });
});
