import { describe, expect, it, vi } from "vitest";
import type {
  ContactPreference,
  ContactPreferenceServiceRepository,
  SuppressionRecord,
  SuppressionServiceRepository,
} from "../src/index.js";
import {
  createContactPreferenceService,
  createSuppressionService,
  GrowthServiceError,
} from "../src/index.js";

const actor = { type: "member" as const, id: "member-1" };
const preference: ContactPreference = {
  id: "preference-1", siteId: "site-1", contactId: "contact-1", key: "service", value: "heating",
  version: 1, updatedAt: "2026-07-18T00:00:00.000Z",
};
const suppression: SuppressionRecord = {
  id: "suppression-1", siteId: "site-1", channel: "email", normalizedDestinationHash: "a".repeat(64),
  reasonCode: "manual", source: "member", retainedForPrevention: true, version: 1,
};

describe("contact preference service", () => {
  it("passes assigned scope and the original command to the authoritative repository", async () => {
    const repository: ContactPreferenceServiceRepository = {
      listAuthorized: vi.fn(async () => [preference]),
      setAuthorized: vi.fn(async () => preference),
      clearAuthorized: vi.fn(async () => ({ status: "applied" as const, value: preference })),
    };
    const service = createContactPreferenceService({
      repository,
      authorize: vi.fn(async () => ({ allowed: true as const, scope: "assigned" as const })),
    });
    const command = {
      siteId: "site-1", actor, idempotencyKey: "preference-1", contactId: "contact-1", key: "service", value: "heating",
    };

    await expect(service.set(command)).resolves.toEqual(preference);
    expect(repository.setAuthorized).toHaveBeenCalledWith({ command, scope: "assigned" });
  });

  it("rejects invalid preference keys before authorization or persistence", async () => {
    const authorize = vi.fn(async () => ({ allowed: true as const, scope: "site" as const }));
    const repository: ContactPreferenceServiceRepository = {
      listAuthorized: vi.fn(async () => []),
      setAuthorized: vi.fn(async () => preference),
      clearAuthorized: vi.fn(async () => ({ status: "applied" as const, value: preference })),
    };
    const service = createContactPreferenceService({ repository, authorize });

    await expect(service.set({
      siteId: "site-1", actor, idempotencyKey: "bad", contactId: "contact-1", key: "Bad Key", value: "x",
    })).rejects.toEqual(expect.objectContaining<Partial<GrowthServiceError>>({ code: "invalid_request" }));
    expect(authorize).not.toHaveBeenCalled();
    expect(repository.setAuthorized).not.toHaveBeenCalled();
  });
});

describe("suppression service", () => {
  it("requires site scope for suppression mutation and preserves expected versions", async () => {
    const repository: SuppressionServiceRepository = {
      addAuthorized: vi.fn(async () => suppression),
      evaluateAuthorized: vi.fn(async () => ({ suppressed: true, reasonCode: "manual", suppressionId: suppression.id })),
      reconcileAuthorized: vi.fn(async () => suppression),
      retainAuthorized: vi.fn(async () => ({ status: "applied" as const, value: { ...suppression, version: 2 } })),
    };
    const command = {
      siteId: "site-1", actor, idempotencyKey: "retain-1", expectedVersion: 1, suppressionId: "suppression-1", source: "member",
    };
    const assigned = createSuppressionService({ repository, authorize: vi.fn(async () => ({ allowed: true as const, scope: "assigned" as const })) });
    const site = createSuppressionService({ repository, authorize: vi.fn(async () => ({ allowed: true as const, scope: "site" as const })) });

    await expect(assigned.retainPreventionEvidence(command))
      .rejects.toEqual(expect.objectContaining<Partial<GrowthServiceError>>({ code: "not_authorized" }));
    await expect(site.retainPreventionEvidence(command)).resolves.toMatchObject({ status: "applied", value: { version: 2 } });
    expect(repository.retainAuthorized).toHaveBeenCalledWith({ command, scope: "site" });

    await expect(site.evaluate({
      siteId: "site-1",
      actor,
      channel: "email",
      normalizedDestinationHash: "a".repeat(64),
    })).resolves.toMatchObject({ suppressed: true });
    expect(repository.evaluateAuthorized).toHaveBeenCalledWith({
      siteId: "site-1",
      memberId: actor.id,
      channel: "email",
      normalizedDestinationHash: "a".repeat(64),
      scope: "site",
    });
  });
});
