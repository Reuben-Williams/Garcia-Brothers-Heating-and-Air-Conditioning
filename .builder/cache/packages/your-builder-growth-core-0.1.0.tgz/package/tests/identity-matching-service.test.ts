import { describe, expect, it, vi } from "vitest";
import type {
  Contact,
  ContactIdentity,
  ContactIdentityRepository,
  ContactRepository,
} from "../src/index.js";
import { createIdentityMatchingService, IdentityMatchingError } from "../src/index.js";

const contact = (id: string, siteId = "site-1"): Contact => ({
  id,
  siteId,
  displayName: id,
  createdAt: "2026-07-18T00:00:00.000Z",
  updatedAt: "2026-07-18T00:00:00.000Z",
  version: 1,
});

function identity(kind: "email" | "phone", normalizedValue: string, contactId: string): ContactIdentity {
  return {
    id: `${kind}-identity`,
    siteId: "site-1",
    contactId,
    kind,
    normalizedValue,
    verified: false,
    source: "form",
    createdAt: "2026-07-18T00:00:00.000Z",
  };
}

function repositories(matches: Record<string, ContactIdentity>, contacts: Record<string, Contact>) {
  const identities: ContactIdentityRepository = {
    findExact: vi.fn(async (_siteId, kind, value) => matches[`${kind}:${value}`] ?? null),
    listForContact: vi.fn(async () => []),
    append: vi.fn(async () => { throw new Error("not used"); }),
  };
  const contactRepository: ContactRepository = {
    create: vi.fn(async () => { throw new Error("not used"); }),
    match: vi.fn(async () => []),
    get: vi.fn(async (siteId, id) => contacts[id]?.siteId === siteId ? contacts[id] : null),
    update: vi.fn(async () => { throw new Error("not used"); }),
    proposeMerge: vi.fn(async () => { throw new Error("not used"); }),
    executeReviewedMerge: vi.fn(async () => { throw new Error("not used"); }),
    exportContactRecord: vi.fn(async () => ({})),
    pseudonymizeContactRecord: vi.fn(async () => { throw new Error("not used"); }),
  };
  return { identities, contacts: contactRepository };
}

describe("identity matching service", () => {
  it("normalizes email and phone before returning one deterministic exact contact", async () => {
    const existing = contact("contact-1");
    const repos = repositories({
      "email:person@example.com": identity("email", "person@example.com", existing.id),
      "phone:+12025550123": identity("phone", "+12025550123", existing.id),
    }, { [existing.id]: existing });
    const reviewEvidence = { find: vi.fn(async () => ["name" as const, "zip" as const]) };
    const service = createIdentityMatchingService({ ...repos, reviewEvidence });

    await expect(service.match({
      siteId: "site-1",
      email: " Person@Example.com ",
      phone: "(202) 555-0123",
      phoneRegion: "US",
      displayName: "Person Example",
      serviceAreaZip: "07105",
    })).resolves.toEqual({
      kind: "exact_contact",
      contactId: "contact-1",
      matchedIdentityKinds: ["email", "phone"],
    });
    expect(reviewEvidence.find).not.toHaveBeenCalled();
  });

  it("returns a conflict when exact email and phone identities belong to different contacts", async () => {
    const emailContact = contact("contact-email");
    const phoneContact = contact("contact-phone");
    const repos = repositories({
      "email:person@example.com": identity("email", "person@example.com", emailContact.id),
      "phone:+12025550123": identity("phone", "+12025550123", phoneContact.id),
    }, { [emailContact.id]: emailContact, [phoneContact.id]: phoneContact });
    const service = createIdentityMatchingService({ ...repos });

    await expect(service.match({
      siteId: "site-1",
      email: "person@example.com",
      phone: "+1 202 555 0123",
      phoneRegion: "US",
    })).resolves.toEqual({
      kind: "identity_conflict",
      matchedContactIds: ["contact-email", "contact-phone"],
    });
  });

  it("returns only bounded review evidence and never an automatic contact for fuzzy facts", async () => {
    const repos = repositories({}, {});
    const service = createIdentityMatchingService({
      ...repos,
      reviewEvidence: { find: vi.fn(async () => ["zip", "name", "zip", "address"] as const) },
    });

    await expect(service.match({
      siteId: "site-1",
      displayName: "Pat Garcia",
      serviceAreaZip: "07105",
    })).resolves.toEqual({ kind: "review_suggested", evidence: ["name", "zip", "address"] });
  });

  it("rejects invalid supplied identities and inconsistent repository rows with safe errors", async () => {
    const wrongSite = contact("contact-1", "site-2");
    const repos = repositories({
      "email:person@example.com": identity("email", "person@example.com", wrongSite.id),
    }, { [wrongSite.id]: wrongSite });
    const service = createIdentityMatchingService({ ...repos });

    await expect(service.match({ siteId: "site-1", email: "not-an-email" }))
      .rejects.toEqual(expect.objectContaining<Partial<IdentityMatchingError>>({ code: "invalid_email" }));
    await expect(service.match({ siteId: "site-1", email: "person@example.com" }))
      .rejects.toEqual(expect.objectContaining<Partial<IdentityMatchingError>>({ code: "repository_inconsistent" }));
  });
});
