import { describe, expect, it, vi } from "vitest";
import type { InAppNotification, InAppNotificationRepository } from "../src/index.js";
import { createInAppNotificationService } from "../src/index.js";

describe("in-app notification service", () => {
  it("uses a stable sanitized preview instead of caller-controlled customer text", async () => {
    const create = vi.fn(async (input): Promise<InAppNotification> => ({
      id: "notification-1",
      ...input,
      createdAt: "2026-07-18T00:00:00.000Z",
    }));
    const repository: InAppNotificationRepository = {
      create,
      listForRecipient: vi.fn(async () => []),
      markRead: vi.fn(async () => { throw new Error("not used"); }),
    };
    const service = createInAppNotificationService(repository);

    await service.notify({
      siteId: "site-1",
      recipientMemberId: "member-1",
      eventType: "lead.created",
      relatedType: "lead",
      relatedId: "lead-1",
      idempotencyKey: "notify-1",
    });

    expect(create).toHaveBeenCalledWith(expect.objectContaining({
      previewText: "A new lead is ready for review.",
    }));
  });

  it("falls back to a generic preview for unknown event types", async () => {
    const create = vi.fn(async (input): Promise<InAppNotification> => ({
      id: "notification-1",
      ...input,
      createdAt: "2026-07-18T00:00:00.000Z",
    }));
    const repository: InAppNotificationRepository = {
      create,
      listForRecipient: vi.fn(async () => []),
      markRead: vi.fn(async () => { throw new Error("not used"); }),
    };

    await createInAppNotificationService(repository).notify({
      siteId: "site-1",
      recipientMemberId: "member-1",
      eventType: "provider.raw.customer@example.com",
      relatedType: "site",
      relatedId: "site-1",
      idempotencyKey: "notify-2",
    });

    expect(create.mock.calls[0]?.[0].previewText).toBe("Activity requires your attention.");
    expect(create.mock.calls[0]?.[0].eventType).toBe("activity.updated");
  });
});
