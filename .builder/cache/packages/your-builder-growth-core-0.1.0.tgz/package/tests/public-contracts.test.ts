import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import ts from "typescript";
import { describe, expect, it } from "vitest";
import type {
  AddSuppressionCommand,
  AppendDomainEventCommand,
  AppliedOrConflict,
  AppliedResult,
  AssignTaskCommand,
  CancelJobCommand,
  CancelTaskCommand,
  ClaimedOutboxRecord,
  ClaimOutboxCommand,
  CommandContext,
  CompleteJobCommand,
  CompleteOutboxCommand,
  CompleteTaskCommand,
  ConsentChannel,
  ConsentEvaluation,
  ConsentEvidenceLocator,
  ConsentEvidenceReference,
  ConsentExplanation,
  ConsentService,
  ConsentStatus,
  Contact,
  ContactMatch,
  ContactMergeProposal,
  ContactRepository,
  ContactUpdatePatch,
  CreateContactCommand,
  CreateTaskCommand,
  DeadLetterJobCommand,
  DisconnectIntegrationCommand,
  DomainEventEnvelope,
  DomainEventStore,
  DurableJobStatus,
  EnqueueOutboxCommand,
  EvaluateConsentQuery,
  ExecuteContactMergeCommand,
  ExplainConsentQuery,
  ExportContactRecordQuery,
  FailJobCommand,
  FailOutboxCommand,
  IntegrationHealth,
  IntegrationHealthStatus,
  IntegrationRegistry,
  IntegrationServiceEventOrigin,
  IntegrationTransition,
  JobLeaseFence,
  JobLeaseResourceIdentity,
  JobRepository,
  JobScheduleSource,
  JobTransition,
  JsonPrimitive,
  JsonValue,
  LeaseAppliedResult,
  LeaseConflict,
  LeaseConflictReason,
  LeaseExpiredConflict,
  LeaseReplayResult,
  LeaseResourceIdentity,
  LeaseResult,
  LeaseStaleTokenConflict,
  LeaseVersionConflict,
  LeaseWorkerMismatchConflict,
  LeaseJobCommand,
  LeasedJobRecord,
  ManualServiceEventOrigin,
  ManualServiceEventActor,
  MemberOperationActor,
  OperationActor,
  OperationActorType,
  OutboxLeaseResourceIdentity,
  OutboxLeaseFence,
  OutboxRepository,
  OutboxTransition,
  PauseJobCommand,
  ReconcileProviderSuppressionCommand,
  PseudonymizeContactRecordCommand,
  ProviderOperationActor,
  ReadonlyJsonObject,
  RecordConsentEvidenceCommand,
  RecordServiceEventCommand,
  RegisterIntegrationCommand,
  RenewJobLeaseCommand,
  ResolvedIntegration,
  ResumeJobCommand,
  RetainSuppressionEvidenceCommand,
  RevokeConsentCommand,
  ScheduleJobCommand,
  SecretReference,
  SecretReferenceStore,
  ServiceEvent,
  ServiceEventKind,
  ServiceEventOrigin,
  ServiceEventRepository,
  SiteScopedRecord,
  SystemOperationActor,
  SuppressionChannel,
  SuppressionEvaluation,
  SuppressionRecord,
  SuppressionRepository,
  TaskRepository,
  TaskStatus,
  TaskSummary,
  UpdateContactCommand,
  VersionConflict,
  VersionedCommandContext,
  VisitorOperationActor,
} from "@your-builder/growth-core";

type Equal<Left, Right> =
  (<Value>() => Value extends Left ? 1 : 2) extends
  (<Value>() => Value extends Right ? 1 : 2)
    ? (<Value>() => Value extends Right ? 1 : 2) extends
        (<Value>() => Value extends Left ? 1 : 2)
      ? true
      : false
    : false;

type Assert<Condition extends true> = Condition;

type ExpectedJsonPrimitive = string | number | boolean | null;
type ExpectedJsonValue =
  | ExpectedJsonPrimitive
  | ExpectedReadonlyJsonObject
  | readonly ExpectedJsonValue[];
interface ExpectedReadonlyJsonObject {
  readonly [key: string]: ExpectedJsonValue;
}

type ExpectedOperationActorType = "member" | "visitor" | "system" | "provider";
interface ExpectedMemberOperationActor {
  readonly type: "member";
  readonly id: string;
}
interface ExpectedProviderOperationActor {
  readonly type: "provider";
  readonly id: string;
}
interface ExpectedVisitorOperationActor {
  readonly type: "visitor";
  readonly id?: string;
}
interface ExpectedSystemOperationActor {
  readonly type: "system";
  readonly id?: string;
}
type ExpectedOperationActor =
  | ExpectedMemberOperationActor
  | ExpectedProviderOperationActor
  | ExpectedVisitorOperationActor
  | ExpectedSystemOperationActor;
interface ExpectedCommandContext {
  readonly siteId: string;
  readonly actor: ExpectedOperationActor;
  readonly idempotencyKey: string;
}
interface ExpectedVersionedCommandContext extends ExpectedCommandContext {
  readonly expectedVersion: number;
}
interface ExpectedVersionConflict {
  readonly status: "conflict";
  readonly reason: "version_conflict";
  readonly resourceType: string;
  readonly resourceId: string;
  readonly expectedVersion: number;
  readonly actualVersion: number;
}
interface ExpectedAppliedResult<Value> {
  readonly status: "applied";
  readonly value: Value;
}
type ExpectedAppliedOrConflict<Value> = ExpectedAppliedResult<Value> | ExpectedVersionConflict;

type ExpectedLeaseConflictReason = "expired" | "stale_token" | "worker_mismatch" | "version_conflict";
interface ExpectedJobLeaseResourceIdentity {
  readonly resourceType: "job";
  readonly siteId: string;
  readonly jobId: string;
}
interface ExpectedOutboxLeaseResourceIdentity {
  readonly resourceType: "outbox";
  readonly siteId: string;
  readonly outboxId: string;
}
type ExpectedLeaseResourceIdentity =
  | ExpectedJobLeaseResourceIdentity
  | ExpectedOutboxLeaseResourceIdentity;
interface ExpectedLeaseAppliedResult<
  Value,
  Resource extends ExpectedLeaseResourceIdentity = ExpectedLeaseResourceIdentity,
> {
  readonly status: "applied";
  readonly resource: Resource;
  readonly value: Value;
}
interface ExpectedLeaseReplayResult<
  Value,
  Resource extends ExpectedLeaseResourceIdentity = ExpectedLeaseResourceIdentity,
> {
  readonly status: "replayed";
  readonly replayReason: "same_fence";
  readonly resource: Resource;
  readonly workerId: string;
  readonly leaseToken: string;
  readonly attempt: number;
  readonly value: Value;
}
interface ExpectedLeaseExpiredConflict<
  Resource extends ExpectedLeaseResourceIdentity = ExpectedLeaseResourceIdentity,
> {
  readonly status: "conflict";
  readonly reason: "expired";
  readonly resource: Resource;
  readonly leaseExpiresAt: string;
  readonly observedAt: string;
}
interface ExpectedLeaseStaleTokenConflict<
  Resource extends ExpectedLeaseResourceIdentity = ExpectedLeaseResourceIdentity,
> {
  readonly status: "conflict";
  readonly reason: "stale_token";
  readonly resource: Resource;
  readonly providedLeaseToken: string;
}
interface ExpectedLeaseWorkerMismatchConflict<
  Resource extends ExpectedLeaseResourceIdentity = ExpectedLeaseResourceIdentity,
> {
  readonly status: "conflict";
  readonly reason: "worker_mismatch";
  readonly resource: Resource;
  readonly providedWorkerId: string;
  readonly leasedWorkerId: string;
}
interface ExpectedLeaseVersionConflict<
  Resource extends ExpectedLeaseResourceIdentity = ExpectedLeaseResourceIdentity,
> {
  readonly status: "conflict";
  readonly reason: "version_conflict";
  readonly resource: Resource;
  readonly expectedVersion: number;
  readonly actualVersion: number;
}
type ExpectedLeaseConflict<Resource extends ExpectedLeaseResourceIdentity = ExpectedLeaseResourceIdentity> =
  | ExpectedLeaseExpiredConflict<Resource>
  | ExpectedLeaseStaleTokenConflict<Resource>
  | ExpectedLeaseWorkerMismatchConflict<Resource>
  | ExpectedLeaseVersionConflict<Resource>;
type ExpectedLeaseResult<
  Value,
  Resource extends ExpectedLeaseResourceIdentity = ExpectedLeaseResourceIdentity,
> = ExpectedLeaseAppliedResult<Value, Resource> | ExpectedLeaseReplayResult<Value, Resource> | ExpectedLeaseConflict<Resource>;

interface ExpectedSiteScopedRecord {
  readonly id: string;
  readonly siteId: string;
  readonly createdAt: string;
  readonly updatedAt: string;
  readonly version: number;
}
interface ExpectedContact extends ExpectedSiteScopedRecord {
  readonly displayName: string;
  readonly email?: string;
  readonly phone?: string;
  readonly lifecycleState?: "active" | "inactive" | "merged" | "deleted";
  readonly preferredContactMethod?: "email" | "phone" | "none";
  readonly serviceAreaZip?: string;
}
interface ExpectedContactMatch {
  readonly contactId: string;
  readonly confidence: "exact" | "review";
  readonly reasons: readonly string[];
}
interface ExpectedContactMergeProposal {
  readonly sourceId: string;
  readonly targetId: string;
  readonly conflicts: readonly string[];
}
interface ExpectedCreateContactCommand extends ExpectedCommandContext {
  readonly displayName: string;
  readonly email?: string;
  readonly phone?: string;
}
interface ExpectedContactUpdatePatch {
  readonly displayName?: string;
  readonly email?: string | null;
  readonly phone?: string | null;
}
interface ExpectedUpdateContactCommand extends ExpectedVersionedCommandContext {
  readonly contactId: string;
  readonly patch: ExpectedContactUpdatePatch;
}
interface ExpectedExecuteContactMergeCommand extends ExpectedCommandContext {
  readonly sourceId: string;
  readonly targetId: string;
  readonly expectedSourceVersion: number;
  readonly expectedTargetVersion: number;
}
interface ExpectedExportContactRecordQuery {
  readonly siteId: string;
  readonly contactId: string;
  readonly actor: ExpectedOperationActor;
  readonly purpose: string;
}
interface ExpectedPseudonymizeContactRecordCommand extends ExpectedVersionedCommandContext {
  readonly contactId: string;
}
interface ExpectedContactRepository {
  create(input: ExpectedCreateContactCommand): Promise<ExpectedContact>;
  match(
    siteId: string,
    identity: { readonly email?: string; readonly phone?: string },
  ): Promise<readonly ExpectedContactMatch[]>;
  get(siteId: string, contactId: string): Promise<ExpectedContact | null>;
  update(input: ExpectedUpdateContactCommand): Promise<ExpectedAppliedOrConflict<ExpectedContact>>;
  proposeMerge(siteId: string, sourceId: string, targetId: string): Promise<ExpectedContactMergeProposal>;
  executeReviewedMerge(
    input: ExpectedExecuteContactMergeCommand,
  ): Promise<ExpectedAppliedOrConflict<ExpectedContact>>;
  exportContactRecord(input: ExpectedExportContactRecordQuery): Promise<ExpectedReadonlyJsonObject>;
  pseudonymizeContactRecord(
    input: ExpectedPseudonymizeContactRecordCommand,
  ): Promise<ExpectedAppliedOrConflict<ExpectedContact>>;
}

type ExpectedConsentChannel = "email" | "sms";
type ExpectedConsentStatus = "granted" | "denied";
interface ExpectedConsentEvidenceReference {
  readonly system: string;
  readonly referenceId: string;
}
type ExpectedConsentEvidenceLocator =
  | {
      readonly evidenceReference: ExpectedConsentEvidenceReference;
      readonly evidenceDigest?: string;
    }
  | {
      readonly evidenceReference?: never;
      readonly evidenceDigest: string;
    };
type ExpectedRecordConsentEvidenceCommand = ExpectedCommandContext &
  ExpectedConsentEvidenceLocator & {
    readonly contactId: string;
    readonly channel: ExpectedConsentChannel;
    readonly purpose: string;
    readonly status: ExpectedConsentStatus;
    readonly source: string;
    readonly occurredAt: string;
    readonly policyVersion: string;
  };
interface ExpectedEvaluateConsentQuery {
  readonly siteId: string;
  readonly contactId: string;
  readonly channel: ExpectedConsentChannel;
  readonly purpose: string;
  readonly at: string;
}
interface ExpectedRevokeConsentCommand extends ExpectedCommandContext {
  readonly contactId: string;
  readonly channel: ExpectedConsentChannel;
  readonly purpose: string;
  readonly occurredAt: string;
  readonly source: string;
}
interface ExpectedExplainConsentQuery extends ExpectedEvaluateConsentQuery {}
interface ExpectedConsentEvaluation {
  readonly allowed: boolean;
  readonly reasonCode: string;
  readonly evidenceId?: string;
}
interface ExpectedConsentExplanation {
  readonly code: string;
  readonly message: string;
  readonly evidenceId?: string;
}
interface ExpectedConsentService {
  recordEvidence(input: ExpectedRecordConsentEvidenceCommand): Promise<string>;
  evaluate(input: ExpectedEvaluateConsentQuery): Promise<ExpectedConsentEvaluation>;
  revoke(input: ExpectedRevokeConsentCommand): Promise<void>;
  explain(input: ExpectedExplainConsentQuery): Promise<readonly ExpectedConsentExplanation[]>;
}

type ExpectedSuppressionChannel = "email" | "sms";
interface ExpectedSuppressionRecord {
  readonly id: string;
  readonly siteId: string;
  readonly channel: ExpectedSuppressionChannel;
  readonly normalizedDestinationHash: string;
  readonly reasonCode: string;
  readonly source: string;
  readonly retainedForPrevention: boolean;
  readonly version: number;
}
interface ExpectedAddSuppressionCommand extends ExpectedCommandContext {
  readonly channel: ExpectedSuppressionChannel;
  readonly normalizedDestinationHash: string;
  readonly reasonCode: string;
  readonly source: string;
}
interface ExpectedSuppressionEvaluation {
  readonly suppressed: boolean;
  readonly reasonCode?: string;
  readonly suppressionId?: string;
}
interface ExpectedReconcileProviderSuppressionCommand {
  readonly siteId: string;
  readonly actor: ExpectedOperationActor;
  readonly provider: string;
  readonly providerEventId: string;
  readonly idempotencyIdentity: "providerEventId";
  readonly channel: ExpectedSuppressionChannel;
  readonly normalizedDestinationHash: string;
  readonly reasonCode: string;
  readonly source: string;
}
interface ExpectedRetainSuppressionEvidenceCommand extends ExpectedVersionedCommandContext {
  readonly suppressionId: string;
  readonly source: string;
}
interface ExpectedSuppressionRepository {
  add(input: ExpectedAddSuppressionCommand): Promise<ExpectedSuppressionRecord>;
  evaluate(
    siteId: string,
    channel: ExpectedSuppressionChannel,
    normalizedDestinationHash: string,
  ): Promise<ExpectedSuppressionEvaluation>;
  reconcileProviderFact(input: ExpectedReconcileProviderSuppressionCommand): Promise<ExpectedSuppressionRecord>;
  retainPreventionEvidence(
    input: ExpectedRetainSuppressionEvidenceCommand,
  ): Promise<ExpectedAppliedOrConflict<ExpectedSuppressionRecord>>;
}

type ExpectedTaskStatus = "open" | "assigned" | "completed" | "cancelled";
type ExpectedTaskPriority = "low" | "normal" | "high" | "urgent";
interface ExpectedAuthorizationParent { readonly type: "lead" | "customer" | "task"; readonly id: string; }
interface ExpectedTaskSummary {
  readonly id: string;
  readonly siteId: string;
  readonly relatedType: string;
  readonly relatedId: string;
  readonly title: string;
  readonly status: ExpectedTaskStatus;
  readonly priority?: ExpectedTaskPriority;
  readonly dueAt?: string;
  readonly authorizationParents?: readonly ExpectedAuthorizationParent[];
  readonly assigneeId?: string;
  readonly version: number;
}
interface ExpectedCreateTaskCommand extends ExpectedCommandContext {
  readonly relatedType: string;
  readonly relatedId: string;
  readonly title: string;
  readonly assigneeId?: string;
  readonly priority?: ExpectedTaskPriority;
  readonly dueAt?: string;
  readonly authorizationParents: readonly ExpectedAuthorizationParent[];
  readonly selfAssignmentIntent: boolean;
}
interface ExpectedAssignTaskCommand extends ExpectedVersionedCommandContext {
  readonly taskId: string;
  readonly assigneeId: string;
}
interface ExpectedCompleteTaskCommand extends ExpectedVersionedCommandContext {
  readonly taskId: string;
  readonly completedAt: string;
}
interface ExpectedCancelTaskCommand extends ExpectedVersionedCommandContext {
  readonly taskId: string;
  readonly reason: string;
}
interface ExpectedTaskRepository {
  create(input: ExpectedCreateTaskCommand): Promise<ExpectedTaskSummary>;
  assign(input: ExpectedAssignTaskCommand): Promise<ExpectedAppliedOrConflict<ExpectedTaskSummary>>;
  complete(input: ExpectedCompleteTaskCommand): Promise<ExpectedAppliedOrConflict<ExpectedTaskSummary>>;
  cancel(input: ExpectedCancelTaskCommand): Promise<ExpectedAppliedOrConflict<ExpectedTaskSummary>>;
  listByRelatedRecord(
    siteId: string,
    relatedType: string,
    relatedId: string,
  ): Promise<readonly ExpectedTaskSummary[]>;
}

type ExpectedServiceEventKind =
  | "estimate.sent"
  | "estimate.accepted"
  | "estimate.declined"
  | "appointment.scheduled"
  | "appointment.rescheduled"
  | "appointment.cancelled"
  | "appointment.completed";
type ExpectedManualServiceEventActor = ExpectedMemberOperationActor | ExpectedSystemOperationActor;
interface ExpectedManualServiceEventOrigin {
  readonly type: "manual";
  readonly actor: ExpectedManualServiceEventActor;
}
interface ExpectedIntegrationServiceEventOrigin {
  readonly type: "integration";
  readonly integrationId: string;
  readonly providerEventId: string;
}
type ExpectedServiceEventOrigin =
  | ExpectedManualServiceEventOrigin
  | ExpectedIntegrationServiceEventOrigin;
interface ExpectedServiceEvent {
  readonly id: string;
  readonly siteId: string;
  readonly contactId: string;
  readonly leadId?: string;
  readonly kind: ExpectedServiceEventKind;
  readonly purpose?: "estimate" | "service";
  readonly scheduledAt?: string;
  readonly origin: ExpectedServiceEventOrigin;
  readonly occurredAt: string;
  readonly correlationId: string;
  readonly replacesEventId?: string;
}
interface ExpectedRecordServiceEventCommand {
  readonly siteId: string;
  readonly contactId: string;
  readonly leadId?: string;
  readonly kind: ExpectedServiceEventKind;
  readonly purpose?: "estimate" | "service";
  readonly scheduledAt?: string;
  readonly origin: ExpectedServiceEventOrigin;
  readonly occurredAt: string;
  readonly correlationId: string;
  readonly replacesEventId?: string;
  readonly idempotencyKey: string;
}
interface ExpectedServiceEventRepository {
  record(input: ExpectedRecordServiceEventCommand): Promise<ExpectedServiceEvent>;
  list(siteId: string, contactId: string): Promise<readonly ExpectedServiceEvent[]>;
}

interface ExpectedDomainEventEnvelope<Payload extends ExpectedReadonlyJsonObject = ExpectedReadonlyJsonObject> {
  readonly id: string;
  readonly schemaVersion: number;
  readonly siteId: string;
  readonly type: string;
  readonly occurredAt: string;
  readonly actor: ExpectedOperationActor;
  readonly correlationId: string;
  readonly causationId?: string;
  readonly aggregateType: string;
  readonly aggregateId: string;
  readonly aggregateVersion: number;
  readonly payload: Payload;
}
interface ExpectedAppendDomainEventCommand<Payload extends ExpectedReadonlyJsonObject = ExpectedReadonlyJsonObject> {
  readonly event: ExpectedDomainEventEnvelope<Payload>;
  readonly expectedAggregateVersion: number;
  readonly idempotencyIdentity: "event.id";
}
interface ExpectedDomainEventStore {
  append<Payload extends ExpectedReadonlyJsonObject>(
    input: ExpectedAppendDomainEventCommand<Payload>,
  ): Promise<ExpectedAppliedOrConflict<ExpectedDomainEventEnvelope<Payload>>>;
  read(siteId: string, eventId: string): Promise<ExpectedDomainEventEnvelope | null>;
}

interface ExpectedEnqueueOutboxCommand extends ExpectedCommandContext {
  readonly eventId: string;
  readonly destination: string;
  readonly payload: ExpectedReadonlyJsonObject;
}
interface ExpectedClaimOutboxCommand {
  readonly siteId: string;
  readonly workerId: string;
  readonly now: string;
  readonly leaseSeconds: number;
}
interface ExpectedClaimedOutboxRecord {
  readonly siteId: string;
  readonly outboxId: string;
  readonly eventId: string;
  readonly destination: string;
  readonly payload: ExpectedReadonlyJsonObject;
  readonly idempotencyKey: string;
  readonly workerId: string;
  readonly leaseToken: string;
  readonly leaseExpiresAt: string;
  readonly attempt: number;
}
interface ExpectedOutboxLeaseFence {
  readonly siteId: string;
  readonly outboxId: string;
  readonly workerId: string;
  readonly leaseToken: string;
  readonly leaseExpiresAt: string;
  readonly attempt: number;
}
interface ExpectedCompleteOutboxCommand {
  readonly lease: ExpectedOutboxLeaseFence;
  readonly resultCode: string;
}
interface ExpectedFailOutboxCommand {
  readonly lease: ExpectedOutboxLeaseFence;
  readonly errorCode: string;
  readonly retryAt?: string;
}
interface ExpectedOutboxTransition {
  readonly siteId: string;
  readonly outboxId: string;
  readonly status: "completed" | "failed";
  readonly attempt: number;
  readonly retryAt?: string;
}
interface ExpectedOutboxRepository {
  enqueue(input: ExpectedEnqueueOutboxCommand): Promise<string>;
  claim(input: ExpectedClaimOutboxCommand): Promise<ExpectedClaimedOutboxRecord | null>;
  complete(
    input: ExpectedCompleteOutboxCommand,
  ): Promise<ExpectedLeaseResult<ExpectedOutboxTransition, ExpectedOutboxLeaseResourceIdentity>>;
  fail(
    input: ExpectedFailOutboxCommand,
  ): Promise<ExpectedLeaseResult<ExpectedOutboxTransition, ExpectedOutboxLeaseResourceIdentity>>;
}

type ExpectedDurableJobStatus =
  | "scheduled"
  | "leased"
  | "paused"
  | "completed"
  | "failed"
  | "dead_letter"
  | "cancelled";
type ExpectedJobScheduleSource = "manual" | "automation" | "integration" | "system";
interface ExpectedScheduleJobCommand extends ExpectedCommandContext {
  readonly kind: string;
  readonly runAt: string;
  readonly payload: ExpectedReadonlyJsonObject;
  readonly source: ExpectedJobScheduleSource;
}
interface ExpectedLeaseJobCommand {
  readonly siteId: string;
  readonly workerId: string;
  readonly now: string;
  readonly leaseSeconds: number;
}
interface ExpectedJobLeaseFence {
  readonly siteId: string;
  readonly jobId: string;
  readonly workerId: string;
  readonly leaseToken: string;
  readonly leaseExpiresAt: string;
  readonly attempt: number;
  readonly version: number;
}
interface ExpectedLeasedJobRecord extends ExpectedJobLeaseFence {
  readonly kind: string;
  readonly payload: ExpectedReadonlyJsonObject;
  readonly runAt: string;
}
interface ExpectedRenewJobLeaseCommand {
  readonly lease: ExpectedJobLeaseFence;
  readonly now: string;
  readonly leaseSeconds: number;
}
interface ExpectedPauseJobCommand extends ExpectedVersionedCommandContext {
  readonly jobId: string;
  readonly reason: string;
}
interface ExpectedResumeJobCommand extends ExpectedVersionedCommandContext {
  readonly jobId: string;
  readonly now: string;
}
interface ExpectedCancelJobCommand extends ExpectedVersionedCommandContext {
  readonly jobId: string;
  readonly reason: string;
}
interface ExpectedJobTransition {
  readonly siteId: string;
  readonly jobId: string;
  readonly status: ExpectedDurableJobStatus;
  readonly version: number;
}
interface ExpectedCompleteJobCommand {
  readonly lease: ExpectedJobLeaseFence;
  readonly result: ExpectedReadonlyJsonObject;
}
interface ExpectedFailJobCommand {
  readonly lease: ExpectedJobLeaseFence;
  readonly errorCode: string;
  readonly retryAt?: string;
}
interface ExpectedDeadLetterJobCommand {
  readonly lease: ExpectedJobLeaseFence;
  readonly errorCode: string;
}
interface ExpectedJobRepository {
  schedule(input: ExpectedScheduleJobCommand): Promise<string>;
  lease(input: ExpectedLeaseJobCommand): Promise<ExpectedLeasedJobRecord | null>;
  renew(
    input: ExpectedRenewJobLeaseCommand,
  ): Promise<ExpectedLeaseResult<ExpectedLeasedJobRecord, ExpectedJobLeaseResourceIdentity>>;
  pause(input: ExpectedPauseJobCommand): Promise<ExpectedAppliedOrConflict<ExpectedJobTransition>>;
  resume(input: ExpectedResumeJobCommand): Promise<ExpectedAppliedOrConflict<ExpectedJobTransition>>;
  cancel(input: ExpectedCancelJobCommand): Promise<ExpectedAppliedOrConflict<ExpectedJobTransition>>;
  complete(
    input: ExpectedCompleteJobCommand,
  ): Promise<ExpectedLeaseResult<ExpectedJobTransition, ExpectedJobLeaseResourceIdentity>>;
  fail(
    input: ExpectedFailJobCommand,
  ): Promise<ExpectedLeaseResult<ExpectedJobTransition, ExpectedJobLeaseResourceIdentity>>;
  deadLetter(
    input: ExpectedDeadLetterJobCommand,
  ): Promise<ExpectedLeaseResult<ExpectedJobTransition, ExpectedJobLeaseResourceIdentity>>;
}

type ExpectedSecretReferenceStore = "vault" | "provider";
interface ExpectedSecretReference {
  readonly store: ExpectedSecretReferenceStore;
  readonly referenceId: string;
}
interface ExpectedRegisterIntegrationCommand extends ExpectedCommandContext {
  readonly provider: string;
  readonly capabilities: readonly string[];
  readonly secretReference: ExpectedSecretReference;
}
interface ExpectedResolvedIntegration {
  readonly integrationId: string;
  readonly provider: string;
  readonly secretReference: ExpectedSecretReference;
  readonly version: number;
}
type ExpectedIntegrationHealthStatus = "connected" | "degraded" | "disconnected";
interface ExpectedIntegrationHealth {
  readonly status: ExpectedIntegrationHealthStatus;
  readonly reasonCode?: string;
}
interface ExpectedDisconnectIntegrationCommand extends ExpectedVersionedCommandContext {
  readonly integrationId: string;
  readonly reason: string;
}
interface ExpectedIntegrationTransition {
  readonly siteId: string;
  readonly integrationId: string;
  readonly status: "disconnected";
  readonly version: number;
}
interface ExpectedIntegrationRegistry {
  register(input: ExpectedRegisterIntegrationCommand): Promise<string>;
  resolve(siteId: string, capability: string): Promise<ExpectedResolvedIntegration | null>;
  checkHealth(siteId: string, integrationId: string): Promise<ExpectedIntegrationHealth>;
  disconnect(
    input: ExpectedDisconnectIntegrationCommand,
  ): Promise<ExpectedAppliedOrConflict<ExpectedIntegrationTransition>>;
}

type ActualContracts = {
  JsonPrimitive: JsonPrimitive;
  JsonValue: JsonValue;
  ReadonlyJsonObject: ReadonlyJsonObject;
  OperationActorType: OperationActorType;
  MemberOperationActor: MemberOperationActor;
  ProviderOperationActor: ProviderOperationActor;
  VisitorOperationActor: VisitorOperationActor;
  SystemOperationActor: SystemOperationActor;
  OperationActor: OperationActor;
  CommandContext: CommandContext;
  VersionedCommandContext: VersionedCommandContext;
  VersionConflict: VersionConflict;
  AppliedResult: AppliedResult<string>;
  AppliedOrConflict: AppliedOrConflict<string>;
  LeaseConflictReason: LeaseConflictReason;
  JobLeaseResourceIdentity: JobLeaseResourceIdentity;
  OutboxLeaseResourceIdentity: OutboxLeaseResourceIdentity;
  LeaseResourceIdentity: LeaseResourceIdentity;
  LeaseAppliedResult: LeaseAppliedResult<string>;
  LeaseReplayResult: LeaseReplayResult<string>;
  LeaseExpiredConflict: LeaseExpiredConflict;
  LeaseStaleTokenConflict: LeaseStaleTokenConflict;
  LeaseWorkerMismatchConflict: LeaseWorkerMismatchConflict;
  LeaseVersionConflict: LeaseVersionConflict;
  LeaseConflict: LeaseConflict;
  LeaseResult: LeaseResult<string>;
  SiteScopedRecord: SiteScopedRecord;
  Contact: Contact;
  ContactMatch: ContactMatch;
  ContactMergeProposal: ContactMergeProposal;
  CreateContactCommand: CreateContactCommand;
  ContactUpdatePatch: ContactUpdatePatch;
  UpdateContactCommand: UpdateContactCommand;
  ExecuteContactMergeCommand: ExecuteContactMergeCommand;
  ExportContactRecordQuery: ExportContactRecordQuery;
  PseudonymizeContactRecordCommand: PseudonymizeContactRecordCommand;
  ContactRepository: ContactRepository;
  ConsentChannel: ConsentChannel;
  ConsentStatus: ConsentStatus;
  ConsentEvidenceReference: ConsentEvidenceReference;
  ConsentEvidenceLocator: ConsentEvidenceLocator;
  RecordConsentEvidenceCommand: RecordConsentEvidenceCommand;
  EvaluateConsentQuery: EvaluateConsentQuery;
  RevokeConsentCommand: RevokeConsentCommand;
  ExplainConsentQuery: ExplainConsentQuery;
  ConsentEvaluation: ConsentEvaluation;
  ConsentExplanation: ConsentExplanation;
  ConsentService: ConsentService;
  SuppressionChannel: SuppressionChannel;
  SuppressionRecord: SuppressionRecord;
  AddSuppressionCommand: AddSuppressionCommand;
  SuppressionEvaluation: SuppressionEvaluation;
  ReconcileProviderSuppressionCommand: ReconcileProviderSuppressionCommand;
  RetainSuppressionEvidenceCommand: RetainSuppressionEvidenceCommand;
  SuppressionRepository: SuppressionRepository;
  TaskStatus: TaskStatus;
  TaskSummary: TaskSummary;
  CreateTaskCommand: CreateTaskCommand;
  AssignTaskCommand: AssignTaskCommand;
  CompleteTaskCommand: CompleteTaskCommand;
  CancelTaskCommand: CancelTaskCommand;
  TaskRepository: TaskRepository;
  ServiceEventKind: ServiceEventKind;
  ManualServiceEventActor: ManualServiceEventActor;
  ManualServiceEventOrigin: ManualServiceEventOrigin;
  IntegrationServiceEventOrigin: IntegrationServiceEventOrigin;
  ServiceEventOrigin: ServiceEventOrigin;
  ServiceEvent: ServiceEvent;
  RecordServiceEventCommand: RecordServiceEventCommand;
  ServiceEventRepository: ServiceEventRepository;
  DomainEventEnvelope: DomainEventEnvelope;
  AppendDomainEventCommand: AppendDomainEventCommand;
  DomainEventStore: DomainEventStore;
  EnqueueOutboxCommand: EnqueueOutboxCommand;
  ClaimOutboxCommand: ClaimOutboxCommand;
  ClaimedOutboxRecord: ClaimedOutboxRecord;
  OutboxLeaseFence: OutboxLeaseFence;
  CompleteOutboxCommand: CompleteOutboxCommand;
  FailOutboxCommand: FailOutboxCommand;
  OutboxTransition: OutboxTransition;
  OutboxRepository: OutboxRepository;
  DurableJobStatus: DurableJobStatus;
  JobScheduleSource: JobScheduleSource;
  ScheduleJobCommand: ScheduleJobCommand;
  LeaseJobCommand: LeaseJobCommand;
  JobLeaseFence: JobLeaseFence;
  LeasedJobRecord: LeasedJobRecord;
  RenewJobLeaseCommand: RenewJobLeaseCommand;
  PauseJobCommand: PauseJobCommand;
  ResumeJobCommand: ResumeJobCommand;
  CancelJobCommand: CancelJobCommand;
  JobTransition: JobTransition;
  CompleteJobCommand: CompleteJobCommand;
  FailJobCommand: FailJobCommand;
  DeadLetterJobCommand: DeadLetterJobCommand;
  JobRepository: JobRepository;
  SecretReferenceStore: SecretReferenceStore;
  SecretReference: SecretReference;
  RegisterIntegrationCommand: RegisterIntegrationCommand;
  ResolvedIntegration: ResolvedIntegration;
  IntegrationHealthStatus: IntegrationHealthStatus;
  IntegrationHealth: IntegrationHealth;
  DisconnectIntegrationCommand: DisconnectIntegrationCommand;
  IntegrationTransition: IntegrationTransition;
  IntegrationRegistry: IntegrationRegistry;
};

type ExpectedContracts = {
  JsonPrimitive: ExpectedJsonPrimitive;
  JsonValue: ExpectedJsonValue;
  ReadonlyJsonObject: ExpectedReadonlyJsonObject;
  OperationActorType: ExpectedOperationActorType;
  MemberOperationActor: ExpectedMemberOperationActor;
  ProviderOperationActor: ExpectedProviderOperationActor;
  VisitorOperationActor: ExpectedVisitorOperationActor;
  SystemOperationActor: ExpectedSystemOperationActor;
  OperationActor: ExpectedOperationActor;
  CommandContext: ExpectedCommandContext;
  VersionedCommandContext: ExpectedVersionedCommandContext;
  VersionConflict: ExpectedVersionConflict;
  AppliedResult: ExpectedAppliedResult<string>;
  AppliedOrConflict: ExpectedAppliedOrConflict<string>;
  LeaseConflictReason: ExpectedLeaseConflictReason;
  JobLeaseResourceIdentity: ExpectedJobLeaseResourceIdentity;
  OutboxLeaseResourceIdentity: ExpectedOutboxLeaseResourceIdentity;
  LeaseResourceIdentity: ExpectedLeaseResourceIdentity;
  LeaseAppliedResult: ExpectedLeaseAppliedResult<string>;
  LeaseReplayResult: ExpectedLeaseReplayResult<string>;
  LeaseExpiredConflict: ExpectedLeaseExpiredConflict;
  LeaseStaleTokenConflict: ExpectedLeaseStaleTokenConflict;
  LeaseWorkerMismatchConflict: ExpectedLeaseWorkerMismatchConflict;
  LeaseVersionConflict: ExpectedLeaseVersionConflict;
  LeaseConflict: ExpectedLeaseConflict;
  LeaseResult: ExpectedLeaseResult<string>;
  SiteScopedRecord: ExpectedSiteScopedRecord;
  Contact: ExpectedContact;
  ContactMatch: ExpectedContactMatch;
  ContactMergeProposal: ExpectedContactMergeProposal;
  CreateContactCommand: ExpectedCreateContactCommand;
  ContactUpdatePatch: ExpectedContactUpdatePatch;
  UpdateContactCommand: ExpectedUpdateContactCommand;
  ExecuteContactMergeCommand: ExpectedExecuteContactMergeCommand;
  ExportContactRecordQuery: ExpectedExportContactRecordQuery;
  PseudonymizeContactRecordCommand: ExpectedPseudonymizeContactRecordCommand;
  ContactRepository: ExpectedContactRepository;
  ConsentChannel: ExpectedConsentChannel;
  ConsentStatus: ExpectedConsentStatus;
  ConsentEvidenceReference: ExpectedConsentEvidenceReference;
  ConsentEvidenceLocator: ExpectedConsentEvidenceLocator;
  RecordConsentEvidenceCommand: ExpectedRecordConsentEvidenceCommand;
  EvaluateConsentQuery: ExpectedEvaluateConsentQuery;
  RevokeConsentCommand: ExpectedRevokeConsentCommand;
  ExplainConsentQuery: ExpectedExplainConsentQuery;
  ConsentEvaluation: ExpectedConsentEvaluation;
  ConsentExplanation: ExpectedConsentExplanation;
  ConsentService: ExpectedConsentService;
  SuppressionChannel: ExpectedSuppressionChannel;
  SuppressionRecord: ExpectedSuppressionRecord;
  AddSuppressionCommand: ExpectedAddSuppressionCommand;
  SuppressionEvaluation: ExpectedSuppressionEvaluation;
  ReconcileProviderSuppressionCommand: ExpectedReconcileProviderSuppressionCommand;
  RetainSuppressionEvidenceCommand: ExpectedRetainSuppressionEvidenceCommand;
  SuppressionRepository: ExpectedSuppressionRepository;
  TaskStatus: ExpectedTaskStatus;
  TaskSummary: ExpectedTaskSummary;
  CreateTaskCommand: ExpectedCreateTaskCommand;
  AssignTaskCommand: ExpectedAssignTaskCommand;
  CompleteTaskCommand: ExpectedCompleteTaskCommand;
  CancelTaskCommand: ExpectedCancelTaskCommand;
  TaskRepository: ExpectedTaskRepository;
  ServiceEventKind: ExpectedServiceEventKind;
  ManualServiceEventActor: ExpectedManualServiceEventActor;
  ManualServiceEventOrigin: ExpectedManualServiceEventOrigin;
  IntegrationServiceEventOrigin: ExpectedIntegrationServiceEventOrigin;
  ServiceEventOrigin: ExpectedServiceEventOrigin;
  ServiceEvent: ExpectedServiceEvent;
  RecordServiceEventCommand: ExpectedRecordServiceEventCommand;
  ServiceEventRepository: ExpectedServiceEventRepository;
  DomainEventEnvelope: ExpectedDomainEventEnvelope;
  AppendDomainEventCommand: ExpectedAppendDomainEventCommand;
  DomainEventStore: ExpectedDomainEventStore;
  EnqueueOutboxCommand: ExpectedEnqueueOutboxCommand;
  ClaimOutboxCommand: ExpectedClaimOutboxCommand;
  ClaimedOutboxRecord: ExpectedClaimedOutboxRecord;
  OutboxLeaseFence: ExpectedOutboxLeaseFence;
  CompleteOutboxCommand: ExpectedCompleteOutboxCommand;
  FailOutboxCommand: ExpectedFailOutboxCommand;
  OutboxTransition: ExpectedOutboxTransition;
  OutboxRepository: ExpectedOutboxRepository;
  DurableJobStatus: ExpectedDurableJobStatus;
  JobScheduleSource: ExpectedJobScheduleSource;
  ScheduleJobCommand: ExpectedScheduleJobCommand;
  LeaseJobCommand: ExpectedLeaseJobCommand;
  JobLeaseFence: ExpectedJobLeaseFence;
  LeasedJobRecord: ExpectedLeasedJobRecord;
  RenewJobLeaseCommand: ExpectedRenewJobLeaseCommand;
  PauseJobCommand: ExpectedPauseJobCommand;
  ResumeJobCommand: ExpectedResumeJobCommand;
  CancelJobCommand: ExpectedCancelJobCommand;
  JobTransition: ExpectedJobTransition;
  CompleteJobCommand: ExpectedCompleteJobCommand;
  FailJobCommand: ExpectedFailJobCommand;
  DeadLetterJobCommand: ExpectedDeadLetterJobCommand;
  JobRepository: ExpectedJobRepository;
  SecretReferenceStore: ExpectedSecretReferenceStore;
  SecretReference: ExpectedSecretReference;
  RegisterIntegrationCommand: ExpectedRegisterIntegrationCommand;
  ResolvedIntegration: ExpectedResolvedIntegration;
  IntegrationHealthStatus: ExpectedIntegrationHealthStatus;
  IntegrationHealth: ExpectedIntegrationHealth;
  DisconnectIntegrationCommand: ExpectedDisconnectIntegrationCommand;
  IntegrationTransition: ExpectedIntegrationTransition;
  IntegrationRegistry: ExpectedIntegrationRegistry;
};

const exactContractEquality: Assert<Equal<ActualContracts, ExpectedContracts>> = true;

// @ts-expect-error Member actors require an id.
const invalidMemberActor: OperationActor = { type: "member" };
// @ts-expect-error Provider actors require an id.
const invalidProviderActor: OperationActor = { type: "provider" };
const invalidProviderManualOrigin: ManualServiceEventOrigin = {
  type: "manual",
  // @ts-expect-error Provider activity must use an integration service-event origin.
  actor: { type: "provider", id: "provider-1" },
};

const actor: ExpectedOperationActor = { type: "member", id: "member-1" };
const contactClearPatch: ExpectedContactUpdatePatch = { email: null, phone: null };
const contact: ExpectedContact = {
  id: "contact-1",
  siteId: "site-1",
  createdAt: "2026-07-16T12:00:00.000Z",
  updatedAt: "2026-07-16T12:00:00.000Z",
  version: 2,
  displayName: "Ada Lovelace",
  email: "ada@example.com",
};
const appliedContact: ExpectedAppliedOrConflict<ExpectedContact> = { status: "applied", value: contact };
const task: ExpectedTaskSummary = {
  id: "task-1",
  siteId: "site-1",
  relatedType: "contact",
  relatedId: contact.id,
  title: "Follow up",
  status: "open",
  version: 1,
};
const suppression: ExpectedSuppressionRecord = {
  id: "suppression-1",
  siteId: "site-1",
  channel: "email",
  normalizedDestinationHash: "sha256:example",
  reasonCode: "unsubscribed",
  source: "contact_request",
  retainedForPrevention: false,
  version: 1,
};
const outboxLease: ExpectedOutboxLeaseFence = {
  siteId: "site-1",
  outboxId: "outbox-1",
  workerId: "worker-1",
  leaseToken: "lease-1",
  leaseExpiresAt: "2026-07-16T12:05:00.000Z",
  attempt: 1,
};
const claimedOutbox: ExpectedClaimedOutboxRecord = {
  ...outboxLease,
  eventId: "event-1",
  destination: "email.send",
  payload: { contactId: contact.id },
  idempotencyKey: "outbox-event-1",
};
const jobLease: ExpectedJobLeaseFence = {
  siteId: "site-1",
  jobId: "job-1",
  workerId: "worker-1",
  leaseToken: "lease-2",
  leaseExpiresAt: "2026-07-16T12:05:00.000Z",
  attempt: 1,
  version: 3,
};
const leasedJob: ExpectedLeasedJobRecord = {
  ...jobLease,
  kind: "follow_up",
  payload: { contactId: contact.id },
  runAt: "2026-07-16T12:00:00.000Z",
};
const outboxTransition: ExpectedOutboxTransition = {
  siteId: "site-1",
  outboxId: "outbox-1",
  status: "completed",
  attempt: 1,
};
const jobTransition: ExpectedJobTransition = {
  siteId: "site-1",
  jobId: "job-1",
  status: "completed",
  version: 4,
};
const outboxAppliedResult: ExpectedLeaseResult<
  ExpectedOutboxTransition,
  ExpectedOutboxLeaseResourceIdentity
> = {
  status: "applied",
  resource: { resourceType: "outbox", siteId: "site-1", outboxId: "outbox-1" },
  value: outboxTransition,
};
const outboxReplayResult: ExpectedLeaseResult<
  ExpectedOutboxTransition,
  ExpectedOutboxLeaseResourceIdentity
> = {
  status: "replayed",
  replayReason: "same_fence",
  resource: { resourceType: "outbox", siteId: "site-1", outboxId: "outbox-1" },
  workerId: "worker-1",
  leaseToken: "lease-1",
  attempt: 1,
  value: outboxTransition,
};
const renewedJobResult: ExpectedLeaseResult<ExpectedLeasedJobRecord, ExpectedJobLeaseResourceIdentity> = {
  status: "applied",
  resource: { resourceType: "job", siteId: "site-1", jobId: "job-1" },
  value: leasedJob,
};
const jobAppliedResult: ExpectedLeaseResult<ExpectedJobTransition, ExpectedJobLeaseResourceIdentity> = {
  status: "applied",
  resource: { resourceType: "job", siteId: "site-1", jobId: "job-1" },
  value: jobTransition,
};
const leaseConflicts: readonly ExpectedLeaseConflict[] = [
  {
    status: "conflict",
    reason: "expired",
    resource: { resourceType: "job", siteId: "site-1", jobId: "job-1" },
    leaseExpiresAt: "2026-07-16T12:05:00.000Z",
    observedAt: "2026-07-16T12:06:00.000Z",
  },
  {
    status: "conflict",
    reason: "stale_token",
    resource: { resourceType: "outbox", siteId: "site-1", outboxId: "outbox-1" },
    providedLeaseToken: "lease-stale",
  },
  {
    status: "conflict",
    reason: "worker_mismatch",
    resource: { resourceType: "job", siteId: "site-1", jobId: "job-1" },
    providedWorkerId: "worker-2",
    leasedWorkerId: "worker-1",
  },
  {
    status: "conflict",
    reason: "version_conflict",
    resource: { resourceType: "job", siteId: "site-1", jobId: "job-1" },
    expectedVersion: 3,
    actualVersion: 4,
  },
];
const serviceEvent: ExpectedServiceEvent = {
  id: "service-event-1",
  siteId: "site-1",
  contactId: contact.id,
  kind: "estimate.sent",
  origin: { type: "manual", actor },
  occurredAt: "2026-07-16T12:00:00.000Z",
  correlationId: "correlation-1",
};
const domainEvent: ExpectedDomainEventEnvelope = {
  id: "event-1",
  schemaVersion: 1,
  siteId: "site-1",
  type: "contact.created",
  occurredAt: "2026-07-16T12:00:00.000Z",
  actor,
  correlationId: "correlation-1",
  causationId: "command-1",
  aggregateType: "contact",
  aggregateId: contact.id,
  aggregateVersion: 1,
  payload: { contactId: contact.id },
};
const secretReference: ExpectedSecretReference = { store: "vault", referenceId: "secret-1" };

const expectedContactRepository: ExpectedContactRepository = {
  create: async (_input: ExpectedCreateContactCommand): Promise<ExpectedContact> => contact,
  match: async (
    _siteId: string,
    _identity: { readonly email?: string; readonly phone?: string },
  ): Promise<readonly ExpectedContactMatch[]> => [],
  get: async (_siteId: string, _contactId: string): Promise<ExpectedContact | null> => contact,
  update: async (_input: ExpectedUpdateContactCommand): Promise<ExpectedAppliedOrConflict<ExpectedContact>> =>
    appliedContact,
  proposeMerge: async (
    _siteId: string,
    sourceId: string,
    targetId: string,
  ): Promise<ExpectedContactMergeProposal> => ({ sourceId, targetId, conflicts: [] }),
  executeReviewedMerge: async (
    _input: ExpectedExecuteContactMergeCommand,
  ): Promise<ExpectedAppliedOrConflict<ExpectedContact>> => appliedContact,
  exportContactRecord: async (_input: ExpectedExportContactRecordQuery): Promise<ExpectedReadonlyJsonObject> => ({
    contactId: contact.id,
  }),
  pseudonymizeContactRecord: async (
    _input: ExpectedPseudonymizeContactRecordCommand,
  ): Promise<ExpectedAppliedOrConflict<ExpectedContact>> => appliedContact,
};

const expectedConsentService: ExpectedConsentService = {
  recordEvidence: async (_input: ExpectedRecordConsentEvidenceCommand): Promise<string> => "evidence-1",
  evaluate: async (_input: ExpectedEvaluateConsentQuery): Promise<ExpectedConsentEvaluation> => ({
    allowed: true,
    reasonCode: "consent_granted",
    evidenceId: "evidence-1",
  }),
  revoke: async (_input: ExpectedRevokeConsentCommand): Promise<void> => {},
  explain: async (_input: ExpectedExplainConsentQuery): Promise<readonly ExpectedConsentExplanation[]> => [
    { code: "consent_granted", message: "Consent evidence permits this operation", evidenceId: "evidence-1" },
  ],
};

const expectedSuppressionRepository: ExpectedSuppressionRepository = {
  add: async (_input: ExpectedAddSuppressionCommand): Promise<ExpectedSuppressionRecord> => suppression,
  evaluate: async (
    _siteId: string,
    _channel: ExpectedSuppressionChannel,
    _hash: string,
  ): Promise<ExpectedSuppressionEvaluation> => ({ suppressed: false }),
  reconcileProviderFact: async (
    _input: ExpectedReconcileProviderSuppressionCommand,
  ): Promise<ExpectedSuppressionRecord> => suppression,
  retainPreventionEvidence: async (
    _input: ExpectedRetainSuppressionEvidenceCommand,
  ): Promise<ExpectedAppliedOrConflict<ExpectedSuppressionRecord>> => ({ status: "applied", value: suppression }),
};

const expectedTaskRepository: ExpectedTaskRepository = {
  create: async (_input: ExpectedCreateTaskCommand): Promise<ExpectedTaskSummary> => task,
  assign: async (_input: ExpectedAssignTaskCommand): Promise<ExpectedAppliedOrConflict<ExpectedTaskSummary>> => ({
    status: "applied",
    value: task,
  }),
  complete: async (_input: ExpectedCompleteTaskCommand): Promise<ExpectedAppliedOrConflict<ExpectedTaskSummary>> => ({
    status: "applied",
    value: task,
  }),
  cancel: async (_input: ExpectedCancelTaskCommand): Promise<ExpectedAppliedOrConflict<ExpectedTaskSummary>> => ({
    status: "applied",
    value: task,
  }),
  listByRelatedRecord: async (
    _siteId: string,
    _relatedType: string,
    _relatedId: string,
  ): Promise<readonly ExpectedTaskSummary[]> => [task],
};

const expectedServiceEventRepository: ExpectedServiceEventRepository = {
  record: async (_input: ExpectedRecordServiceEventCommand): Promise<ExpectedServiceEvent> => serviceEvent,
  list: async (_siteId: string, _contactId: string): Promise<readonly ExpectedServiceEvent[]> => [serviceEvent],
};

const expectedDomainEventStore: ExpectedDomainEventStore = {
  append: async <Payload extends ExpectedReadonlyJsonObject>(
    input: ExpectedAppendDomainEventCommand<Payload>,
  ): Promise<ExpectedAppliedOrConflict<ExpectedDomainEventEnvelope<Payload>>> => ({
    status: "applied",
    value: input.event,
  }),
  read: async (_siteId: string, _eventId: string): Promise<ExpectedDomainEventEnvelope | null> => null,
};

const expectedOutboxRepository: ExpectedOutboxRepository = {
  enqueue: async (_input: ExpectedEnqueueOutboxCommand): Promise<string> => claimedOutbox.outboxId,
  claim: async (_input: ExpectedClaimOutboxCommand): Promise<ExpectedClaimedOutboxRecord | null> => claimedOutbox,
  complete: async (
    _input: ExpectedCompleteOutboxCommand,
  ): Promise<ExpectedLeaseResult<ExpectedOutboxTransition, ExpectedOutboxLeaseResourceIdentity>> =>
    outboxAppliedResult,
  fail: async (
    _input: ExpectedFailOutboxCommand,
  ): Promise<ExpectedLeaseResult<ExpectedOutboxTransition, ExpectedOutboxLeaseResourceIdentity>> =>
    outboxReplayResult,
};

const expectedJobRepository: ExpectedJobRepository = {
  schedule: async (_input: ExpectedScheduleJobCommand): Promise<string> => leasedJob.jobId,
  lease: async (_input: ExpectedLeaseJobCommand): Promise<ExpectedLeasedJobRecord | null> => leasedJob,
  renew: async (
    _input: ExpectedRenewJobLeaseCommand,
  ): Promise<ExpectedLeaseResult<ExpectedLeasedJobRecord, ExpectedJobLeaseResourceIdentity>> => renewedJobResult,
  pause: async (_input: ExpectedPauseJobCommand): Promise<ExpectedAppliedOrConflict<ExpectedJobTransition>> => ({
    status: "applied",
    value: { siteId: leasedJob.siteId, jobId: leasedJob.jobId, status: "paused", version: 4 },
  }),
  resume: async (_input: ExpectedResumeJobCommand): Promise<ExpectedAppliedOrConflict<ExpectedJobTransition>> => ({
    status: "applied",
    value: { siteId: leasedJob.siteId, jobId: leasedJob.jobId, status: "scheduled", version: 4 },
  }),
  cancel: async (_input: ExpectedCancelJobCommand): Promise<ExpectedAppliedOrConflict<ExpectedJobTransition>> => ({
    status: "applied",
    value: { siteId: leasedJob.siteId, jobId: leasedJob.jobId, status: "cancelled", version: 4 },
  }),
  complete: async (
    _input: ExpectedCompleteJobCommand,
  ): Promise<ExpectedLeaseResult<ExpectedJobTransition, ExpectedJobLeaseResourceIdentity>> => jobAppliedResult,
  fail: async (
    _input: ExpectedFailJobCommand,
  ): Promise<ExpectedLeaseResult<ExpectedJobTransition, ExpectedJobLeaseResourceIdentity>> => jobAppliedResult,
  deadLetter: async (
    _input: ExpectedDeadLetterJobCommand,
  ): Promise<ExpectedLeaseResult<ExpectedJobTransition, ExpectedJobLeaseResourceIdentity>> => jobAppliedResult,
};

const expectedIntegrationRegistry: ExpectedIntegrationRegistry = {
  register: async (_input: ExpectedRegisterIntegrationCommand): Promise<string> => "integration-1",
  resolve: async (_siteId: string, _capability: string): Promise<ExpectedResolvedIntegration | null> => ({
    integrationId: "integration-1",
    provider: "example",
    secretReference,
    version: 1,
  }),
  checkHealth: async (_siteId: string, _integrationId: string): Promise<ExpectedIntegrationHealth> => ({
    status: "connected",
  }),
  disconnect: async (
    input: ExpectedDisconnectIntegrationCommand,
  ): Promise<ExpectedAppliedOrConflict<ExpectedIntegrationTransition>> => ({
    status: "applied",
    value: {
      siteId: input.siteId,
      integrationId: input.integrationId,
      status: "disconnected",
      version: input.expectedVersion + 1,
    },
  }),
};

const contactRepository: ContactRepository = expectedContactRepository;
const consentService: ConsentService = expectedConsentService;
const suppressionRepository: SuppressionRepository = expectedSuppressionRepository;
const taskRepository: TaskRepository = expectedTaskRepository;
const serviceEventRepository: ServiceEventRepository = expectedServiceEventRepository;
const domainEventStore: DomainEventStore = expectedDomainEventStore;
const outboxRepository: OutboxRepository = expectedOutboxRepository;
const jobRepository: JobRepository = expectedJobRepository;
const integrationRegistry: IntegrationRegistry = expectedIntegrationRegistry;

const methodContracts = [
  [
    contactRepository,
    [
      "create",
      "match",
      "get",
      "update",
      "proposeMerge",
      "executeReviewedMerge",
      "exportContactRecord",
      "pseudonymizeContactRecord",
    ],
  ],
  [consentService, ["recordEvidence", "evaluate", "revoke", "explain"]],
  [suppressionRepository, ["add", "evaluate", "reconcileProviderFact", "retainPreventionEvidence"]],
  [taskRepository, ["create", "assign", "complete", "cancel", "listByRelatedRecord"]],
  [serviceEventRepository, ["record", "list"]],
  [domainEventStore, ["append", "read"]],
  [outboxRepository, ["enqueue", "claim", "complete", "fail"]],
  [jobRepository, ["schedule", "lease", "renew", "pause", "resume", "cancel", "complete", "fail", "deadLetter"]],
  [integrationRegistry, ["register", "resolve", "checkHealth", "disconnect"]],
] as const;

const serviceEventKinds: readonly ServiceEventKind[] = [
  "estimate.sent",
  "estimate.accepted",
  "estimate.declined",
  "appointment.scheduled",
  "appointment.rescheduled",
  "appointment.cancelled",
  "appointment.completed",
];

describe("growth-core public contracts", () => {
  it("type-checks the independent fixture from the package entry point", () => {
    const fixturePath = fileURLToPath(import.meta.url);
    const packageRoot = resolve(dirname(fixturePath), "..");
    const configPath = resolve(packageRoot, "tsconfig.json");
    const config = ts.readConfigFile(configPath, ts.sys.readFile);

    expect(config.error).toBeUndefined();

    const parsedConfig = ts.parseJsonConfigFileContent(config.config, ts.sys, packageRoot);

    expect(parsedConfig.errors).toEqual([]);
    expect(parsedConfig.fileNames.map((fileName) => resolve(fileName))).toContain(resolve(fixturePath));

    const program = ts.createProgram(parsedConfig.fileNames, parsedConfig.options);
    const diagnostics = [...parsedConfig.errors, ...ts.getPreEmitDiagnostics(program)];
    const formattedDiagnostics = ts.formatDiagnosticsWithColorAndContext(diagnostics, {
      getCanonicalFileName: (fileName) => fileName,
      getCurrentDirectory: ts.sys.getCurrentDirectory,
      getNewLine: () => ts.sys.newLine,
    });

    expect(formattedDiagnostics).toBe("");
    expect(exactContractEquality).toBe(true);
  }, 30_000);

  it("keeps every stable service method present and callable", () => {
    for (const [service, methodNames] of methodContracts) {
      expect(Object.keys(service).sort()).toEqual([...methodNames].sort());
      for (const methodName of methodNames) {
        expect(Reflect.get(service, methodName)).toBeTypeOf("function");
      }
    }
  });

  it("locks event kinds, executable leases, command fencing, causality, and secret references", () => {
    const pauseJobCommand: ExpectedPauseJobCommand = {
      siteId: "site-1",
      actor,
      idempotencyKey: "operation-1",
      expectedVersion: 2,
      jobId: "job-1",
      reason: "maintenance",
    };
    const consentEvidenceCommand: ExpectedRecordConsentEvidenceCommand = {
      siteId: "site-1",
      actor,
      idempotencyKey: "consent-evidence-1",
      contactId: "contact-1",
      channel: "email",
      purpose: "marketing",
      status: "granted",
      source: "website_form",
      occurredAt: "2026-07-16T12:00:00.000Z",
      policyVersion: "2026-07",
      evidenceReference: { system: "form-submissions", referenceId: "submission-1" },
    };
    const serviceEventCommand: ExpectedRecordServiceEventCommand = {
      siteId: "site-1",
      contactId: "contact-1",
      kind: "appointment.rescheduled",
      origin: {
        type: "integration",
        integrationId: "integration-1",
        providerEventId: "provider-event-1",
      },
      occurredAt: "2026-07-16T13:00:00.000Z",
      correlationId: "correlation-1",
      replacesEventId: "service-event-previous",
      idempotencyKey: "service-event-1",
    };
    const providerSuppression: ExpectedReconcileProviderSuppressionCommand = {
      siteId: "site-1",
      actor: { type: "provider", id: "provider-1" },
      provider: "example",
      providerEventId: "provider-event-1",
      idempotencyIdentity: "providerEventId",
      channel: "email",
      normalizedDestinationHash: "sha256:example",
      reasonCode: "bounce",
      source: "provider_webhook",
    };

    expect(serviceEventKinds).toEqual([
      "estimate.sent",
      "estimate.accepted",
      "estimate.declined",
      "appointment.scheduled",
      "appointment.rescheduled",
      "appointment.cancelled",
      "appointment.completed",
    ]);
    expect(claimedOutbox).toEqual({
      siteId: "site-1",
      outboxId: "outbox-1",
      eventId: "event-1",
      destination: "email.send",
      payload: { contactId: "contact-1" },
      idempotencyKey: "outbox-event-1",
      workerId: "worker-1",
      leaseToken: "lease-1",
      leaseExpiresAt: "2026-07-16T12:05:00.000Z",
      attempt: 1,
    });
    expect(outboxLease).toEqual({
      siteId: "site-1",
      outboxId: "outbox-1",
      workerId: "worker-1",
      leaseToken: "lease-1",
      leaseExpiresAt: "2026-07-16T12:05:00.000Z",
      attempt: 1,
    });
    expect(leasedJob).toEqual({
      siteId: "site-1",
      jobId: "job-1",
      kind: "follow_up",
      payload: { contactId: "contact-1" },
      runAt: "2026-07-16T12:00:00.000Z",
      workerId: "worker-1",
      leaseToken: "lease-2",
      leaseExpiresAt: "2026-07-16T12:05:00.000Z",
      attempt: 1,
      version: 3,
    });
    expect(jobLease).toEqual({
      siteId: "site-1",
      jobId: "job-1",
      workerId: "worker-1",
      leaseToken: "lease-2",
      leaseExpiresAt: "2026-07-16T12:05:00.000Z",
      attempt: 1,
      version: 3,
    });
    expect(outboxAppliedResult).toEqual({
      status: "applied",
      resource: { resourceType: "outbox", siteId: "site-1", outboxId: "outbox-1" },
      value: {
        siteId: "site-1",
        outboxId: "outbox-1",
        status: "completed",
        attempt: 1,
      },
    });
    expect(outboxReplayResult).toEqual({
      status: "replayed",
      replayReason: "same_fence",
      resource: { resourceType: "outbox", siteId: "site-1", outboxId: "outbox-1" },
      workerId: "worker-1",
      leaseToken: "lease-1",
      attempt: 1,
      value: {
        siteId: "site-1",
        outboxId: "outbox-1",
        status: "completed",
        attempt: 1,
      },
    });
    expect(renewedJobResult).toEqual({
      status: "applied",
      resource: { resourceType: "job", siteId: "site-1", jobId: "job-1" },
      value: {
        siteId: "site-1",
        jobId: "job-1",
        workerId: "worker-1",
        leaseToken: "lease-2",
        leaseExpiresAt: "2026-07-16T12:05:00.000Z",
        attempt: 1,
        version: 3,
        kind: "follow_up",
        payload: { contactId: "contact-1" },
        runAt: "2026-07-16T12:00:00.000Z",
      },
    });
    expect(jobAppliedResult).toEqual({
      status: "applied",
      resource: { resourceType: "job", siteId: "site-1", jobId: "job-1" },
      value: {
        siteId: "site-1",
        jobId: "job-1",
        status: "completed",
        version: 4,
      },
    });
    expect(leaseConflicts).toEqual([
      {
        status: "conflict",
        reason: "expired",
        resource: { resourceType: "job", siteId: "site-1", jobId: "job-1" },
        leaseExpiresAt: "2026-07-16T12:05:00.000Z",
        observedAt: "2026-07-16T12:06:00.000Z",
      },
      {
        status: "conflict",
        reason: "stale_token",
        resource: { resourceType: "outbox", siteId: "site-1", outboxId: "outbox-1" },
        providedLeaseToken: "lease-stale",
      },
      {
        status: "conflict",
        reason: "worker_mismatch",
        resource: { resourceType: "job", siteId: "site-1", jobId: "job-1" },
        providedWorkerId: "worker-2",
        leasedWorkerId: "worker-1",
      },
      {
        status: "conflict",
        reason: "version_conflict",
        resource: { resourceType: "job", siteId: "site-1", jobId: "job-1" },
        expectedVersion: 3,
        actualVersion: 4,
      },
    ]);
    expect(pauseJobCommand).toEqual({
      siteId: "site-1",
      actor: { type: "member", id: "member-1" },
      idempotencyKey: "operation-1",
      expectedVersion: 2,
      jobId: "job-1",
      reason: "maintenance",
    });
    expect(domainEvent).toEqual({
      id: "event-1",
      schemaVersion: 1,
      siteId: "site-1",
      type: "contact.created",
      occurredAt: "2026-07-16T12:00:00.000Z",
      actor: { type: "member", id: "member-1" },
      correlationId: "correlation-1",
      causationId: "command-1",
      aggregateType: "contact",
      aggregateId: "contact-1",
      aggregateVersion: 1,
      payload: { contactId: "contact-1" },
    });
    expect(consentEvidenceCommand).toEqual({
      siteId: "site-1",
      actor: { type: "member", id: "member-1" },
      idempotencyKey: "consent-evidence-1",
      contactId: "contact-1",
      channel: "email",
      purpose: "marketing",
      status: "granted",
      source: "website_form",
      occurredAt: "2026-07-16T12:00:00.000Z",
      policyVersion: "2026-07",
      evidenceReference: { system: "form-submissions", referenceId: "submission-1" },
    });
    expect(serviceEventCommand).toEqual({
      siteId: "site-1",
      contactId: "contact-1",
      kind: "appointment.rescheduled",
      origin: {
        type: "integration",
        integrationId: "integration-1",
        providerEventId: "provider-event-1",
      },
      occurredAt: "2026-07-16T13:00:00.000Z",
      correlationId: "correlation-1",
      replacesEventId: "service-event-previous",
      idempotencyKey: "service-event-1",
    });
    expect(secretReference).toEqual({ store: "vault", referenceId: "secret-1" });
    expect(providerSuppression).toEqual({
      siteId: "site-1",
      actor: { type: "provider", id: "provider-1" },
      provider: "example",
      providerEventId: "provider-event-1",
      idempotencyIdentity: "providerEventId",
      channel: "email",
      normalizedDestinationHash: "sha256:example",
      reasonCode: "bounce",
      source: "provider_webhook",
    });
    expect(contactClearPatch).toEqual({ email: null, phone: null });
    expect(contactClearPatch).not.toHaveProperty("displayName");
    expect([
      actor,
      { type: "provider", id: "provider-1" },
      { type: "visitor" },
      { type: "system" },
    ] satisfies readonly ExpectedOperationActor[]).toEqual([
      { type: "member", id: "member-1" },
      { type: "provider", id: "provider-1" },
      { type: "visitor" },
      { type: "system" },
    ]);
  });
});
