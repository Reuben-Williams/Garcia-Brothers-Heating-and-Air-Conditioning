import { describe, expect, it, vi } from "vitest";
import type {
  RecordAssignment,
  ScopedAssignmentRepository,
  ScopedServiceEventRepository,
  ScopedTaskRepository,
  ServiceEvent,
  TaskSummary,
} from "../src/index.js";
import {
  createRecordAssignmentService,
  createServiceEventOrchestrationService,
  createTaskOrchestrationService,
} from "../src/index.js";

const actor = { type: "member" as const, id: "member-1" };
const assignment: RecordAssignment = {
  id: "assignment-1", siteId: "site-1", recordType: "lead", recordId: "lead-1", memberId: "member-2",
  state: "active", version: 2, assignedAt: "2026-07-18T00:00:00.000Z",
};
const task: TaskSummary = {
  id: "task-1", siteId: "site-1", relatedType: "lead", relatedId: "lead-1", title: "Call",
  status: "open", version: 1,
};

describe("shared assignment service", () => {
  it("passes expected versions and resolved scope to the transactional repository", async () => {
    const repository: ScopedAssignmentRepository = {
      listAuthorized: vi.fn(async () => [assignment]),
      setAuthorized: vi.fn(async () => ({ status: "applied" as const, value: assignment })),
      endAuthorized: vi.fn(async () => ({ status: "applied" as const, value: { ...assignment, state: "ended" as const, version: 3 } })),
    };
    const service = createRecordAssignmentService({ repository, authorize: vi.fn(async () => ({ allowed: true as const, scope: "site" as const })) });
    const command = {
      siteId: "site-1", actor, idempotencyKey: "assign-1", expectedVersion: 1,
      recordType: "lead" as const, recordId: "lead-1", memberId: "member-2",
    };

    await expect(service.set(command)).resolves.toMatchObject({ status: "applied", value: { version: 2 } });
    expect(repository.setAuthorized).toHaveBeenCalledWith({ command, scope: "site" });
    await service.list({ siteId: "site-1", actor, recordType: "lead", recordId: "lead-1" });
    expect(repository.listAuthorized).toHaveBeenCalledWith({
      siteId: "site-1",
      memberId: actor.id,
      recordType: "lead",
      recordId: "lead-1",
      scope: "site",
    });
  });
});

describe("shared task service", () => {
  it("requires expected parent versions and carries assigned scope into atomic creation", async () => {
    const repository: ScopedTaskRepository = {
      createAuthorized: vi.fn(async () => task),
      assignAuthorized: vi.fn(async () => ({ status: "applied" as const, value: task })),
      completeAuthorized: vi.fn(async () => ({ status: "applied" as const, value: { ...task, status: "completed" as const, version: 2 } })),
      cancelAuthorized: vi.fn(async () => ({ status: "applied" as const, value: { ...task, status: "cancelled" as const, version: 2 } })),
    };
    const service = createTaskOrchestrationService({ repository, authorize: vi.fn(async () => ({ allowed: true as const, scope: "assigned" as const })) });
    const command = {
      siteId: "site-1", actor, idempotencyKey: "task-1", relatedType: "lead", relatedId: "lead-1", title: "Call",
      authorizationParents: [{ type: "lead" as const, id: "lead-1" }], selfAssignmentIntent: true,
      expectedParentVersions: [{ type: "lead" as const, id: "lead-1", expectedVersion: 4 }],
    };

    await expect(service.create(command)).resolves.toEqual(task);
    expect(repository.createAuthorized).toHaveBeenCalledWith({ command, scope: "assigned" });
  });
});

describe("shared service-event orchestration", () => {
  it("carries contact and lead expected versions with assigned scope", async () => {
    const event: ServiceEvent = {
      id: "event-1", siteId: "site-1", contactId: "contact-1", leadId: "lead-1", kind: "appointment.scheduled",
      purpose: "estimate", origin: { type: "manual", actor }, occurredAt: "2026-07-18T00:00:00.000Z", correlationId: "event-1",
    };
    const repository: ScopedServiceEventRepository = { recordAuthorized: vi.fn(async () => event) };
    const service = createServiceEventOrchestrationService({ repository, authorize: vi.fn(async () => ({ allowed: true as const, scope: "assigned" as const })) });
    const command = {
      siteId: "site-1", contactId: "contact-1", leadId: "lead-1", kind: "appointment.scheduled" as const,
      purpose: "estimate" as const, origin: { type: "manual" as const, actor }, occurredAt: "2026-07-18T00:00:00.000Z",
      correlationId: "event-1", idempotencyKey: "event-1", expectedContactVersion: 3, expectedLeadVersion: 5,
    };

    await expect(service.record(command)).resolves.toEqual(event);
    expect(repository.recordAuthorized).toHaveBeenCalledWith({ command, scope: "assigned" });
  });

  it("preserves frozen system-origin support while requiring explicit authorization", async () => {
    const event: ServiceEvent = {
      id: "event-system", siteId: "site-1", contactId: "contact-1", kind: "estimate.sent",
      origin: { type: "manual", actor: { type: "system", id: "worker-1" } },
      occurredAt: "2026-07-18T00:00:00.000Z", correlationId: "event-system",
    };
    const repository: ScopedServiceEventRepository = { recordAuthorized: vi.fn(async () => event) };
    const authorize = vi.fn(async () => ({ allowed: true as const, scope: "site" as const }));
    const service = createServiceEventOrchestrationService({ repository, authorize });
    const command = {
      siteId: "site-1", contactId: "contact-1", kind: "estimate.sent" as const,
      origin: { type: "manual" as const, actor: { type: "system" as const, id: "worker-1" } },
      occurredAt: "2026-07-18T00:00:00.000Z", correlationId: "event-system", idempotencyKey: "event-system",
      expectedContactVersion: 2,
    };

    await expect(service.record(command)).resolves.toEqual(event);
    expect(authorize).toHaveBeenCalledWith(expect.objectContaining({ actor: command.origin.actor }));
    expect(repository.recordAuthorized).toHaveBeenCalledWith({ command, scope: "site" });
  });
});
