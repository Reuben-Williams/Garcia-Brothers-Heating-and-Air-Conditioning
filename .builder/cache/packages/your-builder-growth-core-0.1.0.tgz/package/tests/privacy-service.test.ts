import { describe, expect, it, vi } from "vitest";
import type {
  DataExport,
  DataExportServiceRepository,
  DeletionRequest,
  DeletionRequestRepository,
} from "../src/index.js";
import { createDataExportService, createDeletionRequestService, PrivacyServiceError } from "../src/index.js";

const member = { type: "member" as const, id: "owner-1" };
const now = "2026-07-18T12:00:00.000Z";

function exportRecord(overrides: Partial<DataExport> = {}): DataExport {
  return {
    id: "export-1",
    siteId: "site-1",
    requestedBy: "owner-1",
    scope: "customers",
    filters: {},
    status: "requested",
    version: 1,
    createdAt: now,
    ...overrides,
  };
}

function deletionRecord(overrides: Partial<DeletionRequest> = {}): DeletionRequest {
  return {
    id: "deletion-1",
    siteId: "site-1",
    requestedBy: "owner-1",
    targetType: "customer",
    targetId: "customer-1",
    legalHold: false,
    status: "requested",
    version: 1,
    createdAt: now,
    ...overrides,
  };
}

describe("data export service", () => {
  it("requires current authorization and a fresh session before requesting an export", async () => {
    const repository: DataExportServiceRepository = {
      request: vi.fn(async () => exportRecord()),
      get: vi.fn(async () => null),
      transition: vi.fn(async () => { throw new Error("not used"); }),
      lease: vi.fn(async () => null),
      complete: vi.fn(async () => { throw new Error("not used"); }),
      expire: vi.fn(async () => { throw new Error("not used"); }),
      createDownloadAuthorization: vi.fn(async () => { throw new Error("not used"); }),
    };
    const service = createDataExportService(repository, () => now);
    const command = { siteId: "site-1", actor: member, idempotencyKey: "export-request", scope: "customers" as const, filters: {} };

    await expect(service.request(command, { canExport: false, freshSession: true }))
      .rejects.toEqual(expect.objectContaining<Partial<PrivacyServiceError>>({ code: "not_authorized" }));
    await expect(service.request(command, { canExport: true, freshSession: false }))
      .rejects.toEqual(expect.objectContaining<Partial<PrivacyServiceError>>({ code: "fresh_session_required" }));
    await expect(service.request(command, { canExport: true, freshSession: true })).resolves.toEqual(exportRecord());
  });

  it("leases, completes, expires, and authorizes downloads through explicit worker boundaries", async () => {
    const completed = exportRecord({ status: "completed", version: 3, expiresAt: "2026-07-18T13:00:00.000Z" });
    const repository: DataExportServiceRepository = {
      request: vi.fn(async () => exportRecord()),
      get: vi.fn(async () => completed),
      transition: vi.fn(async () => { throw new Error("not used"); }),
      lease: vi.fn(async () => ({ export: exportRecord({ status: "processing", version: 2 }), workerId: "worker-1", leaseToken: "lease-1", leaseExpiresAt: "2026-07-18T12:05:00.000Z" })),
      complete: vi.fn(async () => ({ status: "applied" as const, value: completed })),
      expire: vi.fn(async () => ({ status: "applied" as const, value: exportRecord({ status: "expired", version: 4 }) })),
      createDownloadAuthorization: vi.fn(async () => ({ url: "https://download.invalid/signed", expiresAt: "2026-07-18T12:05:00.000Z" })),
    };
    const service = createDataExportService(repository, () => now);

    await expect(service.lease({ siteId: "site-1", exportId: "export-1", workerId: "worker-1", leaseSeconds: 300 })).resolves.toMatchObject({ leaseToken: "lease-1" });
    await expect(service.complete({ siteId: "site-1", exportId: "export-1", workerId: "worker-1", leaseToken: "lease-1", expectedVersion: 2, artifactReference: "exports/export-1.csv", expiresAt: "2026-07-18T13:00:00.000Z" })).resolves.toEqual({ status: "applied", value: completed });
    await expect(service.authorizeDownload({ siteId: "site-1", exportId: "export-1", actor: member }, { canExport: true, isOwner: false })).resolves.toMatchObject({ url: expect.stringContaining("download.invalid") });
    await expect(service.expire({ siteId: "site-1", exportId: "export-1", expectedVersion: 3 })).resolves.toMatchObject({ status: "applied" });
  });

  it("denies expired downloads and callers other than the requester or owner", async () => {
    const repository: DataExportServiceRepository = {
      request: vi.fn(async () => exportRecord()),
      get: vi.fn(async () => exportRecord({ requestedBy: "member-2", status: "completed", expiresAt: "2026-07-18T11:00:00.000Z" })),
      transition: vi.fn(async () => { throw new Error("not used"); }),
      lease: vi.fn(async () => null),
      complete: vi.fn(async () => { throw new Error("not used"); }),
      expire: vi.fn(async () => { throw new Error("not used"); }),
      createDownloadAuthorization: vi.fn(async () => { throw new Error("not used"); }),
    };
    const service = createDataExportService(repository, () => now);

    await expect(service.authorizeDownload({ siteId: "site-1", exportId: "export-1", actor: member }, { canExport: true, isOwner: false }))
      .rejects.toEqual(expect.objectContaining<Partial<PrivacyServiceError>>({ code: "not_authorized" }));
    await expect(service.authorizeDownload({ siteId: "site-1", exportId: "export-1", actor: member }, { canExport: true, isOwner: true }))
      .rejects.toEqual(expect.objectContaining<Partial<PrivacyServiceError>>({ code: "export_expired" }));
  });
});

describe("deletion request service", () => {
  it("allows only an owner to create a request and does not execute deletion inline", async () => {
    const request = vi.fn(async () => deletionRecord());
    const repository: DeletionRequestRepository = {
      request,
      get: vi.fn(async () => null),
      transition: vi.fn(async () => { throw new Error("not used"); }),
    };
    const service = createDeletionRequestService(repository);
    const command = { siteId: "site-1", actor: member, idempotencyKey: "delete-request", targetType: "customer" as const, targetId: "customer-1", reason: "owner request" };

    await expect(service.request(command, { isOwner: false }))
      .rejects.toEqual(expect.objectContaining<Partial<PrivacyServiceError>>({ code: "not_authorized" }));
    await expect(service.request(command, { isOwner: true })).resolves.toEqual(deletionRecord());
    expect(request).toHaveBeenCalledTimes(1);
  });

  it("permits only owner review transitions and blocks approval under legal hold", async () => {
    const transition = vi.fn(async () => ({ status: "applied" as const, value: deletionRecord({ status: "rejected", version: 2 }) }));
    const repository: DeletionRequestRepository = {
      request: vi.fn(async () => deletionRecord()),
      get: vi.fn(async () => deletionRecord({ legalHold: true })),
      transition,
    };
    const service = createDeletionRequestService(repository);
    const command = { siteId: "site-1", requestId: "deletion-1", actor: member, idempotencyKey: "delete-review", expectedVersion: 1 };

    await expect(service.review({ ...command, decision: "approve" }, { isOwner: true }))
      .rejects.toEqual(expect.objectContaining<Partial<PrivacyServiceError>>({ code: "legal_hold" }));
    await expect(service.review({ ...command, decision: "reject" }, { isOwner: true })).resolves.toMatchObject({ status: "applied" });
    expect(transition).toHaveBeenCalledWith(expect.objectContaining({ to: "rejected" }));
  });
});
