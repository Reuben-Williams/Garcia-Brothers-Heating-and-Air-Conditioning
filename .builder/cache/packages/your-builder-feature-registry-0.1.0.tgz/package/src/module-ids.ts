export const MODULE_IDS = Object.freeze({
  website: "core.website",
  dashboard: "growth.dashboard",
  leads: "growth.leads",
  customers: "growth.customers",
  messaging: "growth.messaging",
  automations: "growth.automations",
  reviews: "growth.reviews",
  projects: "growth.projects",
  ai: "growth.ai",
  chat: "growth.chat",
} as const);

export type GrowthModuleId = (typeof MODULE_IDS)[keyof typeof MODULE_IDS];
