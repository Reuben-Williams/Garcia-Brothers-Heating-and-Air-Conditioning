import type { BuilderCapability } from "@your-builder/core";
import type { GrowthModuleId } from "./module-ids.js";

export type FeatureRegistryErrorCode =
  | "UNKNOWN_MODULE_ID"
  | "DUPLICATE_MODULE"
  | "DUPLICATE_ROUTE"
  | "INVALID_DEPENDENCY"
  | "UNKNOWN_DEPENDENCY"
  | "DEPENDENCY_CYCLE"
  | "INVALID_VERSION"
  | "ENTITLEMENT_MISMATCH"
  | "UNSAFE_DEMO";

export class FeatureRegistryError extends Error {
  constructor(public readonly code: FeatureRegistryErrorCode, message: string) {
    super(message);
    this.name = "FeatureRegistryError";
  }
}

export interface ModuleRouteDefinition { readonly id: string; readonly path: string; readonly label: string; }
export interface ModuleDependency { readonly moduleId: GrowthModuleId; readonly optional: boolean; }
export interface ModuleSetupStep {
  readonly id: string;
  readonly label: string;
  readonly required: boolean;
  readonly capability?: BuilderCapability;
}
export interface ModuleDemoDefinition {
  readonly fixtureId: string;
  readonly allowMutations: boolean;
  readonly allowsExternalEffects: false;
}
export interface ModuleHealthCheck {
  readonly id: string;
  readonly label: string;
  readonly severity: "info" | "warning" | "critical";
}

export interface GrowthFeatureModule {
  readonly id: GrowthModuleId;
  readonly version: string;
  readonly label: string;
  readonly description: string;
  readonly icon: string;
  readonly navigationGroup: "website" | "growth" | "manage";
  readonly routes: readonly ModuleRouteDefinition[];
  readonly requiredEntitlement: GrowthModuleId;
  readonly requiredCapabilities: readonly BuilderCapability[];
  readonly dependencies: readonly ModuleDependency[];
  readonly setupSteps: readonly ModuleSetupStep[];
  readonly demo: ModuleDemoDefinition;
  readonly healthChecks: readonly ModuleHealthCheck[];
  readonly mobileNavigationPriority?: number;
}
