import { FeatureRegistryError, type GrowthFeatureModule } from "./module.js";
import type { GrowthModuleId } from "./module-ids.js";

export function resolveFeatureDependencyOrder(
  modules: readonly GrowthFeatureModule[],
): readonly GrowthModuleId[] {
  for (const featureModule of modules) {
    for (const dependency of featureModule.dependencies) {
      if (typeof dependency.optional !== "boolean") {
        throw new FeatureRegistryError(
          "INVALID_DEPENDENCY",
          `INVALID_DEPENDENCY: Module "${String(featureModule.id)}" dependency "${String(dependency.moduleId)}" must declare "optional" as a boolean.`,
        );
      }
    }
  }

  const byId = new Map<GrowthModuleId, GrowthFeatureModule>();
  for (const featureModule of modules) byId.set(featureModule.id, featureModule);

  const visiting = new Set<GrowthModuleId>();
  const visited = new Set<GrowthModuleId>();
  const path: GrowthModuleId[] = [];
  const order: GrowthModuleId[] = [];

  const visit = (featureModule: GrowthFeatureModule): void => {
    if (visited.has(featureModule.id)) return;

    visiting.add(featureModule.id);
    path.push(featureModule.id);

    for (const dependency of featureModule.dependencies) {
      const dependencyModule = byId.get(dependency.moduleId);
      if (!dependencyModule) {
        if (dependency.optional === true) continue;
        throw new FeatureRegistryError(
          "UNKNOWN_DEPENDENCY",
          `UNKNOWN_DEPENDENCY: Module "${featureModule.id}" requires unknown module "${dependency.moduleId}".`,
        );
      }

      if (visiting.has(dependency.moduleId)) {
        const cyclePath = [...path, dependency.moduleId].join(" -> ");
        throw new FeatureRegistryError(
          "DEPENDENCY_CYCLE",
          `DEPENDENCY_CYCLE: ${cyclePath}`,
        );
      }

      visit(dependencyModule);
    }

    path.pop();
    visiting.delete(featureModule.id);
    visited.add(featureModule.id);
    order.push(featureModule.id);
  };

  for (const featureModule of modules) visit(featureModule);
  return Object.freeze(order);
}

export function validateFeatureDependencies(modules: readonly GrowthFeatureModule[]): void {
  resolveFeatureDependencyOrder(modules);
}
