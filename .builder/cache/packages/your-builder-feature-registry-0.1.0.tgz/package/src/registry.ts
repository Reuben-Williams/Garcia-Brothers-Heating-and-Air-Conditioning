import { validateFeatureDependencies } from "./dependency-validation.js";
import { FeatureRegistryError, type GrowthFeatureModule } from "./module.js";
import { MODULE_IDS, type GrowthModuleId } from "./module-ids.js";

export interface FeatureRegistry {
  readonly modules: readonly GrowthFeatureModule[];
  readonly get: (id: GrowthModuleId) => GrowthFeatureModule | undefined;
  readonly routeOwner: (path: string) => GrowthModuleId | undefined;
}

const RELEASE_VERSION = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
const CANONICAL_MODULE_IDS: readonly GrowthModuleId[] = Object.freeze(Object.values(MODULE_IDS));

function isGrowthModuleId(value: unknown): value is GrowthModuleId {
  return typeof value === "string" && CANONICAL_MODULE_IDS.some((moduleId) => moduleId === value);
}

export function createFeatureRegistry(modules: readonly GrowthFeatureModule[]): FeatureRegistry {
  for (const featureModule of modules) {
    if (!isGrowthModuleId(featureModule.id)) {
      throw new FeatureRegistryError(
        "UNKNOWN_MODULE_ID",
        `UNKNOWN_MODULE_ID: Module id "${String(featureModule.id)}" is not registered in MODULE_IDS.`,
      );
    }
  }

  const moduleIds = new Set<GrowthModuleId>();
  for (const featureModule of modules) {
    if (moduleIds.has(featureModule.id)) {
      throw new FeatureRegistryError(
        "DUPLICATE_MODULE",
        `DUPLICATE_MODULE: Module "${featureModule.id}" is declared more than once.`,
      );
    }
    moduleIds.add(featureModule.id);
  }

  for (const featureModule of modules) {
    if (typeof featureModule.version !== "string" || !RELEASE_VERSION.test(featureModule.version)) {
      throw new FeatureRegistryError(
        "INVALID_VERSION",
        `INVALID_VERSION: Module "${featureModule.id}" has invalid version "${String(featureModule.version)}".`,
      );
    }
  }

  const routePaths = new Set<string>();
  for (const featureModule of modules) {
    for (const route of featureModule.routes) {
      if (routePaths.has(route.path)) {
        throw new FeatureRegistryError(
          "DUPLICATE_ROUTE",
          `DUPLICATE_ROUTE: Route path "${route.path}" is declared more than once.`,
        );
      }
      routePaths.add(route.path);
    }
  }

  const routeIds = new Set<string>();
  for (const featureModule of modules) {
    for (const route of featureModule.routes) {
      if (routeIds.has(route.id)) {
        throw new FeatureRegistryError(
          "DUPLICATE_ROUTE",
          `DUPLICATE_ROUTE: Route id "${route.id}" is declared more than once.`,
        );
      }
      routeIds.add(route.id);
    }
  }

  for (const featureModule of modules) {
    if (featureModule.requiredEntitlement !== featureModule.id) {
      throw new FeatureRegistryError(
        "ENTITLEMENT_MISMATCH",
        `ENTITLEMENT_MISMATCH: Module "${featureModule.id}" requires entitlement "${featureModule.requiredEntitlement}" instead of its own id.`,
      );
    }
  }

  for (const featureModule of modules) {
    if (featureModule.demo.allowsExternalEffects !== false) {
      throw new FeatureRegistryError(
        "UNSAFE_DEMO",
        `UNSAFE_DEMO: Module "${featureModule.id}" allows external demo effects.`,
      );
    }
  }

  const registryModules = Object.freeze(modules.map(createModuleSnapshot));
  validateFeatureDependencies(registryModules);
  const byId = new Map(registryModules.map((featureModule) => [featureModule.id, featureModule]));
  const routeOwners = new Map<string, GrowthModuleId>();
  for (const featureModule of registryModules) {
    for (const route of featureModule.routes) routeOwners.set(route.path, featureModule.id);
  }

  return Object.freeze({
    modules: registryModules,
    get: (id: GrowthModuleId) => byId.get(id),
    routeOwner: (path: string) => routeOwners.get(path),
  });
}

function createModuleSnapshot(featureModule: GrowthFeatureModule): GrowthFeatureModule {
  const routes = Object.freeze(featureModule.routes.map((route) => Object.freeze({ ...route })));
  const requiredCapabilities = Object.freeze([...featureModule.requiredCapabilities]);
  const dependencies = Object.freeze(
    featureModule.dependencies.map((dependency) => Object.freeze({ ...dependency })),
  );
  const setupSteps = Object.freeze(featureModule.setupSteps.map((step) => Object.freeze({ ...step })));
  const demo = Object.freeze({ ...featureModule.demo });
  const healthChecks = Object.freeze(
    featureModule.healthChecks.map((healthCheck) => Object.freeze({ ...healthCheck })),
  );

  return Object.freeze({
    id: featureModule.id,
    version: featureModule.version,
    label: featureModule.label,
    description: featureModule.description,
    icon: featureModule.icon,
    navigationGroup: featureModule.navigationGroup,
    routes,
    requiredEntitlement: featureModule.requiredEntitlement,
    requiredCapabilities,
    dependencies,
    setupSteps,
    demo,
    healthChecks,
    ...(featureModule.mobileNavigationPriority === undefined
      ? {}
      : { mobileNavigationPriority: featureModule.mobileNavigationPriority }),
  });
}
