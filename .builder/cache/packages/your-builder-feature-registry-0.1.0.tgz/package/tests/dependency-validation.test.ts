import { describe, expect, it } from "vitest";
import {
  FeatureRegistryError,
  MODULE_IDS,
  resolveFeatureDependencyOrder,
  validateFeatureDependencies,
  type GrowthFeatureModule,
  type GrowthModuleId,
} from "@your-builder/feature-registry";

const module = (id: GrowthModuleId, route: string, dependencies: readonly GrowthModuleId[] = []) => ({
  id, version: "1.0.0", label: id, description: id, icon: "blocks",
  navigationGroup: "growth" as const,
  routes: [{ id: `${id}.home`, path: route, label: id }],
  requiredEntitlement: id,
  requiredCapabilities: ["dashboard.read"] as const,
  dependencies: dependencies.map((moduleId) => ({ moduleId, optional: false })),
  setupSteps: [],
  demo: { fixtureId: `${id}.demo`, allowMutations: true, allowsExternalEffects: false as const },
  healthChecks: [],
});

function dependencyError(modules: readonly GrowthFeatureModule[]): FeatureRegistryError {
  try {
    validateFeatureDependencies(modules);
  } catch (error) {
    expect(error).toBeInstanceOf(FeatureRegistryError);
    return error as FeatureRegistryError;
  }
  throw new Error("Expected dependency validation to fail.");
}

describe("validateFeatureDependencies", () => {
  it("returns dependencies before dependents regardless of registration order", () => {
    const customers = module(MODULE_IDS.customers, "/customers");
    const leads = module(MODULE_IDS.leads, "/leads", [MODULE_IDS.customers]);
    const dashboard = module(MODULE_IDS.dashboard, "/dashboard", [
      MODULE_IDS.customers,
      MODULE_IDS.leads,
    ]);

    expect(resolveFeatureDependencyOrder([dashboard, leads, customers])).toEqual([
      MODULE_IDS.customers,
      MODULE_IDS.leads,
      MODULE_IDS.dashboard,
    ]);
  });

  it("rejects non-boolean optional metadata before dependency traversal", () => {
    const malformedDependencyModule = {
      ...module(MODULE_IDS.leads, "/leads"),
      dependencies: [{ moduleId: MODULE_IDS.customers, optional: "false" }],
    } as unknown as GrowthFeatureModule;

    const error = dependencyError([malformedDependencyModule]);

    expect(error.code).toBe("INVALID_DEPENDENCY");
    expect(error.message).toBe(
      `INVALID_DEPENDENCY: Module "${MODULE_IDS.leads}" dependency "${MODULE_IDS.customers}" must declare "optional" as a boolean.`,
    );
  });

  it("rejects an unknown required dependency", () => {
    const error = dependencyError([
      module(MODULE_IDS.leads, "/leads", [MODULE_IDS.customers]),
    ]);

    expect(error.code).toBe("UNKNOWN_DEPENDENCY");
    expect(error.message).toBe(
      `UNKNOWN_DEPENDENCY: Module "${MODULE_IDS.leads}" requires unknown module "${MODULE_IDS.customers}".`,
    );
  });

  it("accepts a missing optional dependency", () => {
    const leads = {
      ...module(MODULE_IDS.leads, "/leads"),
      dependencies: [{ moduleId: MODULE_IDS.customers, optional: true }],
    } satisfies GrowthFeatureModule;

    expect(() => validateFeatureDependencies([leads])).not.toThrow();
  });

  it("keeps malformed dependency module IDs on the unknown-dependency path", () => {
    const unknownModuleId = "growth.typo";
    const malformedDependencyModule = {
      ...module(MODULE_IDS.leads, "/leads"),
      dependencies: [{ moduleId: unknownModuleId, optional: false }],
    } as unknown as GrowthFeatureModule;

    const error = dependencyError([malformedDependencyModule]);

    expect(error.code).toBe("UNKNOWN_DEPENDENCY");
    expect(error.message).toBe(
      `UNKNOWN_DEPENDENCY: Module "${MODULE_IDS.leads}" requires unknown module "${unknownModuleId}".`,
    );
  });

  it("includes existing optional dependencies in cycle detection", () => {
    const leads = {
      ...module(MODULE_IDS.leads, "/leads"),
      dependencies: [{ moduleId: MODULE_IDS.customers, optional: true }],
    } satisfies GrowthFeatureModule;
    const customers = module(MODULE_IDS.customers, "/customers", [MODULE_IDS.leads]);

    expect(dependencyError([leads, customers]).code).toBe("DEPENDENCY_CYCLE");
  });

  it("reports the deterministic traversed cycle path", () => {
    const leads = module(MODULE_IDS.leads, "/leads", [MODULE_IDS.customers]);
    const customers = module(MODULE_IDS.customers, "/customers", [MODULE_IDS.projects]);
    const projects = module(MODULE_IDS.projects, "/projects", [MODULE_IDS.leads]);
    const error = dependencyError([leads, customers, projects]);

    expect(error.code).toBe("DEPENDENCY_CYCLE");
    expect(error.message).toBe(
      `DEPENDENCY_CYCLE: ${MODULE_IDS.leads} -> ${MODULE_IDS.customers} -> ${MODULE_IDS.projects} -> ${MODULE_IDS.leads}`,
    );
  });

  it("reports a deterministic self-cycle path", () => {
    const error = dependencyError([
      module(MODULE_IDS.leads, "/leads", [MODULE_IDS.leads]),
    ]);

    expect(error.code).toBe("DEPENDENCY_CYCLE");
    expect(error.message).toBe(`DEPENDENCY_CYCLE: ${MODULE_IDS.leads} -> ${MODULE_IDS.leads}`);
  });

  it("follows module input order when choosing the first cycle", () => {
    const projects = module(MODULE_IDS.projects, "/projects", [MODULE_IDS.reviews]);
    const reviews = module(MODULE_IDS.reviews, "/reviews", [MODULE_IDS.projects]);
    const leads = module(MODULE_IDS.leads, "/leads", [MODULE_IDS.customers]);
    const customers = module(MODULE_IDS.customers, "/customers", [MODULE_IDS.leads]);
    const error = dependencyError([projects, reviews, leads, customers]);

    expect(error.message).toContain(`${MODULE_IDS.projects} -> ${MODULE_IDS.reviews} -> ${MODULE_IDS.projects}`);
  });
});
