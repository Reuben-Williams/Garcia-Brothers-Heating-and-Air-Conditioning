import { describe, expect, it } from "vitest";
import type { BuilderCapability } from "@your-builder/core";
import {
  FeatureRegistryError,
  MODULE_IDS,
  createFeatureRegistry,
  type GrowthFeatureModule,
  type GrowthModuleId,
} from "@your-builder/feature-registry";

const module = (id: GrowthModuleId, route: string, dependencies: readonly GrowthModuleId[] = []) => ({
  id, version: "1.0.0", label: id, description: id, icon: "blocks",
  navigationGroup: "growth" as const,
  routes: [{ id: `${id}.home`, path: route, label: id }],
  requiredEntitlement: id,
  requiredCapabilities: ["dashboard.read"] as const,
  dependencies: dependencies.map((moduleId) => ({ moduleId, optional: false })),
  setupSteps: [],
  demo: { fixtureId: `${id}.demo`, allowMutations: true, allowsExternalEffects: false as const },
  healthChecks: [],
});

function expectRegistryError(
  run: () => unknown,
  code: FeatureRegistryError["code"],
  message?: string,
): FeatureRegistryError {
  try {
    run();
  } catch (error) {
    expect(error).toBeInstanceOf(FeatureRegistryError);
    expect((error as FeatureRegistryError).code).toBe(code);
    if (message) expect((error as FeatureRegistryError).message).toBe(message);
    return error as FeatureRegistryError;
  }
  throw new Error(`Expected ${code}.`);
}

describe("createFeatureRegistry", () => {
  it("rejects unknown module IDs before all other registry validation", () => {
    const untrustedModule = {
      ...module(MODULE_IDS.leads, "/shared"),
      id: "growth.typo",
      version: "invalid",
      requiredEntitlement: "growth.typo",
      dependencies: [{ moduleId: MODULE_IDS.customers, optional: "false" }],
    } as unknown as GrowthFeatureModule;

    expectRegistryError(
      () => createFeatureRegistry([
        untrustedModule,
        module(MODULE_IDS.leads, "/shared"),
        module(MODULE_IDS.leads, "/other"),
      ]),
      "UNKNOWN_MODULE_ID",
      'UNKNOWN_MODULE_ID: Module id "growth.typo" is not registered in MODULE_IDS.',
    );
  });

  it("rejects duplicate routes and dependency cycles", () => {
    expect(() => createFeatureRegistry([
      module(MODULE_IDS.leads, "/admin/editor/leads"),
      module(MODULE_IDS.customers, "/admin/editor/leads"),
    ])).toThrow("DUPLICATE_ROUTE");
    expect(() => createFeatureRegistry([
      module(MODULE_IDS.leads, "/a", [MODULE_IDS.customers]),
      module(MODULE_IDS.customers, "/b", [MODULE_IDS.leads]),
    ])).toThrow("DEPENDENCY_CYCLE");
  });

  it("rejects duplicate module IDs before map construction can collapse them", () => {
    const error = expectRegistryError(
      () => createFeatureRegistry([
        module(MODULE_IDS.leads, "/leads"),
        module(MODULE_IDS.leads, "/other-leads"),
      ]),
      "DUPLICATE_MODULE",
    );

    expect(error.message).toContain(MODULE_IDS.leads);
  });

  it("accepts exact numeric semantic versions and rejects other formats", () => {
    const validVersions = ["0.0.0", "1.0.0", "10.20.30"];
    for (const version of validVersions) {
      expect(() => createFeatureRegistry([{ ...module(MODULE_IDS.leads, "/leads"), version }])).not.toThrow();
    }

    const invalidVersions: readonly unknown[] = [
      "1", "1.0", "v1.0.0", "1.0.0-beta", "1.0.0+build", "1.0.0.0",
      "01.2.3", "1.02.3", "1.2.03", 1,
    ];
    for (const version of invalidVersions) {
      const error = expectRegistryError(
        () => createFeatureRegistry([{ ...module(MODULE_IDS.leads, "/leads"), version: version as string }]),
        "INVALID_VERSION",
        `INVALID_VERSION: Module "${MODULE_IDS.leads}" has invalid version "${String(version)}".`,
      );
      expect(error.message).toContain(String(version));
    }
  });

  it("reports Symbol versions as deterministic registry errors", () => {
    const version = Symbol("1.0.0");
    const untrustedModule = {
      ...module(MODULE_IDS.leads, "/leads"),
      version,
    } as unknown as GrowthFeatureModule;

    expectRegistryError(
      () => createFeatureRegistry([untrustedModule]),
      "INVALID_VERSION",
      `INVALID_VERSION: Module "${MODULE_IDS.leads}" has invalid version "${String(version)}".`,
    );
  });

  it("rejects duplicate route IDs even when route paths differ", () => {
    const leads = module(MODULE_IDS.leads, "/leads");
    const customers = {
      ...module(MODULE_IDS.customers, "/customers"),
      routes: [{ id: leads.routes[0].id, path: "/customers", label: "Customers" }],
    } satisfies GrowthFeatureModule;

    expectRegistryError(() => createFeatureRegistry([leads, customers]), "DUPLICATE_ROUTE");
  });

  it("preserves input order and provides deterministic lookups", () => {
    const customers = module(MODULE_IDS.customers, "/customers");
    const leads = module(MODULE_IDS.leads, "/leads");
    const registry = createFeatureRegistry([customers, leads]);

    expect(registry.modules.map(({ id }) => id)).toEqual([MODULE_IDS.customers, MODULE_IDS.leads]);
    expect(registry.get(MODULE_IDS.customers)).toEqual(customers);
    expect(registry.get(MODULE_IDS.customers)).not.toBe(customers);
    expect(registry.get(MODULE_IDS.chat)).toBeUndefined();
    expect(registry.routeOwner("/leads")).toBe(MODULE_IDS.leads);
    expect(registry.routeOwner("/missing")).toBeUndefined();
  });

  it("isolates lookups and snapshots from caller mutations", () => {
    const requiredCapabilities: BuilderCapability[] = ["dashboard.read"];
    const dependencies: Array<{ moduleId: GrowthModuleId; optional: boolean }> = [
      { moduleId: MODULE_IDS.customers, optional: true },
    ];
    const setupSteps: Array<{
      id: string;
      label: string;
      required: boolean;
      capability?: BuilderCapability;
    }> = [{ id: "connect", label: "Connect", required: true, capability: "integrations.manage" }];
    const healthChecks: Array<{
      id: string;
      label: string;
      severity: "info" | "warning" | "critical";
    }> = [{ id: "ready", label: "Ready", severity: "info" }];
    const leads = {
      ...module(MODULE_IDS.leads, "/leads"),
      routes: [{ id: "growth.leads.home", path: "/leads", label: "Leads" }],
      requiredCapabilities,
      dependencies,
      setupSteps,
      demo: { fixtureId: "growth.leads.demo", allowMutations: true, allowsExternalEffects: false as const },
      healthChecks,
    } satisfies GrowthFeatureModule;
    const registry = createFeatureRegistry([leads]);
    const snapshot = registry.get(MODULE_IDS.leads);

    leads.id = MODULE_IDS.customers;
    Reflect.set(leads, "label", "Changed");
    leads.routes[0].id = "changed.home";
    leads.routes[0].path = "/changed";
    leads.routes.push({ id: "changed.other", path: "/other", label: "Other" });
    leads.requiredCapabilities.push("leads.read");
    leads.dependencies[0].moduleId = MODULE_IDS.projects;
    leads.dependencies.push({ moduleId: MODULE_IDS.reviews, optional: true });
    leads.setupSteps[0].label = "Changed";
    leads.setupSteps.push({ id: "other", label: "Other", required: false });
    leads.demo.fixtureId = "changed.demo";
    leads.healthChecks[0].label = "Changed";
    leads.healthChecks.push({ id: "other", label: "Other", severity: "warning" });

    expect(snapshot).toMatchObject({ id: MODULE_IDS.leads, label: MODULE_IDS.leads });
    expect(snapshot?.routes).toEqual([{ id: "growth.leads.home", path: "/leads", label: "Leads" }]);
    expect(snapshot?.requiredCapabilities).toEqual(["dashboard.read"]);
    expect(snapshot?.dependencies).toEqual([{ moduleId: MODULE_IDS.customers, optional: true }]);
    expect(snapshot?.setupSteps).toEqual([
      { id: "connect", label: "Connect", required: true, capability: "integrations.manage" },
    ]);
    expect(snapshot?.demo.fixtureId).toBe("growth.leads.demo");
    expect(snapshot?.healthChecks).toEqual([{ id: "ready", label: "Ready", severity: "info" }]);
    expect(registry.get(MODULE_IDS.leads)).toBe(snapshot);
    expect(registry.get(MODULE_IDS.customers)).toBeUndefined();
    expect(registry.routeOwner("/leads")).toBe(MODULE_IDS.leads);
    expect(registry.routeOwner("/changed")).toBeUndefined();
  });

  it("recursively freezes module snapshots and nested collections", () => {
    const leads = {
      ...module(MODULE_IDS.leads, "/leads"),
      dependencies: [{ moduleId: MODULE_IDS.customers, optional: true }],
      setupSteps: [{ id: "connect", label: "Connect", required: true }],
      healthChecks: [{ id: "ready", label: "Ready", severity: "info" as const }],
    } satisfies GrowthFeatureModule;
    const modules: GrowthFeatureModule[] = [leads];
    const registry = createFeatureRegistry(modules);
    const snapshot = registry.modules[0];
    modules.push(module(MODULE_IDS.customers, "/customers"));

    expect(Object.isFrozen(registry)).toBe(true);
    expect(Object.isFrozen(registry.modules)).toBe(true);
    expect(registry.modules).toHaveLength(1);
    expect(Object.isFrozen(snapshot)).toBe(true);
    expect(Object.isFrozen(snapshot.routes)).toBe(true);
    expect(Object.isFrozen(snapshot.routes[0])).toBe(true);
    expect(Object.isFrozen(snapshot.requiredCapabilities)).toBe(true);
    expect(Object.isFrozen(snapshot.dependencies)).toBe(true);
    expect(Object.isFrozen(snapshot.dependencies[0])).toBe(true);
    expect(Object.isFrozen(snapshot.setupSteps)).toBe(true);
    expect(Object.isFrozen(snapshot.setupSteps[0])).toBe(true);
    expect(Object.isFrozen(snapshot.demo)).toBe(true);
    expect(Object.isFrozen(snapshot.healthChecks)).toBe(true);
    expect(Object.isFrozen(snapshot.healthChecks[0])).toBe(true);
  });

  it("rejects entitlement mismatches and unsafe demo metadata", () => {
    expectRegistryError(
      () => createFeatureRegistry([{
        ...module(MODULE_IDS.leads, "/leads"),
        requiredEntitlement: MODULE_IDS.customers,
      }]),
      "ENTITLEMENT_MISMATCH",
      `ENTITLEMENT_MISMATCH: Module "${MODULE_IDS.leads}" requires entitlement "${MODULE_IDS.customers}" instead of its own id.`,
    );

    const unsafeModule = {
      ...module(MODULE_IDS.leads, "/leads"),
      demo: { fixtureId: "growth.leads.demo", allowMutations: true, allowsExternalEffects: true },
    } as unknown as GrowthFeatureModule;
    expectRegistryError(
      () => createFeatureRegistry([unsafeModule]),
      "UNSAFE_DEMO",
      `UNSAFE_DEMO: Module "${MODULE_IDS.leads}" allows external demo effects.`,
    );
  });

  it("uses deterministic validation precedence for fixtures with multiple errors", () => {
    const duplicateWithInvalidVersion = { ...module(MODULE_IDS.leads, "/first"), version: "invalid" };
    expectRegistryError(
      () => createFeatureRegistry([duplicateWithInvalidVersion, module(MODULE_IDS.leads, "/second")]),
      "DUPLICATE_MODULE",
      `DUPLICATE_MODULE: Module "${MODULE_IDS.leads}" is declared more than once.`,
    );

    expectRegistryError(
      () => createFeatureRegistry([
        { ...module(MODULE_IDS.leads, "/same"), version: "invalid" },
        module(MODULE_IDS.customers, "/same"),
      ]),
      "INVALID_VERSION",
      `INVALID_VERSION: Module "${MODULE_IDS.leads}" has invalid version "invalid".`,
    );

    const sharedRoute = { id: "shared.home", path: "/same", label: "Shared" };
    expectRegistryError(
      () => createFeatureRegistry([
        { ...module(MODULE_IDS.leads, "/leads"), routes: [sharedRoute] },
        { ...module(MODULE_IDS.customers, "/customers"), routes: [sharedRoute] },
      ]),
      "DUPLICATE_ROUTE",
      `DUPLICATE_ROUTE: Route path "/same" is declared more than once.`,
    );

    expectRegistryError(
      () => createFeatureRegistry([
        { ...module(MODULE_IDS.leads, "/leads"), routes: [{ ...sharedRoute, path: "/leads" }] },
        {
          ...module(MODULE_IDS.customers, "/customers"),
          routes: [{ ...sharedRoute, path: "/customers" }],
          requiredEntitlement: MODULE_IDS.projects,
        },
      ]),
      "DUPLICATE_ROUTE",
      `DUPLICATE_ROUTE: Route id "shared.home" is declared more than once.`,
    );

    const unsafeDemo = {
      fixtureId: "growth.leads.demo",
      allowMutations: true,
      allowsExternalEffects: true,
    } as unknown as GrowthFeatureModule["demo"];
    expectRegistryError(
      () => createFeatureRegistry([{
        ...module(MODULE_IDS.leads, "/leads"),
        requiredEntitlement: MODULE_IDS.customers,
        demo: unsafeDemo,
      }]),
      "ENTITLEMENT_MISMATCH",
      `ENTITLEMENT_MISMATCH: Module "${MODULE_IDS.leads}" requires entitlement "${MODULE_IDS.customers}" instead of its own id.`,
    );

    expectRegistryError(
      () => createFeatureRegistry([{
        ...module(MODULE_IDS.leads, "/leads", [MODULE_IDS.customers]),
        demo: unsafeDemo,
      }]),
      "UNSAFE_DEMO",
      `UNSAFE_DEMO: Module "${MODULE_IDS.leads}" allows external demo effects.`,
    );
  });

  it("keeps entitlement and demo safety contracts on valid modules", () => {
    const modules = [
      module(MODULE_IDS.leads, "/leads"),
      module(MODULE_IDS.customers, "/customers", [MODULE_IDS.leads]),
    ];
    const registry = createFeatureRegistry(modules);

    for (const featureModule of registry.modules) {
      expect(featureModule.requiredEntitlement).toBe(featureModule.id);
      expect(featureModule.demo.allowsExternalEffects).toBe(false);
    }
  });
});
