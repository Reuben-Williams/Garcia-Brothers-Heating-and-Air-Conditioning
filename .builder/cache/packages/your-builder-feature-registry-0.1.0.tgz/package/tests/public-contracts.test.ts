import { describe, expect, it } from "vitest";
import * as featureRegistry from "@your-builder/feature-registry";
import type {
  GrowthFeatureModule,
  FeatureRegistry,
  FeatureRegistryErrorCode,
  ModuleDemoDefinition,
  ModuleDependency,
  ModuleHealthCheck,
  ModuleRouteDefinition,
  ModuleSetupStep,
} from "@your-builder/feature-registry";

type IfEqual<X, Y, Then = true, Else = false> =
  (<T>() => T extends X ? 1 : 2) extends (<T>() => T extends Y ? 1 : 2) ? Then : Else;
type ReadonlyKeys<T> = {
  [Key in keyof T]-?: IfEqual<
    { [Field in Key]: T[Key] },
    { -readonly [Field in Key]: T[Key] },
    never,
    Key
  >;
}[keyof T];
type AllPropertiesReadonly<T> = IfEqual<ReadonlyKeys<T>, keyof T>;

describe("feature registry public contracts", () => {
  it("exports stable module IDs", () => {
    expect(featureRegistry.MODULE_IDS).toEqual({
      website: "core.website",
      dashboard: "growth.dashboard",
      leads: "growth.leads",
      customers: "growth.customers",
      messaging: "growth.messaging",
      automations: "growth.automations",
      reviews: "growth.reviews",
      projects: "growth.projects",
      ai: "growth.ai",
      chat: "growth.chat",
    });
    expect(Object.isFrozen(featureRegistry.MODULE_IDS)).toBe(true);
    expect(Reflect.set(featureRegistry.MODULE_IDS, "leads", "growth.typo")).toBe(false);
    expect(featureRegistry.MODULE_IDS.leads).toBe("growth.leads");
  });

  it("exports the registry runtime API from the package entry point", () => {
    expect(featureRegistry.createFeatureRegistry).toBeTypeOf("function");
    expect(featureRegistry.validateFeatureDependencies).toBeTypeOf("function");
    expect(featureRegistry.resolveFeatureDependencyOrder).toBeTypeOf("function");
    expect(featureRegistry.FeatureRegistryError).toBeTypeOf("function");
  });

  it("exports the named registry contract and error code union", () => {
    const errorCode: FeatureRegistryErrorCode = "UNSAFE_DEMO";
    const registry: FeatureRegistry = featureRegistry.createFeatureRegistry([]);
    const error = new featureRegistry.FeatureRegistryError(errorCode, "unsafe");

    expect(registry.modules).toEqual([]);
    expect(error.name).toBe("FeatureRegistryError");
    expect(error.code).toBe("UNSAFE_DEMO");
  });

  it("marks every module contract property readonly", () => {
    const readonlyContracts: [
      AllPropertiesReadonly<ModuleRouteDefinition>,
      AllPropertiesReadonly<ModuleDependency>,
      AllPropertiesReadonly<ModuleSetupStep>,
      AllPropertiesReadonly<ModuleDemoDefinition>,
      AllPropertiesReadonly<ModuleHealthCheck>,
      AllPropertiesReadonly<GrowthFeatureModule>,
    ] = [true, true, true, true, true, true];

    expect(readonlyContracts).toEqual([true, true, true, true, true, true]);
  });

  it("exposes the strict module metadata types", () => {
    const route: ModuleRouteDefinition = { id: "growth.leads.home", path: "/leads", label: "Leads" };
    const dependency: ModuleDependency = { moduleId: featureRegistry.MODULE_IDS.dashboard, optional: false };
    const setupStep: ModuleSetupStep = {
      id: "connect",
      label: "Connect",
      required: true,
      capability: "integrations.manage",
    };
    const demo: ModuleDemoDefinition = {
      fixtureId: "growth.leads.demo",
      allowMutations: true,
      allowsExternalEffects: false,
    };
    const healthCheck: ModuleHealthCheck = { id: "ready", label: "Ready", severity: "info" };
    const module: GrowthFeatureModule = {
      id: featureRegistry.MODULE_IDS.leads,
      version: "1.0.0",
      label: "Leads",
      description: "Leads",
      icon: "blocks",
      navigationGroup: "growth",
      routes: [route],
      requiredEntitlement: featureRegistry.MODULE_IDS.leads,
      requiredCapabilities: ["dashboard.read"],
      dependencies: [dependency],
      setupSteps: [setupStep],
      demo,
      healthChecks: [healthCheck],
      mobileNavigationPriority: 1,
    };

    expect(module.demo.allowsExternalEffects).toBe(false);
    expect(module.requiredEntitlement).toBe(module.id);
  });
});
