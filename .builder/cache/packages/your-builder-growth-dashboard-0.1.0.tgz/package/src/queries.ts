import type { DashboardFact } from "./facts.js";

export interface DashboardFactsQuery {
  readonly siteId: string;
  readonly actorId: string;
  readonly asOf: string;
}

export interface DashboardFactsSnapshot {
  readonly siteId: string;
  readonly generatedAt: string;
  readonly facts: readonly DashboardFact[];
}

export type DashboardFactAccess<T> = { readonly status: "allowed" } & T | { readonly status: "restricted" };

export interface DashboardFactsProjection {
  readonly leads: DashboardFactAccess<{ readonly newCount: number; readonly agingCount: number; readonly unassignedCount: number }>;
  readonly customers: DashboardFactAccess<{ readonly activeCount: number; readonly recentActivityCount: number }>;
  readonly tasks: DashboardFactAccess<{ readonly dueTodayCount: number; readonly overdueCount: number }>;
  readonly notifications: DashboardFactAccess<{ readonly unreadCount: number }>;
  readonly baseSubmissions: DashboardFactAccess<{ readonly recentCount: number; readonly spamReviewCount: number }>;
  readonly health: DashboardFactAccess<{ readonly items: readonly DashboardHealthProjection[] }>;
}

export interface DashboardHealthProjection {
  readonly checkKind: string;
  readonly status: string;
  readonly observedVersion?: string;
  readonly queueAgeSeconds?: number;
  readonly snapshotAgeSeconds?: number;
  readonly safeCode?: string;
  readonly observedAt: string;
}

export interface DashboardFactsRepository {
  readonly query: (input: DashboardFactsQuery) => Promise<DashboardFactsSnapshot>;
}
