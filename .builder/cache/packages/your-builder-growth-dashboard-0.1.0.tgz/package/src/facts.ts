import type { BuilderRole } from "@your-builder/core";
import { MODULE_IDS, type GrowthModuleId } from "@your-builder/feature-registry";

export type DashboardSafeModuleState =
  | "available"
  | "requested"
  | "request_withdrawn"
  | "trialing"
  | "trial_expired"
  | "provisioning"
  | "provisioning_error"
  | "setup_required"
  | "active"
  | "payment_attention"
  | "grace_period"
  | "suspended"
  | "offboarding"
  | "termination_failed"
  | "terminated"
  | "unavailable";

export interface DashboardLeadAgingBucket {
  readonly minimumAgeDays: number;
  readonly maximumAgeDays: number | null;
  readonly count: number;
}

export type DashboardFact =
  | {
      readonly kind: "lead_aging";
      readonly domain: "leads";
      readonly buckets: readonly DashboardLeadAgingBucket[];
    }
  | {
      readonly kind: "unassigned_leads";
      readonly domain: "leads";
      readonly count: number;
    }
  | {
      readonly kind: "task_deadlines";
      readonly domain: "leads";
      readonly dueCount: number;
      readonly overdueCount: number;
    }
  | {
      readonly kind: "customer_activity";
      readonly domain: "customers";
      readonly activeCount: number;
    }
  | {
      readonly kind: "module_health";
      readonly domain: "dashboard";
      readonly warningCount: number;
      readonly criticalCount: number;
    }
  | {
      readonly kind: "notification_count";
      readonly domain: "dashboard";
      readonly unreadCount: number;
    }
  | {
      readonly kind: "base_inbox";
      readonly domain: "base_submissions";
      readonly newCount: number;
      readonly spamReviewCount: number;
    };

export interface DashboardAccessProjection {
  readonly effectiveRead: boolean;
  readonly hasCapability: boolean;
}

export interface DashboardDomainAccessProjection {
  readonly effectiveRead: boolean;
  readonly hasRecordCapability: boolean;
  readonly state: DashboardSafeModuleState;
}

export interface GateDashboardFactInput {
  readonly fact: DashboardFact;
  readonly actorRole: BuilderRole;
  readonly dashboard: DashboardAccessProjection;
  readonly domain?: DashboardDomainAccessProjection;
}

export type DashboardFactGateResult =
  | { readonly kind: "fact"; readonly fact: DashboardFact }
  | { readonly kind: "dashboard_restricted" }
  | { readonly kind: "base_role_restricted" }
  | {
      readonly kind: "module_state";
      readonly moduleId: Extract<GrowthModuleId, "growth.customers" | "growth.leads">;
      readonly state: DashboardSafeModuleState;
    };

function domainModuleId(
  domain: Extract<DashboardFact["domain"], "customers" | "leads">,
): Extract<GrowthModuleId, "growth.customers" | "growth.leads"> {
  return domain === "customers" ? MODULE_IDS.customers : MODULE_IDS.leads;
}

export function gateDashboardFact(input: GateDashboardFactInput): DashboardFactGateResult {
  if (!input.dashboard.effectiveRead || !input.dashboard.hasCapability) {
    return { kind: "dashboard_restricted" };
  }

  if (input.fact.domain === "base_submissions") {
    return input.actorRole === "owner" || input.actorRole === "editor"
      ? { kind: "fact", fact: input.fact }
      : { kind: "base_role_restricted" };
  }

  if (input.fact.domain === "customers" || input.fact.domain === "leads") {
    if (!input.domain?.effectiveRead || !input.domain.hasRecordCapability) {
      return {
        kind: "module_state",
        moduleId: domainModuleId(input.fact.domain),
        state: input.domain?.state ?? "unavailable",
      };
    }
  }

  return { kind: "fact", fact: input.fact };
}
