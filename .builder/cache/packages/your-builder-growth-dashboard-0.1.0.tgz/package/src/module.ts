import {
  MODULE_IDS,
  type GrowthFeatureModule,
} from "@your-builder/feature-registry";

export const GROWTH_DASHBOARD_MODULE = Object.freeze({
  id: MODULE_IDS.dashboard,
  version: "2.0.0",
  label: "Dashboard",
  description: "Operational growth facts and module health.",
  icon: "layout-dashboard",
  navigationGroup: "growth",
  routes: [{
    id: "growth.dashboard.home",
    path: "/admin/editor/dashboard",
    label: "Dashboard",
  }],
  requiredEntitlement: MODULE_IDS.dashboard,
  requiredCapabilities: ["dashboard.read"],
  dependencies: [
    { moduleId: MODULE_IDS.customers, optional: false },
    { moduleId: MODULE_IDS.leads, optional: false },
  ],
  setupSteps: [],
  demo: {
    fixtureId: "growth.dashboard.demo.v2",
    allowMutations: false,
    allowsExternalEffects: false,
  },
  healthChecks: [
    { id: "entitlement-snapshot", label: "Entitlement snapshot", severity: "critical" },
    { id: "growth-queue", label: "Growth queue", severity: "warning" },
  ],
  mobileNavigationPriority: 1,
} as const satisfies GrowthFeatureModule);
