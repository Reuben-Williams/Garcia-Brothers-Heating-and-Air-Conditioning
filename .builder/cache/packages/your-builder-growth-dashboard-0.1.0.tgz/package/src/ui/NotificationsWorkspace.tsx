"use client";

import { useEffect, useMemo, useState } from "react";
import { Bell, Check } from "lucide-react";
import {
  AsyncStatus,
  DemoBanner,
  ResponsiveCollection,
  StatusBadge,
  WorkspaceHeader,
  WorkspaceState,
} from "@your-builder/editor";
import styles from "./operational-workspaces.module.css";

export type NotificationsWorkspaceMode =
  | "demo"
  | "operational"
  | "read_only"
  | "loading"
  | "error"
  | "denied";

export type NotificationsView = "all" | "unread";

export interface NotificationRecord {
  readonly id: string;
  readonly eventType: string;
  readonly resourceType?: "lead" | "customer" | "task";
  readonly resourceId?: string;
  readonly previewText: string;
  readonly createdAt: string;
  readonly readAt?: string;
}

export interface NotificationsPage {
  readonly items: readonly NotificationRecord[];
  readonly unreadCount: number;
  readonly nextCursor?: string;
}

export interface NotificationsUrlState {
  readonly view: NotificationsView;
  readonly cursor?: string;
}

export type MarkNotificationReadResult =
  | { readonly status: "applied" }
  | { readonly status: "already_read" }
  | { readonly status: "denied"; readonly reason: string };

export interface NotificationsApi {
  readonly list: (input: {
    readonly view: NotificationsView;
    readonly cursor?: string;
    readonly limit: number;
  }) => Promise<NotificationsPage>;
  readonly markRead: (input: { readonly notificationId: string }) => Promise<MarkNotificationReadResult>;
}

export interface NotificationsWorkspaceProps {
  readonly mode: NotificationsWorkspaceMode;
  readonly initialPage?: NotificationsPage;
  readonly urlState: NotificationsUrlState;
  readonly api: NotificationsApi;
  readonly errorMessage?: string;
  readonly onUrlStateChange?: (state: NotificationsUrlState) => void;
  readonly onUnreadCountChange?: (count: number) => void;
  readonly onResetDemo?: () => void;
}

export const NOTIFICATIONS_DEMO_PAGE = Object.freeze({
  items: Object.freeze([
    {
      id: "demo-notification-1",
      eventType: "submission.received",
      previewText: "New website inquiry",
      createdAt: "2026-07-18T12:45:00.000Z",
    },
    {
      id: "demo-notification-2",
      eventType: "task.due",
      resourceType: "task",
      resourceId: "demo-task-1",
      previewText: "A follow-up task is due today",
      createdAt: "2026-07-18T11:30:00.000Z",
    },
  ]),
  unreadCount: 2,
} as const satisfies NotificationsPage);

export function createNotificationsDemoApi(): NotificationsApi {
  let items: NotificationRecord[] = NOTIFICATIONS_DEMO_PAGE.items.map((item) => ({ ...item }));
  return {
    list: async ({ view }) => ({
      items: view === "unread" ? items.filter((item) => !item.readAt) : items,
      unreadCount: items.filter((item) => !item.readAt).length,
    }),
    markRead: async ({ notificationId }) => {
      const current = items.find((item) => item.id === notificationId);
      if (!current) return { status: "denied", reason: "not_found" };
      if (current.readAt) return { status: "already_read" };
      const readAt = "2026-07-18T13:00:00.000Z";
      items = items.map((item) => item.id === notificationId
        ? { ...item, readAt }
        : item);
      return { status: "applied" };
    },
  };
}

function demoPage(): NotificationsPage {
  return { items: NOTIFICATIONS_DEMO_PAGE.items.map((item) => ({ ...item })), unreadCount: NOTIFICATIONS_DEMO_PAGE.unreadCount };
}

function dateLabel(value: string) {
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(new Date(value));
}

function NotificationRow({
  item,
  readOnly,
  pending,
  onMarkRead,
}: {
  readonly item: NotificationRecord;
  readonly readOnly: boolean;
  readonly pending: boolean;
  readonly onMarkRead: (item: NotificationRecord) => void;
}) {
  return (
    <div className={styles.notificationRow} data-builder-notification-id={item.id} data-notification-read={item.readAt ? "true" : "false"}>
      <span className={styles.notificationIcon}><Bell size={18} aria-hidden="true" /></span>
      <div className={styles.rowCopy}>
        <strong>{item.previewText}</strong>
        <span>{item.resourceType?.replaceAll("_", " ") ?? item.eventType.replaceAll(".", " ")}</span>
      </div>
      <time dateTime={item.createdAt}>{dateLabel(item.createdAt)}</time>
      <StatusBadge tone={item.readAt ? "neutral" : "info"}>{item.readAt ? "Read" : "Unread"}</StatusBadge>
      {!readOnly && !item.readAt ? (
        <button type="button" className={styles.secondaryButton} disabled={pending} onClick={() => onMarkRead(item)}>
          <Check size={17} aria-hidden="true" />
          {pending ? "Marking..." : "Mark read"}
        </button>
      ) : null}
    </div>
  );
}

export function NotificationsWorkspace(props: NotificationsWorkspaceProps) {
  const startingPage = props.mode === "demo" ? demoPage() : props.initialPage;
  const [items, setItems] = useState<readonly NotificationRecord[]>(startingPage?.items ?? []);
  const [unreadCount, setUnreadCount] = useState(startingPage?.unreadCount ?? 0);
  const [nextCursor, setNextCursor] = useState(startingPage?.nextCursor);
  const [loading, setLoading] = useState(props.mode === "loading" || (props.mode === "operational" && !props.initialPage));
  const [pendingId, setPendingId] = useState<string>();
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const readOnly = props.mode === "read_only";

  const visibleItems = useMemo(() => props.urlState.view === "unread"
    ? items.filter((item) => !item.readAt)
    : items, [items, props.urlState.view]);

  useEffect(() => {
    if (props.mode !== "operational" || props.initialPage) return;
    let active = true;
    setLoading(true);
    void props.api.list({
      view: props.urlState.view,
      cursor: props.urlState.cursor,
      limit: 25,
    }).then((page) => {
      if (!active) return;
      setItems(page.items);
      setUnreadCount(page.unreadCount);
      setNextCursor(page.nextCursor);
      props.onUnreadCountChange?.(page.unreadCount);
    }).catch(() => active && setError("Notifications could not be loaded. Try again.")).finally(() => active && setLoading(false));
    return () => { active = false; };
  }, [props.api, props.initialPage, props.mode, props.urlState.cursor, props.urlState.view]);

  async function refreshPage() {
    const page = await props.api.list({ view: props.urlState.view, cursor: undefined, limit: 25 });
    setItems(page.items);
    setUnreadCount(page.unreadCount);
    setNextCursor(page.nextCursor);
    props.onUnreadCountChange?.(page.unreadCount);
  }

  async function markRead(item: NotificationRecord) {
    setPendingId(item.id);
    setMessage("");
    setError("");
    try {
      const result = await props.api.markRead({ notificationId: item.id });
      if (result.status === "applied" || result.status === "already_read") {
        await refreshPage();
        setMessage(result.status === "applied" ? "Notification marked read." : "Notification was already read.");
      } else {
        setMessage("You no longer have permission to mark this notification read.");
      }
    } catch {
      setError("The notification could not be updated. Try again.");
    } finally {
      setPendingId(undefined);
    }
  }

  async function loadMore() {
    if (!nextCursor) return;
    setLoading(true);
    setError("");
    try {
      const page = await props.api.list({
        view: props.urlState.view,
        cursor: nextCursor,
        limit: 25,
      });
      const incoming = page.items;
      setItems((current) => {
        const byId = new Map(current.map((item) => [item.id, item]));
        incoming.forEach((item) => byId.set(item.id, item));
        return [...byId.values()];
      });
      setUnreadCount(page.unreadCount);
      setNextCursor(page.nextCursor);
      props.onUnreadCountChange?.(page.unreadCount);
      props.onUrlStateChange?.({ ...props.urlState, cursor: page.nextCursor });
    } catch {
      setError("More notifications could not be loaded. Try again.");
    } finally {
      setLoading(false);
    }
  }

  if (props.mode === "denied") {
    return <section className={styles.workspace} data-builder-notifications-workspace data-notifications-mode="denied"><WorkspaceState kind="denied" title="Notifications access is not available" description="Your current role does not include this workspace." /></section>;
  }
  if (props.mode === "error") {
    return <section className={styles.workspace} data-builder-notifications-workspace data-notifications-mode="error"><WorkspaceState kind="error" title="Notifications are temporarily unavailable" description={props.errorMessage ?? "Try again shortly."} /></section>;
  }

  const collection = visibleItems.length > 0 ? (
    <ResponsiveCollection
      desktop={<div className={styles.notificationList} data-notifications-list="desktop">{visibleItems.map((item) => <NotificationRow key={item.id} item={item} readOnly={readOnly} pending={pendingId === item.id} onMarkRead={(record) => void markRead(record)} />)}</div>}
      mobile={<div className={styles.notificationList} data-notifications-list="mobile">{visibleItems.map((item) => <NotificationRow key={item.id} item={item} readOnly={readOnly} pending={pendingId === item.id} onMarkRead={(record) => void markRead(record)} />)}</div>}
    />
  ) : <WorkspaceState kind="empty" title="No notifications yet" description="Current in-app activity will appear here." />;

  return (
    <section className={styles.workspace} data-builder-notifications-workspace data-notifications-mode={props.mode}>
      <WorkspaceHeader eyebrow="Dashboard" title="Notifications" description="In-app updates for your current work." status={readOnly ? "Read-only access" : `${unreadCount} unread`} />
      {props.mode === "demo" ? <DemoBanner moduleName="Notifications" onReset={props.onResetDemo ?? (() => undefined)} /> : null}
      <AsyncStatus message={error || message} assertive={Boolean(error)} />
      <div className={styles.segmentedControl} aria-label="Notification view">
        {(["all", "unread"] as const).map((view) => <button key={view} type="button" aria-pressed={props.urlState.view === view} onClick={() => props.onUrlStateChange?.({ view, cursor: undefined })}>{view === "all" ? "All" : "Unread"}</button>)}
      </div>
      {loading && items.length === 0 ? <WorkspaceState kind="loading" title="Loading notifications" /> : collection}
      {nextCursor ? <button type="button" className={styles.loadMoreButton} disabled={loading} onClick={() => void loadMore()}>{loading ? "Loading..." : "Load more"}</button> : null}
    </section>
  );
}
