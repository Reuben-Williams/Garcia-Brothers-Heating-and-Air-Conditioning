import type { DashboardFactsSnapshot } from "../index.js";

export const DASHBOARD_DEMO_SNAPSHOT = Object.freeze({
  siteId: "dashboard-demo",
  generatedAt: "2026-07-18T13:00:00.000Z",
  facts: Object.freeze([
    {
      kind: "lead_aging",
      domain: "leads",
      buckets: Object.freeze([
        { minimumAgeDays: 0, maximumAgeDays: 2, count: 8 },
        { minimumAgeDays: 3, maximumAgeDays: 6, count: 3 },
        { minimumAgeDays: 7, maximumAgeDays: null, count: 1 },
      ]),
    },
    { kind: "unassigned_leads", domain: "leads", count: 3 },
    { kind: "task_deadlines", domain: "leads", dueCount: 5, overdueCount: 1 },
    { kind: "customer_activity", domain: "customers", activeCount: 18 },
    { kind: "module_health", domain: "dashboard", warningCount: 1, criticalCount: 0 },
    { kind: "notification_count", domain: "dashboard", unreadCount: 2 },
    { kind: "base_inbox", domain: "base_submissions", newCount: 4, spamReviewCount: 1 },
  ]),
} as const satisfies DashboardFactsSnapshot);
