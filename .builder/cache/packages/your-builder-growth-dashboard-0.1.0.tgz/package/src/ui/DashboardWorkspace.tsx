"use client";

import {
  AlertTriangle,
  ArrowRight,
  Bell,
  CheckCircle2,
  ClipboardCheck,
  ContactRound,
  HeartPulse,
  Inbox,
  Users,
} from "lucide-react";
import type { ComponentType } from "react";
import { DemoBanner, WorkspaceHeader } from "@your-builder/editor";
import {
  gateDashboardFact,
  type DashboardFact,
  type DashboardFactGateResult,
} from "../index.js";
import { DASHBOARD_DEMO_SNAPSHOT } from "./demo.js";
import type {
  DashboardDestination,
  DashboardWorkspaceProps,
} from "./types.js";
import styles from "./dashboard-workspace.module.css";

type FactIcon = ComponentType<{ size?: number; "aria-hidden"?: "true" }>;

const factIcons: Readonly<Record<DashboardFact["kind"], FactIcon>> = {
  lead_aging: ContactRound,
  unassigned_leads: Users,
  task_deadlines: ClipboardCheck,
  customer_activity: Users,
  module_health: HeartPulse,
  notification_count: Bell,
  base_inbox: Inbox,
};

const factDestinations: Readonly<Record<DashboardFact["kind"], DashboardDestination>> = {
  lead_aging: "leads",
  unassigned_leads: "leads",
  task_deadlines: "leads",
  customer_activity: "customers",
  module_health: "health",
  notification_count: "notifications",
  base_inbox: "submissions",
};

const destinationLabels: Readonly<Record<DashboardDestination, string>> = {
  leads: "View leads",
  customers: "View customers",
  submissions: "View submissions",
  notifications: "View notifications",
  health: "View site health",
};

function factValue(fact: DashboardFact): string {
  switch (fact.kind) {
    case "lead_aging":
      return `${fact.buckets.reduce((total, bucket) => total + bucket.count, 0)} open leads`;
    case "unassigned_leads":
      return `${fact.count} unassigned`;
    case "task_deadlines":
      return `${fact.dueCount} due today`;
    case "customer_activity":
      return `${fact.activeCount} active customers`;
    case "module_health":
      return fact.criticalCount > 0
        ? `${fact.criticalCount} critical`
        : `${fact.warningCount} warning${fact.warningCount === 1 ? "" : "s"}`;
    case "notification_count":
      return `${fact.unreadCount} unread`;
    case "base_inbox":
      return `${fact.newCount} new submissions`;
  }
}

function factDetail(fact: DashboardFact): string {
  switch (fact.kind) {
    case "lead_aging": {
      const oldest = fact.buckets.at(-1);
      return oldest && oldest.count > 0
        ? `${oldest.count} need aging follow-up`
        : "No aging follow-up needed";
    }
    case "unassigned_leads":
      return "Ready for assignment";
    case "task_deadlines":
      return `${fact.overdueCount} overdue`;
    case "customer_activity":
      return "Recent authorized activity";
    case "module_health":
      return fact.criticalCount === 0 ? "No critical issues" : "Review required";
    case "notification_count":
      return "In-app updates";
    case "base_inbox":
      return `${fact.spamReviewCount} awaiting spam review`;
  }
}

function domainAccess(props: DashboardWorkspaceProps, fact: DashboardFact) {
  if (fact.domain === "leads") return props.access.leads;
  if (fact.domain === "customers") return props.access.customers;
  return undefined;
}

function gateFacts(props: DashboardWorkspaceProps): readonly DashboardFactGateResult[] {
  const snapshot = props.mode === "demo" ? DASHBOARD_DEMO_SNAPSHOT : props.snapshot;
  if (!snapshot) return [];
  return snapshot.facts.map((fact) => gateDashboardFact({
    fact,
    actorRole: props.actorRole,
    dashboard: props.access.dashboard,
    ...(domainAccess(props, fact) ? { domain: domainAccess(props, fact) } : {}),
  }));
}

function FactRow({
  fact,
  onNavigate,
}: {
  fact: DashboardFact;
  onNavigate: DashboardWorkspaceProps["onNavigate"];
}) {
  const Icon = factIcons[fact.kind];
  const destination = factDestinations[fact.kind];
  return (
    <article className={styles.fact} data-dashboard-fact={fact.kind}>
      <div className={styles.factIcon}><Icon size={19} aria-hidden="true" /></div>
      <div className={styles.factCopy}>
        <strong>{factValue(fact)}</strong>
        <span>{factDetail(fact)}</span>
      </div>
      <button type="button" className={styles.factAction} onClick={() => onNavigate(destination)}>
        <span>{destinationLabels[destination]}</span>
        <ArrowRight size={17} aria-hidden="true" />
      </button>
    </article>
  );
}

function WorkspaceMessage({
  kind,
  title,
  message,
}: {
  kind: "loading" | "error" | "denied" | "empty";
  title: string;
  message: string;
}) {
  const Icon = kind === "error" || kind === "denied" ? AlertTriangle : CheckCircle2;
  return (
    <section className={styles.state} data-dashboard-state={kind} role={kind === "error" ? "alert" : "status"}>
      <Icon size={22} aria-hidden="true" />
      <div><h3>{title}</h3><p>{message}</p></div>
    </section>
  );
}

export function DashboardWorkspace(props: DashboardWorkspaceProps) {
  const gatedFacts = props.mode === "denied" ? [] : gateFacts(props);
  const facts = gatedFacts.flatMap((result) => result.kind === "fact" ? [result.fact] : []);
  const restrictions = [...new Map(gatedFacts.flatMap((result) => result.kind === "module_state"
    ? [[result.moduleId, result] as const]
    : [])).values()];

  return (
    <section
      className={styles.workspace}
      data-builder-dashboard-workspace
      data-dashboard-mode={props.mode}
    >
      <WorkspaceHeader
        eyebrow="Growth"
        title="Dashboard"
        description="Current work, follow-up, and module health."
        status={props.mode === "read_only" ? "Read-only access" : undefined}
      />
      {props.mode === "demo" ? <DemoBanner moduleName="Dashboard" onReset={props.onResetDemo} /> : null}
      {props.mode === "loading" ? (
        <WorkspaceMessage kind="loading" title="Loading dashboard" message="Preparing current operational facts." />
      ) : null}
      {props.mode === "error" ? (
        <WorkspaceMessage kind="error" title="Dashboard unavailable" message={props.errorMessage ?? "Try again shortly."} />
      ) : null}
      {props.mode === "denied" ? (
        <WorkspaceMessage kind="denied" title="Dashboard access is not available" message="Your current role does not include this workspace." />
      ) : null}
      {restrictions.map((restriction) => (
        <section
          key={restriction.moduleId}
          className={styles.restriction}
          data-dashboard-module-restriction={restriction.moduleId}
        >
          <AlertTriangle size={19} aria-hidden="true" />
          <div>
            <strong>{restriction.moduleId === "growth.leads" ? "Leads" : "Customers"} is currently {restriction.state.replaceAll("_", " ")}</strong>
            <span>Other authorized dashboard facts remain available.</span>
          </div>
        </section>
      ))}
      {props.mode !== "loading" && props.mode !== "error" && props.mode !== "denied" ? (
        facts.length > 0 ? (
          <div className={styles.facts} aria-label="Operational facts">
            {facts.map((fact) => <FactRow key={fact.kind} fact={fact} onNavigate={props.onNavigate} />)}
          </div>
        ) : (
          <WorkspaceMessage kind="empty" title="No current work" message="New operational activity will appear here." />
        )
      ) : null}
    </section>
  );
}
