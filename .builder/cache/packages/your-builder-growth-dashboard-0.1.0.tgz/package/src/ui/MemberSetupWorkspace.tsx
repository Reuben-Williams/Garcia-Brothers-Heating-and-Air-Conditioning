"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { Clipboard, UserPlus } from "lucide-react";
import type {
  BuilderRole,
  GrowthInvitationTemplateId,
  MemberInvitationStatus,
} from "@your-builder/core";
import {
  AsyncStatus,
  DemoBanner,
  DestructiveActionGuard,
  ResponsiveCollection,
  StatusBadge,
  WorkspaceHeader,
  WorkspaceState,
} from "@your-builder/editor";
import styles from "./operational-workspaces.module.css";

export type MemberSetupWorkspaceMode =
  | "demo"
  | "operational"
  | "read_only"
  | "loading"
  | "error"
  | "denied";

export interface InvitationDeliveryHandoff {
  readonly invitationId: string;
  readonly token: string;
}

export interface MemberInvitationRecord {
  readonly id: string;
  readonly templateId: GrowthInvitationTemplateId;
  readonly templateVersion: number;
  readonly state: MemberInvitationStatus;
  readonly invitedBy: string;
  readonly acceptedBy?: string;
  readonly expiresAt: string;
  readonly createdAt: string;
  readonly acceptedAt?: string;
  readonly revokedAt?: string;
  readonly version: number;
  readonly updatedAt: string;
}

export interface MemberInvitationPage {
  readonly items: readonly MemberInvitationRecord[];
  readonly nextCursor?: string;
}

export type CreateMemberInvitationResult =
  | { readonly result: "applied"; readonly invitation: { readonly id: string; readonly token: string }; readonly version?: number; readonly replayed: boolean }
  | { readonly result: "recent_aal2_required" }
  | { readonly result: "denied"; readonly code: "OPERATION_DENIED" }
  | { readonly result: "conflict"; readonly expectedVersion?: number; readonly actualVersion?: number };

export type RevokeMemberInvitationResult =
  | { readonly result: "applied"; readonly resource: { readonly type: "member_invitation"; readonly id: string }; readonly version?: number; readonly replayed: boolean }
  | { readonly result: "recent_aal2_required" }
  | { readonly result: "denied"; readonly code: "OPERATION_DENIED" }
  | { readonly result: "conflict"; readonly expectedVersion?: number; readonly actualVersion?: number };

export interface MemberSetupApi {
  readonly list: () => Promise<MemberInvitationPage>;
  readonly create: (input: {
    readonly email: string;
    readonly templateId: GrowthInvitationTemplateId;
  }) => Promise<CreateMemberInvitationResult>;
  readonly revoke: (input: {
    readonly invitationId: string;
    readonly expectedVersion: number;
    readonly reason: string;
  }) => Promise<RevokeMemberInvitationResult>;
}

export interface MemberSetupWorkspaceProps {
  readonly mode: MemberSetupWorkspaceMode;
  readonly actorRole: BuilderRole;
  readonly initialInvitations?: readonly MemberInvitationRecord[];
  readonly api: MemberSetupApi;
  readonly errorMessage?: string;
  readonly onRequestAal2: () => void;
  readonly onResetDemo?: () => void;
}

export const MEMBER_SETUP_TEMPLATES = Object.freeze([
  { id: "growth_manager_v1", label: "Manager" },
  { id: "growth_staff_v1", label: "Staff" },
  { id: "growth_read_only_v1", label: "Read-only" },
] as const satisfies readonly { readonly id: GrowthInvitationTemplateId; readonly label: string }[]);

export const MEMBER_SETUP_DEMO_INVITATIONS = Object.freeze([
  {
    id: "demo-invitation-1",
    templateId: "growth_manager_v1",
    templateVersion: 1,
    state: "pending",
    invitedBy: "demo-owner",
    expiresAt: "2026-07-25T13:00:00.000Z",
    createdAt: "2026-07-18T13:00:00.000Z",
    version: 1,
    updatedAt: "2026-07-18T13:00:00.000Z",
  },
] as const satisfies readonly MemberInvitationRecord[]);

export function createMemberSetupDemoApi(): MemberSetupApi {
  let invitations: readonly MemberInvitationRecord[] = MEMBER_SETUP_DEMO_INVITATIONS.map((item) => ({ ...item }));
  return {
    list: async () => ({ items: invitations }),
    create: async ({ templateId }) => {
      const invitation: MemberInvitationRecord = {
        id: `demo-invitation-${invitations.length + 1}`,
        templateId,
        templateVersion: 1,
        state: "pending",
        invitedBy: "demo-owner",
        expiresAt: "2026-07-25T13:00:00.000Z",
        createdAt: "2026-07-18T13:00:00.000Z",
        version: 1,
        updatedAt: "2026-07-18T13:00:00.000Z",
      };
      invitations = [invitation, ...invitations];
      return {
        result: "applied",
        invitation: { id: invitation.id, token: `demo-delivery-token-${invitations.length}` },
        version: invitation.version,
        replayed: false,
      };
    },
    revoke: async ({ invitationId, expectedVersion }) => {
      const current = invitations.find((item) => item.id === invitationId);
      if (!current || current.version !== expectedVersion) {
        return { result: "conflict", expectedVersion, actualVersion: current?.version };
      }
      const invitation: MemberInvitationRecord = {
        ...current,
        state: "revoked",
        revokedAt: "2026-07-18T14:00:00.000Z",
        version: current.version + 1,
        updatedAt: "2026-07-18T14:00:00.000Z",
      };
      invitations = invitations.map((item) => item.id === invitationId ? invitation : item);
      return { result: "applied", resource: { type: "member_invitation", id: invitation.id }, version: invitation.version, replayed: false };
    },
  };
}

function templateLabel(templateId: GrowthInvitationTemplateId) {
  return MEMBER_SETUP_TEMPLATES.find((template) => template.id === templateId)?.label ?? "Read-only";
}

function statusTone(status: MemberInvitationRecord["state"]) {
  if (status === "accepted") return "success" as const;
  if (status === "pending") return "info" as const;
  if (status === "expired") return "warning" as const;
  return "neutral" as const;
}

function invitationDate(value: string) {
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", year: "numeric" }).format(new Date(value));
}

function InvitationRow({
  invitation,
  readOnly,
  onRevoke,
}: {
  readonly invitation: MemberInvitationRecord;
  readonly readOnly: boolean;
  readonly onRevoke: (invitation: MemberInvitationRecord, reason: string) => Promise<void>;
}) {
  const canRevoke = invitation.state === "pending" && !readOnly;
  return (
    <div className={styles.invitationRow} data-builder-member-invitation-id={invitation.id}>
      <div className={styles.rowCopy}>
        <strong>Invitation {invitation.id}</strong>
        <span>Created {invitationDate(invitation.createdAt)}</span>
      </div>
      <span>{templateLabel(invitation.templateId)}</span>
      <StatusBadge tone={statusTone(invitation.state)}>{invitation.state[0]!.toUpperCase() + invitation.state.slice(1)}</StatusBadge>
      <span>Expires {invitationDate(invitation.expiresAt)}</span>
      {canRevoke ? (
        <DestructiveActionGuard
          triggerLabel="Revoke"
          title="Revoke invitation"
          description={`Revoke pending invitation ${invitation.id}?`}
          confirmLabel="Revoke invitation"
          reasonLabel="Reason for revocation"
          requireReason
          triggerAttributes={{ "data-member-invitation-revoke": invitation.id }}
          onConfirm={(reason) => onRevoke(invitation, reason ?? "")}
        />
      ) : <span />}
    </div>
  );
}

export function MemberSetupWorkspace(props: MemberSetupWorkspaceProps) {
  const ownerAuthorized = props.actorRole === "owner" && props.mode !== "denied";
  const startingInvitations = props.mode === "demo" ? MEMBER_SETUP_DEMO_INVITATIONS : props.initialInvitations;
  const [invitations, setInvitations] = useState<readonly MemberInvitationRecord[]>(startingInvitations ?? []);
  const [loading, setLoading] = useState(props.mode === "loading" || (props.mode === "operational" && !props.initialInvitations));
  const [email, setEmail] = useState("");
  const [templateId, setTemplateId] = useState<GrowthInvitationTemplateId>("growth_manager_v1");
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [aal2Required, setAal2Required] = useState(false);
  const [delivery, setDelivery] = useState<InvitationDeliveryHandoff>();
  const consumedDeliveryIds = useRef(new Set<string>());
  const readOnly = props.mode === "read_only";

  useEffect(() => {
    if (!ownerAuthorized || props.mode !== "operational" || props.initialInvitations) return;
    let active = true;
    setLoading(true);
    void props.api.list().then((page) => active && setInvitations(page.items)).catch(() => active && setError("Member invitations could not be loaded. Try again.")).finally(() => active && setLoading(false));
    return () => { active = false; };
  }, [ownerAuthorized, props.api, props.initialInvitations, props.mode]);

  function requireAal2() {
    setAal2Required(true);
    setMessage("A recent identity verification is required before managing invitations.");
  }

  async function refreshInvitations() {
    const page = await props.api.list();
    setInvitations(page.items);
  }

  async function createInvitation(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (readOnly || pending) return;
    setPending(true);
    setMessage("");
    setError("");
    setAal2Required(false);
    try {
      const result = await props.api.create({ email: email.trim(), templateId });
      if (result.result === "applied") {
        setEmail("");
        setMessage("Invitation created.");
        if (!result.replayed && !consumedDeliveryIds.current.has(result.invitation.id)) {
          consumedDeliveryIds.current.add(result.invitation.id);
          setDelivery({ invitationId: result.invitation.id, token: result.invitation.token });
        }
        await refreshInvitations();
      } else if (result.result === "recent_aal2_required") requireAal2();
      else if (result.result === "conflict") setMessage("This invitation request conflicted with a newer operation. Try again.");
      else setMessage("You no longer have permission to create invitations.");
    } catch {
      setError("The invitation could not be created. Try again.");
    } finally {
      setPending(false);
    }
  }

  async function revokeInvitation(invitation: MemberInvitationRecord, reason: string) {
    setMessage("");
    setError("");
    setAal2Required(false);
    const result = await props.api.revoke({ invitationId: invitation.id, expectedVersion: invitation.version, reason });
    if (result.result === "applied") {
      await refreshInvitations();
      setMessage("Invitation revoked.");
    } else if (result.result === "recent_aal2_required") requireAal2();
    else if (result.result === "conflict") setMessage("This invitation changed elsewhere. Refresh and try again.");
    else setMessage("You no longer have permission to revoke this invitation.");
  }

  if (!ownerAuthorized) {
    return <section className={styles.workspace} data-builder-member-setup-workspace data-member-setup-mode="denied"><WorkspaceState kind="denied" title="Member setup is owner-only" description="Only the site owner can create or revoke member invitations." /></section>;
  }
  if (props.mode === "error") {
    return <section className={styles.workspace} data-builder-member-setup-workspace data-member-setup-mode="error"><WorkspaceState kind="error" title="Member setup is temporarily unavailable" description={props.errorMessage ?? "Try again shortly."} /></section>;
  }

  const rows = invitations.length > 0 ? (
    <ResponsiveCollection
      desktop={<div className={styles.invitationList} data-member-invitations-list="desktop">{invitations.map((invitation) => <InvitationRow key={invitation.id} invitation={invitation} readOnly={readOnly} onRevoke={revokeInvitation} />)}</div>}
      mobile={<div className={styles.invitationList} data-member-invitations-list="mobile">{invitations.map((invitation) => <InvitationRow key={invitation.id} invitation={invitation} readOnly={readOnly} onRevoke={revokeInvitation} />)}</div>}
    />
  ) : <WorkspaceState kind="empty" title="No invitations yet" description="Create an invitation when another person needs access." />;

  return (
    <section className={styles.workspace} data-builder-member-setup-workspace data-member-setup-mode={props.mode}>
      <WorkspaceHeader eyebrow="Dashboard" title="Member setup" description="Invite members with approved permission templates." status={readOnly ? "Read-only access" : "Owner access"} />
      {props.mode === "demo" ? <DemoBanner moduleName="Member setup" onReset={props.onResetDemo ?? (() => undefined)} /> : null}
      <AsyncStatus message={error || message} assertive={Boolean(error)} />
      {aal2Required ? <button type="button" className={styles.primaryButton} onClick={props.onRequestAal2}>Verify identity</button> : null}
      {!readOnly ? (
        <form className={styles.invitationForm} onSubmit={(event) => void createInvitation(event)}>
          <label><span>Member email</span><input type="email" name="email" required maxLength={254} autoComplete="off" value={email} onChange={(event) => setEmail(event.currentTarget.value)} /></label>
          <label><span>Permission template</span><select name="templateId" value={templateId} onChange={(event) => setTemplateId(event.currentTarget.value as GrowthInvitationTemplateId)}>{MEMBER_SETUP_TEMPLATES.map((template) => <option key={template.id} value={template.id}>{template.label}</option>)}</select></label>
          <button type="submit" className={styles.primaryButton} disabled={pending || !email.trim()}><UserPlus size={18} aria-hidden="true" />{pending ? "Creating..." : "Create invitation"}</button>
        </form>
      ) : null}
      {delivery ? (
        <section className={styles.deliveryHandoff} data-member-invitation-delivery role="status">
          <div><strong>Delivery handoff</strong><p>This invitation token is shown only once. Deliver it through your approved secure channel.</p></div>
          <code className={styles.deliveryToken}>{delivery.token}</code>
          <div className={styles.deliveryActions}>
            <button type="button" className={styles.secondaryButton} onClick={() => void navigator.clipboard?.writeText(delivery.token)}><Clipboard size={17} aria-hidden="true" />Copy token</button>
            <button type="button" className={styles.primaryButton} onClick={() => setDelivery(undefined)}>Delivery complete</button>
          </div>
        </section>
      ) : null}
      {loading && invitations.length === 0 ? <WorkspaceState kind="loading" title="Loading member invitations" /> : rows}
    </section>
  );
}
