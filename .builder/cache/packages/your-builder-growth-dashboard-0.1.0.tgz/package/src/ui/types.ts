import type { BuilderRole } from "@your-builder/core";
import type {
  DashboardAccessProjection,
  DashboardDomainAccessProjection,
  DashboardFactsSnapshot,
} from "../index.js";

export type DashboardWorkspaceMode =
  | "demo"
  | "operational"
  | "read_only"
  | "loading"
  | "error"
  | "denied";

export type DashboardDestination =
  | "leads"
  | "customers"
  | "submissions"
  | "notifications"
  | "health";

export interface DashboardWorkspaceAccess {
  readonly dashboard: DashboardAccessProjection;
  readonly leads?: DashboardDomainAccessProjection;
  readonly customers?: DashboardDomainAccessProjection;
}

export interface DashboardWorkspaceProps {
  readonly mode: DashboardWorkspaceMode;
  readonly actorRole: BuilderRole;
  readonly snapshot?: DashboardFactsSnapshot;
  readonly access: DashboardWorkspaceAccess;
  readonly errorMessage?: string;
  readonly onNavigate: (destination: DashboardDestination) => void;
  readonly onResetDemo: () => void;
}
