import { readFileSync } from "node:fs";
import { resolve } from "node:path";

import { describe, expect, it } from "vitest";

import {
  GROWTH_DASHBOARD_MODULE,
  GROWTH_DASHBOARD_CONTRACT_VERSION,
} from "../src/index.js";
import {
  MODULE_IDS,
  resolveFeatureDependencyOrder,
  type GrowthFeatureModule,
  type GrowthModuleId,
} from "../../feature-registry/src/index.js";

function dependencyModule(
  id: GrowthModuleId,
  dependencies: readonly GrowthModuleId[],
): GrowthFeatureModule {
  return {
    id,
    version: "1.0.0",
    label: id,
    description: id,
    icon: "blocks",
    navigationGroup: "growth",
    routes: [{ id: `${id}.home`, path: `/${id}`, label: id }],
    requiredEntitlement: id,
    requiredCapabilities: ["dashboard.read"],
    dependencies: dependencies.map((moduleId) => ({ moduleId, optional: false })),
    setupSteps: [],
    demo: { fixtureId: `${id}.demo`, allowMutations: false, allowsExternalEffects: false },
    healthChecks: [],
  };
}

describe("growth Dashboard package", () => {
  it("declares the package-local dependency boundary", () => {
    const packagePath = resolve(process.cwd(), "packages/growth-dashboard/package.json");
    const manifest = JSON.parse(readFileSync(packagePath, "utf8")) as {
      name: string;
      dependencies: Record<string, string>;
    };

    expect(manifest.name).toBe("@your-builder/growth-dashboard");
    expect(Object.keys(manifest.dependencies).sort()).toEqual([
      "@your-builder/core",
      "@your-builder/editor",
      "@your-builder/feature-registry",
      "@your-builder/growth-customers",
      "@your-builder/growth-leads",
      "lucide-react",
    ]);
  });

  it("registers Dashboard 2.0.0 with its own entitlement and capability", () => {
    expect(GROWTH_DASHBOARD_CONTRACT_VERSION).toBe(1);
    expect(GROWTH_DASHBOARD_MODULE).toMatchObject({
      id: MODULE_IDS.dashboard,
      version: "2.0.0",
      requiredEntitlement: MODULE_IDS.dashboard,
      requiredCapabilities: ["dashboard.read"],
      routes: [{ path: "/admin/editor/dashboard" }],
    });
    expect(GROWTH_DASHBOARD_MODULE.dependencies).toEqual([
      { moduleId: MODULE_IDS.customers, optional: false },
      { moduleId: MODULE_IDS.leads, optional: false },
    ]);
    expect(GROWTH_DASHBOARD_MODULE.demo.allowsExternalEffects).toBe(false);
  });

  it("orders Customers before Leads before Dashboard", () => {
    const customers = dependencyModule(MODULE_IDS.customers, []);
    const leads = dependencyModule(MODULE_IDS.leads, [MODULE_IDS.customers]);

    expect(resolveFeatureDependencyOrder([
      GROWTH_DASHBOARD_MODULE,
      leads,
      customers,
    ])).toEqual([
      MODULE_IDS.customers,
      MODULE_IDS.leads,
      MODULE_IDS.dashboard,
    ]);
  });
});
