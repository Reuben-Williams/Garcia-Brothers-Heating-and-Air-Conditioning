import { describe, expect, it } from "vitest";

import {
  gateDashboardFact,
  type DashboardFact,
} from "../src/index.js";

const leadAging = {
  kind: "lead_aging",
  domain: "leads",
  buckets: [{ minimumAgeDays: 0, maximumAgeDays: 2, count: 4 }],
} as const satisfies DashboardFact;

const customerActivity = {
  kind: "customer_activity",
  domain: "customers",
  activeCount: 9,
} as const satisfies DashboardFact;

const baseInbox = {
  kind: "base_inbox",
  domain: "base_submissions",
  newCount: 3,
  spamReviewCount: 1,
} as const satisfies DashboardFact;

describe("Dashboard fact gating", () => {
  it("requires Dashboard effective read independently of underlying modules", () => {
    expect(gateDashboardFact({
      fact: leadAging,
      actorRole: "owner",
      dashboard: { effectiveRead: false, hasCapability: true },
      domain: { effectiveRead: true, hasRecordCapability: true, state: "active" },
    })).toEqual({ kind: "dashboard_restricted" });
  });

  it("requires dashboard.read independently of Dashboard entitlement", () => {
    expect(gateDashboardFact({
      fact: leadAging,
      actorRole: "owner",
      dashboard: { effectiveRead: true, hasCapability: false },
      domain: { effectiveRead: true, hasRecordCapability: true, state: "active" },
    })).toEqual({ kind: "dashboard_restricted" });
  });

  it.each([
    [leadAging, "growth.leads", false, true],
    [leadAging, "growth.leads", true, false],
    [customerActivity, "growth.customers", false, true],
    [customerActivity, "growth.customers", true, false],
  ] as const)(
    "replaces a restricted %s fact with safe module state",
    (fact, moduleId, effectiveRead, hasRecordCapability) => {
      expect(gateDashboardFact({
        fact,
        actorRole: "owner",
        dashboard: { effectiveRead: true, hasCapability: true },
        domain: { effectiveRead, hasRecordCapability, state: "suspended" },
      })).toEqual({
        kind: "module_state",
        moduleId,
        state: "suspended",
      });
    },
  );

  it("returns an authorized domain fact without changing its counts", () => {
    expect(gateDashboardFact({
      fact: leadAging,
      actorRole: "viewer",
      dashboard: { effectiveRead: true, hasCapability: true },
      domain: { effectiveRead: true, hasRecordCapability: true, state: "active" },
    })).toEqual({ kind: "fact", fact: leadAging });
  });

  it.each(["owner", "editor"] as const)(
    "requires Dashboard effective read before allowing base-inbox facts for %s",
    (actorRole) => {
      expect(gateDashboardFact({
        fact: baseInbox,
        actorRole,
        dashboard: { effectiveRead: false, hasCapability: false },
      })).toEqual({ kind: "dashboard_restricted" });
    },
  );

  it("requires dashboard.read before applying the base-role check", () => {
    expect(gateDashboardFact({
      fact: baseInbox,
      actorRole: "owner",
      dashboard: { effectiveRead: true, hasCapability: false },
    })).toEqual({ kind: "dashboard_restricted" });
  });

  it.each(["owner", "editor"] as const)(
    "allows base-inbox facts for %s after Dashboard access passes",
    (actorRole) => {
      expect(gateDashboardFact({
        fact: baseInbox,
        actorRole,
        dashboard: { effectiveRead: true, hasCapability: true },
      })).toEqual({ kind: "fact", fact: baseInbox });
    },
  );

  it.each(["contributor", "viewer"] as const)(
    "denies base-inbox facts to %s even with dashboard.read",
    (actorRole) => {
      expect(gateDashboardFact({
        fact: baseInbox,
        actorRole,
        dashboard: { effectiveRead: true, hasCapability: true },
      })).toEqual({ kind: "base_role_restricted" });
    },
  );

  it("fails a domain fact closed when its domain access projection is absent", () => {
    expect(gateDashboardFact({
      fact: customerActivity,
      actorRole: "owner",
      dashboard: { effectiveRead: true, hasCapability: true },
    })).toEqual({
      kind: "module_state",
      moduleId: "growth.customers",
      state: "unavailable",
    });
  });
});
