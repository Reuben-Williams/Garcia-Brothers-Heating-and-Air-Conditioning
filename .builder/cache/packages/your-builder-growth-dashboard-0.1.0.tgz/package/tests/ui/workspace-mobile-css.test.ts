import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("Dashboard operational workspace CSS", () => {
  it("provides 44px controls, responsive collection switching, and bounded overflow", async () => {
    const css = await readFile(resolve(import.meta.dirname, "../../src/ui/operational-workspaces.module.css"), "utf8");
    expect(css).toContain("min-height: 44px");
    expect(css).toContain("overflow-wrap: anywhere");
    expect(css).toContain("@media (min-width: 768px)");
    expect(css).toContain("max-width: 100%");
    expect(css).not.toContain("max-width: 767px");
  });
});
