// @vitest-environment jsdom

import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import {
  NotificationsWorkspace,
  type NotificationsPage,
  type NotificationsWorkspaceProps,
} from "../../src/ui/index.js";

const page = {
  items: [
    { id: "notification-1", eventType: "lead.created", resourceType: "lead", resourceId: "lead-1", previewText: "A new heating lead arrived.", createdAt: "2026-07-18T12:00:00.000Z" },
    { id: "notification-2", eventType: "task.due", resourceType: "task", resourceId: "task-2", previewText: "A follow-up task is due.", createdAt: "2026-07-18T11:00:00.000Z", readAt: "2026-07-18T11:30:00.000Z" },
  ],
  unreadCount: 1,
  nextCursor: "notification-page-2",
} as const satisfies NotificationsPage;

function props(overrides: Partial<NotificationsWorkspaceProps> = {}): NotificationsWorkspaceProps {
  return {
    mode: "operational",
    initialPage: page,
    urlState: { view: "all" },
    api: {
      list: vi.fn(async () => page),
      markRead: vi.fn(async () => ({ status: "applied" as const })),
    },
    onUrlStateChange: vi.fn(),
    onUnreadCountChange: vi.fn(),
    onResetDemo: vi.fn(),
    ...overrides,
  };
}

describe("NotificationsWorkspace", () => {
  it("renders the trusted-recipient projection with unread count and paging", () => {
    const html = renderToStaticMarkup(<NotificationsWorkspace {...props()} />);
    expect(html).toContain("data-builder-notifications-workspace");
    expect(html).toContain('data-notifications-mode="operational"');
    expect(html).toContain("1 unread");
    expect(html).toContain("A new heating lead arrived.");
    expect(html).toContain("A follow-up task is due.");
    expect(html).toContain("Load more");
    expect(html).not.toMatch(/recipientMemberId|siteId|version|email|sms/i);
  });

  it("keeps authorized records visible but removes mutation controls in read-only", () => {
    const html = renderToStaticMarkup(<NotificationsWorkspace {...props({ mode: "read_only" })} />);
    expect(html).toContain("Read-only access");
    expect(html).toContain("A new heating lead arrived.");
    expect(html).not.toContain("Mark read");
  });

  it.each([
    ["denied", "Notifications access is not available"],
    ["error", "Notifications are temporarily unavailable"],
  ] as const)("renders explicit %s state", (mode, message) => {
    const html = renderToStaticMarkup(<NotificationsWorkspace {...props({ mode, initialPage: undefined })} />);
    expect(html).toContain(`data-notifications-mode="${mode}"`);
    expect(html).toContain(message);
    expect(html).not.toContain("A new heating lead arrived.");
  });

  it("renders explicit empty and deterministic demo states", () => {
    const empty = renderToStaticMarkup(<NotificationsWorkspace {...props({ initialPage: { items: [], unreadCount: 0 } })} />);
    const demo = renderToStaticMarkup(<NotificationsWorkspace {...props({ mode: "demo", initialPage: undefined })} />);
    expect(empty).toContain("No notifications yet");
    expect(demo).toContain("Preview with sample data");
    expect(demo).toContain("New website inquiry");
  });
});
