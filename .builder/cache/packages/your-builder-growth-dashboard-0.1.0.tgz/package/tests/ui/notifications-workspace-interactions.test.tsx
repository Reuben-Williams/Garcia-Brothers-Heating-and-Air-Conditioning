// @vitest-environment jsdom

import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import {
  NotificationsWorkspace,
  type NotificationsApi,
  type NotificationsWorkspaceProps,
} from "../../src/ui/index.js";

const first = { id: "notification-1", eventType: "lead.created", resourceType: "lead" as const, resourceId: "lead-1", previewText: "New lead assigned.", createdAt: "2026-07-18T12:00:00.000Z" };
const readFirst = { ...first, readAt: "2026-07-18T13:00:00.000Z" };
const second = { id: "notification-2", eventType: "task.due", resourceType: "task" as const, resourceId: "task-1", previewText: "Follow-up is due.", createdAt: "2026-07-18T11:00:00.000Z" };

function api(result: Awaited<ReturnType<NotificationsApi["markRead"]>> = { status: "applied" }): NotificationsApi {
  return {
    list: vi.fn(async ({ cursor }) => cursor
      ? { items: [readFirst, second], unreadCount: 1 }
      : { items: [readFirst], unreadCount: 0 }),
    markRead: vi.fn(async () => result),
  };
}

function props(client: NotificationsApi, onUrlStateChange = vi.fn()): NotificationsWorkspaceProps {
  return {
    mode: "operational",
    initialPage: { items: [first], unreadCount: 1, nextCursor: "page-2" },
    urlState: { view: "all" },
    api: client,
    onUrlStateChange,
    onUnreadCountChange: vi.fn(),
    onResetDemo: vi.fn(),
  };
}

let container: HTMLDivElement;
let root: Root;

beforeAll(() => {
  (globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
});

afterEach(async () => {
  if (root) await act(async () => root.unmount());
  container?.remove();
});

async function render(workspaceProps: NotificationsWorkspaceProps) {
  container = document.createElement("div");
  document.body.append(container);
  root = createRoot(container);
  await act(async () => root.render(<NotificationsWorkspace {...workspaceProps} />));
}

function button(label: string) {
  return Array.from(container.querySelectorAll<HTMLButtonElement>("button")).find((item) => item.textContent?.trim() === label);
}

describe("NotificationsWorkspace interactions", () => {
  it("loads without accepting a browser-selected recipient", async () => {
    const client = api();
    await render({ ...props(client), initialPage: undefined });
    expect(client.list).toHaveBeenCalledWith({ view: "all", cursor: undefined, limit: 25 });
    expect(client.list).not.toHaveBeenCalledWith(expect.objectContaining({ recipientMemberId: expect.anything() }));
  });

  it("disables the mark-read action while the injected command is pending", async () => {
    let resolveMarkRead!: (result: Awaited<ReturnType<NotificationsApi["markRead"]>>) => void;
    const client: NotificationsApi = {
      ...api(),
      markRead: vi.fn(() => new Promise<Awaited<ReturnType<NotificationsApi["markRead"]>>>((resolve) => { resolveMarkRead = resolve; })),
    };
    await render(props(client));
    await act(async () => button("Mark read")?.click());
    expect(button("Marking...")?.disabled).toBe(true);
    await act(async () => resolveMarkRead({ status: "applied" }));
    expect(container.textContent).toContain("Notification marked read");
  });

  it("sends only notificationId and refreshes the trusted projection", async () => {
    const client = api();
    await render(props(client));
    await act(async () => button("Mark read")?.click());
    expect(client.markRead).toHaveBeenCalledWith({ notificationId: first.id });
    expect(client.list).toHaveBeenCalledWith({ view: "all", cursor: undefined, limit: 25 });
    expect(container.textContent).toContain("Notification marked read");
    expect(container.textContent).toContain("0 unread");
  });

  it.each([
    [{ status: "already_read" } as const, "already read"],
    [{ status: "denied", reason: "not_authorized" } as const, "permission"],
  ])("announces the idempotent mark-read result", async (result, message) => {
    await render(props(api(result)));
    await act(async () => button("Mark read")?.click());
    expect(container.textContent).toContain(message);
  });

  it("loads a deduplicated next page and reports cursor/view URL state", async () => {
    const client = api();
    const onUrlStateChange = vi.fn();
    await render(props(client, onUrlStateChange));
    await act(async () => button("Unread")?.click());
    expect(onUrlStateChange).toHaveBeenCalledWith({ view: "unread", cursor: undefined });
    await act(async () => button("Load more")?.click());
    expect(client.list).toHaveBeenCalledWith({ view: "all", cursor: "page-2", limit: 25 });
    expect(container.querySelectorAll('[data-notifications-list="desktop"] [data-builder-notification-id]')).toHaveLength(2);
    expect(container.querySelectorAll('[data-notifications-list="mobile"] [data-builder-notification-id]')).toHaveLength(2);
  });
});
