// @vitest-environment jsdom

import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import {
  MemberSetupWorkspace,
  type MemberInvitationRecord,
  type MemberSetupWorkspaceProps,
} from "../../src/ui/index.js";

const invitation = {
  id: "invitation-1",
  templateId: "growth_manager_v1",
  templateVersion: 1,
  state: "pending",
  invitedBy: "owner-1",
  expiresAt: "2026-07-25T12:00:00.000Z",
  createdAt: "2026-07-18T12:00:00.000Z",
  version: 1,
  updatedAt: "2026-07-18T12:00:00.000Z",
} as const satisfies MemberInvitationRecord;

function props(overrides: Partial<MemberSetupWorkspaceProps> = {}): MemberSetupWorkspaceProps {
  return {
    mode: "operational",
    actorRole: "owner",
    initialInvitations: [invitation],
    api: {
      list: vi.fn(async () => ({ items: [invitation] })),
      create: vi.fn(async () => ({ result: "applied" as const, invitation: { id: invitation.id, token: "one-time-token-value" }, version: 1, replayed: false })),
      revoke: vi.fn(async () => ({ result: "applied" as const, resource: { type: "member_invitation" as const, id: invitation.id }, version: 2, replayed: false })),
    },
    onRequestAal2: vi.fn(),
    onResetDemo: vi.fn(),
    ...overrides,
  };
}

describe("MemberSetupWorkspace", () => {
  it("renders only safe invitation projection metadata and exact approved templates", () => {
    const html = renderToStaticMarkup(<MemberSetupWorkspace {...props()} />);
    expect(html).toContain("data-builder-member-setup-workspace");
    expect(html).toContain("Invitation invitation-1");
    expect(html).toContain("Manager");
    expect(html).toContain("Staff");
    expect(html).toContain("Read-only");
    expect(html).toContain("Pending");
    expect(html).not.toMatch(/emailHint|@|canonicalEmailDigest|tokenHash|raw digest/i);
    expect(html).not.toContain("one-time-token-value");
  });

  it("denies non-owner and explicit denied modes without invitation metadata", () => {
    const nonOwner = renderToStaticMarkup(<MemberSetupWorkspace {...props({ actorRole: "editor" })} />);
    const denied = renderToStaticMarkup(<MemberSetupWorkspace {...props({ mode: "denied" })} />);
    expect(nonOwner).toContain("Member setup is owner-only");
    expect(nonOwner).not.toContain(invitation.id);
    expect(denied).toContain("Member setup is owner-only");
  });

  it("renders deterministic safe demo and explicit empty/error states", () => {
    const demo = renderToStaticMarkup(<MemberSetupWorkspace {...props({ mode: "demo", initialInvitations: undefined })} />);
    const empty = renderToStaticMarkup(<MemberSetupWorkspace {...props({ initialInvitations: [] })} />);
    const error = renderToStaticMarkup(<MemberSetupWorkspace {...props({ mode: "error", initialInvitations: undefined })} />);
    expect(demo).toContain("Preview with sample data");
    expect(demo).toContain("Invitation demo-invitation-1");
    expect(demo).not.toMatch(/emailHint|@/i);
    expect(empty).toContain("No invitations yet");
    expect(error).toContain("Member setup is temporarily unavailable");
  });
});
