// @vitest-environment jsdom

import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import {
  MemberSetupWorkspace,
  type MemberInvitationRecord,
  type MemberSetupApi,
  type MemberSetupWorkspaceProps,
} from "../../src/ui/index.js";

const invitation = {
  id: "invitation-1",
  templateId: "growth_staff_v1",
  templateVersion: 1,
  state: "pending",
  invitedBy: "owner-1",
  expiresAt: "2026-07-25T12:00:00.000Z",
  createdAt: "2026-07-18T12:00:00.000Z",
  version: 1,
  updatedAt: "2026-07-18T12:00:00.000Z",
} as const satisfies MemberInvitationRecord;

const revokedInvitation = {
  ...invitation,
  state: "revoked",
  revokedAt: "2026-07-18T14:00:00.000Z",
  version: 2,
  updatedAt: "2026-07-18T14:00:00.000Z",
} as const satisfies MemberInvitationRecord;

function props(client: MemberSetupApi, onRequestAal2 = vi.fn()): MemberSetupWorkspaceProps {
  return { mode: "operational", actorRole: "owner", initialInvitations: [invitation], api: client, onRequestAal2, onResetDemo: vi.fn() };
}

let container: HTMLDivElement;
let root: Root;

beforeAll(() => {
  (globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
  Object.assign(navigator, { clipboard: { writeText: vi.fn(async () => undefined) } });
});

afterEach(async () => {
  if (root) await act(async () => root.unmount());
  container?.remove();
});

async function render(workspaceProps: MemberSetupWorkspaceProps) {
  container = document.createElement("div");
  document.body.append(container);
  root = createRoot(container);
  await act(async () => root.render(<MemberSetupWorkspace {...workspaceProps} />));
}

function button(label: string) {
  return Array.from(container.querySelectorAll<HTMLButtonElement>("button")).find((item) => item.textContent?.trim() === label);
}

async function fill(selector: string, value: string) {
  const field = container.querySelector<HTMLInputElement | HTMLSelectElement>(selector)!;
  await act(async () => {
    const prototype = field instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const valueSetter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    valueSetter?.call(field, value);
    field.dispatchEvent(new Event("input", { bubbles: true }));
    field.dispatchEvent(new Event("change", { bubbles: true }));
  });
}

function appliedCreate() {
  return { result: "applied" as const, invitation: { id: invitation.id, token: "fixture-secret-token" }, version: 1, replayed: false };
}

function appliedRevoke() {
  return { result: "applied" as const, resource: { type: "member_invitation" as const, id: invitation.id }, version: 2, replayed: false };
}

describe("MemberSetupWorkspace interactions", () => {
  it("accepts the create envelope, refreshes the list, and shows its token only once", async () => {
    const client: MemberSetupApi = {
      list: vi.fn(async () => ({ items: [invitation] })),
      create: vi.fn(async () => appliedCreate()),
      revoke: vi.fn(async () => appliedRevoke()),
    };
    await render(props(client));
    await fill('[name="email"]', "member@example.test");
    await fill('[name="templateId"]', "growth_staff_v1");
    await act(async () => container.querySelector("form")?.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
    expect(client.create).toHaveBeenCalledWith({ email: "member@example.test", templateId: "growth_staff_v1" });
    expect(client.list).toHaveBeenCalledOnce();
    expect(container.textContent).toContain("fixture-secret-token");
    expect(container.textContent).toContain("shown only once");
    await act(async () => button("Delivery complete")?.click());
    expect(container.textContent).not.toContain("fixture-secret-token");

    await fill('[name="email"]', "member@example.test");
    await act(async () => container.querySelector("form")?.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
    expect(client.list).toHaveBeenCalledTimes(2);
    expect(container.textContent).not.toContain("fixture-secret-token");
  });

  it("never re-shows a token from a replayed create operation", async () => {
    const client: MemberSetupApi = {
      list: vi.fn(async () => ({ items: [invitation] })),
      create: vi.fn(async () => ({ ...appliedCreate(), replayed: true })),
      revoke: vi.fn(async () => appliedRevoke()),
    };
    await render(props(client));
    await fill('[name="email"]', "member@example.test");
    await act(async () => container.querySelector("form")?.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
    expect(client.list).toHaveBeenCalledOnce();
    expect(container.textContent).toContain("Invitation created");
    expect(container.textContent).not.toContain("fixture-secret-token");
    expect(container.querySelector("[data-member-invitation-delivery]")).toBeNull();
  });

  it("routes recent AAL2 requirements to re-verification", async () => {
    const onRequestAal2 = vi.fn();
    const client: MemberSetupApi = {
      list: vi.fn(async () => ({ items: [invitation] })),
      create: vi.fn(async () => ({ result: "recent_aal2_required" as const })),
      revoke: vi.fn(async () => ({ result: "recent_aal2_required" as const })),
    };
    await render(props(client, onRequestAal2));
    await fill('[name="email"]', "member@example.test");
    await act(async () => container.querySelector("form")?.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
    expect(container.textContent).toContain("recent identity verification");
    await act(async () => button("Verify identity")?.click());
    expect(onRequestAal2).toHaveBeenCalledOnce();
  });

  it("requires confirmation and a reason, accepts an operation result, and refreshes after revoke", async () => {
    const client: MemberSetupApi = {
      list: vi.fn(async () => ({ items: [revokedInvitation] })),
      create: vi.fn(async () => appliedCreate()),
      revoke: vi.fn(async () => appliedRevoke()),
    };
    await render(props(client));
    await act(async () => button("Revoke")?.click());
    expect(container.querySelector('[role="dialog"]')).toBeTruthy();
    expect(container.textContent).not.toMatch(/@|emailHint/i);
    expect(button("Revoke invitation")?.disabled).toBe(true);
    await fill('[aria-label="Reason for revocation"]', "Invited in error");
    await act(async () => button("Revoke invitation")?.click());
    expect(client.revoke).toHaveBeenCalledWith({ invitationId: invitation.id, expectedVersion: 1, reason: "Invited in error" });
    expect(client.list).toHaveBeenCalledOnce();
    expect(container.textContent).toContain("Revoked");
  });

  it("handles recent AAL2 requirements returned by revoke", async () => {
    const onRequestAal2 = vi.fn();
    const client: MemberSetupApi = {
      list: vi.fn(async () => ({ items: [invitation] })),
      create: vi.fn(async () => appliedCreate()),
      revoke: vi.fn(async () => ({ result: "recent_aal2_required" as const })),
    };
    await render(props(client, onRequestAal2));
    await act(async () => button("Revoke")?.click());
    await fill('[aria-label="Reason for revocation"]', "Owner security check");
    await act(async () => button("Revoke invitation")?.click());
    expect(container.textContent).toContain("recent identity verification");
    expect(client.list).not.toHaveBeenCalled();
    await act(async () => button("Verify identity")?.click());
    expect(onRequestAal2).toHaveBeenCalledOnce();
  });

  it("surfaces the destructive-action guard when a revoke request fails", async () => {
    const client: MemberSetupApi = {
      list: vi.fn(async () => ({ items: [invitation] })),
      create: vi.fn(async () => appliedCreate()),
      revoke: vi.fn(async () => { throw new Error("network unavailable"); }),
    };
    await render(props(client));
    await act(async () => button("Revoke")?.click());
    await fill('[aria-label="Reason for revocation"]', "Invited in error");
    await act(async () => button("Revoke invitation")?.click());
    expect(container.textContent).toContain("Action could not be completed. Try again.");
    expect(client.list).not.toHaveBeenCalled();
  });
});
