// @vitest-environment jsdom

import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";

import {
  DashboardWorkspace,
  type DashboardWorkspaceProps,
} from "../../src/ui/index.js";

const snapshot = {
  siteId: "11111111-1111-4111-8111-111111111111",
  generatedAt: "2026-07-18T13:00:00.000Z",
  facts: [
    {
      kind: "lead_aging",
      domain: "leads",
      buckets: [
        { minimumAgeDays: 0, maximumAgeDays: 2, count: 4 },
        { minimumAgeDays: 3, maximumAgeDays: null, count: 2 },
      ],
    },
    { kind: "unassigned_leads", domain: "leads", count: 3 },
    { kind: "task_deadlines", domain: "leads", dueCount: 5, overdueCount: 1 },
    { kind: "customer_activity", domain: "customers", activeCount: 12 },
    { kind: "module_health", domain: "dashboard", warningCount: 1, criticalCount: 0 },
    { kind: "notification_count", domain: "dashboard", unreadCount: 2 },
    { kind: "base_inbox", domain: "base_submissions", newCount: 6, spamReviewCount: 1 },
  ],
} as const;

function props(overrides: Partial<DashboardWorkspaceProps> = {}): DashboardWorkspaceProps {
  return {
    mode: "operational",
    actorRole: "owner",
    snapshot,
    access: {
      dashboard: { effectiveRead: true, hasCapability: true },
      leads: { effectiveRead: true, hasRecordCapability: true, state: "active" },
      customers: { effectiveRead: true, hasRecordCapability: true, state: "active" },
    },
    onNavigate: vi.fn(),
    onResetDemo: vi.fn(),
    ...overrides,
  };
}

describe("DashboardWorkspace", () => {
  it("renders authorized operational facts with drill-down destinations", () => {
    const html = renderToStaticMarkup(<DashboardWorkspace {...props()} />);

    expect(html).toContain("data-builder-dashboard-workspace");
    expect(html).toContain('data-dashboard-mode="operational"');
    expect(html).toContain('data-dashboard-fact="lead_aging"');
    expect(html).toContain('data-dashboard-fact="unassigned_leads"');
    expect(html).toContain('data-dashboard-fact="base_inbox"');
    expect(html).toContain("6 new submissions");
    expect(html).toContain("View leads");
    expect(html).toContain("View submissions");
  });

  it("replaces a restricted domain with a safe state instead of exposing its facts", () => {
    const html = renderToStaticMarkup(<DashboardWorkspace {...props({
      access: {
        dashboard: { effectiveRead: true, hasCapability: true },
        leads: { effectiveRead: false, hasRecordCapability: true, state: "suspended" },
        customers: { effectiveRead: true, hasRecordCapability: true, state: "active" },
      },
    })} />);

    expect(html).toContain('data-dashboard-module-restriction="growth.leads"');
    expect(html).toContain("Leads is currently suspended");
    expect(html).not.toContain('data-dashboard-fact="unassigned_leads"');
    expect(html).toContain('data-dashboard-fact="customer_activity"');
  });

  it("renders deterministic sample data with the existing demo disclosure", () => {
    const html = renderToStaticMarkup(<DashboardWorkspace {...props({
      mode: "demo",
      snapshot: undefined,
    })} />);

    expect(html).toContain('data-dashboard-mode="demo"');
    expect(html).toContain("Preview with sample data");
    expect(html).toContain("Reset demo");
    expect(html).toContain('data-dashboard-fact="unassigned_leads"');
  });

  it("keeps authorized read-only facts navigable without mutation controls", () => {
    const html = renderToStaticMarkup(<DashboardWorkspace {...props({ mode: "read_only" })} />);

    expect(html).toContain('data-dashboard-mode="read_only"');
    expect(html).toContain("Read-only access");
    expect(html).toContain("View leads");
    expect(html).not.toContain("disabled");
  });

  it("renders an explicit no-data denied state", () => {
    const html = renderToStaticMarkup(<DashboardWorkspace {...props({
      mode: "denied",
      snapshot: undefined,
      access: {
        dashboard: { effectiveRead: false, hasCapability: false },
      },
    })} />);

    expect(html).toContain('data-dashboard-mode="denied"');
    expect(html).toContain("Dashboard access is not available");
    expect(html).not.toContain('data-dashboard-fact="');
  });
});
