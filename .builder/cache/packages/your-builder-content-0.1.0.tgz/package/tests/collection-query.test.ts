import { describe, expect, it } from "vitest";
import { filterAndSortPublishedPosts, parsePostCollectionQuery, type PublishedPost } from "@your-builder/content";

function post(overrides: Partial<PublishedPost>): PublishedPost {
  return {
    entryId: crypto.randomUUID(),
    versionId: crypto.randomUUID(),
    slug: "post",
    title: "Post",
    excerpt: "Excerpt",
    categoryKeys: ["notice"],
    tagKeys: [],
    displayDate: "2026-07-10T12:00:00.000Z",
    versionPublishedAt: "2026-07-10T12:00:00.000Z",
    expiresAt: null,
    featured: false,
    pinned: false,
    ...overrides,
  };
}

describe("post collection query", () => {
  it("filters by stable taxonomy keys and sorts pinned posts first", () => {
    const result = filterAndSortPublishedPosts(
      [
        post({ title: "Older", slug: "older", displayDate: "2026-07-01T12:00:00.000Z" }),
        post({ title: "Pinned", slug: "pinned", pinned: true, displayDate: "2026-06-01T12:00:00.000Z" }),
        post({ title: "Other", slug: "other", categoryKeys: ["education"] }),
      ],
      parsePostCollectionQuery({
        categoryKeys: ["notice"],
        pinnedFirst: true,
        limit: 2,
        orderBy: "displayDate",
        orderDirection: "desc",
      }),
    );

    expect(result.map((entry) => entry.slug)).toEqual(["pinned", "older"]);
  });

  it("rejects an unbounded collection", () => {
    expect(() =>
      parsePostCollectionQuery({ limit: 0, orderBy: "displayDate", orderDirection: "desc" }),
    ).toThrow(/limit/i);
  });
});

