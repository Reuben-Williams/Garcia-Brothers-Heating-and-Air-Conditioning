import { describe, expect, it } from "vitest";
import { parseContentTransitionInput } from "@your-builder/content";

describe("content lifecycle inputs", () => {
  it("requires concurrency and idempotency data for publication", () => {
    expect(() =>
      parseContentTransitionInput("publish", {
        entryId: crypto.randomUUID(),
        expectedDraftVersionId: crypto.randomUUID(),
      }),
    ).toThrow(/idempotency/i);
  });

  it("requires future schedule time and both expected versions", () => {
    expect(() =>
      parseContentTransitionInput("schedule", {
        entryId: crypto.randomUUID(),
        expectedDraftVersionId: crypto.randomUUID(),
        expectedPublishedVersionId: null,
        idempotencyKey: "schedule:request-1",
        publishAt: "2020-01-01T00:00:00.000Z",
      }),
    ).toThrow(/future|schedule/i);
  });
});
