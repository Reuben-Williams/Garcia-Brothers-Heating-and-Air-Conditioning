import { describe, expect, it } from "vitest";
import { createSeedHash, parsePostMigrationManifest } from "@your-builder/content";

const entryId = "06a80923-d9a6-4e46-8e7b-c7a475f7a915";

function manifest(seedHash: string) {
  return {
    schemaVersion: 1,
    toolVersion: "0.1.0",
    manifestId: `postmig_${seedHash}`,
    seedHash,
    siteKey: "official-assembly-website-v1",
    sourceScopeKey: "assembly-community-announcements-v1",
    collectionRegionId: "home.communityAnnouncements",
    sourceFiles: [
      {
        path: "prototype/home/code.html",
        sha256: "a".repeat(64),
        astFingerprint: "b".repeat(64),
      },
    ],
    reviewedPatchSpec: {
      candidates: [
        {
          candidateId: "home-announcements",
          sourceFile: "prototype/home/code.html",
          sourceSpan: { start: 100, end: 500 },
          transform: "replace-post-collection",
          fieldMappings: [{ postField: "title", sourceExpression: "h3" }],
          categoryMappings: { Event: "events" },
        },
      ],
      detailRoute: {
        route: "/news/[postSlug]",
        sourceFile: "src/app/news/[postSlug]/page.tsx",
        rendererExport: "AssemblyPostDetail",
      },
      fallbackSource: { sourceFile: "src/content/posts/fallback-posts.ts", exportName: "fallbackPosts" },
      collectionRenderer: {
        sourceFile: "src/components/posts/AssemblyAnnouncementCard.tsx",
        exportName: "AssemblyAnnouncementCard",
        variant: "featured-and-compact",
      },
    },
    records: [
      {
        sourceRecordKey: "route-9-repairs",
        entryId,
        fallbackEntryId: entryId,
        approvedFields: {
          slug: "route-9-repairs",
          data: {
            title: "Route 9 repairs",
            excerpt: "Repairs begin next week.",
            body: { version: 1, type: "doc", content: [] },
            featuredImage: null,
            author: { key: null, name: "District Office" },
            featured: false,
            pinned: false,
            seo: {
              title: "Route 9 repairs",
              description: "Repairs begin next week.",
              canonicalUrl: null,
              socialImage: null,
              noIndex: false,
            },
          },
          taxonomyKeys: { categories: ["infrastructure"], tags: [] },
          taxonomySnapshot: {
            infrastructure: { label: "Infrastructure", slug: "infrastructure" },
          },
          displayDate: "2024-10-10T12:00:00.000Z",
          expiresAt: null,
        },
      },
    ],
    generatedArtifacts: [],
  };
}

describe("post migration manifest", () => {
  it("content-addresses approved seed records and validates stable fallback identity", async () => {
    const draft = manifest("0".repeat(64));
    const seedHash = await createSeedHash({
      schemaVersion: draft.schemaVersion,
      siteKey: draft.siteKey,
      sourceScopeKey: draft.sourceScopeKey,
      records: draft.records,
    });
    const parsed = parsePostMigrationManifest(manifest(seedHash));

    expect(parsed.seedHash).toBe(seedHash);
    expect(parsed.records[0].entryId).toBe(parsed.records[0].fallbackEntryId);
  });

  it("rejects a fallback identity that differs from the stable entry id", async () => {
    const draft = manifest("0".repeat(64));
    draft.records[0].fallbackEntryId = crypto.randomUUID();

    expect(() => parsePostMigrationManifest(draft)).toThrow(/fallback|entry/i);
  });
});

