import { describe, expect, it } from "vitest";
import {
  SlugConflictError,
  assertTaxonomyKeyStable,
  normalizePostSlug,
  resolveDirectPostRedirect,
} from "@your-builder/content";

describe("post slug and taxonomy identity", () => {
  it("normalizes human labels and rejects reserved routes", () => {
    expect(normalizePostSlug(" Route 9 Repairs! ")).toBe("route-9-repairs");
    expect(() => normalizePostSlug("admin")).toThrow(SlugConflictError);
  });

  it("resolves one direct redirect without following a redirect chain", () => {
    expect(
      resolveDirectPostRedirect("old-route", [
        { fromSlug: "old-route", entryId: "entry-1", currentSlug: "route-9-repairs" },
      ]),
    ).toEqual({ entryId: "entry-1", slug: "route-9-repairs" });
  });

  it("keeps taxonomy identity stable when its display slug changes", () => {
    expect(() =>
      assertTaxonomyKeyStable(
        { key: "infrastructure", slug: "roads", label: "Infrastructure" },
        { key: "transportation", slug: "transportation", label: "Transportation" },
      ),
    ).toThrow(/taxonomy|key|identity/i);
  });
});
