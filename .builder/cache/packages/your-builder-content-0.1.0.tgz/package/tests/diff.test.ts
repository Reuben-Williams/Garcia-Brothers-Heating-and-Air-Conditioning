import { describe, expect, it } from "vitest";
import { diffPostSnapshots, parsePostSnapshot } from "@your-builder/content";

const base = parsePostSnapshot({
  slug: "notice",
  data: {
    title: "Notice",
    excerpt: "Before",
    body: { version: 1, type: "doc", content: [] },
    featuredImage: { kind: "static", src: "/before.jpg", alt: "Before" },
    author: { key: null, name: "Office" },
    featured: false,
    pinned: false,
    seo: { title: "Notice", description: "Before", canonicalUrl: null, socialImage: null, noIndex: false },
  },
  taxonomyKeys: { categories: ["notice"], tags: [] },
  taxonomySnapshot: { notice: { label: "Notice", slug: "notice" } },
  displayDate: "2026-07-14T12:00:00.000Z",
  expiresAt: null,
});

describe("post snapshot diff", () => {
  it("summarizes changed fields and preserves image previews", () => {
    const after = parsePostSnapshot({
      ...base,
      data: {
        ...base.data,
        excerpt: "After",
        featuredImage: { kind: "static", src: "/after.jpg", alt: "After" },
      },
    });
    const result = diffPostSnapshots(base, after);

    expect(result.changedFields).toContain("data.excerpt");
    expect(result.imageChanges[0]).toMatchObject({
      before: { src: "/before.jpg", alt: "Before" },
      after: { src: "/after.jpg", alt: "After" },
    });
  });
});
