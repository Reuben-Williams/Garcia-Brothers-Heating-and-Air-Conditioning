import { describe, expect, it } from "vitest";
import { parsePostSnapshot } from "@your-builder/content";

const validSnapshot = {
  slug: "route-9-repairs",
  data: {
    title: "Major Road Repairs Begin Next Week on Route 9",
    excerpt: "Resurfacing work begins next week.",
    body: {
      version: 1,
      type: "doc",
      content: [
        {
          type: "paragraph",
          content: [{ type: "text", text: "Crews will begin work Monday." }],
        },
      ],
    },
    featuredImage: {
      kind: "managed",
      mediaId: "5dfc10d7-c9b0-4c24-9be1-d5507a75ce3d",
      revisionId: "4149f953-b337-486c-8c91-8510410037c3",
      alt: "Road crews preparing Route 9 for repairs",
    },
    author: { key: "district-office", name: "District Office" },
    featured: false,
    pinned: false,
    seo: {
      title: "Route 9 repairs",
      description: "What residents need to know about Route 9 repairs.",
      canonicalUrl: null,
      socialImage: null,
      noIndex: false,
    },
  },
  taxonomyKeys: {
    categories: ["infrastructure"],
    tags: ["route-9"],
  },
  taxonomySnapshot: {
    infrastructure: { label: "Infrastructure", slug: "infrastructure" },
    "route-9": { label: "Route 9", slug: "route-9" },
  },
  displayDate: "2026-07-14T12:00:00.000Z",
  expiresAt: null,
};

describe("post snapshot schema", () => {
  it("accepts an immutable post snapshot with managed media references", () => {
    expect(parsePostSnapshot(validSnapshot)).toEqual(validSnapshot);
  });

  it("rejects raw html rich-text nodes", () => {
    expect(() =>
      parsePostSnapshot({
        ...validSnapshot,
        data: {
          ...validSnapshot.data,
          body: { version: 1, type: "doc", content: [{ type: "html", value: "<script>alert(1)</script>" }] },
        },
      }),
    ).toThrow(/rich text|node|invalid/i);
  });

  it("rejects caller-supplied managed-media object keys", () => {
    expect(() =>
      parsePostSnapshot({
        ...validSnapshot,
        data: {
          ...validSnapshot.data,
          featuredImage: {
            ...validSnapshot.data.featuredImage,
            objectKey: "another-site/private.jpg",
          },
        },
      }),
    ).toThrow(/unrecognized|objectKey|invalid/i);
  });
});

