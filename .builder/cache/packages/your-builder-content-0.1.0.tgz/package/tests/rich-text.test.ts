import { describe, expect, it } from "vitest";
import { richTextDocumentSchema } from "@your-builder/content";

describe("safe rich text", () => {
  it("allows formatting and safe links", () => {
    expect(
      richTextDocumentSchema.parse({
        version: 1,
        type: "doc",
        content: [
          {
            type: "paragraph",
            content: [
              { type: "text", text: "Read more", marks: [{ type: "link", attrs: { href: "/news" } }] },
            ],
          },
        ],
      }),
    ).toBeTruthy();
  });

  it("rejects executable link protocols", () => {
    expect(() =>
      richTextDocumentSchema.parse({
        version: 1,
        type: "doc",
        content: [
          {
            type: "paragraph",
            content: [
              {
                type: "text",
                text: "Unsafe",
                marks: [{ type: "link", attrs: { href: "javascript:alert(1)" } }],
              },
            ],
          },
        ],
      }),
    ).toThrow(/link|href|url|protocol/i);
  });
});
