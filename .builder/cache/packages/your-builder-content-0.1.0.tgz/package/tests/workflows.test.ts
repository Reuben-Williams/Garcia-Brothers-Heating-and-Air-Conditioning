import { describe, expect, it } from "vitest";
import {
  ContentConflictError,
  assertTransitionExpectations,
  createIdempotencyRequestKey,
} from "@your-builder/content";

describe("content transition contracts", () => {
  it("rejects a stale published version before a lifecycle transition", () => {
    expect(() =>
      assertTransitionExpectations(
        { draftVersionId: "draft-2", publishedVersionId: "published-2" },
        { expectedDraftVersionId: "draft-2", expectedPublishedVersionId: "published-1" },
      ),
    ).toThrow(ContentConflictError);
  });

  it("creates a stable request key without accepting tenant identity from the payload", async () => {
    const first = await createIdempotencyRequestKey("post.publish", {
      entryId: "2bb47eb4-ce87-4a68-874e-a0ddbe98dd89",
      expectedDraftVersionId: "draft-2",
    });
    const second = await createIdempotencyRequestKey("post.publish", {
      expectedDraftVersionId: "draft-2",
      entryId: "2bb47eb4-ce87-4a68-874e-a0ddbe98dd89",
    });

    expect(first).toBe(second);
    expect(first).toMatch(/^post\.publish:[a-f0-9]{64}$/);
  });
});

