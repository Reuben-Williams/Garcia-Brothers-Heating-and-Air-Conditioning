export interface TaxonomyDefinition {
  key: string;
  slug: string;
  label: string;
}

export function assertTaxonomyKeyStable(
  current: TaxonomyDefinition,
  proposed: TaxonomyDefinition,
): void {
  if (current.key !== proposed.key) {
    throw new TypeError("Taxonomy key is immutable identity; create a new taxonomy item instead.");
  }
}

