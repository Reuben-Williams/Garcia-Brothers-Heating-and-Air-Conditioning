import { z } from "zod";

export interface PublishedPost {
  entryId: string;
  versionId: string;
  slug: string;
  title: string;
  excerpt: string;
  categoryKeys: string[];
  tagKeys: string[];
  displayDate: string;
  versionPublishedAt: string;
  expiresAt: string | null;
  featured: boolean;
  pinned: boolean;
  snapshot?: import("./post-schema.js").PostSnapshot;
  featuredImageUrl?: string;
}

export const postCollectionQuerySchema = z.strictObject({
  categoryKeys: z.array(z.string().min(1)).default([]),
  tagKeys: z.array(z.string().min(1)).default([]),
  entryIds: z.array(z.string().uuid()).default([]),
  featuredOnly: z.boolean().default(false),
  pinnedFirst: z.boolean().default(false),
  limit: z.number().int().min(1, "limit must be at least 1").max(100),
  orderBy: z.enum(["displayDate", "versionPublishedAt"]),
  orderDirection: z.enum(["asc", "desc"]),
});

export type PostCollectionQuery = z.infer<typeof postCollectionQuerySchema>;

export function parsePostCollectionQuery(input: unknown): PostCollectionQuery {
  return postCollectionQuerySchema.parse(input);
}

export function filterAndSortPublishedPosts(
  posts: readonly PublishedPost[],
  query: PostCollectionQuery,
  now = new Date(),
): PublishedPost[] {
  const requestedEntries = new Set(query.entryIds);
  const categories = new Set(query.categoryKeys);
  const tags = new Set(query.tagKeys);
  const nowMs = now.getTime();

  const filtered = posts.filter((post) => {
    if (post.expiresAt && Date.parse(post.expiresAt) <= nowMs) return false;
    if (requestedEntries.size > 0 && !requestedEntries.has(post.entryId)) return false;
    if (categories.size > 0 && !post.categoryKeys.some((key) => categories.has(key))) return false;
    if (tags.size > 0 && !post.tagKeys.some((key) => tags.has(key))) return false;
    if (query.featuredOnly && !post.featured) return false;
    return true;
  });

  filtered.sort((left, right) => {
    if (query.pinnedFirst && left.pinned !== right.pinned) return left.pinned ? -1 : 1;
    const comparison = Date.parse(left[query.orderBy]) - Date.parse(right[query.orderBy]);
    if (comparison !== 0) return query.orderDirection === "asc" ? comparison : -comparison;
    return left.entryId.localeCompare(right.entryId);
  });

  return filtered.slice(0, query.limit);
}
