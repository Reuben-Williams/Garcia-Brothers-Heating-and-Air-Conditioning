import type { PostCollectionQuery, PublishedPost } from "./collection-query.js";
import type { PostSnapshot } from "./post-schema.js";

export type ContentLifecycleStatus = "draft" | "scheduled" | "published" | "archived";

export interface ContentEntryRecord {
  entryId: string;
  siteId: string;
  contentType: "post";
  status: ContentLifecycleStatus;
  draftVersionId: string | null;
  publishedVersionId: string | null;
}

export interface ContentVersionRecord {
  versionId: string;
  entryId: string;
  siteId: string;
  snapshot: PostSnapshot;
  createdBy: string;
  createdAt: string;
}

export interface ContentAuditRecord {
  auditId: string;
  siteId: string;
  entryId: string;
  actorId: string;
  action: string;
  beforeVersionId: string | null;
  afterVersionId: string | null;
  summary: string;
  createdAt: string;
}

export interface ContentUnitOfWork {
  getEntryForUpdate(entryId: string): Promise<ContentEntryRecord | null>;
  getVersion(versionId: string): Promise<ContentVersionRecord | null>;
  appendVersion(input: Omit<ContentVersionRecord, "versionId" | "createdAt">): Promise<ContentVersionRecord>;
  updateEntryPointers(entry: ContentEntryRecord): Promise<void>;
  appendAudit(input: Omit<ContentAuditRecord, "auditId" | "createdAt">): Promise<ContentAuditRecord>;
  reserveIdempotencyKey(key: string, requestHash: string): Promise<"reserved" | "replayed">;
}

export interface ContentRepository {
  withTransaction<T>(operation: (unit: ContentUnitOfWork) => Promise<T>): Promise<T>;
  getPublishedPostBySlug(siteId: string, slug: string): Promise<PublishedPost | null>;
  listPublishedPosts(siteId: string, query: PostCollectionQuery): Promise<PublishedPost[]>;
}

