import { z } from "zod";

const linkMarkSchema = z.strictObject({
  type: z.literal("link"),
  attrs: z.strictObject({
    href: z.string().min(1).refine(
      (href) =>
        href.startsWith("/") ||
        href.startsWith("#") ||
        href.startsWith("mailto:") ||
        href.startsWith("tel:") ||
        /^https:\/\//i.test(href),
      "Link href uses an invalid or executable protocol.",
    ),
    target: z.enum(["_self", "_blank"]).optional(),
  }),
});

const textMarkSchema = z.union([
  z.strictObject({ type: z.enum(["bold", "italic", "underline", "strike", "code"]) }),
  linkMarkSchema,
]);

const textNodeSchema = z.strictObject({
  type: z.literal("text"),
  text: z.string(),
  marks: z.array(textMarkSchema).optional(),
});

type RichTextNodeInput =
  | z.infer<typeof textNodeSchema>
  | {
      type: "paragraph" | "blockquote" | "bulletList" | "orderedList" | "listItem";
      content?: RichTextNodeInput[];
    }
  | { type: "heading"; attrs: { level: 2 | 3 | 4 }; content?: RichTextNodeInput[] }
  | { type: "horizontalRule" | "hardBreak" };

const richTextNodeSchema: z.ZodType<RichTextNodeInput> = z.lazy(() =>
  z.union([
    textNodeSchema,
    z.strictObject({
      type: z.enum(["paragraph", "blockquote", "bulletList", "orderedList", "listItem"]),
      content: z.array(richTextNodeSchema).optional(),
    }),
    z.strictObject({
      type: z.literal("heading"),
      attrs: z.strictObject({ level: z.union([z.literal(2), z.literal(3), z.literal(4)]) }),
      content: z.array(richTextNodeSchema).optional(),
    }),
    z.strictObject({ type: z.enum(["horizontalRule", "hardBreak"]) }),
  ]),
);

export const richTextDocumentSchema = z.strictObject({
  version: z.literal(1),
  type: z.literal("doc"),
  content: z.array(richTextNodeSchema),
});

export type RichTextDocument = z.infer<typeof richTextDocumentSchema>;
