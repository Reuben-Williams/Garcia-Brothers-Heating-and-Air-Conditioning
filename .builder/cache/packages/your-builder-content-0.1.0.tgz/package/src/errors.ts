export class ContentPermissionError extends Error {
  readonly code = "CONTENT_PERMISSION_DENIED";
  constructor(message = "You do not have permission to perform this content operation.") {
    super(message);
    this.name = "ContentPermissionError";
  }
}

export class ContentSchemaError extends Error {
  readonly code = "CONTENT_SCHEMA_INVALID";
  constructor(message: string) {
    super(message);
    this.name = "ContentSchemaError";
  }
}

export class SlugConflictError extends Error {
  readonly code = "CONTENT_SLUG_CONFLICT";
  constructor(message: string) {
    super(message);
    this.name = "SlugConflictError";
  }
}

export class MediaReferenceError extends Error {
  readonly code = "CONTENT_MEDIA_INVALID";
  constructor(message: string) {
    super(message);
    this.name = "MediaReferenceError";
  }
}

export class ContentScheduleError extends Error {
  readonly code = "CONTENT_SCHEDULE_INVALID";
  constructor(message: string) {
    super(message);
    this.name = "ContentScheduleError";
  }
}

export class IdempotencyConflictError extends Error {
  readonly code = "CONTENT_IDEMPOTENCY_CONFLICT";
  constructor(message: string) {
    super(message);
    this.name = "IdempotencyConflictError";
  }
}

