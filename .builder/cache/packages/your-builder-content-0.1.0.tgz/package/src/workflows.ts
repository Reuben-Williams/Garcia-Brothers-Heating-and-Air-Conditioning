import { z } from "zod";

export interface ContentVersionState {
  draftVersionId: string | null;
  publishedVersionId: string | null;
}

export interface ContentTransitionExpectations {
  expectedDraftVersionId?: string | null;
  expectedPublishedVersionId?: string | null;
}

export class ContentConflictError extends Error {
  readonly code = "CONTENT_VERSION_CONFLICT";

  constructor(message: string) {
    super(message);
    this.name = "ContentConflictError";
  }
}

export function assertTransitionExpectations(
  actual: ContentVersionState,
  expected: ContentTransitionExpectations,
): void {
  if (
    expected.expectedDraftVersionId !== undefined &&
    actual.draftVersionId !== expected.expectedDraftVersionId
  ) {
    throw new ContentConflictError("The draft changed before this operation completed.");
  }
  if (
    expected.expectedPublishedVersionId !== undefined &&
    actual.publishedVersionId !== expected.expectedPublishedVersionId
  ) {
    throw new ContentConflictError("The published version changed before this operation completed.");
  }
}

const forbiddenIdentityKeys = new Set(["siteId", "siteKey", "tenantId", "organizationId"]);

function canonicalize(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonicalize);
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([key, child]) => [key, canonicalize(child)]),
    );
  }
  return value;
}

function assertNoTenantIdentity(payload: Record<string, unknown>): void {
  const supplied = Object.keys(payload).find((key) => forbiddenIdentityKeys.has(key));
  if (supplied) throw new TypeError(`${supplied} must come from the authenticated request context.`);
}

export async function sha256Json(value: unknown): Promise<string> {
  const bytes = new TextEncoder().encode(JSON.stringify(canonicalize(value)));
  const digest = await globalThis.crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function createIdempotencyRequestKey(
  operation: string,
  payload: Record<string, unknown>,
): Promise<string> {
  if (!operation.trim()) throw new TypeError("operation is required");
  assertNoTenantIdentity(payload);
  return `${operation}:${await sha256Json(payload)}`;
}

export type ContentTransitionOperation =
  | "saveDraft"
  | "publish"
  | "schedule"
  | "cancelSchedule"
  | "reschedule"
  | "archive"
  | "restoreDraft"
  | "rollback"
  | "undoRollback";

const baseTransitionSchema = z.strictObject({
  entryId: z.string().uuid(),
  expectedDraftVersionId: z.string().uuid().nullable(),
  expectedPublishedVersionId: z.string().uuid().nullable(),
  idempotencyKey: z.string().min(8, "idempotencyKey is required"),
});

const versionTransitionSchema = baseTransitionSchema.extend({
  sourceVersionId: z.string().uuid(),
});

const scheduleTransitionSchema = baseTransitionSchema
  .extend({ publishAt: z.string().datetime({ offset: true }) })
  .refine((input) => Date.parse(input.publishAt) > Date.now(), {
    path: ["publishAt"],
    message: "Schedule time must be in the future.",
  });

export function parseContentTransitionInput(operation: ContentTransitionOperation, input: unknown): unknown {
  switch (operation) {
    case "schedule":
    case "reschedule":
      return scheduleTransitionSchema.parse(input);
    case "rollback":
    case "undoRollback":
      return versionTransitionSchema.parse(input);
    default:
      return baseTransitionSchema.parse(input);
  }
}
