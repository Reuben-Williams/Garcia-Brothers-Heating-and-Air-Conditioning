import { z } from "zod";
import { richTextDocumentSchema } from "./rich-text.js";

export const managedMediaReferenceSchema = z.strictObject({
  kind: z.literal("managed"),
  mediaId: z.string().uuid(),
  revisionId: z.string().uuid(),
  alt: z.string().min(1),
});

export const staticMediaReferenceSchema = z.strictObject({
  kind: z.literal("static"),
  src: z.string().min(1),
  alt: z.string(),
});

export const mediaReferenceSchema = z.discriminatedUnion("kind", [
  managedMediaReferenceSchema,
  staticMediaReferenceSchema,
]);

const taxonomyValueSchema = z.strictObject({
  label: z.string().min(1),
  slug: z.string().min(1),
});

export const postSnapshotSchema = z.strictObject({
  slug: z.string().min(1).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Invalid post slug"),
  data: z.strictObject({
    title: z.string().min(1),
    excerpt: z.string(),
    body: richTextDocumentSchema,
    featuredImage: mediaReferenceSchema.nullable(),
    author: z.strictObject({
      key: z.string().min(1).nullable(),
      name: z.string().min(1),
    }),
    featured: z.boolean(),
    pinned: z.boolean(),
    seo: z.strictObject({
      title: z.string().min(1),
      description: z.string(),
      canonicalUrl: z.string().url().nullable(),
      socialImage: mediaReferenceSchema.nullable(),
      noIndex: z.boolean(),
    }),
  }),
  taxonomyKeys: z.strictObject({
    categories: z.array(z.string().min(1)),
    tags: z.array(z.string().min(1)),
  }),
  taxonomySnapshot: z.record(z.string(), taxonomyValueSchema),
  displayDate: z.string().datetime({ offset: true }),
  expiresAt: z.string().datetime({ offset: true }).nullable(),
});

export type PostSnapshot = z.infer<typeof postSnapshotSchema>;
export type MediaReference = z.infer<typeof mediaReferenceSchema>;

export function parsePostSnapshot(input: unknown): PostSnapshot {
  return postSnapshotSchema.parse(input);
}

