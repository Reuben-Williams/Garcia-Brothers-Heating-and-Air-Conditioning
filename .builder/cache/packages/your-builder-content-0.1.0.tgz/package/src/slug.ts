import { SlugConflictError } from "./errors.js";

const DEFAULT_RESERVED_SLUGS = new Set([
  "admin",
  "api",
  "editor",
  "login",
  "logout",
  "preview",
  "robots.txt",
  "sitemap.xml",
]);

export function normalizePostSlug(value: string, reserved = DEFAULT_RESERVED_SLUGS): string {
  const slug = value
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  if (!slug) throw new SlugConflictError("Post slug cannot be empty.");
  if (reserved.has(slug)) throw new SlugConflictError(`Post slug "${slug}" is reserved.`);
  return slug;
}

export interface DirectPostRedirect {
  fromSlug: string;
  entryId: string;
  currentSlug: string;
}

export function resolveDirectPostRedirect(
  requestedSlug: string,
  redirects: readonly DirectPostRedirect[],
): { entryId: string; slug: string } | null {
  const redirect = redirects.find((candidate) => candidate.fromSlug === requestedSlug);
  if (!redirect || redirect.currentSlug === requestedSlug) return null;
  return { entryId: redirect.entryId, slug: redirect.currentSlug };
}

