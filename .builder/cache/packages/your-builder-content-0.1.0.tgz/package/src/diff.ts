import type { MediaReference, PostSnapshot } from "./post-schema.js";

export interface ImagePreview {
  src?: string;
  mediaId?: string;
  revisionId?: string;
  alt: string;
}

export interface PostImageChange {
  field: string;
  before: ImagePreview | null;
  after: ImagePreview | null;
}

export interface PostSnapshotDiff {
  changedFields: string[];
  imageChanges: PostImageChange[];
  summary: string;
}

function imagePreview(image: MediaReference | null): ImagePreview | null {
  if (!image) return null;
  return image.kind === "static"
    ? { src: image.src, alt: image.alt }
    : { mediaId: image.mediaId, revisionId: image.revisionId, alt: image.alt };
}

function collectChangedFields(before: unknown, after: unknown, path: string, output: string[]): void {
  if (JSON.stringify(before) === JSON.stringify(after)) return;
  if (
    before &&
    after &&
    typeof before === "object" &&
    typeof after === "object" &&
    !Array.isArray(before) &&
    !Array.isArray(after)
  ) {
    const keys = new Set([
      ...Object.keys(before as Record<string, unknown>),
      ...Object.keys(after as Record<string, unknown>),
    ]);
    for (const key of keys) {
      collectChangedFields(
        (before as Record<string, unknown>)[key],
        (after as Record<string, unknown>)[key],
        path ? `${path}.${key}` : key,
        output,
      );
    }
    return;
  }
  output.push(path);
}

export function diffPostSnapshots(before: PostSnapshot, after: PostSnapshot): PostSnapshotDiff {
  const changedFields: string[] = [];
  collectChangedFields(before, after, "", changedFields);
  const imageChanges: PostImageChange[] = [];
  if (JSON.stringify(before.data.featuredImage) !== JSON.stringify(after.data.featuredImage)) {
    imageChanges.push({
      field: "data.featuredImage",
      before: imagePreview(before.data.featuredImage),
      after: imagePreview(after.data.featuredImage),
    });
  }
  if (JSON.stringify(before.data.seo.socialImage) !== JSON.stringify(after.data.seo.socialImage)) {
    imageChanges.push({
      field: "data.seo.socialImage",
      before: imagePreview(before.data.seo.socialImage),
      after: imagePreview(after.data.seo.socialImage),
    });
  }
  return {
    changedFields,
    imageChanges,
    summary: changedFields.length === 0 ? "No changes" : `Changed ${changedFields.join(", ")}`,
  };
}

