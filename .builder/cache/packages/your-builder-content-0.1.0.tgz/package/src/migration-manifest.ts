import { z } from "zod";
import { postSnapshotSchema } from "./post-schema.js";
import { sha256Json } from "./workflows.js";

const sha256Schema = z.string().regex(/^[a-f0-9]{64}$/i, "Expected a SHA-256 hash");

const sourceFileSchema = z.strictObject({
  path: z.string().min(1),
  sha256: sha256Schema,
  astFingerprint: sha256Schema,
});

const candidateSchema = z.strictObject({
  candidateId: z.string().min(1),
  sourceFile: z.string().min(1),
  sourceSpan: z.strictObject({ start: z.number().int().nonnegative(), end: z.number().int().positive() }),
  transform: z.enum(["replace-post-collection", "replace-post-card", "add-post-detail-route"]),
  fieldMappings: z.array(
    z.strictObject({ postField: z.string().min(1), sourceExpression: z.string().min(1) }),
  ),
  categoryMappings: z.record(z.string(), z.string().min(1)),
});

export const postMigrationManifestSchema = z
  .strictObject({
    schemaVersion: z.literal(1),
    toolVersion: z.string().min(1),
    manifestId: z.string().min(1),
    seedHash: sha256Schema,
    siteKey: z.string().min(1),
    sourceScopeKey: z.string().min(1),
    collectionRegionId: z.string().min(1),
    sourceFiles: z.array(sourceFileSchema).min(1),
    reviewedPatchSpec: z.strictObject({
      candidates: z.array(candidateSchema).min(1),
      detailRoute: z.strictObject({
        route: z.string().min(1),
        sourceFile: z.string().min(1),
        rendererExport: z.string().min(1),
      }),
      fallbackSource: z.strictObject({
        sourceFile: z.string().min(1),
        exportName: z.string().min(1),
      }),
      collectionRenderer: z.strictObject({
        sourceFile: z.string().min(1),
        exportName: z.string().min(1),
        variant: z.string().min(1),
      }),
    }),
    records: z
      .array(
        z.strictObject({
          sourceRecordKey: z.string().min(1),
          entryId: z.string().uuid(),
          fallbackEntryId: z.string().uuid(),
          approvedFields: postSnapshotSchema,
        }),
      )
      .min(1),
    generatedArtifacts: z.array(z.unknown()),
  })
  .superRefine((manifest, context) => {
    for (const [index, record] of manifest.records.entries()) {
      if (record.entryId !== record.fallbackEntryId) {
        context.addIssue({
          code: "custom",
          path: ["records", index, "fallbackEntryId"],
          message: "Fallback entry identity must match the stable entry ID.",
        });
      }
    }
  });

export type PostMigrationManifest = z.infer<typeof postMigrationManifestSchema>;

export function parsePostMigrationManifest(input: unknown): PostMigrationManifest {
  return postMigrationManifestSchema.parse(input);
}

export function createSeedHash(input: unknown): Promise<string> {
  return sha256Json(input);
}

