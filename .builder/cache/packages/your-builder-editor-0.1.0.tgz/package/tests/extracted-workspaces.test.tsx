import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import { HistoryWorkspace, MediaWorkspace } from "@your-builder/editor";

const asset = {
  id: "asset-1",
  siteId: "site-1",
  url: "/asset.jpg",
  path: "campaign/asset.jpg",
  label: "Gallery asset",
  alt: "Gallery asset alt",
  mimeType: "image/jpeg",
  source: "upload" as const,
  createdAt: "2026-07-12T00:00:00.000Z",
  userId: "owner-1",
};

describe("extracted editor workspaces", () => {
  it("preserves the media workspace actions and technical details", () => {
    const html = renderToStaticMarkup(<MediaWorkspace mediaAssets={[asset]} />);
    expect(html).toContain('aria-label="Media workspace"');
    expect(html).toContain('title="Open Gallery asset"');
    expect(html).toContain('aria-label="Favorite Gallery asset"');
    expect(html).toContain("Show details");
  });

  it("preserves history formatting and restore controls", () => {
    const html = renderToStaticMarkup(
      <HistoryWorkspace
        pages={[{ path: "/", label: "Home", regions: [] }]}
        onRestoreVersion={vi.fn()}
        auditLog={[{
          id: "event-1",
          siteId: "site-1",
          pagePath: "/",
          action: "draft.saved",
          userId: "owner-1",
          userLabel: "Owner",
          createdAt: "2026-07-12T00:00:00.000Z",
          summary: "Changed hero title",
          regionId: "home.hero.title",
          kind: "text",
          before: { type: "text", value: "Old" },
          after: { type: "text", value: "New" },
        }]}
      />,
    );
    expect(html).toContain('aria-label="History workspace"');
    expect(html).toContain("Updated Hero Title text");
    expect(html).toContain("Restore previous version");
    expect(html).toContain("Expand to review details");
  });
});
