import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import {
  EditorShell,
  type BuilderShellRegistration,
  type EditorShellProps,
} from "@your-builder/editor";

function renderShell(props: Partial<EditorShellProps> = {}) {
  return renderToStaticMarkup(
    <EditorShell
      siteId="test-site"
      currentPath="/"
      pages={[{ path: "/", label: "Home", regions: [] }]}
      previewBaseUrl="https://client.example"
      {...props}
    />,
  );
}

describe("editor shell regression contract", () => {
  it("preserves the public shell contract", () => {
    const html = renderShell();

    expect(html).toContain("data-builder-editor-shell");
    expect(html).toContain("data-builder-preview-frame");
    expect(html).toContain('data-builder-workspace="website"');
    expect(html).toContain('aria-label="Site pages"');
    expect(html.match(/id="builder-region-value"/g) ?? []).toHaveLength(0);
  });

  it("renders selected-region controls exactly once on the server desktop default", () => {
    const html = renderShell({
      selectedRegion: { id: "home.hero.title", kind: "text", label: "Hero title", value: "Headline" },
    });

    expect(html.match(/id="builder-region-value"/g) ?? []).toHaveLength(1);
    expect(html).toContain('aria-label="Editing controls"');
  });

  it("hosts registered workspaces inside the existing shell without replacing the preview", () => {
    const registration: BuilderShellRegistration = {
      modules: [],
      workspaces: [{
        id: "growth.dashboard",
        label: "Dashboard",
        group: "growth",
        icon: "layout-dashboard",
        render: () => <p data-testid="registered-dashboard">Registered dashboard</p>,
      }],
      globalHeader: <p data-testid="global-indicator">3 new submissions</p>,
    };

    const html = renderShell({
      registration,
      initialWorkspace: "growth.dashboard",
    });

    expect(html.match(/data-builder-app-shell/g) ?? []).toHaveLength(1);
    expect(html).toContain('data-builder-workspace="growth.dashboard"');
    expect(html).toContain('data-testid="registered-dashboard"');
    expect(html).toContain('data-testid="global-indicator"');
    expect(html).toContain("data-builder-preview-frame");
  });
});
