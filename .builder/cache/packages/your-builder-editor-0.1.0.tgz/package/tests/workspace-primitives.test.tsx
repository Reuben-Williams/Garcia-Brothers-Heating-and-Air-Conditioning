import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { renderToStaticMarkup } from "react-dom/server";
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  ActivityTimeline,
  AsyncStatus,
  BulkToolbar,
  CollectionToolbar,
  ConfirmationDialog,
  DestructiveActionGuard,
  OverflowMenu,
  RecordDetailLayout,
  ResponsiveCollection,
  StatusBadge,
  WorkspaceState,
} from "@your-builder/editor";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

let container: HTMLDivElement | null = null;
let root: Root | null = null;

afterEach(async () => {
  if (root) await act(async () => root?.unmount());
  root = null;
  container?.remove();
  container = null;
  document.body.style.overflow = "";
  document.documentElement.style.overflow = "";
});

describe("workspace primitives", () => {
  it("renders announced status, non-color badges, state actions, and toolbar slots", () => {
    const html = renderToStaticMarkup(
      <section>
        <AsyncStatus message="Submissions refreshed" />
        <StatusBadge tone="warning">Spam review</StatusBadge>
        <WorkspaceState
          kind="denied"
          title="Access denied"
          description="Ask an owner for access."
          action={<button type="button">Return to website</button>}
        />
        <CollectionToolbar
          search={<input aria-label="Search submissions" />}
          filters={<button type="button">Filters</button>}
          sort={<button type="button">Sort</button>}
          savedView={<button type="button">New</button>}
          actions={<button type="button">Export</button>}
        />
      </section>,
    );

    expect(html).toContain('data-builder-async-status="true"');
    expect(html).toContain('role="status"');
    expect(html).toContain('aria-live="polite"');
    expect(html).toContain('data-status-tone="warning"');
    expect(html).toContain("Spam review");
    expect(html).toContain('data-workspace-state="denied"');
    expect(html).toContain('data-collection-toolbar="true"');
    expect(html).toContain("Search submissions");
    expect(html).toContain("Export");
  });

  it("renders stable desktop/mobile collections, detail slots, timeline, and bulk actions", () => {
    const html = renderToStaticMarkup(
      <section>
        <ResponsiveCollection
          desktop={<table><tbody><tr><td>Desktop row</td></tr></tbody></table>}
          mobile={<ul><li>Mobile row</li></ul>}
        />
        <RecordDetailLayout
          title="Jordan Lee"
          eyebrow="Submission"
          backAction={<button type="button">Back to submissions</button>}
          status={<StatusBadge tone="neutral">New</StatusBadge>}
          actions={<button type="button">Mark spam</button>}
          summary={<p>Heat repair request</p>}
          aside={<p>Captured today</p>}
        >
          <p>Submission fields</p>
        </RecordDetailLayout>
        <ActivityTimeline items={[{
          id: "event-1",
          title: "Submission received",
          description: "Website contact form",
          occurredAt: "2026-07-18T12:00:00.000Z",
        }]} />
        <BulkToolbar selectedCount={2} onClear={() => undefined} actions={<button type="button">Mark spam</button>} />
      </section>,
    );

    expect(html).toContain('data-responsive-collection="true"');
    expect(html).toContain('data-collection-surface="desktop"');
    expect(html).toContain('data-collection-surface="mobile"');
    expect(html).toContain('data-record-detail="true"');
    expect(html).toContain("Back to submissions");
    expect(html).toContain('data-activity-timeline="true"');
    expect(html).toContain('dateTime="2026-07-18T12:00:00.000Z"');
    expect(html).toContain('data-bulk-toolbar="true"');
    expect(html).toContain("2 selected");
  });

  it("locks responsive, focus, and target-size CSS contracts", () => {
    const css = readFileSync(resolve("packages/editor/src/workspaces/workspaces.module.css"), "utf8");
    expect(css).toMatch(/overflow-x:\s*clip/);
    expect(css).toMatch(/min-height:\s*44px/);
    expect(css).toMatch(/min-width:\s*44px/);
    expect(css).toMatch(/:focus-visible/);
    expect(css).toMatch(/@media \(max-width:\s*1023px\)/);
  });

  it("operates overflow actions by keyboard and restores trigger focus", async () => {
    const selected = vi.fn();
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => root?.render(
      <OverflowMenu
        label="Submission actions"
        items={[{ id: "spam", label: "Mark as spam", onSelect: selected, destructive: true }]}
      />,
    ));
    const trigger = container.querySelector<HTMLButtonElement>('[aria-label="Submission actions"]');
    trigger?.focus();
    await act(async () => trigger?.click());
    expect(container.querySelector('[role="menu"]')).toBeTruthy();
    expect(document.activeElement?.textContent).toContain("Mark as spam");

    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })));
    expect(container.querySelector('[role="menu"]')).toBeNull();
    expect(document.activeElement).toBe(trigger);
  });

  it("guards destructive actions with a modal, scroll lock, and confirmation", async () => {
    const confirm = vi.fn();
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => root?.render(
      <DestructiveActionGuard
        triggerLabel="Mark as spam"
        title="Mark submission as spam?"
        description="The submission moves to Spam Review."
        confirmLabel="Mark as spam"
        onConfirm={confirm}
      />,
    ));
    const trigger = container.querySelector<HTMLButtonElement>('[data-destructive-trigger]');
    await act(async () => trigger?.click());
    expect(container.querySelector('[role="dialog"]')).toBeTruthy();
    expect(document.body.style.overflow).toBe("hidden");

    const confirmButton = Array.from(container.querySelectorAll("button")).find(
      (button) => button.textContent === "Mark as spam" && button !== trigger,
    );
    await act(async () => confirmButton?.click());
    expect(confirm).toHaveBeenCalledTimes(1);
    expect(container.querySelector('[role="dialog"]')).toBeNull();
    expect(document.body.style.overflow).toBe("");
    expect(document.activeElement).toBe(trigger);
  });

  it("requires and forwards an owner reason for auditable destructive requests", async () => {
    const confirm = vi.fn();
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => root?.render(
      <DestructiveActionGuard
        triggerLabel="Request deletion"
        title="Request customer deletion?"
        description="This request is reviewed before customer data is removed."
        confirmLabel="Submit request"
        reasonLabel="Reason for deletion"
        requireReason
        onConfirm={confirm}
      />,
    ));

    await act(async () => container?.querySelector<HTMLButtonElement>("[data-destructive-trigger]")?.click());
    const input = container?.querySelector<HTMLInputElement>('[aria-label="Reason for deletion"]');
    const submit = Array.from(container?.querySelectorAll<HTMLButtonElement>("button") ?? []).find(
      (button) => button.textContent === "Submit request",
    );
    expect(input).toBeTruthy();
    expect(submit?.disabled).toBe(true);

    if (input) {
      await act(async () => {
        const valueSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
        valueSetter?.call(input, "Customer requested account removal");
        input.dispatchEvent(new Event("input", { bubbles: true }));
      });
    }
    expect(submit?.disabled).toBe(false);
    await act(async () => submit?.click());
    expect(confirm).toHaveBeenCalledWith("Customer requested account removal");
  });

  it("exposes the confirmation dialog as a controlled primitive", () => {
    const html = renderToStaticMarkup(
      <ConfirmationDialog
        open
        title="Confirm export"
        description="Export the filtered submissions."
        confirmLabel="Request export"
        onCancel={() => undefined}
        onConfirm={() => undefined}
      />,
    );
    expect(html).toContain('role="dialog"');
    expect(html).toContain('aria-modal="true"');
    expect(html).toContain("Request export");
  });
});
