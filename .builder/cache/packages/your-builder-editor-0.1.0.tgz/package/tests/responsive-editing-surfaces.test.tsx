import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, describe, expect, it, vi } from "vitest";
import { EditorShell, MobileBottomSheet } from "@your-builder/editor";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

type ChangeListener = (event: MediaQueryListEvent) => void;

function installMatchMedia(initialMatches = false) {
  let matches = initialMatches;
  const listeners = new Set<ChangeListener>();
  const mediaQueryList = {
    get matches() {
      return matches;
    },
    media: "(max-width: 767px)",
    onchange: null,
    addEventListener: vi.fn((_type: string, listener: ChangeListener) => listeners.add(listener)),
    removeEventListener: vi.fn((_type: string, listener: ChangeListener) => listeners.delete(listener)),
    addListener: vi.fn(),
    removeListener: vi.fn(),
    dispatchEvent: vi.fn(),
    change(nextMatches: boolean) {
      matches = nextMatches;
      listeners.forEach((listener) => listener({ matches, media: this.media } as MediaQueryListEvent));
    },
  };
  vi.stubGlobal("matchMedia", vi.fn(() => mediaQueryList));
  return mediaQueryList;
}

function shell() {
  return (
    <EditorShell
      siteId="test-site"
      currentPath="/"
      pages={[{ path: "/", label: "Home", regions: [] }]}
      previewBaseUrl="https://client.example"
      selectedRegion={{ id: "home.hero.title", kind: "text", label: "Hero title", value: "Original headline" }}
    />
  );
}

let root: Root | null = null;
let container: HTMLDivElement | null = null;

afterEach(async () => {
  try {
    if (root) await act(async () => root?.unmount());
  } finally {
    root = null;
    container?.remove();
    container = null;
    vi.unstubAllGlobals();
    document.body.style.overflow = "";
  }
});

describe("responsive editing surfaces", () => {
  it("renders selected-region controls once in the desktop editing aside", async () => {
    installMatchMedia(false);
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root?.render(shell()));

    expect(container.querySelectorAll("#builder-region-value")).toHaveLength(1);
    expect(container.querySelector('aside[aria-label="Editing controls"]')).toBeTruthy();
    expect(container.querySelector('[role="dialog"][aria-modal="true"]')).toBeNull();
  });

  it("renders one mobile dialog without moving the toolbar into it", async () => {
    installMatchMedia(true);
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root?.render(shell()));

    const dialog = container.querySelector<HTMLElement>('[role="dialog"][aria-modal="true"]');
    expect(dialog).toBeTruthy();
    expect(dialog?.textContent).toContain("Hero title");
    expect(dialog?.querySelector('button[aria-label="Close editing controls"]')).toBeTruthy();
    expect(container.querySelectorAll("#builder-region-value")).toHaveLength(1);
    expect(dialog?.textContent).not.toContain("Save draft");
    expect(container.textContent).toContain("Save draft");
    expect(document.body.style.overflow).toBe("hidden");
  });

  it("preserves an in-progress field value when the breakpoint changes", async () => {
    const mediaQueryList = installMatchMedia(false);
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root?.render(shell()));

    const field = container.querySelector<HTMLTextAreaElement>("#builder-region-value");
    expect(field).toBeTruthy();
    await act(async () => {
      if (!field) return;
      const valueSetter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      valueSetter?.call(field, "Unsaved mobile-safe draft");
      field.dispatchEvent(new Event("input", { bubbles: true }));
    });

    await act(async () => mediaQueryList.change(true));
    expect(container.querySelector<HTMLTextAreaElement>("#builder-region-value")?.value).toBe(
      "Unsaved mobile-safe draft",
    );
    expect(container.querySelectorAll("#builder-region-value")).toHaveLength(1);
  });

  it("reconciles same-region upstream updates without overwriting a dirty draft", async () => {
    installMatchMedia(false);
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    const renderRegion = (id: string, value: string, kind: "text" | "richText" = "text") => (
      <EditorShell
        siteId="test-site"
        currentPath="/"
        pages={[{ path: "/", label: "Home", regions: [] }]}
        previewBaseUrl="https://client.example"
        selectedRegion={{ id, kind, label: "Hero title", value }}
      />
    );

    await act(async () => root?.render(renderRegion("home.hero.title", "Initial")));
    let field = container.querySelector<HTMLTextAreaElement>("#builder-region-value");
    await act(async () => {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      setter?.call(field, "Local draft");
      field?.dispatchEvent(new Event("input", { bubbles: true }));
    });

    await act(async () => root?.render(renderRegion("home.hero.title", "Conflicting upstream")));
    expect(container.querySelector<HTMLTextAreaElement>("#builder-region-value")?.value).toBe("Local draft");

    await act(async () => root?.render(renderRegion("home.hero.title", "Local draft")));
    await act(async () => root?.render(renderRegion("home.hero.title", "Accepted after acknowledgment")));
    expect(container.querySelector<HTMLTextAreaElement>("#builder-region-value")?.value).toBe(
      "Accepted after acknowledgment",
    );

    field = container.querySelector<HTMLTextAreaElement>("#builder-region-value");
    await act(async () => {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      setter?.call(field, "Second local draft");
      field?.dispatchEvent(new Event("input", { bubbles: true }));
    });
    await act(async () => root?.render(renderRegion("home.hero.subtitle", "Different region")));
    expect(container.querySelector<HTMLTextAreaElement>("#builder-region-value")?.value).toBe("Different region");
    await act(async () => root?.render(renderRegion("home.hero.subtitle", "Different kind", "richText")));
    expect(container.querySelector<HTMLTextAreaElement>("#builder-region-value")?.value).toBe("Different kind");
  });

  it("reopens dismissed editing controls for the same selected region", async () => {
    installMatchMedia(true);
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root?.render(shell()));

    const close = container.querySelector<HTMLButtonElement>('button[aria-label="Close editing controls"]');
    await act(async () => close?.click());
    expect(container.querySelector('[role="dialog"]')).toBeNull();
    const reopen = container.querySelector<HTMLButtonElement>('button[aria-label="Open editing controls"]');
    expect(reopen).toBeTruthy();
    expect(reopen?.textContent).toContain("Edit");

    await act(async () => reopen?.click());
    expect(container.querySelector('[role="dialog"][aria-modal="true"]')).toBeTruthy();
  });

  it("contains focus, closes on Escape, and restores prior focus", async () => {
    const trigger = document.createElement("button");
    trigger.textContent = "Open editor";
    document.body.append(trigger);
    trigger.focus();
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    function Harness() {
      const [open, setOpen] = React.useState(true);
      const [value, setValue] = React.useState("");
      return (
        <MobileBottomSheet open={open} title="Hero title" onClose={() => setOpen(false)}>
          <input aria-label="Draft title" value={value} onChange={(event) => setValue(event.target.value)} />
        </MobileBottomSheet>
      );
    }

    await act(async () => root?.render(<Harness />));
    const closeButton = container.querySelector<HTMLButtonElement>('button[aria-label="Close editing controls"]');
    const input = container.querySelector<HTMLInputElement>('input[aria-label="Draft title"]');
    expect(document.activeElement).toBe(closeButton);

    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", shiftKey: true })));
    expect(document.activeElement).toBe(input);
    await act(async () => {
      const valueSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      valueSetter?.call(input, "A");
      input?.dispatchEvent(new Event("input", { bubbles: true }));
    });
    expect(input?.value).toBe("A");
    expect(document.activeElement).toBe(input);

    trigger.focus();
    expect(document.activeElement).toBe(closeButton);
    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab" })));
    expect(document.activeElement).toBe(closeButton);
    trigger.focus();
    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", shiftKey: true })));
    expect(document.activeElement).toBe(input);
    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab" })));
    expect(document.activeElement).toBe(closeButton);

    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape" })));
    expect(container.querySelector('[role="dialog"]')).toBeNull();
    expect(document.activeElement).toBe(trigger);
    expect(document.body.style.overflow).toBe("");
    trigger.remove();
  });

  it("keeps collapsed history actions out of the mobile sheet focus order", async () => {
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    function HistoryHarness() {
      return (
        <MobileBottomSheet open title="Hero title" onClose={() => {}}>
          <details>
            <summary>History entry</summary>
            <button type="button">Restore previous version</button>
          </details>
        </MobileBottomSheet>
      );
    }

    await act(async () => root?.render(<HistoryHarness />));
    const closeButton = container.querySelector<HTMLButtonElement>('button[aria-label="Close editing controls"]');
    const details = container.querySelector<HTMLDetailsElement>("details");
    const summary = container.querySelector<HTMLElement>("summary");
    const restore = Array.from(container.querySelectorAll<HTMLButtonElement>("button")).find(
      (button) => button.textContent?.trim() === "Restore previous version",
    );

    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", shiftKey: true })));
    expect(document.activeElement).toBe(summary);
    expect(document.activeElement).not.toBe(restore);

    if (details) details.open = true;
    closeButton?.focus();
    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", shiftKey: true })));
    expect(document.activeElement).toBe(restore);
  });
});
