import { describe, expect, it } from "vitest";
import { getVisibleFocusableElements } from "../src/shell/focusableElements.js";

describe("getVisibleFocusableElements", () => {
  it("includes summaries while excluding hidden controls and collapsed details descendants", () => {
    const container = document.createElement("section");
    container.innerHTML = `
      <button>Visible</button>
      <button hidden>Hidden</button>
      <div aria-hidden="true"><button>Aria hidden</button></div>
      <details><summary>Closed summary</summary><button>Closed action</button></details>
      <details open><summary>Open summary</summary><button>Open action</button></details>
    `;
    document.body.append(container);

    expect(getVisibleFocusableElements(container).map((element) => element.textContent?.trim())).toEqual([
      "Visible",
      "Closed summary",
      "Open summary",
      "Open action",
    ]);
    container.remove();
  });
});
