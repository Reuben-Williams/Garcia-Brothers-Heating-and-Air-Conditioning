import React, { act, useState } from "react";
import { createRoot } from "react-dom/client";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { WebsitePreviewWorkspace, WorkspaceRegistryHost } from "@your-builder/editor";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

describe("workspace registry host", () => {
  const growthWorkspace = {
    id: "growth.dashboard" as const,
    label: "Overview",
    group: "growth" as const,
    icon: "layout-dashboard",
    render: () => <p>Overview</p>,
  };

  it("accepts the entitlement-independent Submissions workspace id", () => {
    const html = renderToStaticMarkup(
      <WorkspaceRegistryHost
        activeWorkspace="website.submissions"
        website={<p>Website preview</p>}
        workspaces={[{
          id: "website.submissions",
          label: "Submissions",
          group: "website",
          icon: "inbox",
          render: () => <p>Submission inbox</p>,
        }]}
      />,
    );

    expect(html).toContain('data-builder-workspace="website.submissions"');
    expect(html).toContain("Submission inbox");
  });

  it("keeps the website workspace mounted while another workspace is active", () => {
    const html = renderToStaticMarkup(
      <WorkspaceRegistryHost
        activeWorkspace="growth.dashboard"
        website={
          <WebsitePreviewWorkspace>
            <iframe data-builder-preview-frame src="https://example.test" />
          </WebsitePreviewWorkspace>
        }
        workspaces={[growthWorkspace]}
      />,
    );

    expect(html).toContain("data-builder-preview-frame");
    expect(html).toContain('data-builder-workspace="website"');
    expect(html).toContain('data-builder-workspace-active="false"');
    expect(html).toContain("hidden");
    expect(html).toContain("Overview");
  });

  it("shows the persistent website workspace for website workspace ids", () => {
    const html = renderToStaticMarkup(
      <WorkspaceRegistryHost
        activeWorkspace="website.pages"
        website={<p>Website preview</p>}
        workspaces={[growthWorkspace]}
      />,
    );

    expect(html).toContain('data-builder-workspace-active="true"');
    expect(html).not.toContain("hidden");
    expect(html).toContain("Website preview");
    expect(html).not.toContain("Overview");
  });

  it("fails closed to the website workspace for an unknown id", () => {
    const html = renderToStaticMarkup(
      <WorkspaceRegistryHost
        activeWorkspace={"growth.unavailable" as "growth.dashboard"}
        website={<p>Website preview</p>}
        workspaces={[growthWorkspace]}
      />,
    );

    expect(html).toContain("Website preview");
    expect(html).toContain('data-builder-workspace-active="true"');
    expect(html).not.toContain("hidden");
    expect(html).not.toContain("Overview");
  });

  it("isolates hooks when switching between registered workspace renderers", async () => {
    const container = document.createElement("div");
    const root = createRoot(container);
    const workspaces = [
      {
        ...growthWorkspace,
        render: () => {
          const [label] = useState("Overview with hooks");
          return <p>{label}</p>;
        },
      },
      {
        id: "growth.leads" as const,
        label: "Leads",
        group: "growth" as const,
        icon: "users",
        render: () => {
          const [label] = useState("Leads with hooks");
          return <p>{label}</p>;
        },
      },
    ];

    try {
      await act(async () => {
        root.render(
          <WorkspaceRegistryHost
            activeWorkspace="growth.dashboard"
            website={<p>Website preview</p>}
            workspaces={workspaces}
          />,
        );
      });
      expect(container.textContent).toContain("Overview with hooks");

      await act(async () => {
        root.render(
          <WorkspaceRegistryHost
            activeWorkspace="growth.leads"
            website={<p>Website preview</p>}
            workspaces={workspaces}
          />,
        );
      });
      expect(container.textContent).toContain("Leads with hooks");
    } finally {
      await act(async () => root.unmount());
    }
  });
});
