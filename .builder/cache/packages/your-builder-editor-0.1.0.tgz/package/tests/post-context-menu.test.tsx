import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { computeContextMenuPosition, PostContextMenu } from "../src/content/PostContextMenu.js";

describe("PostContextMenu", () => {
  it("shows stable post actions and manual collection controls", () => {
    const html = renderToStaticMarkup(
      <PostContextMenu
        entryId="entry-uuid"
        regionId="home.communityAnnouncements"
        collectionMode="manual"
        position={{ left: 100, top: 120 }}
        onEdit={() => undefined}
        onChooseAnother={() => undefined}
        onOpenDetail={() => undefined}
        onViewHistory={() => undefined}
        onRemove={() => undefined}
        onClose={() => undefined}
      />,
    );

    expect(html).toContain('data-builder-entry-id="entry-uuid"');
    expect(html).toContain("Edit post");
    expect(html).toContain("Choose another post");
    expect(html).toContain("Open detail page");
    expect(html).toContain("View history");
    expect(html).toContain("Remove from collection");
  });

  it("does not offer manual removal for query collections", () => {
    const html = renderToStaticMarkup(
      <PostContextMenu
        entryId="entry-uuid"
        regionId="home.communityAnnouncements"
        collectionMode="query"
        position={{ left: 0, top: 0 }}
        onEdit={() => undefined}
        onOpenDetail={() => undefined}
        onViewHistory={() => undefined}
        onClose={() => undefined}
      />,
    );

    expect(html).not.toContain("Choose another post");
    expect(html).not.toContain("Remove from collection");
  });

  it("clamps the menu inside the visible editor window", () => {
    expect(computeContextMenuPosition({ x: 980, y: 740 }, { width: 1000, height: 760 }, { width: 260, height: 280 }))
      .toEqual({ left: 724, top: 464 });
    expect(computeContextMenuPosition({ x: -20, y: -10 }, { width: 1000, height: 760 }, { width: 260, height: 280 }))
      .toEqual({ left: 16, top: 16 });
  });
});
