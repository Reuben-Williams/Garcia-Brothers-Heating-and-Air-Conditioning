import { describe, expect, it } from "vitest";
import { DEMO_LEADS } from "@your-builder/testing";
import { createDemoAdapter } from "../src/modules/demo-adapter.js";

describe("createDemoAdapter", () => {
  it("uses deterministic fictional data and declares zero external effects", () => {
    const adapter = createDemoAdapter(DEMO_LEADS);
    expect(adapter.externalEffects).toBe(false);
    expect(adapter.list()).toEqual(DEMO_LEADS);
    expect(adapter.list().every((lead) => lead.email.endsWith("@example.test"))).toBe(true);
  });

  it("returns clones, supports local mutations, and resets to the seed", () => {
    const adapter = createDemoAdapter(DEMO_LEADS);
    const first = adapter.list() as Array<(typeof DEMO_LEADS)[number]>;
    first[0] = { ...first[0], name: "Changed outside" };
    expect(adapter.list()[0]?.name).toBe("Ada Brooks");

    expect(adapter.update("demo-lead-ada", { status: "qualified" }).status).toBe("qualified");
    expect(adapter.list()[0]?.status).toBe("qualified");

    adapter.reset();
    expect(adapter.list()).toEqual(DEMO_LEADS);
  });

  it("rejects unknown records without changing data", () => {
    const adapter = createDemoAdapter(DEMO_LEADS);
    expect(() => adapter.update("missing", { status: "qualified" })).toThrow("Unknown demo record: missing");
    expect(adapter.list()).toEqual(DEMO_LEADS);
  });
});
