import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, describe, expect, it, vi } from "vitest";
import { MediaWorkspace } from "@your-builder/editor";
import { acquireBodyScrollLock } from "../src/shell/bodyScrollLock.js";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const asset = {
  id: "asset-1",
  siteId: "site-1",
  url: "/asset.jpg",
  path: "campaign/asset.jpg",
  label: "Gallery asset",
  alt: "Gallery asset alt",
  mimeType: "image/jpeg",
  source: "upload" as const,
  createdAt: "2026-07-12T00:00:00.000Z",
  userId: "owner-1",
};

let root: Root | null = null;
let container: HTMLDivElement | null = null;

afterEach(async () => {
  try {
    if (root) await act(async () => root?.unmount());
  } finally {
    root = null;
    container?.remove();
    container = null;
    document.body.style.overflow = "";
    document.documentElement.style.overflow = "";
    window.localStorage.clear();
    vi.restoreAllMocks();
  }
});

describe("MediaWorkspace interactions", () => {
  it("provides modal focus, keyboard close, restoration, and overlapping scroll locks", async () => {
    const outside = document.createElement("button");
    outside.textContent = "Outside";
    document.body.append(outside);
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root?.render(<MediaWorkspace mediaAssets={[asset]} />));

    const open = container.querySelector<HTMLButtonElement>('button[title="Open Gallery asset"]');
    open?.focus();
    const releaseOuterLock = acquireBodyScrollLock();
    await act(async () => open?.click());

    const dialog = container.querySelector<HTMLElement>('[role="dialog"][aria-modal="true"]');
    const close = dialog?.querySelector<HTMLButtonElement>('button[aria-label="Close media preview"]');
    const favorite = Array.from(dialog?.querySelectorAll<HTMLButtonElement>("button") ?? []).find(
      (button) => button.textContent?.trim() === "Favorite",
    );
    const technicalSummary = Array.from(dialog?.querySelectorAll<HTMLElement>("summary") ?? []).find(
      (summary) => summary.textContent?.trim() === "Show technical details",
    );
    expect(dialog).toBeTruthy();
    expect(favorite).toBeTruthy();
    expect(document.activeElement).toBe(close);
    expect(document.body.style.overflow).toBe("hidden");

    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", shiftKey: true })));
    expect(document.activeElement).toBe(technicalSummary);
    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab" })));
    expect(document.activeElement).toBe(close);

    outside.focus();
    expect(document.activeElement).toBe(close);
    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab" })));
    expect(document.activeElement).toBe(close);
    outside.focus();
    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", shiftKey: true })));
    expect(document.activeElement).toBe(technicalSummary);

    await act(async () => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape" })));
    expect(container.querySelector('[role="dialog"]')).toBeNull();
    expect(document.activeElement).toBe(open);
    expect(document.body.style.overflow).toBe("hidden");
    releaseOuterLock();
    expect(document.body.style.overflow).toBe("");
    outside.remove();
  });

  it("keeps favorite UI responsive when localStorage writes fail", async () => {
    vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
      throw new DOMException("Quota exceeded", "QuotaExceededError");
    });
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root?.render(<MediaWorkspace mediaAssets={[asset]} />));

    const favorite = container.querySelector<HTMLButtonElement>('button[aria-label="Favorite Gallery asset"]');
    await expect(act(async () => favorite?.click())).resolves.toBeUndefined();
    expect(container.querySelector('button[aria-label="Remove Gallery asset from favorites"]')).toBeTruthy();
  });
});
