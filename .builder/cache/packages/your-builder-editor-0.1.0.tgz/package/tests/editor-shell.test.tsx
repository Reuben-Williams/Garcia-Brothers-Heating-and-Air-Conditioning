import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { buildPreviewUrl, EditorShell, resizeViewportWidth } from "@your-builder/editor";

describe("editor shell", () => {
  it("preserves a hosted base path when building preview URLs", () => {
    expect(buildPreviewUrl("https://client.example/Campaign-Website-V1/", "/about", "demo-site")).toBe(
      "https://client.example/Campaign-Website-V1/about?builderPreview=1&builderSiteId=demo-site",
    );
  });

  it("resizes symmetrically from either canvas edge", () => {
    expect(resizeViewportWidth(820, 40, "right")).toBe(900);
    expect(resizeViewportWidth(820, 40, "left")).toBe(740);
  });

  it("renders the selected viewport as the iframe width instead of only scaling the preview", () => {
    const html = renderToStaticMarkup(
      <EditorShell
        siteId="demo-site"
        currentPath="/"
        pages={[{ path: "/", label: "Home", regions: ["home.hero.title"] }]}
        previewBaseUrl="https://client.example"
        defaultViewport="mobile"
        defaultZoom={0.8}
      />,
    );

    expect(html).toContain('data-builder-viewport="mobile"');
    expect(html).toContain("Mobile");
    expect(html).toContain("390px");
    expect(html).toContain("844px");
    expect(html).toContain("80%");
  });

  it("supports custom viewport presets and exposes the active width for responsive verification", () => {
    const html = renderToStaticMarkup(
      <EditorShell
        siteId="demo-site"
        currentPath="/"
        pages={[{ path: "/", label: "Home", regions: ["home.hero.title"] }]}
        previewBaseUrl="https://client.example"
        defaultViewport="narrow"
        viewportPresets={[{ id: "narrow", label: "Narrow", width: 360, height: 740 }]}
      />,
    );

    expect(html).toContain('data-builder-viewport="narrow"');
    expect(html).toContain('data-builder-viewport-width="360"');
    expect(html).toContain("Narrow");
    expect(html).toContain("360px");
  });

  it("renders a zoomed preview, page navigation, save controls, and rollback history", () => {
    const html = renderToStaticMarkup(
      <EditorShell
        siteId="demo-site"
        currentPath="/"
        pages={[
          { path: "/", label: "Home", regions: ["home.hero.title"] },
          { path: "/about", label: "About", regions: ["about.hero.title"] },
        ]}
        previewBaseUrl="https://client.example"
        selectedRegion={{
          id: "home.hero.title",
          kind: "text",
          label: "Hero title",
          value: "Edited headline",
        }}
        auditLog={[
          {
            id: "audit-1",
            siteId: "demo-site",
            pagePath: "/",
            action: "version.published",
            userId: "owner-1",
            createdAt: "2026-07-12T00:00:00.000Z",
            summary: "Published Home",
          },
        ]}
      />,
    );

    expect(html).toContain("data-builder-editor-shell");
    expect(html).toContain('src="https://client.example/?builderPreview=1&amp;builderSiteId=demo-site"');
    expect(html).toContain("Home");
    expect(html).toContain("Save draft");
    expect(html).toContain("Publish");
    expect(html).toContain("Version history");
  });

  it("renders a persistent multi-selection toolbar with host-supported actions", () => {
    const html = renderToStaticMarkup(
      <EditorShell
        siteId="demo-site"
        currentPath="/"
        pages={[{ path: "/", label: "Home", regions: [] }]}
        previewBaseUrl="https://client.example"
        selectedRegions={[
          { id: "home.primary-cta", kind: "link", label: "Primary call to action", value: "Donate", href: "/donate" },
          { id: "home.secondary-cta", kind: "link", label: "Secondary call to action", value: "Volunteer", href: "/volunteer" },
        ]}
        onLinkSelectedRegions={() => undefined}
        onCreatePostFromSelection={() => undefined}
      />,
    );

    expect(html).toContain("2 selected");
    expect(html).toContain("Primary call to action");
    expect(html).toContain("Secondary call to action");
    expect(html).toContain("Link selected");
    expect(html).toContain("Create draft post");
    expect(html).toContain('aria-label="Clear selection"');
  });

  it("renders device controls, resize handles, demo status, and a user-view action", () => {
    const html = renderToStaticMarkup(
      <EditorShell
        siteId="demo-site"
        currentPath="/"
        pages={[{ path: "/", label: "Home", regions: [] }]}
        previewBaseUrl="https://client.example"
        userViewUrl="https://client.example/"
        logoutUrl="/auth/logout"
        demoMode
      />,
    );

    expect(html).toContain('aria-label="Desktop view"');
    expect(html).toContain('aria-label="Tablet view"');
    expect(html).toContain('aria-label="Mobile view"');
    expect(html).toContain('data-builder-resize-handle="left"');
    expect(html).toContain('data-builder-resize-handle="right"');
    expect(html).toContain("Demo mode");
    expect(html).toContain("Back to user view");
    expect(html).toContain('action="/auth/logout"');
    expect(html).toContain("Sign out");
    expect(html).toContain("grid-template-rows:auto 1fr");
    expect(html).toContain("min-height:72px");
  });

  it("renders image-specific editing controls, gallery access, and visual audit values", () => {
    const html = renderToStaticMarkup(
      <EditorShell
        siteId="demo-site"
        currentPath="/"
        pages={[{ path: "/", label: "Home", regions: [{ id: "home.hero.image", kind: "image", label: "Hero image" }] }]}
        previewBaseUrl="https://client.example"
        selectedRegion={{
          id: "home.hero.image",
          kind: "image",
          label: "Hero image",
          value: "/images/hero.jpg",
          alt: "Original hero",
        }}
        mediaAssets={[
          {
            id: "asset-1",
            siteId: "demo-site",
            url: "/images/asset.jpg",
            path: "campaign/asset.jpg",
            label: "Gallery asset",
            alt: "Gallery asset alt",
            mimeType: "image/jpeg",
            source: "upload",
            createdAt: "2026-07-12T00:00:00.000Z",
            userId: "owner-1",
          },
        ]}
        auditLog={[
          {
            id: "audit-1",
            siteId: "demo-site",
            pagePath: "/",
            action: "draft.saved",
            kind: "image",
            userId: "owner-1",
            userLabel: "Owner",
            createdAt: "2026-07-12T00:00:00.000Z",
            summary: "Changed hero image",
            regionId: "home.hero.image",
            before: { type: "image", src: "/images/old.jpg", alt: "Old" },
            after: { type: "image", src: "/images/new.jpg", alt: "New" },
          },
        ]}
      />,
    );

    expect(html).toContain("Selected image");
    expect(html).toContain("Alt text");
    expect(html).toContain("Open gallery");
    expect(html).toContain("Gallery asset");
    expect(html).toContain('src="/images/old.jpg"');
    expect(html).toContain('src="/images/new.jpg"');
    expect(html).toContain("Restore previous version");
  });

  it("renders icon-specific editing controls instead of treating icons as text", () => {
    const html = renderToStaticMarkup(
      <EditorShell
        siteId="demo-site"
        currentPath="/"
        pages={[
          {
            path: "/",
            label: "Home",
            regions: [{ id: "home.services.card.icon", kind: "icon", label: "Service icon" }],
          },
        ]}
        previewBaseUrl="https://client.example"
        selectedRegion={{
          id: "home.services.card.icon",
          kind: "icon",
          label: "Service icon",
          value: "mail",
        }}
      />,
    );

    expect(html).toContain("Icon");
    expect(html).toContain("Choose an icon");
    expect(html).toContain("material-symbols-outlined");
    expect(html).toContain("mail");
    expect(html).not.toContain("<textarea");
  });

  it("mounts an injected posts workspace without removing the preview iframe", () => {
    const html = renderToStaticMarkup(
      <EditorShell
        siteId="demo-site"
        currentPath="/"
        pages={[{ path: "/", label: "Home", regions: [] }]}
        previewBaseUrl="https://client.example"
        initialWorkspace="posts"
        postsWorkspace={<section data-testid="hosted-posts">Hosted posts</section>}
      />,
    );

    expect(html).toContain('data-testid="hosted-posts"');
    expect(html).toContain("Hosted posts");
    expect(html).toContain("data-builder-preview-frame");
    expect(html).toContain('data-builder-workspace="website"');
    expect(html).toContain('data-builder-preview-visible="false"');
  });

  it("includes the campaign editor parity surfaces for pages, media, and readable history", () => {
    const historyHtml = renderToStaticMarkup(
      <EditorShell
        siteId="demo-site"
        currentPath="/"
        pages={[
          { path: "/", label: "Home", regions: ["home.hero.title"] },
          { path: "/about", label: "About", regions: ["about.hero.title"] },
        ]}
        previewBaseUrl="https://client.example"
        mediaAssets={[
          {
            id: "asset-1",
            siteId: "demo-site",
            url: "/images/asset.jpg",
            path: "campaign/asset.jpg",
            label: "Gallery asset",
            alt: "Gallery asset alt",
            mimeType: "image/jpeg",
            source: "upload",
            createdAt: "2026-07-12T00:00:00.000Z",
            userId: "owner-1",
          },
        ]}
        auditLog={[
          {
            id: "audit-1",
            siteId: "demo-site",
            pagePath: "/",
            action: "draft.saved",
            userId: "owner-1",
            userLabel: "Owner",
            createdAt: "2026-07-12T00:00:00.000Z",
            summary: "Changed hero text",
            regionId: "home.hero.title",
            before: { type: "text", value: "Old" },
            after: { type: "text", value: "New" },
          },
        ]}
        initialWorkspace="history"
      />,
    );
    const mediaHtml = renderToStaticMarkup(
      <EditorShell
        siteId="demo-site"
        currentPath="/"
        pages={[
          { path: "/", label: "Home", regions: ["home.hero.title"] },
          { path: "/about", label: "About", regions: ["about.hero.title"] },
        ]}
        previewBaseUrl="https://client.example"
        initialWorkspace="media"
        mediaAssets={[
          {
            id: "asset-1",
            siteId: "demo-site",
            url: "/images/asset.jpg",
            path: "campaign/asset.jpg",
            label: "Gallery asset",
            alt: "Gallery asset alt",
            mimeType: "image/jpeg",
            source: "upload",
            createdAt: "2026-07-12T00:00:00.000Z",
            userId: "owner-1",
          },
        ]}
      />,
    );

    expect(historyHtml).toContain("Toggle pages list");
    expect(historyHtml).toContain("<details");
    expect(historyHtml).toContain("<summary");
    expect(historyHtml).toContain("Expand to review details");
    expect(historyHtml).toContain("grid-template-columns:1fr");
    expect(historyHtml).toContain("justify-self:stretch");
    expect(mediaHtml).toContain("Media library");
    expect(mediaHtml).toContain("Gallery asset");
    expect(mediaHtml).toContain('title="Open Gallery asset"');
    expect(mediaHtml).toContain('aria-label="Favorite Gallery asset"');
    expect(mediaHtml).toContain("Show details");
    expect(historyHtml).toContain("Restore previous version");
  });
});
