import { describe, expect, it } from "vitest";
import {
  createRegionEditorState,
  resolveRegionEditorStateForRender,
  type RegionEditorState,
} from "../src/shell/regionDraftState.js";

describe("region draft render resolution", () => {
  it("renders Region B source values synchronously when identity changes", () => {
    const regionA = createRegionEditorState({ id: "region-a", kind: "text", value: "Region A value" });
    const rendered = resolveRegionEditorStateForRender(
      regionA,
      { id: "region-b", kind: "text", value: "Region B value" },
    );

    expect(rendered.identityKey).toContain("region-b");
    expect(rendered.draft.value).toBe("Region B value");
  });

  it("preserves same-identity dirty data but renders clean upstream updates", () => {
    const initial = createRegionEditorState({ id: "region-a", kind: "text", value: "Initial" });
    const dirty: RegionEditorState = { ...initial, draft: { ...initial.draft, value: "Local draft" }, dirty: true };

    expect(resolveRegionEditorStateForRender(
      dirty,
      { id: "region-a", kind: "text", value: "Conflicting upstream" },
    ).draft.value).toBe("Local draft");
    expect(resolveRegionEditorStateForRender(
      initial,
      { id: "region-a", kind: "text", value: "Clean upstream" },
    ).draft.value).toBe("Clean upstream");
  });
});
