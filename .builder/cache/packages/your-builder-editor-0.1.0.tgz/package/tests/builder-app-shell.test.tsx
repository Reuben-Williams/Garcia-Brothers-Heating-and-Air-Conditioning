import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { BuilderAppShell, WorkspaceHeader } from "@your-builder/editor";

describe("BuilderAppShell", () => {
  it("composes navigation, an optional compact header, and workspace content", () => {
    const html = renderToStaticMarkup(
      <BuilderAppShell
        navigation={<nav aria-label="Editor navigation">Navigation</nav>}
        header={<WorkspaceHeader title="Leads" status="Ready" actions={<button type="button">Add lead</button>} />}
      >
        <section data-testid="workspace-content">Workspace content</section>
      </BuilderAppShell>,
    );

    expect(html).toContain("data-builder-app-shell");
    expect(html).toContain('aria-label="Editor navigation"');
    expect(html).toContain("data-builder-workspace-header");
    expect(html).toContain("Leads");
    expect(html).toContain("Ready");
    expect(html).toContain("Add lead");
    expect(html).toContain('data-testid="workspace-content"');
  });

  it("does not require a workspace header", () => {
    const html = renderToStaticMarkup(
      <BuilderAppShell navigation={<nav>Navigation</nav>}>
        <p>Workspace</p>
      </BuilderAppShell>,
    );

    expect(html).toContain("data-builder-app-shell");
    expect(html).not.toContain("data-builder-workspace-header");
  });
});
