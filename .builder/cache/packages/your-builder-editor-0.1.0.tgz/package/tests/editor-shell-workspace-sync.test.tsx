// @vitest-environment jsdom

import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";

import { EditorShell, type BuilderShellRegistration } from "@your-builder/editor";

const registration: BuilderShellRegistration = {
  modules: [],
  workspaces: [
    {
      id: "growth.dashboard",
      label: "Overview",
      group: "growth",
      icon: "layout-dashboard",
      render: () => <p>Overview workspace content</p>,
    },
    {
      id: "growth.leads",
      label: "Leads",
      group: "growth",
      icon: "contact-round",
      render: () => <p>Leads workspace content</p>,
    },
  ],
};

let root: Root;
let container: HTMLDivElement;

beforeAll(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
});

afterEach(async () => {
  if (root) await act(async () => root.unmount());
  container?.remove();
});

function shell(initialWorkspace: "growth.dashboard" | "growth.leads") {
  return (
    <EditorShell
      siteId="demo-site"
      currentPath="/"
      pages={[{ path: "/", label: "Home", regions: [] }]}
      previewBaseUrl="https://client.example"
      registration={registration}
      initialWorkspace={initialWorkspace}
    />
  );
}

describe("EditorShell workspace synchronization", () => {
  it("follows a changed URL-derived workspace without remounting the shell", async () => {
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => root.render(shell("growth.dashboard")));
    expect(container.textContent).toContain("Overview workspace content");

    await act(async () => root.render(shell("growth.leads")));
    expect(container.textContent).toContain("Leads workspace content");
    expect(container.textContent).not.toContain("Overview workspace content");
  });

  it("reports page, workspace, draft-save, and publish actions to the host", async () => {
    const onPageChange = vi.fn();
    const onWorkspaceChange = vi.fn();
    const onSaveDraft = vi.fn(async () => undefined);
    const onPublish = vi.fn(async () => undefined);
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => root.render(
      <EditorShell
        siteId="demo-site"
        currentPath="/"
        pages={[{ path: "/", label: "Home", regions: [] }, { path: "/about", label: "About", regions: [] }]}
        previewBaseUrl="https://client.example"
        registration={registration}
        initialWorkspace="website.pages"
        selectedRegion={{ id: "home.hero.title", kind: "text", value: "Original" }}
        onPageChange={onPageChange}
        onWorkspaceChange={onWorkspaceChange}
        onSaveDraft={onSaveDraft}
        onPublish={onPublish}
      />,
    ));

    const about = container.querySelector<HTMLAnchorElement>('a[href="?path=%2Fabout"]');
    const leads = Array.from(container.querySelectorAll<HTMLButtonElement>("button")).find((button) => button.textContent?.includes("Leads"));
    const editor = container.querySelector<HTMLTextAreaElement>("#builder-region-value");
    const save = Array.from(container.querySelectorAll<HTMLButtonElement>("button")).find((button) => button.textContent?.trim() === "Save draft");
    const publish = Array.from(container.querySelectorAll<HTMLButtonElement>("button")).find((button) => button.textContent?.trim() === "Publish");
    expect(about && leads && editor && save && publish).toBeTruthy();

    await act(async () => about?.click());
    await act(async () => leads?.click());
    await act(async () => {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      setter?.call(editor, "Updated title");
      editor?.dispatchEvent(new Event("input", { bubbles: true }));
    });
    await act(async () => save?.click());
    await act(async () => publish?.click());

    expect(onPageChange).toHaveBeenCalledWith("/about");
    expect(onWorkspaceChange).toHaveBeenCalledWith("growth.leads");
    expect(onSaveDraft).toHaveBeenCalledWith({
      pagePath: "/",
      regionId: "home.hero.title",
      value: { type: "text", value: "Updated title" },
    });
    expect(onPublish).toHaveBeenCalledWith({ pagePath: "/" });
  });
});
