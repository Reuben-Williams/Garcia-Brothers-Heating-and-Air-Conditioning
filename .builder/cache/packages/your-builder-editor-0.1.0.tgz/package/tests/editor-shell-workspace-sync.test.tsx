// @vitest-environment jsdom

import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeAll, describe, expect, it } from "vitest";

import { EditorShell, type BuilderShellRegistration } from "@your-builder/editor";

const registration: BuilderShellRegistration = {
  modules: [],
  workspaces: [
    {
      id: "growth.dashboard",
      label: "Overview",
      group: "growth",
      icon: "layout-dashboard",
      render: () => <p>Overview workspace content</p>,
    },
    {
      id: "growth.leads",
      label: "Leads",
      group: "growth",
      icon: "contact-round",
      render: () => <p>Leads workspace content</p>,
    },
  ],
};

let root: Root;
let container: HTMLDivElement;

beforeAll(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
});

afterEach(async () => {
  if (root) await act(async () => root.unmount());
  container?.remove();
});

function shell(initialWorkspace: "growth.dashboard" | "growth.leads") {
  return (
    <EditorShell
      siteId="demo-site"
      currentPath="/"
      pages={[{ path: "/", label: "Home", regions: [] }]}
      previewBaseUrl="https://client.example"
      registration={registration}
      initialWorkspace={initialWorkspace}
    />
  );
}

describe("EditorShell workspace synchronization", () => {
  it("follows a changed URL-derived workspace without remounting the shell", async () => {
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => root.render(shell("growth.dashboard")));
    expect(container.textContent).toContain("Overview workspace content");

    await act(async () => root.render(shell("growth.leads")));
    expect(container.textContent).toContain("Leads workspace content");
    expect(container.textContent).not.toContain("Overview workspace content");
  });
});
