import { afterEach, describe, expect, it, vi } from "vitest";
import { registerModalFocus } from "../src/shell/modalFocusStack.js";

afterEach(() => {
  document.body.replaceChildren();
  vi.restoreAllMocks();
});

describe("modal focus stack", () => {
  it("arbitrates focus, Tab, Escape, restoration, and global listener cleanup", () => {
    const addListener = vi.spyOn(document, "addEventListener");
    const removeListener = vi.spyOn(document, "removeEventListener");
    const external = document.createElement("button");
    external.textContent = "External";
    const underlying = document.createElement("section");
    underlying.tabIndex = -1;
    const underlyingButton = document.createElement("button");
    underlyingButton.textContent = "Underlying";
    underlying.append(underlyingButton);
    const top = document.createElement("section");
    top.tabIndex = -1;
    const topButton = document.createElement("button");
    topButton.textContent = "Top";
    const topLast = document.createElement("button");
    topLast.textContent = "Top last";
    top.append(topButton, topLast);
    document.body.append(external, underlying, top);
    external.focus();

    const underlyingEscape = vi.fn();
    let unregisterUnderlying = () => {};
    unregisterUnderlying = registerModalFocus({
      container: underlying,
      onEscape: () => {
        underlyingEscape();
        unregisterUnderlying();
      },
    });
    expect(document.activeElement).toBe(underlyingButton);

    const topEscape = vi.fn();
    let unregisterTop = () => {};
    unregisterTop = registerModalFocus({
      container: top,
      onEscape: () => {
        topEscape();
        unregisterTop();
      },
    });
    expect(document.activeElement).toBe(topButton);

    underlyingButton.focus();
    expect(document.activeElement).toBe(topButton);
    external.focus();
    expect(document.activeElement).toBe(topButton);

    topButton.focus();
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", shiftKey: true, cancelable: true }));
    expect(document.activeElement).toBe(topLast);

    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", cancelable: true }));
    expect(topEscape).toHaveBeenCalledTimes(1);
    expect(underlyingEscape).not.toHaveBeenCalled();
    expect(document.activeElement).toBe(underlyingButton);

    external.focus();
    expect(document.activeElement).toBe(underlyingButton);
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", cancelable: true }));
    expect(underlyingEscape).toHaveBeenCalledTimes(1);
    expect(document.activeElement).toBe(external);

    expect(addListener.mock.calls.filter(([type]) => type === "focusin")).toHaveLength(1);
    expect(addListener.mock.calls.filter(([type]) => type === "keydown")).toHaveLength(1);
    expect(removeListener.mock.calls.filter(([type]) => type === "focusin")).toHaveLength(1);
    expect(removeListener.mock.calls.filter(([type]) => type === "keydown")).toHaveLength(1);
  });
});
