import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { renderToStaticMarkup } from "react-dom/server";
import { afterEach, describe, expect, it, vi } from "vitest";
import { useMediaQuery } from "@your-builder/editor";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

type ChangeListener = (event: MediaQueryListEvent) => void;

function createMediaQueryList(initialMatches: boolean) {
  let matches = initialMatches;
  const listeners = new Set<ChangeListener>();
  const mediaQueryList = {
    get matches() {
      return matches;
    },
    media: "(max-width: 767px)",
    onchange: null,
    addEventListener: vi.fn((_type: string, listener: ChangeListener) => listeners.add(listener)),
    removeEventListener: vi.fn((_type: string, listener: ChangeListener) => listeners.delete(listener)),
    addListener: vi.fn(),
    removeListener: vi.fn(),
    dispatchEvent: vi.fn(),
    change(nextMatches: boolean) {
      matches = nextMatches;
      const event = { matches, media: this.media } as MediaQueryListEvent;
      listeners.forEach((listener) => listener(event));
    },
  };
  return mediaQueryList;
}

function Probe() {
  const mobile = useMediaQuery("(max-width: 767px)");
  return <output>{mobile ? "mobile" : "desktop"}</output>;
}

let root: Root | null = null;
let container: HTMLDivElement | null = null;

afterEach(async () => {
  try {
    if (root) await act(async () => root?.unmount());
  } finally {
    root = null;
    container?.remove();
    container = null;
    vi.unstubAllGlobals();
  }
});

describe("useMediaQuery", () => {
  it("defaults to desktop during server rendering", () => {
    expect(renderToStaticMarkup(<Probe />)).toContain("desktop");
  });

  it("subscribes to change events, updates, and cleans up", async () => {
    const mediaQueryList = createMediaQueryList(false);
    vi.stubGlobal("matchMedia", vi.fn(() => mediaQueryList));
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => root?.render(<Probe />));
    expect(container.textContent).toBe("desktop");
    expect(mediaQueryList.addEventListener).toHaveBeenCalledWith("change", expect.any(Function));

    await act(async () => mediaQueryList.change(true));
    expect(container.textContent).toBe("mobile");

    await act(async () => root?.unmount());
    root = null;
    expect(mediaQueryList.removeEventListener).toHaveBeenCalledWith("change", expect.any(Function));
  });

  it("falls back to legacy MediaQueryList listeners", async () => {
    let matches = false;
    let listener: ChangeListener | undefined;
    const mediaQueryList = {
      get matches() {
        return matches;
      },
      media: "(max-width: 767px)",
      onchange: null,
      addListener: vi.fn((nextListener: ChangeListener) => { listener = nextListener; }),
      removeListener: vi.fn((nextListener: ChangeListener) => {
        if (listener === nextListener) listener = undefined;
      }),
      dispatchEvent: vi.fn(),
    } as unknown as MediaQueryList;
    vi.stubGlobal("matchMedia", vi.fn(() => mediaQueryList));
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => root?.render(<Probe />));
    expect(mediaQueryList.addListener).toHaveBeenCalledWith(expect.any(Function));
    matches = true;
    await act(async () => listener?.({ matches, media: mediaQueryList.media } as MediaQueryListEvent));
    expect(container.textContent).toBe("mobile");

    await act(async () => root?.unmount());
    root = null;
    expect(mediaQueryList.removeListener).toHaveBeenCalledWith(expect.any(Function));
  });
});
