import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { PostList, PostsWorkspace } from "../src/content/PostsWorkspace.js";

const posts = [
  {
    entryId: "entry-1",
    title: "Route 9 repairs",
    slug: "route-9-repairs",
    status: "published" as const,
    updatedAt: "2026-07-14T12:00:00.000Z",
  },
  {
    entryId: "entry-2",
    title: "Town hall",
    slug: "town-hall",
    status: "draft" as const,
    updatedAt: "2026-07-14T13:00:00.000Z",
  },
];

describe("PostsWorkspace", () => {
  it("renders searchable status-aware posts and a clear create action", () => {
    const html = renderToStaticMarkup(<PostList posts={posts} selectedEntryId="entry-2" onSelect={() => undefined} onCreate={() => undefined} />);

    expect(html).toContain("Search posts");
    expect(html).toContain("All statuses");
    expect(html).toContain("Route 9 repairs");
    expect(html).toContain("Draft");
    expect(html).toContain("New post");
    expect(html).toContain('aria-current="true"');
    expect(html).toContain('data-builder-selected-post="entry-2"');
  });

  it("uses a stacked workspace layout that remains usable at narrow editor widths", () => {
    const html = renderToStaticMarkup(
      <PostsWorkspace posts={posts} selectedEntryId="entry-1" loading={false} onCreate={() => undefined} onSelect={() => undefined} />,
    );

    expect(html).toContain("data-builder-posts-workspace");
    expect(html).toContain("minmax(260px, 360px)");
    expect(html).toContain("builder-posts-workspace-layout");
    expect(html).toContain("@media (max-width: 900px)");
    expect(html).toContain("grid-template-columns: 1fr");
    expect(html).toContain("Posts");
  });
});
