import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { PostHistory } from "../src/content/PostHistory.js";

describe("PostHistory", () => {
  it("shows attribution, image previews, rollback, and explicit undo rollback", () => {
    const html = renderToStaticMarkup(
      <PostHistory
        events={[
          {
            id: "audit-1",
            action: "post.rolled_back",
            summary: "Rolled back featured image",
            actorLabel: "Site owner",
            createdAt: "2026-07-14T12:00:00.000Z",
            beforeImage: { src: "/old.jpg", alt: "Old image" },
            afterImage: { src: "/new.jpg", alt: "New image" },
            canUndo: true,
          },
        ]}
        onRollback={() => undefined}
        onUndo={() => undefined}
      />,
    );

    expect(html).toContain("Site owner");
    expect(html).toContain('src="/old.jpg"');
    expect(html).toContain('src="/new.jpg"');
    expect(html).toContain("Undo rollback");
    expect(html).not.toContain(">Rollback<");
  });
});
