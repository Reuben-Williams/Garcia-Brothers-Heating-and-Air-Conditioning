import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, describe, expect, it } from "vitest";
import { EditorShell } from "../src/index.js";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

let container: HTMLDivElement | null = null;
let root: Root | null = null;

afterEach(async () => {
  try {
    if (root) await act(async () => root?.unmount());
  } finally {
    root = null;
    container?.remove();
    container = null;
  }
});

describe("editor content navigation", () => {
  it("opens Posts without replacing the preview iframe or changing its viewport", async () => {
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => {
      root?.render(
        <EditorShell
          siteId="assembly"
          currentPath="/"
          pages={[{ path: "/", label: "Home", regions: [] }]}
          previewBaseUrl="https://site.test"
          defaultViewport="tablet"
        />,
      );
    });

    const iframeBefore = container.querySelector("[data-builder-preview-frame]");
    const postsButton = Array.from(container.querySelectorAll("button")).find(
      (button) => button.textContent?.trim() === "Posts",
    );
    expect(postsButton).toBeTruthy();

    await act(async () => postsButton?.dispatchEvent(new MouseEvent("click", { bubbles: true })));

    expect(container.querySelector("[data-builder-preview-frame]")).toBe(iframeBefore);
    expect(container.querySelector("[data-builder-viewport-width='820']")).toBeTruthy();
    expect(container.textContent).toContain("Posts workspace");

  });

  it("opens post actions for a stable preview entry selection", async () => {
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => {
      root?.render(
        <EditorShell
          siteId="assembly"
          currentPath="/"
          pages={[{ path: "/", label: "Home", regions: [] }]}
          previewBaseUrl="https://site.test"
        />,
      );
    });

    const previewFrame = container.querySelector<HTMLIFrameElement>("[data-builder-preview-frame]");
    expect(previewFrame?.contentWindow).toBeTruthy();

    await act(async () => {
      window.dispatchEvent(new MessageEvent("message", {
        origin: "https://site.test",
        source: previewFrame?.contentWindow,
        data: {
          protocol: "your-builder.preview",
          version: 1,
          siteId: "assembly",
          type: "builder:select-entry",
          pagePath: "/",
          entryId: "entry-1",
          contentType: "post",
          regionId: "home.posts",
          anchor: { x: 48, y: 72 },
        },
      }));
    });

    const postActions = container.querySelector('[role="menu"][aria-label="Post actions"]');
    expect(postActions?.getAttribute("data-builder-entry-id")).toBe("entry-1");
    expect(postActions?.getAttribute("data-builder-region-id")).toBe("home.posts");
    expect(container.textContent).toContain("Posts workspace");

  });
});
