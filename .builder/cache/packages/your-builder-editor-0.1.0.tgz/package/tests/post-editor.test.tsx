import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { PostEditor, type EditablePostDraft } from "../src/content/PostEditor.js";
import { PostPublishingPanel } from "../src/content/PostPublishingPanel.js";
import { normalizeEditorDocument } from "../src/content/RichTextEditor.js";

const draft: EditablePostDraft = {
  entryId: "entry-1",
  draftVersionId: "draft-1",
  publishedVersionId: null,
  title: "Town hall",
  slug: "town-hall",
  excerpt: "",
  body: { version: 1, type: "doc", content: [] },
  featuredImage: null,
  authorName: "Office staff",
  authorKey: null,
  categoryKeys: [],
  tagKeys: [],
  displayDate: "2026-07-14T12:00:00.000Z",
  expiresAt: null,
  featured: false,
  pinned: false,
  seoTitle: "",
  seoDescription: "",
  canonicalUrl: null,
  noIndex: false,
};

describe("PostEditor", () => {
  it("renders the complete structured post form while allowing incomplete drafts to save", () => {
    const html = renderToStaticMarkup(
      <PostEditor value={draft} saving={false} onChange={() => undefined} onSave={() => undefined} />,
    );

    expect(html).toContain("Post title");
    expect(html).toContain("Featured image");
    expect(html).toContain("Categories");
    expect(html).toContain("Display date");
    expect(html).toContain("Search and sharing");
    expect(html).toContain("Save draft");
    expect(html).not.toContain("disabled=\"\"");
  });

  it("normalizes only allowlisted rich text JSON", () => {
    expect(
      normalizeEditorDocument({
        type: "doc",
        content: [{ type: "paragraph", content: [{ type: "text", text: "Hello", marks: [{ type: "bold" }] }] }],
      }),
    ).toEqual({
      version: 1,
      type: "doc",
      content: [{ type: "paragraph", content: [{ type: "text", text: "Hello", marks: [{ type: "bold" }] }] }],
    });

    expect(() => normalizeEditorDocument({ type: "doc", content: [{ type: "rawHtml", html: "<script />" }] })).toThrow();
  });

  it("lets a hosted workspace provide the lifecycle controls without duplicating the save panel", () => {
    const html = renderToStaticMarkup(
      <PostEditor
        value={draft}
        saving={false}
        onChange={() => undefined}
        onSave={() => undefined}
        showPublishingPanel={false}
      />,
    );

    expect(html).not.toContain('aria-label="Post publishing"');
  });

  it("shows clear reschedule and cancellation actions for scheduled posts", () => {
    const html = renderToStaticMarkup(
      <PostPublishingPanel
        saving={false}
        scheduled
        onSave={() => undefined}
        onReschedule={() => undefined}
        onCancelSchedule={() => undefined}
      />,
    );
    expect(html).toContain("Reschedule");
    expect(html).toContain("Cancel schedule");
  });
});
