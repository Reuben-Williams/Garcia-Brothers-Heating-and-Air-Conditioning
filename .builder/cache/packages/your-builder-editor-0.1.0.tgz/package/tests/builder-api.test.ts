import { describe, expect, it, vi } from "vitest";
import { BuilderApiClient, BuilderApiError } from "../src/api/builder-api.js";

describe("BuilderApiClient", () => {
  it("adds CSRF and idempotency headers to mutations", async () => {
    const fetcher = vi.fn(async () => Response.json({ ok: true }));
    const client = new BuilderApiClient({
      baseUrl: "https://site.test/api/builder",
      fetcher,
      getCsrfToken: () => "csrf-1",
    });

    await client.request("/posts/entry-1/publish", {
      method: "POST",
      body: { expectedDraftVersionId: "draft-1" },
      idempotencyKey: "publish-1",
    });

    expect(fetcher).toHaveBeenCalledWith(
      "https://site.test/api/builder/posts/entry-1/publish",
      expect.objectContaining({
        headers: expect.objectContaining({
          "x-builder-csrf": "csrf-1",
          "x-idempotency-key": "publish-1",
        }),
      }),
    );
  });

  it("throws typed API conflicts without discarding server details", async () => {
    const client = new BuilderApiClient({
      baseUrl: "/api/builder",
      fetcher: async () =>
        Response.json(
          { error: { code: "CONTENT_VERSION_CONFLICT", message: "Draft changed", latestVersionId: "v2" } },
          { status: 409 },
        ),
    });

    await expect(client.request("/posts/entry-1/publish", { method: "POST" })).rejects.toMatchObject({
      name: "BuilderApiError",
      status: 409,
      code: "CONTENT_VERSION_CONFLICT",
      details: { latestVersionId: "v2" },
    } satisfies Partial<BuilderApiError>);
  });

  it("retries transient reads but never retries mutations", async () => {
    const fetcher = vi
      .fn()
      .mockResolvedValueOnce(Response.json({ error: { code: "UNAVAILABLE", message: "Retry" } }, { status: 503 }))
      .mockResolvedValueOnce(Response.json([{ entryId: "entry-1" }]));
    const client = new BuilderApiClient({ baseUrl: "/api/builder", fetcher, retryDelayMs: 0 });

    await expect(client.request("/posts")).resolves.toEqual([{ entryId: "entry-1" }]);
    expect(fetcher).toHaveBeenCalledTimes(2);
  });

  it("uploads FormData without replacing the browser multipart boundary", async () => {
    const fetcher = vi.fn(async () => Response.json({ ok: true }));
    const client = new BuilderApiClient({ baseUrl: "/api/builder", fetcher, getCsrfToken: () => "csrf-1" });
    const body = new FormData();
    body.set("label", "Town hall");
    body.set("file", new File(["image"], "town-hall.png", { type: "image/png" }));

    await client.request("/media", { method: "POST", body, idempotencyKey: "upload-1" });

    expect(fetcher).toHaveBeenCalledWith(
      "/api/builder/media",
      expect.objectContaining({
        body,
        headers: expect.not.objectContaining({ "content-type": "application/json" }),
      }),
    );
  });
});
