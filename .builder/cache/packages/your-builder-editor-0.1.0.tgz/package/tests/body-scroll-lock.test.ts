import { afterEach, describe, expect, it } from "vitest";
import { acquireBodyScrollLock } from "../src/shell/bodyScrollLock.js";

afterEach(() => {
  document.body.style.overflow = "";
  document.documentElement.style.overflow = "";
});

describe("body scroll lock", () => {
  it("restores scrolling only after the final overlapping lock releases", () => {
    document.body.style.overflow = "auto";
    document.documentElement.style.overflow = "scroll";

    const releaseFirst = acquireBodyScrollLock();
    const releaseSecond = acquireBodyScrollLock();
    expect(document.body.style.overflow).toBe("hidden");
    expect(document.documentElement.style.overflow).toBe("hidden");

    releaseFirst();
    expect(document.body.style.overflow).toBe("hidden");
    expect(document.documentElement.style.overflow).toBe("hidden");

    releaseSecond();
    expect(document.body.style.overflow).toBe("auto");
    expect(document.documentElement.style.overflow).toBe("scroll");
    releaseSecond();
    expect(document.body.style.overflow).toBe("auto");
  });
});
