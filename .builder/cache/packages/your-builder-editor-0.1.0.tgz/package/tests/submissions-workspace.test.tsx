import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  SubmissionsIndicator,
  SubmissionsWorkspace,
  type BaseSubmissionDetail,
  type BaseSubmissionSummary,
  type SubmissionsApi,
} from "@your-builder/editor";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const summary: BaseSubmissionSummary = {
  id: "submission-1",
  formId: "contact",
  sourcePage: "/contact",
  displayName: "Jordan Lee",
  capturedAt: "2026-07-18T12:00:00.000Z",
  reviewState: "new",
  enhancementState: "base_only",
  version: 0,
};

const detail: BaseSubmissionDetail = {
  ...summary,
  fields: [
    { key: "service", label: "Service", value: "No cooling" },
    { key: "phone", label: "Phone", value: "(973) 555-0100" },
  ],
  activity: [{
    id: "event-1",
    title: "Submission received",
    occurredAt: "2026-07-18T12:00:00.000Z",
  }],
};

function createApi(overrides: Partial<SubmissionsApi> = {}): SubmissionsApi {
  return {
    list: vi.fn(async () => ({ items: [summary], newCount: 3, nextCursor: "next-page" })),
    detail: vi.fn(async () => detail),
    markSpam: vi.fn(async () => ({ status: "applied" as const, version: 1 })),
    restore: vi.fn(async () => ({ status: "applied" as const, version: 2 })),
    requestExport: vi.fn(async () => ({ status: "applied" as const, exportId: "export-1" })),
    ...overrides,
  };
}

let container: HTMLDivElement | null = null;
let root: Root | null = null;

async function renderWorkspace(node: React.ReactNode) {
  container = document.createElement("div");
  document.body.append(container);
  root = createRoot(container);
  await act(async () => {
    root?.render(node);
    await Promise.resolve();
  });
  return container;
}

async function flush() {
  await act(async () => {
    await Promise.resolve();
    await Promise.resolve();
  });
}

afterEach(async () => {
  if (root) await act(async () => root?.unmount());
  root = null;
  container?.remove();
  container = null;
  document.body.style.overflow = "";
  document.documentElement.style.overflow = "";
});

describe("SubmissionsWorkspace", () => {
  it.each(["contributor", "viewer"] as const)("denies %s without calling the inbox API", async (role) => {
    const api = createApi();
    const view = await renderWorkspace(<SubmissionsWorkspace role={role} api={api} />);
    expect(view.querySelector('[data-workspace-state="denied"]')).toBeTruthy();
    expect(api.list).not.toHaveBeenCalled();
    expect(view.querySelector("[data-builder-submission-list]")).toBeNull();
  });

  it.each(["owner", "editor"] as const)("loads the authoritative inbox for %s and reports the global count", async (role) => {
    const api = createApi();
    const onNewCountChange = vi.fn();
    const view = await renderWorkspace(
      <SubmissionsWorkspace role={role} api={api} onNewCountChange={onNewCountChange} />,
    );
    await flush();

    expect(view.querySelector("[data-builder-submissions-workspace]")).toBeTruthy();
    expect(view.querySelector("[data-builder-submission-list]")).toBeTruthy();
    expect(view.querySelector('[data-builder-submission-id="submission-1"]')).toBeTruthy();
    expect(view.textContent).toContain("Not in enhanced pipeline");
    expect(onNewCountChange).toHaveBeenCalledWith(3);
  });

  it("opens detail and confirms a versioned spam action", async () => {
    const api = createApi();
    const view = await renderWorkspace(<SubmissionsWorkspace role="owner" api={api} />);
    await flush();
    const row = view.querySelector<HTMLButtonElement>('[data-builder-submission-id="submission-1"]');
    await act(async () => row?.click());
    await flush();

    expect(view.querySelector('[data-builder-submission-detail="submission-1"]')).toBeTruthy();
    expect(view.textContent).toContain("No cooling");
    const spamTrigger = view.querySelector<HTMLButtonElement>("[data-submission-spam-trigger]");
    await act(async () => spamTrigger?.click());
    const confirm = Array.from(view.querySelectorAll("button")).find(
      (button) => button.textContent === "Mark as spam" && button !== spamTrigger,
    );
    await act(async () => confirm?.click());
    await flush();

    expect(api.markSpam).toHaveBeenCalledWith({ submissionId: "submission-1", expectedVersion: 0 });
    expect(view.textContent).toContain("Submission moved to Spam Review.");
  });

  it("restores spam and requests a bounded export from the current query", async () => {
    const spammed = { ...summary, reviewState: "spam" as const, version: 4 };
    const spammedDetail = { ...detail, ...spammed };
    const api = createApi({
      list: vi.fn(async () => ({ items: [spammed], newCount: 0 })),
      detail: vi.fn(async () => spammedDetail),
    });
    const view = await renderWorkspace(
      <SubmissionsWorkspace role="editor" api={api} initialQuery={{ search: "Jordan", reviewState: "spam", limit: 25 }} />,
    );
    await flush();

    const exportButton = view.querySelector<HTMLButtonElement>("[data-submissions-export]");
    await act(async () => exportButton?.click());
    await flush();
    expect(api.requestExport).toHaveBeenCalledWith({ search: "Jordan", reviewState: "spam", limit: 25 });

    const row = view.querySelector<HTMLButtonElement>('[data-builder-submission-id="submission-1"]');
    await act(async () => row?.click());
    await flush();
    const restore = view.querySelector<HTMLButtonElement>("[data-submission-restore]");
    await act(async () => restore?.click());
    await flush();
    expect(api.restore).toHaveBeenCalledWith({ submissionId: "submission-1", expectedVersion: 4 });
    expect(view.textContent).toContain("Submission restored.");
  });

  it("renders a global new-submission indicator with a stable selector", () => {
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    act(() => root?.render(<SubmissionsIndicator count={3} onOpen={() => undefined} />));
    const indicator = container.querySelector("[data-builder-submissions-indicator]");
    expect(indicator?.textContent).toContain("3 new submissions");
    expect(indicator?.getAttribute("aria-label")).toBe("Open 3 new submissions");
  });
});
