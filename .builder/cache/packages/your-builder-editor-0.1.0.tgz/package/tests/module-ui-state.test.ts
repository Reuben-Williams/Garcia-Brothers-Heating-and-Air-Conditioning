import { describe, expect, it } from "vitest";
import { ENTITLEMENT_STATES, type EntitlementState } from "@your-builder/entitlements";
import { resolveModuleUiMode, type ModuleUiMode } from "../src/modules/module-ui-state.js";

const expectedModes = {
  available: "demo",
  requested: "requesting",
  request_withdrawn: "demo",
  trialing: "operational",
  trial_expired: "demo",
  provisioning: "provisioning",
  provisioning_error: "provisioning",
  setup_required: "setup",
  active: "operational",
  payment_attention: "operational",
  grace_period: "operational",
  suspended: "read_only",
  offboarding: "read_only",
  termination_failed: "read_only",
  terminated: "terminated",
} satisfies Record<EntitlementState, ModuleUiMode>;

describe("resolveModuleUiMode", () => {
  it("maps every entitlement state exhaustively", () => {
    expect(ENTITLEMENT_STATES.map((state) => [state, resolveModuleUiMode(state, "fresh")])).toEqual(
      ENTITLEMENT_STATES.map((state) => [state, expectedModes[state]]),
    );
  });

  it.each(["missing", "invalid"] as const)("fails %s snapshots into an isolated demo", (status) => {
    expect(resolveModuleUiMode("active", status)).toBe("demo");
  });

  it("makes stale snapshots and incidents read-only while permission denial is explicit", () => {
    expect(resolveModuleUiMode("active", "stale")).toBe("read_only");
    expect(resolveModuleUiMode("active", "fresh", { hasPermission: false })).toBe("denied");
    expect(resolveModuleUiMode("active", "missing", { hasPermission: false })).toBe("denied");
    expect(resolveModuleUiMode("active", "invalid", { hasPermission: false })).toBe("denied");
    expect(resolveModuleUiMode("active", "fresh", { incidentOverride: "read_only" })).toBe("read_only");
    expect(resolveModuleUiMode("active", "fresh", { incidentOverride: "blocked" })).toBe("read_only");
  });

  it("keeps an incomplete operational module in setup", () => {
    expect(resolveModuleUiMode("active", "fresh", { setupComplete: false })).toBe("setup");
    expect(resolveModuleUiMode("active", "fresh", { setupComplete: true })).toBe("operational");
  });
});
