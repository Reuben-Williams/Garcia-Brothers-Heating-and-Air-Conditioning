import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, describe, expect, it, vi } from "vitest";
import { ActivationRequest } from "../src/modules/ActivationRequest.js";
import type { BuilderApiClient } from "../src/api/builder-api.js";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const SITE_ID = "11111111-1111-4111-8111-111111111111";

let container: HTMLDivElement | null = null;
let root: Root | null = null;

afterEach(async () => {
  if (root) await act(async () => root?.unmount());
  root = null;
  container?.remove();
  container = null;
});

function mount(client: Pick<BuilderApiClient, "request">, state: "available" | "requested" = "available") {
  container = document.createElement("div");
  document.body.append(container);
  root = createRoot(container);
  return act(async () => root?.render(
    <ActivationRequest
      client={client}
      siteId={SITE_ID}
      moduleId="growth.leads"
      moduleName="Leads"
      initialState={state}
      withdrawalAllowed={state === "requested"}
      createRequestId={() => "33333333-3333-4333-8333-333333333333"}
    />,
  ));
}

describe("ActivationRequest", () => {
  it("submits an optional business note and shows the confirmed request", async () => {
    const request = vi.fn(async () => ({
      state: "requested" as const,
      requestId: "44444444-4444-4444-8444-444444444444",
      updatedAt: "2026-01-15T12:00:00.000Z",
      withdrawalAllowed: true,
      correlationId: "55555555-5555-4555-8555-555555555555",
    }));
    await mount({ request } as Pick<BuilderApiClient, "request">);

    const note = container?.querySelector<HTMLTextAreaElement>("textarea");
    await act(async () => {
      if (note) {
        Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set?.call(
          note,
          "We need this for our front desk.",
        );
        note.dispatchEvent(new Event("input", { bubbles: true }));
      }
    });
    const button = Array.from(container?.querySelectorAll("button") ?? []).find((item) => item.textContent?.includes("Request activation"));
    await act(async () => button?.click());

    expect(request).toHaveBeenCalledWith("/entitlements/activation", expect.objectContaining({
      method: "POST",
      idempotencyKey: "33333333-3333-4333-8333-333333333333",
      body: expect.objectContaining({
        siteId: SITE_ID,
        moduleId: "growth.leads",
        note: "We need this for our front desk.",
      }),
    }));
    expect(container?.textContent).toContain("Activation requested");
    expect(container?.textContent).toContain("Withdraw request");
  });

  it("disables the request action while the server response is pending", async () => {
    let resolveRequest: ((value: unknown) => void) | undefined;
    const request = vi.fn(() => new Promise((resolve) => { resolveRequest = resolve; }));
    await mount({ request } as Pick<BuilderApiClient, "request">);
    const button = container?.querySelector<HTMLButtonElement>("button");
    await act(async () => button?.click());
    expect(button?.disabled).toBe(true);
    expect(container?.textContent).toContain("Sending request");
    await act(async () => resolveRequest?.({
      state: "requested",
      requestId: "44444444-4444-4444-8444-444444444444",
      updatedAt: "2026-01-15T12:00:00.000Z",
      withdrawalAllowed: true,
      correlationId: "55555555-5555-4555-8555-555555555555",
    }));
  });

  it("withdraws only when the server marks the request withdrawable", async () => {
    const request = vi.fn(async () => ({
      state: "request_withdrawn" as const,
      requestId: "44444444-4444-4444-8444-444444444444",
      updatedAt: "2026-01-15T12:00:00.000Z",
      withdrawalAllowed: false,
      correlationId: "55555555-5555-4555-8555-555555555555",
    }));
    await mount({ request } as Pick<BuilderApiClient, "request">, "requested");
    const button = container?.querySelector<HTMLButtonElement>("button");
    expect(button?.textContent).toContain("Withdraw request");
    await act(async () => button?.click());
    expect(request).toHaveBeenCalledWith("/entitlements/activation", expect.objectContaining({ method: "DELETE" }));
    expect(container?.textContent).toContain("Request withdrawn");
  });

  it("shows a generic retryable error without leaking raw details", async () => {
    const request = vi.fn(async () => { throw new Error("private server detail"); });
    await mount({ request } as Pick<BuilderApiClient, "request">);
    await act(async () => container?.querySelector<HTMLButtonElement>("button")?.click());
    expect(container?.textContent).toContain("We could not update this request. Try again.");
    expect(container?.textContent).not.toContain("private server detail");
  });
});
