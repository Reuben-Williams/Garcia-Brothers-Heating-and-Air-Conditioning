import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { MediaGallery } from "../src/content/MediaGallery.js";

describe("MediaGallery", () => {
  it("shows private media choices and an image upload control in a clear modal", () => {
    const html = renderToStaticMarkup(
      <MediaGallery
        open
        assets={[{
          mediaId: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
          revisionId: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
          label: "Town hall",
          alt: "Residents at the town hall",
          mimeType: "image/jpeg",
          url: "/api/builder/media/example",
        }]}
        uploading={false}
        onClose={() => undefined}
        onSelect={() => undefined}
        onUpload={() => undefined}
      />,
    );

    expect(html).toContain('role="dialog"');
    expect(html).toContain("Media gallery");
    expect(html).toContain("Town hall");
    expect(html).toContain('accept="image/png,image/jpeg,image/webp,image/gif,image/avif"');
    expect(html).toContain("Upload image");
    expect(html).toContain("builder-media-gallery-content");
    expect(html).toContain("@media (max-width: 700px)");
  });

  it("renders nothing while closed", () => {
    expect(renderToStaticMarkup(
      <MediaGallery open={false} assets={[]} uploading={false} onClose={() => undefined} onSelect={() => undefined} onUpload={() => undefined} />,
    )).toBe("");
  });
});
