import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { renderToStaticMarkup } from "react-dom/server";
import { afterEach, describe, expect, it, vi } from "vitest";
import { SetupChecklist, type SetupChecklistItem } from "../src/modules/SetupChecklist.js";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const items: readonly SetupChecklistItem[] = [
  { id: "sender", label: "Connect sender", required: true, completed: true, evidence: "Verified sender@example.test" },
  { id: "destination", label: "Choose test destination", required: true, completed: false, testDestinationOnly: true },
  { id: "branding", label: "Review branding", required: false, completed: false },
  { id: "restricted", label: "Manage billing", required: true, completed: false, hidden: true },
];

let container: HTMLDivElement | null = null;
let root: Root | null = null;

afterEach(async () => {
  if (root) await act(async () => root?.unmount());
  root = null;
  container?.remove();
  container = null;
});

describe("SetupChecklist", () => {
  it("counts visible required steps, hides denied capabilities, and shows evidence", () => {
    const html = renderToStaticMarkup(<SetupChecklist items={items} onOpen={() => undefined} />);
    expect(html).toContain("1 of 2 required steps complete");
    expect(html).toContain("Verified sender@example.test");
    expect(html).toContain("Test destination only");
    expect(html).not.toContain("Manage billing");
  });

  it("resumes from updated server state without internal progress drift", async () => {
    container = document.createElement("div");
    root = createRoot(container);
    await act(async () => root?.render(<SetupChecklist items={items} onOpen={() => undefined} />));
    expect(container.textContent).toContain("1 of 2 required steps complete");
    await act(async () => root?.render(
      <SetupChecklist
        items={items.map((item) => item.id === "destination" ? { ...item, completed: true } : item)}
        onOpen={() => undefined}
      />,
    ));
    expect(container.textContent).toContain("2 of 2 required steps complete");
  });

  it("associates validation errors with the step action", () => {
    const html = renderToStaticMarkup(
      <SetupChecklist
        items={[{ ...items[1]!, error: "Enter a verified test address." }]}
        onOpen={() => undefined}
      />,
    );
    expect(html).toContain('aria-describedby="setup-destination-error"');
    expect(html).toContain('id="setup-destination-error"');
    expect(html).toContain("Enter a verified test address.");
  });

  it("disables all setup actions while suspended", async () => {
    const onOpen = vi.fn();
    container = document.createElement("div");
    root = createRoot(container);
    await act(async () => root?.render(<SetupChecklist items={items} onOpen={onOpen} suspended />));
    expect(Array.from(container.querySelectorAll("button")).every((button) => button.disabled)).toBe(true);
    expect(container.textContent).toContain("Setup is paused while this module is suspended.");
  });

  it("uses touch-safe actions and a full-screen mobile workspace", () => {
    const css = readFileSync(resolve("packages/editor/src/modules/setup-checklist.module.css"), "utf8");
    expect(css).toMatch(/\.stepButton\s*{[^}]*min-height:\s*44px;/s);
    expect(css).toMatch(/@media \(max-width: 767px\)[\s\S]*\.checklist\s*{[^}]*min-height:\s*calc\(100dvh - 120px\);/);
  });
});
