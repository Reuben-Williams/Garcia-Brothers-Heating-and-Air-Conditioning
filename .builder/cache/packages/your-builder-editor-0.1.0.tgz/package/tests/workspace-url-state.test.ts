import { describe, expect, it } from "vitest";
import {
  parseWorkspaceUrlState,
  updateWorkspaceUrlState,
} from "@your-builder/editor";

describe("workspace URL state", () => {
  it("parses namespaced list, filter, and detail state", () => {
    expect(parseWorkspaceUrlState(
      "?utm=kept&ws.q=heat&ws.sort=-capturedAt&ws.view=new&ws.cursor=next&ws.detail=sub-1&ws.filter.status=new&ws.filter.status=spam",
    )).toEqual({
      query: "heat",
      sort: "-capturedAt",
      savedView: "new",
      cursor: "next",
      detailId: "sub-1",
      filters: { status: ["new", "spam"] },
    });
  });

  it("updates workspace state while preserving unrelated query parameters", () => {
    const next = updateWorkspaceUrlState("?utm=kept&ws.q=old&ws.cursor=stale", {
      query: "new search",
      cursor: null,
      filters: { status: ["spam"] },
    });

    expect(next.get("utm")).toBe("kept");
    expect(next.get("ws.q")).toBe("new search");
    expect(next.has("ws.cursor")).toBe(false);
    expect(next.getAll("ws.filter.status")).toEqual(["spam"]);
  });
});
