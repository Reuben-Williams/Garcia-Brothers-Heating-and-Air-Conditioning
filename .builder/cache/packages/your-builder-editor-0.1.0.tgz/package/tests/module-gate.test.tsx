import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { ModuleGate } from "../src/modules/ModuleGate.js";
import type { ModuleUiMode } from "../src/modules/module-ui-state.js";

function render(mode: ModuleUiMode, readOnlyReason?: string) {
  return renderToStaticMarkup(
    <ModuleGate
      mode={mode}
      moduleName="Leads"
      demo={<div>DEMO_WORKSPACE</div>}
      operational={<div>OPERATIONAL_WORKSPACE</div>}
      setup={<div>SETUP_CHECKLIST</div>}
      request={<div>REQUEST_SURFACE</div>}
      readOnlyReason={readOnlyReason}
      denied={<div>PERMISSION_DENIED</div>}
      onResetDemo={() => undefined}
    />,
  );
}

describe("ModuleGate", () => {
  it("renders the demo and request action without operational content", () => {
    const html = render("demo");
    expect(html).toContain('data-module-mode="demo"');
    expect(html).toContain("Preview with sample data");
    expect(html).toContain("DEMO_WORKSPACE");
    expect(html).toContain("REQUEST_SURFACE");
    expect(html).not.toContain("OPERATIONAL_WORKSPACE");
  });

  it.each(["requesting", "provisioning"] as const)("renders an announced %s state", (mode) => {
    const html = render(mode);
    expect(html).toContain(`data-module-mode="${mode}"`);
    expect(html).toContain('aria-live="polite"');
    expect(html).toContain("REQUEST_SURFACE");
    expect(html).not.toContain("DEMO_WORKSPACE");
    expect(html).not.toContain("OPERATIONAL_WORKSPACE");
  });

  it("renders setup and operational modes exclusively", () => {
    expect(render("setup")).toContain("SETUP_CHECKLIST");
    expect(render("setup")).not.toContain("OPERATIONAL_WORKSPACE");
    expect(render("operational")).toContain("OPERATIONAL_WORKSPACE");
    expect(render("operational")).not.toContain("DEMO_WORKSPACE");
  });

  it("renders operational data read-only with an explicit reason", () => {
    const html = render("read_only", "Your access snapshot needs to refresh.");
    expect(html).toContain('data-module-mode="read_only"');
    expect(html).toContain('role="status"');
    expect(html).not.toContain("inert");
    expect(html).toContain('data-module-read-only="true"');
    expect(html).toContain("Your access snapshot needs to refresh.");
    expect(html).toContain("OPERATIONAL_WORKSPACE");
    expect(html).not.toContain("DEMO_WORKSPACE");
  });

  it("renders an explicit denied surface without demo or operational content", () => {
    const html = render("denied");
    expect(html).toContain('data-module-mode="denied"');
    expect(html).toContain("PERMISSION_DENIED");
    expect(html).not.toContain("DEMO_WORKSPACE");
    expect(html).not.toContain("OPERATIONAL_WORKSPACE");
  });

  it("renders no demo or operational content after termination", () => {
    const html = render("terminated");
    expect(html).toContain("This module is no longer active.");
    expect(html).not.toContain("DEMO_WORKSPACE");
    expect(html).not.toContain("OPERATIONAL_WORKSPACE");
  });
});
