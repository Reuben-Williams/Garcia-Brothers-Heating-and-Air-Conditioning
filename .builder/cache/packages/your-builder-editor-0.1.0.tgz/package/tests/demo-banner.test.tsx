import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import React, { act } from "react";
import { createRoot } from "react-dom/client";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import { DemoBanner } from "../src/modules/DemoBanner.js";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

describe("DemoBanner", () => {
  it("names the module and clearly labels fictional data", () => {
    const html = renderToStaticMarkup(<DemoBanner moduleName="Leads" onReset={() => undefined} />);
    expect(html).toContain("Preview with sample data");
    expect(html).toContain("Leads");
    expect(html).toContain("Reset demo");
    expect(html).not.toMatch(/revenue|ROI|guarantee/i);
  });

  it("calls the reset action", async () => {
    const onReset = vi.fn();
    const container = document.createElement("div");
    const root = createRoot(container);
    await act(async () => root.render(<DemoBanner moduleName="Leads" onReset={onReset} />));
    await act(async () => container.querySelector<HTMLButtonElement>("button")?.click());
    expect(onReset).toHaveBeenCalledOnce();
    await act(async () => root.unmount());
  });

  it("keeps the compact notice visible and its reset target touch-safe", () => {
    const css = readFileSync(resolve("packages/editor/src/modules/module-gate.module.css"), "utf8");
    expect(css).toMatch(/\.demoBanner\s*{[^}]*position:\s*sticky;/s);
    expect(css).toMatch(/\.resetButton\s*{[^}]*min-height:\s*44px;/s);
    expect(css).toMatch(/border-radius:\s*6px;/);
    expect(css).not.toMatch(/gradient/i);
  });
});
