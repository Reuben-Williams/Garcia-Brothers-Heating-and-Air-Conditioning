import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { renderToStaticMarkup } from "react-dom/server";
import { afterEach, describe, expect, it, vi } from "vitest";
import { ResponsiveNavigation, type RegisteredWorkspace } from "@your-builder/editor";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const workspace = (
  id: RegisteredWorkspace["id"],
  label: string,
  group: RegisteredWorkspace["group"],
  icon: string,
  mobilePriority?: number,
): RegisteredWorkspace => ({ id, label, group, icon, mobilePriority, render: () => null });

const workspaces: readonly RegisteredWorkspace[] = [
  workspace("website.pages", "Pages", "website", "file-text", 3),
  workspace("website.posts", "Posts", "website", "newspaper"),
  workspace("growth.dashboard", "Overview", "growth", "layout-dashboard", 1),
  workspace("growth.leads", "Leads", "growth", "users", 2),
  workspace("growth.automations", "Automations", "growth", "workflow", 4),
  workspace("growth.customers", "Customers", "manage", "contact"),
];

const shellCss = readFileSync(resolve("packages/editor/src/shell/editor-shell.module.css"), "utf8");
const tabletBreakpoint = shellCss.slice(
  shellCss.indexOf("@media (min-width: 768px) and (max-width: 1023px)"),
  shellCss.indexOf("@media (max-width: 767px)"),
);
const mobileBreakpoint = shellCss.slice(shellCss.indexOf("@media (max-width: 767px)"));

let container: HTMLDivElement | null = null;
let root: Root | null = null;

function installMutableMatchMedia(initialMatches = false) {
  let matches = initialMatches;
  const listeners = new Set<(event: MediaQueryListEvent) => void>();
  const mediaQueryList = {
    get matches() {
      return matches;
    },
    media: "(min-width: 768px)",
    onchange: null,
    addEventListener: vi.fn((_type: string, listener: (event: MediaQueryListEvent) => void) => listeners.add(listener)),
    removeEventListener: vi.fn((_type: string, listener: (event: MediaQueryListEvent) => void) => listeners.delete(listener)),
    addListener: vi.fn(),
    removeListener: vi.fn(),
    dispatchEvent: vi.fn(),
    change(nextMatches: boolean) {
      matches = nextMatches;
      listeners.forEach((listener) => listener({ matches, media: this.media } as MediaQueryListEvent));
    },
  };
  vi.stubGlobal("matchMedia", vi.fn(() => mediaQueryList));
  return mediaQueryList;
}

afterEach(async () => {
  try {
    if (root) await act(async () => root?.unmount());
  } finally {
    root = null;
    container?.remove();
    container = null;
    vi.unstubAllGlobals();
    document.body.style.overflow = "";
    document.documentElement.style.overflow = "";
  }
});

describe("ResponsiveNavigation", () => {
  it("groups only registered desktop destinations", () => {
    const html = renderToStaticMarkup(
      <ResponsiveNavigation
        siteLabel="Assembly"
        siteStatus="Site editor"
        workspaces={workspaces}
        activeWorkspace="growth.leads"
        onWorkspaceChange={() => undefined}
      />,
    );

    expect(html).toContain('data-builder-navigation-surface="desktop"');
    expect(html).toContain('data-builder-navigation-group="website"');
    expect(html).toContain('data-builder-navigation-group="growth"');
    expect(html).toContain('data-builder-navigation-group="manage"');
    expect(html).toContain("Pages");
    expect(html).toContain("Overview");
    expect(html).toContain("Customers");
    expect(html).not.toContain("Reviews");
    expect(html).not.toContain("AI assistant");
  });

  it("renders semantic tablet and mobile surfaces with registered primary destinations", () => {
    const html = renderToStaticMarkup(
      <ResponsiveNavigation
        siteLabel="Assembly"
        workspaces={workspaces}
        activeWorkspace="growth.leads"
        onWorkspaceChange={() => undefined}
      />,
    );

    expect(html).toContain('data-builder-navigation-surface="tablet"');
    expect(html).toContain('aria-label="Tablet editor navigation"');
    expect(html).toContain('data-builder-navigation-surface="mobile-top"');
    expect(html).toContain('data-builder-navigation-surface="mobile-bottom"');
    expect(html).toContain('aria-label="Mobile editor navigation"');
    expect(html).toContain('data-builder-mobile-destination="growth.dashboard"');
    expect(html).toContain('data-builder-mobile-destination="growth.leads"');
    expect(html).toContain('data-builder-mobile-destination="website.pages"');
    expect(html).toContain('data-builder-mobile-destination="growth.automations"');
    expect(html).toContain('aria-label="More destinations"');
    expect(html).toContain('aria-current="page"');
    expect(html).toContain("navigationButton");
  });

  it("uses the inbox icon for the base Submissions destination", () => {
    const html = renderToStaticMarkup(
      <ResponsiveNavigation
        siteLabel="Assembly"
        workspaces={[workspace("website.submissions", "Submissions", "website", "inbox")]}
        activeWorkspace="website.submissions"
        onWorkspaceChange={() => undefined}
      />,
    );

    expect(html).toContain("lucide-inbox");
  });

  it("keeps locked modules discoverable with a Preview status on every navigation surface", () => {
    const locked = {
      ...workspace("growth.leads", "Leads", "growth", "users", 2),
      status: "preview" as const,
    };
    const html = renderToStaticMarkup(
      <ResponsiveNavigation
        siteLabel="Assembly"
        workspaces={[locked]}
        activeWorkspace="growth.leads"
        onWorkspaceChange={() => undefined}
      />,
    );
    expect(html.match(/>Preview</g)?.length).toBeGreaterThanOrEqual(3);
    expect(html).toContain('data-workspace-status="preview"');
  });

  it("orders registered mobile destinations by priority with canonical fallback", () => {
    const priorityWorkspaces: readonly RegisteredWorkspace[] = [
      workspace("growth.dashboard", "Overview", "growth", "layout-dashboard", 40),
      workspace("growth.leads", "Leads", "growth", "users", 10),
      workspace("website.pages", "Pages", "website", "file-text", 30),
      workspace("growth.automations", "Automations", "growth", "workflow", 20),
    ];
    const html = renderToStaticMarkup(
      <ResponsiveNavigation
        siteLabel="Assembly"
        workspaces={priorityWorkspaces}
        activeWorkspace="growth.leads"
        onWorkspaceChange={() => undefined}
      />,
    );
    const mobileMarkup = html.slice(html.indexOf('data-builder-navigation-surface="mobile-bottom"'));

    expect(mobileMarkup.indexOf('data-builder-mobile-destination="growth.leads"')).toBeLessThan(
      mobileMarkup.indexOf('data-builder-mobile-destination="growth.automations"'),
    );
    expect(mobileMarkup.indexOf('data-builder-mobile-destination="growth.automations"')).toBeLessThan(
      mobileMarkup.indexOf('data-builder-mobile-destination="website.pages"'),
    );
    expect(mobileMarkup.indexOf('data-builder-mobile-destination="website.pages"')).toBeLessThan(
      mobileMarkup.indexOf('data-builder-mobile-destination="growth.dashboard"'),
    );
    expect(mobileMarkup).toContain('data-builder-mobile-count="5"');
    expect(mobileMarkup).toContain("--mobile-navigation-columns:5");
  });

  it("sizes sparse mobile navigation to registered destinations plus More", () => {
    const html = renderToStaticMarkup(
      <ResponsiveNavigation
        siteLabel="Assembly"
        workspaces={[workspace("website.pages", "Pages", "website", "file-text")]}
        activeWorkspace="website.pages"
        onWorkspaceChange={() => undefined}
      />,
    );

    expect(html).toContain('data-builder-mobile-count="2"');
    expect(html).toContain("--mobile-navigation-columns:2");
  });

  it("locks the responsive CSS breakpoint and touch-target contracts", () => {
    expect(shellCss).toMatch(/@media \(min-width: 768px\) and \(max-width: 1023px\)/);
    expect(shellCss).toMatch(/@media \(max-width: 767px\)/);
    expect(tabletBreakpoint).toMatch(/\.tabletNavigation\s*{[^}]*display:\s*grid;/);
    expect(shellCss).toMatch(/\.navigationButton\s*{[\s\S]*?min-width:\s*44px;[\s\S]*?min-height:\s*44px;/);
    expect(mobileBreakpoint).not.toMatch(/\.mobileBottomNav \.navigationButton\s*{[^}]*min-width:\s*0;/);
    expect(shellCss).toMatch(/grid-template-columns:\s*repeat\(var\(--mobile-navigation-columns\), minmax\(44px, 1fr\)\);/);
    expect(shellCss).toMatch(/padding:\s*56px 0 calc\(64px \+ env\(safe-area-inset-bottom\)\);/);
    expect(shellCss).toMatch(/padding:\s*4px 4px calc\(4px \+ env\(safe-area-inset-bottom\)\);/);
    expect(shellCss.match(/overflow-x:\s*clip;/g)?.length ?? 0).toBeGreaterThanOrEqual(2);
    expect(shellCss).toMatch(/\.moreSheet\s*{[^}]*overscroll-behavior:\s*contain;/);
  });

  it("preserves the optional website page-link model", () => {
    const html = renderToStaticMarkup(
      <ResponsiveNavigation
        siteLabel="Assembly"
        workspaces={workspaces}
        activeWorkspace="website.pages"
        onWorkspaceChange={() => undefined}
        pageLinks={[
          { path: "/", label: "Home" },
          { path: "/about", label: "About" },
        ]}
        currentPath="/about"
        pagesExpanded
        onTogglePages={() => undefined}
      />,
    );

    expect(html).toContain('aria-label="Site pages"');
    expect(html).toContain("Home");
    expect(html).toContain("About");
    expect(html).toContain('href="?path=%2Fabout"');
    expect(html).toContain('aria-current="page"');
  });

  it("routes page links through the host without reloading when a page callback is provided", async () => {
    const onPageChange = vi.fn();
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => root?.render(
      <ResponsiveNavigation
        siteLabel="Assembly"
        workspaces={workspaces}
        activeWorkspace="website.pages"
        onWorkspaceChange={() => undefined}
        pageLinks={[{ path: "/", label: "Home" }, { path: "/about", label: "About" }]}
        currentPath="/"
        pagesExpanded
        onPageChange={onPageChange}
      />,
    ));

    const about = container.querySelector<HTMLAnchorElement>('a[href="?path=%2Fabout"]');
    expect(about).toBeTruthy();
    await act(async () => about?.click());
    expect(onPageChange).toHaveBeenCalledWith("/about");
  });

  it("opens More with all remaining registered destinations", async () => {
    const onWorkspaceChange = vi.fn();
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => {
      root?.render(
        <ResponsiveNavigation
          siteLabel="Assembly"
          workspaces={workspaces}
          activeWorkspace="growth.dashboard"
          onWorkspaceChange={onWorkspaceChange}
        />,
      );
    });

    const more = container.querySelector<HTMLButtonElement>('[aria-label="More destinations"]');
    expect(more).toBeTruthy();
    expect(more?.className).toContain("navigationButton");

    await act(async () => more?.click());

    const menu = container.querySelector('[role="dialog"][aria-label="More destinations"]');
    expect(menu).toBeTruthy();
    expect(menu?.textContent).toContain("Posts");
    expect(menu?.textContent).toContain("Customers");
    expect(menu?.textContent).not.toContain("Reviews");

    const customers = Array.from(menu?.querySelectorAll("button") ?? []).find(
      (button) => button.textContent?.trim() === "Customers",
    );
    await act(async () => customers?.click());
    expect(onWorkspaceChange).toHaveBeenCalledWith("growth.customers");
    expect(container.querySelector('[role="dialog"][aria-label="More destinations"]')).toBeNull();
  });

  it("moves focus into More and traps forward and reverse tab navigation", async () => {
    const outside = document.createElement("button");
    outside.textContent = "Outside";
    document.body.append(outside);
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => {
      root?.render(
        <ResponsiveNavigation
          siteLabel="Assembly"
          workspaces={workspaces}
          activeWorkspace="growth.dashboard"
          onWorkspaceChange={() => undefined}
        />,
      );
    });

    const more = container.querySelector<HTMLButtonElement>('[aria-label="More destinations"]');
    await act(async () => more?.click());

    const dialog = container.querySelector<HTMLElement>('[role="dialog"][aria-label="More destinations"]');
    const controls = Array.from(dialog?.querySelectorAll<HTMLButtonElement>("button") ?? []);
    expect(dialog).toBeTruthy();
    expect(document.activeElement).toBe(controls[0]);

    outside.focus();
    expect(document.activeElement).toBe(controls[0]);

    controls.at(-1)?.focus();
    await act(async () => {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", bubbles: true, cancelable: true }));
    });
    expect(document.activeElement).toBe(controls[0]);

    controls[0]?.focus();
    await act(async () => {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", shiftKey: true, bubbles: true, cancelable: true }));
    });
    expect(document.activeElement).toBe(controls.at(-1));
    outside.remove();
  });

  it("closes More and releases its scroll lock when leaving the mobile breakpoint", async () => {
    const mediaQueryList = installMutableMatchMedia(false);
    document.body.style.overflow = "auto";
    document.documentElement.style.overflow = "scroll";
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => root?.render(
      <ResponsiveNavigation
        siteLabel="Assembly"
        workspaces={workspaces}
        activeWorkspace="growth.dashboard"
        onWorkspaceChange={() => undefined}
      />,
    ));
    const more = container.querySelector<HTMLButtonElement>('[aria-label="More destinations"]');
    await act(async () => more?.click());
    expect(container.querySelector('[role="dialog"][aria-label="More destinations"]')).toBeTruthy();
    expect(document.body.style.overflow).toBe("hidden");

    await act(async () => mediaQueryList.change(true));
    expect(container.querySelector('[role="dialog"][aria-label="More destinations"]')).toBeNull();
    expect(document.body.style.overflow).toBe("auto");
    expect(document.documentElement.style.overflow).toBe("scroll");
  });

  it("closes More on Escape and restores focus to its trigger", async () => {
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => {
      root?.render(
        <ResponsiveNavigation
          siteLabel="Assembly"
          workspaces={workspaces}
          activeWorkspace="growth.dashboard"
          onWorkspaceChange={() => undefined}
        />,
      );
    });

    const more = container.querySelector<HTMLButtonElement>('[aria-label="More destinations"]');
    await act(async () => more?.click());
    expect(container.querySelector('[role="dialog"][aria-label="More destinations"]')).toBeTruthy();

    await act(async () => {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    });

    expect(container.querySelector('[role="dialog"][aria-label="More destinations"]')).toBeNull();
    expect(document.activeElement).toBe(more);
  });

  it("restores trigger focus when the close button dismisses More", async () => {
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    await act(async () => {
      root?.render(
        <ResponsiveNavigation
          siteLabel="Assembly"
          workspaces={workspaces}
          activeWorkspace="growth.dashboard"
          onWorkspaceChange={() => undefined}
        />,
      );
    });

    const more = container.querySelector<HTMLButtonElement>('[aria-label="More destinations"]');
    await act(async () => more?.click());
    const close = container.querySelector<HTMLButtonElement>('[aria-label="Close more destinations"]');
    await act(async () => close?.click());

    expect(container.querySelector('[role="dialog"][aria-label="More destinations"]')).toBeNull();
    expect(document.activeElement).toBe(more);
  });

  it("locks document scrolling while More is open and restores prior values on close and unmount", async () => {
    const originalBodyOverflow = document.body.style.overflow;
    const originalDocumentOverflow = document.documentElement.style.overflow;
    document.body.style.overflow = "scroll";
    document.documentElement.style.overflow = "auto";
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);

    try {
      await act(async () => {
        root?.render(
          <ResponsiveNavigation
            siteLabel="Assembly"
            workspaces={workspaces}
            activeWorkspace="growth.dashboard"
            onWorkspaceChange={() => undefined}
          />,
        );
      });

      let more = container.querySelector<HTMLButtonElement>('[aria-label="More destinations"]');
      await act(async () => more?.click());
      expect(document.body.style.overflow).toBe("hidden");
      expect(document.documentElement.style.overflow).toBe("hidden");

      const close = container.querySelector<HTMLButtonElement>('[aria-label="Close more destinations"]');
      await act(async () => close?.click());
      expect(document.body.style.overflow).toBe("scroll");
      expect(document.documentElement.style.overflow).toBe("auto");

      more = container.querySelector<HTMLButtonElement>('[aria-label="More destinations"]');
      await act(async () => more?.click());
      expect(document.body.style.overflow).toBe("hidden");
      expect(document.documentElement.style.overflow).toBe("hidden");

      await act(async () => root?.unmount());
      root = null;
      expect(document.body.style.overflow).toBe("scroll");
      expect(document.documentElement.style.overflow).toBe("auto");
    } finally {
      document.body.style.overflow = originalBodyOverflow;
      document.documentElement.style.overflow = originalDocumentOverflow;
    }
  });
});
