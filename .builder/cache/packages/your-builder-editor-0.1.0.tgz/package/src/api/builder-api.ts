export class BuilderApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
    public readonly details: Record<string, unknown> = {},
  ) {
    super(message);
    this.name = "BuilderApiError";
  }
}

export interface BuilderApiClientOptions {
  baseUrl: string;
  fetcher?: typeof fetch;
  getCsrfToken?: () => string | null | Promise<string | null>;
  retryDelayMs?: number;
}

export interface BuilderApiRequestOptions {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  idempotencyKey?: string;
  signal?: AbortSignal;
}

export interface ActivationRequestInput {
  readonly siteId: string;
  readonly moduleId: string;
  readonly requestId: string;
  readonly note?: string;
}

export interface ActivationRequestResult {
  readonly state: "requested" | "request_withdrawn";
  readonly requestId: string;
  readonly updatedAt: string;
  readonly withdrawalAllowed: boolean;
  readonly correlationId: string;
}

const transientStatuses = new Set([502, 503, 504]);

export class BuilderApiClient {
  private readonly fetcher: typeof fetch;
  private readonly baseUrl: string;

  constructor(private readonly options: BuilderApiClientOptions) {
    this.fetcher = options.fetcher ?? fetch;
    this.baseUrl = options.baseUrl.replace(/\/$/, "");
  }

  async request<T = unknown>(path: string, options: BuilderApiRequestOptions = {}): Promise<T> {
    const method = options.method ?? "GET";
    const maxAttempts = method === "GET" ? 3 : 1;

    for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
      const headers: Record<string, string> = { accept: "application/json" };
      const isFormData = typeof FormData !== "undefined" && options.body instanceof FormData;
      if (options.body !== undefined && !isFormData) headers["content-type"] = "application/json";
      if (method !== "GET") {
        const csrfToken = await this.options.getCsrfToken?.();
        if (csrfToken) headers["x-builder-csrf"] = csrfToken;
        if (options.idempotencyKey) headers["x-idempotency-key"] = options.idempotencyKey;
      }

      const response = await this.fetcher(`${this.baseUrl}/${path.replace(/^\//, "")}`, {
        method,
        headers,
        body: options.body === undefined
          ? undefined
          : isFormData
            ? options.body as FormData
            : JSON.stringify(options.body),
        credentials: "same-origin",
        cache: "no-store",
        signal: options.signal,
      });

      if (response.ok) {
        if (response.status === 204) return undefined as T;
        return (await response.json()) as T;
      }

      if (method === "GET" && transientStatuses.has(response.status) && attempt < maxAttempts) {
        await new Promise((resolve) => setTimeout(resolve, this.options.retryDelayMs ?? 150 * attempt));
        continue;
      }

      const payload = (await response.json().catch(() => null)) as {
        error?: Record<string, unknown>;
      } | null;
      const apiError = payload?.error ?? {};
      const { code, message, ...details } = apiError;
      throw new BuilderApiError(
        response.status,
        typeof code === "string" ? code : "REQUEST_FAILED",
        typeof message === "string" ? message : "The builder request failed.",
        details,
      );
    }

    throw new BuilderApiError(503, "REQUEST_FAILED", "The builder request failed.");
  }
}
