const focusableSelector = [
  "a[href]",
  "area[href]",
  "button:not([disabled])",
  "input:not([disabled]):not([type='hidden'])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  "summary",
  "[contenteditable='true']",
  "[tabindex]:not([tabindex='-1'])",
].join(",");

function isHiddenWithin(element: HTMLElement, container: HTMLElement) {
  let current: HTMLElement | null = element;
  while (current) {
    if (current.hidden || current.getAttribute("aria-hidden") === "true" || current.hasAttribute("inert")) return true;
    const style = window.getComputedStyle(current);
    if (style.display === "none" || style.visibility === "hidden") return true;
    if (current === container) break;
    current = current.parentElement;
  }
  return false;
}

function isAvailableWithinDetails(element: HTMLElement) {
  const closedDetails = element.closest<HTMLDetailsElement>("details:not([open])");
  if (!closedDetails) return true;
  const ownSummary = Array.from(closedDetails.children).find((child) => child.tagName === "SUMMARY");
  return element === ownSummary;
}

export function getVisibleFocusableElements(container: HTMLElement | null) {
  if (!container) return [];
  return Array.from(container.querySelectorAll<HTMLElement>(focusableSelector)).filter((element) => {
    if (element.tabIndex < 0 || isHiddenWithin(element, container) || !isAvailableWithinDetails(element)) return false;
    if (element.tagName !== "SUMMARY") return true;
    const details = element.parentElement;
    return details?.tagName === "DETAILS"
      && Array.from(details.children).find((child) => child.tagName === "SUMMARY") === element;
  });
}

export function focusFirstVisibleElement(container: HTMLElement | null) {
  const target = getVisibleFocusableElements(container)[0] ?? container;
  target?.focus();
  return target;
}

export function containFocusWithin(container: HTMLElement | null, eventTarget: EventTarget | null) {
  if (!container || (eventTarget instanceof Node && container.contains(eventTarget))) return;
  focusFirstVisibleElement(container);
}
