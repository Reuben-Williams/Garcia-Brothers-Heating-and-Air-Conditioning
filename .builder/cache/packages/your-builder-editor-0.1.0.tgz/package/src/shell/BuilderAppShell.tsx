import type { ReactNode } from "react";
import styles from "./editor-shell.module.css";

export interface BuilderAppShellProps {
  navigation: ReactNode;
  header?: ReactNode;
  children: ReactNode;
}

export function BuilderAppShell({ navigation, header, children }: BuilderAppShellProps) {
  return (
    <main className={styles.shell} data-builder-app-shell data-builder-editor-shell>
      <div className={styles.navigation}>{navigation}</div>
      <div className={styles.main}>
        {header}
        <div className={styles.workspace}>{children}</div>
      </div>
    </main>
  );
}
