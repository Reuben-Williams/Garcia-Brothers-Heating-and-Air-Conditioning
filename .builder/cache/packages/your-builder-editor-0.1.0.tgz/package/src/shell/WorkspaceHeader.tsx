import type { ReactNode } from "react";
import styles from "./editor-shell.module.css";

export interface WorkspaceHeaderProps {
  title: string;
  eyebrow?: string;
  description?: string;
  status?: ReactNode;
  actions?: ReactNode;
}

export function WorkspaceHeader({ title, eyebrow, description, status, actions }: WorkspaceHeaderProps) {
  return (
    <header className={styles.workspaceHeader} data-builder-workspace-header>
      <div className={styles.workspaceHeaderCopy}>
        {eyebrow ? <span className={styles.workspaceEyebrow}>{eyebrow}</span> : null}
        <div className={styles.workspaceTitleRow}>
          <h2 className={styles.workspaceTitle}>{title}</h2>
          {status ? <span className={styles.workspaceStatus}>{status}</span> : null}
        </div>
        {description ? <p className={styles.workspaceDescription}>{description}</p> : null}
      </div>
      {actions ? <div className={styles.workspaceActions}>{actions}</div> : null}
    </header>
  );
}
