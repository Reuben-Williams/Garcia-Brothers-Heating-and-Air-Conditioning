let activeLocks = 0;
let previousBodyOverflow = "";
let previousDocumentOverflow = "";

export function acquireBodyScrollLock() {
  if (typeof document === "undefined") return () => {};

  if (activeLocks === 0) {
    previousBodyOverflow = document.body.style.overflow;
    previousDocumentOverflow = document.documentElement.style.overflow;
    document.body.style.overflow = "hidden";
    document.documentElement.style.overflow = "hidden";
  }
  activeLocks += 1;
  let released = false;

  return () => {
    if (released) return;
    released = true;
    activeLocks = Math.max(0, activeLocks - 1);
    if (activeLocks !== 0) return;

    document.body.style.overflow = previousBodyOverflow;
    document.documentElement.style.overflow = previousDocumentOverflow;
    previousBodyOverflow = "";
    previousDocumentOverflow = "";
  };
}
