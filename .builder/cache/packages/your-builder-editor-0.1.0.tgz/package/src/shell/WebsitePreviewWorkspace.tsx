import type { ReactNode } from "react";

export function WebsitePreviewWorkspace({ children }: { children: ReactNode }) {
  return (
    <div data-builder-website-preview-workspace style={{ display: "contents" }}>
      {children}
    </div>
  );
}
