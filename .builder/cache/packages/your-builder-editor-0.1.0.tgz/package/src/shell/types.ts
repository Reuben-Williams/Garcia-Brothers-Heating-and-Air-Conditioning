import type { ReactNode } from "react";
import type { GrowthFeatureModule, GrowthModuleId } from "@your-builder/feature-registry";

export type WebsiteWorkspaceId =
  | "website.pages"
  | "website.posts"
  | "website.media"
  | "website.history"
  | "website.submissions";

export type BuilderWorkspaceId = WebsiteWorkspaceId | GrowthModuleId;

export interface RegisteredWorkspace {
  id: BuilderWorkspaceId;
  label: string;
  group: "website" | "growth" | "manage";
  icon: string;
  mobilePriority?: number;
  status?: "preview" | "setup" | "active" | "read_only";
  render: () => ReactNode;
}

export interface BuilderShellRegistration {
  modules: readonly GrowthFeatureModule[];
  workspaces: readonly RegisteredWorkspace[];
  globalHeader?: ReactNode;
}
