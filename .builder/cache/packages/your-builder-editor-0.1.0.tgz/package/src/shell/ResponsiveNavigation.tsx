import { useEffect, useRef, useState, type ComponentType, type CSSProperties } from "react";
import {
  Blocks,
  Bot,
  Contact,
  FileText,
  History,
  Image,
  Inbox,
  LayoutDashboard,
  Menu,
  MessageCircle,
  MessagesSquare,
  MoreHorizontal,
  Newspaper,
  PanelsTopLeft,
  Star,
  Users,
  Workflow,
  X,
} from "lucide-react";
import type { BuilderWorkspaceId, RegisteredWorkspace } from "./types.js";
import { acquireBodyScrollLock } from "./bodyScrollLock.js";
import { registerModalFocus } from "./modalFocusStack.js";
import { useMediaQuery } from "./useMediaQuery.js";
import styles from "./editor-shell.module.css";

type NavigationIcon = ComponentType<{ size?: number; "aria-hidden"?: "true" }>;

const iconMap: Readonly<Record<string, NavigationIcon>> = {
  blocks: Blocks,
  bot: Bot,
  contact: Contact,
  customers: Contact,
  "file-text": FileText,
  history: History,
  image: Image,
  images: Image,
  inbox: Inbox,
  "layout-dashboard": LayoutDashboard,
  leads: Users,
  media: Image,
  messaging: MessagesSquare,
  newspaper: Newspaper,
  pages: FileText,
  posts: Newspaper,
  reviews: Star,
  chat: MessageCircle,
  users: Users,
  website: PanelsTopLeft,
  workflow: Workflow,
  automations: Workflow,
};

const groupLabels: Readonly<Record<RegisteredWorkspace["group"], string>> = {
  website: "Website",
  growth: "Growth",
  manage: "Manage",
};

const mobileDestinations = [
  { ids: ["growth.dashboard"] as const, label: "Overview" },
  { ids: ["growth.leads"] as const, label: "Leads" },
  { ids: ["website.pages", "core.website"] as const, label: "Website" },
  { ids: ["growth.automations"] as const, label: "Automations" },
] as const;

export interface WebsitePageLink {
  path: string;
  label: string;
}

export interface ResponsiveNavigationProps {
  siteLabel: string;
  siteStatus?: string;
  workspaces: readonly RegisteredWorkspace[];
  activeWorkspace: BuilderWorkspaceId;
  onWorkspaceChange: (workspace: BuilderWorkspaceId) => void;
  pageLinks?: readonly WebsitePageLink[];
  currentPath?: string;
  pagesExpanded?: boolean;
  onTogglePages?: () => void;
  onPageChange?: (path: string) => void;
}

function WorkspaceIcon({ name, size = 19 }: { name: string; size?: number }) {
  const Icon = iconMap[name.toLowerCase()] ?? Blocks;
  return <Icon size={size} aria-hidden="true" />;
}

const workspaceStatusLabels: Readonly<Record<NonNullable<RegisteredWorkspace["status"]>, string>> = {
  preview: "Preview",
  setup: "Setup",
  active: "Active",
  read_only: "Read-only",
};

function WorkspaceStatus({ status }: { status: RegisteredWorkspace["status"] }) {
  if (!status || status === "active") return null;
  return <span className={styles.navigationStatus} data-workspace-status={status}>{workspaceStatusLabels[status]}</span>;
}

function WorkspaceButton({
  workspace,
  activeWorkspace,
  onWorkspaceChange,
  labelClassName,
}: {
  workspace: RegisteredWorkspace;
  activeWorkspace: BuilderWorkspaceId;
  onWorkspaceChange: (workspace: BuilderWorkspaceId) => void;
  labelClassName?: string;
}) {
  return (
    <button
      type="button"
      className={styles.navigationButton}
      aria-current={activeWorkspace === workspace.id ? "page" : undefined}
      onClick={() => onWorkspaceChange(workspace.id)}
      title={workspace.label}
    >
      <WorkspaceIcon name={workspace.icon} />
      <span className={labelClassName}>{workspace.label}</span>
      <WorkspaceStatus status={workspace.status} />
    </button>
  );
}

function DesktopPageLinks({
  pageLinks,
  currentPath,
  onPageChange,
}: {
  pageLinks: readonly WebsitePageLink[];
  currentPath?: string;
  onPageChange?: (path: string) => void;
}) {
  return (
    <nav className={styles.pageLinks} aria-label="Site pages">
      {pageLinks.map((page) => (
        <a
          key={page.path}
          className={styles.pageLink}
          href={`?path=${encodeURIComponent(page.path)}`}
          aria-current={page.path === currentPath ? "page" : undefined}
          onClick={onPageChange ? (event) => {
            event.preventDefault();
            onPageChange(page.path);
          } : undefined}
        >
          {page.label}
        </a>
      ))}
    </nav>
  );
}

export function ResponsiveNavigation({
  siteLabel,
  siteStatus = "Site editor",
  workspaces,
  activeWorkspace,
  onWorkspaceChange,
  pageLinks = [],
  currentPath,
  pagesExpanded = true,
  onTogglePages,
  onPageChange,
}: ResponsiveNavigationProps) {
  const [moreOpen, setMoreOpen] = useState(false);
  const moreTriggerRef = useRef<HTMLButtonElement | null>(null);
  const moreDialogRef = useRef<HTMLElement | null>(null);
  const isNonMobile = useMediaQuery("(min-width: 768px)");
  const primary = mobileDestinations.flatMap((destination, canonicalOrder) => {
    const workspace = destination.ids
      .map((id) => workspaces.find((candidate) => candidate.id === id))
      .find((candidate): candidate is RegisteredWorkspace => Boolean(candidate));
    return workspace ? [{ workspace, label: destination.label, canonicalOrder }] : [];
  }).sort((left, right) => {
    const leftPriority = left.workspace.mobilePriority ?? left.canonicalOrder + 1;
    const rightPriority = right.workspace.mobilePriority ?? right.canonicalOrder + 1;
    return leftPriority - rightPriority || left.canonicalOrder - right.canonicalOrder;
  });
  const primaryIds = new Set(primary.map(({ workspace }) => workspace.id));
  const remaining = workspaces
    .filter((workspace) => !primaryIds.has(workspace.id))
    .sort((left, right) => (left.mobilePriority ?? Number.MAX_SAFE_INTEGER) - (right.mobilePriority ?? Number.MAX_SAFE_INTEGER));
  const activeIsRemaining = remaining.some((workspace) => workspace.id === activeWorkspace);

  function closeMore() {
    setMoreOpen(false);
  }

  useEffect(() => {
    if (moreOpen && isNonMobile) closeMore();
  }, [isNonMobile, moreOpen]);

  useEffect(() => {
    if (!moreOpen) return;

    const container = moreDialogRef.current;
    if (!container) return;
    const releaseScrollLock = acquireBodyScrollLock();
    const unregisterModalFocus = registerModalFocus({
      container,
      onEscape: closeMore,
      restoreFocusTo: moreTriggerRef.current,
    });
    return () => {
      unregisterModalFocus();
      releaseScrollLock();
    };
  }, [moreOpen]);

  function chooseWorkspace(workspace: RegisteredWorkspace) {
    onWorkspaceChange(workspace.id);
    closeMore();
  }

  function chooseDesktopWorkspace(workspace: RegisteredWorkspace) {
    onWorkspaceChange(workspace.id);
    if (workspace.id === "website.pages") onTogglePages?.();
  }

  return (
    <>
      <aside className={styles.desktopNavigation} data-builder-navigation-surface="desktop">
        <div className={styles.siteIdentity}>
          <strong>{siteLabel}</strong>
          <span>{siteStatus}</span>
        </div>
        <nav className={styles.desktopNavigationGroups} aria-label="Editor workspaces">
          {(["website", "growth", "manage"] as const).map((group) => {
            const entries = workspaces.filter((workspace) => workspace.group === group);
            if (entries.length === 0) return null;
            return (
              <section key={group} className={styles.navigationGroup} data-builder-navigation-group={group}>
                <h2>{groupLabels[group]}</h2>
                {entries.map((workspace) => (
                  <div key={workspace.id}>
                    <button
                      type="button"
                      className={styles.navigationButton}
                      aria-current={activeWorkspace === workspace.id ? "page" : undefined}
                      aria-expanded={workspace.id === "website.pages" ? pagesExpanded : undefined}
                      aria-label={workspace.id === "website.pages" ? "Toggle pages list" : undefined}
                      onClick={() => chooseDesktopWorkspace(workspace)}
                    >
                      <WorkspaceIcon name={workspace.icon} />
                      <span>{workspace.label}</span>
                      <WorkspaceStatus status={workspace.status} />
                      {workspace.id === "website.pages" ? <Menu size={16} aria-hidden="true" /> : null}
                    </button>
                    {workspace.id === "website.pages" && pagesExpanded && pageLinks.length > 0 ? (
                      <DesktopPageLinks pageLinks={pageLinks} currentPath={currentPath} onPageChange={onPageChange} />
                    ) : null}
                  </div>
                ))}
              </section>
            );
          })}
        </nav>
      </aside>

      <nav
        className={styles.tabletNavigation}
        aria-label="Tablet editor navigation"
        data-builder-navigation-surface="tablet"
      >
        {workspaces.map((workspace) => (
          <WorkspaceButton
            key={workspace.id}
            workspace={workspace}
            activeWorkspace={activeWorkspace}
            onWorkspaceChange={onWorkspaceChange}
            labelClassName={styles.navigationLabel}
          />
        ))}
      </nav>

      <header className={styles.mobileTopBar} data-builder-navigation-surface="mobile-top">
        <div>
          <strong>{siteLabel}</strong>
          <span>{siteStatus}</span>
        </div>
      </header>

      <nav
        className={styles.mobileBottomNav}
        aria-label="Mobile editor navigation"
        data-builder-navigation-surface="mobile-bottom"
        data-builder-mobile-count={primary.length + 1}
        style={{ "--mobile-navigation-columns": primary.length + 1 } as CSSProperties}
      >
        {primary.map(({ workspace, label }) => (
          <button
            key={workspace.id}
            type="button"
            className={styles.navigationButton}
            data-builder-mobile-destination={workspace.id}
            aria-current={activeWorkspace === workspace.id ? "page" : undefined}
            onClick={() => chooseWorkspace(workspace)}
          >
            <WorkspaceIcon name={workspace.icon} size={18} />
            <span>{label}</span>
            <WorkspaceStatus status={workspace.status} />
          </button>
        ))}
        <button
          ref={moreTriggerRef}
          type="button"
          className={styles.navigationButton}
          aria-label="More destinations"
          aria-expanded={moreOpen}
          aria-current={activeIsRemaining ? "page" : undefined}
          onClick={() => (moreOpen ? closeMore() : setMoreOpen(true))}
        >
          <MoreHorizontal size={19} aria-hidden="true" />
          <span>More</span>
        </button>
      </nav>

      {moreOpen ? (
        <div className={styles.moreBackdrop}>
          <section
            ref={moreDialogRef}
            className={styles.moreSheet}
            role="dialog"
            aria-modal="true"
            aria-label="More destinations"
            tabIndex={-1}
          >
            <header>
              <h2>More</h2>
              <button type="button" className={styles.iconButton} aria-label="Close more destinations" onClick={closeMore}>
                <X size={20} aria-hidden="true" />
              </button>
            </header>
            <div className={styles.moreDestinations}>
              {remaining.map((workspace) => (
                <WorkspaceButton
                  key={workspace.id}
                  workspace={workspace}
                  activeWorkspace={activeWorkspace}
                  onWorkspaceChange={() => chooseWorkspace(workspace)}
                />
              ))}
            </div>
          </section>
        </div>
      ) : null}
    </>
  );
}
