"use client";

import React, { type ReactNode } from "react";
import styles from "./editor-shell.module.css";

export interface RightPanelProps {
  title: string;
  children: ReactNode;
}

export function RightPanel({ title, children }: RightPanelProps) {
  return (
    <aside className={styles.rightPanel} aria-label="Editing controls">
      <h2 className={styles.editingSurfaceTitle}>{title}</h2>
      {children}
    </aside>
  );
}
