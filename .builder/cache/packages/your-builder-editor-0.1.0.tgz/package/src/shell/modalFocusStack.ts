import { containFocusWithin, focusFirstVisibleElement, getVisibleFocusableElements } from "./focusableElements.js";

export interface ModalFocusRegistration {
  container: HTMLElement;
  onEscape: () => void;
  restoreFocusTo?: HTMLElement | null;
}

interface ModalFocusEntry extends ModalFocusRegistration {
  id: symbol;
  previousFocus: HTMLElement | null;
}

const modalStack: ModalFocusEntry[] = [];
let listenersAttached = false;

function topModal() {
  return modalStack.at(-1);
}

function handleFocusIn(event: FocusEvent) {
  containFocusWithin(topModal()?.container ?? null, event.target);
}

function handleKeyDown(event: KeyboardEvent) {
  const modal = topModal();
  if (!modal) return;

  if (event.key === "Escape") {
    event.preventDefault();
    event.stopPropagation();
    modal.onEscape();
    return;
  }
  if (event.key !== "Tab") return;

  const focusable = getVisibleFocusableElements(modal.container);
  const first = focusable[0];
  const last = focusable.at(-1);
  if (!first || !last) {
    event.preventDefault();
    modal.container.focus();
    return;
  }

  const activeElement = document.activeElement;
  if (!modal.container.contains(activeElement)) {
    event.preventDefault();
    (event.shiftKey ? last : first).focus();
  } else if (event.shiftKey && activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && activeElement === last) {
    event.preventDefault();
    first.focus();
  }
}

function attachListeners() {
  if (listenersAttached) return;
  document.addEventListener("focusin", handleFocusIn);
  document.addEventListener("keydown", handleKeyDown);
  listenersAttached = true;
}

function detachListeners() {
  if (!listenersAttached || modalStack.length > 0) return;
  document.removeEventListener("focusin", handleFocusIn);
  document.removeEventListener("keydown", handleKeyDown);
  listenersAttached = false;
}

export function registerModalFocus({ container, onEscape, restoreFocusTo }: ModalFocusRegistration) {
  const entry: ModalFocusEntry = {
    id: Symbol("modal-focus"),
    container,
    onEscape,
    previousFocus:
      restoreFocusTo ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null),
  };
  modalStack.push(entry);
  attachListeners();
  focusFirstVisibleElement(container);
  let registered = true;

  return () => {
    if (!registered) return;
    registered = false;
    const index = modalStack.findIndex((candidate) => candidate.id === entry.id);
    if (index < 0) return;
    const wasTop = index === modalStack.length - 1;
    modalStack.splice(index, 1);
    detachListeners();
    if (wasTop && entry.previousFocus?.isConnected) entry.previousFocus.focus();
  };
}
