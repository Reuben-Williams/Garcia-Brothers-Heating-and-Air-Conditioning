"use client";

import React, { useEffect, useId, useRef, type ReactNode } from "react";
import { X } from "lucide-react";
import { acquireBodyScrollLock } from "./bodyScrollLock.js";
import { registerModalFocus } from "./modalFocusStack.js";
import styles from "./editor-shell.module.css";

export interface MobileBottomSheetProps {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}

export function MobileBottomSheet({ open, title, onClose, children }: MobileBottomSheetProps) {
  const titleId = useId();
  const sheetRef = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose);

  useEffect(() => {
    onCloseRef.current = onClose;
  }, [onClose]);

  useEffect(() => {
    if (!open) return;

    const container = sheetRef.current;
    if (!container) return;
    const releaseScrollLock = acquireBodyScrollLock();
    const unregisterModalFocus = registerModalFocus({
      container,
      onEscape: () => onCloseRef.current(),
    });
    return () => {
      unregisterModalFocus();
      releaseScrollLock();
    };
  }, [open]);

  if (!open) return null;

  return (
    <div
      className={styles.editingSheetBackdrop}
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onCloseRef.current();
      }}
    >
      <div
        ref={sheetRef}
        className={styles.editingSheet}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
      >
        <header className={styles.editingSheetHeader}>
          <h2 id={titleId} className={styles.editingSurfaceTitle}>{title}</h2>
          <button
            type="button"
            className={styles.editingSheetClose}
            aria-label="Close editing controls"
            onClick={() => onCloseRef.current()}
          >
            <X size={20} aria-hidden="true" />
          </button>
        </header>
        <div className={styles.editingSheetBody}>{children}</div>
      </div>
    </div>
  );
}
