import type { ReactNode } from "react";
import type { BuilderWorkspaceId, RegisteredWorkspace } from "./types.js";

export interface WorkspaceRegistryHostProps {
  activeWorkspace: BuilderWorkspaceId;
  website: ReactNode;
  workspaces: readonly RegisteredWorkspace[];
}

function RegisteredWorkspaceContent({ workspace }: { workspace: RegisteredWorkspace }) {
  return workspace.render();
}

export function WorkspaceRegistryHost({
  activeWorkspace,
  website,
  workspaces,
}: WorkspaceRegistryHostProps) {
  const active = workspaces.find((workspace) => workspace.id === activeWorkspace);
  const websiteActive = !active;

  return (
    <div data-builder-workspace-host style={{ display: "contents" }}>
      <section
        data-builder-workspace="website"
        data-builder-workspace-active={websiteActive ? "true" : "false"}
        hidden={!websiteActive}
        style={{ display: websiteActive ? "contents" : "none" }}
      >
        {website}
      </section>
      {active ? (
        <section
          data-builder-workspace={active.id}
          data-builder-workspace-active="true"
          style={{ display: "contents" }}
        >
          <RegisteredWorkspaceContent key={active.id} workspace={active} />
        </section>
      ) : null}
    </div>
  );
}
