export interface RegionSelection {
  id: string;
  kind: string;
  value?: string;
  alt?: string;
  href?: string;
}

export interface RegionEditorDraft {
  value: string;
  alt: string;
  href: string;
}

export interface RegionEditorState {
  identityKey: string;
  sourceKey: string;
  sourceDraft: RegionEditorDraft;
  draft: RegionEditorDraft;
  dirty: boolean;
}

export function createRegionEditorDraft(selectedRegion?: RegionSelection): RegionEditorDraft {
  return {
    value: selectedRegion?.value ?? "",
    alt: selectedRegion?.alt ?? "",
    href: selectedRegion?.href ?? "",
  };
}

export function regionIdentityKey(selectedRegion?: RegionSelection) {
  return selectedRegion ? `${selectedRegion.id}\u0000${selectedRegion.kind}` : "";
}

export function regionSourceKey(selectedRegion?: RegionSelection) {
  return selectedRegion
    ? [selectedRegion.id, selectedRegion.kind, selectedRegion.value, selectedRegion.alt, selectedRegion.href].join("\u0000")
    : "";
}

export function regionDraftsMatch(left: RegionEditorDraft, right: RegionEditorDraft) {
  return left.value === right.value && left.alt === right.alt && left.href === right.href;
}

export function createRegionEditorState(selectedRegion?: RegionSelection): RegionEditorState {
  const draft = createRegionEditorDraft(selectedRegion);
  return {
    identityKey: regionIdentityKey(selectedRegion),
    sourceKey: regionSourceKey(selectedRegion),
    sourceDraft: draft,
    draft,
    dirty: false,
  };
}

export function resolveRegionEditorStateForRender(
  current: RegionEditorState,
  selectedRegion?: RegionSelection,
): RegionEditorState {
  const incoming = createRegionEditorState(selectedRegion);
  if (current.identityKey !== incoming.identityKey) return incoming;
  if (current.sourceKey === incoming.sourceKey || current.dirty) return current;
  return incoming;
}

export function reconcileRegionEditorState(
  current: RegionEditorState,
  selectedRegion?: RegionSelection,
): RegionEditorState {
  const incoming = createRegionEditorState(selectedRegion);
  if (current.identityKey !== incoming.identityKey) return incoming;
  if (current.sourceKey === incoming.sourceKey) return current;
  if (!current.dirty || regionDraftsMatch(incoming.draft, current.draft)) return incoming;
  return { ...current, sourceKey: incoming.sourceKey, sourceDraft: incoming.sourceDraft };
}
