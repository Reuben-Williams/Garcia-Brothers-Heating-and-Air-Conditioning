import React from "react";
import type { RichTextDocument } from "@your-builder/content";
import { RichTextEditor } from "./RichTextEditor.js";
import { PostPublishingPanel } from "./PostPublishingPanel.js";

export interface EditablePostDraft {
  entryId: string | null;
  draftVersionId: string | null;
  publishedVersionId: string | null;
  title: string;
  slug: string;
  excerpt: string;
  body: RichTextDocument;
  featuredImage:
    | { kind: "managed"; mediaId: string; revisionId: string; alt: string; previewUrl?: string }
    | { kind: "static"; src: string; alt: string; previewUrl?: string }
    | null;
  authorName: string;
  authorKey: string | null;
  categoryKeys: string[];
  tagKeys: string[];
  displayDate: string;
  expiresAt: string | null;
  featured: boolean;
  pinned: boolean;
  seoTitle: string;
  seoDescription: string;
  canonicalUrl: string | null;
  noIndex: boolean;
}

export function PostEditor({
  value,
  saving,
  onChange,
  onSave,
  onOpenMedia,
  showPublishingPanel = true,
}: {
  value: EditablePostDraft;
  saving: boolean;
  onChange: (value: EditablePostDraft) => void;
  onSave: () => void;
  onOpenMedia?: () => void;
  showPublishingPanel?: boolean;
}) {
  const update = <TKey extends keyof EditablePostDraft>(key: TKey, nextValue: EditablePostDraft[TKey]) =>
    onChange({ ...value, [key]: nextValue });
  const textList = (input: string) => input.split(",").map((item) => item.trim()).filter(Boolean);

  return (
    <form onSubmit={(event) => { event.preventDefault(); onSave(); }} style={styles.form}>
      <div style={styles.headingRow}>
        <div>
          <h2 style={styles.heading}>{value.entryId ? "Edit post" : "New post"}</h2>
          <span style={styles.muted}>Drafts can be saved before every publishing field is complete.</span>
        </div>
      </div>
      <label style={styles.label}>Post title<input value={value.title} onChange={(event) => update("title", event.target.value)} style={styles.input} /></label>
      <label style={styles.label}>Slug<input value={value.slug} onChange={(event) => update("slug", event.target.value)} style={styles.input} /></label>
      <label style={styles.label}>Excerpt<textarea value={value.excerpt} onChange={(event) => update("excerpt", event.target.value)} style={styles.textarea} /></label>
      <label style={styles.label}>Post body<RichTextEditor value={value.body} onChange={(body) => update("body", body)} /></label>

      <section style={styles.section}>
        <h3 style={styles.sectionTitle}>Featured image</h3>
        {value.featuredImage?.previewUrl ? <img src={value.featuredImage.previewUrl} alt="" style={styles.imagePreview} /> : null}
        <button type="button" onClick={onOpenMedia} style={styles.secondaryButton}>Choose from media gallery</button>
        <label style={styles.label}>Image alt text<input value={value.featuredImage?.alt ?? ""} onChange={(event) => value.featuredImage && update("featuredImage", { ...value.featuredImage, alt: event.target.value })} style={styles.input} /></label>
      </section>

      <div style={styles.twoColumns}>
        <label style={styles.label}>Author<input value={value.authorName} onChange={(event) => update("authorName", event.target.value)} style={styles.input} /></label>
        <label style={styles.label}>Display date<input type="datetime-local" value={value.displayDate.slice(0, 16)} onChange={(event) => update("displayDate", new Date(event.target.value).toISOString())} style={styles.input} /></label>
        <label style={styles.label}>Categories<input value={value.categoryKeys.join(", ")} onChange={(event) => update("categoryKeys", textList(event.target.value))} placeholder="news, infrastructure" style={styles.input} /></label>
        <label style={styles.label}>Tags<input value={value.tagKeys.join(", ")} onChange={(event) => update("tagKeys", textList(event.target.value))} placeholder="route-9, repairs" style={styles.input} /></label>
        <label style={styles.label}>Expiry date<input type="datetime-local" value={value.expiresAt?.slice(0, 16) ?? ""} onChange={(event) => update("expiresAt", event.target.value ? new Date(event.target.value).toISOString() : null)} style={styles.input} /></label>
        <div style={styles.checkboxGroup}>
          <label><input type="checkbox" checked={value.featured} onChange={(event) => update("featured", event.target.checked)} /> Featured</label>
          <label><input type="checkbox" checked={value.pinned} onChange={(event) => update("pinned", event.target.checked)} /> Pin first</label>
        </div>
      </div>

      <details style={styles.section}>
        <summary style={styles.summary}>Search and sharing</summary>
        <div style={styles.detailsBody}>
          <label style={styles.label}>SEO title<input value={value.seoTitle} onChange={(event) => update("seoTitle", event.target.value)} style={styles.input} /></label>
          <label style={styles.label}>SEO description<textarea value={value.seoDescription} onChange={(event) => update("seoDescription", event.target.value)} style={styles.textarea} /></label>
          <label style={styles.label}>Canonical URL<input value={value.canonicalUrl ?? ""} onChange={(event) => update("canonicalUrl", event.target.value || null)} style={styles.input} /></label>
          <label><input type="checkbox" checked={value.noIndex} onChange={(event) => update("noIndex", event.target.checked)} /> Hide from search engines</label>
        </div>
      </details>

      {showPublishingPanel ? <PostPublishingPanel saving={saving} onSave={onSave} /> : null}
    </form>
  );
}

const styles = {
  form: { display: "grid", gap: 18, minWidth: 0 },
  headingRow: { display: "flex", justifyContent: "space-between", gap: 12 },
  heading: { margin: 0, fontSize: 22 },
  muted: { color: "#667085", fontSize: 13 },
  label: { display: "grid", gap: 7, color: "#344054", fontSize: 13, fontWeight: 700 },
  input: { width: "100%", minWidth: 0, boxSizing: "border-box", border: "1px solid #c9d2df", borderRadius: 8, padding: 10, font: "inherit" },
  textarea: { width: "100%", minHeight: 96, boxSizing: "border-box", resize: "vertical", border: "1px solid #c9d2df", borderRadius: 8, padding: 10, font: "inherit" },
  section: { display: "grid", gap: 12, border: "1px solid #d7dde5", borderRadius: 8, padding: 14 },
  sectionTitle: { margin: 0, fontSize: 16 },
  imagePreview: { width: 180, aspectRatio: "4 / 3", objectFit: "cover", borderRadius: 6 },
  secondaryButton: { width: "100%", border: "1px solid #c9d2df", borderRadius: 8, background: "#fff", padding: "10px 13px", fontWeight: 700 },
  twoColumns: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 },
  checkboxGroup: { display: "flex", alignItems: "center", flexWrap: "wrap", gap: 16 },
  summary: { cursor: "pointer", fontWeight: 700 },
  detailsBody: { display: "grid", gap: 14, paddingTop: 14 },
} satisfies Record<string, React.CSSProperties>;
