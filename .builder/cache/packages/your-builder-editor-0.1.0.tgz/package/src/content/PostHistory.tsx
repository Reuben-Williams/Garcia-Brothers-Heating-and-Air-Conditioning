import React from "react";

export interface PostHistoryEvent {
  id: string;
  action: string;
  summary: string;
  actorLabel: string;
  createdAt: string;
  beforeText?: string;
  afterText?: string;
  beforeImage?: { src: string; alt: string };
  afterImage?: { src: string; alt: string };
  canUndo?: boolean;
  canRollback?: boolean;
  targetVersionId?: string;
}

export function PostHistory({
  events,
  onRollback,
  onUndo,
}: {
  events: readonly PostHistoryEvent[];
  onRollback: (eventId: string) => void;
  onUndo: (eventId: string) => void;
}) {
  return (
    <section aria-label="Post history" style={styles.shell}>
      <h2 style={styles.heading}>Post history</h2>
      {events.length === 0 ? <p style={styles.muted}>No saved changes yet.</p> : null}
      <ol style={styles.list}>
        {events.map((event) => (
          <li key={event.id} style={styles.event}>
            <strong>{event.summary}</strong>
            <span style={styles.muted}>{new Date(event.createdAt).toLocaleString()} by {event.actorLabel}</span>
            <div style={styles.comparison}>
              <HistorySide label="Before" text={event.beforeText} image={event.beforeImage} />
              <HistorySide label="After" text={event.afterText} image={event.afterImage} />
            </div>
            {event.canUndo ? (
              <button type="button" onClick={() => onUndo(event.targetVersionId ?? event.id)} style={styles.undoButton}>Undo rollback</button>
            ) : event.canRollback !== false ? (
              <button type="button" onClick={() => onRollback(event.targetVersionId ?? event.id)} style={styles.rollbackButton}>Rollback</button>
            ) : null}
          </li>
        ))}
      </ol>
    </section>
  );
}

function HistorySide({ label, text, image }: { label: string; text?: string; image?: { src: string; alt: string } }) {
  if (!text && !image) return null;
  return (
    <div style={styles.side}>
      <span style={styles.sideLabel}>{label}</span>
      {image ? <img src={image.src} alt={image.alt} style={styles.image} /> : null}
      {text ? <span>{text}</span> : null}
    </div>
  );
}

const styles = {
  shell: { display: "grid", gap: 14 },
  heading: { margin: 0, fontSize: 20 },
  muted: { color: "#667085", fontSize: 13 },
  list: { display: "grid", gap: 12, margin: 0, padding: 0, listStyle: "none" },
  event: { display: "grid", gap: 9, border: "1px solid #d7dde5", borderRadius: 8, padding: 14 },
  comparison: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 10 },
  side: { display: "grid", gap: 7, border: "1px solid #e4e7ec", borderRadius: 8, background: "#f8fafc", padding: 10 },
  sideLabel: { color: "#344054", fontSize: 12, fontWeight: 700, textTransform: "uppercase" },
  image: { width: 112, aspectRatio: "4 / 3", objectFit: "cover", borderRadius: 6 },
  rollbackButton: { width: 144, border: 0, borderRadius: 8, background: "#087f78", color: "#fff", padding: "10px 12px", fontWeight: 700 },
  undoButton: { width: 144, border: "1px solid #d92d20", borderRadius: 8, background: "#fff", color: "#b42318", padding: "10px 12px", fontWeight: 700 },
} satisfies Record<string, React.CSSProperties>;
