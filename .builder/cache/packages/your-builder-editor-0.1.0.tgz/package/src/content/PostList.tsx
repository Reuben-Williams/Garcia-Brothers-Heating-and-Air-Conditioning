import React, { useMemo, useState } from "react";
import { Plus, Search } from "lucide-react";

export type PostListStatus = "draft" | "scheduled" | "published" | "archived";

export interface PostListItem {
  entryId: string;
  title: string;
  slug: string;
  status: PostListStatus;
  updatedAt: string;
}

export function PostList({
  posts,
  onSelect,
  onCreate,
}: {
  posts: readonly PostListItem[];
  onSelect: (entryId: string) => void;
  onCreate: () => void;
}) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<"all" | PostListStatus>("all");
  const filtered = useMemo(() => {
    const query = search.trim().toLocaleLowerCase();
    return posts.filter(
      (post) =>
        (status === "all" || post.status === status) &&
        (!query || `${post.title} ${post.slug}`.toLocaleLowerCase().includes(query)),
    );
  }, [posts, search, status]);

  return (
    <section aria-label="Posts" style={styles.listPanel}>
      <div style={styles.headingRow}>
        <div>
          <h2 style={styles.heading}>Posts</h2>
          <span style={styles.muted}>{posts.length} total</span>
        </div>
        <button type="button" onClick={onCreate} style={styles.primaryButton}>
          <Plus size={17} aria-hidden="true" />
          New post
        </button>
      </div>
      <label style={styles.searchField}>
        <Search size={16} aria-hidden="true" />
        <input
          aria-label="Search posts"
          type="search"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search posts"
          style={styles.searchInput}
        />
      </label>
      <label style={styles.label}>
        Status
        <select value={status} onChange={(event) => setStatus(event.target.value as typeof status)} style={styles.input}>
          <option value="all">All statuses</option>
          <option value="draft">Draft</option>
          <option value="scheduled">Scheduled</option>
          <option value="published">Published</option>
          <option value="archived">Archived</option>
        </select>
      </label>
      <div style={styles.results}>
        {filtered.map((post) => (
          <button key={post.entryId} type="button" onClick={() => onSelect(post.entryId)} style={styles.postButton}>
            <strong>{post.title || "Untitled post"}</strong>
            <span style={styles.muted}>/{post.slug || "draft"}</span>
            <span style={styles.status}>{post.status[0].toUpperCase() + post.status.slice(1)}</span>
          </button>
        ))}
        {filtered.length === 0 ? <p style={styles.muted}>No posts match these filters.</p> : null}
      </div>
    </section>
  );
}

const styles = {
  listPanel: { display: "grid", alignContent: "start", gap: 16, minWidth: 0 },
  headingRow: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 },
  heading: { margin: 0, fontSize: 22 },
  muted: { color: "#667085", fontSize: 13 },
  primaryButton: {
    display: "inline-flex",
    alignItems: "center",
    gap: 7,
    border: 0,
    borderRadius: 8,
    background: "#175cd3",
    color: "#fff",
    padding: "10px 12px",
    fontWeight: 700,
  },
  searchField: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    border: "1px solid #c9d2df",
    borderRadius: 8,
    padding: "0 10px",
  },
  searchInput: { width: "100%", border: 0, outline: 0, padding: "10px 0", font: "inherit" },
  label: { display: "grid", gap: 6, color: "#344054", fontSize: 13, fontWeight: 700 },
  input: { width: "100%", border: "1px solid #c9d2df", borderRadius: 8, padding: 10, font: "inherit" },
  results: { display: "grid", gap: 8 },
  postButton: {
    display: "grid",
    gap: 4,
    width: "100%",
    border: "1px solid #d7dde5",
    borderRadius: 8,
    background: "#fff",
    padding: 12,
    textAlign: "left",
    font: "inherit",
  },
  status: { color: "#175cd3", fontSize: 12, fontWeight: 700, textTransform: "uppercase" },
} satisfies Record<string, React.CSSProperties>;
