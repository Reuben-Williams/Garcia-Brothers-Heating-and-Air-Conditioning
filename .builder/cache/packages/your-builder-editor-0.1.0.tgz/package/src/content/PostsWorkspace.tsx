import React from "react";
import { PostList, type PostListItem } from "./PostList.js";

export { PostList } from "./PostList.js";
export type { PostListItem, PostListStatus } from "./PostList.js";

export function PostsWorkspace({
  posts,
  selectedEntryId,
  loading,
  onCreate,
  onSelect,
  children,
}: {
  posts: readonly PostListItem[];
  selectedEntryId?: string | null;
  loading: boolean;
  onCreate: () => void;
  onSelect: (entryId: string) => void;
  children?: React.ReactNode;
}) {
  return (
    <section
      data-builder-posts-workspace
      className="builder-posts-workspace-layout"
      aria-busy={loading}
      style={{
        display: "grid",
        gap: 24,
        alignItems: "start",
        width: "100%",
      }}
    >
      <style>{postsWorkspaceResponsiveCss}</style>
      <PostList posts={posts} selectedEntryId={selectedEntryId} onCreate={onCreate} onSelect={onSelect} />
      <div style={{ minWidth: 0 }}>{children ?? <p style={{ color: "#667085" }}>Choose a post or create a new one.</p>}</div>
    </section>
  );
}

const postsWorkspaceResponsiveCss = `
  .builder-posts-workspace-layout {
    grid-template-columns: minmax(260px, 360px) minmax(0, 1fr);
  }
  @media (max-width: 900px) {
    .builder-posts-workspace-layout {
      grid-template-columns: 1fr;
    }
  }
`;
