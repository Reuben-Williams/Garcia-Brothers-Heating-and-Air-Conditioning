"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { Star, X } from "lucide-react";
import type { MediaAsset } from "@your-builder/core";
import { WorkspaceHeader } from "../shell/WorkspaceHeader.js";
import { acquireBodyScrollLock } from "../shell/bodyScrollLock.js";
import { registerModalFocus } from "../shell/modalFocusStack.js";

export interface MediaWorkspaceProps {
  mediaAssets: MediaAsset[];
}

const favoriteMediaStorageKey = "campaign-v1-editor:favorite-media";

function readFavoriteMediaIds() {
  if (typeof window === "undefined") return new Set<string>();
  try {
    const ids = JSON.parse(window.localStorage.getItem(favoriteMediaStorageKey) ?? "[]") as string[];
    return new Set(Array.isArray(ids) ? ids : []);
  } catch {
    return new Set<string>();
  }
}

function writeFavoriteMediaIds(ids: Set<string>) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(favoriteMediaStorageKey, JSON.stringify(Array.from(ids)));
  } catch {
    // Favorites remain usable for the current session when storage is unavailable.
  }
}

function friendlyAssetName(asset: MediaAsset) {
  return asset.label.replace(/\s+/g, " ").replace(/\bAsw Carmenmorales\b/i, "Campaign").trim();
}

function friendlyAssetLocation(asset: MediaAsset) {
  const parts = asset.path.split("/").filter(Boolean);
  const folder = parts.length > 1 ? parts.at(-2) : "Project media";
  return `${folder?.replace(/[-_]+/g, " ")} image`;
}

function MediaAssetCard({ asset, isFavorite, onOpen, onToggleFavorite }: {
  asset: MediaAsset;
  isFavorite: boolean;
  onOpen: () => void;
  onToggleFavorite: () => void;
}) {
  return (
    <article style={styles.mediaCard}>
      <button type="button" style={styles.mediaOpenButton} onClick={onOpen} title={`Open ${asset.label}`}>
        <img src={asset.url} alt={asset.alt} style={styles.mediaPreview} />
      </button>
      <div style={styles.mediaBody}>
        <div style={styles.mediaTitleRow}>
          <strong>{friendlyAssetName(asset)}</strong>
          <button
            type="button"
            style={{ ...styles.favoriteButton, ...(isFavorite ? styles.favoriteButtonActive : {}) }}
            onClick={onToggleFavorite}
            aria-pressed={isFavorite}
            aria-label={isFavorite ? `Remove ${asset.label} from favorites` : `Favorite ${asset.label}`}
          >
            <Star size={15} aria-hidden="true" fill={isFavorite ? "currentColor" : "none"} />
          </button>
        </div>
        <span style={styles.workspaceCardMeta}>{friendlyAssetLocation(asset)}</span>
        <details style={styles.technicalDetails}>
          <summary>Show details</summary>
          <span>{asset.path}</span>
          <span>{asset.mimeType}</span>
        </details>
      </div>
    </article>
  );
}

export function MediaWorkspace({ mediaAssets }: MediaWorkspaceProps) {
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(() => readFavoriteMediaIds());
  const [fullscreenAsset, setFullscreenAsset] = useState<MediaAsset | null>(null);
  const modalRef = useRef<HTMLElement>(null);
  const sortedAssets = useMemo(
    () => [...mediaAssets].sort((a, b) => Number(favoriteIds.has(b.id)) - Number(favoriteIds.has(a.id))),
    [favoriteIds, mediaAssets],
  );

  function toggleFavorite(assetId: string) {
    setFavoriteIds((current) => {
      const next = new Set(current);
      if (next.has(assetId)) next.delete(assetId);
      else next.add(assetId);
      writeFavoriteMediaIds(next);
      return next;
    });
  }

  useEffect(() => {
    if (!fullscreenAsset) return;

    const container = modalRef.current;
    if (!container) return;
    const releaseScrollLock = acquireBodyScrollLock();
    const unregisterModalFocus = registerModalFocus({
      container,
      onEscape: () => setFullscreenAsset(null),
    });
    return () => {
      unregisterModalFocus();
      releaseScrollLock();
    };
  }, [fullscreenAsset]);

  return (
    <section style={styles.contentWorkspace} aria-label="Media workspace" data-builder-content-workspace="media">
      <WorkspaceHeader
        title="Media library"
        eyebrow="Assets"
        description="Review project images, mark favorites for the page editor gallery, and open any image for a larger view."
      />
      <div style={styles.mediaGrid}>
        {sortedAssets.map((asset) => (
          <MediaAssetCard
            key={asset.id}
            asset={asset}
            isFavorite={favoriteIds.has(asset.id)}
            onOpen={() => setFullscreenAsset(asset)}
            onToggleFavorite={() => toggleFavorite(asset.id)}
          />
        ))}
      </div>
      {fullscreenAsset ? (
        <div
          style={styles.mediaModalBackdrop}
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setFullscreenAsset(null);
          }}
        >
          <section
            ref={modalRef}
            style={styles.mediaModal}
            role="dialog"
            aria-modal="true"
            aria-label={fullscreenAsset.label}
            tabIndex={-1}
          >
            <div style={styles.mediaModalHeader}>
              <div>
                <span style={styles.statusPill}>Media preview</span>
                <h3 style={styles.workspaceCardTitle}>{fullscreenAsset.label}</h3>
                <p style={styles.workspaceCardMeta}>{friendlyAssetLocation(fullscreenAsset)}</p>
              </div>
              <button
                type="button"
                style={styles.iconButton}
                onClick={() => setFullscreenAsset(null)}
                aria-label="Close media preview"
              >
                <X size={18} aria-hidden="true" />
              </button>
            </div>
            <img src={fullscreenAsset.url} alt={fullscreenAsset.alt} style={styles.mediaModalImage} />
            <div style={styles.mediaModalActions}>
              <button type="button" style={styles.secondaryButton} onClick={() => toggleFavorite(fullscreenAsset.id)}>
                <Star size={17} aria-hidden="true" fill={favoriteIds.has(fullscreenAsset.id) ? "currentColor" : "none"} />
                <span>{favoriteIds.has(fullscreenAsset.id) ? "Favorited" : "Favorite"}</span>
              </button>
              <details style={styles.technicalDetails}>
                <summary>Show technical details</summary>
                <span>{fullscreenAsset.path}</span>
                <span>{fullscreenAsset.mimeType}</span>
              </details>
            </div>
          </section>
        </div>
      ) : null}
    </section>
  );
}

const styles = {
  contentWorkspace: { minWidth: 0, overflow: "auto", background: "#f8fafc", padding: "24px" },
  mediaGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "14px" },
  mediaCard: { display: "grid", overflow: "hidden", border: "1px solid #d7dde5", borderRadius: "8px", background: "#fff" },
  mediaOpenButton: { width: "100%", border: 0, background: "#f8fafc", cursor: "zoom-in", padding: 0 },
  mediaPreview: { width: "100%", aspectRatio: "16 / 10", objectFit: "contain", background: "#eef2f6" },
  mediaBody: { display: "grid", gap: "5px", padding: "12px" },
  mediaTitleRow: { display: "grid", gridTemplateColumns: "minmax(0, 1fr) auto", alignItems: "center", gap: "8px" },
  favoriteButton: { display: "grid", placeItems: "center", width: "32px", height: "32px", border: "1px solid #d7dde5", borderRadius: "8px", background: "#fff", color: "#667085", cursor: "pointer" },
  favoriteButtonActive: { border: "1px solid #f59e0b", background: "#fffbeb", color: "#b45309" },
  workspaceCardMeta: { margin: 0, color: "#667085", fontSize: "13px" },
  technicalDetails: { display: "grid", gap: "4px", color: "#667085", fontSize: "12px", overflowWrap: "anywhere" },
  mediaModalBackdrop: { position: "fixed", inset: 0, zIndex: 50, display: "grid", placeItems: "center", background: "rgba(5, 12, 28, 0.62)", padding: "24px" },
  mediaModal: { display: "grid", gridTemplateRows: "auto minmax(0, 1fr) auto", gap: "16px", width: "min(980px, calc(100vw - 48px))", maxHeight: "min(860px, calc(100vh - 64px))", overflowY: "auto", overscrollBehavior: "contain", borderRadius: "8px", background: "#fff", boxShadow: "0 28px 90px rgba(0, 8, 30, 0.38)", padding: "18px" },
  mediaModalHeader: { display: "flex", alignItems: "start", justifyContent: "space-between", gap: "14px" },
  statusPill: { justifySelf: "start", border: "1px solid #b2ccff", borderRadius: "8px", background: "#eef4ff", color: "#175cd3", fontSize: "12px", fontWeight: 800, padding: "4px 8px" },
  workspaceCardTitle: { margin: 0, fontSize: "18px", lineHeight: 1.25 },
  iconButton: { display: "grid", placeItems: "center", width: "44px", height: "44px", border: "1px solid #d7dde5", borderRadius: "8px", background: "#fff", color: "#344054", cursor: "pointer" },
  mediaModalImage: { width: "100%", minHeight: 0, maxHeight: "calc(100vh - 260px)", borderRadius: "8px", background: "#eef2f6", objectFit: "contain" },
  mediaModalActions: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "12px" },
  secondaryButton: { minHeight: "44px", display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "7px", border: "1px solid #c9d2df", borderRadius: "8px", background: "#fff", color: "#344054", fontWeight: 700, padding: "10px 14px" },
} satisfies Record<string, React.CSSProperties>;
