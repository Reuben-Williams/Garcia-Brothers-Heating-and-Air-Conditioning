import React from "react";
import { EditorContent, useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import { richTextDocumentSchema, type RichTextDocument } from "@your-builder/content";

export function normalizeEditorDocument(value: unknown): RichTextDocument {
  const document = value && typeof value === "object" ? { version: 1, ...(value as object) } : value;
  return richTextDocumentSchema.parse(document);
}

export function RichTextEditor({ value, onChange }: { value: RichTextDocument; onChange: (value: RichTextDocument) => void }) {
  const editor = useEditor({
    immediatelyRender: false,
    extensions: [
      StarterKit.configure({
        heading: { levels: [2, 3, 4] },
        codeBlock: false,
      }),
    ],
    content: value,
    onUpdate: ({ editor: currentEditor }) => onChange(normalizeEditorDocument(currentEditor.getJSON())),
  });

  return (
    <div style={styles.shell}>
      <div role="toolbar" aria-label="Post body formatting" style={styles.toolbar}>
        <button type="button" aria-label="Bold" onClick={() => editor?.chain().focus().toggleBold().run()} style={styles.toolButton}>
          <strong>B</strong>
        </button>
        <button type="button" aria-label="Italic" onClick={() => editor?.chain().focus().toggleItalic().run()} style={styles.toolButton}>
          <em>I</em>
        </button>
        <button type="button" onClick={() => editor?.chain().focus().toggleHeading({ level: 2 }).run()} style={styles.toolButton}>
          H2
        </button>
        <button type="button" onClick={() => editor?.chain().focus().toggleBulletList().run()} style={styles.toolButton}>
          List
        </button>
        <button type="button" onClick={() => editor?.chain().focus().toggleBlockquote().run()} style={styles.toolButton}>
          Quote
        </button>
      </div>
      <EditorContent editor={editor} style={styles.content} />
    </div>
  );
}

const styles = {
  shell: { border: "1px solid #c9d2df", borderRadius: 8, overflow: "hidden" },
  toolbar: { display: "flex", flexWrap: "wrap", gap: 4, borderBottom: "1px solid #d7dde5", padding: 8 },
  toolButton: { minWidth: 36, border: "1px solid #d7dde5", borderRadius: 6, background: "#fff", padding: "7px 9px" },
  content: { minHeight: 220, padding: 14 },
} satisfies Record<string, React.CSSProperties>;
