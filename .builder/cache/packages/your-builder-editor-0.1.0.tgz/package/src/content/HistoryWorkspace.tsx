"use client";

import React from "react";
import type { AuditEvent, BuilderPage, EditableValue } from "@your-builder/core";
import { WorkspaceHeader } from "../shell/WorkspaceHeader.js";

export interface HistoryWorkspaceProps {
  auditLog: AuditEvent[];
  pages: BuilderPage[];
  onRestoreVersion: (event: AuditEvent) => void;
}

export interface HistoryEntriesProps extends HistoryWorkspaceProps {
  variant?: "panel" | "workspace";
}

function formatRegionLabel(regionId?: string) {
  if (!regionId) return "Selected area";
  const parts = regionId.split(/[.:]/).filter(Boolean);
  return parts
    .slice(-2)
    .map((part) => part.replace(/[-_]+/g, " "))
    .join(" ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function formatPageLabel(pagePath: string, pages: BuilderPage[]) {
  return pages.find((page) => page.path === pagePath)?.label ?? (pagePath === "/" ? "Home" : pagePath.replace("/", ""));
}

function formatAuditEventTitle(event: AuditEvent, pages: BuilderPage[]) {
  const actionLabel = event.action === "version.rolled_back" ? "Restored" : "Updated";
  const kindLabel = event.kind === "image" ? "image" : event.kind === "link" ? "link" : "text";
  return `${actionLabel} ${formatRegionLabel(event.regionId)} ${kindLabel}`;
}

function formatAuditEventMeta(event: AuditEvent, pages: BuilderPage[]) {
  const pageLabel = formatPageLabel(event.pagePath, pages);
  const actor = event.userLabel ?? event.userId;
  const time = new Date(event.createdAt).toLocaleString();
  return `${pageLabel} page - ${time}${actor ? ` by ${actor}` : ""}`;
}

function HistoryValue({ label, value }: { label: string; value?: EditableValue | null }) {
  if (!value) return null;
  if (value.type === "image") {
    return (
      <div style={styles.historyValue}>
        <strong style={styles.historyValueLabel}>{label}</strong>
        <img src={value.src} alt={`${label} preview`} style={styles.historyImage} />
        <span style={styles.muted}>{value.alt ?? value.src}</span>
      </div>
    );
  }

  const text = value.type === "link"
    ? `${value.label} -> ${value.href}`
    : value.type === "sections"
      ? value.value.join(", ")
      : value.type === "icon"
        ? value.icon
        : value.type === "postCollection"
          ? `Posts from ${value.sourceScopeKey}`
          : value.value;

  return (
    <div style={styles.historyValue}>
      <strong style={styles.historyValueLabel}>{label}</strong>
      <span>{text}</span>
    </div>
  );
}

function HistoryAccordionItem({ event, pages, onRestoreVersion }: HistoryWorkspaceProps & { event: AuditEvent }) {
  return (
    <li style={styles.historyListItem}>
      <details style={styles.historyItem}>
        <summary style={styles.historySummary}>
          <span style={styles.historySummaryText}>
            <strong>{formatAuditEventTitle(event, pages)}</strong>
            <span style={styles.muted}>{formatAuditEventMeta(event, pages)}</span>
            <span style={styles.muted}>Area: {formatRegionLabel(event.regionId)}</span>
          </span>
          <span style={styles.historySummaryHint}>Expand to review details</span>
        </summary>
        <div style={styles.historyItemDetails}>
          <dl style={styles.historyValues}>
            <HistoryValue label="Before" value={event.before} />
            <HistoryValue label="After" value={event.after} />
          </dl>
          <button
            type="button"
            style={event.action === "version.rolled_back" ? styles.secondaryButton : styles.primaryButton}
            onClick={() => onRestoreVersion(event)}
          >
            {event.action === "version.rolled_back" ? "Undo restore" : "Restore previous version"}
          </button>
        </div>
      </details>
    </li>
  );
}

export function HistoryEntries({ auditLog, pages, onRestoreVersion, variant = "panel" }: HistoryEntriesProps) {
  return (
    <ol style={variant === "workspace" ? styles.workspaceHistoryList : styles.historyList}>
      {auditLog.map((event) => (
        <HistoryAccordionItem
          key={event.id}
          event={event}
          auditLog={auditLog}
          pages={pages}
          onRestoreVersion={onRestoreVersion}
        />
      ))}
    </ol>
  );
}

export function HistoryWorkspace({ auditLog, pages, onRestoreVersion }: HistoryWorkspaceProps) {
  return (
    <section style={styles.contentWorkspace} aria-label="History workspace" data-builder-content-workspace="history">
      <WorkspaceHeader
        title="Change history"
        eyebrow="Versions"
        description="Track editor changes, published revisions, and rollback options for the selected campaign site."
      />
      {auditLog.length > 0 ? (
        <HistoryEntries auditLog={auditLog} pages={pages} onRestoreVersion={onRestoreVersion} variant="workspace" />
      ) : (
        <div style={styles.emptyState}>
          <h3 style={styles.workspaceCardTitle}>No changes recorded yet</h3>
          <p style={styles.workspaceCardText}>
            Edit any region on {pages[0]?.label ?? "a page"} and save it to populate this history workspace.
          </p>
        </div>
      )}
    </section>
  );
}

const styles = {
  muted: { color: "#667085", fontSize: "13px" },
  contentWorkspace: { minWidth: 0, overflow: "auto", background: "#f8fafc", padding: "24px" },
  workspaceHistoryList: { display: "grid", gap: "12px", maxHeight: "min(620px, calc(100vh - 210px))", overflowY: "auto", listStyle: "none", margin: 0, padding: "0 4px 0 0" },
  historyList: { display: "grid", gap: "10px", maxHeight: "min(420px, calc(100vh - 410px))", overflowY: "auto", listStyle: "none", margin: 0, padding: "0 4px 0 0" },
  historyListItem: { listStyle: "none" },
  historyItem: { border: "1px solid #e4e7ec", borderRadius: "8px", background: "#fff", overflow: "hidden" },
  historySummary: { display: "grid", gridTemplateColumns: "1fr", gap: "10px", alignItems: "start", cursor: "pointer", listStyle: "none", padding: "10px" },
  historySummaryText: { display: "grid", gap: "4px", minWidth: 0 },
  historySummaryHint: { justifySelf: "stretch", boxSizing: "border-box", width: "100%", borderRadius: "8px", background: "#eef4ff", color: "#175cd3", fontSize: "12px", fontWeight: 800, padding: "5px 8px", textAlign: "center", whiteSpace: "normal" },
  historyItemDetails: { display: "grid", gap: "10px", borderTop: "1px solid #e4e7ec", background: "#fbfcff", padding: "10px" },
  historyValues: { display: "grid", gap: "8px", margin: 0 },
  historyValue: { display: "grid", gap: "4px", border: "1px solid #eef2f7", borderRadius: "8px", background: "#f8fafc", padding: "8px" },
  historyValueLabel: { color: "#344054", fontSize: "12px", textTransform: "uppercase" },
  historyImage: { width: "72px", height: "52px", objectFit: "cover", borderRadius: "6px" },
  primaryButton: { display: "inline-flex", alignItems: "center", gap: "7px", border: 0, borderRadius: "8px", background: "#175cd3", color: "#fff", fontWeight: 700, padding: "10px 14px" },
  secondaryButton: { display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "7px", border: "1px solid #c9d2df", borderRadius: "8px", background: "#fff", color: "#344054", fontWeight: 700, padding: "10px 14px" },
  emptyState: { display: "grid", gap: "8px", maxWidth: "560px", border: "1px solid #d7dde5", borderRadius: "8px", background: "#fff", padding: "18px" },
  workspaceCardTitle: { margin: 0, fontSize: "18px", lineHeight: 1.25 },
  workspaceCardText: { margin: 0, color: "#344054", fontSize: "14px", lineHeight: 1.5 },
} satisfies Record<string, React.CSSProperties>;
