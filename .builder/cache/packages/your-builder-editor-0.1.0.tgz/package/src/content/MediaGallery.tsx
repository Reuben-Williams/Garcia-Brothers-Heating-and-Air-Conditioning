import React, { useEffect, useState } from "react";
import { ImagePlus, X } from "lucide-react";

export interface BuilderMediaChoice {
  mediaId: string;
  revisionId: string;
  label: string;
  alt: string;
  mimeType: string;
  url: string;
}

export function MediaGallery({
  open,
  assets,
  uploading,
  onClose,
  onSelect,
  onUpload,
}: {
  open: boolean;
  assets: readonly BuilderMediaChoice[];
  uploading: boolean;
  onClose: () => void;
  onSelect: (asset: BuilderMediaChoice) => void;
  onUpload: (file: File, metadata: { label: string; alt: string }) => void;
}) {
  const [label, setLabel] = useState("");
  const [alt, setAlt] = useState("");

  useEffect(() => {
    if (!open) return;
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [onClose, open]);

  if (!open) return null;
  return (
    <div style={styles.backdrop} onMouseDown={onClose}>
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="builder-media-title"
        style={styles.modal}
        onMouseDown={(event) => event.stopPropagation()}
      >
        <style>{mediaGalleryResponsiveCss}</style>
        <header style={styles.header}>
          <div>
            <span style={styles.eyebrow}>Private site library</span>
            <h2 id="builder-media-title" style={styles.heading}>Media gallery</h2>
          </div>
          <button type="button" aria-label="Close media gallery" onClick={onClose} style={styles.iconButton}><X size={20} /></button>
        </header>

        <div className="builder-media-gallery-content" style={styles.content}>
          <section className="builder-media-gallery-upload" aria-label="Upload image" style={styles.uploadPanel}>
            <h3 style={styles.subheading}>Upload a new image</h3>
            <label style={styles.label}>Image name<input value={label} onChange={(event) => setLabel(event.target.value)} style={styles.input} /></label>
            <label style={styles.label}>Alt text<input value={alt} onChange={(event) => setAlt(event.target.value)} style={styles.input} /></label>
            <label style={styles.uploadButton}>
              <ImagePlus size={18} aria-hidden="true" />
              {uploading ? "Uploading..." : "Upload image"}
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp,image/gif,image/avif"
                disabled={uploading}
                hidden
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (file) onUpload(file, { label: label.trim() || file.name, alt: alt.trim() });
                  event.target.value = "";
                }}
              />
            </label>
          </section>

          <section aria-label="Available images" style={styles.library}>
            {assets.length === 0 ? <p style={styles.muted}>No uploaded images yet.</p> : null}
            <div style={styles.grid}>
              {assets.map((asset) => (
                <button key={`${asset.mediaId}:${asset.revisionId}`} type="button" onClick={() => onSelect(asset)} style={styles.asset}>
                  <img src={asset.url} alt="" style={styles.image} />
                  <strong>{asset.label}</strong>
                  <span style={styles.muted}>{asset.alt || "Alt text needed"}</span>
                </button>
              ))}
            </div>
          </section>
        </div>
      </section>
    </div>
  );
}

const styles = {
  backdrop: { position: "fixed", inset: 0, zIndex: 1000, display: "grid", placeItems: "center", background: "rgba(15, 23, 42, 0.58)", padding: 24 },
  modal: { display: "grid", gridTemplateRows: "auto minmax(0, 1fr)", width: "min(980px, 100%)", maxHeight: "min(760px, calc(100vh - 48px))", overflow: "hidden", borderRadius: 8, background: "#fff", boxShadow: "0 24px 80px rgba(15, 23, 42, 0.35)" },
  header: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, borderBottom: "1px solid #d7dde5", padding: "18px 22px" },
  eyebrow: { color: "#087f78", fontSize: 12, fontWeight: 800, textTransform: "uppercase" },
  heading: { margin: "3px 0 0", fontSize: 24 },
  iconButton: { display: "grid", placeItems: "center", width: 40, height: 40, border: "1px solid #c9d2df", borderRadius: 8, background: "#fff" },
  content: { display: "grid", minHeight: 0, overflow: "auto" },
  uploadPanel: { display: "grid", alignContent: "start", gap: 14, borderRight: "1px solid #d7dde5", background: "#f8fafc", padding: 22 },
  subheading: { margin: 0, fontSize: 17 },
  label: { display: "grid", gap: 7, color: "#344054", fontSize: 13, fontWeight: 700 },
  input: { width: "100%", boxSizing: "border-box", border: "1px solid #c9d2df", borderRadius: 8, padding: 10, font: "inherit" },
  uploadButton: { display: "flex", alignItems: "center", justifyContent: "center", gap: 8, borderRadius: 8, background: "#087f78", color: "#fff", padding: "11px 14px", fontWeight: 800, cursor: "pointer" },
  library: { minWidth: 0, padding: 22 },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: 14 },
  asset: { display: "grid", gap: 7, minWidth: 0, border: "1px solid #d7dde5", borderRadius: 8, background: "#fff", padding: 9, textAlign: "left", font: "inherit" },
  image: { width: "100%", aspectRatio: "4 / 3", objectFit: "cover", borderRadius: 6, background: "#eef2f6" },
  muted: { color: "#667085", fontSize: 13 },
} satisfies Record<string, React.CSSProperties>;

const mediaGalleryResponsiveCss = `
  .builder-media-gallery-content {
    grid-template-columns: minmax(240px, 300px) minmax(0, 1fr);
  }
  @media (max-width: 700px) {
    .builder-media-gallery-content {
      grid-template-columns: 1fr;
    }
    .builder-media-gallery-upload {
      border-right: 0 !important;
      border-bottom: 1px solid #d7dde5;
    }
  }
`;
