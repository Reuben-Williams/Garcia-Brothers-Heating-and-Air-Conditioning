import React from "react";
import { Archive, CalendarClock, CalendarX, Eye, RotateCcw, Send, Save } from "lucide-react";

export function PostPublishingPanel({
  saving,
  publishing,
  publishBlockedReasons = [],
  archived = false,
  scheduled = false,
  onPreview,
  onSave,
  onPublish,
  onSchedule,
  onArchive,
  onRestore,
  onCancelSchedule,
  onReschedule,
}: {
  saving: boolean;
  publishing?: boolean;
  publishBlockedReasons?: readonly string[];
  archived?: boolean;
  scheduled?: boolean;
  onPreview?: () => void;
  onSave: () => void;
  onPublish?: () => void;
  onSchedule?: () => void;
  onArchive?: () => void;
  onRestore?: () => void;
  onCancelSchedule?: () => void;
  onReschedule?: () => void;
}) {
  const publishDisabled = publishing || publishBlockedReasons.length > 0;
  return (
    <section aria-label="Post publishing" style={styles.shell}>
      {publishBlockedReasons.length > 0 ? (
        <div role="status" style={styles.warning}>
          <strong>Finish these items before publishing:</strong>
          <ul style={{ margin: 0, paddingLeft: 20 }}>
            {publishBlockedReasons.map((reason) => <li key={reason}>{reason}</li>)}
          </ul>
        </div>
      ) : null}
      <div style={styles.actions}>
        {onPreview ? <button type="button" onClick={onPreview} style={styles.secondary}><Eye size={16} /> Preview</button> : null}
        <button type="button" disabled={saving} onClick={onSave} style={styles.secondary}><Save size={16} /> Save draft</button>
        {scheduled && onReschedule ? <button type="button" disabled={publishDisabled} onClick={onReschedule} style={styles.secondary}><CalendarClock size={16} /> Reschedule</button> : null}
        {scheduled && onCancelSchedule ? <button type="button" onClick={onCancelSchedule} style={styles.danger}><CalendarX size={16} /> Cancel schedule</button> : null}
        {!scheduled && onSchedule ? <button type="button" disabled={publishDisabled} onClick={onSchedule} style={styles.secondary}><CalendarClock size={16} /> Schedule</button> : null}
        {onPublish ? <button type="button" disabled={publishDisabled} onClick={onPublish} style={styles.primary}><Send size={16} /> Publish</button> : null}
        {archived && onRestore ? (
          <button type="button" onClick={onRestore} style={styles.secondary}><RotateCcw size={16} /> Restore draft</button>
        ) : onArchive ? (
          <button type="button" onClick={onArchive} style={styles.danger}><Archive size={16} /> Archive</button>
        ) : null}
      </div>
    </section>
  );
}

const styles = {
  shell: { display: "grid", gap: 12, borderTop: "1px solid #d7dde5", paddingTop: 16 },
  warning: { display: "grid", gap: 6, border: "1px solid #fdb022", borderRadius: 8, background: "#fffaeb", padding: 12, fontSize: 13 },
  actions: { display: "flex", flexWrap: "wrap", justifyContent: "flex-end", gap: 8 },
  secondary: { display: "inline-flex", alignItems: "center", gap: 7, border: "1px solid #c9d2df", borderRadius: 8, background: "#fff", padding: "10px 13px", fontWeight: 700 },
  primary: { display: "inline-flex", alignItems: "center", gap: 7, border: 0, borderRadius: 8, background: "#175cd3", color: "#fff", padding: "10px 13px", fontWeight: 700 },
  danger: { display: "inline-flex", alignItems: "center", gap: 7, border: "1px solid #fda29b", borderRadius: 8, background: "#fff", color: "#b42318", padding: "10px 13px", fontWeight: 700 },
} satisfies Record<string, React.CSSProperties>;
