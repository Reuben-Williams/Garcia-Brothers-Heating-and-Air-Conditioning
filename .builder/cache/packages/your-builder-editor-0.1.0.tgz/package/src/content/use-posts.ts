import { useCallback, useEffect, useState } from "react";
import type { BuilderApiClient } from "../api/builder-api.js";
import type { PostListItem } from "./PostList.js";

export function usePosts(client: BuilderApiClient) {
  const [posts, setPosts] = useState<PostListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setPosts(await client.request<PostListItem[]>("/posts"));
    } catch (caught) {
      setError(caught instanceof Error ? caught : new Error("Posts could not be loaded."));
    } finally {
      setLoading(false);
    }
  }, [client]);

  useEffect(() => { void refresh(); }, [refresh]);
  return { posts, loading, error, refresh };
}
