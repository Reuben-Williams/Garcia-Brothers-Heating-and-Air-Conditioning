export type BaseSubmissionReviewState = "new" | "reviewed" | "spam";
export type BaseSubmissionEnhancementState = "enhanced" | "base_only" | "review_required";

export interface BaseSubmissionSummary {
  readonly id: string;
  readonly formId: string;
  readonly sourcePage: string;
  readonly displayName: string;
  readonly capturedAt: string;
  readonly reviewState: BaseSubmissionReviewState;
  readonly enhancementState: BaseSubmissionEnhancementState;
  readonly version: number;
}

export interface BaseSubmissionField {
  readonly key: string;
  readonly label: string;
  readonly value: string;
}

export interface BaseSubmissionActivityItem {
  readonly id: string;
  readonly title: string;
  readonly description?: string;
  readonly occurredAt: string;
}

export interface BaseSubmissionDetail extends BaseSubmissionSummary {
  readonly fields: readonly BaseSubmissionField[];
  readonly activity: readonly BaseSubmissionActivityItem[];
}

export interface SubmissionsListQuery {
  readonly search?: string;
  readonly reviewState?: BaseSubmissionReviewState;
  readonly cursor?: string;
  readonly limit?: number;
}

export interface SubmissionsListResult {
  readonly items: readonly BaseSubmissionSummary[];
  readonly newCount: number;
  readonly nextCursor?: string;
}

export type SubmissionMutationResult =
  | { readonly status: "applied"; readonly version: number }
  | { readonly status: "conflict"; readonly currentVersion: number }
  | { readonly status: "denied"; readonly reason: string };

export type SubmissionExportResult =
  | { readonly status: "applied"; readonly exportId: string }
  | { readonly status: "denied"; readonly reason: string };

export interface SubmissionsApi {
  list(query: SubmissionsListQuery): Promise<SubmissionsListResult>;
  detail(submissionId: string): Promise<BaseSubmissionDetail>;
  markSpam(input: { readonly submissionId: string; readonly expectedVersion: number }): Promise<SubmissionMutationResult>;
  restore(input: { readonly submissionId: string; readonly expectedVersion: number }): Promise<SubmissionMutationResult>;
  requestExport(query: SubmissionsListQuery): Promise<SubmissionExportResult>;
}
