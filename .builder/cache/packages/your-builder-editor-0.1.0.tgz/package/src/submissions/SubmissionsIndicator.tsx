import { Inbox } from "lucide-react";
import styles from "./submissions.module.css";

export function SubmissionsIndicator({ count, onOpen }: {
  readonly count: number;
  readonly onOpen: () => void;
}) {
  const safeCount = Math.max(0, Math.floor(count));
  const label = safeCount === 1 ? "1 new submission" : `${safeCount} new submissions`;
  return (
    <button
      type="button"
      className={styles.indicator}
      data-builder-submissions-indicator
      aria-label={`Open ${label}`}
      onClick={onOpen}
    >
      <Inbox size={18} aria-hidden="true" />
      <span>{label}</span>
    </button>
  );
}
