import { ChevronRight } from "lucide-react";
import { ResponsiveCollection, StatusBadge } from "../workspaces/index.js";
import type { BaseSubmissionSummary } from "./types.js";
import styles from "./submissions.module.css";

const capturedAtFormatter = new Intl.DateTimeFormat("en", {
  dateStyle: "medium",
  timeStyle: "short",
});

function enhancementLabel(state: BaseSubmissionSummary["enhancementState"]) {
  if (state === "base_only") return "Not in enhanced pipeline";
  if (state === "review_required") return "Review required";
  return "Enhanced lead";
}

function reviewTone(state: BaseSubmissionSummary["reviewState"]) {
  if (state === "spam") return "danger" as const;
  if (state === "new") return "info" as const;
  return "neutral" as const;
}

export function SubmissionList({ items, onOpen }: {
  readonly items: readonly BaseSubmissionSummary[];
  readonly onOpen: (submissionId: string) => void;
}) {
  const rowButton = (item: BaseSubmissionSummary, mobile = false) => (
    <button
      type="button"
      className={mobile ? styles.mobileRow : styles.rowButton}
      data-builder-submission-id={item.id}
      onClick={() => onOpen(item.id)}
    >
      <span className={styles.primaryCell}>
        <strong>{item.displayName}</strong>
        <small>{enhancementLabel(item.enhancementState)}</small>
      </span>
      {mobile ? (
        <>
          <StatusBadge tone={reviewTone(item.reviewState)}>{item.reviewState}</StatusBadge>
          <time dateTime={item.capturedAt}>{capturedAtFormatter.format(new Date(item.capturedAt))}</time>
          <ChevronRight size={18} aria-hidden="true" />
        </>
      ) : null}
    </button>
  );

  return (
    <div data-builder-submission-list>
      <ResponsiveCollection
        desktop={
          <table className={styles.table}>
            <thead><tr><th scope="col">Submission</th><th scope="col">Status</th><th scope="col">Source</th><th scope="col">Captured</th></tr></thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.id}>
                  <td>{rowButton(item)}</td>
                  <td><StatusBadge tone={reviewTone(item.reviewState)}>{item.reviewState}</StatusBadge></td>
                  <td>{item.formId}<small className={styles.blockMeta}>{item.sourcePage}</small></td>
                  <td><time dateTime={item.capturedAt}>{capturedAtFormatter.format(new Date(item.capturedAt))}</time></td>
                </tr>
              ))}
            </tbody>
          </table>
        }
        mobile={<div className={styles.mobileList}>{items.map((item) => <div key={item.id}>{rowButton(item, true)}</div>)}</div>}
      />
    </div>
  );
}
