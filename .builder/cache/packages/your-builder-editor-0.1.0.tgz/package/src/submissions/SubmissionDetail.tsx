import { ArrowLeft } from "lucide-react";
import {
  ActivityTimeline,
  DestructiveActionGuard,
  RecordDetailLayout,
  StatusBadge,
} from "../workspaces/index.js";
import type { BaseSubmissionDetail } from "./types.js";
import styles from "./submissions.module.css";

export function SubmissionDetail({ submission, onBack, onSpam, onRestore }: {
  readonly submission: BaseSubmissionDetail;
  readonly onBack: () => void;
  readonly onSpam: () => void | Promise<void>;
  readonly onRestore: () => void | Promise<void>;
}) {
  const spam = submission.reviewState === "spam";
  return (
    <div data-builder-submission-detail={submission.id}>
      <RecordDetailLayout
        title={submission.displayName}
        eyebrow="Submission"
        backAction={
          <button type="button" className={styles.backButton} onClick={onBack}>
            <ArrowLeft size={17} aria-hidden="true" />
            Back to submissions
          </button>
        }
        status={<StatusBadge tone={spam ? "danger" : submission.reviewState === "new" ? "info" : "neutral"}>{submission.reviewState}</StatusBadge>}
        summary={<p>{submission.formId} from {submission.sourcePage}</p>}
        actions={spam ? (
          <button type="button" className={styles.secondaryButton} data-submission-restore onClick={() => void onRestore()}>
            Restore
          </button>
        ) : (
          <DestructiveActionGuard
            triggerLabel="Mark as spam"
            title="Mark submission as spam?"
            description="The submission moves to Spam Review and can be restored later."
            confirmLabel="Mark as spam"
            triggerAttributes={{ "data-submission-spam-trigger": "" }}
            onConfirm={onSpam}
          />
        )}
        aside={<ActivityTimeline items={submission.activity} />}
      >
        <dl className={styles.fields}>
          {submission.fields.map((field) => (
            <div key={field.key}>
              <dt>{field.label}</dt>
              <dd>{field.value}</dd>
            </div>
          ))}
        </dl>
      </RecordDetailLayout>
    </div>
  );
}
