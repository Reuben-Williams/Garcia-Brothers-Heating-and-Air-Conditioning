"use client";

import { useEffect, useState } from "react";
import { Download, Search } from "lucide-react";
import type { BuilderRole } from "@your-builder/core";
import { WorkspaceHeader } from "../shell/WorkspaceHeader.js";
import {
  AsyncStatus,
  CollectionToolbar,
  WorkspaceState,
} from "../workspaces/index.js";
import { SubmissionDetail } from "./SubmissionDetail.js";
import { SubmissionList } from "./SubmissionList.js";
import type {
  BaseSubmissionDetail,
  SubmissionsApi,
  SubmissionsListQuery,
  SubmissionMutationResult,
} from "./types.js";
import styles from "./submissions.module.css";

export interface SubmissionsWorkspaceProps {
  readonly role: BuilderRole;
  readonly api: SubmissionsApi;
  readonly initialQuery?: SubmissionsListQuery;
  readonly onNewCountChange?: (count: number) => void;
}

function mutationMessage(result: SubmissionMutationResult, applied: string) {
  if (result.status === "applied") return applied;
  if (result.status === "conflict") return "This submission changed. Refresh and try again.";
  return "You no longer have permission to change this submission.";
}

export function SubmissionsWorkspace({ role, api, initialQuery, onNewCountChange }: SubmissionsWorkspaceProps) {
  const authorized = role === "owner" || role === "editor";
  const [query, setQuery] = useState<SubmissionsListQuery>(initialQuery ?? { limit: 25 });
  const [searchDraft, setSearchDraft] = useState(initialQuery?.search ?? "");
  const [items, setItems] = useState<Awaited<ReturnType<SubmissionsApi["list"]>>["items"]>([]);
  const [loading, setLoading] = useState(authorized);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [detail, setDetail] = useState<BaseSubmissionDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [exportPending, setExportPending] = useState(false);

  async function loadList() {
    setLoading(true);
    setError("");
    try {
      const result = await api.list(query);
      setItems(result.items);
      onNewCountChange?.(result.newCount);
    } catch {
      setError("Submissions could not be loaded. Try again.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (!authorized) return;
    void loadList();
  }, [authorized, api, query.search, query.reviewState, query.cursor, query.limit]);

  async function openDetail(submissionId: string) {
    setSelectedId(submissionId);
    setDetail(null);
    setDetailLoading(true);
    setError("");
    try {
      setDetail(await api.detail(submissionId));
    } catch {
      setError("Submission details could not be loaded. Try again.");
    } finally {
      setDetailLoading(false);
    }
  }

  async function refreshDetail(submissionId: string) {
    setDetail(await api.detail(submissionId));
    await loadList();
  }

  async function markSpam(submission: BaseSubmissionDetail) {
    const result = await api.markSpam({ submissionId: submission.id, expectedVersion: submission.version });
    setMessage(mutationMessage(result, "Submission moved to Spam Review."));
    if (result.status === "applied") await refreshDetail(submission.id);
  }

  async function restore(submission: BaseSubmissionDetail) {
    setError("");
    try {
      const result = await api.restore({ submissionId: submission.id, expectedVersion: submission.version });
      setMessage(mutationMessage(result, "Submission restored."));
      if (result.status === "applied") await refreshDetail(submission.id);
    } catch {
      setError("The submission could not be restored. Try again.");
    }
  }

  async function requestExport() {
    setExportPending(true);
    setError("");
    try {
      const result = await api.requestExport(query);
      setMessage(result.status === "applied"
        ? "Export requested. You can continue working while it is prepared."
        : "You no longer have permission to export submissions.");
    } catch {
      setError("The export could not be requested. Try again.");
    } finally {
      setExportPending(false);
    }
  }

  if (!authorized) {
    return (
      <section className={styles.workspace} data-builder-submissions-workspace>
        <WorkspaceState kind="denied" title="Submissions are restricted" description="Only site owners and editors can open the base submissions inbox." />
      </section>
    );
  }

  return (
    <section className={styles.workspace} data-builder-submissions-workspace>
      <WorkspaceHeader
        title="Submissions"
        eyebrow="Website"
        description="Review every website inquiry, including submissions not added to the enhanced pipeline."
      />
      <AsyncStatus message={error || message} assertive={Boolean(error)} />
      {selectedId ? (
        detailLoading ? <WorkspaceState kind="loading" title="Loading submission..." />
          : detail ? (
            <SubmissionDetail
              submission={detail}
              onBack={() => { setSelectedId(null); setDetail(null); }}
              onSpam={() => markSpam(detail)}
              onRestore={() => restore(detail)}
            />
          ) : <WorkspaceState kind="error" title="Submission unavailable" description={error || "Return to the inbox and try again."} />
      ) : (
        <>
          <CollectionToolbar
            search={
              <form className={styles.searchForm} onSubmit={(event) => {
                event.preventDefault();
                setQuery((current) => ({ ...current, search: searchDraft.trim() || undefined, cursor: undefined }));
              }}>
                <Search size={18} aria-hidden="true" />
                <input
                  type="search"
                  name="submission-search"
                  aria-label="Search submissions"
                  placeholder="Search submissions..."
                  autoComplete="off"
                  value={searchDraft}
                  onChange={(event) => setSearchDraft(event.currentTarget.value)}
                />
              </form>
            }
            filters={
              <label className={styles.filterField}>
                <span>Review state</span>
                <select
                  name="submission-review-state"
                  value={query.reviewState ?? ""}
                  onChange={(event) => setQuery((current) => ({
                    ...current,
                    reviewState: event.currentTarget.value as SubmissionsListQuery["reviewState"] || undefined,
                    cursor: undefined,
                  }))}
                >
                  <option value="">All</option>
                  <option value="new">New</option>
                  <option value="reviewed">Reviewed</option>
                  <option value="spam">Spam Review</option>
                </select>
              </label>
            }
            actions={
              <button
                type="button"
                className={styles.exportButton}
                data-submissions-export
                disabled={exportPending}
                onClick={() => void requestExport()}
              >
                <Download size={17} aria-hidden="true" />
                {exportPending ? "Requesting..." : "Export"}
              </button>
            }
          />
          {loading ? <WorkspaceState kind="loading" title="Loading submissions..." />
            : error ? <WorkspaceState kind="error" title="Submissions unavailable" description={error} action={<button type="button" onClick={() => void loadList()}>Try again</button>} />
              : items.length === 0 ? <WorkspaceState kind="empty" title="No submissions found" description="Adjust the search or review-state filter." />
                : <SubmissionList items={items} onOpen={(id) => void openDetail(id)} />}
        </>
      )}
    </section>
  );
}
