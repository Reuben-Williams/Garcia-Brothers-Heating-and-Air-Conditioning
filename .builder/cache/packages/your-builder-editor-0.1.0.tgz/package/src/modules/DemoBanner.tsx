import { Info, RotateCcw } from "lucide-react";
import styles from "./module-gate.module.css";

export interface DemoBannerProps {
  readonly moduleName: string;
  readonly onReset: () => void;
}

export function DemoBanner({ moduleName, onReset }: DemoBannerProps) {
  return (
    <aside className={styles.demoBanner} aria-label={`${moduleName} sample data preview`}>
      <div className={styles.demoMessage}>
        <Info size={18} aria-hidden="true" />
        <span><strong>Preview with sample data</strong><small>{moduleName}</small></span>
      </div>
      <button type="button" className={styles.resetButton} onClick={onReset}>
        <RotateCcw size={16} aria-hidden="true" />
        Reset demo
      </button>
    </aside>
  );
}
