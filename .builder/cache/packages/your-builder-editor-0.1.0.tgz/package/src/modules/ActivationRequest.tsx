import { useState } from "react";
import { CheckCircle2, LoaderCircle, Send, Undo2 } from "lucide-react";
import type { GrowthModuleId } from "@your-builder/feature-registry";
import type {
  ActivationRequestInput,
  ActivationRequestResult,
  BuilderApiClient,
} from "../api/builder-api.js";
import styles from "./activation-request.module.css";

type ActivationUiState =
  | "available"
  | "requested"
  | "request_withdrawn"
  | "trial_expired"
  | "provisioning"
  | "provisioning_error";

export interface ActivationRequestProps {
  readonly client: Pick<BuilderApiClient, "request">;
  readonly siteId: string;
  readonly moduleId: GrowthModuleId;
  readonly moduleName: string;
  readonly initialState: ActivationUiState;
  readonly withdrawalAllowed?: boolean;
  readonly createRequestId?: () => string;
}

export function ActivationRequest(props: ActivationRequestProps) {
  const [state, setState] = useState<ActivationUiState>(props.initialState);
  const [canWithdraw, setCanWithdraw] = useState(Boolean(props.withdrawalAllowed));
  const [note, setNote] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateRequest = async (action: "create" | "withdraw") => {
    const requestId = props.createRequestId?.() ?? crypto.randomUUID();
    setPending(true);
    setError(null);
    try {
      const body: ActivationRequestInput = {
        siteId: props.siteId,
        moduleId: props.moduleId,
        requestId,
        ...(note.trim() ? { note: note.trim() } : {}),
      };
      const result = await props.client.request<ActivationRequestResult>("/entitlements/activation", {
        method: action === "create" ? "POST" : "DELETE",
        body,
        idempotencyKey: requestId,
      });
      setState(result.state);
      setCanWithdraw(result.withdrawalAllowed);
    } catch {
      setError("We could not update this request. Try again.");
    } finally {
      setPending(false);
    }
  };

  if (state === "provisioning") {
    return <section className={styles.surface} aria-live="polite"><LoaderCircle size={20} aria-hidden="true" /> Preparing {props.moduleName}</section>;
  }

  if (state === "provisioning_error") {
    return (
      <section className={styles.surface} role="status">
        <strong>Setup could not be prepared.</strong>
        <span>Your request is still saved. A site operator can retry provisioning.</span>
      </section>
    );
  }

  if (state === "requested") {
    return (
      <section className={styles.surface} aria-live="polite">
        <div className={styles.confirmation}><CheckCircle2 size={20} aria-hidden="true" /><span><strong>Activation requested</strong><small>We will update this page when setup is ready.</small></span></div>
        {canWithdraw ? (
          <button type="button" className={styles.secondaryButton} disabled={pending} onClick={() => void updateRequest("withdraw")}>
            {pending ? <LoaderCircle size={16} aria-hidden="true" /> : <Undo2 size={16} aria-hidden="true" />}
            {pending ? "Withdrawing request" : "Withdraw request"}
          </button>
        ) : null}
        {error ? <p className={styles.error} role="alert">{error}</p> : null}
      </section>
    );
  }

  if (state === "request_withdrawn") {
    return <p className={styles.withdrawn} role="status">Request withdrawn</p>;
  }

  return (
    <section className={styles.surface} aria-labelledby={`${props.moduleId}-activation-title`}>
      <div>
        <h2 id={`${props.moduleId}-activation-title`}>Request {props.moduleName}</h2>
        <p>Send an activation request for review. Nothing is purchased or enabled immediately.</p>
      </div>
      <label className={styles.noteField}>
        <span>Business note <small>Optional</small></span>
        <textarea value={note} maxLength={500} rows={3} onChange={(event) => setNote(event.currentTarget.value)} />
      </label>
      <button type="button" className={styles.primaryButton} disabled={pending} onClick={() => void updateRequest("create")}>
        {pending ? <LoaderCircle size={17} aria-hidden="true" /> : <Send size={17} aria-hidden="true" />}
        {pending ? "Sending request" : "Request activation"}
      </button>
      {error ? <p className={styles.error} role="alert">{error}</p> : null}
    </section>
  );
}
