import type { EntitlementState } from "@your-builder/entitlements";

export type ModuleUiMode =
  | "demo"
  | "denied"
  | "requesting"
  | "provisioning"
  | "setup"
  | "operational"
  | "read_only"
  | "terminated";

export type EntitlementSnapshotStatus = "fresh" | "stale" | "missing" | "invalid";

export interface ModuleUiStateOptions {
  readonly hasPermission?: boolean;
  readonly setupComplete?: boolean;
  readonly incidentOverride?: "read_only" | "blocked" | null;
}

function assertNever(value: never): never {
  throw new Error(`Unhandled entitlement state: ${String(value)}`);
}

export function resolveModuleUiMode(
  state: EntitlementState,
  snapshotStatus: EntitlementSnapshotStatus,
  options: ModuleUiStateOptions = {},
): ModuleUiMode {
  if (options.hasPermission === false) return "denied";
  if (snapshotStatus === "missing" || snapshotStatus === "invalid") return "demo";
  if (snapshotStatus === "stale" || options.incidentOverride) {
    return "read_only";
  }

  switch (state) {
    case "available":
    case "request_withdrawn":
    case "trial_expired":
      return "demo";
    case "requested":
      return "requesting";
    case "provisioning":
    case "provisioning_error":
      return "provisioning";
    case "setup_required":
      return "setup";
    case "trialing":
    case "active":
    case "payment_attention":
    case "grace_period":
      return options.setupComplete === false ? "setup" : "operational";
    case "suspended":
    case "offboarding":
    case "termination_failed":
      return "read_only";
    case "terminated":
      return "terminated";
    default:
      return assertNever(state);
  }
}
