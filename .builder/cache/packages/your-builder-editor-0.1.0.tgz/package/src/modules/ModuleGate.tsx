import type { ReactNode } from "react";
import { DemoBanner } from "./DemoBanner.js";
import type { ModuleUiMode } from "./module-ui-state.js";
import styles from "./module-gate.module.css";

export interface ModuleGateProps {
  readonly mode: ModuleUiMode;
  readonly moduleName: string;
  readonly demo: ReactNode;
  readonly denied?: ReactNode;
  readonly operational: ReactNode;
  readonly readOnly?: ReactNode;
  readonly setup: ReactNode;
  readonly request: ReactNode;
  readonly readOnlyReason?: string;
  readonly onResetDemo: () => void;
}

export function ModuleGate(props: ModuleGateProps) {
  if (props.mode === "denied") {
    return (
      <section className={styles.moduleWorkspace} data-module-mode="denied">
        {props.denied ?? <p className={styles.terminatedNotice}>You do not have access to this module.</p>}
      </section>
    );
  }

  if (props.mode === "demo") {
    return (
      <section className={styles.moduleWorkspace} data-module-mode="demo">
        <DemoBanner moduleName={props.moduleName} onReset={props.onResetDemo} />
        {props.demo}
        {props.request}
      </section>
    );
  }

  if (props.mode === "requesting" || props.mode === "provisioning") {
    return (
      <section className={styles.moduleWorkspace} data-module-mode={props.mode} aria-live="polite">
        {props.request}
      </section>
    );
  }

  if (props.mode === "setup") {
    return <section className={styles.moduleWorkspace} data-module-mode="setup">{props.setup}</section>;
  }

  if (props.mode === "read_only") {
    return (
      <section className={styles.moduleWorkspace} data-module-mode="read_only">
        <p className={styles.readOnlyNotice} role="status">
          {props.readOnlyReason ?? "This module is temporarily read-only."}
        </p>
        <div data-module-read-only="true">{props.readOnly ?? props.operational}</div>
      </section>
    );
  }

  if (props.mode === "operational") {
    return <section className={styles.moduleWorkspace} data-module-mode="operational">{props.operational}</section>;
  }

  return (
    <section className={styles.moduleWorkspace} data-module-mode="terminated">
      <p className={styles.terminatedNotice}>This module is no longer active.</p>
    </section>
  );
}
