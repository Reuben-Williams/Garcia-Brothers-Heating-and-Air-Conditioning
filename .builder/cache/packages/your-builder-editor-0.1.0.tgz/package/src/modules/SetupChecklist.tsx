import { CheckCircle2, ChevronRight, Circle, LockKeyhole } from "lucide-react";
import styles from "./setup-checklist.module.css";

export interface SetupChecklistItem {
  readonly id: string;
  readonly label: string;
  readonly required: boolean;
  readonly completed: boolean;
  readonly hidden?: boolean;
  readonly disabled?: boolean;
  readonly disabledReason?: string;
  readonly evidence?: string;
  readonly error?: string;
  readonly testDestinationOnly?: boolean;
}

export interface SetupChecklistProps {
  readonly items: readonly SetupChecklistItem[];
  readonly onOpen: (id: string) => void;
  readonly suspended?: boolean;
}

export function SetupChecklist({ items, onOpen, suspended = false }: SetupChecklistProps) {
  const visibleItems = items.filter((item) => !item.hidden);
  const requiredItems = visibleItems.filter((item) => item.required);
  const complete = requiredItems.filter((item) => item.completed).length;

  return (
    <section className={styles.checklist} aria-labelledby="module-setup-title">
      <header className={styles.header}>
        <div>
          <h2 id="module-setup-title">Finish setup</h2>
          <p aria-live="polite">{complete} of {requiredItems.length} required steps complete</p>
        </div>
        <span className={styles.progress} aria-hidden="true">{complete}/{requiredItems.length}</span>
      </header>
      {suspended ? <p className={styles.suspended} role="status">Setup is paused while this module is suspended.</p> : null}
      <ol className={styles.steps}>
        {visibleItems.map((item) => {
          const disabled = suspended || Boolean(item.disabled);
          const errorId = item.error ? `setup-${item.id}-error` : undefined;
          const reason = suspended ? undefined : item.disabledReason;
          return (
            <li key={item.id} className={styles.step} data-setup-completed={item.completed ? "true" : "false"}>
              <button
                type="button"
                className={styles.stepButton}
                disabled={disabled}
                aria-describedby={errorId}
                onClick={() => onOpen(item.id)}
              >
                {disabled ? <LockKeyhole size={19} aria-hidden="true" /> : item.completed ? <CheckCircle2 size={20} aria-hidden="true" /> : <Circle size={20} aria-hidden="true" />}
                <span className={styles.stepCopy}>
                  <strong>{item.label}</strong>
                  <small>
                    {item.required ? "Required" : "Optional"}
                    {item.testDestinationOnly ? " · Test destination only" : ""}
                  </small>
                </span>
                <ChevronRight size={18} aria-hidden="true" />
              </button>
              {item.evidence ? <p className={styles.evidence}>{item.evidence}</p> : null}
              {reason ? <p className={styles.reason}>{reason}</p> : null}
              {item.error ? <p id={errorId} className={styles.error}>{item.error}</p> : null}
            </li>
          );
        })}
      </ol>
    </section>
  );
}
