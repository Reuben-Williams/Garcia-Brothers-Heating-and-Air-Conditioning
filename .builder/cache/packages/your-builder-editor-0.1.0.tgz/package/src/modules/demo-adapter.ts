export interface DemoAdapter<T extends { id: string }> {
  readonly externalEffects: false;
  list(): readonly T[];
  update(id: string, patch: Partial<Omit<T, "id">>): T;
  reset(): void;
}

export function createDemoAdapter<T extends { id: string }>(seed: readonly T[]): DemoAdapter<T> {
  const initialRecords = structuredClone(seed);
  let records = structuredClone(initialRecords);

  return Object.freeze({
    externalEffects: false as const,
    list: () => structuredClone(records),
    update: (id: string, patch: Partial<Omit<T, "id">>) => {
      const index = records.findIndex((record) => record.id === id);
      if (index === -1) throw new Error(`Unknown demo record: ${id}`);

      const updated = { ...records[index], ...structuredClone(patch), id } as T;
      records = records.map((record, recordIndex) => recordIndex === index ? updated : record);
      return structuredClone(updated);
    },
    reset: () => {
      records = structuredClone(initialRecords);
    },
  });
}
