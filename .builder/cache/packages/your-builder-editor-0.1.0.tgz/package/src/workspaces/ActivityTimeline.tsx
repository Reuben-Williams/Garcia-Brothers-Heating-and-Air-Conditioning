import styles from "./workspaces.module.css";

export interface ActivityTimelineItem {
  readonly id: string;
  readonly title: string;
  readonly description?: string;
  readonly occurredAt: string;
}

const timelineDateFormatter = new Intl.DateTimeFormat("en", {
  dateStyle: "medium",
  timeStyle: "short",
});

export function ActivityTimeline({
  items,
  emptyLabel = "No activity yet.",
}: {
  readonly items: readonly ActivityTimelineItem[];
  readonly emptyLabel?: string;
}) {
  return (
    <section className={styles.timeline} data-activity-timeline aria-label="Activity timeline">
      {items.length === 0 ? <p className={styles.muted}>{emptyLabel}</p> : (
        <ol>
          {items.map((item) => (
            <li key={item.id}>
              <span className={styles.timelineMarker} aria-hidden="true" />
              <div>
                <strong>{item.title}</strong>
                {item.description ? <p>{item.description}</p> : null}
                <time dateTime={item.occurredAt}>{timelineDateFormatter.format(new Date(item.occurredAt))}</time>
              </div>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}
