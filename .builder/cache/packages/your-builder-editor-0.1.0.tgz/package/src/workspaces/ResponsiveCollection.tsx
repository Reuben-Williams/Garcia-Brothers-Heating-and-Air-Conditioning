import type { ReactNode } from "react";
import styles from "./workspaces.module.css";

export function ResponsiveCollection({ desktop, mobile }: {
  readonly desktop: ReactNode;
  readonly mobile: ReactNode;
}) {
  return (
    <div className={styles.responsiveCollection} data-responsive-collection>
      <div className={styles.desktopCollection} data-collection-surface="desktop">{desktop}</div>
      <div className={styles.mobileCollection} data-collection-surface="mobile">{mobile}</div>
    </div>
  );
}
