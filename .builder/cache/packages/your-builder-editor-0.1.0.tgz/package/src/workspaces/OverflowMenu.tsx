"use client";

import { useEffect, useRef, useState } from "react";
import { MoreHorizontal } from "lucide-react";
import { registerModalFocus } from "../shell/modalFocusStack.js";
import styles from "./workspaces.module.css";

export interface OverflowMenuItem {
  readonly id: string;
  readonly label: string;
  readonly onSelect: () => void;
  readonly destructive?: boolean;
  readonly disabled?: boolean;
}

export function OverflowMenu({ label, items }: {
  readonly label: string;
  readonly items: readonly OverflowMenuItem[];
}) {
  const [open, setOpen] = useState(false);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open || !menuRef.current) return;
    return registerModalFocus({
      container: menuRef.current,
      onEscape: () => setOpen(false),
      restoreFocusTo: triggerRef.current,
    });
  }, [open]);

  return (
    <div className={styles.overflowMenu}>
      <button
        ref={triggerRef}
        type="button"
        className={styles.iconButton}
        aria-label={label}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((current) => !current)}
      >
        <MoreHorizontal size={19} aria-hidden="true" />
      </button>
      {open ? (
        <div ref={menuRef} className={styles.menu} role="menu" aria-label={label} tabIndex={-1}>
          {items.map((item) => (
            <button
              key={item.id}
              type="button"
              role="menuitem"
              className={item.destructive ? styles.dangerMenuItem : styles.menuItem}
              disabled={item.disabled}
              onClick={() => {
                setOpen(false);
                item.onSelect();
              }}
            >
              {item.label}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}
