"use client";

import { useRef, useState } from "react";
import { AsyncStatus } from "./AsyncStatus.js";
import { ConfirmationDialog } from "./ConfirmationDialog.js";
import styles from "./workspaces.module.css";

export interface DestructiveActionGuardProps {
  readonly triggerLabel: string;
  readonly title: string;
  readonly description: string;
  readonly confirmLabel: string;
  readonly disabled?: boolean;
  readonly reasonLabel?: string;
  readonly requireReason?: boolean;
  readonly triggerAttributes?: Readonly<Record<`data-${string}`, string>>;
  readonly onConfirm: (reason?: string) => void | Promise<void>;
}

export function DestructiveActionGuard(props: DestructiveActionGuardProps) {
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const [reason, setReason] = useState("");
  const triggerRef = useRef<HTMLButtonElement>(null);

  async function confirm() {
    setPending(true);
    setError("");
    try {
      await props.onConfirm(reason.trim() || undefined);
      setOpen(false);
      setReason("");
    } catch {
      setError("Action could not be completed. Try again.");
    } finally {
      setPending(false);
    }
  }

  return (
    <>
      <button
        {...props.triggerAttributes}
        ref={triggerRef}
        type="button"
        className={styles.dangerOutlineButton}
        data-destructive-trigger
        disabled={props.disabled}
        onClick={() => {
          setReason("");
          setOpen(true);
        }}
      >
        {props.triggerLabel}
      </button>
      <ConfirmationDialog
        open={open}
        title={props.title}
        description={props.description}
        confirmLabel={props.confirmLabel}
        pending={pending}
        confirmDisabled={props.requireReason && reason.trim().length === 0}
        restoreFocusTo={triggerRef.current}
        onCancel={() => setOpen(false)}
        onConfirm={() => void confirm()}
      >
        {props.reasonLabel ? (
          <label className={styles.dialogField}>
            <span>{props.reasonLabel}</span>
            <input
              aria-label={props.reasonLabel}
              maxLength={500}
              value={reason}
              onChange={(event) => setReason(event.currentTarget.value)}
              required={props.requireReason}
            />
          </label>
        ) : null}
      </ConfirmationDialog>
      <AsyncStatus message={error} assertive={Boolean(error)} />
    </>
  );
}
