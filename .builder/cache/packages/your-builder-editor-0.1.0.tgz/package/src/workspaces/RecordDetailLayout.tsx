import type { ReactNode } from "react";
import styles from "./workspaces.module.css";

export interface RecordDetailLayoutProps {
  readonly title: string;
  readonly eyebrow?: string;
  readonly backAction?: ReactNode;
  readonly status?: ReactNode;
  readonly actions?: ReactNode;
  readonly summary?: ReactNode;
  readonly aside?: ReactNode;
  readonly children: ReactNode;
}

export function RecordDetailLayout(props: RecordDetailLayoutProps) {
  return (
    <article className={styles.recordDetail} data-record-detail>
      {props.backAction ? <div className={styles.backAction}>{props.backAction}</div> : null}
      <header className={styles.detailHeader}>
        <div className={styles.detailHeading}>
          {props.eyebrow ? <span className={styles.eyebrow}>{props.eyebrow}</span> : null}
          <div className={styles.detailTitleRow}>
            <h2>{props.title}</h2>
            {props.status}
          </div>
          {props.summary}
        </div>
        {props.actions ? <div className={styles.detailActions}>{props.actions}</div> : null}
      </header>
      <div className={styles.detailBody}>
        <div className={styles.detailContent}>{props.children}</div>
        {props.aside ? <aside className={styles.detailAside}>{props.aside}</aside> : null}
      </div>
    </article>
  );
}
