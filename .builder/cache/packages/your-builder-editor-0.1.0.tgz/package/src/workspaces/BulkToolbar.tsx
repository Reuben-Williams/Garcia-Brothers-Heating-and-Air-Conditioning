import type { ReactNode } from "react";
import styles from "./workspaces.module.css";

export function BulkToolbar({ selectedCount, onClear, actions }: {
  readonly selectedCount: number;
  readonly onClear: () => void;
  readonly actions: ReactNode;
}) {
  if (selectedCount < 1) return null;
  return (
    <div className={styles.bulkToolbar} data-bulk-toolbar role="region" aria-label="Bulk actions">
      <strong>{selectedCount} selected</strong>
      <div className={styles.bulkActions}>{actions}</div>
      <button type="button" className={styles.secondaryButton} onClick={onClear}>Clear selection</button>
    </div>
  );
}
