import type { ReactNode } from "react";
import styles from "./workspaces.module.css";

export type WorkspaceStateKind =
  | "loading"
  | "empty"
  | "error"
  | "denied"
  | "read_only"
  | "suspended"
  | "stale"
  | "offboarding"
  | "terminated";

export interface WorkspaceStateProps {
  readonly kind: WorkspaceStateKind;
  readonly title: string;
  readonly description?: string;
  readonly action?: ReactNode;
}

export function WorkspaceState({ kind, title, description, action }: WorkspaceStateProps) {
  return (
    <section
      className={styles.workspaceState}
      data-workspace-state={kind}
      role={kind === "error" ? "alert" : kind === "loading" ? "status" : undefined}
      aria-live={kind === "loading" ? "polite" : undefined}
    >
      <h2>{title}</h2>
      {description ? <p>{description}</p> : null}
      {action ? <div className={styles.stateAction}>{action}</div> : null}
    </section>
  );
}
