import type { ReactNode } from "react";
import styles from "./workspaces.module.css";

export interface CollectionToolbarProps {
  readonly search?: ReactNode;
  readonly filters?: ReactNode;
  readonly sort?: ReactNode;
  readonly savedView?: ReactNode;
  readonly actions?: ReactNode;
}

export function CollectionToolbar({ search, filters, sort, savedView, actions }: CollectionToolbarProps) {
  return (
    <div className={styles.collectionToolbar} data-collection-toolbar>
      {search ? <div className={styles.searchSlot}>{search}</div> : null}
      <div className={styles.toolbarControls}>
        {savedView}
        {filters}
        {sort}
      </div>
      {actions ? <div className={styles.toolbarActions}>{actions}</div> : null}
    </div>
  );
}
