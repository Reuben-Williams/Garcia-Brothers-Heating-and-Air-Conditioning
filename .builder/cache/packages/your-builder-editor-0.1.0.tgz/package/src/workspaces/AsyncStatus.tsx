import styles from "./workspaces.module.css";

export interface AsyncStatusProps {
  readonly message?: string | null;
  readonly assertive?: boolean;
}

export function AsyncStatus({ message, assertive = false }: AsyncStatusProps) {
  return (
    <p
      className={styles.asyncStatus}
      data-builder-async-status
      role={assertive ? "alert" : "status"}
      aria-live={assertive ? "assertive" : "polite"}
      aria-atomic="true"
    >
      {message ?? ""}
    </p>
  );
}
