"use client";

import { useEffect, useId, useRef, type ReactNode } from "react";
import { X } from "lucide-react";
import { acquireBodyScrollLock } from "../shell/bodyScrollLock.js";
import { registerModalFocus } from "../shell/modalFocusStack.js";
import styles from "./workspaces.module.css";

export interface ConfirmationDialogProps {
  readonly open: boolean;
  readonly title: string;
  readonly description: string;
  readonly confirmLabel: string;
  readonly cancelLabel?: string;
  readonly dangerous?: boolean;
  readonly pending?: boolean;
  readonly confirmDisabled?: boolean;
  readonly children?: ReactNode;
  readonly restoreFocusTo?: HTMLElement | null;
  readonly onCancel: () => void;
  readonly onConfirm: () => void;
}

export function ConfirmationDialog(props: ConfirmationDialogProps) {
  const titleId = useId();
  const descriptionId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!props.open || !dialogRef.current) return;
    const releaseScrollLock = acquireBodyScrollLock();
    const unregisterFocus = registerModalFocus({
      container: dialogRef.current,
      onEscape: props.onCancel,
      restoreFocusTo: props.restoreFocusTo,
    });
    return () => {
      unregisterFocus();
      releaseScrollLock();
    };
  }, [props.open, props.onCancel, props.restoreFocusTo]);

  if (!props.open) return null;
  return (
    <div className={styles.dialogBackdrop} onMouseDown={(event) => {
      if (event.target === event.currentTarget && !props.pending) props.onCancel();
    }}>
      <div
        ref={dialogRef}
        className={styles.dialog}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={descriptionId}
        tabIndex={-1}
      >
        <header>
          <h2 id={titleId}>{props.title}</h2>
          <button type="button" className={styles.iconButton} aria-label="Close confirmation" disabled={props.pending} onClick={props.onCancel}>
            <X size={20} aria-hidden="true" />
          </button>
        </header>
        <p id={descriptionId}>{props.description}</p>
        {props.children}
        <footer>
          <button type="button" className={styles.secondaryButton} disabled={props.pending} onClick={props.onCancel}>
            {props.cancelLabel ?? "Cancel"}
          </button>
          <button
            type="button"
            className={props.dangerous === false ? styles.primaryButton : styles.dangerButton}
            disabled={props.pending || props.confirmDisabled}
            onClick={props.onConfirm}
          >
            {props.pending ? "Working..." : props.confirmLabel}
          </button>
        </footer>
      </div>
    </div>
  );
}
