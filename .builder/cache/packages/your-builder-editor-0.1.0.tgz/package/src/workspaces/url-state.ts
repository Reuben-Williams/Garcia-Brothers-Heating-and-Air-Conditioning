export interface WorkspaceUrlState {
  readonly query?: string;
  readonly sort?: string;
  readonly savedView?: string;
  readonly cursor?: string;
  readonly detailId?: string;
  readonly filters: Readonly<Record<string, readonly string[]>>;
}

export interface WorkspaceUrlStatePatch {
  readonly query?: string | null;
  readonly sort?: string | null;
  readonly savedView?: string | null;
  readonly cursor?: string | null;
  readonly detailId?: string | null;
  readonly filters?: Readonly<Record<string, readonly string[]>> | null;
}

const keys = {
  query: "ws.q",
  sort: "ws.sort",
  savedView: "ws.view",
  cursor: "ws.cursor",
  detailId: "ws.detail",
} as const;
const filterPrefix = "ws.filter.";

function asSearchParams(input: string | URLSearchParams): URLSearchParams {
  return input instanceof URLSearchParams
    ? new URLSearchParams(input)
    : new URLSearchParams(input.startsWith("?") ? input.slice(1) : input);
}

export function parseWorkspaceUrlState(input: string | URLSearchParams): WorkspaceUrlState {
  const params = asSearchParams(input);
  const filters: Record<string, string[]> = {};
  for (const [key, value] of params) {
    if (!key.startsWith(filterPrefix) || !value) continue;
    const filter = key.slice(filterPrefix.length);
    if (!filter) continue;
    (filters[filter] ??= []).push(value);
  }

  const value = (key: string) => params.get(key) || undefined;
  return {
    ...(value(keys.query) ? { query: value(keys.query) } : {}),
    ...(value(keys.sort) ? { sort: value(keys.sort) } : {}),
    ...(value(keys.savedView) ? { savedView: value(keys.savedView) } : {}),
    ...(value(keys.cursor) ? { cursor: value(keys.cursor) } : {}),
    ...(value(keys.detailId) ? { detailId: value(keys.detailId) } : {}),
    filters,
  };
}

export function updateWorkspaceUrlState(
  input: string | URLSearchParams,
  patch: WorkspaceUrlStatePatch,
): URLSearchParams {
  const params = asSearchParams(input);
  const setValue = (key: string, value: string | null | undefined) => {
    if (value === null || value === "") params.delete(key);
    else if (value !== undefined) params.set(key, value);
  };

  setValue(keys.query, patch.query);
  setValue(keys.sort, patch.sort);
  setValue(keys.savedView, patch.savedView);
  setValue(keys.cursor, patch.cursor);
  setValue(keys.detailId, patch.detailId);

  if (patch.filters !== undefined) {
    for (const key of Array.from(params.keys())) {
      if (key.startsWith(filterPrefix)) params.delete(key);
    }
    if (patch.filters) {
      for (const [filter, values] of Object.entries(patch.filters)) {
        for (const value of values) {
          if (value) params.append(`${filterPrefix}${filter}`, value);
        }
      }
    }
  }
  return params;
}
