import type { ReactNode } from "react";
import styles from "./workspaces.module.css";

export type StatusBadgeTone = "neutral" | "info" | "success" | "warning" | "danger";

export function StatusBadge({
  tone = "neutral",
  children,
}: {
  readonly tone?: StatusBadgeTone;
  readonly children: ReactNode;
}) {
  return <span className={styles.statusBadge} data-status-tone={tone}>{children}</span>;
}
