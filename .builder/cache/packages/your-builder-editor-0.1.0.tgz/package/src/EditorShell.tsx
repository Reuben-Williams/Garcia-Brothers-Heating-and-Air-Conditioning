"use client";

import React, { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  ArrowLeft,
  Monitor,
  PanelRightOpen,
  RotateCw,
  Save,
  LogOut,
  Smartphone,
  Tablet,
  Upload,
} from "lucide-react";
import { isBuilderPreviewMessage, type AuditEvent, type BuilderPage, type EditableValue, type MediaAsset } from "@your-builder/core";
import type { ContentWorkspace } from "./content/content-types.js";
import { HistoryEntries, HistoryWorkspace } from "./content/HistoryWorkspace.js";
import { MediaWorkspace as ExtractedMediaWorkspace } from "./content/MediaWorkspace.js";
import { computeContextMenuPosition, PostContextMenu } from "./content/PostContextMenu.js";
import { BuilderAppShell } from "./shell/BuilderAppShell.js";
import { MobileBottomSheet } from "./shell/MobileBottomSheet.js";
import { ResponsiveNavigation } from "./shell/ResponsiveNavigation.js";
import { RightPanel } from "./shell/RightPanel.js";
import {
  createRegionEditorState,
  reconcileRegionEditorState,
  regionDraftsMatch,
  regionIdentityKey,
  regionSourceKey,
  resolveRegionEditorStateForRender,
  type RegionEditorDraft,
  type RegionEditorState,
} from "./shell/regionDraftState.js";
import { WebsitePreviewWorkspace } from "./shell/WebsitePreviewWorkspace.js";
import { WorkspaceHeader } from "./shell/WorkspaceHeader.js";
import { WorkspaceRegistryHost } from "./shell/WorkspaceRegistryHost.js";
import type {
  BuilderShellRegistration,
  BuilderWorkspaceId,
  RegisteredWorkspace,
} from "./shell/types.js";
import { useMediaQuery } from "./shell/useMediaQuery.js";
import shellStyles from "./shell/editor-shell.module.css";

export interface SelectedRegion {
  id: string;
  kind: "text" | "richText" | "image" | "link" | "sections" | "icon";
  label?: string;
  value?: string;
  alt?: string;
  href?: string;
}

export interface EditorShellProps {
  siteId: string;
  currentPath: string;
  pages: BuilderPage[];
  previewBaseUrl: string;
  viewportPresets?: EditorViewportPreset[];
  defaultViewport?: string;
  defaultZoom?: number;
  userViewUrl?: string;
  logoutUrl?: string;
  demoMode?: boolean;
  onViewportChange?: (viewport: EditorViewportState) => void;
  selectedRegion?: SelectedRegion;
  auditLog?: AuditEvent[];
  mediaAssets?: MediaAsset[];
  children?: ReactNode;
  postCollectionMode?: "manual" | "query";
  onEditPost?: (entryId: string) => void;
  onChooseAnotherPost?: (entryId: string, regionId: string) => void;
  onOpenPostDetail?: (entryId: string) => void;
  onViewPostHistory?: (entryId: string) => void;
  onRemovePostFromCollection?: (entryId: string, regionId: string) => void;
  initialWorkspace?: ContentWorkspace | BuilderWorkspaceId;
  registration?: BuilderShellRegistration;
  postsWorkspace?: ReactNode;
  onPageChange?: (path: string) => void;
  onWorkspaceChange?: (workspace: BuilderWorkspaceId) => void;
  onSaveDraft?: (input: { pagePath: string; regionId: string; value: EditableValue }) => void | Promise<void>;
  onPublish?: (input: { pagePath: string }) => void | Promise<void>;
  previewRevision?: number | string;
}

export interface EditorViewportPreset {
  id: string;
  label: string;
  width: number;
  height: number;
}

export interface EditorViewportState extends EditorViewportPreset {
  zoom: number;
  orientation: "portrait" | "landscape";
}

type DemoStoredEdit =
  | { kind: "text"; text: string }
  | { kind: "image"; src: string; alt: string }
  | { kind: "link"; text: string; href: string };

type DemoAuditEvent = {
  id: string;
  action: "save" | "rollback";
  pagePath: string;
  regionKey: string;
  kind: "text" | "image" | "link";
  changedAt: string;
  oldValue: DemoStoredEdit | null;
  newValue: DemoStoredEdit | null;
  summary: string;
  userLabel: string;
};

type DemoHistoryMessage = {
  type: "campaign-v1-static-editor:history-updated";
  events: DemoAuditEvent[];
};

type DemoRollbackRequestMessage = {
  type: "campaign-v1-static-editor:rollback-request";
  eventId: string;
};

export const defaultViewportPresets: EditorViewportPreset[] = [
  { id: "desktop", label: "Desktop", width: 1280, height: 860 },
  { id: "tablet", label: "Tablet", width: 820, height: 1080 },
  { id: "mobile", label: "Mobile", width: 390, height: 844 },
];

const demoHistoryStorageKey = "campaign-v1-static-editor:history";
const demoHistoryMessageType = "campaign-v1-static-editor:history-updated";
const demoHistoryRequestMessageType = "campaign-v1-static-editor:history-request";
const demoRollbackRequestMessageType = "campaign-v1-static-editor:rollback-request";
const emptyAuditLog: AuditEvent[] = [];
const emptyMediaAssets: MediaAsset[] = [];
const contentWorkspaceIds: Record<ContentWorkspace, BuilderWorkspaceId> = {
  pages: "website.pages",
  posts: "website.posts",
  media: "website.media",
  history: "website.history",
};

function resolveWorkspaceId(workspace: ContentWorkspace | BuilderWorkspaceId): BuilderWorkspaceId {
  return workspace in contentWorkspaceIds
    ? contentWorkspaceIds[workspace as ContentWorkspace]
    : workspace as BuilderWorkspaceId;
}

export function buildPreviewUrl(baseUrl: string, path: string, siteId?: string) {
  const base = new URL(baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`);
  const url = new URL(path.replace(/^\/+/, ""), base);
  url.searchParams.set("builderPreview", "1");
  if (siteId) url.searchParams.set("builderSiteId", siteId);
  return url.toString();
}

export function resizeViewportWidth(width: number, deltaX: number, edge: "left" | "right") {
  const direction = edge === "right" ? 1 : -1;
  return Math.min(1920, Math.max(280, Math.round(width + deltaX * direction * 2)));
}

function clampZoom(zoom: number) {
  return Math.min(1.25, Math.max(0.35, Number.isFinite(zoom) ? zoom : 0.72));
}

function resolveViewport(presets: EditorViewportPreset[], id: string | undefined) {
  return presets.find((preset) => preset.id === id) ?? presets[0] ?? defaultViewportPresets[0];
}

function orientViewport(viewport: EditorViewportPreset, orientation: EditorViewportState["orientation"]) {
  if (orientation === "portrait") return viewport;
  return { ...viewport, width: viewport.height, height: viewport.width };
}

function convertDemoEditToEditableValue(edit: DemoStoredEdit | null): EditableValue | null {
  if (!edit) return null;
  if (edit.kind === "image") return { type: "image", src: edit.src, alt: edit.alt };
  if (edit.kind === "link") return { type: "link", label: edit.text, href: edit.href };
  return { type: "text", value: edit.text };
}

function mapDemoAuditEvents(events: DemoAuditEvent[]): AuditEvent[] {
  return events.map((event) => ({
    id: event.id,
    siteId: "campaign-website-v1",
    pagePath: event.pagePath,
    action: event.action === "rollback" ? "version.rolled_back" : "draft.saved",
    userId: "demo-local",
    userLabel: event.userLabel,
    createdAt: event.changedAt,
    summary: event.summary,
    regionId: event.regionKey,
    kind: event.kind,
    before: convertDemoEditToEditableValue(event.oldValue),
    after: convertDemoEditToEditableValue(event.newValue),
  }));
}

function readDemoAuditLog(): AuditEvent[] {
  if (typeof window === "undefined") return [];

  try {
    const events = JSON.parse(window.localStorage.getItem(demoHistoryStorageKey) ?? "[]") as DemoAuditEvent[];
    return mapDemoAuditEvents(events);
  } catch {
    return [];
  }
}

function isDemoHistoryMessage(value: unknown): value is DemoHistoryMessage {
  if (!value || typeof value !== "object") return false;
  const message = value as Partial<DemoHistoryMessage>;
  return message.type === demoHistoryMessageType && Array.isArray(message.events);
}

export function EditorShell({
  siteId,
  currentPath,
  pages,
  previewBaseUrl,
  viewportPresets,
  defaultViewport = "desktop",
  defaultZoom = 0.72,
  userViewUrl,
  logoutUrl,
  demoMode = false,
  onViewportChange,
  selectedRegion,
  auditLog = emptyAuditLog,
  mediaAssets = emptyMediaAssets,
  children,
  postCollectionMode = "query",
  onEditPost,
  onChooseAnotherPost,
  onOpenPostDetail,
  onViewPostHistory,
  onRemovePostFromCollection,
  initialWorkspace = "pages",
  postsWorkspace,
  registration,
  onPageChange,
  onWorkspaceChange,
  onSaveDraft,
  onPublish,
  previewRevision = 0,
}: EditorShellProps) {
  const presets = useMemo(() => (viewportPresets?.length ? viewportPresets : defaultViewportPresets), [viewportPresets]);
  const initialViewport = resolveViewport(presets, defaultViewport);
  const [viewportId, setViewportId] = useState(initialViewport.id);
  const [customWidth, setCustomWidth] = useState(initialViewport.width);
  const [customHeight, setCustomHeight] = useState(initialViewport.height);
  const [zoom, setZoom] = useState(clampZoom(defaultZoom));
  const [orientation, setOrientation] = useState<EditorViewportState["orientation"]>("portrait");
  const [activeWorkspaceId, setActiveWorkspaceId] = useState<BuilderWorkspaceId>(() =>
    resolveWorkspaceId(initialWorkspace),
  );
  const [pagesExpanded, setPagesExpanded] = useState(true);
  const [displayedAuditLog, setDisplayedAuditLog] = useState<AuditEvent[]>(auditLog);
  const [regionEditorState, setRegionEditorState] = useState<RegionEditorState>(() => createRegionEditorState(selectedRegion));
  const [mobileEditingOpen, setMobileEditingOpen] = useState(Boolean(selectedRegion));
  const selectedRegionIdentityRef = useRef(regionIdentityKey(selectedRegion));
  const isMobile = useMediaQuery("(max-width: 767px)");
  const dragCleanupRef = useRef<(() => void) | null>(null);
  const previewFrameRef = useRef<HTMLIFrameElement | null>(null);
  const [selectedPost, setSelectedPost] = useState<{
    entryId: string;
    regionId: string;
    anchor: { x: number; y: number };
  } | null>(null);
  const [postMenuPosition, setPostMenuPosition] = useState({ left: 16, top: 16 });
  const [operationStatus, setOperationStatus] = useState("");
  const [operationBusy, setOperationBusy] = useState(false);
  const selectedPreset = resolveViewport(presets, viewportId);
  const activeBaseViewport =
    viewportId === "custom"
      ? { id: "custom", label: "Custom", width: customWidth, height: customHeight }
      : selectedPreset;
  const orientedViewport = orientViewport(activeBaseViewport, orientation);
  const activeViewport: EditorViewportState = {
    ...orientedViewport,
    id: activeBaseViewport.id,
    label: activeBaseViewport.label,
    zoom,
    orientation,
  };

  const selectedRegionIdentityKey = regionIdentityKey(selectedRegion);
  const selectedRegionSourceKey = regionSourceKey(selectedRegion);
  const renderedRegionEditorState = resolveRegionEditorStateForRender(regionEditorState, selectedRegion);

  useEffect(() => {
    setActiveWorkspaceId(resolveWorkspaceId(initialWorkspace));
  }, [initialWorkspace]);

  useEffect(() => {
    setRegionEditorState((current) => reconcileRegionEditorState(current, selectedRegion));
  }, [selectedRegion, selectedRegionIdentityKey, selectedRegionSourceKey]);

  useEffect(() => {
    if (!selectedRegion) {
      selectedRegionIdentityRef.current = "";
      setMobileEditingOpen(false);
      return;
    }
    if (selectedRegionIdentityRef.current !== selectedRegionIdentityKey) {
      selectedRegionIdentityRef.current = selectedRegionIdentityKey;
      setMobileEditingOpen(true);
    }
  }, [selectedRegion, selectedRegionIdentityKey]);

  useEffect(() => {
    onViewportChange?.(activeViewport);
  }, [activeViewport.id, activeViewport.width, activeViewport.height, activeViewport.zoom, activeViewport.orientation]);

  function chooseViewport(preset: EditorViewportPreset) {
    setViewportId(preset.id);
    setCustomWidth(preset.width);
    setCustomHeight(preset.height);
  }

  function chooseCustomWidth(width: number, height = activeViewport.height) {
    const nextWidth = Math.min(1920, Math.max(280, width || 280));
    setViewportId("custom");
    setCustomWidth(nextWidth);
    setCustomHeight(height);
  }

  function chooseZoomPercent(percent: number) {
    setZoom(clampZoom(percent / 100));
  }

  function startResize(edge: "left" | "right", clientX: number) {
    dragCleanupRef.current?.();
    const startWidth = activeViewport.width;
    const startHeight = activeViewport.height;

    const move = (event: PointerEvent) => {
      chooseCustomWidth(resizeViewportWidth(startWidth, event.clientX - clientX, edge), startHeight);
    };
    const stop = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", stop);
      dragCleanupRef.current = null;
    };

    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", stop);
    dragCleanupRef.current = stop;
  }

  useEffect(() => () => dragCleanupRef.current?.(), []);

  useEffect(() => {
    if (!demoMode) {
      setDisplayedAuditLog(auditLog);
      return;
    }

    setDisplayedAuditLog(readDemoAuditLog());
    const refreshFromDemoStorage = (event: StorageEvent) => {
      if (event.key === demoHistoryStorageKey) setDisplayedAuditLog(readDemoAuditLog());
    };
    const refreshFromDemoMessage = (event: MessageEvent) => {
      if (event.origin !== window.location.origin || !isDemoHistoryMessage(event.data)) return;
      setDisplayedAuditLog(mapDemoAuditEvents(event.data.events));
    };

    window.addEventListener("storage", refreshFromDemoStorage);
    window.addEventListener("message", refreshFromDemoMessage);
    return () => {
      window.removeEventListener("storage", refreshFromDemoStorage);
      window.removeEventListener("message", refreshFromDemoMessage);
    };
  }, [auditLog, demoMode]);

  useEffect(() => {
    const previewOrigin = new URL(previewBaseUrl).origin;
    const handleMessage = (event: MessageEvent) => {
      if (
        event.origin !== previewOrigin ||
        event.source !== previewFrameRef.current?.contentWindow ||
        !isBuilderPreviewMessage(event.data, siteId) ||
        event.data.type !== "builder:select-entry" ||
        event.data.pagePath !== currentPath
      ) return;

      setSelectedPost({
        entryId: event.data.entryId,
        regionId: event.data.regionId ?? "",
        anchor: event.data.anchor ?? { x: 24, y: 24 },
      });
      setActiveWorkspaceId("website.posts");
    };
    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, [currentPath, previewBaseUrl, siteId]);

  useEffect(() => {
    if (!selectedPost) return;
    const reposition = () => {
      const frameRect = previewFrameRef.current?.getBoundingClientRect();
      if (!frameRect) return;
      setPostMenuPosition(computeContextMenuPosition(
        {
          x: frameRect.left + selectedPost.anchor.x * activeViewport.zoom,
          y: frameRect.top + selectedPost.anchor.y * activeViewport.zoom,
        },
        { width: window.innerWidth, height: window.innerHeight },
      ));
    };
    reposition();
    window.addEventListener("scroll", reposition, true);
    window.addEventListener("resize", reposition);
    return () => {
      window.removeEventListener("scroll", reposition, true);
      window.removeEventListener("resize", reposition);
    };
  }, [selectedPost, activeViewport.zoom, activeViewport.width, activeViewport.height]);

  function resetViewport() {
    const desktop = resolveViewport(presets, "desktop");
    setViewportId(desktop.id);
    setCustomWidth(desktop.width);
    setCustomHeight(desktop.height);
    setOrientation("portrait");
    setZoom(clampZoom(defaultZoom));
  }

  function refreshDisplayedAuditLog() {
    if (!demoMode) {
      setDisplayedAuditLog(auditLog);
      return;
    }

    setDisplayedAuditLog(readDemoAuditLog());
    previewFrameRef.current?.contentWindow?.postMessage({ type: demoHistoryRequestMessageType }, window.location.origin);
  }

  function requestDemoRollback(event: AuditEvent) {
    if (!demoMode) return;
    const message: DemoRollbackRequestMessage = {
      type: demoRollbackRequestMessageType,
      eventId: event.id,
    };
    previewFrameRef.current?.contentWindow?.postMessage(message, window.location.origin);
  }

  const resolvedMediaAssets = mediaAssets.length > 0 ? mediaAssets : defaultDemoMediaAssets(previewBaseUrl, siteId);
  const websiteWorkspaces: readonly RegisteredWorkspace[] = (["pages", "posts", "media", "history"] as const).map(
    (workspace): RegisteredWorkspace => {
      const label = workspace[0].toUpperCase() + workspace.slice(1);
      return {
        id: contentWorkspaceIds[workspace],
        label,
        group: "website",
        icon: workspace,
        mobilePriority: workspace === "pages" ? 3 : undefined,
        render: () => (
          <>
            <span hidden>{label} workspace</span>
            {workspace === "pages" ? null : renderWorkspaceContent({
              activeWorkspace: workspace,
              postsWorkspace,
              mediaAssets: resolvedMediaAssets,
              auditLog: displayedAuditLog,
              pages,
              onRestoreVersion: requestDemoRollback,
            })}
          </>
        ),
      };
    },
  );
  const registeredWorkspaces: readonly RegisteredWorkspace[] = [
    ...websiteWorkspaces,
    ...(registration?.workspaces.filter((candidate) =>
      !websiteWorkspaces.some((workspace) => workspace.id === candidate.id)
    ) ?? []),
  ];
  const hostedWorkspaces = registeredWorkspaces.filter((workspace) => workspace.id !== "website.pages");
  const activeContentWorkspace = (Object.entries(contentWorkspaceIds) as Array<[ContentWorkspace, BuilderWorkspaceId]>).find(
    ([, id]) => id === activeWorkspaceId,
  )?.[0];

  function selectWorkspace(workspaceId: BuilderWorkspaceId) {
    setActiveWorkspaceId(workspaceId);
    onWorkspaceChange?.(workspaceId);
  }

  function draftValue(): EditableValue | null {
    if (!selectedRegion) return null;
    const draft = renderedRegionEditorState.draft;
    if (selectedRegion.kind === "image") return { type: "image", src: draft.value, alt: draft.alt };
    if (selectedRegion.kind === "link") return { type: "link", label: draft.value, href: draft.href };
    if (selectedRegion.kind === "richText") return { type: "richText", value: draft.value };
    if (selectedRegion.kind === "icon") return { type: "icon", icon: draft.value };
    if (selectedRegion.kind === "sections") return null;
    return { type: "text", value: draft.value };
  }

  async function saveDraft() {
    const value = draftValue();
    if (!selectedRegion || !value || !onSaveDraft) {
      refreshDisplayedAuditLog();
      return;
    }
    setOperationBusy(true);
    setOperationStatus("Saving draft...");
    try {
      await onSaveDraft({ pagePath: currentPath, regionId: selectedRegion.id, value });
      setRegionEditorState((current) => ({ ...current, sourceDraft: current.draft, dirty: false }));
      setOperationStatus("Draft saved.");
      refreshDisplayedAuditLog();
    } catch {
      setOperationStatus("Draft could not be saved.");
    } finally {
      setOperationBusy(false);
    }
  }

  async function publish() {
    if (!onPublish) return;
    setOperationBusy(true);
    setOperationStatus("Publishing...");
    try {
      await onPublish({ pagePath: currentPath });
      setOperationStatus("Page published.");
    } catch {
      setOperationStatus("Page could not be published.");
    } finally {
      setOperationBusy(false);
    }
  }

  const editingControlBody = (
    <>
      {selectedRegion ? (
        <RegionEditorFields
          selectedRegion={selectedRegion}
          mediaAssets={mediaAssets}
          draft={renderedRegionEditorState.draft}
          onDraftChange={(draft) => setRegionEditorState((current) => {
            const rendered = resolveRegionEditorStateForRender(current, selectedRegion);
            return {
              ...rendered,
              draft,
              dirty: !regionDraftsMatch(draft, rendered.sourceDraft),
            };
          })}
        />
      ) : (
        <p style={styles.muted}>Click text, images, links, or approved sections in the preview.</p>
      )}
      {children}
      <h3 style={styles.historyTitle}>Version history</h3>
      <HistoryEntries auditLog={displayedAuditLog} pages={pages} onRestoreVersion={requestDemoRollback} />
    </>
  );

  return (
    <BuilderAppShell
      header={registration?.globalHeader}
      navigation={
        <ResponsiveNavigation
          siteLabel={siteId}
          siteStatus={demoMode ? "Demo mode" : "Site editor"}
          workspaces={registeredWorkspaces}
          activeWorkspace={activeWorkspaceId}
          onWorkspaceChange={selectWorkspace}
          pageLinks={pages.map((page) => ({ path: page.path, label: page.label }))}
          currentPath={currentPath}
          pagesExpanded={pagesExpanded}
          onTogglePages={() => setPagesExpanded((expanded) => !expanded)}
          onPageChange={onPageChange}
        />
      }
    >
      <WorkspaceRegistryHost
        activeWorkspace={activeWorkspaceId}
        workspaces={hostedWorkspaces}
        website={
          <WebsitePreviewWorkspace>
            <div className={shellStyles.websiteWorkspaceLayout}>
      <section
        style={styles.canvasArea}
        aria-label="Website preview"
        data-builder-preview-visible={activeContentWorkspace === "pages" ? "true" : "false"}
      >
        <div style={styles.toolbar}>
          <div style={styles.toolbarStatus}>
            <span style={styles.muted}>Editing {currentPath}</span>
            <strong data-builder-active-width>
              {activeViewport.label}: {activeViewport.width}x{activeViewport.height} at {Math.round(activeViewport.zoom * 100)}%
            </strong>
          </div>
          <div style={styles.toolbarActions}>
            <div style={styles.segmentedControl} aria-label="Viewport presets">
              {presets.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  aria-pressed={activeBaseViewport.id === preset.id}
                  style={{
                    ...styles.segmentButton,
                    ...(activeBaseViewport.id === preset.id ? styles.segmentButtonActive : {}),
                  }}
                  onClick={() => chooseViewport(preset)}
                  aria-label={`${preset.label} view`}
                  title={`${preset.label} view`}
                >
                  {preset.id === "desktop" ? (
                    <Monitor size={18} aria-hidden="true" />
                  ) : preset.id === "tablet" ? (
                    <Tablet size={18} aria-hidden="true" />
                  ) : preset.id === "mobile" ? (
                    <Smartphone size={18} aria-hidden="true" />
                  ) : (
                    preset.label
                  )}
                </button>
              ))}
            </div>
            <label style={styles.inlineField}>
              Width
              <input
                aria-label="Custom viewport width"
                type="number"
                min={280}
                max={1920}
                value={activeViewport.width}
                onChange={(event) => chooseCustomWidth(Number(event.target.value))}
                style={styles.compactInput}
              />
            </label>
            <label style={styles.inlineField}>
              Zoom
              <input
                aria-label="Preview zoom"
                type="range"
                min={35}
                max={125}
                value={Math.round(activeViewport.zoom * 100)}
                onChange={(event) => chooseZoomPercent(Number(event.target.value))}
              />
              <input
                aria-label="Custom zoom percent"
                type="number"
                min={35}
                max={125}
                value={Math.round(activeViewport.zoom * 100)}
                onChange={(event) => chooseZoomPercent(Number(event.target.value))}
                style={styles.zoomInput}
              />
              <span>%</span>
            </label>
            <button
              type="button"
              style={styles.secondaryButton}
              onClick={() => setOrientation((current) => (current === "portrait" ? "landscape" : "portrait"))}
            >
              <RotateCw size={17} aria-hidden="true" />
              <span>Rotate</span>
            </button>
            <button type="button" style={styles.secondaryButton} onClick={resetViewport}>
              Reset
            </button>
            <button type="button" style={styles.secondaryButton} disabled={operationBusy} onClick={() => void saveDraft()}>
              <Save size={17} aria-hidden="true" />
              <span>Save draft</span>
            </button>
            <button type="button" style={styles.primaryButton} disabled={operationBusy || !onPublish} onClick={() => void publish()}>
              <Upload size={17} aria-hidden="true" />
              <span>Publish</span>
            </button>
            {userViewUrl ? (
              <a href={userViewUrl} style={styles.userViewLink}>
                <ArrowLeft size={17} aria-hidden="true" />
                <span>Back to user view</span>
              </a>
            ) : null}
            {logoutUrl ? (
              <form action={logoutUrl} method="post" style={styles.inlineForm}>
                <button type="submit" style={styles.secondaryButton}>
                  <LogOut size={17} aria-hidden="true" />
                  <span>Sign out</span>
                </button>
              </form>
            ) : null}
            {operationStatus ? <span role="status" style={styles.muted}>{operationStatus}</span> : null}
          </div>
        </div>
        <div style={styles.canvas}>
          <div style={{ ...styles.previewStage, transform: `scale(${activeViewport.zoom})` }}>
            <button
              type="button"
              aria-label="Resize preview from left edge"
              data-builder-resize-handle="left"
              style={{ ...styles.resizeHandle, left: "-32px" }}
              onPointerDown={(event) => startResize("left", event.clientX)}
            >
              <span aria-hidden="true" style={styles.resizeHandleBar} />
            </button>
            <div
              style={{
                ...styles.previewFrame,
                width: `${activeViewport.width}px`,
                height: `${activeViewport.height}px`,
              }}
              data-builder-viewport={activeViewport.id}
              data-builder-viewport-width={activeViewport.width}
              data-builder-viewport-height={activeViewport.height}
            >
              <iframe
                key={`${currentPath}:${previewRevision}`}
                ref={previewFrameRef}
                title="Editable website preview"
                src={buildPreviewUrl(previewBaseUrl, currentPath, siteId)}
                style={styles.iframe}
                data-builder-preview
                data-builder-preview-frame
                data-builder-viewport={activeViewport.id}
                data-builder-viewport-width={activeViewport.width}
              />
            </div>
            <button
              type="button"
              aria-label="Resize preview from right edge"
              data-builder-resize-handle="right"
              style={{ ...styles.resizeHandle, right: "-32px" }}
              onPointerDown={(event) => startResize("right", event.clientX)}
            >
              <span aria-hidden="true" style={styles.resizeHandleBar} />
            </button>
          </div>
        </div>
      </section>

      {isMobile ? (
        <>
          <MobileBottomSheet
            open={Boolean(selectedRegion) && mobileEditingOpen}
            title={selectedRegion?.label ?? "Editing controls"}
            onClose={() => setMobileEditingOpen(false)}
          >
            {editingControlBody}
          </MobileBottomSheet>
          {selectedRegion && !mobileEditingOpen ? (
            <button
              type="button"
              className={shellStyles.openEditingControls}
              aria-label="Open editing controls"
              onClick={() => setMobileEditingOpen(true)}
            >
              <PanelRightOpen size={19} aria-hidden="true" />
              <span>Edit</span>
            </button>
          ) : null}
        </>
      ) : (
        <RightPanel title={selectedRegion?.label ?? "Select an editable area"}>{editingControlBody}</RightPanel>
      )}
            </div>
          </WebsitePreviewWorkspace>
        }
      />
      {selectedPost ? (
        <PostContextMenu
          entryId={selectedPost.entryId}
          regionId={selectedPost.regionId}
          collectionMode={postCollectionMode}
          position={postMenuPosition}
          onEdit={() => onEditPost?.(selectedPost.entryId)}
          onChooseAnother={onChooseAnotherPost ? () => onChooseAnotherPost(selectedPost.entryId, selectedPost.regionId) : undefined}
          onOpenDetail={() => onOpenPostDetail?.(selectedPost.entryId)}
          onViewHistory={() => onViewPostHistory?.(selectedPost.entryId)}
          onRemove={onRemovePostFromCollection ? () => onRemovePostFromCollection(selectedPost.entryId, selectedPost.regionId) : undefined}
          onClose={() => setSelectedPost(null)}
        />
      ) : null}
    </BuilderAppShell>
  );
}

function renderWorkspaceContent({
  activeWorkspace,
  postsWorkspace,
  mediaAssets,
  auditLog,
  pages,
  onRestoreVersion,
}: {
  activeWorkspace: Exclude<ContentWorkspace, "pages">;
  postsWorkspace?: ReactNode;
  mediaAssets: MediaAsset[];
  auditLog: AuditEvent[];
  pages: BuilderPage[];
  onRestoreVersion: (event: AuditEvent) => void;
}) {
  if (activeWorkspace === "posts") {
    return (
      <section
        style={styles.contentWorkspace}
        aria-label="Posts workspace"
        data-builder-content-workspace="posts"
        data-builder-hosted-workspace="posts"
      >
        <WorkspaceHeader
          title="Campaign updates"
          eyebrow="Posts"
          description="Draft and organize campaign news, events, and update entries before placing them on the public site."
        />
        {postsWorkspace ? (
          postsWorkspace
        ) : (
          <div style={styles.workspaceGrid}>
            {demoPosts.map((post) => (
              <article key={post.title} style={styles.workspaceCard}>
                <span style={styles.statusPill}>{post.status}</span>
                <h3 style={styles.workspaceCardTitle}>{post.title}</h3>
                <p style={styles.workspaceCardMeta}>{post.location}</p>
                <p style={styles.workspaceCardText}>{post.summary}</p>
              </article>
            ))}
          </div>
        )}
      </section>
    );
  }

  if (activeWorkspace === "media") {
    return <ExtractedMediaWorkspace mediaAssets={mediaAssets} />;
  }

  return <HistoryWorkspace auditLog={auditLog} pages={pages} onRestoreVersion={onRestoreVersion} />;
}

function defaultDemoMediaAssets(previewBaseUrl: string, siteId: string): MediaAsset[] {
  const now = new Date(0).toISOString();
  return [
    {
      id: "campaign-office-briefing",
      siteId,
      path: "/images/campaign/campaign-office-briefing.jpg",
      url: new URL("images/campaign/campaign-office-briefing.jpg", previewBaseUrl).toString(),
      alt: "Campaign team reviewing materials in an office",
      label: "Campaign office briefing",
      mimeType: "image/jpeg",
      source: "seed",
      userId: "demo",
      createdAt: now,
    },
    {
      id: "community-table-outreach",
      siteId,
      path: "/images/campaign/community-table-outreach.jpg",
      url: new URL("images/campaign/community-table-outreach.jpg", previewBaseUrl).toString(),
      alt: "Community outreach table with campaign materials",
      label: "Community table outreach",
      mimeType: "image/jpeg",
      source: "seed",
      userId: "demo",
      createdAt: now,
    },
    {
      id: "volunteer-team-morales",
      siteId,
      path: "/images/campaign/volunteer-team-morales.jpg",
      url: new URL("images/campaign/volunteer-team-morales.jpg", previewBaseUrl).toString(),
      alt: "Morales campaign volunteer team",
      label: "Volunteer team",
      mimeType: "image/jpeg",
      source: "seed",
      userId: "demo",
      createdAt: now,
    },
  ];
}

const demoPosts = [
  {
    title: "District listening session recap",
    location: "News page",
    status: "Draft",
    summary: "Short-form campaign update ready to connect to a future posts collection.",
  },
  {
    title: "Weekend volunteer launch",
    location: "Events page",
    status: "Scheduled",
    summary: "Event-style post for canvassing, phone banking, or community stops.",
  },
  {
    title: "Education priorities statement",
    location: "Issues page",
    status: "Published",
    summary: "Policy update that can be reused across issue and news sections.",
  },
];

function RegionEditorFields({
  selectedRegion,
  mediaAssets,
  draft,
  onDraftChange,
}: {
  selectedRegion: SelectedRegion;
  mediaAssets: MediaAsset[];
  draft: RegionEditorDraft;
  onDraftChange: (draft: RegionEditorDraft) => void;
}) {
  if (selectedRegion.kind === "icon") {
    return (
      <div style={styles.fieldGroup}>
        <label htmlFor="builder-region-value" style={styles.label}>
          Icon
        </label>
        <select
          id="builder-region-value"
          value={draft.value}
          onChange={(event) => onDraftChange({ ...draft, value: event.target.value })}
          style={styles.input}
        >
          <option value="">Choose an icon</option>
          {iconOptions.map((icon) => (
            <option key={icon} value={icon}>
              {icon}
            </option>
          ))}
        </select>
        <div aria-label="Choose an icon" style={styles.iconGrid}>
          {iconOptions.map((icon) => (
            <button
              key={icon}
              type="button"
              style={styles.iconChoice}
              onClick={() => onDraftChange({ ...draft, value: icon })}
            >
              <span className="material-symbols-outlined" aria-hidden="true">
                {icon}
              </span>
              <span>{icon}</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (selectedRegion.kind === "image") {
    return (
      <div style={styles.fieldGroup}>
        <label htmlFor="builder-region-value" style={styles.label}>
          Selected image
        </label>
        <input
          id="builder-region-value"
          value={draft.value}
          onChange={(event) => onDraftChange({ ...draft, value: event.target.value })}
          style={styles.input}
        />
        <label htmlFor="builder-region-alt" style={styles.label}>
          Alt text
        </label>
        <textarea
          id="builder-region-alt"
          value={draft.alt}
          onChange={(event) => onDraftChange({ ...draft, alt: event.target.value })}
          style={styles.textarea}
        />
        <button type="button" style={styles.secondaryButton}>
          Open gallery
        </button>
        <label style={styles.uploadButton}>
          Upload image
          <input type="file" accept="image/*" hidden />
        </label>
        <div style={styles.galleryGrid}>
          {mediaAssets.map((asset) => (
            <button
              key={asset.id}
              type="button"
              style={styles.galleryCard}
              onClick={() => onDraftChange({ ...draft, value: asset.url, alt: asset.alt })}
            >
              <img src={asset.url} alt="" style={styles.galleryImage} />
              <span>{asset.label}</span>
              <small style={styles.muted}>{asset.mimeType}</small>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (selectedRegion.kind === "link") {
    return (
      <div style={styles.fieldGroup}>
        <label htmlFor="builder-region-value" style={styles.label}>
          Link text
        </label>
        <textarea
          id="builder-region-value"
          value={draft.value}
          onChange={(event) => onDraftChange({ ...draft, value: event.target.value })}
          style={styles.textarea}
        />
        <label htmlFor="builder-region-href" style={styles.label}>
          Link destination
        </label>
        <input
          id="builder-region-href"
          value={draft.href}
          onChange={(event) => onDraftChange({ ...draft, href: event.target.value })}
          style={styles.input}
        />
      </div>
    );
  }

  return (
    <div style={styles.fieldGroup}>
      <label htmlFor="builder-region-value" style={styles.label}>
        {selectedRegion.kind}
      </label>
      <textarea
        id="builder-region-value"
        value={draft.value}
        onChange={(event) => onDraftChange({ ...draft, value: event.target.value })}
        style={styles.textarea}
      />
    </div>
  );
}

const iconOptions = [
  "home",
  "work",
  "mail",
  "phone",
  "campaign",
  "how_to_vote",
  "warning",
  "business_center",
  "volunteer_activism",
  "groups",
  "event",
  "location_on",
];

const styles = {
  muted: {
    color: "#667085",
    fontSize: "13px",
  },
  canvasArea: {
    display: "grid",
    gridTemplateRows: "auto 1fr",
    minWidth: 0,
  },
  toolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    minHeight: "72px",
    gap: "12px 18px",
    borderBottom: "1px solid #d7dde5",
    background: "#ffffff",
    padding: "12px 18px",
  },
  toolbarActions: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    justifyContent: "flex-end",
    gap: "10px",
  },
  toolbarStatus: {
    display: "grid",
    gap: "3px",
    minWidth: "160px",
  },
  primaryButton: {
    display: "inline-flex",
    alignItems: "center",
    gap: "7px",
    border: "0",
    borderRadius: "8px",
    background: "#175cd3",
    color: "#ffffff",
    fontWeight: 700,
    minHeight: "44px",
    padding: "10px 14px",
  },
  secondaryButton: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "7px",
    border: "1px solid #c9d2df",
    borderRadius: "8px",
    background: "#ffffff",
    color: "#344054",
    fontWeight: 700,
    minHeight: "44px",
    padding: "10px 14px",
  },
  segmentedControl: {
    display: "flex",
    border: "1px solid #c9d2df",
    borderRadius: "8px",
    overflow: "hidden",
  },
  segmentButton: {
    display: "grid",
    placeItems: "center",
    minWidth: "44px",
    minHeight: "44px",
    border: "0",
    borderRight: "1px solid #c9d2df",
    background: "#ffffff",
    color: "#344054",
    fontWeight: 700,
    padding: "9px 10px",
  },
  segmentButtonActive: {
    background: "#175cd3",
    color: "#ffffff",
  },
  inlineField: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    color: "#344054",
    fontSize: "13px",
    fontWeight: 700,
  },
  compactInput: {
    width: "74px",
    minHeight: "44px",
    border: "1px solid #c9d2df",
    borderRadius: "8px",
    padding: "8px",
    font: "inherit",
  },
  zoomInput: {
    width: "58px",
    minHeight: "44px",
    border: "1px solid #c9d2df",
    borderRadius: "8px",
    padding: "8px",
    font: "inherit",
  },
  canvas: {
    display: "grid",
    alignItems: "center",
    justifyItems: "center",
    minWidth: 0,
    overflow: "auto",
    padding: "28px",
  },
  previewFrame: {
    background: "#ffffff",
    boxShadow: "0 24px 80px rgba(15, 23, 42, 0.22)",
    borderRadius: "10px",
    overflow: "hidden",
  },
  previewStage: {
    position: "relative",
    transformOrigin: "center",
  },
  resizeHandle: {
    position: "absolute",
    zIndex: 2,
    top: "50%",
    width: "64px",
    height: "72px",
    display: "grid",
    placeItems: "center",
    transform: "translateY(-50%)",
    border: 0,
    background: "transparent",
    cursor: "ew-resize",
    touchAction: "none",
  },
  resizeHandleBar: {
    width: "16px",
    height: "64px",
    border: "1px solid #98a2b3",
    borderRadius: "6px",
    background: "#ffffff",
    boxShadow: "0 3px 10px rgba(15, 23, 42, 0.16)",
  },
  iframe: {
    width: "100%",
    height: "100%",
    border: "0",
  },
  panel: {
    borderLeft: "1px solid #d7dde5",
    background: "#ffffff",
    padding: "18px",
  },
  userViewLink: {
    display: "inline-flex",
    alignItems: "center",
    gap: "7px",
    borderRadius: "8px",
    background: "#087f78",
    color: "#ffffff",
    fontWeight: 700,
    minHeight: "44px",
    padding: "10px 14px",
    textDecoration: "none",
  },
  inlineForm: {
    margin: 0,
  },
  panelTitle: {
    margin: "0 0 16px",
    fontSize: "18px",
  },
  workspaceNotice: {
    display: "grid",
    gap: "4px",
    marginBottom: "18px",
    border: "1px solid #b2ccff",
    borderRadius: "8px",
    background: "#eef4ff",
    padding: "12px",
  },
  contentWorkspace: {
    minWidth: 0,
    overflow: "auto",
    background: "#f8fafc",
    padding: "24px",
  },
  workspaceGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
    gap: "14px",
  },
  workspaceCard: {
    display: "grid",
    gap: "8px",
    alignContent: "start",
    border: "1px solid #d7dde5",
    borderRadius: "8px",
    background: "#ffffff",
    padding: "16px",
  },
  statusPill: {
    justifySelf: "start",
    border: "1px solid #b2ccff",
    borderRadius: "999px",
    background: "#eef4ff",
    color: "#175cd3",
    fontSize: "12px",
    fontWeight: 800,
    padding: "4px 8px",
  },
  workspaceCardTitle: {
    margin: 0,
    fontSize: "18px",
    lineHeight: 1.25,
  },
  workspaceCardMeta: {
    margin: 0,
    color: "#667085",
    fontSize: "13px",
  },
  workspaceCardText: {
    margin: 0,
    color: "#344054",
    fontSize: "14px",
    lineHeight: 1.5,
  },
  mediaGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
    gap: "14px",
  },
  mediaCard: {
    display: "grid",
    overflow: "hidden",
    border: "1px solid #d7dde5",
    borderRadius: "8px",
    background: "#ffffff",
  },
  mediaOpenButton: {
    width: "100%",
    border: 0,
    background: "#f8fafc",
    cursor: "zoom-in",
    padding: 0,
  },
  mediaPreview: {
    width: "100%",
    aspectRatio: "16 / 10",
    objectFit: "contain",
    background: "#eef2f6",
  },
  mediaBody: {
    display: "grid",
    gap: "5px",
    padding: "12px",
  },
  mediaTitleRow: {
    display: "grid",
    gridTemplateColumns: "minmax(0, 1fr) auto",
    alignItems: "center",
    gap: "8px",
  },
  favoriteButton: {
    display: "grid",
    placeItems: "center",
    width: "32px",
    height: "32px",
    border: "1px solid #d7dde5",
    borderRadius: "8px",
    background: "#ffffff",
    color: "#667085",
    cursor: "pointer",
  },
  favoriteButtonActive: {
    border: "1px solid #f59e0b",
    background: "#fffbeb",
    color: "#b45309",
  },
  mediaModalBackdrop: {
    position: "fixed",
    inset: 0,
    zIndex: 50,
    display: "grid",
    placeItems: "center",
    background: "rgba(5, 12, 28, 0.62)",
    padding: "24px",
  },
  mediaModal: {
    display: "grid",
    gridTemplateRows: "auto minmax(0, 1fr) auto",
    gap: "16px",
    width: "min(980px, calc(100vw - 48px))",
    maxHeight: "min(860px, calc(100vh - 64px))",
    borderRadius: "12px",
    background: "#ffffff",
    boxShadow: "0 28px 90px rgba(0, 8, 30, 0.38)",
    padding: "18px",
  },
  mediaModalHeader: {
    display: "flex",
    alignItems: "start",
    justifyContent: "space-between",
    gap: "14px",
  },
  iconButton: {
    display: "grid",
    placeItems: "center",
    width: "38px",
    height: "38px",
    border: "1px solid #d7dde5",
    borderRadius: "8px",
    background: "#ffffff",
    color: "#344054",
    cursor: "pointer",
  },
  mediaModalImage: {
    width: "100%",
    minHeight: 0,
    maxHeight: "calc(100vh - 260px)",
    borderRadius: "8px",
    background: "#eef2f6",
    objectFit: "contain",
  },
  mediaModalActions: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "12px",
  },
  technicalDetails: {
    display: "grid",
    gap: "4px",
    color: "#667085",
    fontSize: "12px",
    overflowWrap: "anywhere",
  },
  workspaceHistoryList: {
    display: "grid",
    gap: "12px",
    maxHeight: "min(620px, calc(100vh - 210px))",
    overflowY: "auto",
    listStyle: "none",
    margin: 0,
    padding: "0 4px 0 0",
  },
  emptyState: {
    display: "grid",
    gap: "8px",
    maxWidth: "560px",
    border: "1px solid #d7dde5",
    borderRadius: "8px",
    background: "#ffffff",
    padding: "18px",
  },
  fieldGroup: {
    display: "grid",
    gap: "8px",
  },
  label: {
    fontSize: "13px",
    fontWeight: 700,
    color: "#344054",
    textTransform: "capitalize",
  },
  textarea: {
    minHeight: "120px",
    resize: "vertical",
    border: "1px solid #c9d2df",
    borderRadius: "8px",
    padding: "10px",
    font: "inherit",
  },
  input: {
    border: "1px solid #c9d2df",
    borderRadius: "8px",
    padding: "10px",
    font: "inherit",
  },
  uploadButton: {
    border: "1px solid #c9d2df",
    borderRadius: "8px",
    background: "#ffffff",
    color: "#344054",
    fontWeight: 700,
    padding: "10px 14px",
    textAlign: "center",
  },
  galleryGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: "8px",
  },
  galleryCard: {
    display: "grid",
    gap: "6px",
    border: "1px solid #d7dde5",
    borderRadius: "8px",
    background: "#ffffff",
    padding: "8px",
    textAlign: "left",
    font: "inherit",
  },
  galleryImage: {
    width: "100%",
    aspectRatio: "4 / 3",
    objectFit: "cover",
    borderRadius: "6px",
  },
  iconGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: "8px",
  },
  iconChoice: {
    display: "grid",
    gridTemplateColumns: "24px 1fr",
    alignItems: "center",
    gap: "8px",
    border: "1px solid #d7dde5",
    borderRadius: "8px",
    background: "#ffffff",
    padding: "10px",
    textAlign: "left",
    font: "inherit",
  },
  historyTitle: {
    margin: "28px 0 12px",
    fontSize: "15px",
  },
  historyList: {
    display: "grid",
    gap: "10px",
    maxHeight: "min(420px, calc(100vh - 410px))",
    overflowY: "auto",
    listStyle: "none",
    margin: 0,
    padding: "0 4px 0 0",
  },
  historyListItem: {
    listStyle: "none",
  },
  historyItem: {
    border: "1px solid #e4e7ec",
    borderRadius: "8px",
    background: "#ffffff",
    overflow: "hidden",
  },
  historySummary: {
    display: "grid",
    gridTemplateColumns: "1fr",
    gap: "10px",
    alignItems: "start",
    cursor: "pointer",
    listStyle: "none",
    padding: "10px",
  },
  historySummaryText: {
    display: "grid",
    gap: "4px",
    minWidth: 0,
  },
  historySummaryHint: {
    justifySelf: "stretch",
    boxSizing: "border-box",
    width: "100%",
    borderRadius: "999px",
    background: "#eef4ff",
    color: "#175cd3",
    fontSize: "12px",
    fontWeight: 800,
    padding: "5px 8px",
    textAlign: "center",
    whiteSpace: "normal",
  },
  historyItemDetails: {
    display: "grid",
    gap: "10px",
    borderTop: "1px solid #e4e7ec",
    background: "#fbfcff",
    padding: "10px",
  },
  historyValues: {
    display: "grid",
    gap: "8px",
    margin: 0,
  },
  historyValue: {
    display: "grid",
    gap: "4px",
    border: "1px solid #eef2f7",
    borderRadius: "8px",
    background: "#f8fafc",
    padding: "8px",
  },
  historyValueLabel: {
    color: "#344054",
    fontSize: "12px",
    textTransform: "uppercase",
  },
  historyImage: {
    width: "72px",
    height: "52px",
    objectFit: "cover",
    borderRadius: "6px",
  },
} satisfies Record<string, React.CSSProperties>;
