import type { PostCollectionQuery } from "@your-builder/content";

export type ContentSourceMode = "fallback" | "live";

export interface ContentSourceScope {
  key: string;
  contentSource: ContentSourceMode;
  entryIds: string[];
}

export interface PostContentConfiguration {
  route: string;
  sourceScopes: ContentSourceScope[];
  categories: string[];
  tags?: string[];
  approvedStaticImageOrigins?: string[];
}

export interface BuilderContentConfiguration {
  post: PostContentConfiguration;
}

export interface PostCollectionRegionOptions {
  sourceScopeKey?: string;
  query?: Partial<PostCollectionQuery> & Pick<PostCollectionQuery, "limit" | "orderBy" | "orderDirection">;
}

export interface SiteConfigurationIssue {
  code: string;
  message: string;
  path?: string;
}

interface ConfigRegion extends PostCollectionRegionOptions {
  id: string;
  kind: string;
}

interface ConfigPage {
  path: string;
  regions: Array<string | ConfigRegion>;
}

export function validateContentConfiguration(
  content: BuilderContentConfiguration | undefined,
  pages: readonly ConfigPage[],
): SiteConfigurationIssue[] {
  if (!content) return [];
  const issues: SiteConfigurationIssue[] = [];
  const post = content.post;
  if (!post.route.startsWith("/") || !post.route.includes("[slug]")) {
    issues.push({
      code: "content.post.route.invalid",
      message: "Post route must start with / and include [slug].",
      path: "content.post.route",
    });
  }

  const scopes = new Map<string, ContentSourceScope>();
  const scopedEntries = new Map<string, string>();
  for (const scope of post.sourceScopes) {
    if (scopes.has(scope.key)) {
      issues.push({
        code: "content.scope.duplicate",
        message: `Content source scope "${scope.key}" is declared more than once.`,
        path: `content.post.sourceScopes.${scope.key}`,
      });
    }
    scopes.set(scope.key, scope);
    for (const entryId of scope.entryIds) {
      const existingScope = scopedEntries.get(entryId);
      if (existingScope && existingScope !== scope.key) {
        issues.push({
          code: "content.scope.entry.duplicate",
          message: `Entry "${entryId}" belongs to both "${existingScope}" and "${scope.key}".`,
          path: `content.post.sourceScopes.${scope.key}`,
        });
      }
      scopedEntries.set(entryId, scope.key);
    }
  }

  const categories = new Set(post.categories);
  const tags = new Set(post.tags ?? []);
  for (const page of pages) {
    for (const input of page.regions) {
      if (typeof input === "string" || input.kind !== "postCollection") continue;
      if (!input.sourceScopeKey || !scopes.has(input.sourceScopeKey)) {
        issues.push({
          code: "content.scope.unknown",
          message: `Post collection "${input.id}" references an unknown source scope.`,
          path: `${page.path}:${input.id}`,
        });
      }
      for (const key of input.query?.categoryKeys ?? []) {
        if (!categories.has(key)) {
          issues.push({
            code: "content.taxonomy.unknown",
            message: `Post collection "${input.id}" references unknown category "${key}".`,
            path: `${page.path}:${input.id}`,
          });
        }
      }
      for (const key of input.query?.tagKeys ?? []) {
        if (!tags.has(key)) {
          issues.push({
            code: "content.taxonomy.unknown",
            message: `Post collection "${input.id}" references unknown tag "${key}".`,
            path: `${page.path}:${input.id}`,
          });
        }
      }
    }
  }
  return issues;
}

