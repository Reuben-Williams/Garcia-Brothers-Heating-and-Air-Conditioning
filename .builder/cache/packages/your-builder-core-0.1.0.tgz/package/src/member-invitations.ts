import type { BuilderCapability } from "./capabilities.js";
import {
  GROWTH_PERMISSION_TEMPLATES,
  type CapabilityGrantTemplateRow,
} from "./permission-templates.js";
import type { BuilderRole } from "./permissions.js";

export const APPROVED_GROWTH_INVITATION_TEMPLATES = Object.freeze([
  "growth_manager_v1",
  "growth_staff_v1",
  "growth_read_only_v1",
] as const);

export type GrowthInvitationTemplateId = (typeof APPROVED_GROWTH_INVITATION_TEMPLATES)[number];
export type MemberInvitationStatus = "pending" | "accepted" | "revoked" | "expired";

export interface CreateMemberInvitationCommand {
  readonly siteId: string;
  readonly actorId: string;
  readonly email: string;
  readonly templateId: GrowthInvitationTemplateId;
  readonly templateVersion: number;
  readonly expiresAt: string;
  readonly idempotencyKey: string;
  readonly aal2VerifiedAt: string;
}

export interface RevokeMemberInvitationCommand {
  readonly siteId: string;
  readonly actorId: string;
  readonly invitationId: string;
  readonly expectedVersion: number;
  readonly reason: string;
  readonly idempotencyKey: string;
  readonly aal2VerifiedAt: string;
}

export interface AcceptMemberInvitationCommand {
  readonly siteId: string;
  readonly invitationToken: string;
  readonly authenticatedUserId: string;
  readonly authenticatedEmail: string;
  readonly idempotencyKey: string;
}

export interface MemberInvitationOwnerView {
  readonly id: string;
  readonly siteId: string;
  readonly emailHint: string;
  readonly templateId: GrowthInvitationTemplateId;
  readonly templateVersion: number;
  readonly status: MemberInvitationStatus;
  readonly invitedBy: string;
  readonly expiresAt: string;
  readonly createdAt: string;
  readonly acceptedAt?: string;
  readonly revokedAt?: string;
  readonly version: number;
}

export interface MemberInvitationService {
  create(input: CreateMemberInvitationCommand): Promise<MemberInvitationOwnerView>;
  revoke(input: RevokeMemberInvitationCommand): Promise<MemberInvitationOwnerView>;
  accept(input: AcceptMemberInvitationCommand): Promise<{ readonly memberId: string; readonly replayed: boolean }>;
  listOwnerView(siteId: string, actorId: string): Promise<readonly MemberInvitationOwnerView[]>;
}

export type MemberInvitationOperation = "create" | "revoke" | "list";

export interface MemberInvitationAuthorizationQuery {
  readonly siteId: string;
  readonly actorId: string;
  readonly operation: MemberInvitationOperation;
  readonly assertedAal2VerifiedAt?: string;
}

export interface MemberInvitationAuthorization {
  readonly active: boolean;
  readonly owner: boolean;
  readonly capabilities: readonly BuilderCapability[];
  readonly aal2VerifiedAt: string | null;
}

interface MemberInvitationTrustedOwnerContext {
  readonly siteId: string;
  readonly actorId: string;
  readonly aal2VerifiedAt: string;
}

export interface MemberInvitationRepositoryCreateCommand extends MemberInvitationTrustedOwnerContext {
  readonly canonicalEmailDigest: string;
  readonly emailHint: string;
  readonly tokenHash: string;
  readonly templateId: GrowthInvitationTemplateId;
  readonly templateVersion: 1;
  readonly memberRole: BuilderRole;
  readonly capabilityGrants: readonly CapabilityGrantTemplateRow[];
  readonly expiresAt: string;
  readonly idempotencyKey: string;
  readonly createdAt: string;
}

export interface MemberInvitationRepositoryRevokeCommand extends MemberInvitationTrustedOwnerContext {
  readonly invitationId: string;
  readonly expectedVersion: number;
  readonly reason: string;
  readonly idempotencyKey: string;
  readonly revokedAt: string;
}

export interface MemberInvitationRepositoryAcceptCommand {
  readonly siteId: string;
  readonly tokenHash: string;
  readonly canonicalEmailDigest: string;
  readonly authenticatedUserId: string;
  readonly idempotencyKey: string;
  readonly acceptedAt: string;
}

export interface MemberInvitationRepositoryListQuery extends MemberInvitationTrustedOwnerContext {
  readonly observedAt: string;
}

export interface MemberInvitationAcceptance {
  readonly memberId: string;
  readonly replayed: boolean;
}

/**
 * Implementations must perform each method as one authoritative transaction. In particular,
 * acceptance owns token single-use, expiry, inviter activity, site, email-digest, and replay checks.
 */
export interface MemberInvitationRepository {
  createAuthoritatively(input: MemberInvitationRepositoryCreateCommand): Promise<MemberInvitationOwnerView>;
  revokeAuthoritatively(input: MemberInvitationRepositoryRevokeCommand): Promise<MemberInvitationOwnerView>;
  acceptAuthoritatively(input: MemberInvitationRepositoryAcceptCommand): Promise<MemberInvitationAcceptance>;
  listOwnerViewAuthoritatively(input: MemberInvitationRepositoryListQuery): Promise<readonly MemberInvitationOwnerView[]>;
}

export interface MemberInvitationCrypto {
  /** Returns the same unforgeable token when the same trusted issuance context is retried. */
  issueToken(input: MemberInvitationTokenIssuance): Promise<string>;
  hashToken(token: string): Promise<string>;
  digestCanonicalEmail(canonicalEmail: string): Promise<string>;
}

export interface MemberInvitationTokenIssuance {
  readonly siteId: string;
  readonly actorId: string;
  readonly idempotencyKey: string;
}

export interface MemberInvitationDispatchCommand {
  readonly siteId: string;
  readonly invitationId: string;
  readonly canonicalEmail: string;
  readonly invitationToken: string;
  readonly expiresAt: string;
  readonly idempotencyKey: string;
}

/** Implementations must dispatch idempotently by site and idempotency key and must not log secrets. */
export type MemberInvitationDispatcher = (input: MemberInvitationDispatchCommand) => Promise<void>;

export interface MemberInvitationServiceDependencies {
  readonly repository: MemberInvitationRepository;
  readonly authorize: (input: MemberInvitationAuthorizationQuery) => Promise<MemberInvitationAuthorization>;
  readonly crypto: MemberInvitationCrypto;
  readonly dispatch: MemberInvitationDispatcher;
}

export interface MemberInvitationServiceOptions {
  readonly now?: () => string;
  readonly recentAal2WindowMs?: number;
  readonly futureClockSkewMs?: number;
}

export type MemberInvitationServiceErrorCode =
  | "dispatch_failed"
  | "invalid_request"
  | "invalid_repository_result"
  | "not_authorized"
  | "recent_aal2_required";

export class MemberInvitationServiceError extends Error {
  readonly code: MemberInvitationServiceErrorCode;

  constructor(code: MemberInvitationServiceErrorCode) {
    super(code);
    this.name = "MemberInvitationServiceError";
    this.code = code;
  }
}

const TEMPLATE_ROLE: Readonly<Record<GrowthInvitationTemplateId, BuilderRole>> = Object.freeze({
  growth_manager_v1: "editor",
  growth_staff_v1: "contributor",
  growth_read_only_v1: "viewer",
});
const approvedTemplateIds = new Set<string>(APPROVED_GROWTH_INVITATION_TEMPLATES);
const SHA256_HEX = /^[a-f0-9]{64}$/;
const EMAIL = /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/;
const DEFAULT_RECENT_AAL2_WINDOW_MS = 5 * 60 * 1000;
const DEFAULT_FUTURE_CLOCK_SKEW_MS = 60 * 1000;

export function createMemberInvitationService(
  dependencies: MemberInvitationServiceDependencies,
  options: MemberInvitationServiceOptions = {},
): MemberInvitationService {
  const now = options.now ?? (() => new Date().toISOString());
  const recentAal2WindowMs = options.recentAal2WindowMs ?? DEFAULT_RECENT_AAL2_WINDOW_MS;
  const futureClockSkewMs = options.futureClockSkewMs ?? DEFAULT_FUTURE_CLOCK_SKEW_MS;

  async function authorizeOwner(
    siteId: string,
    actorId: string,
    operation: MemberInvitationOperation,
    assertedAal2VerifiedAt?: string,
  ): Promise<MemberInvitationTrustedOwnerContext> {
    requireIdentifier(siteId);
    requireIdentifier(actorId);
    const authorization = await dependencies.authorize({
      siteId,
      actorId,
      operation,
      ...(assertedAal2VerifiedAt === undefined ? {} : { assertedAal2VerifiedAt }),
    });
    if (!authorization.active || !authorization.owner || !authorization.capabilities.includes("members.manage")) {
      throw new MemberInvitationServiceError("not_authorized");
    }
    const observedAt = parseTimestamp(now());
    const aal2At = authorization.aal2VerifiedAt === null
      ? Number.NaN
      : Date.parse(authorization.aal2VerifiedAt);
    if (
      !Number.isFinite(aal2At)
      || aal2At < observedAt - recentAal2WindowMs
      || aal2At > observedAt + futureClockSkewMs
    ) {
      throw new MemberInvitationServiceError("recent_aal2_required");
    }
    return { siteId, actorId, aal2VerifiedAt: authorization.aal2VerifiedAt! };
  }

  return {
    async create(input) {
      const owner = await authorizeOwner(
        input.siteId,
        input.actorId,
        "create",
        input.aal2VerifiedAt,
      );
      const observedAt = now();
      const observedAtMs = parseTimestamp(observedAt);
      const canonicalEmail = canonicalizeEmail(input.email);
      const templateId = requireApprovedTemplate(input.templateId, input.templateVersion);
      const expiresAtMs = parseTimestamp(input.expiresAt);
      if (expiresAtMs <= observedAtMs) throw new MemberInvitationServiceError("invalid_request");
      requireIdempotencyKey(input.idempotencyKey);

      const token = await dependencies.crypto.issueToken({
        siteId: input.siteId,
        actorId: input.actorId,
        idempotencyKey: input.idempotencyKey,
      });
      requireSecret(token);
      const [tokenHash, canonicalEmailDigest] = await Promise.all([
        dependencies.crypto.hashToken(token),
        dependencies.crypto.digestCanonicalEmail(canonicalEmail),
      ]);
      requireDigest(tokenHash);
      requireDigest(canonicalEmailDigest);

      const result = await dependencies.repository.createAuthoritatively({
        ...owner,
        canonicalEmailDigest,
        emailHint: emailHint(canonicalEmail),
        tokenHash,
        templateId,
        templateVersion: 1,
        memberRole: TEMPLATE_ROLE[templateId],
        capabilityGrants: GROWTH_PERMISSION_TEMPLATES[templateId],
        expiresAt: input.expiresAt,
        idempotencyKey: input.idempotencyKey,
        createdAt: observedAt,
      });
      const ownerView = projectOwnerView(result, input.siteId);
      try {
        await dependencies.dispatch({
          siteId: input.siteId,
          invitationId: ownerView.id,
          canonicalEmail,
          invitationToken: token,
          expiresAt: ownerView.expiresAt,
          idempotencyKey: input.idempotencyKey,
        });
      } catch {
        throw new MemberInvitationServiceError("dispatch_failed");
      }
      return ownerView;
    },

    async revoke(input) {
      const owner = await authorizeOwner(
        input.siteId,
        input.actorId,
        "revoke",
        input.aal2VerifiedAt,
      );
      requireIdentifier(input.invitationId);
      requireExpectedVersion(input.expectedVersion);
      const reason = requireBoundedText(input.reason, 1, 500);
      requireIdempotencyKey(input.idempotencyKey);
      const result = await dependencies.repository.revokeAuthoritatively({
        ...owner,
        invitationId: input.invitationId,
        expectedVersion: input.expectedVersion,
        reason,
        idempotencyKey: input.idempotencyKey,
        revokedAt: now(),
      });
      return projectOwnerView(result, input.siteId);
    },

    async accept(input) {
      requireIdentifier(input.siteId);
      requireIdentifier(input.authenticatedUserId);
      requireIdempotencyKey(input.idempotencyKey);
      const canonicalEmail = canonicalizeEmail(input.authenticatedEmail);
      requireSecret(input.invitationToken);
      const [tokenHash, canonicalEmailDigest] = await Promise.all([
        dependencies.crypto.hashToken(input.invitationToken),
        dependencies.crypto.digestCanonicalEmail(canonicalEmail),
      ]);
      requireDigest(tokenHash);
      requireDigest(canonicalEmailDigest);
      const result = await dependencies.repository.acceptAuthoritatively({
        siteId: input.siteId,
        tokenHash,
        canonicalEmailDigest,
        authenticatedUserId: input.authenticatedUserId,
        idempotencyKey: input.idempotencyKey,
        acceptedAt: now(),
      });
      return { memberId: result.memberId, replayed: result.replayed };
    },

    async listOwnerView(siteId, actorId) {
      const owner = await authorizeOwner(siteId, actorId, "list");
      const results = await dependencies.repository.listOwnerViewAuthoritatively({
        ...owner,
        observedAt: now(),
      });
      return results.map((result) => projectOwnerView(result, siteId));
    },
  };
}

function requireApprovedTemplate(
  templateId: GrowthInvitationTemplateId,
  templateVersion: number,
): GrowthInvitationTemplateId {
  if (!approvedTemplateIds.has(templateId) || templateVersion !== 1) {
    throw new MemberInvitationServiceError("invalid_request");
  }
  return templateId;
}

function canonicalizeEmail(value: string): string {
  const canonical = value.trim().toLowerCase();
  const [local = "", domain = ""] = canonical.split("@");
  if (
    canonical.length > 254
    || local.length > 64
    || local.startsWith(".")
    || local.endsWith(".")
    || local.includes("..")
    || !EMAIL.test(canonical)
    || domain.length > 253
  ) {
    throw new MemberInvitationServiceError("invalid_request");
  }
  return canonical;
}

function emailHint(canonicalEmail: string): string {
  const separator = canonicalEmail.lastIndexOf("@");
  return `${canonicalEmail[0]}***${canonicalEmail.slice(separator)}`;
}

function requireIdentifier(value: string): void {
  if (!value || value !== value.trim() || value.length > 200 || value.includes("\0")) {
    throw new MemberInvitationServiceError("invalid_request");
  }
}

function requireIdempotencyKey(value: string): void {
  requireIdentifier(value);
}

function requireExpectedVersion(value: number): void {
  if (!Number.isInteger(value) || value < 1) throw new MemberInvitationServiceError("invalid_request");
}

function requireBoundedText(value: string, minimum: number, maximum: number): string {
  const normalized = value.trim();
  if (normalized.length < minimum || normalized.length > maximum || normalized.includes("\0")) {
    throw new MemberInvitationServiceError("invalid_request");
  }
  return normalized;
}

function requireSecret(value: string): void {
  if (!value || value !== value.trim() || value.length > 4096 || value.includes("\0")) {
    throw new MemberInvitationServiceError("invalid_request");
  }
}

function requireDigest(value: string): void {
  if (!SHA256_HEX.test(value)) throw new MemberInvitationServiceError("invalid_request");
}

function parseTimestamp(value: string): number {
  const parsed = Date.parse(value);
  if (!Number.isFinite(parsed)) throw new MemberInvitationServiceError("invalid_request");
  return parsed;
}

function projectOwnerView(input: MemberInvitationOwnerView, expectedSiteId: string): MemberInvitationOwnerView {
  if (input.siteId !== expectedSiteId) {
    throw new MemberInvitationServiceError("invalid_repository_result");
  }
  return {
    id: input.id,
    siteId: input.siteId,
    emailHint: input.emailHint,
    templateId: input.templateId,
    templateVersion: input.templateVersion,
    status: input.status,
    invitedBy: input.invitedBy,
    expiresAt: input.expiresAt,
    createdAt: input.createdAt,
    ...(input.acceptedAt === undefined ? {} : { acceptedAt: input.acceptedAt }),
    ...(input.revokedAt === undefined ? {} : { revokedAt: input.revokedAt }),
    version: input.version,
  };
}
