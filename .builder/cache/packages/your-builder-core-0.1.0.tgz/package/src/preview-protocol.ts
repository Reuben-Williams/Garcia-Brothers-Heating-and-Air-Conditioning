import type { EditableKind } from "./index.js";

export const BUILDER_PREVIEW_PROTOCOL = "your-builder.preview" as const;
export const BUILDER_PREVIEW_PROTOCOL_VERSION = 1 as const;

export type BuilderPreviewMessagePayload =
  | {
      type: "builder:select-region";
      pagePath: string;
      regionId: string;
      kind: EditableKind;
    }
  | {
      type: "builder:select-entry";
      pagePath: string;
      entryId: string;
      contentType: "post";
      regionId?: string;
      anchor?: { x: number; y: number };
    }
  | {
      type: "builder:open-workspace";
      pagePath: string;
      workspace: "posts" | "media" | "history";
      entryId?: string;
    }
  | { type: "builder:navigate"; pagePath: string }
  | { type: "builder:ready"; pagePath: string };

export type BuilderPreviewMessage = BuilderPreviewMessagePayload & {
  protocol: typeof BUILDER_PREVIEW_PROTOCOL;
  version: typeof BUILDER_PREVIEW_PROTOCOL_VERSION;
  siteId: string;
};

export function createBuilderPreviewMessage<TPayload extends BuilderPreviewMessagePayload>(
  siteId: string,
  payload: TPayload,
): TPayload & Omit<BuilderPreviewMessage, keyof BuilderPreviewMessagePayload> {
  return { protocol: BUILDER_PREVIEW_PROTOCOL, version: BUILDER_PREVIEW_PROTOCOL_VERSION, siteId, ...payload };
}

export function isBuilderPreviewMessage(value: unknown, expectedSiteId?: string): value is BuilderPreviewMessage {
  if (!value || typeof value !== "object") return false;
  const message = value as Partial<BuilderPreviewMessage>;
  if (
    message.protocol !== BUILDER_PREVIEW_PROTOCOL ||
    message.version !== BUILDER_PREVIEW_PROTOCOL_VERSION ||
    typeof message.siteId !== "string" ||
    (expectedSiteId !== undefined && message.siteId !== expectedSiteId) ||
    typeof message.pagePath !== "string"
  ) return false;

  if (message.type === "builder:navigate" || message.type === "builder:ready") return true;
  if (message.type === "builder:select-region") {
    return typeof message.regionId === "string" && typeof message.kind === "string";
  }
  if (message.type === "builder:select-entry") {
    const anchor = message.anchor;
    return typeof message.entryId === "string" && message.contentType === "post" && (
      anchor === undefined ||
      (typeof anchor === "object" && typeof anchor.x === "number" && typeof anchor.y === "number")
    );
  }
  if (message.type === "builder:open-workspace") {
    return message.workspace === "posts" || message.workspace === "media" || message.workspace === "history";
  }
  return false;
}
