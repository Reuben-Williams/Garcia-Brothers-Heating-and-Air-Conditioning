export type PostLifecycleAuditAction =
  | "post.created"
  | "post.draft_saved"
  | "post.published"
  | "post.scheduled"
  | "post.schedule_cancelled"
  | "post.schedule_rescheduled"
  | "post.archived"
  | "post.draft_restored"
  | "post.rolled_back"
  | "post.rollback_undone"
  | "post.taxonomy_assigned"
  | "post.taxonomy_removed"
  | "post.migration_seeded";

export interface ContentAuditContext {
  entryId: string;
  contentType: "post";
  actorEmail?: string;
  correlationId?: string;
  beforeVersionId?: string | null;
  afterVersionId?: string | null;
}

