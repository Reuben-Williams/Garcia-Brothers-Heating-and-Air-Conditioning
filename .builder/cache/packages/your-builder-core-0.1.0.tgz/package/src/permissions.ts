import { GROWTH_CAPABILITIES, WEBSITE_CAPABILITIES, type BuilderCapability } from "./capabilities.js";

export type BuilderRole = "owner" | "editor" | "contributor" | "viewer";

export type { BuilderCapability } from "./capabilities.js";

const roleCapabilities: Record<BuilderRole, readonly BuilderCapability[]> = {
  owner: Array.from(new Set([...WEBSITE_CAPABILITIES, ...GROWTH_CAPABILITIES])),
  editor: [
    "preview.read",
    "history.read",
    "post.create",
    "post.editDraft",
    "post.publish",
    "post.schedule",
    "post.archive",
    "post.rollback",
    "media.upload",
  ],
  contributor: ["preview.read", "history.read", "post.create", "post.editDraft", "media.upload"],
  viewer: ["preview.read", "history.read"],
};

export function capabilitiesForRole(role: BuilderRole): BuilderCapability[] {
  return [...roleCapabilities[role]];
}

export function canBuilderRole(role: BuilderRole, capability: BuilderCapability): boolean {
  return roleCapabilities[role].includes(capability);
}

