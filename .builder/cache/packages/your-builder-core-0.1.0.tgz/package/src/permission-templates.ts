import type { BuilderCapabilityScope, GrowthCapability } from "./capabilities.js";

export interface CapabilityGrantTemplateRow {
  readonly capability: GrowthCapability;
  readonly scope: BuilderCapabilityScope;
}

const rows = (scope: BuilderCapabilityScope, capabilities: readonly GrowthCapability[]) =>
  Object.freeze(capabilities.map((capability) => Object.freeze({ capability, scope })));

export const GROWTH_PERMISSION_TEMPLATES = Object.freeze({
  growth_manager_v1: rows("site", [
    "dashboard.read", "leads.read", "leads.create", "leads.update", "leads.assign", "leads.export",
    "customers.read", "customers.update", "customers.export", "tasks.read", "tasks.manage",
    "messages.read", "messages.draft", "messages.send", "templates.manage", "reviews.manage",
    "automations.read", "automations.manage", "automations.approve", "projects.read", "projects.manage",
    "siteHealth.read", "emergencyPause.manage",
  ]),
  growth_staff_v1: Object.freeze([
    ...rows("site", ["dashboard.read", "leads.create"]),
    ...rows("assigned", [
      "leads.read", "leads.update", "customers.read", "customers.update", "tasks.read", "tasks.manage",
      "messages.read", "messages.draft", "messages.send", "projects.read",
    ]),
  ]),
  growth_read_only_v1: rows("site", [
    "dashboard.read", "leads.read", "customers.read", "tasks.read", "messages.read",
    "automations.read", "projects.read", "siteHealth.read",
  ]),
} as const);
