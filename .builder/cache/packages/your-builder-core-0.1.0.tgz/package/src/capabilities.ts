export const WEBSITE_CAPABILITIES = Object.freeze([
  "members.manage", "preview.read", "history.read", "post.create", "post.editDraft",
  "post.publish", "post.schedule", "post.archive", "post.rollback", "media.upload",
] as const);

export const GROWTH_CAPABILITIES = Object.freeze([
  "dashboard.read", "leads.read", "leads.create", "leads.update", "leads.assign", "leads.export",
  "customers.read", "customers.update", "customers.export", "customers.deleteRequest",
  "tasks.read", "tasks.manage", "messages.read", "messages.draft", "messages.send",
  "templates.manage", "reviews.manage", "automations.read", "automations.manage",
  "automations.approve", "projects.read", "projects.manage", "integrations.manage",
  "members.manage", "billing.manage", "siteHealth.read", "emergencyPause.manage",
] as const);

export type WebsiteCapability = (typeof WEBSITE_CAPABILITIES)[number];
export type GrowthCapability = (typeof GROWTH_CAPABILITIES)[number];
export type BuilderCapability = WebsiteCapability | GrowthCapability;
export type BuilderCapabilityScope = "site" | "assigned";

const growthCapabilitySet = new Set<string>(GROWTH_CAPABILITIES);
const assignedCapable = new Set<GrowthCapability>([
  "leads.read", "leads.update", "customers.read", "customers.update", "tasks.read", "tasks.manage",
  "messages.read", "messages.draft", "messages.send", "projects.read", "projects.manage",
]);
const NO_SCOPES: readonly BuilderCapabilityScope[] = Object.freeze([]);
const SITE_SCOPES: readonly BuilderCapabilityScope[] = Object.freeze(["site"]);
const SITE_AND_ASSIGNED_SCOPES: readonly BuilderCapabilityScope[] = Object.freeze(["site", "assigned"]);

export function allowedCapabilityScopes(capability: GrowthCapability): readonly BuilderCapabilityScope[] {
  if (!growthCapabilitySet.has(capability)) return NO_SCOPES;
  return assignedCapable.has(capability) ? SITE_AND_ASSIGNED_SCOPES : SITE_SCOPES;
}
