export interface ImmutableMediaRevision {
  siteId: string;
  mediaId: string;
  revisionId: string;
  objectKey: string;
  mimeType: string;
  byteSize: number;
  width: number | null;
  height: number | null;
  createdAt: string;
}

export interface RetainedMediaReference {
  siteId: string;
  entryId: string;
  versionId: string;
  mediaId: string;
  revisionId: string;
  fieldPath: string;
}

