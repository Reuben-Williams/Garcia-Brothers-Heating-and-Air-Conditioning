export type BaseFormValue = string | number | boolean | null | BaseFormPayload | readonly BaseFormValue[];

export interface BaseFormPayload {
  readonly [field: string]: BaseFormValue;
}

export interface BaseFormSubmission {
  readonly id: string;
  readonly siteId: string;
  readonly formId: string;
  readonly sourcePage: string;
  readonly payload: BaseFormPayload;
  readonly payloadByteLength: number;
  readonly fieldCount: number;
  readonly capturedAt: string;
  readonly createdAt: string;
}

export interface BaseFormConsentEvidence {
  readonly id: string;
  readonly siteId: string;
  readonly submissionId: string;
  readonly policyVersion: string;
  readonly purpose: string;
  readonly languageDigest: string;
  readonly source: string;
  readonly capturedAt: string;
  readonly createdAt: string;
}

export const BASE_FORM_SUBMISSION_EVENT_KINDS = Object.freeze([
  "spam",
  "restore",
  "review",
  "correction",
] as const);

export type BaseFormSubmissionEventKind = (typeof BASE_FORM_SUBMISSION_EVENT_KINDS)[number];

export interface BaseFormSubmissionEvent {
  readonly id: string;
  readonly siteId: string;
  readonly submissionId: string;
  readonly kind: BaseFormSubmissionEventKind;
  readonly actorId?: string;
  readonly reasonCode?: string;
  readonly correctionOfEventId?: string;
  readonly occurredAt: string;
  readonly createdAt: string;
}

export const BASE_FORM_SAFE_RESULT_CODES = Object.freeze([
  "enhanced",
  "enhancement_unavailable",
  "identity_conflict",
  "review_suggested",
  "spam",
] as const);

export type BaseFormSafeResultCode = (typeof BASE_FORM_SAFE_RESULT_CODES)[number];

interface BaseFormSubmissionResultBase {
  readonly id: string;
  readonly siteId: string;
  readonly submissionId: string;
  readonly version: number;
  readonly priorResultId?: string;
  readonly createdAt: string;
}

export interface EnhancedBaseFormSubmissionResult extends BaseFormSubmissionResultBase {
  readonly outcome: "enhanced";
  readonly safeCode: "enhanced";
  readonly contactId: string;
  readonly leadId: string;
}

export interface BaseOnlyFormSubmissionResult extends BaseFormSubmissionResultBase {
  readonly outcome: "base_only";
  readonly safeCode: "enhancement_unavailable" | "spam";
  readonly contactId?: never;
  readonly leadId?: never;
}

export interface ReviewBaseFormSubmissionResult extends BaseFormSubmissionResultBase {
  readonly outcome: "review_required";
  readonly safeCode: "identity_conflict" | "review_suggested";
  readonly contactId?: never;
  readonly leadId?: never;
}

export type BaseFormSubmissionResult =
  | EnhancedBaseFormSubmissionResult
  | BaseOnlyFormSubmissionResult
  | ReviewBaseFormSubmissionResult;

export type BaseFormSubmissionInboxState =
  | "new"
  | "spam"
  | "review_required"
  | "enhanced"
  | "base_only";

export interface BaseFormSubmissionResultSummary {
  readonly id: string;
  readonly version: number;
  readonly outcome: BaseFormSubmissionResult["outcome"];
  readonly safeCode: BaseFormSafeResultCode;
  readonly contactId?: string;
  readonly leadId?: string;
  readonly createdAt: string;
}

export interface BaseFormSubmissionListItem {
  readonly id: string;
  readonly formId: string;
  readonly sourcePage: string;
  readonly capturedAt: string;
  readonly inboxState: BaseFormSubmissionInboxState;
  readonly currentResult?: BaseFormSubmissionResultSummary;
}

export interface BaseFormSubmissionListFilter {
  readonly states?: readonly BaseFormSubmissionInboxState[];
  readonly formIds?: readonly string[];
  readonly capturedFrom?: string;
  readonly capturedTo?: string;
}

export interface BaseFormSubmissionPage {
  readonly items: readonly BaseFormSubmissionListItem[];
  readonly nextCursor?: string;
}

export interface BaseFormSubmissionDetail {
  readonly submission: BaseFormSubmission;
  readonly consent: BaseFormConsentEvidence;
  readonly events: readonly BaseFormSubmissionEvent[];
  readonly resultHistory: readonly BaseFormSubmissionResultSummary[];
  readonly currentResult?: BaseFormSubmissionResultSummary;
}

export type BaseFormSubmissionQueryResultCode = "base_only" | "enhanced" | "review_required" | "identity_conflict" | "spam";

export interface BaseFormSubmissionQueryResult {
  readonly id: string;
  readonly version: number;
  readonly priorResultId?: string;
  readonly resultCode: BaseFormSubmissionQueryResultCode;
  readonly contactId?: string;
  readonly leadId?: string;
  readonly safeMetadata: BaseFormPayload;
  readonly createdAt: string;
}

export interface BaseFormSubmissionQueryListItem {
  readonly id: string;
  readonly formId: string;
  readonly source: string;
  readonly zipCode?: string;
  readonly locale?: string;
  readonly receivedAt: string;
  readonly currentResult?: BaseFormSubmissionQueryResult;
}

export interface BaseFormSubmissionQueryPage {
  readonly items: readonly BaseFormSubmissionQueryListItem[];
  readonly nextCursor?: string;
}

export interface BaseFormSubmissionQueryDetail {
  readonly submission: {
    readonly id: string;
    readonly formId: string;
    readonly payload: BaseFormPayload;
    readonly source: string;
    readonly zipCode?: string;
    readonly locale?: string;
    readonly receivedAt: string;
    readonly createdAt: string;
  };
  readonly consents: readonly Omit<BaseFormConsentEvidence, "siteId" | "submissionId" | "createdAt">[];
  readonly events: readonly {
    readonly id: string;
    readonly eventKind: BaseFormSubmissionEventKind;
    readonly actorId?: string;
    readonly metadata: BaseFormPayload;
    readonly createdAt: string;
  }[];
  readonly results: readonly BaseFormSubmissionQueryResult[];
}

export type BaseFormPayloadMetadataValidation =
  | { readonly ok: true }
  | { readonly ok: false; readonly code: "invalid_payload_size" | "payload_too_large" | "invalid_field_count" | "too_many_fields" };

export function validateBaseFormPayloadMetadata(input: {
  readonly payloadByteLength: number;
  readonly fieldCount: number;
}): BaseFormPayloadMetadataValidation {
  if (!Number.isInteger(input.payloadByteLength) || input.payloadByteLength < 0) {
    return { ok: false, code: "invalid_payload_size" };
  }
  if (input.payloadByteLength > 65_536) return { ok: false, code: "payload_too_large" };
  if (!Number.isInteger(input.fieldCount) || input.fieldCount < 0) {
    return { ok: false, code: "invalid_field_count" };
  }
  if (input.fieldCount > 64) return { ok: false, code: "too_many_fields" };
  return { ok: true };
}

export function createBaseFormSubmissionResult<TResult extends BaseFormSubmissionResult>(input: TResult): TResult {
  if (!Number.isInteger(input.version) || input.version < 1) {
    throw new Error("Base form submission result version must be a positive integer.");
  }
  if (input.priorResultId === input.id) {
    throw new Error("Base form submission result cannot reference itself as its prior result.");
  }
  if (input.outcome !== "enhanced" && ("contactId" in input || "leadId" in input)) {
    throw new Error(`${input.safeCode} results must not link contact or lead records.`);
  }
  if (input.outcome === "enhanced" && (!input.contactId || !input.leadId)) {
    throw new Error("Enhanced results require both contact and lead links.");
  }
  Object.freeze(input);
  return input;
}
