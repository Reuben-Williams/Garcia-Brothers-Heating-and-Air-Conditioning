import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { PostCollectionQuery } from "@your-builder/content";
import type { PostLifecycleAuditAction } from "./audit.js";
import type { BuilderContentConfiguration, PostCollectionRegionOptions } from "./site-config.js";
import { validateContentConfiguration } from "./site-config.js";

export * from "./audit.js";
export * from "./capabilities.js";
export * from "./form-submissions.js";
export * from "./media.js";
export * from "./member-invitations.js";
export * from "./permission-templates.js";
export * from "./permissions.js";
export * from "./preview-protocol.js";
export * from "./site-config.js";
export * from "./supabase/client.js";
export * from "./supabase/content-mappers.js";
export * from "./supabase/content-repository.js";
export * from "./supabase/errors.js";

export type BuilderAdapterKind = "central" | "supabase" | "memory";

export type EditableKind = "text" | "richText" | "image" | "link" | "sections" | "icon" | "postCollection";

export type EditableValue =
  | { type: "text"; value: string }
  | { type: "richText"; value: string }
  | { type: "image"; src: string; alt?: string; mediaId?: string }
  | { type: "link"; href: string; label: string }
  | { type: "sections"; value: string[] }
  | { type: "icon"; icon: string; label?: string }
  | { type: "postCollection"; sourceScopeKey: string; query: PostCollectionQuery };

export interface BuilderRegionDefinition extends PostCollectionRegionOptions {
  id: string;
  kind: EditableKind;
  label?: string;
  required?: boolean;
}

export type BuilderRegionInput = string | BuilderRegionDefinition;

export interface BuilderPage {
  path: string;
  label: string;
  regions: BuilderRegionInput[];
}

export interface BuilderSiteConfig {
  siteId: string;
  adapter: BuilderAdapterKind;
  editor?: {
    path?: string;
    protected?: boolean;
  };
  globalRegions?: BuilderRegionInput[];
  pages: BuilderPage[];
  sections: Record<string, unknown>;
  content?: BuilderContentConfiguration;
}

export interface PageContent {
  path: string;
  regions: Record<string, EditableValue>;
  versionId?: string;
  updatedAt?: string;
}

export type VersionStatus = "draft" | "published" | "rollback" | "undoRollback";

export interface VersionRecord {
  id: string;
  siteId: string;
  pagePath: string;
  status: VersionStatus;
  snapshot: PageContent;
  userId: string;
  createdAt: string;
}

export type AuditAction =
  | "draft.saved"
  | "version.published"
  | "version.rolled_back"
  | "rollback.undone"
  | "media.uploaded"
  | PostLifecycleAuditAction;

export interface AuditEvent {
  id: string;
  siteId: string;
  pagePath: string;
  action: AuditAction;
  userId: string;
  userLabel?: string;
  createdAt: string;
  summary: string;
  regionId?: string;
  kind?: EditableKind;
  before?: EditableValue | null;
  after?: EditableValue | null;
  versionId?: string;
  sourceVersionId?: string;
  resultVersionId?: string;
  entryId?: string;
  actorEmail?: string;
  correlationId?: string;
  contentBefore?: unknown;
  contentAfter?: unknown;
}

export interface SaveDraftInput {
  siteId: string;
  pagePath: string;
  regionId: string;
  value: EditableValue;
  userId: string;
}

export interface PublishInput {
  siteId: string;
  pagePath: string;
  userId: string;
}

export interface RollbackInput {
  siteId: string;
  pagePath: string;
  versionId: string;
  userId: string;
}

export interface UndoRollbackInput {
  siteId: string;
  pagePath: string;
  rollbackVersionId: string;
  userId: string;
}

export interface MediaAsset {
  id: string;
  siteId: string;
  path: string;
  url: string;
  alt: string;
  label: string;
  mimeType: string;
  source: "seed" | "upload";
  width?: number;
  height?: number;
  userId: string;
  createdAt: string;
}

export interface CreateMediaAssetInput {
  siteId: string;
  path: string;
  url: string;
  alt: string;
  label: string;
  mimeType: string;
  userId: string;
  source?: "seed" | "upload";
  width?: number;
  height?: number;
}

export interface BuilderContentAdapter {
  getPublishedContent(siteId: string, path: string): Promise<PageContent>;
  getDraftContent(siteId: string, path: string): Promise<PageContent>;
  saveDraft(input: SaveDraftInput): Promise<VersionRecord>;
  publishVersion(input: PublishInput): Promise<VersionRecord>;
  rollbackToVersion(input: RollbackInput): Promise<VersionRecord>;
  undoRollback(input: UndoRollbackInput): Promise<VersionRecord>;
  listAuditLog(siteId: string, path?: string): Promise<AuditEvent[]>;
  createMediaAsset(input: CreateMediaAssetInput): Promise<MediaAsset>;
  listMediaAssets(siteId: string): Promise<MediaAsset[]>;
}

export type ContentEntryStatus = "draft" | "scheduled" | "published" | "archived";
export type ContentEntryType =
  | "post"
  | "event"
  | "service"
  | "staff"
  | "testimonial"
  | "faq"
  | "location"
  | "promotion"
  | string;

export interface ContentEntry {
  id: string;
  siteId: string;
  type: ContentEntryType;
  slug: string;
  title: string;
  status: ContentEntryStatus;
  fields: Record<string, unknown>;
  publishAt?: string;
  updatedAt?: string;
}

export interface CreateContentEntryInput {
  siteId: string;
  type: ContentEntryType;
  slug: string;
  title: string;
  status?: ContentEntryStatus;
  fields?: Record<string, unknown>;
  publishAt?: string;
}

export interface BusinessFacts {
  businessName: string;
  services?: string[];
  locations?: string[];
  phone?: string;
  email?: string;
  hours?: string;
  preferredCtas?: string[];
}

export interface BrandVoice {
  tone: string;
  bannedClaims?: string[];
  preferredWords?: string[];
}

export interface BrandProfile {
  siteId: string;
  businessFacts: BusinessFacts;
  voice: BrandVoice;
}

export interface BrandProfileValidationResult {
  ok: boolean;
  profile: BrandProfile;
  issues: ValidationIssue[];
}

export interface RewriteRequest {
  siteId: string;
  pagePath: string;
  regionId: string;
  kind: Extract<EditableKind, "text" | "richText">;
  currentValue: string;
  instruction: string;
  brandProfile: BrandProfile;
  scope: "selected-field";
}

export interface RewriteProvider {
  rewriteSelectedField(input: RewriteRequest): Promise<{ value: string; rationale?: string }>;
}

export type ApprovalStatus = "pending" | "approved" | "changes-requested" | "expired";

export interface DraftApprovalLink {
  id: string;
  siteId: string;
  pagePath: string;
  versionId: string;
  tokenHash: string;
  status: ApprovalStatus;
  expiresAt: string;
  createdBy: string;
}

export interface BulkEditGroup {
  id: string;
  siteId: string;
  label: string;
  itemType: "service" | "testimonial" | "faq" | "staff" | "promotion" | string;
  regionIds: string[];
}

export type CalendarItemKind = "post" | "event" | "promotion" | "campaign" | "section";

export interface ContentCalendarItem {
  id: string;
  siteId: string;
  kind: CalendarItemKind;
  title: string;
  status: ContentEntryStatus;
  scheduledFor: string;
  targetId: string;
}

/** @deprecated Use BaseFormSubmission and the growth-leads workflow contracts. */
export type FormSubmissionStatus = "new" | "contacted" | "qualified" | "closed" | "spam";

/** @deprecated Use BaseFormSubmission and the growth-leads workflow contracts. */
export interface FormLeadSubmission {
  id: string;
  siteId: string;
  formId: string;
  sourcePage: string;
  status: FormSubmissionStatus;
  values: Record<string, unknown>;
  assignedTo?: string;
  createdAt: string;
  updatedAt: string;
}

export interface FormSubmissionStatusChange {
  submissionId: string;
  from: FormSubmissionStatus;
  to: FormSubmissionStatus;
  actorId: string;
  note?: string;
  changedAt: string;
}

export interface RedirectSuggestion {
  id: string;
  siteId: string;
  contentType: string;
  fromPath: string;
  toPath: string;
  status: "pending-review" | "approved" | "rejected";
}

export interface NotificationProvider {
  sendLeadNotification(input: { siteId: string; submissionId: string; recipients: string[] }): Promise<void>;
}

export interface ValidationIssue {
  code: string;
  message: string;
  path?: string;
}

export interface ValidationResult {
  ok: boolean;
  issues: ValidationIssue[];
}

export function defineBuilderSite<TConfig extends BuilderSiteConfig>(config: TConfig): TConfig {
  return config;
}

export function createContentEntry(input: CreateContentEntryInput): ContentEntry {
  const slug = normalizeSlug(input.slug);
  const type = normalizeSlug(String(input.type));
  return {
    id: `${type}:${slug}`,
    siteId: input.siteId,
    type: input.type,
    slug,
    title: input.title,
    status: input.status ?? "draft",
    fields: input.fields ?? {},
    publishAt: input.publishAt,
  };
}

export function validateBrandProfile(profile: BrandProfile): BrandProfileValidationResult {
  const issues: ValidationIssue[] = [];
  if (!profile.siteId.trim()) {
    issues.push({ code: "brand.siteId.missing", message: "Brand profile requires a siteId.", path: "siteId" });
  }
  if (!profile.businessFacts.businessName.trim()) {
    issues.push({
      code: "brand.businessName.missing",
      message: "Business facts require a business name.",
      path: "businessFacts.businessName",
    });
  }
  if (!profile.voice.tone.trim()) {
    issues.push({ code: "brand.voice.missing", message: "Brand voice requires a tone.", path: "voice.tone" });
  }
  return { ok: issues.length === 0, profile, issues };
}

export function createRewriteRequest(input: Omit<RewriteRequest, "scope">): RewriteRequest {
  return { ...input, scope: "selected-field" };
}

export function createRedirectSuggestion(input: {
  siteId: string;
  sourceSlug: string;
  targetSlug: string;
  contentType: string;
}): RedirectSuggestion {
  const contentType = normalizeSlug(input.contentType);
  const fromPath = `/${contentType}/${normalizeSlug(input.sourceSlug)}`;
  const toPath = `/${contentType}/${normalizeSlug(input.targetSlug)}`;
  return {
    id: `${input.siteId}:${fromPath}->${toPath}`,
    siteId: input.siteId,
    contentType: input.contentType,
    fromPath,
    toPath,
    status: "pending-review",
  };
}

/** @deprecated Use append-only base submission or lead events. */
export function createSubmissionStatusChange(input: Omit<FormSubmissionStatusChange, "changedAt">): FormSubmissionStatusChange {
  return { ...input, changedAt: new Date().toISOString() };
}

function normalizeSlug(value: string): string {
  return (
    value
      .toLowerCase()
      .match(/[a-z0-9]+/g)
      ?.join("-") ?? "item"
  );
}

export type NormalizedBuilderRegionDefinition = BuilderRegionDefinition & {
  label: string;
  required: boolean;
};

export function normalizeRegionDefinitions(regions: BuilderRegionInput[]): NormalizedBuilderRegionDefinition[] {
  return regions.map((region) =>
    typeof region === "string"
      ? { id: region, kind: "text", label: region, required: false }
      : {
          id: region.id,
          kind: region.kind,
          label: region.label ?? region.id,
          required: region.required ?? false,
          sourceScopeKey: region.sourceScopeKey,
          query: region.query,
        },
  );
}

export function validateBuilderSite(site: BuilderSiteConfig): ValidationResult {
  const issues: ValidationIssue[] = [];
  const paths = new Set<string>();
  const regions = new Map<string, EditableKind>();

  function registerRegion(region: NormalizedBuilderRegionDefinition, path: string) {
    if (!/^[a-z0-9]+(?:[.-][a-z0-9]+)*$/i.test(region.id)) {
      issues.push({
        code: "region.id.invalid",
        message: `Region id "${region.id}" should use stable dot or dash separated words.`,
        path,
      });
    }

    const existingKind = regions.get(region.id);
    if (existingKind) {
      issues.push({
        code: "region.id.duplicate",
        message: `Region id "${region.id}" is declared more than once.`,
        path,
      });
      if (existingKind !== region.kind) {
        issues.push({
          code: "region.kind.conflict",
          message: `Region id "${region.id}" is declared as both "${existingKind}" and "${region.kind}".`,
          path,
        });
      }
    }
    regions.set(region.id, region.kind);
  }

  if (!site.siteId.trim()) {
    issues.push({ code: "site.id.missing", message: "siteId is required.", path: "siteId" });
  }

  for (const region of normalizeRegionDefinitions(site.globalRegions ?? [])) {
    registerRegion(region, `global:${region.id}`);
  }

  for (const page of site.pages) {
    if (!page.path.startsWith("/")) {
      issues.push({
        code: "page.path.invalid",
        message: `Page path "${page.path}" must start with "/".`,
        path: page.path,
      });
    }

    if (paths.has(page.path)) {
      issues.push({
        code: "page.path.duplicate",
        message: `Page path "${page.path}" is declared more than once.`,
        path: page.path,
      });
    }
    paths.add(page.path);

    for (const region of normalizeRegionDefinitions(page.regions)) {
      registerRegion(region, `${page.path}:${region.id}`);
    }
  }

  issues.push(...validateContentConfiguration(site.content, site.pages));

  return { ok: issues.length === 0, issues };
}

export function readRegionValue(page: PageContent, regionId: string, fallback: string): string {
  const value = page.regions[regionId];
  if (!value) return fallback;
  if (value.type === "text" || value.type === "richText") return value.value;
  if (value.type === "link") return value.label;
  if (value.type === "image") return value.src;
  if (value.type === "icon") return value.icon;
  return fallback;
}

export function readRegion(page: PageContent | undefined, regionId: string): EditableValue | undefined {
  return page?.regions[regionId];
}

export function createInMemoryAdapter(): BuilderContentAdapter {
  const drafts = new Map<string, PageContent>();
  const published = new Map<string, PageContent>();
  const rollbackUndoSnapshots = new Map<string, PageContent>();
  const versions: VersionRecord[] = [];
  const audit: AuditEvent[] = [];
  const mediaAssets: MediaAsset[] = [];
  let sequence = 0;

  const key = (siteId: string, pagePath: string) => `${siteId}:${pagePath}`;
  const now = () => new Date().toISOString();
  const nextId = (prefix: string) => `${prefix}-${++sequence}`;
  const clonePage = (page: PageContent): PageContent => ({
    ...page,
    regions: structuredClone(page.regions),
  });

  function emptyPage(path: string): PageContent {
    return { path, regions: {} };
  }

  function pushAudit(event: Omit<AuditEvent, "id" | "createdAt">): AuditEvent {
    const record = { ...event, id: nextId("audit"), createdAt: now() };
    audit.push(record);
    return record;
  }

  function pushVersion(input: Omit<VersionRecord, "id" | "createdAt">): VersionRecord {
    const record = {
      ...input,
      id: nextId("version"),
      createdAt: now(),
      snapshot: clonePage(input.snapshot),
    };
    versions.push(record);
    return record;
  }

  return {
    async getPublishedContent(siteId, pagePath) {
      return clonePage(published.get(key(siteId, pagePath)) ?? emptyPage(pagePath));
    },

    async getDraftContent(siteId, pagePath) {
      return clonePage(drafts.get(key(siteId, pagePath)) ?? published.get(key(siteId, pagePath)) ?? emptyPage(pagePath));
    },

    async saveDraft(input) {
      const mapKey = key(input.siteId, input.pagePath);
      const current = drafts.get(mapKey) ?? published.get(mapKey) ?? emptyPage(input.pagePath);
      const before = current.regions[input.regionId] ?? null;
      const nextPage: PageContent = {
        path: input.pagePath,
        regions: { ...current.regions, [input.regionId]: input.value },
        updatedAt: now(),
      };
      drafts.set(mapKey, nextPage);

      const version = pushVersion({
        siteId: input.siteId,
        pagePath: input.pagePath,
        status: "draft",
        snapshot: nextPage,
        userId: input.userId,
      });

      pushAudit({
        siteId: input.siteId,
        pagePath: input.pagePath,
        action: "draft.saved",
        userId: input.userId,
        summary: `Saved draft for ${input.regionId}`,
        regionId: input.regionId,
        kind: input.value.type,
        before,
        after: input.value,
        versionId: version.id,
        resultVersionId: version.id,
      });

      return version;
    },

    async publishVersion(input) {
      const mapKey = key(input.siteId, input.pagePath);
      const draft = drafts.get(mapKey) ?? published.get(mapKey) ?? emptyPage(input.pagePath);
      const snapshot = clonePage(draft);
      snapshot.updatedAt = now();
      published.set(mapKey, snapshot);

      const version = pushVersion({
        siteId: input.siteId,
        pagePath: input.pagePath,
        status: "published",
        snapshot,
        userId: input.userId,
      });

      pushAudit({
        siteId: input.siteId,
        pagePath: input.pagePath,
        action: "version.published",
        userId: input.userId,
        summary: `Published ${input.pagePath}`,
        versionId: version.id,
        resultVersionId: version.id,
      });

      return version;
    },

    async rollbackToVersion(input) {
      const target = versions.find(
        (version) =>
          version.id === input.versionId &&
          version.siteId === input.siteId &&
          version.pagePath === input.pagePath,
      );

      if (!target) {
        throw new Error(`Version "${input.versionId}" was not found for ${input.siteId}${input.pagePath}.`);
      }

      const mapKey = key(input.siteId, input.pagePath);
      const previousPublished = published.get(mapKey);
      const snapshot = clonePage(target.snapshot);
      snapshot.updatedAt = now();
      published.set(mapKey, snapshot);

      const version = pushVersion({
        siteId: input.siteId,
        pagePath: input.pagePath,
        status: "rollback",
        snapshot,
        userId: input.userId,
      });
      if (previousPublished) rollbackUndoSnapshots.set(version.id, clonePage(previousPublished));

      pushAudit({
        siteId: input.siteId,
        pagePath: input.pagePath,
        action: "version.rolled_back",
        userId: input.userId,
        summary: `Rolled back ${input.pagePath} to ${input.versionId}`,
        versionId: version.id,
        sourceVersionId: input.versionId,
        resultVersionId: version.id,
      });

      return version;
    },

    async undoRollback(input) {
      const previous = rollbackUndoSnapshots.get(input.rollbackVersionId);
      if (!previous) {
        throw new Error(`Rollback version "${input.rollbackVersionId}" cannot be undone.`);
      }

      const snapshot = clonePage(previous);
      snapshot.updatedAt = now();
      published.set(key(input.siteId, input.pagePath), snapshot);

      const version = pushVersion({
        siteId: input.siteId,
        pagePath: input.pagePath,
        status: "undoRollback",
        snapshot,
        userId: input.userId,
      });

      pushAudit({
        siteId: input.siteId,
        pagePath: input.pagePath,
        action: "rollback.undone",
        userId: input.userId,
        summary: `Undid rollback ${input.rollbackVersionId}`,
        versionId: version.id,
        sourceVersionId: input.rollbackVersionId,
        resultVersionId: version.id,
      });

      return version;
    },

    async listAuditLog(siteId, pagePath) {
      return audit.filter((event) => event.siteId === siteId && (!pagePath || event.pagePath === pagePath));
    },

    async createMediaAsset(input) {
      const asset: MediaAsset = {
        ...input,
        id: nextId("media"),
        source: input.source ?? "upload",
        createdAt: now(),
      };
      mediaAssets.unshift(asset);
      pushAudit({
        siteId: input.siteId,
        pagePath: "/",
        action: "media.uploaded",
        userId: input.userId,
        summary: `Uploaded ${input.label}`,
      });
      return asset;
    },

    async listMediaAssets(siteId) {
      return mediaAssets.filter((asset) => asset.siteId === siteId);
    },
  };
}

export interface CentralAdapterOptions {
  apiUrl: string;
  siteToken: string;
  fetchImpl?: typeof fetch;
}

export function createCentralAdapter(options: CentralAdapterOptions): BuilderContentAdapter {
  const baseUrl = options.apiUrl.replace(/\/$/, "");
  const fetchImpl = options.fetchImpl ?? fetch;

  async function request<T>(path: string, init?: RequestInit): Promise<T> {
    const response = await fetchImpl(`${baseUrl}${path}`, {
      ...init,
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${options.siteToken}`,
        ...(init?.headers ?? {}),
      },
    });

    if (!response.ok) {
      throw new Error(`Builder API request failed: ${response.status} ${response.statusText}`);
    }

    return (await response.json()) as T;
  }

  return {
    getPublishedContent: (siteId, path) =>
      request<PageContent>(`/sites/${encodeURIComponent(siteId)}/pages?path=${encodeURIComponent(path)}&mode=published`),
    getDraftContent: (siteId, path) =>
      request<PageContent>(`/sites/${encodeURIComponent(siteId)}/pages?path=${encodeURIComponent(path)}&mode=draft`),
    saveDraft: (input) =>
      request<VersionRecord>(`/sites/${encodeURIComponent(input.siteId)}/drafts`, {
        method: "POST",
        body: JSON.stringify(input),
      }),
    publishVersion: (input) =>
      request<VersionRecord>(`/sites/${encodeURIComponent(input.siteId)}/publish`, {
        method: "POST",
        body: JSON.stringify(input),
      }),
    rollbackToVersion: (input) =>
      request<VersionRecord>(`/sites/${encodeURIComponent(input.siteId)}/rollback`, {
        method: "POST",
        body: JSON.stringify(input),
      }),
    undoRollback: (input) =>
      request<VersionRecord>(`/sites/${encodeURIComponent(input.siteId)}/rollback/undo`, {
        method: "POST",
        body: JSON.stringify(input),
      }),
    listAuditLog: (siteId, path) =>
      request<AuditEvent[]>(
        `/sites/${encodeURIComponent(siteId)}/audit${path ? `?path=${encodeURIComponent(path)}` : ""}`,
      ),
    createMediaAsset: (input) =>
      request<MediaAsset>(`/sites/${encodeURIComponent(input.siteId)}/media`, {
        method: "POST",
        body: JSON.stringify(input),
      }),
    listMediaAssets: (siteId) => request<MediaAsset[]>(`/sites/${encodeURIComponent(siteId)}/media`),
  };
}

export interface SupabaseAdapterOptions {
  url: string;
  serviceKey: string;
  client?: SupabaseClient;
}

interface SupabasePageRow {
  path: string;
  regions: Record<string, EditableValue> | null;
  version_id?: string | null;
  updated_at?: string | null;
}

function toPageContent(row: SupabasePageRow | null, path: string): PageContent {
  return {
    path: row?.path ?? path,
    regions: row?.regions ?? {},
    versionId: row?.version_id ?? undefined,
    updatedAt: row?.updated_at ?? undefined,
  };
}

export function createSupabaseAdapter(options: SupabaseAdapterOptions): BuilderContentAdapter {
  const client = options.client ?? createClient(options.url, options.serviceKey, { auth: { persistSession: false } });

  async function selectPage(table: string, siteId: string, pagePath: string): Promise<PageContent> {
    const { data, error } = await client
      .from(table)
      .select("path, regions, version_id, updated_at")
      .eq("site_id", siteId)
      .eq("path", pagePath)
      .maybeSingle();

    if (error) throw error;
    return toPageContent(data as SupabasePageRow | null, pagePath);
  }

  async function insertVersion(record: Omit<VersionRecord, "id" | "createdAt">): Promise<VersionRecord> {
    const { data, error } = await client
      .from("builder_versions")
      .insert({
        site_id: record.siteId,
        page_path: record.pagePath,
        status: record.status,
        snapshot: record.snapshot,
        user_id: record.userId,
      })
      .select("id, site_id, page_path, status, snapshot, user_id, created_at")
      .single();

    if (error) throw error;
    return {
      id: String(data.id),
      siteId: String(data.site_id),
      pagePath: String(data.page_path),
      status: data.status as VersionStatus,
      snapshot: data.snapshot as PageContent,
      userId: String(data.user_id),
      createdAt: String(data.created_at),
    };
  }

async function insertAudit(event: Omit<AuditEvent, "id" | "createdAt">): Promise<void> {
    const { error } = await client.from("builder_audit_log").insert({
      site_id: event.siteId,
      page_path: event.pagePath,
      action: event.action,
      user_id: event.userId,
      user_label: event.userLabel ?? null,
      summary: event.summary,
      region_id: event.regionId ?? null,
      kind: event.kind ?? null,
      before: event.before ?? null,
      after: event.after ?? null,
      version_id: event.versionId ?? null,
      source_version_id: event.sourceVersionId ?? null,
      result_version_id: event.resultVersionId ?? null,
    });
    if (error) throw error;
  }

  return {
    getPublishedContent: (siteId, path) => selectPage("builder_published_pages", siteId, path),
    getDraftContent: (siteId, path) => selectPage("builder_draft_pages", siteId, path),

    async saveDraft(input) {
      const current = await selectPage("builder_draft_pages", input.siteId, input.pagePath);
      const before = current.regions[input.regionId] ?? null;
      const snapshot: PageContent = {
        path: input.pagePath,
        regions: { ...current.regions, [input.regionId]: input.value },
        updatedAt: new Date().toISOString(),
      };
      const version = await insertVersion({
        siteId: input.siteId,
        pagePath: input.pagePath,
        status: "draft",
        snapshot,
        userId: input.userId,
      });

      const { error } = await client.from("builder_draft_pages").upsert({
        site_id: input.siteId,
        path: input.pagePath,
        regions: snapshot.regions,
        version_id: version.id,
        updated_at: snapshot.updatedAt,
      });
      if (error) throw error;

      await insertAudit({
        siteId: input.siteId,
        pagePath: input.pagePath,
        action: "draft.saved",
        userId: input.userId,
        summary: `Saved draft for ${input.regionId}`,
        regionId: input.regionId,
        kind: input.value.type,
        before,
        after: input.value,
        versionId: version.id,
        resultVersionId: version.id,
      });

      return version;
    },

    async publishVersion(input) {
      const draft = await selectPage("builder_draft_pages", input.siteId, input.pagePath);
      const version = await insertVersion({
        siteId: input.siteId,
        pagePath: input.pagePath,
        status: "published",
        snapshot: draft,
        userId: input.userId,
      });

      const { error } = await client.from("builder_published_pages").upsert({
        site_id: input.siteId,
        path: input.pagePath,
        regions: draft.regions,
        version_id: version.id,
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;

      await insertAudit({
        siteId: input.siteId,
        pagePath: input.pagePath,
        action: "version.published",
        userId: input.userId,
        summary: `Published ${input.pagePath}`,
        versionId: version.id,
        resultVersionId: version.id,
      });

      return version;
    },

    async rollbackToVersion(input) {
      const { data, error } = await client
        .from("builder_versions")
        .select("snapshot")
        .eq("id", input.versionId)
        .eq("site_id", input.siteId)
        .eq("page_path", input.pagePath)
        .single();
      if (error) throw error;

      const snapshot = data.snapshot as PageContent;
      const version = await insertVersion({
        siteId: input.siteId,
        pagePath: input.pagePath,
        status: "rollback",
        snapshot,
        userId: input.userId,
      });

      const { error: upsertError } = await client.from("builder_published_pages").upsert({
        site_id: input.siteId,
        path: input.pagePath,
        regions: snapshot.regions,
        version_id: version.id,
        updated_at: new Date().toISOString(),
      });
      if (upsertError) throw upsertError;

      await insertAudit({
        siteId: input.siteId,
        pagePath: input.pagePath,
        action: "version.rolled_back",
        userId: input.userId,
        summary: `Rolled back ${input.pagePath} to ${input.versionId}`,
        versionId: version.id,
        sourceVersionId: input.versionId,
        resultVersionId: version.id,
      });

      return version;
    },

    async undoRollback(input) {
      const { data: rollback, error: rollbackError } = await client
        .from("builder_versions")
        .select("created_at")
        .eq("id", input.rollbackVersionId)
        .eq("site_id", input.siteId)
        .eq("page_path", input.pagePath)
        .eq("status", "rollback")
        .single();
      if (rollbackError) throw rollbackError;

      const { data: previous, error: previousError } = await client
        .from("builder_versions")
        .select("snapshot")
        .eq("site_id", input.siteId)
        .eq("page_path", input.pagePath)
        .eq("status", "published")
        .lt("created_at", rollback.created_at)
        .order("created_at", { ascending: false })
        .limit(1)
        .single();
      if (previousError) throw previousError;

      const snapshot = previous.snapshot as PageContent;
      const version = await insertVersion({
        siteId: input.siteId,
        pagePath: input.pagePath,
        status: "undoRollback",
        snapshot,
        userId: input.userId,
      });

      const { error: upsertError } = await client.from("builder_published_pages").upsert({
        site_id: input.siteId,
        path: input.pagePath,
        regions: snapshot.regions,
        version_id: version.id,
        updated_at: new Date().toISOString(),
      });
      if (upsertError) throw upsertError;

      await insertAudit({
        siteId: input.siteId,
        pagePath: input.pagePath,
        action: "rollback.undone",
        userId: input.userId,
        summary: `Undid rollback ${input.rollbackVersionId}`,
        versionId: version.id,
        sourceVersionId: input.rollbackVersionId,
        resultVersionId: version.id,
      });

      return version;
    },

    async listAuditLog(siteId, path) {
      let query = client
        .from("builder_audit_log")
        .select("id, site_id, page_path, action, user_id, user_label, created_at, summary, region_id, kind, before, after, version_id, source_version_id, result_version_id")
        .eq("site_id", siteId)
        .order("created_at", { ascending: true });

      if (path) query = query.eq("page_path", path);
      const { data, error } = await query;
      if (error) throw error;

      return data.map((row) => ({
        id: String(row.id),
        siteId: String(row.site_id),
        pagePath: String(row.page_path),
        action: row.action as AuditAction,
        userId: String(row.user_id),
        userLabel: row.user_label ? String(row.user_label) : undefined,
        createdAt: String(row.created_at),
        summary: String(row.summary),
        regionId: row.region_id ? String(row.region_id) : undefined,
        kind: row.kind ? (String(row.kind) as EditableKind) : undefined,
        before: row.before as EditableValue | null,
        after: row.after as EditableValue | null,
        versionId: row.version_id ? String(row.version_id) : undefined,
        sourceVersionId: row.source_version_id ? String(row.source_version_id) : undefined,
        resultVersionId: row.result_version_id ? String(row.result_version_id) : undefined,
      }));
    },

    async createMediaAsset(input) {
      const { data, error } = await client
        .from("builder_media_assets")
        .insert({
          site_id: input.siteId,
          path: input.path,
          url: input.url,
          alt: input.alt,
          label: input.label,
          mime_type: input.mimeType,
          source: input.source ?? "upload",
          width: input.width ?? null,
          height: input.height ?? null,
          user_id: input.userId,
        })
        .select("id, site_id, path, url, alt, label, mime_type, source, width, height, user_id, created_at")
        .single();
      if (error) throw error;

      const asset: MediaAsset = {
        id: String(data.id),
        siteId: String(data.site_id),
        path: String(data.path),
        url: String(data.url),
        alt: String(data.alt),
        label: String(data.label),
        mimeType: String(data.mime_type),
        source: data.source as "seed" | "upload",
        width: data.width ? Number(data.width) : undefined,
        height: data.height ? Number(data.height) : undefined,
        userId: String(data.user_id),
        createdAt: String(data.created_at),
      };

      await insertAudit({
        siteId: input.siteId,
        pagePath: "/",
        action: "media.uploaded",
        userId: input.userId,
        summary: `Uploaded ${input.label}`,
      });

      return asset;
    },

    async listMediaAssets(siteId) {
      const { data, error } = await client
        .from("builder_media_assets")
        .select("id, site_id, path, url, alt, label, mime_type, source, width, height, user_id, created_at")
        .eq("site_id", siteId)
        .order("created_at", { ascending: false });
      if (error) throw error;

      return data.map((row) => ({
        id: String(row.id),
        siteId: String(row.site_id),
        path: String(row.path),
        url: String(row.url),
        alt: String(row.alt),
        label: String(row.label),
        mimeType: String(row.mime_type),
        source: row.source as "seed" | "upload",
        width: row.width ? Number(row.width) : undefined,
        height: row.height ? Number(row.height) : undefined,
        userId: String(row.user_id),
        createdAt: String(row.created_at),
      }));
    },
  };
}
