import { parsePostSnapshot, type PublishedPost } from "@your-builder/content";

export interface PublishedPostRow {
  entry_id: string;
  version_id: string;
  slug: string;
  title: string;
  excerpt: string;
  category_keys: string[] | null;
  tag_keys: string[] | null;
  display_date: string;
  version_published_at: string;
  expires_at: string | null;
  featured: boolean | null;
  pinned: boolean | null;
  snapshot?: unknown;
}

export function mapPublishedPostRow(row: PublishedPostRow): PublishedPost {
  const snapshot = row.snapshot === undefined ? undefined : parsePostSnapshot(row.snapshot);
  return {
    entryId: row.entry_id,
    versionId: row.version_id,
    slug: row.slug,
    title: row.title,
    excerpt: row.excerpt,
    categoryKeys: row.category_keys ?? [],
    tagKeys: row.tag_keys ?? [],
    displayDate: row.display_date,
    versionPublishedAt: row.version_published_at,
    expiresAt: row.expires_at,
    featured: row.featured ?? false,
    pinned: row.pinned ?? false,
    snapshot,
  };
}
