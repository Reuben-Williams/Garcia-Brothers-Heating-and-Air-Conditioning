import {
  ContentConflictError,
  ContentPermissionError,
  ContentScheduleError,
  ContentSchemaError,
  IdempotencyConflictError,
  SlugConflictError,
} from "@your-builder/content";

export interface SupabaseErrorLike {
  code?: string;
  message: string;
  details?: string;
}

export function mapSupabaseContentError(error: SupabaseErrorLike): Error {
  const message = error.message || "Supabase content operation failed.";
  if (error.code === "40001") return new ContentConflictError(message);
  if (error.code === "42501") return new ContentPermissionError(message);
  if (error.code === "22023") {
    return /schedule|publishat|future/i.test(message)
      ? new ContentScheduleError(message)
      : new ContentSchemaError(message);
  }
  if (error.code === "23505") {
    return /idempotency/i.test(message)
      ? new IdempotencyConflictError(message)
      : new SlugConflictError(message);
  }
  return new Error(message);
}

