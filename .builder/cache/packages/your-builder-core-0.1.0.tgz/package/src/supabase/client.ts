import { createClient, type SupabaseClient } from "@supabase/supabase-js";

export interface SupabaseServerClientOptions {
  url: string;
  serviceRoleKey: string;
}

export function createBuilderSupabaseServerClient(options: SupabaseServerClientOptions): SupabaseClient {
  if (!options.url || !options.serviceRoleKey) {
    throw new Error("Supabase URL and server-only service role key are required.");
  }
  return createClient(options.url, options.serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });
}

