import {
  filterAndSortPublishedPosts,
  type PostCollectionQuery,
  type PublishedPost,
} from "@your-builder/content";
import type { SupabaseClient } from "@supabase/supabase-js";
import { mapPublishedPostRow, type PublishedPostRow } from "./content-mappers.js";
import { mapSupabaseContentError, type SupabaseErrorLike } from "./errors.js";

export type PostTransitionOperation =
  | "save_draft"
  | "publish"
  | "schedule"
  | "cancel_schedule"
  | "reschedule"
  | "archive"
  | "restore_draft"
  | "rollback"
  | "undo_rollback";

export interface SupabaseContentRepository {
  resolveSiteId(siteKey: string): Promise<string>;
  listPublishedPosts(siteKey: string, query: PostCollectionQuery): Promise<PublishedPost[]>;
  getPublishedPostBySlug(siteKey: string, slug: string): Promise<PublishedPost | null>;
  transition(
    siteKey: string,
    operation: PostTransitionOperation,
    payload: Record<string, unknown>,
    idempotencyKey: string,
  ): Promise<Record<string, unknown>>;
}

export interface SupabasePublicPostReader {
  listPublishedPosts(siteKey: string, query: PostCollectionQuery): Promise<PublishedPost[]>;
  getPublishedPostBySlug(siteKey: string, slug: string): Promise<PublishedPost | null>;
}

export interface SupabasePublicRpcClient {
  rpc(
    functionName: string,
    parameters: Record<string, unknown>,
  ): PromiseLike<{ data: unknown; error: SupabaseErrorLike | null }>;
}

export function createSupabasePublicPostReader(
  client: SupabasePublicRpcClient,
): SupabasePublicPostReader {
  return {
    async listPublishedPosts(siteKey, query) {
      const { data, error } = await client.rpc("builder_list_public_posts", {
        p_site_key: siteKey,
      });
      if (error) throw mapSupabaseContentError(error);
      const posts = ((data ?? []) as unknown as PublishedPostRow[]).map(mapPublishedPostRow);
      return filterAndSortPublishedPosts(posts, query);
    },

    async getPublishedPostBySlug(siteKey, slug) {
      const { data, error } = await client.rpc("builder_get_public_post_by_slug", {
        p_site_key: siteKey,
        p_slug: slug,
      });
      if (error) throw mapSupabaseContentError(error);
      const row = Array.isArray(data) ? data[0] : data;
      return row ? mapPublishedPostRow(row as unknown as PublishedPostRow) : null;
    },
  };
}

export function createSupabaseContentRepository(client: SupabaseClient): SupabaseContentRepository {
  async function resolveSiteId(siteKey: string): Promise<string> {
    const { data, error } = await client
      .from("builder_sites")
      .select("id")
      .eq("site_key", siteKey)
      .single();
    if (error) throw mapSupabaseContentError(error);
    if (!data?.id) throw new Error(`Builder site "${siteKey}" was not found.`);
    return String(data.id);
  }

  return {
    resolveSiteId,

    async listPublishedPosts(siteKey, query) {
      const siteId = await resolveSiteId(siteKey);
      let request = client.from("builder_public_posts").select("*").eq("site_id", siteId);
      if (query.categoryKeys.length > 0) request = request.contains("category_keys", query.categoryKeys);
      if (query.tagKeys.length > 0) request = request.contains("tag_keys", query.tagKeys);
      if (query.entryIds.length > 0) request = request.in("entry_id", query.entryIds);
      if (query.featuredOnly) request = request.eq("featured", true);
      if (query.pinnedFirst) request = request.order("pinned", { ascending: false });
      const orderColumn = query.orderBy === "displayDate" ? "display_date" : "version_published_at";
      request = request.order(orderColumn, { ascending: query.orderDirection === "asc" }).limit(query.limit);
      const { data, error } = await request;
      if (error) throw mapSupabaseContentError(error);
      return ((data ?? []) as unknown as PublishedPostRow[]).map(mapPublishedPostRow);
    },

    async getPublishedPostBySlug(siteKey, slug) {
      const siteId = await resolveSiteId(siteKey);
      const { data, error } = await client
        .from("builder_public_posts")
        .select("*")
        .eq("site_id", siteId)
        .eq("slug", slug)
        .maybeSingle();
      if (error) throw mapSupabaseContentError(error);
      return data ? mapPublishedPostRow(data as unknown as PublishedPostRow) : null;
    },

    async transition(siteKey, operation, payload, idempotencyKey) {
      if ("siteId" in payload || "siteKey" in payload || "tenantId" in payload) {
        throw new TypeError("Tenant identity must come from the server request context.");
      }
      const { data, error } = await client.rpc("builder_transition_post", {
        p_site_key: siteKey,
        p_operation: operation,
        p_payload: payload,
        p_idempotency_key: idempotencyKey,
      });
      if (error) throw mapSupabaseContentError(error);
      return (data ?? {}) as Record<string, unknown>;
    },
  };
}
