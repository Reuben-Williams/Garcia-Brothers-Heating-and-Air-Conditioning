import { describe, expect, expectTypeOf, it } from "vitest";
import {
  APPROVED_GROWTH_INVITATION_TEMPLATES,
  type AcceptMemberInvitationCommand,
  type CreateMemberInvitationCommand,
  type MemberInvitationOwnerView,
  type RevokeMemberInvitationCommand,
} from "../src/index.js";

describe("member invitation contracts", () => {
  it("limits invitations to approved versioned templates", () => {
    expect(APPROVED_GROWTH_INVITATION_TEMPLATES).toEqual([
      "growth_manager_v1",
      "growth_staff_v1",
      "growth_read_only_v1",
    ]);
  });

  it("keeps command context explicit", () => {
    expectTypeOf<CreateMemberInvitationCommand>().toMatchTypeOf<{
      siteId: string;
      actorId: string;
      email: string;
      templateId: "growth_manager_v1" | "growth_staff_v1" | "growth_read_only_v1";
      templateVersion: number;
      expiresAt: string;
      idempotencyKey: string;
      aal2VerifiedAt: string;
    }>();
    expectTypeOf<RevokeMemberInvitationCommand>().toMatchTypeOf<{ expectedVersion: number }>();
    expectTypeOf<AcceptMemberInvitationCommand>().toMatchTypeOf<{
      invitationToken: string;
      authenticatedEmail: string;
    }>();
  });

  it("exposes only safe owner-visible metadata", () => {
    const view: MemberInvitationOwnerView = {
      id: "invitation-1",
      siteId: "site-1",
      emailHint: "a***@example.com",
      templateId: "growth_staff_v1",
      templateVersion: 1,
      status: "pending",
      invitedBy: "owner-1",
      expiresAt: "2026-07-19T12:00:00.000Z",
      createdAt: "2026-07-18T12:00:00.000Z",
      version: 1,
    };

    expect(view).not.toHaveProperty("token");
    expect(view).not.toHaveProperty("tokenHash");
    expect(view).not.toHaveProperty("canonicalEmailDigest");
  });
});
