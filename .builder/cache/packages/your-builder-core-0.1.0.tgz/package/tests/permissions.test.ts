import { describe, expect, it } from "vitest";
import {
  GROWTH_CAPABILITIES,
  GROWTH_PERMISSION_TEMPLATES,
  WEBSITE_CAPABILITIES,
  allowedCapabilityScopes,
  canBuilderRole,
  capabilitiesForRole,
} from "@your-builder/core";

const expectedWebsiteCapabilities = [
  "members.manage", "preview.read", "history.read", "post.create", "post.editDraft",
  "post.publish", "post.schedule", "post.archive", "post.rollback", "media.upload",
] as const;

const expectedGrowthCapabilities = [
  "dashboard.read", "leads.read", "leads.create", "leads.update", "leads.assign", "leads.export",
  "customers.read", "customers.update", "customers.export", "customers.deleteRequest",
  "tasks.read", "tasks.manage", "messages.read", "messages.draft", "messages.send",
  "templates.manage", "reviews.manage", "automations.read", "automations.manage",
  "automations.approve", "projects.read", "projects.manage", "integrations.manage",
  "members.manage", "billing.manage", "siteHealth.read", "emergencyPause.manage",
] as const;

const expectedRows = (scope: "site" | "assigned", capabilities: readonly string[]) =>
  capabilities.map((capability) => ({ capability, scope }));

describe("builder role capabilities", () => {
  it("allows editors to publish while contributors can only edit drafts", () => {
    expect(canBuilderRole("editor", "post.publish")).toBe(true);
    expect(canBuilderRole("contributor", "post.editDraft")).toBe(true);
    expect(canBuilderRole("contributor", "post.publish")).toBe(false);
  });

  it("keeps viewers read-only and owners able to manage members", () => {
    expect(capabilitiesForRole("viewer")).toEqual(expect.arrayContaining(["preview.read", "history.read"]));
    expect(canBuilderRole("viewer", "post.editDraft")).toBe(false);
    expect(canBuilderRole("owner", "members.manage")).toBe(true);
  });

  it("keeps non-owner role migration growth-neutral", () => {
    for (const role of ["editor", "contributor", "viewer"] as const) {
      expect(capabilitiesForRole(role).filter((value) => GROWTH_CAPABILITIES.includes(value as never))).toEqual([]);
    }
  });

  it("freezes the staff bundle and assigned scopes", () => {
    expect(GROWTH_PERMISSION_TEMPLATES.growth_staff_v1).toContainEqual({ capability: "leads.read", scope: "assigned" });
    expect(allowedCapabilityScopes("leads.create")).toEqual(["site"]);
    expect(allowedCapabilityScopes("messages.send")).toEqual(["site", "assigned"]);
  });

  it("freezes the exact ordered capability and role contracts", () => {
    expect(WEBSITE_CAPABILITIES).toEqual(expectedWebsiteCapabilities);
    expect(GROWTH_CAPABILITIES).toEqual(expectedGrowthCapabilities);
    expect(capabilitiesForRole("editor")).toEqual([
      "preview.read",
      "history.read",
      "post.create",
      "post.editDraft",
      "post.publish",
      "post.schedule",
      "post.archive",
      "post.rollback",
      "media.upload",
    ]);
    expect(capabilitiesForRole("contributor")).toEqual([
      "preview.read",
      "history.read",
      "post.create",
      "post.editDraft",
      "media.upload",
    ]);
    expect(capabilitiesForRole("viewer")).toEqual(["preview.read", "history.read"]);
    expect(capabilitiesForRole("owner")).toEqual(
      Array.from(new Set([...expectedWebsiteCapabilities, ...expectedGrowthCapabilities])),
    );
  });

  it("freezes the complete ordered permission templates", () => {
    expect(GROWTH_PERMISSION_TEMPLATES.growth_manager_v1).toEqual(expectedRows("site", [
      "dashboard.read", "leads.read", "leads.create", "leads.update", "leads.assign", "leads.export",
      "customers.read", "customers.update", "customers.export", "tasks.read", "tasks.manage",
      "messages.read", "messages.draft", "messages.send", "templates.manage", "reviews.manage",
      "automations.read", "automations.manage", "automations.approve", "projects.read", "projects.manage",
      "siteHealth.read", "emergencyPause.manage",
    ]));
    expect(GROWTH_PERMISSION_TEMPLATES.growth_staff_v1).toEqual([
      ...expectedRows("site", ["dashboard.read", "leads.create"]),
      ...expectedRows("assigned", [
        "leads.read", "leads.update", "customers.read", "customers.update", "tasks.read", "tasks.manage",
        "messages.read", "messages.draft", "messages.send", "projects.read",
      ]),
    ]);
    expect(GROWTH_PERMISSION_TEMPLATES.growth_read_only_v1).toEqual(expectedRows("site", [
      "dashboard.read", "leads.read", "customers.read", "tasks.read", "messages.read",
      "automations.read", "projects.read", "siteHealth.read",
    ]));
  });

  it("returns every approved scope and fails closed for invalid runtime input", () => {
    const assignedCapable = new Set([
      "leads.read", "leads.update", "customers.read", "customers.update", "tasks.read", "tasks.manage",
      "messages.read", "messages.draft", "messages.send", "projects.read", "projects.manage",
    ]);

    for (const capability of GROWTH_CAPABILITIES) {
      expect(allowedCapabilityScopes(capability)).toEqual(
        assignedCapable.has(capability) ? ["site", "assigned"] : ["site"],
      );
    }

    expect(allowedCapabilityScopes("unknown.capability" as never)).toEqual([]);
    expect(allowedCapabilityScopes("preview.read" as never)).toEqual([]);
  });

  it("freezes registries, templates, rows, and shared scope results", () => {
    expect(Object.isFrozen(WEBSITE_CAPABILITIES)).toBe(true);
    expect(Object.isFrozen(GROWTH_CAPABILITIES)).toBe(true);
    expect(Object.isFrozen(GROWTH_PERMISSION_TEMPLATES)).toBe(true);

    for (const template of Object.values(GROWTH_PERMISSION_TEMPLATES)) {
      expect(Object.isFrozen(template)).toBe(true);
      for (const row of template) expect(Object.isFrozen(row)).toBe(true);
    }

    const siteScopes = allowedCapabilityScopes("dashboard.read");
    const assignedScopes = allowedCapabilityScopes("leads.read");
    const emptyScopes = allowedCapabilityScopes("unknown.capability" as never);
    expect(siteScopes).toBe(allowedCapabilityScopes("leads.create"));
    expect(assignedScopes).toBe(allowedCapabilityScopes("messages.send"));
    expect(emptyScopes).toBe(allowedCapabilityScopes("preview.read" as never));
    expect(Object.isFrozen(siteScopes)).toBe(true);
    expect(Object.isFrozen(assignedScopes)).toBe(true);
    expect(Object.isFrozen(emptyScopes)).toBe(true);
  });

  it("rejects attempted mutation of frozen contracts", () => {
    expect(Reflect.set(WEBSITE_CAPABILITIES, 0, "changed")).toBe(false);
    expect(Reflect.set(GROWTH_PERMISSION_TEMPLATES, "growth_staff_v1", [])).toBe(false);
    expect(Reflect.set(GROWTH_PERMISSION_TEMPLATES.growth_staff_v1[0], "scope", "assigned")).toBe(false);
    expect(Reflect.set(allowedCapabilityScopes("messages.send"), 0, "changed")).toBe(false);

    expect(WEBSITE_CAPABILITIES).toEqual(expectedWebsiteCapabilities);
    expect(GROWTH_PERMISSION_TEMPLATES.growth_staff_v1[0]).toEqual({ capability: "dashboard.read", scope: "site" });
    expect(allowedCapabilityScopes("messages.send")).toEqual(["site", "assigned"]);
  });
});
