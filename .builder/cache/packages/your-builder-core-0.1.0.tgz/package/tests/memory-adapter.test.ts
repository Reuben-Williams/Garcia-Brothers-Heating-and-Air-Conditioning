import { describe, expect, it } from "vitest";
import {
  BUILDER_PREVIEW_PROTOCOL,
  BUILDER_PREVIEW_PROTOCOL_VERSION,
  createContentEntry,
  createBuilderPreviewMessage,
  createInMemoryAdapter,
  createRedirectSuggestion,
  createRewriteRequest,
  createSubmissionStatusChange,
  defineBuilderSite,
  normalizeRegionDefinitions,
  readRegionValue,
  validateBuilderSite,
  validateBrandProfile,
  isBuilderPreviewMessage,
} from "@your-builder/core";

describe("preview protocol", () => {
  it("creates and validates site-scoped versioned preview messages", () => {
    const message = createBuilderPreviewMessage("demo-site", {
      type: "builder:select-region",
      pagePath: "/about",
      regionId: "about.hero.title",
      kind: "text",
    });

    expect(message).toEqual({
      protocol: BUILDER_PREVIEW_PROTOCOL,
      version: BUILDER_PREVIEW_PROTOCOL_VERSION,
      siteId: "demo-site",
      type: "builder:select-region",
      pagePath: "/about",
      regionId: "about.hero.title",
      kind: "text",
    });
    expect(isBuilderPreviewMessage(message, "demo-site")).toBe(true);
    expect(isBuilderPreviewMessage(message, "other-site")).toBe(false);
    expect(isBuilderPreviewMessage({ ...message, version: 999 }, "demo-site")).toBe(false);
  });
});

describe("core content model", () => {
  it("reads published region values and falls back when content is missing", async () => {
    const adapter = createInMemoryAdapter();

    await adapter.saveDraft({
      siteId: "demo-site",
      pagePath: "/",
      regionId: "home.hero.title",
      value: { type: "text", value: "Edited headline" },
      userId: "owner-1",
    });
    await adapter.publishVersion({
      siteId: "demo-site",
      pagePath: "/",
      userId: "owner-1",
    });

    const page = await adapter.getPublishedContent("demo-site", "/");

    expect(readRegionValue(page, "home.hero.title", "Fallback headline")).toBe("Edited headline");
    expect(readRegionValue(page, "home.hero.kicker", "Fallback kicker")).toBe("Fallback kicker");
  });

  it("creates audit records for draft, publish, and rollback events", async () => {
    const adapter = createInMemoryAdapter();

    const firstDraft = await adapter.saveDraft({
      siteId: "demo-site",
      pagePath: "/",
      regionId: "home.hero.title",
      value: { type: "text", value: "Version one" },
      userId: "owner-1",
    });
    await adapter.publishVersion({ siteId: "demo-site", pagePath: "/", userId: "owner-1" });
    await adapter.saveDraft({
      siteId: "demo-site",
      pagePath: "/",
      regionId: "home.hero.title",
      value: { type: "text", value: "Version two" },
      userId: "owner-1",
    });
    await adapter.publishVersion({ siteId: "demo-site", pagePath: "/", userId: "owner-1" });
    await adapter.rollbackToVersion({
      siteId: "demo-site",
      pagePath: "/",
      versionId: firstDraft.id,
      userId: "owner-1",
    });

    const page = await adapter.getPublishedContent("demo-site", "/");
    const audit = await adapter.listAuditLog("demo-site", "/");

    expect(readRegionValue(page, "home.hero.title", "")).toBe("Version one");
    expect(audit.map((event) => event.action)).toEqual([
      "draft.saved",
      "version.published",
      "draft.saved",
      "version.published",
      "version.rolled_back",
    ]);
  });

  it("validates attachable site configuration before a project ships", () => {
    const site = defineBuilderSite({
      siteId: "demo-site",
      adapter: "central",
      pages: [
        {
          path: "/",
          label: "Home",
          regions: [
            { id: "home.hero.title", kind: "text", label: "Hero title" },
            { id: "home.sections", kind: "sections", label: "Home sections" },
          ],
        },
        { path: "/about", label: "About", regions: [{ id: "about.hero.title", kind: "text", label: "About title" }] },
      ],
      sections: {
        hero: () => null,
      },
    });

    expect(validateBuilderSite(site)).toEqual({ ok: true, issues: [] });
    expect(
      validateBuilderSite({
        ...site,
        pages: [
          { path: "missing-slash", label: "Broken", regions: [{ id: "home.hero.title", kind: "text" }] },
          { path: "/", label: "Duplicate", regions: [{ id: "home.hero.title", kind: "image" }] },
        ],
      }).issues,
    ).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ code: "page.path.invalid" }),
        expect.objectContaining({ code: "region.id.duplicate" }),
        expect.objectContaining({ code: "region.kind.conflict" }),
      ]),
    );
  });

  it("normalizes typed region definitions while preserving legacy string regions", () => {
    const regions = normalizeRegionDefinitions([
      "home.legacy.title",
      { id: "home.hero.image", kind: "image", label: "Hero image", required: true },
    ]);

    expect(regions).toEqual([
      { id: "home.legacy.title", kind: "text", label: "home.legacy.title", required: false },
      { id: "home.hero.image", kind: "image", label: "Hero image", required: true },
    ]);
  });

  it("treats icons as first-class editable regions with fallback-safe reads", async () => {
    const site = defineBuilderSite({
      siteId: "demo-site",
      adapter: "memory",
      editor: { path: "/admin/editor", protected: true },
      pages: [
        {
          path: "/",
          label: "Home",
          regions: [{ id: "home.services.card.icon", kind: "icon", label: "Service card icon" }],
        },
      ],
      sections: {},
    });
    const adapter = createInMemoryAdapter();

    await adapter.saveDraft({
      siteId: site.siteId,
      pagePath: "/",
      regionId: "home.services.card.icon",
      value: { type: "icon", icon: "mail", label: "Email" },
      userId: "owner-1",
    });
    await adapter.publishVersion({ siteId: site.siteId, pagePath: "/", userId: "owner-1" });

    const page = await adapter.getPublishedContent(site.siteId, "/");
    const audit = await adapter.listAuditLog(site.siteId, "/");

    expect(validateBuilderSite(site)).toEqual({ ok: true, issues: [] });
    expect(readRegionValue(page, "home.services.card.icon", "work")).toBe("mail");
    expect(audit[0]).toEqual(
      expect.objectContaining({
        kind: "icon",
        after: { type: "icon", icon: "mail", label: "Email" },
      }),
    );
  });

  it("logs image changes, media uploads, rollbacks, and undo rollback with before and after values", async () => {
    const adapter = createInMemoryAdapter();

    const media = await adapter.createMediaAsset({
      siteId: "demo-site",
      userId: "owner-1",
      path: "campaign/hero.jpg",
      url: "https://cdn.example/hero.jpg",
      alt: "Campaign hero",
      label: "Campaign hero",
      mimeType: "image/jpeg",
      width: 1200,
      height: 800,
    });

    await adapter.saveDraft({
      siteId: "demo-site",
      pagePath: "/",
      regionId: "home.hero.image",
      value: { type: "image", src: media.url, alt: media.alt, mediaId: media.id },
      userId: "owner-1",
    });
    const published = await adapter.publishVersion({ siteId: "demo-site", pagePath: "/", userId: "owner-1" });
    await adapter.saveDraft({
      siteId: "demo-site",
      pagePath: "/",
      regionId: "home.hero.image",
      value: { type: "image", src: "https://cdn.example/second.jpg", alt: "Second image" },
      userId: "owner-1",
    });
    await adapter.publishVersion({ siteId: "demo-site", pagePath: "/", userId: "owner-1" });
    const rollback = await adapter.rollbackToVersion({
      siteId: "demo-site",
      pagePath: "/",
      versionId: published.id,
      userId: "owner-1",
    });
    await adapter.undoRollback({
      siteId: "demo-site",
      pagePath: "/",
      rollbackVersionId: rollback.id,
      userId: "owner-1",
    });

    const audit = await adapter.listAuditLog("demo-site", "/");
    const assets = await adapter.listMediaAssets("demo-site");

    expect(assets).toEqual([media]);
    expect(audit.map((event) => event.action)).toEqual([
      "media.uploaded",
      "draft.saved",
      "version.published",
      "draft.saved",
      "version.published",
      "version.rolled_back",
      "rollback.undone",
    ]);
    expect(audit.find((event) => event.regionId === "home.hero.image")).toEqual(
      expect.objectContaining({
        kind: "image",
        after: expect.objectContaining({ type: "image", src: "https://cdn.example/hero.jpg" }),
      }),
    );
  });
});

describe("platform feature contracts", () => {
  it("creates content entries with durable status and slug fields", () => {
    const entry = createContentEntry({
      siteId: "demo-site",
      type: "service",
      slug: "housing-help",
      title: "Housing Help",
      status: "draft",
      fields: { summary: "Support for tenants." },
    });

    expect(entry.id).toBe("service:housing-help");
    expect(entry.status).toBe("draft");
    expect(entry.fields.summary).toBe("Support for tenants.");
  });

  it("validates brand profiles used by constrained AI rewrite requests", () => {
    const result = validateBrandProfile({
      siteId: "demo-site",
      businessFacts: {
        businessName: "Morales Office",
        services: ["Housing", "Benefits"],
        preferredCtas: ["Contact us"],
      },
      voice: {
        tone: "Plainspoken, civic, and practical",
        bannedClaims: ["guaranteed approval"],
      },
    });

    expect(result.ok).toBe(true);

    const request = createRewriteRequest({
      siteId: "demo-site",
      pagePath: "/",
      regionId: "home.hero.title",
      kind: "text",
      currentValue: "We help residents",
      instruction: "Make this warmer",
      brandProfile: result.profile,
    });

    expect(request.scope).toBe("selected-field");
    expect(request.regionId).toBe("home.hero.title");
    expect(request.brandProfile.businessFacts.businessName).toBe("Morales Office");
  });

  it("suggests redirects for slug changes and records form lead status transitions", () => {
    const redirect = createRedirectSuggestion({
      siteId: "demo-site",
      sourceSlug: "old-service",
      targetSlug: "new-service",
      contentType: "service",
    });

    expect(redirect.fromPath).toBe("/service/old-service");
    expect(redirect.toPath).toBe("/service/new-service");
    expect(redirect.status).toBe("pending-review");

    const statusChange = createSubmissionStatusChange({
      submissionId: "lead-1",
      from: "new",
      to: "contacted",
      actorId: "owner-1",
      note: "Called and left voicemail.",
    });

    expect(statusChange.to).toBe("contacted");
    expect(statusChange.note).toContain("voicemail");
  });
});
