import { describe, expect, it } from "vitest";
import {
  BASE_FORM_SUBMISSION_EVENT_KINDS,
  createBaseFormSubmissionResult,
  validateBaseFormPayloadMetadata,
  type BaseFormConsentEvidence,
  type BaseFormSubmission,
} from "../src/index.js";

describe("base form submission contracts", () => {
  it("keeps immutable intake separate from lead workflow state", () => {
    const submission: BaseFormSubmission = {
      id: "submission-1",
      siteId: "site-1",
      formId: "contact",
      sourcePage: "/contact",
      payload: { firstName: "Ada", message: "Needs service" },
      payloadByteLength: 45,
      fieldCount: 2,
      capturedAt: "2026-07-18T12:00:00.000Z",
      createdAt: "2026-07-18T12:00:00.000Z",
    };

    expect(submission).not.toHaveProperty("status");
    expect(submission).not.toHaveProperty("assignedTo");
    expect(submission).not.toHaveProperty("leadStatus");
    expect(Object.keys(submission.payload)).toEqual(["firstName", "message"]);
  });

  it("freezes immutable consent evidence and append-only event vocabulary", () => {
    const evidence: BaseFormConsentEvidence = {
      id: "consent-1",
      siteId: "site-1",
      submissionId: "submission-1",
      policyVersion: "privacy-2026-01",
      purpose: "service_inquiry",
      languageDigest: "sha256:language",
      source: "public_form",
      capturedAt: "2026-07-18T12:00:00.000Z",
      createdAt: "2026-07-18T12:00:00.000Z",
    };

    expect(evidence.policyVersion).toBe("privacy-2026-01");
    expect(BASE_FORM_SUBMISSION_EVENT_KINDS).toEqual(["spam", "restore", "review", "correction"]);
  });

  it("accepts bounded metadata and rejects invalid bounds", () => {
    expect(validateBaseFormPayloadMetadata({ payloadByteLength: 65_536, fieldCount: 64 })).toEqual({ ok: true });
    expect(validateBaseFormPayloadMetadata({ payloadByteLength: 65_537, fieldCount: 1 })).toEqual({
      ok: false,
      code: "payload_too_large",
    });
    expect(validateBaseFormPayloadMetadata({ payloadByteLength: 10, fieldCount: 65 })).toEqual({
      ok: false,
      code: "too_many_fields",
    });
  });

  it("creates positive append-only result versions", () => {
    const result = createBaseFormSubmissionResult({
      id: "result-2",
      siteId: "site-1",
      submissionId: "submission-1",
      version: 2,
      priorResultId: "result-1",
      outcome: "enhanced",
      safeCode: "enhanced",
      contactId: "contact-1",
      leadId: "lead-1",
      createdAt: "2026-07-18T12:05:00.000Z",
    });

    expect(result.version).toBe(2);
    expect(result.priorResultId).toBe("result-1");
    expect(() => createBaseFormSubmissionResult({ ...result, version: 0 })).toThrow("positive integer");
  });

  it("never permits identity-conflict results to disclose record links", () => {
    expect(() =>
      Reflect.apply(createBaseFormSubmissionResult, undefined, [{
        id: "result-1",
        siteId: "site-1",
        submissionId: "submission-1",
        version: 1,
        outcome: "review_required",
        safeCode: "identity_conflict",
        contactId: "contact-secret",
        createdAt: "2026-07-18T12:00:00.000Z",
      }]),
    ).toThrow("must not link");
  });
});
