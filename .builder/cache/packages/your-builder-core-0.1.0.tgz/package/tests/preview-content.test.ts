import { describe, expect, it } from "vitest";
import {
  createBuilderPreviewMessage,
  isBuilderPreviewMessage,
  type ImmutableMediaRevision,
} from "@your-builder/core";

describe("content preview protocol", () => {
  it("selects a stable post entry and opens the posts workspace", () => {
    const selected = createBuilderPreviewMessage("assembly", {
      type: "builder:select-entry",
      pagePath: "/",
      entryId: crypto.randomUUID(),
      contentType: "post",
      regionId: "home.announcements",
      anchor: { x: 120, y: 240 },
    });
    const workspace = createBuilderPreviewMessage("assembly", {
      type: "builder:open-workspace",
      pagePath: "/",
      workspace: "posts",
      entryId: selected.entryId,
    });

    expect(isBuilderPreviewMessage(selected, "assembly")).toBe(true);
    expect(selected.anchor).toEqual({ x: 120, y: 240 });
    expect(isBuilderPreviewMessage({ ...selected, anchor: { x: "120", y: 240 } }, "assembly")).toBe(false);
    expect(isBuilderPreviewMessage(workspace, "assembly")).toBe(true);
  });

  it("models immutable media revisions without exposing storage credentials", () => {
    const revision: ImmutableMediaRevision = {
      siteId: crypto.randomUUID(),
      mediaId: crypto.randomUUID(),
      revisionId: crypto.randomUUID(),
      objectKey: "site/media/revision/original.jpg",
      mimeType: "image/jpeg",
      byteSize: 1234,
      width: 800,
      height: 600,
      createdAt: "2026-07-14T12:00:00.000Z",
    };
    expect(revision.revisionId).not.toBe(revision.mediaId);
  });
});
