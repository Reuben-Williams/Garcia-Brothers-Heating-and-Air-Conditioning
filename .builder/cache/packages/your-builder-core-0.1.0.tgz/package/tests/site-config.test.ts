import { describe, expect, it } from "vitest";
import {
  defineBuilderSite,
  normalizeRegionDefinitions,
  validateBuilderSite,
  type BuilderSiteConfig,
} from "@your-builder/core";

function site(): BuilderSiteConfig {
  return defineBuilderSite({
    siteId: "assembly",
    adapter: "memory" as const,
    content: {
      post: {
        route: "/news/[slug]",
        sourceScopes: [
          { key: "announcements-v1", contentSource: "fallback" as const, entryIds: [crypto.randomUUID()] },
        ],
        categories: ["notice", "infrastructure"],
        tags: ["route-9"],
      },
    },
    pages: [
      {
        path: "/",
        label: "Home",
        regions: [
          {
            id: "home.announcements",
            kind: "postCollection" as const,
            sourceScopeKey: "announcements-v1",
            query: {
              categoryKeys: ["notice"],
              limit: 4,
              orderBy: "displayDate" as const,
              orderDirection: "desc" as const,
            },
          },
        ],
      },
    ],
    sections: {},
  });
}

describe("post-aware site config", () => {
  it("supports one canonical set of global regions outside page definitions", () => {
    const config = site();
    config.globalRegions = [
      { id: "global.navigation.primary", kind: "sections", label: "Primary navigation" },
      { id: "global.business.phone", kind: "link", label: "Business phone" },
    ];

    expect(validateBuilderSite(config)).toEqual({ ok: true, issues: [] });
  });

  it("rejects a page region that conflicts with a canonical global region", () => {
    const config = site();
    config.globalRegions = [{ id: "global.business.phone", kind: "link" }];
    config.pages[0].regions.push({ id: "global.business.phone", kind: "text" });

    expect(validateBuilderSite(config).issues.map((issue) => issue.code)).toEqual(
      expect.arrayContaining(["region.id.duplicate", "region.kind.conflict"]),
    );
  });

  it("preserves post collection metadata while normalizing regions", () => {
    const config = site();
    const [region] = normalizeRegionDefinitions(config.pages[0].regions);
    expect(region).toMatchObject({ kind: "postCollection", sourceScopeKey: "announcements-v1" });
    expect(validateBuilderSite(config)).toEqual({ ok: true, issues: [] });
  });

  it("rejects duplicate scope membership and unknown taxonomy keys", () => {
    const config = site();
    const entryId = config.content!.post.sourceScopes[0].entryIds[0];
    config.content!.post.sourceScopes.push({ key: "other", contentSource: "live", entryIds: [entryId] });
    config.pages[0].regions[0] = {
      ...config.pages[0].regions[0] as object,
      id: "home.announcements",
      kind: "postCollection",
      sourceScopeKey: "announcements-v1",
      query: { categoryKeys: ["unknown"], limit: 4, orderBy: "displayDate", orderDirection: "desc" },
    };

    const result = validateBuilderSite(config);
    expect(result.issues.map((issue) => issue.code)).toEqual(
      expect.arrayContaining(["content.scope.entry.duplicate", "content.taxonomy.unknown"]),
    );
  });

  it("rejects invalid detail routes and missing source scopes", () => {
    const config = site();
    config.content!.post.route = "news";
    (config.pages[0].regions[0] as { sourceScopeKey?: string }).sourceScopeKey = "missing";
    const result = validateBuilderSite(config);
    expect(result.issues.map((issue) => issue.code)).toEqual(
      expect.arrayContaining(["content.post.route.invalid", "content.scope.unknown"]),
    );
  });
});
