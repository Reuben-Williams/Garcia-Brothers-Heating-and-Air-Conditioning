import { describe, expect, expectTypeOf, it, vi } from "vitest";
import {
  GROWTH_PERMISSION_TEMPLATES,
  MemberInvitationServiceError,
  createMemberInvitationService,
  type MemberInvitationAuthorization,
  type MemberInvitationDispatchCommand,
  type MemberInvitationRepository,
  type MemberInvitationRepositoryCreateCommand,
} from "../src/index.js";

const NOW = "2026-07-18T12:00:00.000Z";
const RECENT_AAL2 = "2026-07-18T11:55:00.000Z";
const RAW_TOKEN = "raw-invitation-token";
const TOKEN_HASH = "a".repeat(64);
const EMAIL_DIGEST = "b".repeat(64);

const ownerView = {
  id: "invitation-1",
  siteId: "site-1",
  emailHint: "s***@example.com",
  templateId: "growth_staff_v1" as const,
  templateVersion: 1,
  status: "pending" as const,
  invitedBy: "owner-1",
  expiresAt: "2026-07-19T12:00:00.000Z",
  createdAt: NOW,
  version: 1,
};

const allowedAuthorization: MemberInvitationAuthorization = {
  active: true,
  owner: true,
  capabilities: ["members.manage"],
  aal2VerifiedAt: RECENT_AAL2,
};

describe("member invitation service", () => {
  it("canonicalizes and hashes invitation secrets before an authoritative create", async () => {
    const dependencies = createDependencies();
    const service = createMemberInvitationService(dependencies, { now: () => NOW });

    await expect(service.create({
      siteId: "site-1",
      actorId: "owner-1",
      email: "  Staff.Member@Example.COM ",
      templateId: "growth_staff_v1",
      templateVersion: 1,
      expiresAt: ownerView.expiresAt,
      idempotencyKey: "invite-create-1",
      aal2VerifiedAt: RECENT_AAL2,
    })).resolves.toEqual(ownerView);

    expect(dependencies.crypto.issueToken).toHaveBeenCalledWith({
      siteId: "site-1",
      actorId: "owner-1",
      idempotencyKey: "invite-create-1",
    });
    expect(dependencies.crypto.hashToken).toHaveBeenCalledWith(RAW_TOKEN);
    expect(dependencies.crypto.digestCanonicalEmail).toHaveBeenCalledWith("staff.member@example.com");
    expect(dependencies.repository.createAuthoritatively).toHaveBeenCalledWith({
      siteId: "site-1",
      actorId: "owner-1",
      canonicalEmailDigest: EMAIL_DIGEST,
      emailHint: "s***@example.com",
      tokenHash: TOKEN_HASH,
      templateId: "growth_staff_v1",
      templateVersion: 1,
      memberRole: "contributor",
      capabilityGrants: GROWTH_PERMISSION_TEMPLATES.growth_staff_v1,
      expiresAt: ownerView.expiresAt,
      idempotencyKey: "invite-create-1",
      aal2VerifiedAt: RECENT_AAL2,
      createdAt: NOW,
    });
    expect(dependencies.dispatch).toHaveBeenCalledWith({
      siteId: "site-1",
      invitationId: "invitation-1",
      canonicalEmail: "staff.member@example.com",
      invitationToken: RAW_TOKEN,
      expiresAt: ownerView.expiresAt,
      idempotencyKey: "invite-create-1",
    });
    expect(vi.mocked(dependencies.repository.createAuthoritatively).mock.invocationCallOrder[0])
      .toBeLessThan(vi.mocked(dependencies.dispatch).mock.invocationCallOrder[0]!);

    const persisted = vi.mocked(dependencies.repository.createAuthoritatively).mock.calls[0]![0];
    expect(JSON.stringify(persisted)).not.toContain(RAW_TOKEN);
    expect(JSON.stringify(persisted)).not.toContain("staff.member@example.com");
  });

  it.each([
    ["growth_manager_v1", "editor"],
    ["growth_staff_v1", "contributor"],
    ["growth_read_only_v1", "viewer"],
  ] as const)("maps %s to the base %s role while preserving separate grants", async (templateId, memberRole) => {
    const dependencies = createDependencies();
    const service = createMemberInvitationService(dependencies, { now: () => NOW });

    await service.create({
      siteId: "site-1",
      actorId: "owner-1",
      email: "member@example.com",
      templateId,
      templateVersion: 1,
      expiresAt: ownerView.expiresAt,
      idempotencyKey: `create-${templateId}`,
      aal2VerifiedAt: RECENT_AAL2,
    });

    expect(dependencies.repository.createAuthoritatively).toHaveBeenCalledWith(expect.objectContaining({
      memberRole,
      capabilityGrants: GROWTH_PERMISSION_TEMPLATES[templateId],
    }));
  });

  it.each([
    ["inactive owner", { ...allowedAuthorization, active: false }],
    ["non-owner", { ...allowedAuthorization, owner: false }],
    ["missing capability", { ...allowedAuthorization, capabilities: [] }],
    ["missing AAL2", { ...allowedAuthorization, aal2VerifiedAt: null }],
    ["stale AAL2", { ...allowedAuthorization, aal2VerifiedAt: "2026-07-18T11:54:59.999Z" }],
  ] as const)("denies create for an %s", async (_label, authorization) => {
    const dependencies = createDependencies({ authorization });
    const service = createMemberInvitationService(dependencies, { now: () => NOW });

    await expect(service.create({
      siteId: "site-1",
      actorId: "owner-1",
      email: "member@example.com",
      templateId: "growth_staff_v1",
      templateVersion: 1,
      expiresAt: ownerView.expiresAt,
      idempotencyKey: "invite-create-1",
      aal2VerifiedAt: RECENT_AAL2,
    })).rejects.toEqual(expect.objectContaining<Partial<MemberInvitationServiceError>>({
      code: authorization.aal2VerifiedAt === null || authorization.aal2VerifiedAt < "2026-07-18T11:55:00.000Z"
        ? "recent_aal2_required"
        : "not_authorized",
    }));

    expect(dependencies.crypto.issueToken).not.toHaveBeenCalled();
    expect(dependencies.repository.createAuthoritatively).not.toHaveBeenCalled();
  });

  it("rejects invalid email, template version, expiry, and unapproved runtime templates", async () => {
    const invalidCommands = [
      { email: "not-an-email" },
      { templateVersion: 2 },
      { expiresAt: NOW },
      { templateId: "owner_all_v1" as never },
    ];

    for (const patch of invalidCommands) {
      const dependencies = createDependencies();
      const service = createMemberInvitationService(dependencies, { now: () => NOW });
      await expect(service.create({
        siteId: "site-1",
        actorId: "owner-1",
        email: "member@example.com",
        templateId: "growth_staff_v1",
        templateVersion: 1,
        expiresAt: ownerView.expiresAt,
        idempotencyKey: "invite-create-1",
        aal2VerifiedAt: RECENT_AAL2,
        ...patch,
      })).rejects.toEqual(expect.objectContaining<Partial<MemberInvitationServiceError>>({ code: "invalid_request" }));
      expect(dependencies.repository.createAuthoritatively).not.toHaveBeenCalled();
    }
  });

  it("authorizes revoke and list as site-local owner operations with recent AAL2", async () => {
    const dependencies = createDependencies();
    const service = createMemberInvitationService(dependencies, { now: () => NOW });

    await service.revoke({
      siteId: "site-1",
      actorId: "owner-1",
      invitationId: "invitation-1",
      expectedVersion: 1,
      reason: "No longer needed",
      idempotencyKey: "invite-revoke-1",
      aal2VerifiedAt: RECENT_AAL2,
    });
    await service.listOwnerView("site-1", "owner-1");

    expect(dependencies.authorize).toHaveBeenNthCalledWith(1, {
      siteId: "site-1",
      actorId: "owner-1",
      operation: "revoke",
      assertedAal2VerifiedAt: RECENT_AAL2,
    });
    expect(dependencies.repository.revokeAuthoritatively).toHaveBeenCalledWith({
      siteId: "site-1",
      actorId: "owner-1",
      invitationId: "invitation-1",
      expectedVersion: 1,
      reason: "No longer needed",
      idempotencyKey: "invite-revoke-1",
      aal2VerifiedAt: RECENT_AAL2,
      revokedAt: NOW,
    });
    expect(dependencies.authorize).toHaveBeenNthCalledWith(2, {
      siteId: "site-1",
      actorId: "owner-1",
      operation: "list",
    });
    expect(dependencies.repository.listOwnerViewAuthoritatively).toHaveBeenCalledWith({
      siteId: "site-1",
      actorId: "owner-1",
      aal2VerifiedAt: RECENT_AAL2,
      observedAt: NOW,
    });
  });

  it("hashes acceptance inputs and delegates all single-use, expiry, inviter, site, match, and replay decisions atomically", async () => {
    const dependencies = createDependencies({ acceptance: { memberId: "member-2", replayed: true } });
    const service = createMemberInvitationService(dependencies, { now: () => NOW });

    await expect(service.accept({
      siteId: "site-1",
      invitationToken: RAW_TOKEN,
      authenticatedUserId: "user-2",
      authenticatedEmail: " STAFF.Member@Example.com ",
      idempotencyKey: "invite-accept-1",
    })).resolves.toEqual({ memberId: "member-2", replayed: true });

    expect(dependencies.repository.acceptAuthoritatively).toHaveBeenCalledWith({
      siteId: "site-1",
      tokenHash: TOKEN_HASH,
      canonicalEmailDigest: EMAIL_DIGEST,
      authenticatedUserId: "user-2",
      idempotencyKey: "invite-accept-1",
      acceptedAt: NOW,
    });
    expect(dependencies.authorize).not.toHaveBeenCalled();
    expect(JSON.stringify(vi.mocked(dependencies.repository.acceptAuthoritatively).mock.calls[0]![0]))
      .not.toContain("staff.member@example.com");
  });

  it("whitelists owner views and acceptance results returned by repositories", async () => {
    const leakedOwnerView = {
      ...ownerView,
      tokenHash: TOKEN_HASH,
      canonicalEmailDigest: EMAIL_DIGEST,
      rawEmail: "staff.member@example.com",
    };
    const dependencies = createDependencies({
      createResult: leakedOwnerView,
      listResult: [leakedOwnerView],
      acceptance: { memberId: "member-2", replayed: false, tokenHash: TOKEN_HASH } as never,
    });
    const service = createMemberInvitationService(dependencies, { now: () => NOW });

    const created = await service.create({
      siteId: "site-1",
      actorId: "owner-1",
      email: "member@example.com",
      templateId: "growth_staff_v1",
      templateVersion: 1,
      expiresAt: ownerView.expiresAt,
      idempotencyKey: "invite-create-1",
      aal2VerifiedAt: RECENT_AAL2,
    });
    const listed = await service.listOwnerView("site-1", "owner-1");
    const accepted = await service.accept({
      siteId: "site-1",
      invitationToken: RAW_TOKEN,
      authenticatedUserId: "user-2",
      authenticatedEmail: "member@example.com",
      idempotencyKey: "invite-accept-1",
    });

    expect(created).toEqual(ownerView);
    expect(listed).toEqual([ownerView]);
    expect(accepted).toEqual({ memberId: "member-2", replayed: false });
  });

  it("keeps a persisted invitation retryable when dispatch fails without leaking raw secrets", async () => {
    const dependencies = createDependencies();
    vi.mocked(dependencies.dispatch).mockRejectedValueOnce(
      new Error(`provider failed for member@example.com using ${RAW_TOKEN}`),
    );
    const service = createMemberInvitationService(dependencies, { now: () => NOW });
    const command = {
      siteId: "site-1",
      actorId: "owner-1",
      email: "member@example.com",
      templateId: "growth_staff_v1" as const,
      templateVersion: 1,
      expiresAt: ownerView.expiresAt,
      idempotencyKey: "invite-create-retry",
      aal2VerifiedAt: RECENT_AAL2,
    };

    const failure = await service.create(command).catch((error: unknown) => error);
    expect(failure).toEqual(expect.objectContaining<Partial<MemberInvitationServiceError>>({
      code: "dispatch_failed",
      message: "dispatch_failed",
    }));
    expect(JSON.stringify(failure)).not.toContain("member@example.com");
    expect(JSON.stringify(failure)).not.toContain(RAW_TOKEN);
    expect(dependencies.repository.createAuthoritatively).toHaveBeenCalledOnce();

    await expect(service.create(command)).resolves.toEqual(ownerView);

    expect(dependencies.crypto.issueToken).toHaveBeenCalledTimes(2);
    expect(dependencies.crypto.issueToken).toHaveBeenNthCalledWith(1, {
      siteId: "site-1",
      actorId: "owner-1",
      idempotencyKey: "invite-create-retry",
    });
    expect(dependencies.crypto.issueToken).toHaveBeenNthCalledWith(2, {
      siteId: "site-1",
      actorId: "owner-1",
      idempotencyKey: "invite-create-retry",
    });
    expect(dependencies.dispatch).toHaveBeenCalledTimes(2);
    expect(vi.mocked(dependencies.dispatch).mock.calls[0]![0].invitationToken).toBe(RAW_TOKEN);
    expect(vi.mocked(dependencies.dispatch).mock.calls[1]![0].invitationToken).toBe(RAW_TOKEN);
    expect(vi.mocked(dependencies.dispatch).mock.calls[1]![0].idempotencyKey).toBe("invite-create-retry");
  });

  it("does not dispatch when authoritative persistence fails", async () => {
    const dependencies = createDependencies();
    vi.mocked(dependencies.repository.createAuthoritatively).mockRejectedValueOnce(new Error("persistence failed"));
    const service = createMemberInvitationService(dependencies, { now: () => NOW });

    await expect(service.create({
      siteId: "site-1",
      actorId: "owner-1",
      email: "member@example.com",
      templateId: "growth_staff_v1",
      templateVersion: 1,
      expiresAt: ownerView.expiresAt,
      idempotencyKey: "invite-create-1",
      aal2VerifiedAt: RECENT_AAL2,
    })).rejects.toThrow("persistence failed");

    expect(dependencies.dispatch).not.toHaveBeenCalled();
  });

  it("fails closed when an authoritative repository returns a cross-site owner view", async () => {
    const crossSiteView = { ...ownerView, siteId: "site-2" };
    const dependencies = createDependencies({ createResult: crossSiteView, listResult: [crossSiteView] });
    const service = createMemberInvitationService(dependencies, { now: () => NOW });

    await expect(service.create({
      siteId: "site-1",
      actorId: "owner-1",
      email: "member@example.com",
      templateId: "growth_staff_v1",
      templateVersion: 1,
      expiresAt: ownerView.expiresAt,
      idempotencyKey: "invite-create-1",
      aal2VerifiedAt: RECENT_AAL2,
    })).rejects.toEqual(expect.objectContaining<Partial<MemberInvitationServiceError>>({
      code: "invalid_repository_result",
    }));
    await expect(service.listOwnerView("site-1", "owner-1"))
      .rejects.toEqual(expect.objectContaining<Partial<MemberInvitationServiceError>>({
        code: "invalid_repository_result",
      }));
  });

  it("exports repository commands that cannot carry raw token or email fields", () => {
    expectTypeOf<MemberInvitationRepositoryCreateCommand>().toMatchTypeOf<{
      canonicalEmailDigest: string;
      tokenHash: string;
      memberRole: "owner" | "editor" | "contributor" | "viewer";
    }>();
    expectTypeOf<MemberInvitationRepositoryCreateCommand>().not.toHaveProperty("email");
    expectTypeOf<MemberInvitationRepositoryCreateCommand>().not.toHaveProperty("invitationToken");
  });
});

function createDependencies(overrides: {
  authorization?: MemberInvitationAuthorization;
  createResult?: typeof ownerView;
  listResult?: readonly (typeof ownerView)[];
  acceptance?: { readonly memberId: string; readonly replayed: boolean };
} = {}) {
  const repository: MemberInvitationRepository = {
    createAuthoritatively: vi.fn(async () => overrides.createResult ?? ownerView),
    revokeAuthoritatively: vi.fn(async () => ownerView),
    acceptAuthoritatively: vi.fn(async () => overrides.acceptance ?? { memberId: "member-2", replayed: false }),
    listOwnerViewAuthoritatively: vi.fn(async () => overrides.listResult ?? [ownerView]),
  };
  return {
    repository,
    authorize: vi.fn(async () => overrides.authorization ?? allowedAuthorization),
    dispatch: vi.fn(async (_input: MemberInvitationDispatchCommand) => undefined),
    crypto: {
      issueToken: vi.fn(async () => RAW_TOKEN),
      hashToken: vi.fn(async () => TOKEN_HASH),
      digestCanonicalEmail: vi.fn(async () => EMAIL_DIGEST),
    },
  };
}
