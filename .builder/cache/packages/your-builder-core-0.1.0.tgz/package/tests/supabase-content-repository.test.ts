import { describe, expect, it, vi } from "vitest";
import { ContentConflictError, SlugConflictError } from "@your-builder/content";
import {
  createSupabaseContentRepository,
  createSupabasePublicPostReader,
  mapPublishedPostRow,
  mapSupabaseContentError,
} from "@your-builder/core";

function thenableChain(result: { data: unknown; error: unknown }) {
  const chain: Record<string, unknown> = {};
  for (const method of ["select", "eq", "contains", "order", "limit", "single", "maybeSingle"]) {
    chain[method] = vi.fn(() => chain);
  }
  chain.then = (resolve: (value: unknown) => unknown) => Promise.resolve(result).then(resolve);
  return chain;
}

describe("Supabase post content repository", () => {
  it("maps the approved published projection", () => {
    const mapped = mapPublishedPostRow({
      entry_id: "8e37535d-12e8-4824-983e-c03d42a9a21f",
      version_id: "416d03ee-a021-4c7d-97ed-bfe689b3f48f",
      slug: "route-9",
      title: "Route 9",
      excerpt: "Repairs",
      category_keys: ["infrastructure"],
      tag_keys: [],
      display_date: "2026-07-14T12:00:00.000Z",
      version_published_at: "2026-07-14T13:00:00.000Z",
      expires_at: null,
      featured: false,
      pinned: true,
    });
    expect(mapped).toMatchObject({ entryId: expect.any(String), slug: "route-9", pinned: true });
  });

  it("resolves the stable site key server-side before querying the public view", async () => {
    const siteQuery = thenableChain({ data: { id: "80d9f407-ed96-416f-97b2-a62d6736c5bc" }, error: null });
    const postsQuery = thenableChain({ data: [], error: null });
    const from = vi.fn((table: string) => (table === "builder_sites" ? siteQuery : postsQuery));
    const repository = createSupabaseContentRepository({ from, rpc: vi.fn() } as never);

    await repository.listPublishedPosts("assembly", {
      categoryKeys: ["notice"], tagKeys: [], entryIds: [], featuredOnly: false,
      pinnedFirst: false, limit: 4, orderBy: "displayDate", orderDirection: "desc",
    });

    expect(from).toHaveBeenNthCalledWith(1, "builder_sites");
    expect(from).toHaveBeenNthCalledWith(2, "builder_public_posts");
    expect(postsQuery.eq).toHaveBeenCalledWith("site_id", "80d9f407-ed96-416f-97b2-a62d6736c5bc");
    expect(postsQuery.contains).toHaveBeenCalledWith("category_keys", ["notice"]);
  });

  it("calls only the approved transition RPC with stable site identity", async () => {
    const rpc = vi.fn().mockResolvedValue({ data: { operation: "publish" }, error: null });
    const repository = createSupabaseContentRepository({ from: vi.fn(), rpc } as never);
    await repository.transition("assembly", "publish", { entryId: crypto.randomUUID() }, "publish:request-1");
    expect(rpc).toHaveBeenCalledWith("builder_transition_post", {
      p_site_key: "assembly",
      p_operation: "publish",
      p_payload: expect.objectContaining({ entryId: expect.any(String) }),
      p_idempotency_key: "publish:request-1",
    });
  });

  it("maps database conflict codes to domain errors", () => {
    expect(mapSupabaseContentError({ code: "40001", message: "draft version conflict" })).toBeInstanceOf(
      ContentConflictError,
    );
    expect(mapSupabaseContentError({ code: "23505", message: "slug already claimed" })).toBeInstanceOf(
      SlugConflictError,
    );
  });

  it("reads public posts through site-key RPCs without querying private site membership tables", async () => {
    const rpc = vi.fn()
      .mockResolvedValueOnce({ data: [], error: null })
      .mockResolvedValueOnce({ data: null, error: null });
    const from = vi.fn();
    const reader = createSupabasePublicPostReader({ rpc, from } as never);
    const query = {
      categoryKeys: [], tagKeys: [], entryIds: [], featuredOnly: false,
      pinnedFirst: false, limit: 4, orderBy: "displayDate" as const, orderDirection: "desc" as const,
    };

    await reader.listPublishedPosts("assembly", query);
    await reader.getPublishedPostBySlug("assembly", "route-9");

    expect(rpc).toHaveBeenNthCalledWith(1, "builder_list_public_posts", { p_site_key: "assembly" });
    expect(rpc).toHaveBeenNthCalledWith(2, "builder_get_public_post_by_slug", { p_site_key: "assembly", p_slug: "route-9" });
    expect(from).not.toHaveBeenCalled();
  });
});
