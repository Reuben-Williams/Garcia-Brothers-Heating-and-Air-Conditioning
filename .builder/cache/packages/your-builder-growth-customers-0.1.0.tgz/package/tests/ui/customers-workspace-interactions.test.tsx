// @vitest-environment jsdom

import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";

import {
  CustomersWorkspace,
  type CustomersWorkspaceApi,
  type CustomersWorkspaceProps,
  validateCustomerSavedSegmentFilter,
} from "../../src/ui/index.js";

const customerId = "30000000-0000-4000-8000-000000000101";
const candidateCustomerId = "30000000-0000-4000-8000-000000000102";

function api(): CustomersWorkspaceApi {
  return {
    list: vi.fn(async () => ({ items: [] })),
    get: vi.fn(async () => null),
    updateProfile: vi.fn(async () => ({ status: "applied" as const, version: 5 })),
    reviewMerge: vi.fn(async () => ({ status: "applied" as const, version: 2 })),
    executeMerge: vi.fn(async () => ({ status: "applied" as const, version: 6 })),
    requestExport: vi.fn(async () => ({ status: "applied" as const, resourceId: "export-1" })),
    requestDeletion: vi.fn(async () => ({ status: "applied" as const, resourceId: "delete-1" })),
    setPreference: vi.fn(async () => ({ status: "applied" as const, version: 8 })),
    clearPreference: vi.fn(async () => ({ status: "applied" as const, version: 8 })),
    suppress: vi.fn(async () => ({ status: "applied" as const, version: 5 })),
    unsuppress: vi.fn(async () => ({ status: "applied" as const, version: 5 })),
    addTag: vi.fn(async () => ({ status: "applied" as const, version: 5 })),
    removeTag: vi.fn(async () => ({ status: "applied" as const, version: 5 })),
    saveSegment: vi.fn(async (input) => ({ status: "applied" as const, resourceId: input.segmentId ?? "segment-created", version: input.segmentId ? 4 : 1 })),
    removeSegment: vi.fn(async () => ({ status: "applied" as const, version: 5 })),
  };
}

function props(client: CustomersWorkspaceApi): CustomersWorkspaceProps {
  return {
    mode: "operational",
    access: {
      scope: "site",
      canRead: true,
      canUpdate: true,
      canReviewMerge: true,
      canExport: true,
      canRequestDeletion: true,
      canManageTags: true,
      canShareSegments: true,
    },
    initialPage: {
      items: [{
        id: customerId,
        displayName: "Avery Stone",
        identitySummary: [{ kind: "email", display: "avery@example.test", verified: true }],
        tags: [],
        openLeadCount: 1,
        version: 4,
      }],
    },
    initialCustomer: {
      profile: {
        id: customerId,
        siteId: "10000000-0000-4000-8000-00000000a001",
        displayName: "Avery Stone",
        lifecycleState: "active",
        preferredContactMethod: "email",
        identities: [{ kind: "email", display: "avery@example.test", verified: true }],
        preferences: [{ key: "appointment_window", value: "Morning" }],
        suppressions: [{ channel: "email", reasonCode: "customer_request", active: true }],
        tags: [{ id: "tag-maintenance", label: "Maintenance" }],
        relatedRecords: { leadCount: 1, openTaskCount: 0, serviceEventCount: 0 },
        duplicateReview: { state: "reviewed", suggestionCount: 1 },
        version: 4,
        createdAt: "2026-07-01T12:00:00.000Z",
        updatedAt: "2026-07-18T12:00:00.000Z",
      },
      activity: [],
      mergeSuggestions: [{
        id: "40000000-0000-4000-8000-000000000101",
        candidateCustomerId,
        candidateCustomerVersion: 3,
        candidateDisplayName: "A. Stone",
        confidence: "medium",
        state: "accepted",
        version: 2,
      }],
      exportJobs: [],
      preferenceVersions: { appointment_window: 7 },
      suppressionVersions: { email: 3 },
    },
    savedSegments: [{
      id: "segment-active",
      name: "Active customers",
      shared: false,
      version: 3,
      filter: { version: 1, conjunction: "all", clauses: [{ field: "lifecycle_state", operator: "equals", value: "active" }] },
    }],
    tags: [
      { id: "tag-maintenance", label: "Maintenance" },
      { id: "tag-commercial", label: "Commercial" },
    ],
    api: client,
    onUrlStateChange: vi.fn(),
    onResetDemo: vi.fn(),
  };
}

let container: HTMLDivElement;
let root: Root;

beforeAll(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
});

afterEach(async () => {
  if (root) await act(async () => root.unmount());
  container?.remove();
});

function button(label: string) {
  return Array.from(container.querySelectorAll<HTMLButtonElement>("button")).find(
    (item) => item.textContent?.trim() === label,
  );
}

describe("CustomersWorkspace interactions", () => {
  it("executes an accepted merge with projected record identities and versions", async () => {
    const client = api();
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root.render(<CustomersWorkspace {...props(client)} />));

    await act(async () => button("Execute accepted merge")?.click());

    expect(client.executeMerge).not.toHaveBeenCalled();
    expect(container.querySelector('[role="dialog"]')?.textContent).toContain("Merge accepted duplicate?");
    await act(async () => button("Confirm merge execution")?.click());

    expect(client.executeMerge).toHaveBeenCalledWith({
      suggestionId: "40000000-0000-4000-8000-000000000101",
      sourceId: candidateCustomerId,
      targetId: customerId,
      expectedSourceVersion: 3,
      expectedTargetVersion: 4,
    });
  });

  it("maps profile, preference, suppression, and tag commands to projected versions", async () => {
    const client = api();
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root.render(<CustomersWorkspace {...props(client)} />));

    await act(async () => button("Edit profile")?.click());
    const displayName = container.querySelector<HTMLInputElement>('[aria-label="Customer display name"]')!;
    await act(async () => {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      setter?.call(displayName, "Avery Stone Jr.");
      displayName.dispatchEvent(new Event("input", { bubbles: true }));
    });
    await act(async () => button("Save profile")?.click());
    expect(client.updateProfile).toHaveBeenCalledWith({
      customerId,
      expectedVersion: 4,
      patch: { displayName: "Avery Stone Jr.", preferredContactMethod: "email", serviceAreaZip: null },
    });

    const preference = container.querySelector<HTMLInputElement>('[aria-label="appointment_window preference value"]')!;
    await act(async () => {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      setter?.call(preference, "Afternoon");
      preference.dispatchEvent(new Event("input", { bubbles: true }));
    });
    await act(async () => button("Save preference")?.click());
    expect(client.setPreference).toHaveBeenCalledWith({ customerId, key: "appointment_window", value: "Afternoon", expectedVersion: 7 });
    await act(async () => button("Clear preference")?.click());
    expect(client.clearPreference).toHaveBeenCalledWith({ customerId, key: "appointment_window", expectedVersion: 7 });

    await act(async () => button("Unsuppress email")?.click());
    expect(client.unsuppress).toHaveBeenCalledWith({ customerId, channel: "email", expectedVersion: 3 });
    await act(async () => button("Suppress SMS")?.click());
    expect(client.suppress).toHaveBeenCalledWith({ customerId, channel: "sms", reasonCode: "customer_request", expectedVersion: 0 });

    await act(async () => button("Remove Maintenance")?.click());
    expect(client.removeTag).toHaveBeenCalledWith({ customerId, tagId: "tag-maintenance", expectedVersion: 4 });
    const tag = container.querySelector<HTMLSelectElement>('[aria-label="Existing tag"]')!;
    await act(async () => {
      const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value")?.set;
      setter?.call(tag, "tag-commercial");
      tag.dispatchEvent(new Event("change", { bubbles: true }));
    });
    await act(async () => button("Add tag")?.click());
    expect(client.addTag).toHaveBeenCalledWith({ customerId, tagId: "tag-commercial", expectedVersion: 4 });
  });

  it("creates, updates, and removes validated saved segments", async () => {
    const client = api();
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root.render(<CustomersWorkspace {...props(client)} />));

    await act(async () => button("Manage saved segments")?.click());
    const name = container.querySelector<HTMLInputElement>('[aria-label="Saved segment name"]')!;
    await act(async () => {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      setter?.call(name, "Email customers");
      name.dispatchEvent(new Event("input", { bubbles: true }));
    });
    const clauseField = container.querySelector<HTMLSelectElement>('[aria-label="Segment clause field"]')!;
    const clauseValue = container.querySelector<HTMLInputElement>('[aria-label="Segment clause value"]')!;
    await act(async () => {
      const selectSetter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value")?.set;
      const inputSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      selectSetter?.call(clauseField, "preferred_contact_method");
      clauseField.dispatchEvent(new Event("change", { bubbles: true }));
      inputSetter?.call(clauseValue, "email");
      clauseValue.dispatchEvent(new Event("input", { bubbles: true }));
    });
    await act(async () => button("Add filter clause")?.click());
    await act(async () => button("Create saved segment")?.click());
    expect(client.saveSegment).toHaveBeenCalledWith(expect.objectContaining({
      name: "Email customers",
      filter: {
        version: 1,
        conjunction: "all",
        clauses: [{ field: "preferred_contact_method", operator: "equals", value: "email" }],
      },
    }));

    const segment = container.querySelector<HTMLSelectElement>('[aria-label="Saved segment to edit"]')!;
    await act(async () => {
      const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value")?.set;
      setter?.call(segment, "segment-active");
      segment.dispatchEvent(new Event("change", { bubbles: true }));
    });
    await act(async () => button("Update saved segment")?.click());
    expect(client.saveSegment).toHaveBeenLastCalledWith(expect.objectContaining({ segmentId: "segment-active", expectedVersion: 3 }));
    await act(async () => button("Remove saved segment")?.click());
    expect(client.removeSegment).toHaveBeenCalledWith({ segmentId: "segment-active", expectedVersion: 4 });
  });

  it("requires explicit accept or reject confirmation before duplicate review", async () => {
    const client = api();
    const workspaceProps = props(client);
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root.render(<CustomersWorkspace {...workspaceProps} initialCustomer={{
      ...workspaceProps.initialCustomer!,
      mergeSuggestions: [{ ...workspaceProps.initialCustomer!.mergeSuggestions[0]!, state: "suggested" }],
    }} />));

    await act(async () => button("Accept duplicate")?.click());
    expect(client.reviewMerge).not.toHaveBeenCalled();
    await act(async () => button("Confirm accept")?.click());
    expect(client.reviewMerge).toHaveBeenCalledWith({ suggestionId: "40000000-0000-4000-8000-000000000101", expectedVersion: 2, decision: "accept" });

    await act(async () => button("Reject duplicate")?.click());
    await act(async () => button("Confirm reject")?.click());
    expect(client.reviewMerge).toHaveBeenCalledWith({ suggestionId: "40000000-0000-4000-8000-000000000101", expectedVersion: 2, decision: "reject" });
  });

  it("renders AAL2-required results without claiming the job was queued", async () => {
    const client: CustomersWorkspaceApi = {
      ...api(),
      requestExport: vi.fn(async () => ({ status: "aal2_required" as const, message: "Verify again to continue." })),
    };
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root.render(<CustomersWorkspace {...props(client)} />));

    await act(async () => button("Request export")?.click());
    expect(container.textContent).toContain("Additional verification is required");
    expect(container.textContent).not.toContain("Export request queued");
  });

  it("rejects customer segment filters above twenty clauses", () => {
    expect(validateCustomerSavedSegmentFilter({
      version: 1,
      conjunction: "all",
      clauses: Array.from({ length: 21 }, () => ({ field: "lifecycle_state" as const, operator: "equals" as const, value: "active" })),
    })).toEqual({ ok: false, code: "too_many_clauses" });
  });

  it("requires the owner to provide a deletion reason", async () => {
    const client = api();
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
    await act(async () => root.render(<CustomersWorkspace {...props(client)} />));

    await act(async () => button("Request deletion")?.click());
    const reason = container.querySelector<HTMLInputElement>('[aria-label="Reason for deletion"]');
    expect(reason).toBeTruthy();
    expect(button("Submit deletion request")?.disabled).toBe(true);

    if (reason) {
      await act(async () => {
        const valueSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
        valueSetter?.call(reason, "Customer requested account removal");
        reason.dispatchEvent(new Event("input", { bubbles: true }));
      });
    }
    await act(async () => button("Submit deletion request")?.click());
    expect(client.requestDeletion).toHaveBeenCalledWith({
      customerId,
      reason: "Customer requested account removal",
    });
  });
});
