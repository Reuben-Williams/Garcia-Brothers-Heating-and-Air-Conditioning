// @vitest-environment jsdom

import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";

import {
  CustomersWorkspace,
  type CustomersWorkspaceProps,
} from "../../src/ui/index.js";

const customer = {
  id: "30000000-0000-4000-8000-000000000101",
  siteId: "10000000-0000-4000-8000-00000000a001",
  displayName: "Avery Stone",
  lifecycleState: "active",
  preferredContactMethod: "email",
  serviceAreaZip: "07102",
  identities: [
    { kind: "email", display: "avery.stone@example.test", verified: true },
    { kind: "phone", display: "(202) 555-0101", verified: true },
  ],
  preferences: [{ key: "appointment_window", value: "Morning" }],
  suppressions: [{ channel: "email", reasonCode: "customer_request", active: true }],
  tags: [{ id: "tag-maintenance", label: "Maintenance", color: "#175cd3" }],
  relatedRecords: { leadCount: 2, openTaskCount: 1, serviceEventCount: 3 },
  duplicateReview: { state: "suggested", suggestionCount: 1 },
  version: 4,
  createdAt: "2026-07-01T12:00:00.000Z",
  updatedAt: "2026-07-18T12:00:00.000Z",
} as const;

const page = {
  items: [
    {
      id: customer.id,
      displayName: customer.displayName,
      identitySummary: customer.identities,
      tags: customer.tags,
      latestActivityAt: customer.updatedAt,
      openLeadCount: 2,
      version: customer.version,
    },
    {
      id: "30000000-0000-4000-8000-000000000102",
      displayName: "Morgan Lee",
      identitySummary: [{ kind: "phone", display: "(202) 555-0102", verified: true }],
      tags: [{ id: "tag-commercial", label: "Commercial" }],
      latestActivityAt: "2026-07-17T10:00:00.000Z",
      openLeadCount: 1,
      version: 2,
    },
  ],
  nextCursor: "customer-page-2",
} as const;

function props(overrides: Partial<CustomersWorkspaceProps> = {}): CustomersWorkspaceProps {
  return {
    mode: "operational",
    access: {
      scope: "site",
      canRead: true,
      canUpdate: true,
      canReviewMerge: true,
      canExport: true,
      canRequestDeletion: true,
      canManageTags: true,
      canShareSegments: true,
    },
    initialPage: page,
    initialCustomer: {
      profile: customer,
      activity: [
        { id: "activity-1", kind: "lead", label: "AC repair inquiry created", occurredAt: "2026-07-18T12:00:00.000Z" },
        { id: "activity-2", kind: "service_event", label: "Estimate sent", occurredAt: "2026-07-17T15:00:00.000Z" },
      ],
      mergeSuggestions: [{
        id: "merge-1",
        candidateCustomerId: "30000000-0000-4000-8000-000000000102",
        candidateCustomerVersion: 2,
        candidateDisplayName: "A. Stone",
        confidence: "medium",
        state: "suggested",
        version: 1,
      }],
      exportJobs: [{ id: "export-1", state: "queued", requestedAt: "2026-07-18T11:00:00.000Z" }],
      deletionRequest: { id: "deletion-1", state: "running", requestedAt: "2026-07-18T12:00:00.000Z" },
      preferenceVersions: { appointment_window: 7 },
      suppressionVersions: { email: 3 },
    },
    savedSegments: [{
      id: "segment-active",
      name: "Active customers",
      shared: true,
      version: 3,
      filter: { version: 1, conjunction: "all", clauses: [{ field: "lifecycle_state", operator: "equals", value: "active" }] },
    }],
    tags: [{ id: "tag-maintenance", label: "Maintenance" }, { id: "tag-commercial", label: "Commercial" }],
    api: {
      list: vi.fn(async () => page),
      get: vi.fn(async () => null),
      updateProfile: vi.fn(async () => ({ status: "applied" as const, version: 5 })),
      reviewMerge: vi.fn(async () => ({ status: "applied" as const, version: 2 })),
      executeMerge: vi.fn(async () => ({ status: "applied" as const, version: 6 })),
      requestExport: vi.fn(async () => ({ status: "applied" as const, resourceId: "export-2" })),
      requestDeletion: vi.fn(async () => ({ status: "applied" as const, resourceId: "delete-1" })),
      setPreference: vi.fn(async () => ({ status: "applied" as const, version: 8 })),
      clearPreference: vi.fn(async () => ({ status: "applied" as const, version: 8 })),
      suppress: vi.fn(async () => ({ status: "applied" as const, version: 4 })),
      unsuppress: vi.fn(async () => ({ status: "applied" as const, version: 4 })),
      addTag: vi.fn(async () => ({ status: "applied" as const, version: 5 })),
      removeTag: vi.fn(async () => ({ status: "applied" as const, version: 5 })),
      saveSegment: vi.fn(async () => ({ status: "applied" as const, resourceId: "segment-2", version: 1 })),
      removeSegment: vi.fn(async () => ({ status: "applied" as const, version: 4 })),
    },
    onUrlStateChange: vi.fn(),
    onResetDemo: vi.fn(),
    ...overrides,
  };
}

describe("CustomersWorkspace", () => {
  it("renders the owner list, customer detail, and authorized sensitive actions", () => {
    const html = renderToStaticMarkup(<CustomersWorkspace {...props()} />);

    expect(html).toContain("data-builder-customers-workspace");
    expect(html).toContain('data-customers-mode="operational"');
    expect(html).toContain('data-builder-customer-id="30000000-0000-4000-8000-000000000101"');
    expect(html).toContain("Avery Stone");
    expect(html).toContain("Appointment preferences");
    expect(html).toContain("Duplicate review");
    expect(html).toContain("Request export");
    expect(html).toContain("Request deletion");
    expect(html).toContain("Export queued");
    expect(html).toContain("Deletion review in progress");
  });

  it("keeps assigned-scope records usable without merge, export, or deletion actions", () => {
    const html = renderToStaticMarkup(<CustomersWorkspace {...props({
      access: {
        scope: "assigned",
        canRead: true,
        canUpdate: true,
        canReviewMerge: false,
        canExport: false,
        canRequestDeletion: false,
        canManageTags: false,
        canShareSegments: false,
      },
    })} />);

    expect(html).toContain('data-customer-scope="assigned"');
    expect(html).toContain("Avery Stone");
    expect(html).toContain("Edit profile");
    expect(html).not.toContain("Review duplicate");
    expect(html).not.toContain("Request export");
    expect(html).not.toContain("Request deletion");
  });

  it("keeps search and detail navigation available in read-only mode", () => {
    const html = renderToStaticMarkup(<CustomersWorkspace {...props({
      mode: "read_only",
      access: {
        scope: "site",
        canRead: true,
        canUpdate: false,
        canReviewMerge: false,
        canExport: true,
        canRequestDeletion: false,
        canManageTags: false,
        canShareSegments: false,
      },
    })} />);

    expect(html).toContain("Read-only access");
    expect(html).toContain('aria-label="Search customers"');
    expect(html).toContain("Avery Stone");
    expect(html).toContain("Request export");
    expect(html).not.toContain("Edit profile");
    expect(html).not.toContain("Manage saved segments");
    expect(html).not.toContain("Add tag");
    expect(html).not.toContain("Suppress SMS");
  });

  it("keeps narrow controls and stable customer selectors in the static contract", () => {
    const html = renderToStaticMarkup(<CustomersWorkspace {...props()} />);

    expect(html).toContain("data-builder-customers-list");
    expect(html).toContain("data-builder-customer-detail");
    expect(html).toContain("data-builder-customer-profile-controls");
    expect(html).toContain("Manage saved segments");
  });

  it("uses an isolated fictional demo and explicit sample-data disclosure", () => {
    const html = renderToStaticMarkup(<CustomersWorkspace {...props({
      mode: "demo",
      initialPage: undefined,
      initialCustomer: undefined,
    })} />);

    expect(html).toContain('data-customers-mode="demo"');
    expect(html).toContain("Preview with sample data");
    expect(html).toContain("Reset demo");
    expect(html).toContain("Avery Stone");
  });

  it("renders denied without customer records or query controls", () => {
    const html = renderToStaticMarkup(<CustomersWorkspace {...props({
      mode: "denied",
      access: {
        scope: "none",
        canRead: false,
        canUpdate: false,
        canReviewMerge: false,
        canExport: false,
        canRequestDeletion: false,
        canManageTags: false,
        canShareSegments: false,
      },
      initialPage: undefined,
      initialCustomer: undefined,
    })} />);

    expect(html).toContain("Customers access is not available");
    expect(html).not.toContain("Avery Stone");
    expect(html).not.toContain('aria-label="Search customers"');
  });
});
