import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("growth-customers package boundary", () => {
  it("keeps the domain root stable and isolates approved UI dependencies behind a subpath", () => {
    const manifest = JSON.parse(readFileSync(resolve(import.meta.dirname, "../package.json"), "utf8"));
    expect(manifest).toMatchObject({
      name: "@your-builder/growth-customers",
      version: "0.1.0",
      type: "module",
      main: "./src/index.ts",
      types: "./src/index.ts",
      dependencies: {
        "@your-builder/core": "0.1.0",
        "@your-builder/editor": "0.1.0",
        "@your-builder/feature-registry": "0.1.0",
        "@your-builder/growth-core": "0.1.0",
        "lucide-react": "^0.468.0",
      },
    });
    expect(Object.keys(manifest.dependencies).sort()).toEqual([
      "@your-builder/core",
      "@your-builder/editor",
      "@your-builder/feature-registry",
      "@your-builder/growth-core",
      "lucide-react",
    ]);
    expect(manifest.exports["."].default).toBe("./src/index.ts");
    expect(manifest.exports["./ui"].default).toBe("./src/ui/index.ts");
    expect(manifest.peerDependencies).toEqual({ react: "^19.0.0" });
  });
});
