import { describe, expect, it, vi } from "vitest";
import type {
  AppliedOrConflict,
  ContactMergeSuggestion,
  DataExport,
  DataExportService,
  DeletionRequest,
  DeletionRequestService,
  MergeReviewService,
} from "@your-builder/growth-core";
import type {
  CustomerCommandAuthorization,
  CustomerProfile,
  CustomerProfileCommandRepository,
  CustomerQueryRepository,
} from "../src/index.js";
import {
  createCustomerCommandService,
  createCustomerQueryService,
  CustomerServiceError,
} from "../src/index.js";

const actor = { type: "member" as const, id: "member-1" };
const profile = (siteId = "site-1"): CustomerProfile => ({
  id: "customer-1",
  siteId,
  displayName: "Synthetic Customer",
  lifecycleState: "active",
  preferredContactMethod: "email",
  identities: [],
  preferences: [],
  suppressions: [],
  tags: [],
  relatedRecords: { leadCount: 1, openTaskCount: 0, serviceEventCount: 0 },
  duplicateReview: { state: "none", suggestionCount: 0 },
  version: 2,
  createdAt: "2026-07-18T00:00:00.000Z",
  updatedAt: "2026-07-18T00:00:00.000Z",
});

describe("customer query service", () => {
  it("passes explicit assigned scope and bounded pagination to the repository", async () => {
    const list = vi.fn(async () => ({ items: [], nextCursor: undefined }));
    const repository: CustomerQueryRepository = { list, get: vi.fn(async () => null) };
    const service = createCustomerQueryService(repository);

    await service.list({ siteId: "site-1", actor, scope: "assigned", limit: 50 });

    expect(list).toHaveBeenCalledWith(expect.objectContaining({ siteId: "site-1", scope: "assigned", limit: 50 }));
    await expect(service.list({ siteId: "site-1", actor, scope: "site", limit: 101 }))
      .rejects.toEqual(expect.objectContaining<Partial<CustomerServiceError>>({ code: "invalid_query" }));
  });

  it("does not return a cross-site customer projection", async () => {
    const repository: CustomerQueryRepository = {
      list: vi.fn(async () => ({ items: [] })),
      get: vi.fn(async () => profile("site-2")),
    };

    await expect(createCustomerQueryService(repository).get({
      siteId: "site-1",
      customerId: "customer-1",
      actor,
      scope: "site",
    })).resolves.toBeNull();
  });
});

describe("customer command service", () => {
  it("preserves expected version and idempotency on profile updates", async () => {
    const updateProfile = vi.fn(async (): Promise<AppliedOrConflict<CustomerProfile>> => ({ status: "applied", value: profile() }));
    const service = createCustomerCommandService(createDependencies({ updateProfile }));

    await service.updateProfile({
      siteId: "site-1",
      actor,
      idempotencyKey: "update-1",
      expectedVersion: 2,
      customerId: "customer-1",
      patch: { displayName: "Updated Name" },
    });

    expect(updateProfile).toHaveBeenCalledWith(expect.objectContaining({
      customerId: "customer-1",
      expectedVersion: 2,
      idempotencyKey: "update-1",
    }));
  });

  it("delegates merge, export, and deletion with resolved authorization", async () => {
    const dependencies = createDependencies();
    const service = createCustomerCommandService(dependencies);

    await service.reviewMerge({ siteId: "site-1", actor, idempotencyKey: "merge-1", expectedVersion: 1, suggestionId: "suggestion-1", decision: "accept" });
    await service.requestExport({ siteId: "site-1", actor, idempotencyKey: "export-1", customerIds: ["customer-1"] });
    await service.requestDeletion({ siteId: "site-1", actor, idempotencyKey: "delete-1", customerId: "customer-1", reason: "owner request" });

    expect(dependencies.mergeReviews.review).toHaveBeenCalledWith(expect.objectContaining({ suggestionId: "suggestion-1" }), { canReview: true });
    expect(dependencies.exports.request).toHaveBeenCalledWith(expect.objectContaining({ scope: "customers", filters: { customerIds: ["customer-1"] } }), { canExport: true, freshSession: true });
    expect(dependencies.deletions.request).toHaveBeenCalledWith(expect.objectContaining({ targetType: "customer", targetId: "customer-1" }), { isOwner: true });
  });
});

function createDependencies(overrides: Partial<CustomerProfileCommandRepository> = {}) {
  const profileRepository: CustomerProfileCommandRepository = {
    updateProfile: vi.fn(async () => ({ status: "applied" as const, value: profile() })),
    ...overrides,
  };
  const suggestion: ContactMergeSuggestion = {
    id: "suggestion-1",
    siteId: "site-1",
    candidateContactIds: ["customer-1", "customer-2"],
    evidence: ["name"],
    confidence: "low",
    state: "accepted",
    version: 2,
  };
  const mergeReviews: MergeReviewService = {
    review: vi.fn(async () => ({ status: "applied" as const, value: suggestion })),
    executeAccepted: vi.fn(async () => { throw new Error("not used"); }),
  };
  const exportRecord: DataExport = {
    id: "export-1", siteId: "site-1", requestedBy: actor.id, scope: "customers", filters: {}, status: "requested", version: 1, createdAt: "2026-07-18T00:00:00.000Z",
  };
  const exports: DataExportService = {
    request: vi.fn(async () => exportRecord),
    lease: vi.fn(async () => null),
    complete: vi.fn(async () => { throw new Error("not used"); }),
    expire: vi.fn(async () => { throw new Error("not used"); }),
    authorizeDownload: vi.fn(async () => { throw new Error("not used"); }),
  };
  const deletionRecord: DeletionRequest = {
    id: "deletion-1", siteId: "site-1", requestedBy: actor.id, targetType: "customer", targetId: "customer-1", legalHold: false, status: "requested", version: 1, createdAt: "2026-07-18T00:00:00.000Z",
  };
  const deletions: DeletionRequestService = {
    request: vi.fn(async () => deletionRecord),
    review: vi.fn(async () => { throw new Error("not used"); }),
  };
  const authorization: CustomerCommandAuthorization = {
    canUpdate: true,
    canReviewMerges: true,
    canExport: true,
    freshSession: true,
    isOwner: true,
  };
  return {
    profileRepository,
    mergeReviews,
    exports,
    deletions,
    authorize: vi.fn(async () => authorization),
  };
}
