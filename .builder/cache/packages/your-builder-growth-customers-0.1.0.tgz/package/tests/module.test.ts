import { describe, expect, it } from "vitest";
import { GROWTH_CUSTOMERS_CONTRACT_VERSION, growthCustomersModule } from "../src/index.js";

describe("Customers module", () => {
  it("registers the frozen module definition", () => {
    expect(GROWTH_CUSTOMERS_CONTRACT_VERSION).toBe(1);
    expect(growthCustomersModule).toMatchObject({
      id: "growth.customers",
      version: "1.0.0",
      requiredEntitlement: "growth.customers",
      requiredCapabilities: ["customers.read"],
      dependencies: [],
      routes: [{ path: "/admin/editor/customers" }],
      demo: { allowsExternalEffects: false },
    });
  });
});
