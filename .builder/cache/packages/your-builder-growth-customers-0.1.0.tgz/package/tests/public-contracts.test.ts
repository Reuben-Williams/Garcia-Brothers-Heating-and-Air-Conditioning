import { describe, expect, expectTypeOf, it } from "vitest";
import type {
  CustomerCommandService,
  CustomerProfile,
  CustomerQueryService,
  CustomerSegmentFilter,
  ListCustomersQuery,
} from "../src/index.js";
import { CUSTOMER_SEGMENT_FIELDS, validateCustomerSegmentFilter } from "../src/index.js";

describe("Customers public contracts", () => {
  it("defines safe profile projections without destination hashes or invitation data", () => {
    const customer: CustomerProfile = {
      id: "customer-1",
      siteId: "site-1",
      displayName: "Ada Example",
      lifecycleState: "active",
      preferredContactMethod: "phone",
      identities: [{ kind: "email", display: "a***@example.com", verified: true }],
      preferences: [{ key: "service", value: "heating" }],
      suppressions: [{ channel: "sms", reasonCode: "manual", active: true }],
      tags: [{ id: "tag-1", label: "Maintenance" }],
      relatedRecords: { leadCount: 2, openTaskCount: 1, serviceEventCount: 4 },
      duplicateReview: { state: "suggested", suggestionCount: 1 },
      version: 3,
      createdAt: "2026-07-18T12:00:00.000Z",
      updatedAt: "2026-07-18T12:00:00.000Z",
    };

    expect(customer.suppressions[0]).not.toHaveProperty("normalizedDestinationHash");
    expect(customer).not.toHaveProperty("invitation");
  });

  it("validates reusable segment filters", () => {
    expect(CUSTOMER_SEGMENT_FIELDS).toEqual([
      "lifecycle_state",
      "preferred_contact_method",
      "tag_id",
      "service_area_zip",
      "created_at",
      "updated_at",
    ]);
    const filter: CustomerSegmentFilter = {
      version: 1,
      conjunction: "all",
      clauses: [{ field: "tag_id", operator: "equals", value: "tag-1" }],
    };
    expect(validateCustomerSegmentFilter(filter)).toEqual({ ok: true, value: filter });
  });

  it("defines cursor queries and delegated command services", () => {
    expectTypeOf<ListCustomersQuery>().toMatchTypeOf<{
      siteId: string;
      limit: number;
      cursor?: string;
      filter?: CustomerSegmentFilter;
    }>();
    expectTypeOf<CustomerQueryService>().toBeObject();
    expectTypeOf<CustomerCommandService>().toBeObject();
  });
});
