import { describe, expect, it, vi } from "vitest";
import type {
  SavedView,
  SavedViewServiceRepository,
} from "@your-builder/growth-core";
import type {
  CustomerProfile,
  CustomerQueryRepository,
  CustomerSegmentFilter,
} from "../src/index.js";
import {
  createCustomerQueryService,
  createCustomerSegmentService,
  CustomerServiceError,
} from "../src/index.js";

const actor = { type: "member" as const, id: "member-1" };
const segmentFilter: CustomerSegmentFilter = {
  version: 1,
  conjunction: "all",
  clauses: [{ field: "service_area_zip", operator: "equals", value: "07105" }],
};

const view: SavedView = {
  id: "view-1",
  siteId: "site-1",
  ownerMemberId: actor.id,
  domain: "customers",
  name: "Heating customers",
  shared: false,
  filter: segmentFilter,
  version: 1,
  updatedAt: "2026-07-18T00:00:00.000Z",
};

describe("customer segment service", () => {
  it("fixes the saved-view domain, validates customer fields, and keeps repository ownership authoritative", async () => {
    const repository: SavedViewServiceRepository = {
      listAuthorized: vi.fn(async () => [view]),
      saveAuthorized: vi.fn(async () => ({ status: "applied" as const, value: view })),
      removeAuthorized: vi.fn(async () => ({ status: "applied" as const, value: view })),
    };
    const service = createCustomerSegmentService({
      repository,
      authorize: vi.fn(async () => ({ allowed: true as const, canShare: false, scope: "assigned" as const })),
    });
    const command = {
      siteId: "site-1",
      actor,
      idempotencyKey: "segment-1",
      expectedVersion: 0,
      name: "Heating customers",
      shared: false,
      filter: segmentFilter,
    };

    await expect(service.save(command)).resolves.toMatchObject({ status: "applied" });
    expect(repository.saveAuthorized).toHaveBeenCalledWith({
      command: { ...command, domain: "customers" },
      ownerMemberId: actor.id,
      scope: "assigned",
    });
    await expect(service.save({
      ...command,
      filter: {
        version: 1,
        conjunction: "all",
        clauses: [{ field: "raw_sql", operator: "equals" }],
      } as never,
    })).rejects.toEqual(expect.objectContaining<Partial<CustomerServiceError>>({ code: "invalid_segment" }));
  });
});

const profile: CustomerProfile = {
  id: "customer-1",
  siteId: "site-1",
  displayName: "Synthetic Customer",
  lifecycleState: "active",
  preferredContactMethod: "email",
  identities: [{ kind: "email", display: "s***@example.com", verified: true }],
  preferences: [],
  suppressions: [],
  tags: [{ id: "tag-1", label: "Priority" }],
  relatedRecords: { leadCount: 1, openTaskCount: 0, serviceEventCount: 0 },
  duplicateReview: { state: "none", suggestionCount: 0 },
  version: 2,
  createdAt: "2026-07-18T00:00:00.000Z",
  updatedAt: "2026-07-18T00:00:00.000Z",
};

describe("customer query projections", () => {
  it("strips persistence metadata and uncontracted nested identity fields", async () => {
    const rawProfile = {
      ...profile,
      rawRow: { internal: true },
      identities: [{ ...profile.identities[0]!, normalizedValueHash: "secret-hash" }],
    };
    const rawListItem = {
      id: profile.id,
      displayName: profile.displayName,
      identitySummary: rawProfile.identities,
      tags: profile.tags,
      openLeadCount: 1,
      version: 2,
      storageCursor: "row-42",
    };
    const repository: CustomerQueryRepository = {
      list: vi.fn(async () => ({ items: [rawListItem], nextCursor: "opaque-cursor", queryPlan: "private" })),
      get: vi.fn(async () => rawProfile),
    };
    const service = createCustomerQueryService(repository);

    const page = await service.list({ siteId: "site-1", actor, scope: "site", limit: 25 });
    const result = await service.get({ siteId: "site-1", customerId: profile.id, actor, scope: "site" });

    expect(page).toEqual({
      items: [{
        id: profile.id,
        displayName: profile.displayName,
        identitySummary: [{ kind: "email", display: "s***@example.com", verified: true }],
        tags: [{ id: "tag-1", label: "Priority" }],
        openLeadCount: 1,
        version: 2,
      }],
      nextCursor: "opaque-cursor",
    });
    expect(result).toEqual(profile);
  });
});
