import type { JsonValue, OperationActor } from "@your-builder/growth-core";
import type { CustomerListItem, CustomerProfile } from "./customer.js";
import type { CustomerSegmentFilter } from "./filters.js";

export interface ListCustomersQuery {
  readonly siteId: string;
  readonly actor: OperationActor;
  readonly search?: string;
  readonly filter?: CustomerSegmentFilter;
  readonly sort?: "display_name" | "latest_activity" | "created_at";
  readonly direction?: "asc" | "desc";
  readonly limit: number;
  readonly cursor?: string;
}

export interface CustomerPage { readonly items: readonly CustomerListItem[]; readonly nextCursor?: string; }
export interface GetCustomerQuery { readonly siteId: string; readonly customerId: string; readonly actor: OperationActor; }

export interface CustomerQueryService {
  list(input: ListCustomersQuery): Promise<CustomerPage>;
  get(input: GetCustomerQuery): Promise<CustomerProfile | null>;
}

export interface CustomerRelatedLeadProjection {
  readonly id: string;
  readonly source: CustomerReadSource;
  readonly service?: string;
  readonly urgency: "standard" | "urgent" | "emergency";
  readonly status: "new" | "contacted" | "qualified" | "won" | "lost" | "spam";
  readonly version: number;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export interface CustomerWorkspaceListItem {
  readonly id: string;
  readonly displayName: string;
  readonly lifecycleState: "active" | "inactive" | "merged" | "deleted";
  readonly preferredContactMethod?: "email" | "phone" | "none";
  readonly serviceZipCode?: string;
  readonly latestActivityAt: string;
  readonly version: number;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export type CustomerReadSource = "website_form" | "phone" | "walk_in" | "staff_entry" | "import" | "correction" | "integration";

export interface CustomerWorkspacePage {
  readonly items: readonly CustomerWorkspaceListItem[];
  readonly nextCursor?: string;
}

export interface CustomerReadProfileProjection {
  readonly id: string;
  readonly displayName: string;
  readonly lifecycleState: "active" | "inactive" | "merged" | "deleted";
  readonly preferredContactMethod?: "email" | "phone" | "none";
  readonly serviceZipCode?: string;
  readonly version: number;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export interface CustomerIdentityProjection {
  readonly id: string;
  readonly kind: "email" | "phone" | "external";
  readonly value: string;
  readonly verificationState: string;
  readonly source: CustomerReadSource;
  readonly createdAt: string;
}

export interface CustomerPreferenceProjection {
  readonly key: string;
  readonly value: JsonValue;
  readonly version: number;
  readonly updatedAt: string;
}

export interface CustomerSuppressionProjection {
  readonly id: string;
  readonly channel: "email" | "sms";
  readonly reason: string;
  readonly active: boolean;
  readonly createdAt: string;
  readonly endedAt?: string;
}

export interface CustomerTagProjection {
  readonly id: string;
  readonly key: string;
  readonly label: string;
  readonly colorToken?: string;
}

export interface CustomerServiceEventProjection {
  readonly id: string;
  readonly leadId?: string;
  readonly eventKind: string;
  readonly purpose?: "estimate" | "service" | "follow_up";
  readonly scheduledAt?: string;
  readonly occurredAt: string;
  readonly createdAt: string;
}

export interface CustomerMergeProjection {
  readonly id: string;
  readonly leftCustomerId: string;
  readonly rightCustomerId: string;
  readonly evidenceCategories: readonly string[];
  readonly confidenceBand: "low" | "medium" | "high";
  readonly reviewState: "pending" | "accepted" | "merged" | "dismissed";
  readonly version: number;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export interface CustomerExportProjection {
  readonly id: string;
  readonly domain: string;
  readonly state: string;
  readonly schemaVersion: number;
  readonly expiresAt?: string;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export interface CustomerDeletionProjection {
  readonly id: string;
  readonly scope: string;
  readonly state: string;
  readonly legalHold: boolean;
  readonly version: number;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export interface CustomerWorkspaceDetail {
  readonly customer: CustomerReadProfileProjection;
  readonly identities: readonly CustomerIdentityProjection[];
  readonly preferences: readonly CustomerPreferenceProjection[];
  readonly suppressions: readonly CustomerSuppressionProjection[];
  readonly tags: readonly CustomerTagProjection[];
  readonly leads: readonly CustomerRelatedLeadProjection[];
  readonly serviceEvents: readonly CustomerServiceEventProjection[];
  readonly mergeSuggestions: readonly CustomerMergeProjection[];
  readonly exports: readonly CustomerExportProjection[];
  readonly deletionRequests: readonly CustomerDeletionProjection[];
}
