import {
  createSavedViewService,
  type AppliedOrConflict,
  type RemoveSavedViewCommand,
  type SavedView,
  type SavedViewAuthorization,
  type SavedViewAuthorizationQuery,
  type SavedViewServiceRepository,
  type SaveViewCommand,
} from "@your-builder/growth-core";
import type { CustomerSegmentFilter } from "./filters.js";
import { CUSTOMER_SEGMENT_FIELDS, validateCustomerSegmentFilter } from "./filters.js";
import { CustomerServiceError } from "./services.js";

export type SaveCustomerSegmentCommand = Omit<SaveViewCommand, "domain" | "filter"> & {
  readonly filter: CustomerSegmentFilter;
};

export interface CustomerSegmentService {
  list(input: {
    readonly siteId: string;
    readonly actor: SaveViewCommand["actor"];
  }): Promise<readonly SavedView[]>;
  save(command: SaveCustomerSegmentCommand): Promise<AppliedOrConflict<SavedView>>;
  remove(command: RemoveSavedViewCommand): Promise<AppliedOrConflict<SavedView>>;
}

export function createCustomerSegmentService(dependencies: {
  readonly repository: SavedViewServiceRepository;
  readonly authorize: (input: SavedViewAuthorizationQuery) => Promise<SavedViewAuthorization>;
}): CustomerSegmentService {
  const savedViews = createSavedViewService({
    repository: dependencies.repository,
    authorize: dependencies.authorize,
    allowedFields: {
      customers: CUSTOMER_SEGMENT_FIELDS,
      leads: [],
      base_submissions: [],
    },
  });

  return {
    list(input) {
      return savedViews.list({ ...input, domain: "customers" });
    },
    async save(command) {
      if (!validateCustomerSegmentFilter(command.filter).ok) {
        throw new CustomerServiceError("invalid_segment");
      }
      return savedViews.save({ ...command, domain: "customers" });
    },
    remove(command) {
      return savedViews.remove(command);
    },
  };
}
