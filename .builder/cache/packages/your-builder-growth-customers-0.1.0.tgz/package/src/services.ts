import type {
  AppliedOrConflict,
  DataExportService,
  DeletionRequestService,
  MergeReviewService,
  OperationActor,
} from "@your-builder/growth-core";
import type {
  CustomerCommandService,
  RequestCustomerDeletionCommand,
  RequestCustomerExportCommand,
  ReviewCustomerMergeCommand,
  UpdateCustomerProfileCommand,
} from "./commands.js";
import type { CustomerProfile } from "./customer.js";
import type { CustomerIdentitySummary, CustomerListItem, CustomerTagSummary } from "./customer.js";
import type {
  CustomerPage,
  GetCustomerQuery,
  ListCustomersQuery,
} from "./queries.js";

export type CustomerServiceErrorCode = "not_authorized" | "invalid_query" | "invalid_segment";

export class CustomerServiceError extends Error {
  readonly code: CustomerServiceErrorCode;

  constructor(code: CustomerServiceErrorCode) {
    super(code);
    this.name = "CustomerServiceError";
    this.code = code;
  }
}

export type CustomerQueryScope = "site" | "assigned";
export type ScopedListCustomersQuery = ListCustomersQuery & { readonly scope: CustomerQueryScope };
export type ScopedGetCustomerQuery = GetCustomerQuery & { readonly scope: CustomerQueryScope };

export interface CustomerQueryRepository {
  list(input: ScopedListCustomersQuery): Promise<CustomerPage>;
  get(input: ScopedGetCustomerQuery): Promise<CustomerProfile | null>;
}

export interface ScopedCustomerQueryService {
  list(input: ScopedListCustomersQuery): Promise<CustomerPage>;
  get(input: ScopedGetCustomerQuery): Promise<CustomerProfile | null>;
}

export function createCustomerQueryService(
  repository: CustomerQueryRepository,
): ScopedCustomerQueryService {
  return {
    async list(input) {
      if (!Number.isInteger(input.limit) || input.limit < 1 || input.limit > 100) {
        throw new CustomerServiceError("invalid_query");
      }
      const page = await repository.list(input);
      return {
        items: page.items.map(projectCustomerListItem),
        ...(page.nextCursor === undefined ? {} : { nextCursor: page.nextCursor }),
      };
    },
    async get(input) {
      const customer = await repository.get(input);
      return customer?.siteId === input.siteId ? projectCustomerProfile(customer) : null;
    },
  };
}

function projectIdentity(identity: CustomerIdentitySummary): CustomerIdentitySummary {
  return {
    kind: identity.kind,
    display: identity.display,
    verified: identity.verified,
  };
}

function projectTag(tag: CustomerTagSummary): CustomerTagSummary {
  return {
    id: tag.id,
    label: tag.label,
    ...(tag.color === undefined ? {} : { color: tag.color }),
  };
}

function projectCustomerListItem(customer: CustomerListItem): CustomerListItem {
  return {
    id: customer.id,
    displayName: customer.displayName,
    identitySummary: customer.identitySummary.map(projectIdentity),
    tags: customer.tags.map(projectTag),
    ...(customer.latestActivityAt === undefined ? {} : { latestActivityAt: customer.latestActivityAt }),
    openLeadCount: customer.openLeadCount,
    version: customer.version,
  };
}

function projectCustomerProfile(customer: CustomerProfile): CustomerProfile {
  return {
    id: customer.id,
    siteId: customer.siteId,
    displayName: customer.displayName,
    lifecycleState: customer.lifecycleState,
    preferredContactMethod: customer.preferredContactMethod,
    ...(customer.serviceAreaZip === undefined ? {} : { serviceAreaZip: customer.serviceAreaZip }),
    identities: customer.identities.map(projectIdentity),
    preferences: customer.preferences.map(preference => ({
      key: preference.key,
      value: preference.value,
    })),
    suppressions: customer.suppressions.map(suppression => ({
      channel: suppression.channel,
      reasonCode: suppression.reasonCode,
      active: suppression.active,
    })),
    tags: customer.tags.map(projectTag),
    relatedRecords: {
      leadCount: customer.relatedRecords.leadCount,
      openTaskCount: customer.relatedRecords.openTaskCount,
      serviceEventCount: customer.relatedRecords.serviceEventCount,
    },
    duplicateReview: {
      state: customer.duplicateReview.state,
      suggestionCount: customer.duplicateReview.suggestionCount,
    },
    version: customer.version,
    createdAt: customer.createdAt,
    updatedAt: customer.updatedAt,
  };
}

export interface CustomerProfileCommandRepository {
  updateProfile(input: UpdateCustomerProfileCommand): Promise<AppliedOrConflict<CustomerProfile>>;
}

export interface CustomerCommandAuthorization {
  readonly canUpdate: boolean;
  readonly canReviewMerges: boolean;
  readonly canExport: boolean;
  readonly freshSession: boolean;
  readonly isOwner: boolean;
}

export interface CustomerAuthorizationQuery {
  readonly siteId: string;
  readonly actor: OperationActor;
  readonly action: "update" | "review_merge" | "export" | "request_deletion";
  readonly customerId?: string;
}

export interface CustomerCommandServiceDependencies {
  readonly profileRepository: CustomerProfileCommandRepository;
  readonly mergeReviews: MergeReviewService;
  readonly exports: DataExportService;
  readonly deletions: DeletionRequestService;
  readonly authorize: (input: CustomerAuthorizationQuery) => Promise<CustomerCommandAuthorization>;
}

export function createCustomerCommandService(
  dependencies: CustomerCommandServiceDependencies,
): CustomerCommandService {
  return {
    async updateProfile(input: UpdateCustomerProfileCommand) {
      const authorization = await dependencies.authorize({
        siteId: input.siteId,
        actor: input.actor,
        action: "update",
        customerId: input.customerId,
      });
      if (!authorization.canUpdate) throw new CustomerServiceError("not_authorized");
      return dependencies.profileRepository.updateProfile(input);
    },
    async reviewMerge(input: ReviewCustomerMergeCommand) {
      const authorization = await dependencies.authorize({
        siteId: input.siteId,
        actor: input.actor,
        action: "review_merge",
      });
      return dependencies.mergeReviews.review({
        siteId: input.siteId,
        actor: input.actor,
        idempotencyKey: input.idempotencyKey,
        expectedVersion: input.expectedVersion,
        suggestionId: input.suggestionId,
        decision: input.decision,
      }, { canReview: authorization.canReviewMerges });
    },
    async requestExport(input: RequestCustomerExportCommand) {
      const authorization = await dependencies.authorize({
        siteId: input.siteId,
        actor: input.actor,
        action: "export",
      });
      const filters = {
        ...(input.filter ?? {}),
        ...(input.customerIds ? { customerIds: input.customerIds } : {}),
      };
      return dependencies.exports.request({
        siteId: input.siteId,
        actor: input.actor,
        idempotencyKey: input.idempotencyKey,
        scope: "customers",
        filters,
      }, {
        canExport: authorization.canExport,
        freshSession: authorization.freshSession,
      });
    },
    async requestDeletion(input: RequestCustomerDeletionCommand) {
      const authorization = await dependencies.authorize({
        siteId: input.siteId,
        actor: input.actor,
        action: "request_deletion",
        customerId: input.customerId,
      });
      return dependencies.deletions.request({
        siteId: input.siteId,
        actor: input.actor,
        idempotencyKey: input.idempotencyKey,
        targetType: "customer",
        targetId: input.customerId,
        reason: input.reason,
      }, { isOwner: authorization.isOwner });
    },
  };
}
