export type CustomerLifecycleState = "active" | "inactive" | "merged" | "deleted";
export type CustomerPreferredContactMethod = "email" | "phone" | "none";

export interface CustomerIdentitySummary {
  readonly kind: "email" | "phone" | "external";
  readonly display: string;
  readonly verified: boolean;
}

export interface CustomerPreferenceSummary { readonly key: string; readonly value: string; }
export interface CustomerSuppressionSummary { readonly channel: "email" | "sms"; readonly reasonCode: string; readonly active: boolean; }
export interface CustomerTagSummary { readonly id: string; readonly label: string; readonly color?: string; }
export interface CustomerRelatedRecordSummary { readonly leadCount: number; readonly openTaskCount: number; readonly serviceEventCount: number; }
export interface CustomerDuplicateReviewSummary { readonly state: "none" | "suggested" | "reviewed"; readonly suggestionCount: number; }

export interface CustomerProfile {
  readonly id: string;
  readonly siteId: string;
  readonly displayName: string;
  readonly lifecycleState: CustomerLifecycleState;
  readonly preferredContactMethod: CustomerPreferredContactMethod;
  readonly serviceAreaZip?: string;
  readonly identities: readonly CustomerIdentitySummary[];
  readonly preferences: readonly CustomerPreferenceSummary[];
  readonly suppressions: readonly CustomerSuppressionSummary[];
  readonly tags: readonly CustomerTagSummary[];
  readonly relatedRecords: CustomerRelatedRecordSummary;
  readonly duplicateReview: CustomerDuplicateReviewSummary;
  readonly version: number;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export interface CustomerListItem {
  readonly id: string;
  readonly displayName: string;
  readonly identitySummary: readonly CustomerIdentitySummary[];
  readonly tags: readonly CustomerTagSummary[];
  readonly latestActivityAt?: string;
  readonly openLeadCount: number;
  readonly version: number;
}
