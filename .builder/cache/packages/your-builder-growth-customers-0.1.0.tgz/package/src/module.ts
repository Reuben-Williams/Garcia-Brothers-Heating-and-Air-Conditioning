import { MODULE_IDS, type GrowthFeatureModule } from "@your-builder/feature-registry";

export const growthCustomersModule = Object.freeze({
  id: MODULE_IDS.customers,
  version: "1.0.0",
  label: "Customers",
  description: "Customer profiles, preferences, segments, and related activity.",
  icon: "users",
  navigationGroup: "growth",
  routes: [{ id: "growth.customers.home", path: "/admin/editor/customers", label: "Customers" }],
  requiredEntitlement: MODULE_IDS.customers,
  requiredCapabilities: ["customers.read"],
  dependencies: [],
  setupSteps: [],
  demo: { fixtureId: "growth.customers.demo", allowMutations: true, allowsExternalEffects: false },
  healthChecks: [],
  mobileNavigationPriority: 30,
} as const satisfies GrowthFeatureModule);
