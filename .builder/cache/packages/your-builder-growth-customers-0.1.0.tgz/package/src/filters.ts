import { SAVED_VIEW_FILTER_OPERATORS, type JsonValue, type SavedViewFilterOperator } from "@your-builder/growth-core";

export const CUSTOMER_SEGMENT_FIELDS = Object.freeze([
  "lifecycle_state",
  "preferred_contact_method",
  "tag_id",
  "service_area_zip",
  "created_at",
  "updated_at",
] as const);
export type CustomerSegmentField = (typeof CUSTOMER_SEGMENT_FIELDS)[number];

export interface CustomerSegmentFilterClause {
  readonly field: CustomerSegmentField;
  readonly operator: SavedViewFilterOperator;
  readonly value?: JsonValue;
}

export interface CustomerSegmentFilter {
  readonly version: 1;
  readonly conjunction: "all" | "any";
  readonly clauses: readonly CustomerSegmentFilterClause[];
}

export type CustomerSegmentFilterValidation =
  | { readonly ok: true; readonly value: CustomerSegmentFilter }
  | { readonly ok: false; readonly code: "too_many_clauses" | "invalid_field" | "invalid_operator" };

export function validateCustomerSegmentFilter(filter: CustomerSegmentFilter): CustomerSegmentFilterValidation {
  if (filter.clauses.length > 20) return { ok: false, code: "too_many_clauses" };
  for (const clause of filter.clauses) {
    if (!(CUSTOMER_SEGMENT_FIELDS as readonly string[]).includes(clause.field)) {
      return { ok: false, code: "invalid_field" };
    }
    if (!(SAVED_VIEW_FILTER_OPERATORS as readonly string[]).includes(clause.operator)) {
      return { ok: false, code: "invalid_operator" };
    }
  }
  return { ok: true, value: filter };
}
