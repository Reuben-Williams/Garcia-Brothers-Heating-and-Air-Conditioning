import type {
  AppliedOrConflict,
  ContactMergeSuggestion,
  DataExport,
  DeletionRequest,
  OperationActor,
} from "@your-builder/growth-core";
import type { CustomerProfile } from "./customer.js";

interface CustomerCommandContext { readonly siteId: string; readonly actor: OperationActor; readonly idempotencyKey: string; }
interface VersionedCustomerCommandContext extends CustomerCommandContext { readonly expectedVersion: number; }

export interface UpdateCustomerProfileCommand extends VersionedCustomerCommandContext {
  readonly customerId: string;
  readonly patch: { readonly displayName?: string; readonly preferredContactMethod?: "email" | "phone" | "none"; readonly serviceAreaZip?: string | null };
}
export interface ReviewCustomerMergeCommand extends VersionedCustomerCommandContext { readonly suggestionId: string; readonly decision: "accept" | "reject"; }
export interface RequestCustomerExportCommand extends CustomerCommandContext { readonly customerIds?: readonly string[]; readonly filter?: Record<string, string | readonly string[]>; }
export interface RequestCustomerDeletionCommand extends CustomerCommandContext { readonly customerId: string; readonly reason: string; }

export interface CustomerCommandService {
  updateProfile(input: UpdateCustomerProfileCommand): Promise<AppliedOrConflict<CustomerProfile>>;
  reviewMerge(input: ReviewCustomerMergeCommand): Promise<AppliedOrConflict<ContactMergeSuggestion>>;
  requestExport(input: RequestCustomerExportCommand): Promise<DataExport>;
  requestDeletion(input: RequestCustomerDeletionCommand): Promise<DeletionRequest>;
}
