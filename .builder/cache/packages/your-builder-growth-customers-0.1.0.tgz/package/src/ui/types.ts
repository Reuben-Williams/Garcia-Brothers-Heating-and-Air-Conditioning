import { validateCustomerSegmentFilter } from "../index.js";
import type { CustomerListItem, CustomerPage, CustomerProfile, CustomerSegmentFilter } from "../index.js";

export type CustomersWorkspaceMode =
  | "demo"
  | "operational"
  | "read_only"
  | "loading"
  | "error"
  | "denied";

export interface CustomersWorkspaceAccess {
  readonly scope: "site" | "assigned" | "none";
  readonly canRead: boolean;
  readonly canUpdate: boolean;
  readonly canReviewMerge: boolean;
  readonly canExport: boolean;
  readonly canRequestDeletion: boolean;
  readonly canManageTags: boolean;
  readonly canShareSegments: boolean;
}

export interface CustomerActivityItem {
  readonly id: string;
  readonly kind: "lead" | "task" | "service_event" | "profile" | "merge";
  readonly label: string;
  readonly occurredAt: string;
}

export interface CustomerMergeSuggestionView {
  readonly id: string;
  readonly candidateCustomerId: string;
  readonly candidateCustomerVersion: number;
  readonly candidateDisplayName: string;
  readonly confidence: "low" | "medium" | "high";
  readonly state: "suggested" | "accepted" | "dismissed";
  readonly version: number;
}

export interface CustomerJobView {
  readonly id: string;
  readonly state: "queued" | "running" | "completed" | "failed" | "expired";
  readonly requestedAt: string;
}

export interface CustomerWorkspaceDetail {
  readonly profile: CustomerProfile;
  readonly activity: readonly CustomerActivityItem[];
  readonly mergeSuggestions: readonly CustomerMergeSuggestionView[];
  readonly exportJobs: readonly CustomerJobView[];
  readonly deletionRequest?: CustomerJobView;
  readonly preferenceVersions?: Readonly<Record<string, number>>;
  readonly suppressionVersions?: Readonly<Partial<Record<"email" | "sms", number>>>;
}

export interface CustomerSavedSegment {
  readonly id: string;
  readonly name: string;
  readonly shared: boolean;
  readonly filter?: CustomerSegmentFilter;
  readonly version?: number;
}

export interface CustomerTagOption {
  readonly id: string;
  readonly label: string;
  readonly color?: string;
}

export const validateCustomerSavedSegmentFilter = validateCustomerSegmentFilter;

export interface CustomerListInput {
  readonly search?: string;
  readonly segmentId?: string;
  readonly sort?: "display_name" | "latest_activity" | "created_at";
  readonly cursor?: string;
}

export type CustomerWorkspaceCommandResult =
  | { readonly status: "applied"; readonly version?: number; readonly resourceId?: string }
  | { readonly status: "conflict"; readonly actualVersion: number }
  | { readonly status: "denied"; readonly message: string }
  | { readonly status: "aal2_required"; readonly message?: string };

export interface CustomersWorkspaceApi {
  readonly list: (input: CustomerListInput) => Promise<CustomerPage>;
  readonly get: (customerId: string) => Promise<CustomerWorkspaceDetail | null>;
  readonly updateProfile: (input: {
    readonly customerId: string;
    readonly expectedVersion: number;
    readonly patch: { readonly displayName?: string; readonly preferredContactMethod?: "email" | "phone" | "none"; readonly serviceAreaZip?: string | null };
  }) => Promise<CustomerWorkspaceCommandResult>;
  readonly reviewMerge: (input: { readonly suggestionId: string; readonly expectedVersion: number; readonly decision: "accept" | "reject" }) => Promise<CustomerWorkspaceCommandResult>;
  readonly executeMerge: (input: { readonly suggestionId: string; readonly sourceId: string; readonly targetId: string; readonly expectedSourceVersion: number; readonly expectedTargetVersion: number }) => Promise<CustomerWorkspaceCommandResult>;
  readonly requestExport: (input: { readonly customerIds?: readonly string[]; readonly segmentId?: string }) => Promise<CustomerWorkspaceCommandResult>;
  readonly requestDeletion: (input: { readonly customerId: string; readonly reason: string }) => Promise<CustomerWorkspaceCommandResult>;
  readonly setPreference: (input: { readonly customerId: string; readonly key: string; readonly value: string; readonly expectedVersion: number }) => Promise<CustomerWorkspaceCommandResult>;
  readonly clearPreference: (input: { readonly customerId: string; readonly key: string; readonly expectedVersion: number }) => Promise<CustomerWorkspaceCommandResult>;
  readonly suppress: (input: { readonly customerId: string; readonly channel: "email" | "sms"; readonly reasonCode: string; readonly expectedVersion: number }) => Promise<CustomerWorkspaceCommandResult>;
  readonly unsuppress: (input: { readonly customerId: string; readonly channel: "email" | "sms"; readonly expectedVersion: number }) => Promise<CustomerWorkspaceCommandResult>;
  readonly addTag: (input: { readonly customerId: string; readonly tagId: string; readonly expectedVersion: number }) => Promise<CustomerWorkspaceCommandResult>;
  readonly removeTag: (input: { readonly customerId: string; readonly tagId: string; readonly expectedVersion: number }) => Promise<CustomerWorkspaceCommandResult>;
  readonly saveSegment: (input: { readonly segmentId?: string; readonly expectedVersion?: number; readonly name: string; readonly shared: boolean; readonly filter: CustomerSegmentFilter }) => Promise<CustomerWorkspaceCommandResult>;
  readonly removeSegment: (input: { readonly segmentId: string; readonly expectedVersion: number }) => Promise<CustomerWorkspaceCommandResult>;
}

export interface CustomersWorkspaceUrlState {
  readonly search?: string;
  readonly segmentId?: string;
  readonly customerId?: string;
  readonly cursor?: string;
}

export interface CustomersWorkspaceProps {
  readonly mode: CustomersWorkspaceMode;
  readonly access: CustomersWorkspaceAccess;
  readonly initialPage?: { readonly items: readonly CustomerListItem[]; readonly nextCursor?: string };
  readonly initialCustomer?: CustomerWorkspaceDetail;
  readonly savedSegments: readonly CustomerSavedSegment[];
  readonly tags?: readonly CustomerTagOption[];
  readonly api: CustomersWorkspaceApi;
  readonly errorMessage?: string;
  readonly onUrlStateChange: (state: CustomersWorkspaceUrlState) => void;
  readonly onResetDemo: () => void;
}
