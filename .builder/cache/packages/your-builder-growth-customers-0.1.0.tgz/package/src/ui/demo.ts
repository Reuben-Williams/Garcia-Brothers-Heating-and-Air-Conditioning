import type { CustomerPage } from "../index.js";
import type { CustomerWorkspaceDetail } from "./types.js";

export const CUSTOMER_DEMO_DETAIL = Object.freeze({
  profile: Object.freeze({
    id: "demo-customer-avery",
    siteId: "customers-demo",
    displayName: "Avery Stone",
    lifecycleState: "active",
    preferredContactMethod: "email",
    serviceAreaZip: "07102",
    identities: Object.freeze([
      Object.freeze({ kind: "email", display: "avery.stone@example.test", verified: true }),
      Object.freeze({ kind: "phone", display: "(202) 555-0101", verified: true }),
    ]),
    preferences: Object.freeze([Object.freeze({ key: "appointment_window", value: "Morning" })]),
    suppressions: Object.freeze([]),
    tags: Object.freeze([Object.freeze({ id: "demo-tag-maintenance", label: "Maintenance", color: "#175cd3" })]),
    relatedRecords: Object.freeze({ leadCount: 2, openTaskCount: 1, serviceEventCount: 3 }),
    duplicateReview: Object.freeze({ state: "suggested", suggestionCount: 1 }),
    version: 1,
    createdAt: "2026-07-01T12:00:00.000Z",
    updatedAt: "2026-07-18T12:00:00.000Z",
  }),
  activity: Object.freeze([
    Object.freeze({ id: "demo-activity-1", kind: "lead", label: "AC repair inquiry created", occurredAt: "2026-07-18T12:00:00.000Z" }),
    Object.freeze({ id: "demo-activity-2", kind: "service_event", label: "Estimate sent", occurredAt: "2026-07-17T15:00:00.000Z" }),
  ]),
  mergeSuggestions: Object.freeze([
    Object.freeze({
      id: "demo-merge-1",
      candidateCustomerId: "demo-customer-avery-duplicate",
      candidateCustomerVersion: 1,
      candidateDisplayName: "A. Stone",
      confidence: "medium",
      state: "suggested",
      version: 1,
    }),
  ]),
  exportJobs: Object.freeze([]),
} as const satisfies CustomerWorkspaceDetail);

export const CUSTOMER_DEMO_PAGE = Object.freeze({
  items: Object.freeze([
    Object.freeze({
      id: CUSTOMER_DEMO_DETAIL.profile.id,
      displayName: CUSTOMER_DEMO_DETAIL.profile.displayName,
      identitySummary: CUSTOMER_DEMO_DETAIL.profile.identities,
      tags: CUSTOMER_DEMO_DETAIL.profile.tags,
      latestActivityAt: CUSTOMER_DEMO_DETAIL.profile.updatedAt,
      openLeadCount: 2,
      version: 1,
    }),
    Object.freeze({
      id: "demo-customer-morgan",
      displayName: "Morgan Lee",
      identitySummary: Object.freeze([Object.freeze({ kind: "phone", display: "(202) 555-0102", verified: true })]),
      tags: Object.freeze([Object.freeze({ id: "demo-tag-commercial", label: "Commercial" })]),
      latestActivityAt: "2026-07-17T10:00:00.000Z",
      openLeadCount: 1,
      version: 1,
    }),
  ]),
} as const satisfies CustomerPage);
