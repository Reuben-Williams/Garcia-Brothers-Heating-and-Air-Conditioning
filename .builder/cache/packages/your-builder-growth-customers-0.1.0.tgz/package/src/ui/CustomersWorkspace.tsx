"use client";

import {
  AlertTriangle,
  ArrowLeft,
  ChevronRight,
  Download,
  Mail,
  Merge,
  Phone,
  Plus,
  Search,
  ShieldAlert,
  Tag,
  Trash2,
  UserRound,
  X,
} from "lucide-react";
import { useEffect, useState, useTransition, type FormEvent } from "react";
import { DemoBanner, DestructiveActionGuard, WorkspaceHeader } from "@your-builder/editor";
import type { CustomerListItem, CustomerPage, CustomerSegmentFilter } from "../index.js";
import { CUSTOMER_DEMO_DETAIL, CUSTOMER_DEMO_PAGE } from "./demo.js";
import { validateCustomerSavedSegmentFilter } from "./types.js";
import type {
  CustomerMergeSuggestionView,
  CustomerSavedSegment,
  CustomerWorkspaceCommandResult,
  CustomerWorkspaceDetail,
  CustomersWorkspaceProps,
} from "./types.js";
import styles from "./customers-workspace.module.css";

function commandMessage(result: CustomerWorkspaceCommandResult, success: string): string {
  if (result.status === "applied") return success;
  if (result.status === "conflict") return `This record changed. Current version: ${result.actualVersion}. Review and try again.`;
  if (result.status === "aal2_required") return `Additional verification is required before this action can continue.${result.message ? ` ${result.message}` : ""}`;
  return result.message;
}

function identityIcon(kind: "email" | "phone" | "external") {
  if (kind === "email") return Mail;
  if (kind === "phone") return Phone;
  return UserRound;
}

function CustomerRow({ item, selected, onOpen }: { readonly item: CustomerListItem; readonly selected: boolean; readonly onOpen: () => void }) {
  return (
    <button type="button" className={styles.customerRow} data-builder-customer-id={item.id} aria-current={selected ? "true" : undefined} onClick={onOpen}>
      <span className={styles.rowMain}><strong>{item.displayName}</strong><small>{item.identitySummary[0]?.display ?? "No contact method"}</small></span>
      <span className={styles.rowMeta}><span>{item.openLeadCount} open lead{item.openLeadCount === 1 ? "" : "s"}</span><span>{item.tags.map((tag) => tag.label).join(", ") || "No tags"}</span></span>
      <ChevronRight size={18} aria-hidden="true" />
    </button>
  );
}

function ConfirmationDialog({ title, description, confirmLabel, onCancel, onConfirm }: {
  readonly title: string;
  readonly description: string;
  readonly confirmLabel: string;
  readonly onCancel: () => void;
  readonly onConfirm: () => void;
}) {
  return (
    <div className={styles.confirmBackdrop}>
      <section className={styles.confirmDialog} role="dialog" aria-modal="true" aria-labelledby="customer-confirm-title">
        <header><h3 id="customer-confirm-title">{title}</h3><button type="button" className={styles.iconButton} aria-label="Cancel confirmation" onClick={onCancel}><X size={18} aria-hidden="true" /></button></header>
        <p>{description}</p>
        <div><button type="button" className={styles.secondaryButton} onClick={onCancel}>Cancel</button><button type="button" className={styles.primaryButton} onClick={onConfirm}>{confirmLabel}</button></div>
      </section>
    </div>
  );
}

function ProfileControls({ detail, busy, onSave }: {
  readonly detail: CustomerWorkspaceDetail;
  readonly busy: boolean;
  readonly onSave: (patch: { readonly displayName: string; readonly preferredContactMethod: "email" | "phone" | "none"; readonly serviceAreaZip: string | null }) => void;
}) {
  const [editing, setEditing] = useState(false);
  const profile = detail.profile;
  if (!editing) return <button type="button" className={styles.secondaryButton} onClick={() => setEditing(true)}>Edit profile</button>;
  return (
    <form className={styles.profileForm} data-builder-customer-profile-form onSubmit={(event) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      onSave({
        displayName: String(data.get("displayName") ?? "").trim(),
        preferredContactMethod: String(data.get("preferredContactMethod") ?? "none") as "email" | "phone" | "none",
        serviceAreaZip: String(data.get("serviceAreaZip") ?? "").trim() || null,
      });
      setEditing(false);
    }}>
      <label><span>Display name</span><input name="displayName" aria-label="Customer display name" defaultValue={profile.displayName} maxLength={160} required /></label>
      <label><span>Preferred contact</span><select name="preferredContactMethod" defaultValue={profile.preferredContactMethod}><option value="email">Email</option><option value="phone">Phone</option><option value="none">None</option></select></label>
      <label><span>Service ZIP</span><input name="serviceAreaZip" aria-label="Customer service ZIP" defaultValue={profile.serviceAreaZip ?? ""} maxLength={10} /></label>
      <div><button type="button" className={styles.secondaryButton} onClick={() => setEditing(false)}>Cancel</button><button type="submit" className={styles.primaryButton} disabled={busy}>Save profile</button></div>
    </form>
  );
}

function CustomerSettings({ detail, props, busy, onPreference, onClearPreference, onSuppress, onUnsuppress, onAddTag, onRemoveTag }: {
  readonly detail: CustomerWorkspaceDetail;
  readonly props: CustomersWorkspaceProps;
  readonly busy: boolean;
  readonly onPreference: (key: string, value: string, expectedVersion: number) => void;
  readonly onClearPreference: (key: string, expectedVersion: number) => void;
  readonly onSuppress: (channel: "email" | "sms", expectedVersion: number) => void;
  readonly onUnsuppress: (channel: "email" | "sms", expectedVersion: number) => void;
  readonly onAddTag: (tagId: string) => void;
  readonly onRemoveTag: (tagId: string) => void;
}) {
  const profile = detail.profile;
  const [tagId, setTagId] = useState("");
  const assignedTags = new Set(profile.tags.map((tag) => tag.id));
  return (
    <div className={styles.detailColumns} data-builder-customer-profile-controls>
      <section className={styles.detailSection}>
        <h3>Appointment preferences</h3>
        <p>Preferred contact: <strong>{profile.preferredContactMethod}</strong></p>
        {profile.preferences.map((preference) => (
          <form className={styles.inlineControl} key={preference.key} onSubmit={(event) => {
            event.preventDefault();
            const value = String(new FormData(event.currentTarget).get("value") ?? "").trim();
            if (value) onPreference(preference.key, value, detail.preferenceVersions?.[preference.key] ?? 0);
          }}>
            <label><span>{preference.key.replaceAll("_", " ")}</span><input name="value" aria-label={`${preference.key} preference value`} defaultValue={preference.value} maxLength={200} disabled={busy} /></label>
            <button type="submit" className={styles.secondaryButton} disabled={busy}>Save preference</button>
            <button type="button" className={styles.secondaryButton} disabled={busy} onClick={() => onClearPreference(preference.key, detail.preferenceVersions?.[preference.key] ?? 0)}>Clear preference</button>
          </form>
        ))}
        <p>Service ZIP: <strong>{profile.serviceAreaZip ?? "Not set"}</strong></p>
      </section>
      <section className={styles.detailSection}>
        <h3>Tags and suppressions</h3>
        <div className={styles.tags}>{profile.tags.map((tag) => <span key={tag.id}><Tag size={14} aria-hidden="true" />{tag.label}<button type="button" aria-label={`Remove ${tag.label}`} onClick={() => onRemoveTag(tag.id)}><X size={14} aria-hidden="true" /><span className={styles.visuallyHidden}>Remove {tag.label}</span></button></span>)}</div>
        <div className={styles.inlineActions}>
          <select aria-label="Existing tag" value={tagId} onChange={(event) => setTagId(event.currentTarget.value)}><option value="">Choose existing tag</option>{(props.tags ?? []).filter((tag) => !assignedTags.has(tag.id)).map((tag) => <option key={tag.id} value={tag.id}>{tag.label}</option>)}</select>
          <button type="button" className={styles.secondaryButton} disabled={!tagId || busy} onClick={() => onAddTag(tagId)}><Plus size={16} aria-hidden="true" />Add tag</button>
        </div>
        {(["email", "sms"] as const).map((channel) => {
          const active = profile.suppressions.find((item) => item.channel === channel && item.active);
          const version = detail.suppressionVersions?.[channel] ?? 0;
          return active
            ? <button key={channel} type="button" className={styles.secondaryButton} disabled={busy} onClick={() => onUnsuppress(channel, version)}>Unsuppress {channel}</button>
            : <button key={channel} type="button" className={styles.secondaryButton} disabled={busy} onClick={() => onSuppress(channel, version)}>Suppress {channel.toUpperCase()}</button>;
        })}
      </section>
    </div>
  );
}

function Activity({ detail }: { readonly detail: CustomerWorkspaceDetail }) {
  return <section className={styles.detailSection}><h3>Recent activity</h3>{detail.activity.length === 0 ? <p className={styles.muted}>No recent activity.</p> : <ol className={styles.timeline}>{detail.activity.map((item) => <li key={item.id}><span aria-hidden="true" /><div><strong>{item.label}</strong><time dateTime={item.occurredAt}>{new Date(item.occurredAt).toLocaleDateString("en-US")}</time></div></li>)}</ol>}</section>;
}

const jobLabels = {
  export: { queued: "Export queued", running: "Export preparing", completed: "Export ready", failed: "Export failed", expired: "Export expired" },
  deletion: { queued: "Deletion request queued", running: "Deletion review in progress", completed: "Deletion request completed", failed: "Deletion request failed", expired: "Deletion request expired" },
} as const;

type PendingConfirmation = { readonly kind: "accept" | "reject" | "execute"; readonly suggestion: CustomerMergeSuggestionView };

function CustomerDetail({ detail, props, busy, onBack, onCommand }: {
  readonly detail: CustomerWorkspaceDetail;
  readonly props: CustomersWorkspaceProps;
  readonly busy: boolean;
  readonly onBack: () => void;
  readonly onCommand: (action: string, payload?: unknown) => void;
}) {
  const profile = detail.profile;
  const editable = props.mode !== "read_only" && props.access.canUpdate;
  const [confirmation, setConfirmation] = useState<PendingConfirmation | null>(null);
  return (
    <article className={styles.detail} data-builder-customer-detail>
      <header className={styles.detailHeader}>
        <button type="button" className={styles.backButton} onClick={onBack} aria-label="Back to customers"><ArrowLeft size={19} aria-hidden="true" /></button>
        <div><span>Customer</span><h2>{profile.displayName}</h2><p>Updated {new Date(profile.updatedAt).toLocaleDateString("en-US")}</p></div>
        {editable ? <ProfileControls detail={detail} busy={busy} onSave={(patch) => onCommand("profile", patch)} /> : null}
      </header>
      <section className={styles.detailSection}><h3>Contact methods</h3><div className={styles.identityList}>{profile.identities.map((identity) => { const Icon = identityIcon(identity.kind); return <div key={`${identity.kind}-${identity.display}`}><Icon size={18} aria-hidden="true" /><span>{identity.display}</span><small>{identity.verified ? "Verified" : "Unverified"}</small></div>; })}</div></section>
      {editable ? (
        <CustomerSettings
          detail={detail}
          props={props}
          busy={busy}
          onPreference={(key, value, expectedVersion) => onCommand("preference_set", { key, value, expectedVersion })}
          onClearPreference={(key, expectedVersion) => onCommand("preference_clear", { key, expectedVersion })}
          onSuppress={(channel, expectedVersion) => onCommand("suppress", { channel, expectedVersion })}
          onUnsuppress={(channel, expectedVersion) => onCommand("unsuppress", { channel, expectedVersion })}
          onAddTag={(tagId) => onCommand("tag_add", tagId)}
          onRemoveTag={(tagId) => onCommand("tag_remove", tagId)}
        />
      ) : (
        <div className={styles.detailColumns}><section className={styles.detailSection}><h3>Appointment preferences</h3><p>Preferred contact: <strong>{profile.preferredContactMethod}</strong></p>{profile.preferences.map((preference) => <p key={preference.key}>{preference.key.replaceAll("_", " ")}: <strong>{preference.value}</strong></p>)}<p>Service ZIP: <strong>{profile.serviceAreaZip ?? "Not set"}</strong></p></section><section className={styles.detailSection}><h3>Tags and suppressions</h3><div className={styles.tags}>{profile.tags.map((tag) => <span key={tag.id}><Tag size={14} aria-hidden="true" />{tag.label}</span>)}</div>{profile.suppressions.filter((item) => item.active).map((item) => <p key={item.channel}><ShieldAlert size={16} aria-hidden="true" />{item.channel}: {item.reasonCode.replaceAll("_", " ")}</p>)}</section></div>
      )}
      <section className={styles.detailSection}><h3>Related work</h3><div className={styles.summaryGrid}><span><strong>{profile.relatedRecords.leadCount}</strong> leads</span><span><strong>{profile.relatedRecords.openTaskCount}</strong> open tasks</span><span><strong>{profile.relatedRecords.serviceEventCount}</strong> service events</span></div></section>
      <Activity detail={detail} />
      {props.access.canReviewMerge && detail.mergeSuggestions.length > 0 ? <section className={styles.detailSection} data-customer-duplicate-review><h3>Duplicate review</h3>{detail.mergeSuggestions.map((suggestion) => <div className={styles.reviewRow} key={suggestion.id}><div><strong>{suggestion.candidateDisplayName}</strong><span>{suggestion.confidence} confidence - {suggestion.state}</span></div>{suggestion.state === "suggested" ? <div className={styles.inlineActions}><button type="button" className={styles.secondaryButton} onClick={() => setConfirmation({ kind: "accept", suggestion })}>Accept duplicate</button><button type="button" className={styles.secondaryButton} onClick={() => setConfirmation({ kind: "reject", suggestion })}>Reject duplicate</button></div> : null}{suggestion.state === "accepted" ? <button type="button" className={styles.secondaryButton} onClick={() => setConfirmation({ kind: "execute", suggestion })}><Merge size={17} aria-hidden="true" />Execute accepted merge</button> : null}</div>)}</section> : null}
      {(detail.exportJobs.length > 0 || detail.deletionRequest) ? <section className={styles.detailSection} data-customer-job-states><h3>Data request jobs</h3><ul className={styles.jobList}>{detail.exportJobs.map((job) => <li key={job.id}><strong>{jobLabels.export[job.state]}</strong><span>Requested {new Date(job.requestedAt).toLocaleDateString("en-US")}</span></li>)}{detail.deletionRequest ? <li><strong>{jobLabels.deletion[detail.deletionRequest.state]}</strong><span>Requested {new Date(detail.deletionRequest.requestedAt).toLocaleDateString("en-US")}</span></li> : null}</ul></section> : null}
      <section className={styles.sensitiveActions} aria-label="Customer data actions">{props.access.canExport ? <button type="button" className={styles.secondaryButton} disabled={busy} onClick={() => onCommand("export")}><Download size={17} aria-hidden="true" />Request export</button> : null}{props.access.canRequestDeletion && props.mode !== "read_only" ? <DestructiveActionGuard triggerLabel="Request deletion" title="Request customer deletion?" description="This request is reviewed before customer data is removed." confirmLabel="Submit deletion request" reasonLabel="Reason for deletion" requireReason onConfirm={(reason) => onCommand("deletion", reason)} /> : null}</section>
      {confirmation ? <ConfirmationDialog
        title={confirmation.kind === "execute" ? "Merge accepted duplicate?" : confirmation.kind === "accept" ? "Accept duplicate suggestion?" : "Reject duplicate suggestion?"}
        description={confirmation.kind === "execute" ? "This executes the accepted merge and cannot be treated as review only." : "This records the review decision. Accepting does not execute the merge."}
        confirmLabel={confirmation.kind === "execute" ? "Confirm merge execution" : confirmation.kind === "accept" ? "Confirm accept" : "Confirm reject"}
        onCancel={() => setConfirmation(null)}
        onConfirm={() => { onCommand(confirmation.kind === "execute" ? "merge_execute" : "merge_review", { suggestion: confirmation.suggestion, decision: confirmation.kind }); setConfirmation(null); }}
      /> : null}
    </article>
  );
}

function SavedSegmentManager({ segments, selectedId, name, filter, busy, canShare, onSelect, onName, onFilter, onCreate, onUpdate, onRemove }: {
  readonly segments: readonly CustomerSavedSegment[];
  readonly selectedId: string;
  readonly name: string;
  readonly filter: CustomerSegmentFilter;
  readonly busy: boolean;
  readonly canShare: boolean;
  readonly onSelect: (id: string) => void;
  readonly onName: (value: string) => void;
  readonly onFilter: (filter: CustomerSegmentFilter) => void;
  readonly onCreate: (shared: boolean) => void;
  readonly onUpdate: (shared: boolean) => void;
  readonly onRemove: () => void;
}) {
  const [shared, setShared] = useState(false);
  const [field, setField] = useState<CustomerSegmentFilter["clauses"][number]["field"]>("lifecycle_state");
  const [operator, setOperator] = useState<CustomerSegmentFilter["clauses"][number]["operator"]>("equals");
  const [value, setValue] = useState("");
  function addClause() {
    if (filter.clauses.length >= 20 || (operator !== "is_empty" && !value.trim())) return;
    onFilter({ version: 1, conjunction: filter.conjunction, clauses: [...filter.clauses, { field, operator, ...(operator === "is_empty" ? {} : { value: value.trim() }) }] });
    setValue("");
  }
  return <section className={styles.segmentManager} data-builder-customer-segment-manager>
    <div><strong>User-saved segments</strong><span>{filter.clauses.length} of 20 filter clauses</span></div>
    <label><span>Saved segment name</span><input aria-label="Saved segment name" value={name} maxLength={80} onChange={(event) => onName(event.currentTarget.value)} /></label>
    <label><span>Edit existing</span><select aria-label="Saved segment to edit" value={selectedId} onChange={(event) => onSelect(event.currentTarget.value)}><option value="">New segment</option>{segments.map((segment) => <option key={segment.id} value={segment.id}>{segment.name}</option>)}</select></label>
    <div className={styles.clauseBuilder}>
      <select aria-label="Segment clause field" value={field} onChange={(event) => setField(event.currentTarget.value as typeof field)}><option value="lifecycle_state">Lifecycle state</option><option value="preferred_contact_method">Preferred contact</option><option value="tag_id">Tag</option><option value="service_area_zip">Service ZIP</option><option value="created_at">Created date</option><option value="updated_at">Updated date</option></select>
      <select aria-label="Segment clause operator" value={operator} onChange={(event) => setOperator(event.currentTarget.value as typeof operator)}><option value="equals">Equals</option><option value="not_equals">Does not equal</option><option value="contains">Contains</option><option value="before">Before</option><option value="after">After</option><option value="is_empty">Is empty</option></select>
      <input aria-label="Segment clause value" value={value} disabled={operator === "is_empty"} maxLength={160} onChange={(event) => setValue(event.currentTarget.value)} />
      <button type="button" className={styles.secondaryButton} disabled={filter.clauses.length >= 20 || (operator !== "is_empty" && !value.trim())} onClick={addClause}>Add filter clause</button>
    </div>
    {filter.clauses.length ? <ul className={styles.clauseList}>{filter.clauses.map((clause, index) => <li key={`${clause.field}-${index}`}><span>{clause.field.replaceAll("_", " ")} {clause.operator.replaceAll("_", " ")} {typeof clause.value === "string" ? clause.value : ""}</span><button type="button" className={styles.iconButton} aria-label={`Remove filter clause ${index + 1}`} onClick={() => onFilter({ ...filter, clauses: filter.clauses.filter((_, clauseIndex) => clauseIndex !== index) })}><X size={16} aria-hidden="true" /></button></li>)}</ul> : null}
    {canShare ? <label className={styles.checkLabel}><input type="checkbox" checked={shared} onChange={(event) => setShared(event.currentTarget.checked)} />Share with site</label> : null}
    <div className={styles.segmentActions}><button type="button" className={styles.primaryButton} disabled={busy || !name.trim() || Boolean(selectedId)} onClick={() => onCreate(shared)}>Create saved segment</button><button type="button" className={styles.secondaryButton} disabled={busy || !selectedId || !name.trim()} onClick={() => onUpdate(shared)}>Update saved segment</button><button type="button" className={styles.secondaryButton} disabled={busy || !selectedId} onClick={onRemove}><Trash2 size={16} aria-hidden="true" />Remove saved segment</button></div>
  </section>;
}

const emptySegmentFilter: CustomerSegmentFilter = { version: 1, conjunction: "all", clauses: [] };

export function CustomersWorkspace(props: CustomersWorkspaceProps) {
  const demo = props.mode === "demo";
  const [page, setPage] = useState<CustomerPage | undefined>(() => demo ? CUSTOMER_DEMO_PAGE : props.initialPage);
  const [detail, setDetail] = useState<CustomerWorkspaceDetail | undefined>(() => demo ? CUSTOMER_DEMO_DETAIL : props.initialCustomer);
  const [segments, setSegments] = useState<readonly CustomerSavedSegment[]>(props.savedSegments);
  const [search, setSearch] = useState("");
  const [segmentId, setSegmentId] = useState("");
  const [message, setMessage] = useState("");
  const [segmentManagerOpen, setSegmentManagerOpen] = useState(false);
  const [editingSegmentId, setEditingSegmentId] = useState("");
  const [segmentName, setSegmentName] = useState("");
  const [segmentFilter, setSegmentFilter] = useState<CustomerSegmentFilter>(emptySegmentFilter);
  const [isPending, startTransition] = useTransition();

  useEffect(() => setSegments(props.savedSegments), [props.savedSegments]);

  function announce(result: CustomerWorkspaceCommandResult, success: string) { setMessage(commandMessage(result, success)); }
  async function command(operation: () => Promise<CustomerWorkspaceCommandResult>, pending: string, success: string) {
    if (demo) { setMessage(`${success} Demo data remains local.`); return; }
    setMessage(pending);
    try { announce(await operation(), success); } catch { setMessage("The customer action could not be completed."); }
  }

  function submitSearch(event: FormEvent) {
    event.preventDefault();
    props.onUrlStateChange({ ...(search ? { search } : {}), ...(segmentId ? { segmentId } : {}) });
    if (!demo) startTransition(async () => setPage(await props.api.list({ ...(search ? { search } : {}), ...(segmentId ? { segmentId } : {}) })));
  }
  function openCustomer(customerId: string) {
    props.onUrlStateChange({ customerId, ...(search ? { search } : {}), ...(segmentId ? { segmentId } : {}) });
    if (detail?.profile.id === customerId) return;
    if (demo) setDetail(customerId === CUSTOMER_DEMO_DETAIL.profile.id ? CUSTOMER_DEMO_DETAIL : undefined);
    else startTransition(async () => setDetail((await props.api.get(customerId)) ?? undefined));
  }
  function closeDetail() { setDetail(undefined); props.onUrlStateChange({ ...(search ? { search } : {}), ...(segmentId ? { segmentId } : {}) }); }

  function runCustomerCommand(action: string, payload?: unknown) {
    if (!detail) { setMessage("Customer details are unavailable."); return; }
    const customerId = detail.profile.id;
    const version = detail.profile.version;
    const value = payload as Record<string, unknown> | undefined;
    if (action === "profile") void command(() => props.api.updateProfile({ customerId, expectedVersion: version, patch: payload as Parameters<CustomersWorkspaceProps["api"]["updateProfile"]>[0]["patch"] }), "Saving profile...", "Customer profile updated.");
    else if (action === "preference_set") void command(() => props.api.setPreference({ customerId, key: String(value?.key), value: String(value?.value), expectedVersion: Number(value?.expectedVersion) }), "Saving preference...", "Preference saved.");
    else if (action === "preference_clear") void command(() => props.api.clearPreference({ customerId, key: String(value?.key), expectedVersion: Number(value?.expectedVersion) }), "Clearing preference...", "Preference cleared.");
    else if (action === "suppress") void command(() => props.api.suppress({ customerId, channel: value?.channel as "email" | "sms", reasonCode: "customer_request", expectedVersion: Number(value?.expectedVersion) }), "Applying suppression...", "Channel suppressed.");
    else if (action === "unsuppress") void command(() => props.api.unsuppress({ customerId, channel: value?.channel as "email" | "sms", expectedVersion: Number(value?.expectedVersion) }), "Removing suppression...", "Channel unsuppressed.");
    else if (action === "tag_add") void command(() => props.api.addTag({ customerId, tagId: String(payload), expectedVersion: version }), "Adding tag...", "Tag added.");
    else if (action === "tag_remove") void command(() => props.api.removeTag({ customerId, tagId: String(payload), expectedVersion: version }), "Removing tag...", "Tag removed.");
    else if (action === "export") void command(() => props.api.requestExport({ customerIds: [customerId] }), "Requesting export...", "Export request queued.");
    else if (action === "deletion") void command(() => props.api.requestDeletion({ customerId, reason: String(payload ?? "") }), "Submitting deletion request...", "Deletion request recorded for review.");
    else if (action === "merge_review") {
      const review = payload as { readonly suggestion: CustomerMergeSuggestionView; readonly decision: "accept" | "reject" };
      void command(() => props.api.reviewMerge({ suggestionId: review.suggestion.id, expectedVersion: review.suggestion.version, decision: review.decision }), "Recording duplicate review...", review.decision === "accept" ? "Duplicate review accepted. Merge execution still requires confirmation." : "Duplicate suggestion rejected.");
    } else if (action === "merge_execute") {
      const execute = payload as { readonly suggestion: CustomerMergeSuggestionView };
      void command(() => props.api.executeMerge({ suggestionId: execute.suggestion.id, sourceId: execute.suggestion.candidateCustomerId, targetId: customerId, expectedSourceVersion: execute.suggestion.candidateCustomerVersion, expectedTargetVersion: version }), "Executing accepted merge...", "Accepted merge executed.");
    }
  }

  function selectSegmentForEdit(id: string) { const selected = segments.find((segment) => segment.id === id); setEditingSegmentId(id); setSegmentName(selected?.name ?? ""); setSegmentFilter(selected?.filter ?? emptySegmentFilter); }
  async function saveSegment(update: boolean, shared: boolean) {
    const validation = validateCustomerSavedSegmentFilter(segmentFilter);
    if (!validation.ok) { setMessage(validation.code === "too_many_clauses" ? "Saved segments support at most 20 filter clauses." : "The saved segment filter is invalid."); return; }
    const selected = segments.find((segment) => segment.id === editingSegmentId);
    if (demo) { setMessage("Saved segment stored in demo data only."); return; }
    setMessage(update ? "Updating saved segment..." : "Creating saved segment...");
    const result = await props.api.saveSegment({ ...(update && selected ? { segmentId: selected.id, expectedVersion: selected.version ?? 1 } : {}), name: segmentName.trim(), shared: props.access.canShareSegments && shared, filter: validation.value });
    announce(result, update ? "Saved segment updated." : "Saved segment created.");
    if (result.status === "applied") {
      const next: CustomerSavedSegment = { id: update && selected ? selected.id : result.resourceId ?? `local-segment-${segments.length + 1}`, name: segmentName.trim(), shared: props.access.canShareSegments && shared, filter: validation.value, version: result.version ?? (selected?.version ?? 0) + 1 };
      setSegments((current) => update ? current.map((segment) => segment.id === next.id ? next : segment) : [...current, next]);
      if (!update) { setSegmentName(""); setEditingSegmentId(""); }
    }
  }
  async function removeSegment() {
    const selected = segments.find((segment) => segment.id === editingSegmentId);
    if (!selected) return;
    if (demo) { setMessage("Saved segment removed from demo data."); return; }
    setMessage("Removing saved segment...");
    const result = await props.api.removeSegment({ segmentId: selected.id, expectedVersion: selected.version ?? 1 });
    announce(result, "Saved segment removed.");
    if (result.status === "applied") { setSegments((current) => current.filter((segment) => segment.id !== selected.id)); setEditingSegmentId(""); setSegmentName(""); }
  }
  function resetDemo() { setPage(CUSTOMER_DEMO_PAGE); setDetail(CUSTOMER_DEMO_DETAIL); setSegments(props.savedSegments); setSearch(""); setSegmentId(""); setMessage("Sample data reset."); props.onResetDemo(); }

  const denied = props.mode === "denied" || !props.access.canRead;
  const mutable = props.mode !== "read_only" && props.access.canUpdate;
  return (
    <section className={styles.workspace} data-builder-customers-workspace data-customers-mode={props.mode} data-customer-scope={props.access.scope}>
      <WorkspaceHeader eyebrow="Growth" title="Customers" description="Profiles, preferences, related work, and privacy requests." status={props.mode === "read_only" ? "Read-only access" : undefined} />
      {demo ? <DemoBanner moduleName="Customers" onReset={resetDemo} /> : null}
      {message ? <p className={styles.status} role="status" aria-live="polite">{message}</p> : null}
      {props.mode === "loading" ? <section className={styles.state} role="status"><UserRound size={22} aria-hidden="true" /><div><h3>Loading customers</h3><p>Retrieving authorized customer profiles.</p></div></section> : null}
      {props.mode === "error" ? <section className={styles.state} role="alert"><AlertTriangle size={22} aria-hidden="true" /><div><h3>Customers unavailable</h3><p>{props.errorMessage ?? "Try again shortly."}</p></div></section> : null}
      {denied ? <section className={styles.state}><ShieldAlert size={22} aria-hidden="true" /><div><h3>Customers access is not available</h3><p>Your current role does not include customer records.</p></div></section> : null}
      {!denied && props.mode !== "error" && props.mode !== "loading" ? <div className={`${styles.layout} ${detail ? styles.hasDetail : ""}`} aria-busy={isPending}>
        <section className={styles.listPane} data-builder-customers-list>
          <form className={styles.toolbar} onSubmit={submitSearch}><label><span>Search customers</span><div><Search size={17} aria-hidden="true" /><input aria-label="Search customers" value={search} maxLength={120} onChange={(event) => setSearch(event.currentTarget.value)} /></div></label><label><span>Saved segment</span><select value={segmentId} onChange={(event) => setSegmentId(event.currentTarget.value)}><option value="">All customers</option>{segments.map((segment) => <option key={segment.id} value={segment.id}>{segment.name}{segment.shared ? " - Shared" : ""}</option>)}</select></label><button type="submit" className={styles.primaryButton}>Apply</button>{props.access.canExport ? <button type="button" className={styles.iconButton} aria-label="Request export" title="Request export" onClick={() => void command(() => props.api.requestExport({ ...(segmentId ? { segmentId } : {}) }), "Requesting export...", "Export request queued.")}><Download size={18} aria-hidden="true" /></button> : null}</form>
          {mutable ? <button type="button" className={styles.manageSegmentsButton} aria-expanded={segmentManagerOpen} onClick={() => setSegmentManagerOpen((open) => !open)}>Manage saved segments</button> : null}
          {segmentManagerOpen && mutable ? <SavedSegmentManager segments={segments} selectedId={editingSegmentId} name={segmentName} filter={segmentFilter} busy={isPending} canShare={props.access.canShareSegments} onSelect={selectSegmentForEdit} onName={setSegmentName} onFilter={setSegmentFilter} onCreate={(shared) => void saveSegment(false, shared)} onUpdate={(shared) => void saveSegment(true, shared)} onRemove={() => void removeSegment()} /> : null}
          <div className={styles.customerRows}>{page?.items.length ? page.items.map((item) => <CustomerRow key={item.id} item={item} selected={detail?.profile.id === item.id} onOpen={() => openCustomer(item.id)} />) : <div className={styles.empty}><UserRound size={22} aria-hidden="true" /><strong>No customers found</strong><span>Adjust the search or segment.</span></div>}</div>
          {page?.nextCursor ? <button type="button" className={styles.loadMore} onClick={() => startTransition(async () => setPage(await props.api.list({ ...(search ? { search } : {}), ...(segmentId ? { segmentId } : {}), cursor: page.nextCursor })))}>Load more</button> : null}
        </section>
        {detail ? <CustomerDetail detail={detail} props={props} busy={isPending} onBack={closeDetail} onCommand={runCustomerCommand} /> : <section className={styles.detailPlaceholder}><UserRound size={28} aria-hidden="true" /><h2>Select a customer</h2><p>Profile and related work will appear here.</p></section>}
      </div> : null}
    </section>
  );
}
