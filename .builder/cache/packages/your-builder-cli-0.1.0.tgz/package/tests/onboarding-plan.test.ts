// @vitest-environment node

import { mkdtemp, mkdir, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";

import { afterEach, describe, expect, it } from "vitest";

import { inspectOnboardingProject } from "../src/onboarding/inspect.js";
import {
  OnboardingError,
  parseOnboardingApproval,
  parseOnboardingAttachmentPlan,
  parseOnboardingManifest,
  planOnboardingAttachment,
} from "../src/onboarding/index.js";

const temporaryDirectories: string[] = [];

async function review() {
  const projectDir = await mkdtemp(join(process.cwd(), ".tmp-onboarding-plan-"));
  temporaryDirectories.push(projectDir);
  await mkdir(join(projectDir, "app"), { recursive: true });
  await mkdir(join(projectDir, "out"), { recursive: true });
  await writeFile(join(projectDir, "app", "page.jsx"), "export default function Home() {}\n");
  await writeFile(join(projectDir, "out", "index.html"), "<main><h1>Local HVAC service</h1><img src=\"/divider.png\" alt=\"\"></main>");
  return inspectOnboardingProject({
    projectDir,
    manifest: parseOnboardingManifest({
      version: 1,
      site: {
        siteId: "local-hvac-staging",
        stableSiteKey: "local-hvac",
        framework: "next-app-router",
        editorPath: "/admin/editor",
      },
      routes: [{ path: "/", pageSlug: "home", source: "app/page.jsx", renderedArtifact: "out/index.html" }],
      modules: [{ id: "growth.leads", version: "1.0.0" }],
    }),
  });
}

afterEach(async () => {
  await Promise.all(temporaryDirectories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })));
});

describe("Phase 2D onboarding approval planning", () => {
  it("binds grouped stable mappings and explicit exclusions to an immutable review", async () => {
    const report = await review();
    const editable = report.candidates.find((candidate) => candidate.category === "editableRegion")!;
    const excluded = report.candidates.filter((candidate) => candidate.id !== editable.id);
    const approval = parseOnboardingApproval({
      version: 1,
      reviewId: report.reviewId,
      mappings: [{
        stableId: "home.hero.title",
        category: "editableRegion",
        kind: "text",
        candidateIds: [editable.id],
      }],
      exclusions: [{
        reason: "decorative",
        candidateIds: excluded.map((candidate) => candidate.id),
      }],
    });

    const first = planOnboardingAttachment({ report, approval });
    const second = planOnboardingAttachment({ report, approval });

    expect(first).toEqual(second);
    expect(first.planId).toMatch(/^[a-f0-9]{64}$/);
    expect(first.reviewId).toBe(report.reviewId);
    expect(first.mappings).toEqual([expect.objectContaining({ stableId: "home.hero.title" })]);
    expect(first.safety).toEqual({ clientSourceMutated: false, remoteSystemsMutated: false });
    expect(parseOnboardingAttachmentPlan(first)).toEqual(first);
    expect(() => parseOnboardingAttachmentPlan({ ...first, patchSummary: ["tampered"] }))
      .toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "stale_review" }));
  });

  it("rejects stale, incomplete, duplicate, and unknown candidate decisions", async () => {
    const report = await review();
    const candidateIds = report.candidates.map((candidate) => candidate.id);
    const base = {
      version: 1,
      reviewId: report.reviewId,
      mappings: [{
        stableId: "home.content.primary",
        category: "editableRegion",
        candidateIds,
      }],
      exclusions: [],
    };

    expect(() => planOnboardingAttachment({ report, approval: parseOnboardingApproval({ ...base, reviewId: "0".repeat(64) }) }))
      .toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "stale_review" }));
    expect(() => planOnboardingAttachment({ report, approval: parseOnboardingApproval({ ...base, mappings: [{ ...base.mappings[0], candidateIds: candidateIds.slice(1) }] }) }))
      .toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "incomplete_approval" }));
    expect(() => planOnboardingAttachment({ report, approval: parseOnboardingApproval({ ...base, exclusions: [{ reason: "decorative", candidateIds: [candidateIds[0]] }] }) }))
      .toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "duplicate_decision" }));
    expect(() => planOnboardingAttachment({ report, approval: parseOnboardingApproval({ ...base, mappings: [{ ...base.mappings[0], candidateIds: ["missing.candidate"] }] }) }))
      .toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "unknown_candidate" }));
    const typedCandidate = report.candidates.find((candidate) => candidate.kind)!;
    const remaining = candidateIds.filter((candidateId) => candidateId !== typedCandidate.id);
    expect(() => planOnboardingAttachment({
      report,
      approval: parseOnboardingApproval({
        ...base,
        mappings: [{
          ...base.mappings[0],
          kind: typedCandidate.kind === "image" ? "text" : "image",
          candidateIds: [typedCandidate.id],
        }],
        exclusions: [{ reason: "out-of-scope", candidateIds: remaining }],
      }),
    })).toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "kind_conflict" }));
  });
});
