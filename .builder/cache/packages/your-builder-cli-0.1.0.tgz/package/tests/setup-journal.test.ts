import {
  chmod,
  lstat,
  mkdtemp,
  readFile,
  readdir,
  rm,
  symlink,
  unlink,
  writeFile,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, describe, expect, it } from "vitest";

import {
  SETUP_JOURNAL_PATH,
  SetupJournalError,
  createSetupJournalStore,
  parseSetupJournal,
  type SetupJournalStoreOptions,
} from "../src/control-plane/setup-journal.js";
import type {
  WindowsAclAdapter,
  WindowsAclSnapshot,
} from "../src/control-plane/protected-files.js";

const temporaryDirectories: string[] = [];
const INSTALLATION_ID = "11111111-1111-4111-8111-111111111111";
const PROJECT_FINGERPRINT = "a".repeat(64);
const RECEIPT_DIGEST = "b".repeat(64);

async function temporaryProject(): Promise<string> {
  const path = await mkdtemp(join(tmpdir(), "builder-setup-journal-"));
  temporaryDirectories.push(path);
  return path;
}

afterEach(async () => {
  await Promise.all(temporaryDirectories.splice(0).map((path) =>
    rm(path, { recursive: true, force: true })
  ));
});

function identity() {
  return {
    projectFingerprint: PROJECT_FINGERPRINT,
    stableSiteKey: "garcia-brothers-hvac",
    publicUrl: "https://garcia-brothers-private-staging.netlify.app/",
    controlPlaneUrl: "https://site-editor-control-plane-staging.netlify.app",
    installationId: INSTALLATION_ID,
    acceptedKeyId: "installation:key-safe",
    hostingMode: "manual" as const,
  };
}

function ownerOnlySnapshot(sid = "S-1-5-21-owner"): WindowsAclSnapshot {
  return {
    ownerSid: sid,
    inheritanceDisabled: true,
    isReparsePoint: false,
    entries: [{ sid, allow: true, inherited: false, fullControl: true }],
  };
}

class MutableWindowsAcl implements WindowsAclAdapter {
  unsafe = false;

  async currentUserSid(): Promise<string> {
    return "S-1-5-21-owner";
  }

  async protect(): Promise<void> {}

  async inspect(): Promise<WindowsAclSnapshot> {
    return this.unsafe
      ? { ...ownerOnlySnapshot(), inheritanceDisabled: false }
      : ownerOnlySnapshot();
  }
}

function testOptions(now: () => Date): SetupJournalStoreOptions {
  return process.platform === "win32"
    ? { now, platform: "win32", protectedFiles: { windowsAcl: new MutableWindowsAcl() } }
    : { now };
}

describe.sequential("setup journal", () => {
  it("creates the exact protected journal schema and resumes the same identity", async () => {
    const projectDir = await temporaryProject();
    let now = new Date("2026-07-19T12:00:00.000Z");
    const store = await createSetupJournalStore(projectDir, testOptions(() => now));

    const created = await store.initialize(identity());
    now = new Date("2026-07-19T12:01:00.000Z");

    expect(await store.initialize(identity())).toEqual(created);
    expect(await store.read()).toEqual({
      schemaVersion: 1,
      ...identity(),
      stage: "registration_accepted",
      receiptDigest: null,
      createdAt: "2026-07-19T12:00:00.000Z",
      updatedAt: "2026-07-19T12:00:00.000Z",
      lastErrorCode: null,
    });
    expect(JSON.parse(await readFile(join(projectDir, SETUP_JOURNAL_PATH), "utf8")))
      .toEqual(created);
  });

  it("updates only bounded retry state through an atomic protected sibling", async () => {
    const projectDir = await temporaryProject();
    let now = new Date("2026-07-19T12:00:00.000Z");
    const store = await createSetupJournalStore(projectDir, testOptions(() => now));
    await store.initialize(identity());
    now = new Date("2026-07-19T12:02:00.000Z");

    const updated = await store.update({
      stage: "hosting_confirmation_pending",
      receiptDigest: RECEIPT_DIGEST,
      lastErrorCode: "hosting_confirmation_required",
    });

    expect(updated).toMatchObject({
      ...identity(),
      stage: "hosting_confirmation_pending",
      receiptDigest: RECEIPT_DIGEST,
      createdAt: "2026-07-19T12:00:00.000Z",
      updatedAt: "2026-07-19T12:02:00.000Z",
      lastErrorCode: "hosting_confirmation_required",
    });
    expect(await readdir(join(projectDir, ".builder", "secrets", "installation-setup")))
      .toEqual(["journal.json"]);
  });

  it("completes a matching manual handoff once and remains idempotent after removal", async () => {
    const projectDir = await temporaryProject();
    const store = await createSetupJournalStore(projectDir, testOptions(
      () => new Date("2026-07-19T12:00:00.000Z"),
    ));
    await store.initialize(identity());
    await store.update({
      stage: "hosting_verification_pending",
      receiptDigest: RECEIPT_DIGEST,
    });

    await expect(store.completeManualHandoff(RECEIPT_DIGEST)).resolves.toBe(true);
    await expect(store.read()).resolves.toBeNull();
    await expect(store.completeManualHandoff(RECEIPT_DIGEST)).resolves.toBe(false);
  });

  it("rejects identity drift and leaves the accepted journal unchanged", async () => {
    const projectDir = await temporaryProject();
    const store = await createSetupJournalStore(projectDir, testOptions(
      () => new Date("2026-07-19T12:00:00.000Z"),
    ));
    const accepted = await store.initialize(identity());

    await expect(store.initialize({ ...identity(), stableSiteKey: "different-site" }))
      .rejects.toMatchObject({ code: "setup_journal_conflict" });
    expect(await store.read()).toEqual(accepted);
  });

  it.each([
    ["exchange token", { exchangeToken: "exchange-secret-canary" }],
    ["private JWK", { privateJwk: { d: "private-secret-canary" } }],
    ["provider access token", { providerAccessToken: "provider-secret-canary" }],
    ["environment values", { environment: { PRIVATE: "environment-secret-canary" } }],
    ["command output", { commandOutput: "command-secret-canary" }],
    ["raw provider error", { rawError: "provider failed with secret-canary" }],
  ])("rejects a %s field instead of persisting it", async (_label, forbidden) => {
    const projectDir = await temporaryProject();
    const store = await createSetupJournalStore(projectDir, testOptions(
      () => new Date("2026-07-19T12:00:00.000Z"),
    ));

    await expect(store.initialize({ ...identity(), ...forbidden } as never))
      .rejects.toMatchObject({ code: "setup_journal_invalid" });
    expect(await store.read()).toBeNull();
  });

  it("accepts only exact stages, safe error codes, digests, and timestamps", () => {
    const valid = {
      schemaVersion: 1,
      ...identity(),
      stage: "hosting_verification_pending",
      receiptDigest: RECEIPT_DIGEST,
      createdAt: "2026-07-19T12:00:00.000Z",
      updatedAt: "2026-07-19T12:01:00.000Z",
      lastErrorCode: "hosting_verification_failed",
    };

    expect(parseSetupJournal(valid)).toEqual(valid);
    for (const invalid of [
      { ...valid, stage: "provider said secret-canary" },
      { ...valid, lastErrorCode: "raw provider error: secret-canary" },
      { ...valid, receiptDigest: "secret-canary" },
      { ...valid, updatedAt: "not-a-timestamp" },
      { ...valid, controlPlaneUrl: "https://control.example.com/?token=secret-canary" },
      { ...valid, unknown: true },
    ]) {
      expect(() => parseSetupJournal(invalid)).toThrowError(
        expect.objectContaining({ code: "setup_journal_invalid" }),
      );
    }
  });

  it("maps corrupt JSON and parser details to one safe error", async () => {
    const projectDir = await temporaryProject();
    const store = await createSetupJournalStore(projectDir, testOptions(
      () => new Date("2026-07-19T12:00:00.000Z"),
    ));
    await store.initialize(identity());
    await writeFile(join(projectDir, SETUP_JOURNAL_PATH), "private-secret-canary{");

    const error = await store.read().catch((caught: unknown) => caught);
    expect(error).toBeInstanceOf(SetupJournalError);
    expect(error).toMatchObject({ code: "setup_journal_invalid" });
    expect(String(error)).not.toContain("private-secret-canary");
  });

  it.skipIf(process.platform === "win32")(
    "fails closed when Unix directory protection drifts",
    async () => {
      const projectDir = await temporaryProject();
      const store = await createSetupJournalStore(projectDir, testOptions(
        () => new Date("2026-07-19T12:00:00.000Z"),
      ));
      await store.initialize(identity());
      await chmod(join(projectDir, ".builder", "secrets", "installation-setup"), 0o755);

      await expect(store.read()).rejects.toMatchObject({
        code: "setup_journal_protected_storage_unavailable",
      });
    },
  );

  it("fails closed when a Windows ACL drifts before a read or write", async () => {
    const projectDir = await temporaryProject();
    const windowsAcl = new MutableWindowsAcl();
    const store = await createSetupJournalStore(projectDir, {
      platform: "win32",
      protectedFiles: { windowsAcl },
      now: () => new Date("2026-07-19T12:00:00.000Z"),
    });
    await store.initialize(identity());
    windowsAcl.unsafe = true;

    await expect(store.read()).rejects.toMatchObject({
      code: "setup_journal_protected_storage_unavailable",
    });
    await expect(store.update({ stage: "hosting_detection_pending" })).rejects.toMatchObject({
      code: "setup_journal_protected_storage_unavailable",
    });
  });

  it("rejects a symlinked journal without reading its target", async () => {
    const projectDir = await temporaryProject();
    const store = await createSetupJournalStore(projectDir, testOptions(
      () => new Date("2026-07-19T12:00:00.000Z"),
    ));
    await store.initialize(identity());
    const outside = join(projectDir, "outside.json");
    await writeFile(outside, JSON.stringify({ rawError: "outside-secret-canary" }));
    await unlink(join(projectDir, SETUP_JOURNAL_PATH));
    try {
      await symlink(outside, join(projectDir, SETUP_JOURNAL_PATH), "file");
    } catch (error) {
      if (["EPERM", "EACCES", "ENOTSUP"].includes((error as NodeJS.ErrnoException).code ?? "")) return;
      throw error;
    }

    await expect(store.read()).rejects.toMatchObject({
      code: "setup_journal_protected_storage_unavailable",
    });
    expect((await lstat(join(projectDir, SETUP_JOURNAL_PATH))).isSymbolicLink()).toBe(true);
  });
});
