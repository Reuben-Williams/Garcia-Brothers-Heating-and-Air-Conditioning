// @vitest-environment node

import { mkdtemp, mkdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

import { afterEach, describe, expect, it } from "vitest";

import { scanFoundationSecretBoundaries } from "../src/foundation/secret-boundary.js";

const temporaryDirectories: string[] = [];
const CANARIES = {
  siteServiceRole: "canary_site_service_role_7ecda7af",
  installationPrivateJwk: "canary_installation_private_jwk_0a6e8dcb",
  controlPlaneSigningKey: "canary_control_plane_signing_key_d8c40cb1",
};

async function artifactTree() {
  const root = await mkdtemp(join(tmpdir(), "foundation-secret-boundary-"));
  temporaryDirectories.push(root);
  const surfaces = {
    browserHtml: [join(root, "browser-html")],
    staticAssets: [join(root, ".next", "static")],
    pageData: [join(root, "page-data")],
    playwrightArtifacts: [join(root, "test-results")],
    vitestSnapshots: [join(root, "__snapshots__")],
    capturedLogs: [join(root, "captured-logs")],
  };
  for (const paths of Object.values(surfaces)) await mkdir(paths[0]!, { recursive: true });
  await mkdir(join(root, ".next", "server"), { recursive: true });
  await writeFile(join(surfaces.browserHtml[0]!, "index.html"), "<main>safe</main>");
  await writeFile(join(surfaces.staticAssets[0]!, "app.js"), "console.log('safe')");
  await writeFile(join(surfaces.pageData[0]!, "page.rsc"), "safe page data");
  await writeFile(join(surfaces.playwrightArtifacts[0]!, "trace.zip"), Buffer.from("safe trace"));
  await writeFile(join(surfaces.playwrightArtifacts[0]!, "failure.png"), Buffer.from("safe screenshot"));
  await writeFile(join(surfaces.vitestSnapshots[0]!, "output.snap"), "safe snapshot");
  await writeFile(join(surfaces.capturedLogs[0]!, "acceptance.log"), "safe log");
  await writeFile(join(root, ".next", "server", "server-only.js"), CANARIES.siteServiceRole);
  return { root, surfaces };
}

afterEach(async () => {
  await Promise.all(temporaryDirectories.splice(0).map((path) =>
    rm(path, { recursive: true, force: true })));
});

describe("foundation secret boundary", () => {
  it("passes when canaries exist only in the intentionally excluded server bundle", async () => {
    const { surfaces } = await artifactTree();

    const report = await scanFoundationSecretBoundaries({ canaries: CANARIES, surfaces });

    expect(report.ok).toBe(true);
    expect(report.findings).toEqual([]);
    expect(report.scannedFiles).toBe(7);
    expect(JSON.stringify(report)).not.toContain(CANARIES.siteServiceRole);
  });

  it.each([
    ["browserHtml", "index.html", "installationPrivateJwk"],
    ["staticAssets", "app.js", "siteServiceRole"],
    ["pageData", "page.rsc", "controlPlaneSigningKey"],
    ["playwrightArtifacts", "trace.zip", "siteServiceRole"],
    ["playwrightArtifacts", "failure.png", "installationPrivateJwk"],
    ["vitestSnapshots", "output.snap", "controlPlaneSigningKey"],
    ["capturedLogs", "acceptance.log", "installationPrivateJwk"],
  ] as const)("detects a canary in %s/%s without echoing its value", async (surface, file, canaryId) => {
    const { surfaces } = await artifactTree();
    await writeFile(join(surfaces[surface][0]!, file), Buffer.from(`prefix:${CANARIES[canaryId]}:suffix`));

    const report = await scanFoundationSecretBoundaries({ canaries: CANARIES, surfaces });

    expect(report.ok).toBe(false);
    expect(report.findings).toContainEqual({
      surface,
      path: expect.stringContaining(file),
      canaryId,
    });
    expect(JSON.stringify(report)).not.toContain(CANARIES[canaryId]);
  });

  it("requires each recovery runbook to contain the exact operational sections", async () => {
    const requiredSections = [
      "## Detection signal",
      "## Immediate containment",
      "## Commands and UI actions",
      "## Evidence to preserve",
      "## Recovery verification",
      "## Rollback",
      "## Owner communication trigger",
      "## Audit requirement",
    ];
    for (const name of [
      "control-plane-outage.md",
      "installation-compromise.md",
      "provisioning-recovery.md",
    ]) {
      const text = await import("node:fs/promises").then(({ readFile }) =>
        readFile(resolve("docs", "runbooks", name), "utf8"));
      for (const section of requiredSections) expect(text).toContain(section);
      expect(text).not.toMatch(/(?:eyJ[a-zA-Z0-9_-]{20,}|sk_(?:live|test)_|service_role\s*=\s*\S+)/);
    }
  });

  it("ships a fixture-build canary scan that excludes server JavaScript", async () => {
    const script = await import("node:fs/promises").then(({ readFile }) =>
      readFile(resolve("scripts", "run-foundation-secret-scan.mjs"), "utf8"));

    expect(script).toContain("SUPABASE_SERVICE_ROLE_KEY");
    expect(script).toContain("BUILDER_INSTALLATION_PRIVATE_JWK");
    expect(script).toContain("CONTROL_PLANE_PRIVATE_SIGNING_KEY");
    expect(script).toContain("examples/local-business-next");
    expect(script).toContain(".next/static");
    expect(script).toContain("playwright-report");
    expect(script).toContain("test-results");
    expect(script).toContain("ComSpec");
    expect(script).not.toContain("npm.cmd");
    expect(script).not.toMatch(/scanTree\([^\n]*\.next[\\/]server["']/);
  });
});
