import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { applySourcePatch, recoverInterruptedApply } from "../src/migration/apply-source.js";
import { fingerprintSource } from "../src/scan/source-fingerprint.js";

const roots: string[] = [];
afterEach(async () => Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true }))));

describe("safe migration source apply", () => {
  it("refuses source drift before writing any file", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "builder-apply-"));
    roots.push(root);
    await writeFile(path.join(root, "existing.ts"), "user changed", "utf8");

    await expect(applySourcePatch({
      root,
      journalPath: ".builder/apply-journal.json",
      files: [
        { path: "existing.ts", expectedCurrentHash: fingerprintSource("original"), contents: "generated" },
        { path: "new.ts", expectedCurrentHash: null, contents: "new" },
      ],
    })).rejects.toThrow(/drift/i);

    await expect(readFile(path.join(root, "existing.ts"), "utf8")).resolves.toBe("user changed");
    await expect(readFile(path.join(root, "new.ts"), "utf8")).rejects.toThrow();
  });

  it("writes a durable journal and reversal patch for an approved apply", async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), "builder-apply-"));
    roots.push(root);
    await writeFile(path.join(root, "existing.ts"), "original", "utf8");

    const result = await applySourcePatch({
      root,
      journalPath: ".builder/apply-journal.json",
      files: [
        { path: "existing.ts", expectedCurrentHash: fingerprintSource("original"), contents: "generated" },
        { path: "nested/new.ts", expectedCurrentHash: null, contents: "new" },
      ],
    });

    expect(await readFile(path.join(root, "existing.ts"), "utf8")).toBe("generated");
    expect(result.reversal.files).toHaveLength(2);
    expect(result.journal.status).toBe("complete");

    await recoverInterruptedApply(root, result.journalPath, { forceCompleted: true });
    expect(await readFile(path.join(root, "existing.ts"), "utf8")).toBe("original");
    await expect(readFile(path.join(root, "nested/new.ts"), "utf8")).rejects.toThrow();
  });
});
