import { chmod, lstat, mkdtemp, readFile, readdir, stat, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, describe, expect, it, vi } from "vitest";

import { ProjectFilesystem } from "../src/control-plane/project-filesystem.js";
import {
  ProtectedFiles,
  ProtectedStorageError,
  type WindowsAclAdapter,
  type WindowsAclSnapshot,
} from "../src/control-plane/protected-files.js";

const temporaryDirectories: string[] = [];
const ROOT = join(".builder", "secrets");

async function temporaryProject(): Promise<string> {
  const path = await mkdtemp(join(tmpdir(), "builder-protected-files-"));
  temporaryDirectories.push(path);
  return path;
}

afterEach(async () => {
  vi.restoreAllMocks();
  const { rm } = await import("node:fs/promises");
  await Promise.all(temporaryDirectories.splice(0).map((path) =>
    rm(path, { recursive: true, force: true })
  ));
});

function ownerOnlySnapshot(sid = "S-1-5-21-owner"): WindowsAclSnapshot {
  return {
    ownerSid: sid,
    inheritanceDisabled: true,
    isReparsePoint: false,
    entries: [{ sid, allow: true, inherited: false, fullControl: true }],
  };
}

class FakeWindowsAcl implements WindowsAclAdapter {
  readonly protectedPaths: Array<{ path: string; kind: "directory" | "file" }> = [];
  readonly inspections = new Map<string, number>();

  constructor(
    readonly sid = "S-1-5-21-owner",
    readonly snapshot: (path: string, count: number) => WindowsAclSnapshot = () =>
      ownerOnlySnapshot(sid),
  ) {}

  async currentUserSid(): Promise<string> {
    return this.sid;
  }

  async protect(path: string, kind: "directory" | "file"): Promise<void> {
    this.protectedPaths.push({ path, kind });
  }

  async inspect(path: string): Promise<WindowsAclSnapshot> {
    const count = (this.inspections.get(path) ?? 0) + 1;
    this.inspections.set(path, count);
    return this.snapshot(path, count);
  }
}

async function openProtected(
  projectDir: string,
  options: { platform?: NodeJS.Platform; windowsAcl?: WindowsAclAdapter } = {},
): Promise<ProtectedFiles> {
  const files = await ProjectFilesystem.open(projectDir);
  const platform = options.platform ?? process.platform;
  return ProtectedFiles.open(files, ROOT, {
    platform,
    windowsAcl: options.windowsAcl ?? (platform === "win32" ? new FakeWindowsAcl() : undefined),
  });
}

describe.sequential("ProtectedFiles", () => {
  it.skipIf(process.platform === "win32")(
    "creates and verifies private Unix directories and files independently of umask",
    async () => {
      const projectDir = await temporaryProject();
      const previousUmask = process.umask(0o777);
      try {
        const files = await openProtected(projectDir);
        await files.writeExclusive(join(ROOT, "private.txt"), "secret");
      } finally {
        process.umask(previousUmask);
      }

      expect((await stat(join(projectDir, ROOT))).mode & 0o777).toBe(0o700);
      expect((await stat(join(projectDir, ROOT, "private.txt"))).mode & 0o777).toBe(0o600);
      expect(await readFile(join(projectDir, ROOT, "private.txt"), "utf8")).toBe("secret");
    },
  );

  it.skipIf(process.platform === "win32")(
    "fails closed when Unix protection changes before a protected read",
    async () => {
      const projectDir = await temporaryProject();
      const files = await openProtected(projectDir);
      const path = join(ROOT, "private.txt");
      await files.writeExclusive(path, "secret");
      await chmod(join(projectDir, ROOT), 0o755);

      await expect(files.read(path)).rejects.toMatchObject({ code: "protected_storage_unavailable" });
    },
  );

  it("creates and verifies owner-only Windows ACLs", async () => {
    const projectDir = await temporaryProject();
    const acl = new FakeWindowsAcl();
    const files = await openProtected(projectDir, { platform: "win32", windowsAcl: acl });

    await files.writeExclusive(join(ROOT, "private.txt"), "secret");

    expect(acl.protectedPaths.map(({ kind }) => kind)).toContain("directory");
    expect(acl.protectedPaths.map(({ kind }) => kind)).toContain("file");
    expect(await files.read(join(ROOT, "private.txt"))).toBe("secret");
  });

  it.each([
    ["unknown owner SID", () => ({ ...ownerOnlySnapshot(), ownerSid: "S-1-5-21-other" })],
    ["enabled inheritance", () => ({ ...ownerOnlySnapshot(), inheritanceDisabled: false })],
    ["inherited broad ACE", () => ({
      ...ownerOnlySnapshot(),
      entries: [
        ...ownerOnlySnapshot().entries,
        { sid: "S-1-1-0", allow: true, inherited: true, fullControl: false },
      ],
    })],
    ["broad Users access", () => ({
      ...ownerOnlySnapshot(),
      entries: [
        ...ownerOnlySnapshot().entries,
        { sid: "S-1-5-32-545", allow: true, inherited: false, fullControl: false },
      ],
    })],
    ["a reparse point", () => ({ ...ownerOnlySnapshot(), isReparsePoint: true })],
  ])("rejects %s during Windows ACL verification", async (_label, snapshot) => {
    const projectDir = await temporaryProject();
    const acl = new FakeWindowsAcl("S-1-5-21-owner", snapshot);

    await expect(openProtected(projectDir, { platform: "win32", windowsAcl: acl }))
      .rejects.toMatchObject({ code: "protected_storage_unavailable" });
  });

  it("fails closed when Windows SID or ACL lookup fails or times out", async () => {
    const projectDir = await temporaryProject();
    const failures: WindowsAclAdapter[] = [
      {
        currentUserSid: async () => { throw new Error("lookup failed: sensitive details"); },
        protect: async () => undefined,
        inspect: async () => ownerOnlySnapshot(),
      },
      {
        currentUserSid: async () => "S-1-5-21-owner",
        protect: async () => undefined,
        inspect: async () => { throw new Error("verification timeout: sensitive details"); },
      },
    ];

    for (const windowsAcl of failures) {
      const error = await openProtected(projectDir, { platform: "win32", windowsAcl })
        .catch((caught: unknown) => caught);
      expect(error).toBeInstanceOf(ProtectedStorageError);
      expect(error).toMatchObject({ code: "protected_storage_unavailable" });
      expect(String(error)).not.toContain("sensitive details");
    }
  });

  it("detects ACL mutation between directory verification and file creation", async () => {
    const projectDir = await temporaryProject();
    const root = join(projectDir, ROOT);
    const acl = new FakeWindowsAcl("S-1-5-21-owner", (path, count) => {
      if (path === root && count >= 3) {
        return {
          ...ownerOnlySnapshot(),
          entries: [
            ...ownerOnlySnapshot().entries,
            { sid: "S-1-1-0", allow: true, inherited: false, fullControl: false },
          ],
        };
      }
      return ownerOnlySnapshot();
    });
    const files = await openProtected(projectDir, { platform: "win32", windowsAcl: acl });
    const relativePath = join(ROOT, "private.txt");

    await expect(files.writeExclusive(relativePath, "secret"))
      .rejects.toMatchObject({ code: "protected_storage_unavailable" });
    await expect(readFile(join(projectDir, relativePath), "utf8")).rejects.toThrow();
  });

  it("creates files exclusively and permits only one concurrent creator", async () => {
    const projectDir = await temporaryProject();
    const files = await openProtected(projectDir);
    const path = join(ROOT, "private.txt");

    const results = await Promise.allSettled([
      files.writeExclusive(path, "first"),
      files.writeExclusive(path, "second"),
    ]);

    expect(results.filter(({ status }) => status === "fulfilled")).toHaveLength(1);
    expect(results.filter(({ status }) => status === "rejected")).toHaveLength(1);
    expect(["first", "second"]).toContain(await readFile(join(projectDir, path), "utf8"));
  });

  it("permits only one atomic claimant for an existing protected file", async () => {
    const projectDir = await temporaryProject();
    const files = await openProtected(projectDir);
    const source = join(ROOT, "installation-setup.lock");
    const claim = join(ROOT, "installation-setup.lock.recovery");
    await files.writeExclusive(source, "stale-lock");

    const results = await Promise.all([
      files.claimExisting(source, claim),
      files.claimExisting(source, claim),
    ]);

    expect(results.sort()).toEqual([false, true]);
    expect(await files.read(source)).toBe("stale-lock");
    expect(await files.read(claim)).toBe("stale-lock");
  });

  it("rejects symlink leaves without writing through them", async () => {
    const projectDir = await temporaryProject();
    const outside = join(projectDir, "outside.txt");
    await writeFile(outside, "unchanged");
    const files = await openProtected(projectDir);
    const link = join(projectDir, ROOT, "private.txt");
    try {
      await symlink(outside, link, "file");
    } catch (error) {
      if (["EPERM", "EACCES", "ENOTSUP"].includes((error as NodeJS.ErrnoException).code ?? "")) return;
      throw error;
    }

    await expect(files.writeExclusive(join(ROOT, "private.txt"), "changed"))
      .rejects.toMatchObject({ code: "protected_storage_unavailable" });
    expect(await readFile(outside, "utf8")).toBe("unchanged");
  });

  it("atomically replaces through a private sibling and leaves no staged file", async () => {
    const projectDir = await temporaryProject();
    const files = await openProtected(projectDir);
    const path = join(ROOT, "private.txt");
    await files.writeExclusive(path, "before");

    await files.writeAtomic(path, "after", ".private.crash.tmp");

    expect(await files.read(path)).toBe("after");
    expect(await readdir(join(projectDir, ROOT))).toEqual(["private.txt"]);
    expect((await lstat(join(projectDir, ROOT, "private.txt"))).isFile()).toBe(true);
  });

  it("fsyncs the protected parent directory after deleting a file", async () => {
    const projectDir = await temporaryProject();
    const files = await openProtected(projectDir, {
      platform: "win32",
      windowsAcl: new FakeWindowsAcl(),
    });
    const path = join(ROOT, "private.txt");
    await files.writeExclusive(path, "secret");
    const sync = vi.spyOn(ProjectFilesystem.prototype, "sync").mockResolvedValue(undefined);

    await files.remove(path);

    expect(sync).toHaveBeenCalledWith(ROOT);
    await expect(readFile(join(projectDir, path), "utf8")).rejects.toMatchObject({ code: "ENOENT" });
  });

  it("fails closed on genuine Windows directory sync I/O failures", async () => {
    const projectDir = await temporaryProject();
    const files = await openProtected(projectDir, {
      platform: "win32",
      windowsAcl: new FakeWindowsAcl(),
    });
    const path = join(ROOT, "private.txt");
    await files.writeExclusive(path, "secret");
    vi.spyOn(ProjectFilesystem.prototype, "sync").mockRejectedValue(
      Object.assign(new Error("disk failure"), { code: "EIO" }),
    );

    await expect(files.remove(path)).rejects.toMatchObject({
      code: "protected_storage_unavailable",
    });
  });
});
