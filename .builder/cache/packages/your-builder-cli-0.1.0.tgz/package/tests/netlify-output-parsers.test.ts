import { access } from "node:fs/promises";
import { join } from "node:path";

import { describe, expect, it } from "vitest";

describe("Netlify automatic discovery parser", () => {
  it("is absent when no exact CLI version and output schema were frozen", async () => {
    const modulePath = join(process.cwd(), "packages/cli/src/hosting/netlify/output-parsers.ts");
    await expect(access(modulePath)).rejects.toMatchObject({ code: "ENOENT" });
  });
});
