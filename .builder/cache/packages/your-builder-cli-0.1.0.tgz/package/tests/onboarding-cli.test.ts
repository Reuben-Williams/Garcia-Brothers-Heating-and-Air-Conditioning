// @vitest-environment node

import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";

import { afterEach, describe, expect, it, vi } from "vitest";

import { dispatchBuilderCli } from "../src/bin.js";
import { canonicalOnboardingValue, parseOnboardingStageReceipt } from "../src/onboarding/index.js";
import { fingerprintSource } from "../src/scan/source-fingerprint.js";

const temporaryDirectories: string[] = [];

afterEach(async () => {
  await Promise.all(temporaryDirectories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })));
});

describe("builder onboard inspect CLI", () => {
  it("writes one deterministic review artifact and reports its review ID", async () => {
    const root = await mkdtemp(join(process.cwd(), ".tmp-onboarding-cli-"));
    temporaryDirectories.push(root);
    const projectDir = join(root, "site");
    await mkdir(join(projectDir, "app"), { recursive: true });
    await mkdir(join(projectDir, "out"), { recursive: true });
    await writeFile(join(projectDir, "app", "page.jsx"), "export default function Home() {}\n");
    await writeFile(join(projectDir, "out", "index.html"), "<main><h1>Local service</h1></main>");
    const manifestPath = join(root, "manifest.json");
    const outputPath = join(root, "review.json");
    await writeFile(manifestPath, JSON.stringify({
      version: 1,
      site: {
        siteId: "local-service-staging",
        stableSiteKey: "local-service",
        framework: "next-app-router",
        editorPath: "/admin/editor",
      },
      routes: [{ path: "/", pageSlug: "home", source: "app/page.jsx", renderedArtifact: "out/index.html" }],
      modules: [{ id: "growth.leads", version: "1.0.0" }],
    }));
    const output = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };

    await expect(dispatchBuilderCli([
      "onboard",
      "--stage", "inspect",
      "--project", projectDir,
      "--manifest", manifestPath,
      "--output", outputPath,
    ], { output })).resolves.toBe(0);

    const review = JSON.parse(await readFile(outputPath, "utf8")) as {
      reviewId: string;
      candidates: Array<{ id: string }>;
    };
    expect(review.reviewId).toMatch(/^[a-f0-9]{64}$/);
    expect(output.info).toHaveBeenCalledWith(expect.stringContaining(review.reviewId));
    expect(parseOnboardingStageReceipt(JSON.parse(await readFile(`${outputPath}.receipt.json`, "utf8"))))
      .toMatchObject({ stage: "inspect", outputId: review.reviewId });

    await expect(dispatchBuilderCli([
      "onboard",
      "--stage", "inspect",
      "--project", projectDir,
      "--manifest", manifestPath,
      "--output", outputPath,
    ], { output })).resolves.toBe(0);

    const approvalPath = join(root, "approval.json");
    const planPath = join(root, "plan.json");
    await writeFile(approvalPath, JSON.stringify({
      version: 1,
      reviewId: review.reviewId,
      mappings: [{
        stableId: "home.content.primary",
        category: "editableRegion",
        candidateIds: review.candidates.map((candidate) => candidate.id),
      }],
      exclusions: [],
    }));
    await expect(dispatchBuilderCli([
      "onboard",
      "--stage", "plan",
      "--review", outputPath,
      "--approval", approvalPath,
      "--output", planPath,
    ], { output })).resolves.toBe(0);
    const plan = JSON.parse(await readFile(planPath, "utf8")) as { planId: string; reviewId: string };
    expect(plan.planId).toMatch(/^[a-f0-9]{64}$/);
    expect(plan.reviewId).toBe(review.reviewId);
    expect(parseOnboardingStageReceipt(JSON.parse(await readFile(`${planPath}.receipt.json`, "utf8"))))
      .toMatchObject({ stage: "plan", outputId: plan.planId });

    const sourceBefore = "export default function Home() {}\n";
    const patchPayload = {
      version: 1,
      planId: plan.planId,
      files: [{
        path: "app/page.jsx",
        expectedCurrentHash: fingerprintSource(sourceBefore),
        contents: "export default function Home() { return <main>Editable</main>; }\n",
      }],
    };
    const patchPath = join(root, "patch.json");
    const receiptPath = join(root, "receipt.json");
    await writeFile(patchPath, JSON.stringify({
      ...patchPayload,
      patchId: fingerprintSource(canonicalOnboardingValue(patchPayload)),
    }));
    await expect(dispatchBuilderCli([
      "onboard",
      "--stage", "apply",
      "--project", projectDir,
      "--plan", planPath,
      "--patch", patchPath,
      "--output", receiptPath,
    ], { output })).resolves.toBe(0);
    await expect(readFile(join(projectDir, "app/page.jsx"), "utf8"))
      .resolves.toContain("Editable");
    const firstReceipt = await readFile(receiptPath, "utf8");
    expect(parseOnboardingStageReceipt(JSON.parse(await readFile(`${receiptPath}.receipt.json`, "utf8"))))
      .toMatchObject({ stage: "apply" });
    await expect(dispatchBuilderCli([
      "onboard",
      "--stage", "apply",
      "--project", projectDir,
      "--plan", planPath,
      "--patch", patchPath,
      "--output", receiptPath,
    ], { output })).resolves.toBe(0);
    await expect(readFile(receiptPath, "utf8")).resolves.toBe(firstReceipt);
  });
});
