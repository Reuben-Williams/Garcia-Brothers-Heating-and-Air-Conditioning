import { mkdir, mkdtemp, readFile, readdir, rename, stat, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";

import {
  REGISTRATION_REQUEST_HEADER_NAMES,
  verifyRegistrationProof,
} from "@your-builder/entitlements/trust";
import { afterEach, describe, expect, it, vi } from "vitest";

import {
  RegistrationCliError,
  parseInstallationManifest,
  rebindInstallation,
  registerInstallation,
  type InstallationManifestInput,
} from "../src/control-plane/register-installation.js";
import type { WindowsAclAdapter } from "../src/control-plane/protected-files.js";
import type { ExchangeTokenSecret } from "../src/control-plane/secret-prompt.js";
import { dispatchBuilderCli } from "../src/bin.js";

const INSTALLATION_ID = "11111111-1111-4111-8111-111111111111";
const CONTROL_PLANE_URL = "https://control.example.com";
const EXCHANGE_TOKEN = "11qYAYKxCrfVS_7TyWQHOg7hcvPapiMlrwIaaPcHURo";
const REBIND_EXCHANGE_TOKEN = "IiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiI";
const PRIVATE_PATH = join(".builder", "secrets", "installation-private.jwk");
const REVIEW_PATH = join(".builder", "installation-registration.json");
const CANONICAL_PENDING_PATH = join(
  ".builder",
  "secrets",
  "installation-registration.pending",
);
const PENDING_PATH = CANONICAL_PENDING_PATH;
const PENDING_SECRET_PATH = join(PENDING_PATH, "installation-private.jwk");
const PENDING_REQUEST_PATH = join(PENDING_PATH, "request.json");
const PENDING_METADATA_PATH = join(PENDING_PATH, "metadata.json");
const REBIND_BINDING_PATH = join(PENDING_PATH, "rebind.json");
const ROTATION_PENDING_PATH = join(".builder", "secrets", "installation-rotation.pending");
const STAGED_PATH = join(ROTATION_PENDING_PATH, "next-private.jwk");
const ROTATION_METADATA_PATH = join(ROTATION_PENDING_PATH, "metadata.json");

const temporaryDirectories: string[] = [];

async function temporaryProject(): Promise<string> {
  const path = await mkdtemp(join(tmpdir(), "builder-registration-"));
  temporaryDirectories.push(path);
  return path;
}

afterEach(async () => {
  const { rm } = await import("node:fs/promises");
  await Promise.all(temporaryDirectories.splice(0).map((path) => rm(path, { recursive: true, force: true })));
});

function manifest(): InstallationManifestInput {
  return {
    version: 1,
    packages: { "your-builder-next": "0.1.0" },
    schemas: { content: 1 },
    routes: ["/", "/admin/editor"],
    workerVersion: "0.1.0",
  };
}

function registrationResponse(keyId: string) {
  return {
    installationId: INSTALLATION_ID,
    acceptedKeyId: keyId,
    publicSigningKeys: [],
    endpoints: {
      pullCommands: "/api/platform/v1/installations/commands/pull",
      submitCommandResult: "/api/platform/v1/installations/commands/{commandId}/result",
      reportHealth: "/api/platform/v1/installations/health",
      rotateCredential: "/api/platform/v1/installations/credentials/rotate",
    },
  };
}

function input(projectDir: string) {
  return {
    projectDir,
    controlPlaneUrl: CONTROL_PLANE_URL,
    exchangeToken: EXCHANGE_TOKEN,
    stableSiteKey: "garcia-brothers",
    publicUrl: "https://garciabrothers.example.com",
    manifest: manifest(),
  };
}

function dependencies(fetch: typeof globalThis.fetch, lines: string[], maxAttempts = 1) {
  let randomCounter = 0;
  return {
    fetch,
    output: {
      info: (line: string) => lines.push(line),
      warn: (line: string) => lines.push(`WARN:${line}`),
    },
    now: () => new Date("2026-07-16T12:00:00.000Z"),
    randomBytes: (size: number) => {
      randomCounter += 1;
      return new Uint8Array(size).fill(randomCounter);
    },
    maxAttempts,
    platform: "win32" as NodeJS.Platform,
    protectedFiles: {
      windowsAcl: {
        currentUserSid: async () => "S-1-5-21-owner",
        protect: async () => undefined,
        inspect: async () => ({
          ownerSid: "S-1-5-21-owner",
          inheritanceDisabled: true,
          isReparsePoint: false,
          entries: [{
            sid: "S-1-5-21-owner",
            allow: true,
            inherited: false,
            fullControl: true,
          }],
        }),
      },
    },
  };
}

describe("registerInstallation", () => {
  it("fails before key generation and network access when owner-only protection cannot be proved", async () => {
    const projectDir = await temporaryProject();
    const fetch = vi.fn<typeof globalThis.fetch>();
    const generateKeyPair = vi.fn();
    const windowsAcl: WindowsAclAdapter = {
      currentUserSid: async () => "S-1-5-21-owner",
      protect: async () => undefined,
      inspect: async () => { throw new Error("ACL lookup leaked detail"); },
    };

    const error = await registerInstallation(input(projectDir), {
      ...dependencies(fetch, []),
      generateKeyPair,
      protectedFiles: { windowsAcl },
    }).catch((caught: unknown) => caught);

    expect(error).toMatchObject({ code: "pending_state_invalid", message: "pending_state_invalid" });
    expect(String(error)).not.toContain("ACL lookup leaked detail");
    expect(generateKeyPair).not.toHaveBeenCalled();
    expect(fetch).not.toHaveBeenCalled();
  });

  it("matches Task3 manifest schema and serialized-size boundaries", () => {
    expect(parseInstallationManifest({
      ...manifest(),
      packages: { "@your-builder/editor": "0.1.0" },
    })).toMatchObject({ packages: { "@your-builder/editor": "0.1.0" } });
    expect(parseInstallationManifest({
      ...manifest(),
      schemas: { content: 1_000_000 },
    })).toMatchObject({ schemas: { content: 1_000_000 } });
    expect(() => parseInstallationManifest({
      ...manifest(),
      schemas: { content: 1_000_001 },
    })).toThrowError(expect.objectContaining({ code: "invalid_manifest" }));

    const packages = Object.fromEntries(
      Array.from({ length: 256 }, (_, index) => [
        `package${String(index).padStart(3, "0")}${"x".repeat(110)}`,
        `1.${"0".repeat(61)}`,
      ]),
    );
    expect(() => parseInstallationManifest({ ...manifest(), packages }))
      .toThrowError(expect.objectContaining({ code: "invalid_manifest" }));

    const crossSectionManifest = {
      ...manifest(),
      packages: Object.fromEntries(Array.from({ length: 150 }, (_, index) => [
        `package${String(index).padStart(3, "0")}${"x".repeat(108)}`,
        `1${"0".repeat(63)}`,
      ])),
      routes: Array.from({ length: 256 }, (_, index) =>
        `/service/${String(index).padStart(3, "0")}/${"x".repeat(44)}`),
    };
    expect(new TextEncoder().encode(JSON.stringify(crossSectionManifest)).byteLength)
      .toBeGreaterThan(32_768);
    expect(() => parseInstallationManifest(crossSectionManifest))
      .toThrowError(expect.objectContaining({ code: "invalid_manifest" }));
  });

  it("atomically publishes a canonical pending directory before any registration network call", async () => {
    const projectDir = await temporaryProject();
    const fetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      await expect(stat(join(projectDir, CANONICAL_PENDING_PATH))).resolves.toBeDefined();
      await expect(stat(join(projectDir, PRIVATE_PATH))).rejects.toThrow();
      const body = JSON.parse(await new Response(init?.body).text());
      return Response.json(registrationResponse(body.keyId), { status: 201 });
    });

    await registerInstallation(input(projectDir), dependencies(fetch, []));

    await expect(stat(join(projectDir, PRIVATE_PATH))).resolves.toBeDefined();
    await expect(stat(join(projectDir, CANONICAL_PENDING_PATH))).rejects.toThrow();
  }, 15_000);

  it("rejects a project-local builder symlink without touching its outside target", async () => {
    const projectDir = await temporaryProject();
    const outside = await temporaryProject();
    const marker = join(outside, "outside-marker.txt");
    await writeFile(marker, "unchanged");
    try {
      await symlink(outside, join(projectDir, ".builder"), process.platform === "win32" ? "junction" : "dir");
    } catch (error) {
      if (["EPERM", "EACCES", "ENOTSUP"].includes((error as NodeJS.ErrnoException).code ?? "")) {
        return;
      }
      throw error;
    }

    const fetch = vi.fn<typeof globalThis.fetch>();
    await expect(
      registerInstallation(input(projectDir), dependencies(fetch, [])),
    ).rejects.toMatchObject({ code: "pending_state_invalid" });
    expect(await readFile(marker, "utf8")).toBe("unchanged");
    expect(fetch).not.toHaveBeenCalled();
  });

  it("rejects a secrets-directory symlink without touching its outside target", async () => {
    const projectDir = await temporaryProject();
    const outside = await temporaryProject();
    const marker = join(outside, "outside-marker.txt");
    await writeFile(marker, "unchanged");
    await mkdir(join(projectDir, ".builder"));
    try {
      await symlink(outside, join(projectDir, ".builder", "secrets"), process.platform === "win32" ? "junction" : "dir");
    } catch (error) {
      if (["EPERM", "EACCES", "ENOTSUP"].includes((error as NodeJS.ErrnoException).code ?? "")) {
        return;
      }
      throw error;
    }

    const fetch = vi.fn<typeof globalThis.fetch>();
    await expect(
      registerInstallation(input(projectDir), dependencies(fetch, [])),
    ).rejects.toMatchObject({ code: "pending_state_invalid" });
    expect(await readFile(marker, "utf8")).toBe("unchanged");
    expect(fetch).not.toHaveBeenCalled();
  });

  it("removes a stale pre-network temp directory before publishing canonical pending state", async () => {
    const projectDir = await temporaryProject();
    const stale = join(
      projectDir,
      ".builder",
      "secrets",
      ".installation-registration.crash.tmp",
    );
    await mkdir(stale, { recursive: true });
    await writeFile(join(stale, "partial"), "incomplete");
    const fetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      await expect(stat(stale)).rejects.toThrow();
      const body = JSON.parse(await new Response(init?.body).text());
      return Response.json(registrationResponse(body.keyId), { status: 201 });
    });

    await registerInstallation(input(projectDir), dependencies(fetch, []));

    expect(fetch).toHaveBeenCalledOnce();
  });

  it("stages a private key before sending exact proved bytes and writes only safe output", async () => {
    const projectDir = await temporaryProject();
    const lines: string[] = [];
    let requestBody = "";
    const fetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      await expect(stat(join(projectDir, PENDING_SECRET_PATH))).resolves.toBeDefined();
      await expect(stat(join(projectDir, PRIVATE_PATH))).rejects.toThrow();
      requestBody = await new Response(init?.body).text();
      const body = JSON.parse(requestBody);
      expect(body).toMatchObject({
        exchangeToken: EXCHANGE_TOKEN,
        stableSiteKey: "garcia-brothers",
        publicUrl: "https://garciabrothers.example.com",
        manifest: manifest(),
      });
      expect(body.publicJwk).toEqual({
        kty: "OKP",
        crv: "Ed25519",
        alg: "EdDSA",
        x: expect.any(String),
      });
      expect(requestBody).not.toContain('"d"');
      const proof = new Headers(init?.headers).get(REGISTRATION_REQUEST_HEADER_NAMES.proof)!;
      await expect(
        verifyRegistrationProof({
          bodyBytes: new TextEncoder().encode(requestBody),
          publicJwk: body.publicJwk,
          proof,
        }),
      ).resolves.toBe(true);
      return Response.json(registrationResponse(body.keyId), { status: 201 });
    });

    const result = await registerInstallation(input(projectDir), dependencies(fetch, lines));

    expect(result).toMatchObject({ installationId: INSTALLATION_ID, rotated: false });
    expect(fetch).toHaveBeenCalledOnce();
    const privateJwk = JSON.parse(await readFile(join(projectDir, PRIVATE_PATH), "utf8"));
    expect(Object.keys(privateJwk).sort()).toEqual(["alg", "crv", "d", "kty", "x"]);
    expect(privateJwk).toMatchObject({ kty: "OKP", crv: "Ed25519", alg: "EdDSA" });
    const review = JSON.parse(await readFile(join(projectDir, REVIEW_PATH), "utf8"));
    expect(review).not.toHaveProperty("exchangeToken");
    expect(review).not.toHaveProperty("privateJwk");
    expect(JSON.stringify(review)).not.toContain(privateJwk.d);
    const output = lines.join("\n");
    expect(output).toContain("BUILDER_CONTROL_PLANE_URL");
    expect(output).toContain("BUILDER_INSTALLATION_PRIVATE_JWK");
    expect(output).toContain(INSTALLATION_ID);
    expect(output).not.toContain("cannot be guaranteed");
    expect(output).not.toContain("WARN:");
    expect(output).not.toContain(EXCHANGE_TOKEN);
    expect(output).not.toContain(privateJwk.d);
    expect(output).not.toContain(bodyPublicCoordinate(requestBody));
  });

  it("refuses to overwrite an existing private key without rotation or exact pending replay", async () => {
    const projectDir = await temporaryProject();
    await mkdir(join(projectDir, ".builder", "secrets"), { recursive: true });
    await writeFile(join(projectDir, PRIVATE_PATH), '{"existing":true}', { mode: 0o600 });
    const fetch = vi.fn<typeof globalThis.fetch>();

    await expect(
      registerInstallation(input(projectDir), dependencies(fetch, [])),
    ).rejects.toMatchObject({
      name: "RegistrationCliError",
      code: "private_key_exists",
    });
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).toBe('{"existing":true}');
    expect(fetch).not.toHaveBeenCalled();
  });

  it("retains exact pending request bytes after ambiguity and replays without generating a key", async () => {
    const projectDir = await temporaryProject();
    const firstBodies: string[] = [];
    const firstProofs: string[] = [];
    const firstFetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      firstBodies.push(await new Response(init?.body).text());
      firstProofs.push(new Headers(init?.headers).get(REGISTRATION_REQUEST_HEADER_NAMES.proof)!);
      throw new Error(`network failed with ${EXCHANGE_TOKEN}`);
    });

    await expect(
      registerInstallation(input(projectDir), dependencies(firstFetch, [])),
    ).rejects.toMatchObject({ code: "registration_ambiguous" });
    const stagedKey = await readFile(join(projectDir, PENDING_SECRET_PATH), "utf8");
    await expect(stat(join(projectDir, PENDING_PATH))).resolves.toBeDefined();
    await expect(stat(join(projectDir, PENDING_REQUEST_PATH))).resolves.toBeDefined();

    const replayBodies: string[] = [];
    const replayProofs: string[] = [];
    const replayFetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      const raw = await new Response(init?.body).text();
      replayBodies.push(raw);
      replayProofs.push(new Headers(init?.headers).get(REGISTRATION_REQUEST_HEADER_NAMES.proof)!);
      const body = JSON.parse(raw);
      return Response.json(registrationResponse(body.keyId), { status: 201 });
    });

    await registerInstallation(input(projectDir), dependencies(replayFetch, []));

    expect(replayBodies).toEqual(firstBodies);
    expect(replayProofs).toEqual(firstProofs);
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).toBe(stagedKey);
    await expect(stat(join(projectDir, PENDING_PATH))).rejects.toThrow();
    await expect(stat(join(projectDir, PENDING_REQUEST_PATH))).rejects.toThrow();
  });

  it("exact-replays when the final registration key moved but pending metadata remains", async () => {
    const projectDir = await temporaryProject();
    let originalBody = "";
    let originalProof = "";
    const ambiguous = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      originalBody = await new Response(init?.body).text();
      originalProof = new Headers(init?.headers).get(REGISTRATION_REQUEST_HEADER_NAMES.proof)!;
      throw new Error("accepted response was lost");
    });
    await expect(
      registerInstallation(input(projectDir), dependencies(ambiguous, [])),
    ).rejects.toMatchObject({ code: "registration_ambiguous" });
    await rename(join(projectDir, PENDING_SECRET_PATH), join(projectDir, PRIVATE_PATH));

    const replay = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      expect(await new Response(init?.body).text()).toBe(originalBody);
      expect(new Headers(init?.headers).get(REGISTRATION_REQUEST_HEADER_NAMES.proof)).toBe(originalProof);
      const body = JSON.parse(originalBody);
      return Response.json(registrationResponse(body.keyId), { status: 201 });
    });

    await registerInstallation(input(projectDir), dependencies(replay, []));

    expect(replay).toHaveBeenCalledOnce();
    await expect(stat(join(projectDir, PENDING_PATH))).rejects.toThrow();
    await expect(stat(join(projectDir, REVIEW_PATH))).resolves.toBeDefined();
  });

  it("exact-replays and cleans up when registration review and final key already exist", async () => {
    const projectDir = await temporaryProject();
    let originalBody = "";
    await expect(
      registerInstallation(
        input(projectDir),
        dependencies(vi.fn(async (_url, init) => {
          originalBody = await new Response(init?.body).text();
          throw new Error("response lost after acceptance");
        }), []),
      ),
    ).rejects.toMatchObject({ code: "registration_ambiguous" });
    await rename(join(projectDir, PENDING_SECRET_PATH), join(projectDir, PRIVATE_PATH));
    const request = JSON.parse(originalBody);
    const review = {
      version: 1,
      controlPlaneUrl: CONTROL_PLANE_URL,
      stableSiteKey: "garcia-brothers",
      publicUrl: "https://garciabrothers.example.com",
      registeredAt: "2026-07-16T12:00:00.000Z",
      ...registrationResponse(request.keyId),
    };
    await writeFile(join(projectDir, REVIEW_PATH), `${JSON.stringify(review, null, 2)}\n`);
    const replay = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      expect(await new Response(init?.body).text()).toBe(originalBody);
      return Response.json(registrationResponse(request.keyId), { status: 200 });
    });

    await registerInstallation(input(projectDir), dependencies(replay, []));

    expect(replay).toHaveBeenCalledOnce();
    await expect(stat(join(projectDir, PENDING_PATH))).rejects.toThrow();
    expect(JSON.parse(await readFile(join(projectDir, REVIEW_PATH), "utf8"))).toEqual(review);
  });

  it("never overwrites an unrelated review during pending recovery", async () => {
    const projectDir = await temporaryProject();
    await expect(
      registerInstallation(
        input(projectDir),
        dependencies(vi.fn(async () => { throw new Error("lost"); }), []),
      ),
    ).rejects.toMatchObject({ code: "registration_ambiguous" });
    const unrelated = {
      version: 1,
      controlPlaneUrl: "https://other.example.com",
      stableSiteKey: "other-site",
      publicUrl: "https://other-site.example.com",
      registeredAt: "2026-07-16T11:00:00.000Z",
      ...registrationResponse("other-key"),
    };
    await writeFile(join(projectDir, REVIEW_PATH), `${JSON.stringify(unrelated, null, 2)}\n`);
    const fetch = vi.fn<typeof globalThis.fetch>();

    await expect(
      registerInstallation(input(projectDir), dependencies(fetch, [])),
    ).rejects.toMatchObject({ code: "pending_state_invalid" });

    expect(fetch).not.toHaveBeenCalled();
    expect(JSON.parse(await readFile(join(projectDir, REVIEW_PATH), "utf8"))).toEqual(unrelated);
  });


  it("retains staged state and redacts malformed or raw server responses", async () => {
    const projectDir = await temporaryProject();
    const rawSecret = "server-secret-response";
    const lines: string[] = [];
    const fetch = vi.fn<typeof globalThis.fetch>(async () =>
      new Response(`{"unexpected":"${rawSecret}"}`, {
        status: 201,
        headers: { "content-type": "application/json" },
      }),
    );

    const error = await registerInstallation(input(projectDir), dependencies(fetch, lines)).catch(
      (value: RegistrationCliError) => value,
    );
    expect(error).toMatchObject({ code: "invalid_registration_response" });
    expect(String(error)).not.toContain(rawSecret);
    expect(lines.join("\n")).not.toContain(rawSecret);
    await expect(stat(join(projectDir, PENDING_SECRET_PATH))).resolves.toBeDefined();
    await expect(stat(join(projectDir, PENDING_PATH))).resolves.toBeDefined();
  });

  it("rejects malformed control-plane signing keys in a successful response", async () => {
    const projectDir = await temporaryProject();
    const fetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      const body = JSON.parse(await new Response(init?.body).text());
      return Response.json({
        ...registrationResponse(body.keyId),
        publicSigningKeys: [{ privateJwk: { d: "must-not-be-accepted" } }],
      }, { status: 201 });
    });

    await expect(
      registerInstallation(input(projectDir), dependencies(fetch, [])),
    ).rejects.toMatchObject({ code: "invalid_registration_response" });
    await expect(stat(join(projectDir, PENDING_PATH))).resolves.toBeDefined();
  });

  it("cancels a registration response stream as soon as it exceeds the byte bound", async () => {
    const projectDir = await temporaryProject();
    const cancel = vi.fn();
    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(new Uint8Array(200 * 1024));
        controller.enqueue(new Uint8Array(100 * 1024));
      },
      cancel,
    });
    const fetch = vi.fn<typeof globalThis.fetch>(async () =>
      new Response(stream, { status: 201, headers: { "content-type": "application/json" } }),
    );

    await expect(
      registerInstallation(input(projectDir), dependencies(fetch, [])),
    ).rejects.toMatchObject({ code: "invalid_registration_response" });
    expect(cancel).toHaveBeenCalledOnce();
  });

  it("maps a response stream failure to a redacted stable error", async () => {
    const projectDir = await temporaryProject();
    const rawSecret = "stream-secret-that-must-not-leak";
    const stream = new ReadableStream<Uint8Array>({
      pull(controller) {
        controller.error(new Error(rawSecret));
      },
    });
    const fetch = vi.fn<typeof globalThis.fetch>(async () => new Response(stream, { status: 201 }));

    const error = await registerInstallation(input(projectDir), dependencies(fetch, [])).catch(
      (value: unknown) => value,
    );
    expect(error).toMatchObject({ code: "invalid_registration_response" });
    expect(String(error)).not.toContain(rawSecret);
  });

  it("stages rotation separately and replaces the active key only after signed success", async () => {
    const projectDir = await temporaryProject();
    const initialFetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      const body = JSON.parse(await new Response(init?.body).text());
      return Response.json(registrationResponse(body.keyId), { status: 201 });
    });
    await registerInstallation(input(projectDir), dependencies(initialFetch, []));
    const activeBefore = await readFile(join(projectDir, PRIVATE_PATH), "utf8");

    let failedRotationBody = "";
    const failedRotation = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      failedRotationBody = await new Response(init?.body).text();
      expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).toBe(activeBefore);
      await expect(stat(join(projectDir, STAGED_PATH))).resolves.toBeDefined();
      throw new Error("ambiguous rotation");
    });
    await expect(
      registerInstallation(
        { projectDir, rotate: true, overlapSeconds: 300 },
        dependencies(failedRotation, []),
      ),
    ).rejects.toMatchObject({ code: "rotation_ambiguous" });
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).toBe(activeBefore);
    const staged = await readFile(join(projectDir, STAGED_PATH), "utf8");

    const successfulRotation = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      const bodyText = await new Response(init?.body).text();
      expect(bodyText).toBe(failedRotationBody);
      expect(JSON.parse(bodyText).previousKeyId).toBe(
        JSON.parse(await readFile(join(projectDir, REVIEW_PATH), "utf8")).acceptedKeyId,
      );
      const headers = new Headers(init?.headers);
      expect(headers.get("x-builder-installation-id")).toBe(INSTALLATION_ID);
      expect(headers.get("x-builder-signature")).toMatch(/^[A-Za-z0-9_-]{86}$/);
      return Response.json({ acceptedKeyId: JSON.parse(bodyText).newKeyId });
    });
    const result = await registerInstallation(
      { projectDir, rotate: true, overlapSeconds: 300 },
      dependencies(successfulRotation, []),
    );

    expect(result.rotated).toBe(true);
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).toBe(staged);
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).not.toBe(activeBefore);
    await expect(stat(join(projectDir, STAGED_PATH))).rejects.toThrow();
    const review = JSON.parse(await readFile(join(projectDir, REVIEW_PATH), "utf8"));
    expect(review.acceptedKeyId).toBe(result.acceptedKeyId);
  }, 15_000);

  it("redacts malformed local review state before rotation", async () => {
    const projectDir = await temporaryProject();
    const rawSecret = "local-review-secret";
    await mkdir(join(projectDir, ".builder"), { recursive: true });
    await writeFile(join(projectDir, REVIEW_PATH), `{"secret":"${rawSecret}"`);

    const error = await registerInstallation(
      { projectDir, rotate: true },
      dependencies(vi.fn<typeof globalThis.fetch>(), []),
    ).catch((value: unknown) => value);

    expect(error).toMatchObject({ code: "pending_state_invalid" });
    expect(String(error)).not.toContain(rawSecret);
  });

  it("finishes an accepted rotation locally after a crash before key rename", async () => {
    const projectDir = await temporaryProject();
    const initialFetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      const body = JSON.parse(await new Response(init?.body).text());
      return Response.json(registrationResponse(body.keyId), { status: 201 });
    });
    await registerInstallation(input(projectDir), dependencies(initialFetch, []));
    const activeBefore = await readFile(join(projectDir, PRIVATE_PATH), "utf8");

    const failedRotation = vi.fn<typeof globalThis.fetch>(async () => {
      throw new Error("response lost");
    });
    await expect(
      registerInstallation(
        { projectDir, rotate: true, overlapSeconds: 300 },
        dependencies(failedRotation, []),
      ),
    ).rejects.toMatchObject({ code: "rotation_ambiguous" });
    const staged = await readFile(join(projectDir, STAGED_PATH), "utf8");
    const pending = JSON.parse(
      await readFile(join(projectDir, ROTATION_METADATA_PATH), "utf8"),
    );
    const review = JSON.parse(await readFile(join(projectDir, REVIEW_PATH), "utf8"));
    await writeFile(
      join(projectDir, REVIEW_PATH),
      `${JSON.stringify({ ...review, acceptedKeyId: pending.newKeyId }, null, 2)}\n`,
    );

    const recoveryFetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      const body = JSON.parse(await new Response(init?.body).text());
      expect(body.newKeyId).toBe(pending.newKeyId);
      return Response.json({ acceptedKeyId: pending.newKeyId });
    });
    const result = await registerInstallation(
      { projectDir, rotate: true, overlapSeconds: 300 },
      dependencies(recoveryFetch, []),
    );

    expect(result).toMatchObject({ acceptedKeyId: pending.newKeyId, rotated: true });
    expect(recoveryFetch).toHaveBeenCalledOnce();
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).toBe(staged);
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).not.toBe(activeBefore);
  }, 15_000);

  it("exact-replays rotation after final key promotion when the review write was not durable", async () => {
    const projectDir = await temporaryProject();
    await registerInstallation(
      input(projectDir),
      dependencies(vi.fn(async (_url, init) => {
        const body = JSON.parse(await new Response(init?.body).text());
        return Response.json(registrationResponse(body.keyId), { status: 201 });
      }), []),
    );
    const oldReview = JSON.parse(await readFile(join(projectDir, REVIEW_PATH), "utf8"));
    let rotationBody = "";
    await expect(
      registerInstallation(
        { projectDir, rotate: true, overlapSeconds: 300 },
        dependencies(vi.fn(async (_url, init) => {
          rotationBody = await new Response(init?.body).text();
          throw new Error("response lost after acceptance");
        }), []),
      ),
    ).rejects.toMatchObject({ code: "rotation_ambiguous" });
    const staged = await readFile(join(projectDir, STAGED_PATH), "utf8");
    await rename(join(projectDir, STAGED_PATH), join(projectDir, PRIVATE_PATH));
    const replay = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      expect(await new Response(init?.body).text()).toBe(rotationBody);
      expect(new Headers(init?.headers).get("x-builder-key-id")).toBe(oldReview.acceptedKeyId);
      return Response.json({ acceptedKeyId: JSON.parse(rotationBody).newKeyId });
    });

    const result = await registerInstallation(
      { projectDir, rotate: true, overlapSeconds: 300 },
      dependencies(replay, []),
    );

    expect(replay).toHaveBeenCalledOnce();
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).toBe(staged);
    expect(JSON.parse(await readFile(join(projectDir, REVIEW_PATH), "utf8")).acceptedKeyId)
      .toBe(result.acceptedKeyId);
    await expect(stat(join(projectDir, ROTATION_PENDING_PATH))).rejects.toThrow();
  }, 15_000);

  it("reconciles an ambiguous rotation with the staged new key after old-key expiry", async () => {
    const projectDir = await temporaryProject();
    await registerInstallation(
      input(projectDir),
      dependencies(vi.fn(async (_url, init) => {
        const body = JSON.parse(await new Response(init?.body).text());
        return Response.json(registrationResponse(body.keyId), { status: 201 });
      }), []),
    );
    const oldReview = JSON.parse(await readFile(join(projectDir, REVIEW_PATH), "utf8"));
    const activeBefore = await readFile(join(projectDir, PRIVATE_PATH), "utf8");
    let exactBody = "";
    await expect(
      registerInstallation(
        { projectDir, rotate: true, overlapSeconds: 300 },
        dependencies(vi.fn(async (_url, init) => {
          exactBody = await new Response(init?.body).text();
          throw new Error("accepted response lost");
        }), []),
      ),
    ).rejects.toMatchObject({ code: "rotation_ambiguous" });
    const pending = JSON.parse(await readFile(join(projectDir, ROTATION_METADATA_PATH), "utf8"));
    const staged = await readFile(join(projectDir, STAGED_PATH), "utf8");
    const signingKeyIds: string[] = [];
    const recovery = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      expect(await new Response(init?.body).text()).toBe(exactBody);
      const keyId = new Headers(init?.headers).get("x-builder-key-id")!;
      signingKeyIds.push(keyId);
      if (keyId === oldReview.acceptedKeyId) {
        return Response.json({ error: "installation_authentication_failed" }, { status: 401 });
      }
      expect(keyId).toBe(pending.newKeyId);
      return Response.json({ acceptedKeyId: pending.newKeyId });
    });

    const result = await registerInstallation(
      { projectDir, rotate: true, overlapSeconds: 300 },
      dependencies(recovery, []),
    );

    expect(signingKeyIds).toEqual([oldReview.acceptedKeyId, pending.newKeyId]);
    expect(result).toMatchObject({ acceptedKeyId: pending.newKeyId, rotated: true });
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).toBe(staged);
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).not.toBe(activeBefore);
    expect(JSON.parse(await readFile(join(projectDir, REVIEW_PATH), "utf8")).acceptedKeyId)
      .toBe(pending.newKeyId);
    await expect(stat(join(projectDir, ROTATION_PENDING_PATH))).rejects.toThrow();
  });

  it("preserves the old key and pending rotation when reconciliation conflicts", async () => {
    const projectDir = await temporaryProject();
    await registerInstallation(
      input(projectDir),
      dependencies(vi.fn(async (_url, init) => {
        const body = JSON.parse(await new Response(init?.body).text());
        return Response.json(registrationResponse(body.keyId), { status: 201 });
      }), []),
    );
    const activeBefore = await readFile(join(projectDir, PRIVATE_PATH), "utf8");
    const oldReview = await readFile(join(projectDir, REVIEW_PATH), "utf8");
    await expect(
      registerInstallation(
        { projectDir, rotate: true, overlapSeconds: 300 },
        dependencies(vi.fn(async () => {
          throw new Error("accepted response lost");
        }), []),
      ),
    ).rejects.toMatchObject({ code: "rotation_ambiguous" });
    const pending = JSON.parse(await readFile(join(projectDir, ROTATION_METADATA_PATH), "utf8"));
    const keyIds: string[] = [];
    const recovery = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      const keyId = new Headers(init?.headers).get("x-builder-key-id")!;
      keyIds.push(keyId);
      return keyId === pending.previousKeyId
        ? Response.json({ error: "installation_authentication_failed" }, { status: 401 })
        : Response.json({ error: "conflict" }, { status: 409 });
    });

    await expect(
      registerInstallation(
        { projectDir, rotate: true, overlapSeconds: 300 },
        dependencies(recovery, []),
      ),
    ).rejects.toMatchObject({ code: "rotation_failed", status: 409 });

    expect(keyIds).toEqual([pending.previousKeyId, pending.newKeyId]);
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).toBe(activeBefore);
    expect(await readFile(join(projectDir, REVIEW_PATH), "utf8")).toBe(oldReview);
    await expect(stat(join(projectDir, ROTATION_PENDING_PATH))).resolves.toBeDefined();
  }, 15_000);

  it("rejects a manifest with unknown fields before writing any secret", async () => {
    const projectDir = await temporaryProject();
    const fetch = vi.fn<typeof globalThis.fetch>();
    await expect(
      registerInstallation(
        {
          ...input(projectDir),
          manifest: { ...manifest(), secret: "no" } as unknown as InstallationManifestInput,
        },
        dependencies(fetch, []),
      ),
    ).rejects.toMatchObject({ code: "invalid_manifest" });
    await expect(stat(join(projectDir, PRIVATE_PATH))).rejects.toThrow();
    expect(fetch).not.toHaveBeenCalled();
  });

  it.each([
    ["exchange token", { exchangeToken: "not-a-canonical-token" }],
    ["public URL credentials", { publicUrl: "https://user:pass@example.com" }],
  ])("rejects an invalid %s before writing any secret", async (_label, override) => {
    const projectDir = await temporaryProject();
    const fetch = vi.fn<typeof globalThis.fetch>();
    await expect(
      registerInstallation({ ...input(projectDir), ...override }, dependencies(fetch, [])),
    ).rejects.toMatchObject({ code: "invalid_arguments" });
    await expect(stat(join(projectDir, PRIVATE_PATH))).rejects.toThrow();
    expect(fetch).not.toHaveBeenCalled();
  });

  it.skipIf(process.platform === "win32")(
    "sets mode 0600 when the platform can enforce POSIX permissions",
    async () => {
    const projectDir = await temporaryProject();
    const fetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      const body = JSON.parse(await new Response(init?.body).text());
      return Response.json(registrationResponse(body.keyId), { status: 201 });
    });
    const deps = dependencies(fetch, []);
    deps.platform = "linux";

    await registerInstallation(input(projectDir), deps);

    expect((await stat(join(projectDir, PRIVATE_PATH))).mode & 0o777).toBe(0o600);
    },
  );
});

describe("registration command dispatcher", () => {
  function exchangeSecret(): ExchangeTokenSecret {
    let consumed = false;
    return {
      async use(callback) {
        if (consumed) throw new Error("consumed");
        consumed = true;
        return callback(EXCHANGE_TOKEN);
      },
      toJSON: () => "[REDACTED]",
      toString: () => "[REDACTED]",
    };
  }

  it("dispatches register-installation without changing exported check behavior", async () => {
    const projectDir = await temporaryProject();
    await mkdir(join(projectDir, ".builder"), { recursive: true });
    await writeFile(
      join(projectDir, ".builder", "installation-manifest.json"),
      `${JSON.stringify(manifest())}\n`,
    );
    const calls: unknown[] = [];
    const code = await dispatchBuilderCli(
      [
        "register-installation",
        "--project",
        projectDir,
        "--control-plane-url",
        CONTROL_PLANE_URL,
        "--exchange-token-stdin",
        "--stable-site-key",
        "garcia-brothers",
        "--public-url",
        "https://garciabrothers.example.com",
      ],
      {
        register: async (value) => {
          calls.push(value);
          return { installationId: INSTALLATION_ID, acceptedKeyId: "key-safe", rotated: false };
        },
        exchangeTokenPrompt: async () => exchangeSecret(),
        output: { info: vi.fn(), warn: vi.fn(), error: vi.fn() },
      },
    );

    expect(code).toBe(0);
    expect(calls).toHaveLength(1);
    expect(calls[0]).toMatchObject({ projectDir, exchangeToken: EXCHANGE_TOKEN, manifest: manifest() });
  });

  it("rebinds an expired exchange token without changing the staged registration identity", async () => {
    const projectDir = await temporaryProject();
    await expect(
      registerInstallation(
        input(projectDir),
        dependencies(vi.fn(async () => { throw new Error("expired before response"); }), []),
      ),
    ).rejects.toMatchObject({ code: "registration_ambiguous" });
    const oldRequest = JSON.parse(await readFile(join(projectDir, PENDING_REQUEST_PATH), "utf8"));
    const oldBody = JSON.parse(oldRequest.body);
    const oldSecret = await readFile(join(projectDir, PENDING_SECRET_PATH), "utf8");
    const oldMetadata = JSON.parse(await readFile(join(projectDir, PENDING_METADATA_PATH), "utf8"));
    const generateKeyPair = vi.fn();
    let reboundBody = "";
    const fetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      reboundBody = await new Response(init?.body).text();
      const parsed = JSON.parse(reboundBody);
      expect({ ...parsed, exchangeToken: EXCHANGE_TOKEN }).toEqual(oldBody);
      expect(parsed.exchangeToken).toBe(REBIND_EXCHANGE_TOKEN);
      expect(parsed.keyId).toBe(oldMetadata.keyId);
      expect(parsed.publicJwk).toEqual(oldBody.publicJwk);
      expect(parsed.manifest).toEqual(oldBody.manifest);
      const proof = new Headers(init?.headers).get(REGISTRATION_REQUEST_HEADER_NAMES.proof)!;
      await expect(verifyRegistrationProof({
        bodyBytes: new TextEncoder().encode(reboundBody),
        publicJwk: parsed.publicJwk,
        proof,
      })).resolves.toBe(true);
      return Response.json(registrationResponse(parsed.keyId), { status: 201 });
    });

    const result = await rebindInstallation(
      {
        projectDir,
        exchangeToken: REBIND_EXCHANGE_TOKEN,
        expectedInstallationId: INSTALLATION_ID,
      },
      { ...dependencies(fetch, []), generateKeyPair },
    );

    expect(result).toMatchObject({
      installationId: INSTALLATION_ID,
      acceptedKeyId: oldMetadata.keyId,
      rotated: false,
      rebound: true,
    });
    expect(generateKeyPair).not.toHaveBeenCalled();
    expect(await readFile(join(projectDir, PRIVATE_PATH), "utf8")).toBe(oldSecret);
    const review = JSON.parse(await readFile(join(projectDir, REVIEW_PATH), "utf8"));
    expect(review).toMatchObject({
      installationId: INSTALLATION_ID,
      acceptedKeyId: oldMetadata.keyId,
      controlPlaneUrl: CONTROL_PLANE_URL,
      stableSiteKey: oldBody.stableSiteKey,
      publicUrl: oldBody.publicUrl,
    });
  }, 15_000);

  it.each([
    ["missing", undefined],
    ["malformed", "not-a-uuid"],
  ])("rejects a %s expected installation ID before rebinding", async (_label, expectedInstallationId) => {
    const projectDir = await temporaryProject();
    const fetch = vi.fn<typeof globalThis.fetch>();

    await expect(rebindInstallation({
      projectDir,
      exchangeToken: REBIND_EXCHANGE_TOKEN,
      expectedInstallationId,
    } as Parameters<typeof rebindInstallation>[0], dependencies(fetch, [])))
      .rejects.toMatchObject({ code: "invalid_arguments" });

    expect(fetch).not.toHaveBeenCalled();
  });

  it("does not promote a rebind response for a different installation", async () => {
    const projectDir = await temporaryProject();
    await expect(registerInstallation(
      input(projectDir),
      dependencies(vi.fn(async () => { throw new Error("response lost"); }), []),
    )).rejects.toMatchObject({ code: "registration_ambiguous" });
    const stagedSecret = await readFile(join(projectDir, PENDING_SECRET_PATH), "utf8");
    const otherInstallationId = "22222222-2222-4222-8222-222222222222";
    const fetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      const body = JSON.parse(await new Response(init?.body).text());
      return Response.json({
        ...registrationResponse(body.keyId),
        installationId: otherInstallationId,
      }, { status: 201 });
    });

    await expect(rebindInstallation({
      projectDir,
      exchangeToken: REBIND_EXCHANGE_TOKEN,
      expectedInstallationId: INSTALLATION_ID,
    }, dependencies(fetch, []))).rejects.toMatchObject({ code: "installation_id_mismatch" });

    expect(await readFile(join(projectDir, PENDING_SECRET_PATH), "utf8")).toBe(stagedSecret);
    await expect(stat(join(projectDir, PRIVATE_PATH))).rejects.toThrow();
    await expect(stat(join(projectDir, REVIEW_PATH))).rejects.toThrow();
  });

  it("rejects rebind after registration has already been accepted", async () => {
    const projectDir = await temporaryProject();
    await registerInstallation(input(projectDir), dependencies(vi.fn(async (_url, init) => {
      const body = JSON.parse(await new Response(init?.body).text());
      return Response.json(registrationResponse(body.keyId), { status: 201 });
    }), []));
    const fetch = vi.fn<typeof globalThis.fetch>();

    await expect(rebindInstallation({
      projectDir,
      exchangeToken: REBIND_EXCHANGE_TOKEN,
      expectedInstallationId: INSTALLATION_ID,
    }, dependencies(fetch, []))).rejects.toMatchObject({ code: "registration_already_accepted" });

    expect(fetch).not.toHaveBeenCalled();
  });

  it("verifies immutable protected pending metadata before rebinding", async () => {
    const projectDir = await temporaryProject();
    await expect(registerInstallation(
      input(projectDir),
      dependencies(vi.fn(async () => { throw new Error("response lost"); }), []),
    )).rejects.toMatchObject({ code: "registration_ambiguous" });
    const metadataPath = join(projectDir, PENDING_METADATA_PATH);
    const metadata = JSON.parse(await readFile(metadataPath, "utf8"));
    await writeFile(metadataPath, `${JSON.stringify({
      ...metadata,
      controlPlaneUrl: "not-a-control-plane-url",
    }, null, 2)}\n`);
    const fetch = vi.fn<typeof globalThis.fetch>();

    await expect(rebindInstallation({
      projectDir,
      exchangeToken: REBIND_EXCHANGE_TOKEN,
      expectedInstallationId: INSTALLATION_ID,
    }, dependencies(fetch, []))).rejects.toMatchObject({ code: "pending_state_invalid" });

    expect(fetch).not.toHaveBeenCalled();
  });

  it("leaves the complete old binding when rebinding crashes before the atomic swap", async () => {
    const projectDir = await temporaryProject();
    await expect(registerInstallation(
      input(projectDir),
      dependencies(vi.fn(async () => { throw new Error("response lost"); }), []),
    )).rejects.toMatchObject({ code: "registration_ambiguous" });
    const oldRequest = await readFile(join(projectDir, PENDING_REQUEST_PATH), "utf8");
    const fetch = vi.fn<typeof globalThis.fetch>();

    await expect(rebindInstallation({
      projectDir,
      exchangeToken: REBIND_EXCHANGE_TOKEN,
      expectedInstallationId: INSTALLATION_ID,
    }, {
      ...dependencies(fetch, []),
      rebindCheckpoint: async (checkpoint) => {
        if (checkpoint === "binding_staged") throw new Error("simulated crash");
      },
    })).rejects.toMatchObject({ code: "pending_state_invalid" });

    expect(await readFile(join(projectDir, PENDING_REQUEST_PATH), "utf8")).toBe(oldRequest);
    await expect(stat(join(projectDir, REBIND_BINDING_PATH))).rejects.toThrow();
    const stagedNames = (await readdir(join(projectDir, PENDING_PATH)))
      .filter((name) => name.startsWith(".installation-rebind.") && name.endsWith(".tmp"));
    expect(stagedNames).toHaveLength(1);
    const stagedBinding = await readFile(join(projectDir, PENDING_PATH, stagedNames[0]!), "utf8");
    expect(() => JSON.parse(stagedBinding)).not.toThrow();
    expect(fetch).not.toHaveBeenCalled();
  });

  it("recovers the complete new binding when rebinding crashes after the atomic swap", async () => {
    const projectDir = await temporaryProject();
    await expect(registerInstallation(
      input(projectDir),
      dependencies(vi.fn(async () => { throw new Error("response lost"); }), []),
    )).rejects.toMatchObject({ code: "registration_ambiguous" });
    const fetchBeforeCrash = vi.fn<typeof globalThis.fetch>();

    await expect(rebindInstallation({
      projectDir,
      exchangeToken: REBIND_EXCHANGE_TOKEN,
      expectedInstallationId: INSTALLATION_ID,
    }, {
      ...dependencies(fetchBeforeCrash, []),
      rebindCheckpoint: async (checkpoint) => {
        if (checkpoint === "binding_promoted") throw new Error("simulated crash");
      },
    })).rejects.toMatchObject({ code: "pending_state_invalid" });

    expect(fetchBeforeCrash).not.toHaveBeenCalled();
    const promoted = JSON.parse(await readFile(join(projectDir, REBIND_BINDING_PATH), "utf8"));
    expect(promoted).toMatchObject({
      version: 1,
      operation: "rebind",
      expectedInstallationId: INSTALLATION_ID,
    });
    const replay = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      expect(await new Response(init?.body).text()).toBe(promoted.body);
      expect(new Headers(init?.headers).get(REGISTRATION_REQUEST_HEADER_NAMES.proof)).toBe(promoted.proof);
      return Response.json(registrationResponse(JSON.parse(promoted.body).keyId), { status: 201 });
    });

    await expect(rebindInstallation({
      projectDir,
      exchangeToken: REBIND_EXCHANGE_TOKEN,
      expectedInstallationId: INSTALLATION_ID,
    }, dependencies(replay, []))).resolves.toMatchObject({ rebound: true });

    expect(replay).toHaveBeenCalledOnce();
  }, 15_000);

  it.each([
    ["argv value", ["--exchange-token", EXCHANGE_TOKEN]],
    ["argv assignment", [`--exchange-token=${EXCHANGE_TOKEN}`]],
    ["file", ["--exchange-token-file", "token.txt"]],
    ["command", ["--exchange-token-command", "print-token"]],
    ["unknown", ["--token", EXCHANGE_TOKEN]],
  ])("rejects the %s token transport before prompting", async (_name, transport) => {
    const prompt = vi.fn();
    const output = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };
    const code = await dispatchBuilderCli([
      "register-installation",
      "--project",
      ".",
      ...transport,
    ], { output, exchangeTokenPrompt: prompt });

    expect(code).toBe(1);
    expect(output.error).toHaveBeenCalledWith("invalid_arguments");
    expect(prompt).not.toHaveBeenCalled();
    expect(JSON.stringify(output)).not.toContain(EXCHANGE_TOKEN);
  });

  it("rejects an exchange token environment variable before prompting", async () => {
    const previous = process.env.BUILDER_EXCHANGE_TOKEN;
    process.env.BUILDER_EXCHANGE_TOKEN = EXCHANGE_TOKEN;
    const prompt = vi.fn();
    const output = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };
    try {
      await expect(dispatchBuilderCli([
        "register-installation",
        "--project",
        ".",
        "--exchange-token-stdin",
      ], { output, exchangeTokenPrompt: prompt })).resolves.toBe(1);
    } finally {
      if (previous === undefined) delete process.env.BUILDER_EXCHANGE_TOKEN;
      else process.env.BUILDER_EXCHANGE_TOKEN = previous;
    }
    expect(output.error).toHaveBeenCalledWith("invalid_arguments");
    expect(prompt).not.toHaveBeenCalled();
  });

  it("runs the real bin through its declared runtime loader", () => {
    const result = spawnSync(
      process.execPath,
      [join(process.cwd(), "packages", "cli", "src", "run.js"), "--help"],
      { encoding: "utf8" },
    );

    expect(result.status).toBe(0);
    expect(result.stdout).toContain("Usage: builder register-installation");
    expect(result.stderr).toBe("");
  }, 15_000);

  it("rejects a piped token through the real runtime loader", async () => {
    const projectDir = await temporaryProject();
    await mkdir(join(projectDir, ".builder"), { recursive: true });
    await writeFile(
      join(projectDir, ".builder", "installation-manifest.json"),
      `${JSON.stringify(manifest())}\n`,
    );
    const result = spawnSync(
      process.execPath,
      [
        join(process.cwd(), "packages", "cli", "src", "run.js"),
        "register-installation",
        "--project",
        projectDir,
        "--control-plane-url",
        CONTROL_PLANE_URL,
        "--exchange-token-stdin",
        "--stable-site-key",
        "garcia-brothers",
        "--public-url",
        "https://garciabrothers.example.com",
      ],
      { encoding: "utf8", input: `${EXCHANGE_TOKEN}\n` },
    );

    expect(result.status).toBe(1);
    expect(result.stderr).toContain("exchange_token_tty_required");
    expect(`${result.stdout}${result.stderr}`).not.toContain(EXCHANGE_TOKEN);
  }, 15_000);

  it("runs builder check through the workspace-installed bin path", async () => {
    const projectDir = await temporaryProject();
    await writeFile(
      join(projectDir, "builder.config.ts"),
      `export default {
  siteId: "installed-check",
  adapter: "central",
  editor: { path: "/admin/editor", protected: true },
  pages: [{ path: "/", label: "Home", regions: [] }],
  sections: {},
};\n`,
    );
    const executable = join(
      process.cwd(),
      "node_modules",
      ".bin",
      process.platform === "win32" ? "builder.cmd" : "builder",
    );

    const result = process.platform === "win32"
      ? spawnSync(
          process.env.ComSpec ?? "cmd.exe",
          ["/d", "/c", "call", executable, "check", "--project", projectDir],
          {
            encoding: "utf8",
            env: {
              ...process.env,
              BUILDER_API_URL: "https://builder.example.com",
              BUILDER_SITE_TOKEN: "test-token",
            },
          },
        )
      : spawnSync(executable, ["check", "--project", projectDir], {
          encoding: "utf8",
          env: {
            ...process.env,
            BUILDER_API_URL: "https://builder.example.com",
            BUILDER_SITE_TOKEN: "test-token",
          },
        });

    expect(result.status).toBe(0);
    expect(result.stdout).toContain("Builder check passed.");
    expect(result.stderr).toBe("");
  });

  it("supports concise command-specific registration help without reading project files", async () => {
    const output = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };

    await expect(
      dispatchBuilderCli(["register-installation", "--help"], { output }),
    ).resolves.toBe(0);

    expect(output.info).toHaveBeenCalledWith(expect.stringContaining("register-installation"));
    expect(output.info).toHaveBeenCalledWith(expect.stringContaining("Trust precondition"));
    expect(output.info).toHaveBeenCalledWith(expect.stringContaining("--exchange-token-stdin"));
    expect(output.info).not.toHaveBeenCalledWith(expect.stringContaining("--exchange-token <"));
    expect(output.error).not.toHaveBeenCalled();
  });
});

function bodyPublicCoordinate(body: string): string {
  return JSON.parse(body).publicJwk.x;
}
