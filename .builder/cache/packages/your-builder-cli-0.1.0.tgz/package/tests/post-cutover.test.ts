import { describe, expect, it } from "vitest";
import { checkPostCutover, generatePostCutoverPatch } from "../src/migration/check-cutover.js";

const entries = [
  { entryId: "one", published: true, projectionReady: true, mediaReady: true },
  { entryId: "two", published: false, projectionReady: false, mediaReady: false },
];

describe("post cutover readiness", () => {
  it("reports partial publication, missing media, projection, and detail route", () => {
    const result = checkPostCutover({ sourceScopeKey: "announcements", entries, detailRouteReady: false });
    expect(result.ready).toBe(false);
    expect(result.issues.map((issue) => issue.code)).toEqual(expect.arrayContaining([
      "cutover.entry.unpublished", "cutover.projection.missing", "cutover.media.missing", "cutover.detail-route.missing",
    ]));
    expect(() => generatePostCutoverPatch(result)).toThrow(/not ready/i);
  });

  it("generates a separate reviewed fallback-to-live patch only when all entries are ready", () => {
    const result = checkPostCutover({
      sourceScopeKey: "announcements",
      entries: entries.map((entry) => ({ ...entry, published: true, projectionReady: true, mediaReady: true })),
      detailRouteReady: true,
    });
    const patch = generatePostCutoverPatch(result);

    expect(result.ready).toBe(true);
    expect(patch).toMatchObject({ sourceScopeKey: "announcements", from: "fallback", to: "live", requiresReview: true });
  });
});
