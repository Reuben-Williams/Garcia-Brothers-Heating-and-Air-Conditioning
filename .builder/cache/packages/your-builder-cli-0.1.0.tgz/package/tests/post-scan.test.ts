import { describe, expect, it } from "vitest";
import { scanHtmlPostCandidates } from "../src/scan/html-source.js";
import { scanNextPostCandidates } from "../src/scan/next-source.js";
import { fingerprintSource } from "../src/scan/source-fingerprint.js";

describe("post candidate scanning", () => {
  it("uses the TypeScript AST to find repeated JSX post records and renderer fields", () => {
    const source = `
      import Image from "next/image";
      import Link from "next/link";
      const news = [
        { id: "road-repairs", title: "Road repairs", excerpt: "Work starts Monday", image: "/road.jpg", date: "2026-07-14", category: "Infrastructure", href: "/news/road-repairs" },
        { id: "town-hall", title: "Town hall", excerpt: "Meet your representative", image: "/hall.jpg", date: "2026-07-20", category: "Event", href: "/news/town-hall" },
      ];
      export function News() {
        return <section>{news.map((post) => <article key={post.id}><Link href={post.href}><Image src={post.image} alt={post.title} /><time>{post.date}</time><span>{post.category}</span><h3>{post.title}</h3><p>{post.excerpt}</p></Link></article>)}</section>;
      }
    `;

    const result = scanNextPostCandidates({ source, filePath: "src/app/page.tsx", route: "/" });

    expect(result.collections).toHaveLength(1);
    expect(result.collections[0]).toMatchObject({ recordName: "news", confidence: "high", itemCount: 2 });
    expect(result.collections[0]?.fieldMappings).toMatchObject({
      title: "title", excerpt: "excerpt", image: "image", displayDate: "date", category: "category", detailHref: "href",
    });
    expect(result.collections[0]?.sourceFingerprint).toMatch(/^[a-f0-9]{64}$/);
  });

  it("flags conditional and responsive duplicate renderers for developer review", () => {
    const source = `
      const posts = [{ id: "one", title: "One" }, { id: "two", title: "Two" }];
      export function Cards({ mobile }) { return <>{mobile ? posts.map(p => <h3>{p.title}</h3>) : posts.map(p => <article><h2>{p.title}</h2></article>)}</>; }
    `;
    const result = scanNextPostCandidates({ source, filePath: "Cards.tsx", route: "/" });

    expect(result.warnings.map((warning) => warning.code)).toContain("scan.post.multiple-renderers");
    expect(result.collections[0]?.confidence).toBe("manualReview");
  });

  it("uses a structured HTML parser for legacy repeated article cards", () => {
    const html = `<section><article data-id="one"><a href="/news/one"><img src="/one.jpg" alt="One"><time>July 14</time><h3>One</h3><p>First</p></a></article><article data-id="two"><a href="/news/two"><img src="/two.jpg" alt="Two"><time>July 15</time><h3>Two</h3><p>Second</p></a></article></section>`;
    const result = scanHtmlPostCandidates({ html, filePath: "prototype.html", route: "/" });

    expect(result.collections).toHaveLength(1);
    expect(result.collections[0]).toMatchObject({ itemCount: 2, confidence: "high" });
    expect(result.collections[0]?.records[0]).toMatchObject({ title: "One", excerpt: "First", image: "/one.jpg", detailHref: "/news/one" });
  });

  it("creates deterministic source fingerprints that detect drift", () => {
    expect(fingerprintSource("const value = 1;")).toBe(fingerprintSource("const value = 1;"));
    expect(fingerprintSource("const value = 1;")).not.toBe(fingerprintSource("const value = 2;"));
  });
});
