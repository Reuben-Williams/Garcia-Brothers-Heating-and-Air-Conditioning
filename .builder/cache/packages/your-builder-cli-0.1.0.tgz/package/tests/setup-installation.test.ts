import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, describe, expect, it, vi } from "vitest";

import {
  setupInstallation,
  type SetupInstallationDependencies,
} from "../src/control-plane/setup-installation.js";
import type { WindowsAclAdapter } from "../src/control-plane/protected-files.js";
import type { HostingAdapter } from "../src/hosting/contracts.js";
import type { HostingAdapterRegistry } from "../src/hosting/adapter-registry.js";

const projects: string[] = [];
const SITE_ID = "10000000-0000-4000-8000-000000000001";
const INSTALLATION_ID = "20000000-0000-4000-8000-000000000002";
const PRIVATE_JWK = JSON.stringify({
  kty: "OKP",
  crv: "Ed25519",
  alg: "EdDSA",
  x: "A".repeat(43),
  d: "B".repeat(43),
});

afterEach(async () => {
  await Promise.all(projects.splice(0).map((path) => rm(path, { recursive: true, force: true })));
});

function allowedAcl(): WindowsAclAdapter {
  return {
    currentUserSid: async () => "S-1-5-21-owner",
    protect: async () => undefined,
    inspect: async () => ({
      ownerSid: "S-1-5-21-owner",
      inheritanceDisabled: true,
      isReparsePoint: false,
      entries: [{
        sid: "S-1-5-21-owner",
        allow: true,
        inherited: false,
        fullControl: true,
      }],
    }),
  };
}

async function project(overrides: Record<string, unknown> = {}): Promise<string> {
  const projectDir = await mkdtemp(join(tmpdir(), "builder-setup-installation-"));
  projects.push(projectDir);
  const manifest = {
    version: 1,
    packages: { "@your-builder/next": "0.1.0" },
    schemas: { posts: 1 },
    routes: ["/"],
    workerVersion: "1.2.3",
  };
  const { installationManifestSha256 } = await import("@your-builder/entitlements/trust");
  const marker = {
    version: 1,
    siteDataPlaneSiteId: SITE_ID,
    expectedSiteKey: "garcia-brothers",
    installationManifestSha256: installationManifestSha256(manifest),
    configLoaderContract: "installation-client-config-v1",
    durableStoreContract: "supabase-command-receipts-v1",
    leaseContract: "site-installation-run-lease-v1",
    leaseSeconds: 120,
    invocationTimeoutSeconds: 90,
    scheduledInvocationContract: "direct-in-process-v1",
    handlerRegistrySha256: "a".repeat(64),
    workerVersion: "1.2.3",
    reachabilityEvidenceRevision: "deploy-abc123",
    ...overrides,
  };
  await writeFile(join(projectDir, "package.json"), '{"name":"pilot"}\n');
  await (await import("node:fs/promises")).mkdir(join(projectDir, ".builder"));
  await writeFile(join(projectDir, ".builder", "installation-manifest.json"), `${JSON.stringify(manifest)}\n`);
  await writeFile(join(projectDir, ".builder", "site-runtime.json"), `${JSON.stringify(marker)}\n`);
  return projectDir;
}

async function writeAccepted(projectDir: string): Promise<void> {
  const { mkdir } = await import("node:fs/promises");
  await mkdir(join(projectDir, ".builder", "secrets"), { recursive: true });
  await writeFile(join(projectDir, ".builder", "secrets", "installation-private.jwk"), `${PRIVATE_JWK}\n`);
  await writeFile(join(projectDir, ".builder", "installation-registration.json"), `${JSON.stringify({
    version: 1,
    controlPlaneUrl: "https://control.example.com",
    stableSiteKey: "garcia-brothers",
    publicUrl: "https://garcia.example.com",
    registeredAt: "2026-07-19T12:00:00.000Z",
    installationId: INSTALLATION_ID,
    acceptedKeyId: "key-accepted",
    publicSigningKeys: [],
    endpoints: {
      pullCommands: "/api/platform/v1/installations/commands/pull",
      submitCommandResult: "/api/platform/v1/installations/commands/{commandId}/result",
      reportHealth: "/api/platform/v1/installations/health",
      rotateCredential: "/api/platform/v1/installations/credentials/rotate",
    },
  })}\n`);
}

function registry(adapter: HostingAdapter): HostingAdapterRegistry {
  return { ids: () => [adapter.id], get: () => adapter };
}

function dependencies(adapter: HostingAdapter): SetupInstallationDependencies {
  return {
    adapterRegistry: registry(adapter),
    withExchangeToken: vi.fn(async (callback) => callback("A".repeat(43))),
    platform: "win32",
    protectedFiles: { windowsAcl: allowedAcl() },
    now: () => new Date("2026-07-19T12:00:00.000Z"),
    registerInstallation: vi.fn(async (input) => {
      await writeAccepted(input.projectDir);
      return { installationId: INSTALLATION_ID, acceptedKeyId: "key-accepted", rotated: false };
    }),
    rebindInstallation: vi.fn(async (input) => {
      await writeAccepted(input.projectDir);
      return {
        installationId: INSTALLATION_ID,
        acceptedKeyId: "key-accepted",
        rotated: false as const,
        rebound: true as const,
      };
    }),
  };
}

function adapter(id: "manual" | "netlify" = "manual"): HostingAdapter {
  const target = {
    provider: id,
    accountId: "account",
    siteId: "site",
    siteName: "pilot",
    context: "staging",
    branch: null,
    scopes: ["server-runtime"],
  } as const;
  const receipt = {
    schemaVersion: 1 as const,
    target,
    projectFingerprint: "c".repeat(64),
    linkedStateHash: "d".repeat(64),
    issuedAt: "2026-07-19T12:00:00.000Z",
    expiresAt: "2026-07-19T12:10:00.000Z",
    digest: "e".repeat(64),
  };
  return {
    id,
    detect: vi.fn(async () => ({ status: "detected" as const, target })),
    preflight: vi.fn(async () => receipt),
    configure: vi.fn(async (environment) => {
      expect(environment.reveal()).toEqual({
        BUILDER_CONTROL_PLANE_URL: "https://control.example.com",
        BUILDER_INSTALLATION_ID: INSTALLATION_ID,
        BUILDER_INSTALLATION_KEY_ID: "key-accepted",
        BUILDER_INSTALLATION_PRIVATE_JWK: PRIVATE_JWK,
      });
      return { status: "configured" as const, names: environment.names() };
    }),
    verifyConfiguration: vi.fn(async () => ({
      status: id === "manual" ? "acknowledged" as const : "verified" as const,
      target,
      names: [
        "BUILDER_CONTROL_PLANE_URL",
        "BUILDER_INSTALLATION_ID",
        "BUILDER_INSTALLATION_KEY_ID",
        "BUILDER_INSTALLATION_PRIVATE_JWK",
      ] as const,
    })),
  };
}

const input = (projectDir: string, hosting: "manual" | "netlify" = "manual") => ({
  projectDir,
  controlPlaneUrl: "https://control.example.com",
  stableSiteKey: "garcia-brothers",
  publicUrl: "https://garcia.example.com",
  hosting,
} as const);

describe("setup installation", () => {
  it("rejects an unreviewed runtime before prompting or generating a key", async () => {
    const projectDir = await project({ reachabilityEvidenceRevision: null });
    const deps = dependencies(adapter());

    await expect(setupInstallation(input(projectDir), deps)).rejects.toMatchObject({
      code: "runtime_not_ready",
    });
    expect(deps.withExchangeToken).not.toHaveBeenCalled();
    expect(deps.registerInstallation).not.toHaveBeenCalled();
  });

  it("accepts a reachable runtime when both manifest and marker omit workerVersion", async () => {
    const projectDir = await project();
    const manifestPath = join(projectDir, ".builder", "installation-manifest.json");
    const markerPath = join(projectDir, ".builder", "site-runtime.json");
    const manifest = JSON.parse(await readFile(manifestPath, "utf8")) as Record<string, unknown>;
    const marker = JSON.parse(await readFile(markerPath, "utf8")) as Record<string, unknown>;
    delete manifest.workerVersion;
    delete marker.workerVersion;
    const { installationManifestSha256 } = await import("@your-builder/entitlements/trust");
    marker.installationManifestSha256 = installationManifestSha256(manifest);
    await writeFile(manifestPath, `${JSON.stringify(manifest)}\n`);
    await writeFile(markerPath, `${JSON.stringify(marker)}\n`);
    await writeAccepted(projectDir);
    const automatic = adapter("netlify");
    const deps = dependencies(automatic);

    await expect(setupInstallation(input(projectDir, "netlify"), deps)).resolves.toMatchObject({
      status: "configured",
      installationId: INSTALLATION_ID,
    });
    expect(automatic.verifyConfiguration).toHaveBeenCalledOnce();
  });

  it("registers once, loads the accepted protected identity, and creates a manual handoff", async () => {
    const projectDir = await project();
    const manual = adapter();
    const deps = dependencies(manual);

    await expect(setupInstallation(input(projectDir), deps)).resolves.toMatchObject({
      status: "hosting_handoff_pending",
      installationId: INSTALLATION_ID,
      receiptDigest: "e".repeat(64),
    });
    expect(deps.withExchangeToken).toHaveBeenCalledTimes(1);
    expect(deps.registerInstallation).toHaveBeenCalledTimes(1);
    expect(manual.configure).toHaveBeenCalledTimes(1);
    expect(manual.verifyConfiguration).not.toHaveBeenCalled();
    expect(await readFile(join(projectDir, ".builder", "secrets", "installation-setup", "journal.json"), "utf8"))
      .not.toContain(PRIVATE_JWK);
  });

  it("resumes an accepted registration without requesting the consumed exchange token", async () => {
    const projectDir = await project();
    await writeAccepted(projectDir);
    const automatic = adapter("netlify");
    const deps = dependencies(automatic);

    await expect(setupInstallation(input(projectDir, "netlify"), deps)).resolves.toMatchObject({
      status: "configured",
      installationId: INSTALLATION_ID,
    });
    expect(deps.withExchangeToken).not.toHaveBeenCalled();
    expect(deps.registerInstallation).not.toHaveBeenCalled();
    expect(automatic.verifyConfiguration).toHaveBeenCalledTimes(1);
  });

  it("routes explicit recovery through atomic rebind without generating a new registration", async () => {
    const projectDir = await project();
    const deps = dependencies(adapter());

    await expect(setupInstallation({
      ...input(projectDir),
      rebindExchange: true,
      expectedInstallationId: INSTALLATION_ID,
    }, deps)).resolves.toMatchObject({
      status: "hosting_handoff_pending",
      installationId: INSTALLATION_ID,
    });

    expect(deps.withExchangeToken).toHaveBeenCalledTimes(1);
    expect(deps.rebindInstallation).toHaveBeenCalledWith(
      {
        projectDir,
        exchangeToken: "A".repeat(43),
        expectedInstallationId: INSTALLATION_ID,
      },
      undefined,
    );
    expect(deps.registerInstallation).not.toHaveBeenCalled();
  });

  it("rejects rebind after registration has already been accepted", async () => {
    const projectDir = await project();
    await writeAccepted(projectDir);
    const manual = adapter();
    const deps = dependencies(manual);

    await expect(setupInstallation({
      ...input(projectDir),
      rebindExchange: true,
      expectedInstallationId: INSTALLATION_ID,
    }, deps)).rejects.toMatchObject({ code: "registration_unavailable" });

    expect(deps.withExchangeToken).not.toHaveBeenCalled();
    expect(deps.rebindInstallation).not.toHaveBeenCalled();
    expect(manual.detect).not.toHaveBeenCalled();
  });

  it("rejects an expected installation id outside explicit rebind mode", async () => {
    const projectDir = await project();
    await writeAccepted(projectDir);
    const manual = adapter();
    const deps = dependencies(manual);

    await expect(setupInstallation({
      ...input(projectDir),
      expectedInstallationId: INSTALLATION_ID,
    }, deps)).rejects.toMatchObject({ code: "registration_unavailable" });

    expect(deps.withExchangeToken).not.toHaveBeenCalled();
    expect(manual.detect).not.toHaveBeenCalled();
  });

  it("fails closed when a second setup process targets the same project", async () => {
    const projectDir = await project();
    await writeAccepted(projectDir);
    let release!: () => void;
    const blocked = new Promise<void>((resolve) => { release = resolve; });
    let entered!: () => void;
    const detecting = new Promise<void>((resolve) => { entered = resolve; });
    const firstAdapter = adapter("netlify");
    vi.mocked(firstAdapter.detect).mockImplementationOnce(async () => {
      entered();
      await blocked;
      return {
        status: "detected",
        target: {
          provider: "netlify",
          accountId: "account",
          siteId: "site",
          siteName: "pilot",
          context: "staging",
          branch: null,
          scopes: ["server-runtime"],
        },
      };
    });
    const first = setupInstallation(input(projectDir, "netlify"), dependencies(firstAdapter));
    await detecting;

    await expect(setupInstallation(input(projectDir, "netlify"), dependencies(adapter("netlify"))))
      .rejects.toMatchObject({ code: "setup_in_progress" });
    release();
    await first;
  });

  it("recovers a validated setup lock whose owning process is no longer alive", async () => {
    const projectDir = await project();
    await writeAccepted(projectDir);
    const lockPath = join(projectDir, ".builder", "secrets", "installation-setup.lock");
    await writeFile(lockPath, `${JSON.stringify({
      schemaVersion: 1,
      processId: 987654,
      createdAt: "2026-07-19T11:00:00.000Z",
      lockId: "30000000-0000-4000-8000-000000000003",
    })}\n`);
    const automatic = adapter("netlify");
    const isProcessAlive = vi.fn(() => false);
    const deps = {
      ...dependencies(automatic),
      isProcessAlive,
    } as SetupInstallationDependencies & { isProcessAlive(processId: number): boolean };

    await expect(setupInstallation(input(projectDir, "netlify"), deps)).resolves.toMatchObject({
      status: "configured",
      installationId: INSTALLATION_ID,
    });
    expect(isProcessAlive).toHaveBeenCalledWith(987654);
    await expect(readFile(lockPath, "utf8")).rejects.toMatchObject({ code: "ENOENT" });
  });
});
