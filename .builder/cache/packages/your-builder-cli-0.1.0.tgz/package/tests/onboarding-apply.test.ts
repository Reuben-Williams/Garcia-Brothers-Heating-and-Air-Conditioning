// @vitest-environment node

import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";

import { afterEach, describe, expect, it } from "vitest";

import {
  OnboardingError,
  applyOnboardingSourcePatch,
  canonicalOnboardingValue,
  parseOnboardingSourcePatch,
  verifyOnboardingApply,
} from "../src/onboarding/index.js";
import { fingerprintSource } from "../src/scan/source-fingerprint.js";

const temporaryDirectories: string[] = [];

function reviewedPatch(input: {
  planId?: string;
  files: Array<{ path: string; expectedCurrentHash: string | null; contents: string }>;
}) {
  const payload = {
    version: 1 as const,
    planId: input.planId ?? "a".repeat(64),
    files: input.files,
  };
  return { ...payload, patchId: fingerprintSource(canonicalOnboardingValue(payload)) };
}

afterEach(async () => {
  await Promise.all(temporaryDirectories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })));
});

describe("Phase 2D onboarding source apply", () => {
  it("parses an immutable reviewed patch and rejects protected project paths", () => {
    const patch = reviewedPatch({
      files: [{ path: "app/page.jsx", expectedCurrentHash: null, contents: "export default function Page() {}\n" }],
    });

    expect(parseOnboardingSourcePatch(patch)).toEqual(patch);
    expect(() => parseOnboardingSourcePatch({ ...patch, files: [{ ...patch.files[0], contents: "changed" }] }))
      .toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "invalid_patch" }));

    const environmentTemplate = reviewedPatch({
      files: [{ path: ".env.example", expectedCurrentHash: null, contents: "PUBLIC_VALUE=\n" }],
    });
    expect(parseOnboardingSourcePatch(environmentTemplate)).toEqual(environmentTemplate);

    for (const path of [".env", ".env.local", ".git/config", "node_modules/pkg/index.js", "site-editor-platform/file.ts", "../outside.ts"]) {
      const unsafe = reviewedPatch({ files: [{ path, expectedCurrentHash: null, contents: "blocked" }] });
      expect(() => parseOnboardingSourcePatch(unsafe))
        .toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "unsafe_project_path" }));
    }
  });

  it("refuses source drift before mutation and writes a durable reversal before a successful apply", async () => {
    const projectDir = await mkdtemp(join(process.cwd(), ".tmp-onboarding-apply-"));
    temporaryDirectories.push(projectDir);
    await writeFile(join(projectDir, "existing.js"), "owner edit\n", "utf8");
    const drifted = parseOnboardingSourcePatch(reviewedPatch({
      files: [
        { path: "existing.js", expectedCurrentHash: fingerprintSource("reviewed\n"), contents: "adapter\n" },
        { path: "new.js", expectedCurrentHash: null, contents: "new\n" },
      ],
    }));

    await expect(applyOnboardingSourcePatch({ projectDir, planId: drifted.planId, patch: drifted }))
      .rejects.toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "source_drift" }));
    await expect(readFile(join(projectDir, "existing.js"), "utf8")).resolves.toBe("owner edit\n");
    await expect(readFile(join(projectDir, "new.js"), "utf8")).rejects.toThrow();

    const approved = parseOnboardingSourcePatch(reviewedPatch({
      files: [
        { path: "existing.js", expectedCurrentHash: fingerprintSource("owner edit\n"), contents: "adapter\n" },
        { path: "new.js", expectedCurrentHash: null, contents: "new\n" },
      ],
    }));
    const receipt = await applyOnboardingSourcePatch({ projectDir, planId: approved.planId, patch: approved });

    expect(await readFile(join(projectDir, "existing.js"), "utf8")).toBe("adapter\n");
    expect(JSON.parse(await readFile(join(projectDir, receipt.reversalPath), "utf8"))).toEqual({
      version: 1,
      planId: approved.planId,
      patchId: approved.patchId,
      files: [
        { path: "existing.js", restoreContents: "owner edit\n" },
        { path: "new.js", restoreContents: null },
      ],
    });
    expect(receipt.safety).toEqual({ clientSourceMutated: true, remoteSystemsMutated: false });
    await expect(verifyOnboardingApply({ projectDir, receipt })).resolves.toEqual({
      ok: true,
      checkedFiles: 2,
      planId: approved.planId,
      patchId: approved.patchId,
    });
  });

  it("rejects a patch from another plan and detects post-apply source changes", async () => {
    const projectDir = await mkdtemp(join(process.cwd(), ".tmp-onboarding-verify-"));
    temporaryDirectories.push(projectDir);
    const patch = parseOnboardingSourcePatch(reviewedPatch({
      files: [{ path: "new.js", expectedCurrentHash: null, contents: "new\n" }],
    }));

    await expect(applyOnboardingSourcePatch({ projectDir, planId: "b".repeat(64), patch }))
      .rejects.toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "stale_patch" }));

    const receipt = await applyOnboardingSourcePatch({ projectDir, planId: patch.planId, patch });
    await writeFile(join(projectDir, "new.js"), "changed after apply\n", "utf8");
    await expect(verifyOnboardingApply({ projectDir, receipt }))
      .rejects.toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "verification_failed" }));
  });

  it("returns the same receipt when a completed apply stage is resumed", async () => {
    const projectDir = await mkdtemp(join(process.cwd(), ".tmp-onboarding-resume-"));
    temporaryDirectories.push(projectDir);
    const patch = parseOnboardingSourcePatch(reviewedPatch({
      files: [{ path: "new.js", expectedCurrentHash: null, contents: "new\n" }],
    }));

    const first = await applyOnboardingSourcePatch({ projectDir, planId: patch.planId, patch });
    const second = await applyOnboardingSourcePatch({ projectDir, planId: patch.planId, patch });

    expect(second).toEqual(first);
    await expect(readFile(join(projectDir, "new.js"), "utf8")).resolves.toBe("new\n");
  });

  it("recovers an interrupted journal before resuming the approved apply", async () => {
    const projectDir = await mkdtemp(join(process.cwd(), ".tmp-onboarding-interrupted-"));
    temporaryDirectories.push(projectDir);
    await writeFile(join(projectDir, "existing.js"), "before\n");
    const patch = parseOnboardingSourcePatch(reviewedPatch({
      files: [{
        path: "existing.js",
        expectedCurrentHash: fingerprintSource("before\n"),
        contents: "after\n",
      }],
    }));
    const first = await applyOnboardingSourcePatch({ projectDir, planId: patch.planId, patch });
    const journalPath = join(projectDir, first.journalPath);
    const journal = JSON.parse(await readFile(journalPath, "utf8"));
    journal.status = "pending";
    delete journal.completedAt;
    await writeFile(journalPath, JSON.stringify(journal, null, 2));
    await writeFile(join(projectDir, "existing.js"), "partial write\n");

    const resumed = await applyOnboardingSourcePatch({ projectDir, planId: patch.planId, patch });

    expect(resumed).toEqual(first);
    await expect(readFile(join(projectDir, "existing.js"), "utf8")).resolves.toBe("after\n");
  });

  it.each([
    ["plan ID", (journal: Record<string, any>) => { journal.planId = "b".repeat(64); }],
    ["patch ID", (journal: Record<string, any>) => { journal.patchId = "b".repeat(64); }],
    ["approved file set", (journal: Record<string, any>) => {
      journal.files.push({ path: "victim.js", before: "overwritten\n", afterHash: "b".repeat(64) });
    }],
    ["approved path", (journal: Record<string, any>) => { journal.files[0].path = "victim.js"; }],
    ["before contents", (journal: Record<string, any>) => { journal.files[0].before = "overwritten\n"; }],
    ["after hash", (journal: Record<string, any>) => { journal.files[0].afterHash = "b".repeat(64); }],
  ])("rejects a recovery journal with a tampered %s before writing", async (_label, tamper) => {
    const projectDir = await mkdtemp(join(process.cwd(), ".tmp-onboarding-tampered-journal-"));
    temporaryDirectories.push(projectDir);
    await writeFile(join(projectDir, "existing.js"), "before\n");
    await writeFile(join(projectDir, "victim.js"), "safe\n");
    const patch = parseOnboardingSourcePatch(reviewedPatch({
      files: [{
        path: "existing.js",
        expectedCurrentHash: fingerprintSource("before\n"),
        contents: "after\n",
      }],
    }));
    const first = await applyOnboardingSourcePatch({ projectDir, planId: patch.planId, patch });
    const journalPath = join(projectDir, first.journalPath);
    const journal = JSON.parse(await readFile(journalPath, "utf8")) as Record<string, any>;
    journal.status = "pending";
    delete journal.completedAt;
    tamper(journal);
    await writeFile(journalPath, JSON.stringify(journal, null, 2));
    await writeFile(join(projectDir, "existing.js"), "partial write\n");

    await expect(applyOnboardingSourcePatch({ projectDir, planId: patch.planId, patch }))
      .rejects.toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "verification_failed" }));
    await expect(readFile(join(projectDir, "existing.js"), "utf8")).resolves.toBe("partial write\n");
    await expect(readFile(join(projectDir, "victim.js"), "utf8")).resolves.toBe("safe\n");
  });

  it("rejects a recovery journal path that escapes the project before writing", async () => {
    const projectDir = await mkdtemp(join(process.cwd(), ".tmp-onboarding-escaping-journal-"));
    temporaryDirectories.push(projectDir);
    await writeFile(join(projectDir, "existing.js"), "before\n");
    const patch = parseOnboardingSourcePatch(reviewedPatch({
      files: [{ path: "existing.js", expectedCurrentHash: fingerprintSource("before\n"), contents: "after\n" }],
    }));
    const first = await applyOnboardingSourcePatch({ projectDir, planId: patch.planId, patch });
    const journalPath = join(projectDir, first.journalPath);
    const journal = JSON.parse(await readFile(journalPath, "utf8"));
    journal.status = "pending";
    delete journal.completedAt;
    journal.files[0].path = "../outside.js";
    await writeFile(journalPath, JSON.stringify(journal, null, 2));
    await writeFile(join(projectDir, "existing.js"), "partial write\n");

    await expect(applyOnboardingSourcePatch({ projectDir, planId: patch.planId, patch }))
      .rejects.toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "verification_failed" }));
    await expect(readFile(join(projectDir, "existing.js"), "utf8")).resolves.toBe("partial write\n");
  });
});
