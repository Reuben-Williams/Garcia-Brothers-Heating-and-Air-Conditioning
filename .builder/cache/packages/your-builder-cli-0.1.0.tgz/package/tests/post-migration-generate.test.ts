import { describe, expect, it } from "vitest";
import { buildPostReviewManifest, generatePostMigrationArtifacts } from "../src/migration/generate-posts.js";

const record = {
  sourceRecordKey: "road-repairs",
  entryId: "06a80923-d9a6-4e46-8e7b-c7a475f7a915",
  fallbackEntryId: "06a80923-d9a6-4e46-8e7b-c7a475f7a915",
  approvedFields: {
    slug: "road-repairs",
    data: {
      title: "Road repairs",
      excerpt: "Work starts Monday.",
      body: { version: 1 as const, type: "doc" as const, content: [] },
      featuredImage: null,
      author: { key: null, name: "District Office" },
      featured: false,
      pinned: false,
      seo: { title: "Road repairs", description: "Work starts Monday.", canonicalUrl: null, socialImage: null, noIndex: false },
    },
    taxonomyKeys: { categories: ["infrastructure"], tags: [] },
    taxonomySnapshot: { infrastructure: { label: "Infrastructure", slug: "infrastructure" } },
    displayDate: "2026-07-14T12:00:00.000Z",
    expiresAt: null,
  },
};

const input = {
  toolVersion: "0.1.0",
  siteKey: "assembly",
  sourceScopeKey: "assembly-announcements-v1",
  collectionRegionId: "home.communityAnnouncements",
  sourceFiles: [{ path: "src/prototype.html", contents: "<article>Road repairs</article>" }],
  candidates: [{
    candidateId: "home-announcements",
    sourceFile: "src/prototype.html",
    sourceSpan: { start: 0, end: 38 },
    transform: "replace-post-collection" as const,
    fieldMappings: [{ postField: "title", sourceExpression: "h3" }],
    categoryMappings: { Infrastructure: "infrastructure" },
  }],
  detailRoute: { route: "/news/[postSlug]", sourceFile: "src/app/news/[postSlug]/page.tsx", rendererExport: "AssemblyPostDetail" },
  fallbackSource: { sourceFile: "src/content/posts/fallback-posts.ts", exportName: "fallbackPosts" },
  collectionRenderer: { sourceFile: "src/components/posts/AssemblyAnnouncementCard.tsx", exportName: "AssemblyAnnouncementCard", variant: "featured" },
  records: [record],
};

describe("post migration generation", () => {
  it("content-addresses the reviewed source and approved seed payload", async () => {
    const first = await buildPostReviewManifest(input);
    const second = await buildPostReviewManifest(input);
    const changed = await buildPostReviewManifest({ ...input, sourceFiles: [{ ...input.sourceFiles[0], contents: "changed" }] });

    expect(first.manifestId).toBe(second.manifestId);
    expect(first.seedHash).toBe(second.seedHash);
    expect(first.sourceFiles[0]?.sha256).toMatch(/^[a-f0-9]{64}$/);
    expect(changed.manifestId).not.toBe(first.manifestId);
  });

  it("generates typed fallback, config, collection, detail route, seed, and validation artifacts", async () => {
    const manifest = await buildPostReviewManifest(input);
    const generated = generatePostMigrationArtifacts(manifest);

    expect(generated.files.map((file) => file.path)).toEqual(expect.arrayContaining([
      "src/content/posts/fallback-posts.ts",
      "src/components/posts/GeneratedPostCollection.tsx",
      "src/app/news/[postSlug]/page.tsx",
      ".builder/migrations/seed-posts.json",
      ".builder/migrations/validation-report.json",
    ]));
    expect(generated.files.find((file) => file.path.endsWith("fallback-posts.ts"))?.contents).toContain("06a80923-d9a6-4e46-8e7b-c7a475f7a915");
    expect(generated.validation.readyToApply).toBe(true);
    expect(generated.validation.publishesContent).toBe(false);
  });
});
