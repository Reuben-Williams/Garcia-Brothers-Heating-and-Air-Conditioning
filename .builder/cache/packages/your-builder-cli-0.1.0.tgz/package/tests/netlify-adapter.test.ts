import { describe, expect, it, vi } from "vitest";

import { createNetlifyAdapter } from "../src/hosting/netlify/netlify-adapter.js";

describe("Netlify automatic adapter gate", () => {
  it("fails before discovery or mutation when credential and scope proofs are unavailable", () => {
    const spawn = vi.fn();
    const fetch = vi.fn();

    expect(() => createNetlifyAdapter({ spawn, fetch })).toThrowError(
      expect.objectContaining({ code: "automatic_credential_source_unsupported" }),
    );
    expect(spawn).not.toHaveBeenCalled();
    expect(fetch).not.toHaveBeenCalled();
  });
});
