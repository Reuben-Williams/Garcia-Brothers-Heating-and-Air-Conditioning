import { describe, expect, it } from "vitest";

import { getAutomaticNetlifyCredentialSourceStatus } from "../src/hosting/netlify/credential-provider.js";

describe("Netlify credential source gate", () => {
  it("is compiled disabled when Task 0 did not freeze a supported source", () => {
    expect(getAutomaticNetlifyCredentialSourceStatus()).toEqual({
      enabled: false,
      code: "automatic_credential_source_unsupported",
    });
  });

  it("does not accept an environment, argv, file, or interactive override", () => {
    expect(getAutomaticNetlifyCredentialSourceStatus.length).toBe(0);
    expect(JSON.stringify(getAutomaticNetlifyCredentialSourceStatus())).not.toMatch(/token|auth/i);
  });
});
