import { describe, expect, it } from "vitest";

import { getNetlifyAutomaticScopeStatus } from "../src/hosting/netlify/scope-profile.js";

describe("Netlify exact-scope gate", () => {
  it("keeps the reviewed profile unavailable until a disposable free-account proof passes", () => {
    expect(getNetlifyAutomaticScopeStatus()).toEqual({
      enabled: false,
      profile: "netlify-next-server-v1",
      code: "automatic_scope_proof_unavailable",
    });
  });
});
