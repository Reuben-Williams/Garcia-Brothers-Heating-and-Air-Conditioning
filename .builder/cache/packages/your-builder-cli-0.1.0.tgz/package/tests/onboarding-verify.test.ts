// @vitest-environment node

import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";

import { afterEach, describe, expect, it, vi } from "vitest";

import { dispatchBuilderCli } from "../src/bin.js";
import {
  applyOnboardingSourcePatch,
  canonicalOnboardingValue,
  inspectOnboardingProject,
  parseOnboardingManifest,
  parseOnboardingSourcePatch,
  planOnboardingAttachment,
  parseOnboardingStageReceipt,
  verifyOnboardingProject,
} from "../src/onboarding/index.js";
import { fingerprintSource } from "../src/scan/source-fingerprint.js";

const temporaryDirectories: string[] = [];

async function writeJson(path: string, value: unknown) {
  await writeFile(path, `${JSON.stringify(value, null, 2)}\n`);
}

async function verificationFixture() {
  const projectDir = await mkdtemp(join(process.cwd(), ".tmp-onboarding-aggregate-"));
  temporaryDirectories.push(projectDir);
  for (const path of [
    [".builder"],
    [".builder", "evidence"],
    ["app", "admin", "editor"],
    ["app", "api", "builder"],
    ["lib"],
    ["out"],
  ]) await mkdir(join(projectDir, ...path), { recursive: true });

  await writeFile(join(projectDir, "builder.config.ts"), `export default {
  siteId: "local-service-staging",
  adapter: "central",
  editor: { path: "/admin/editor", protected: true },
  pages: [{ path: "/", label: "Home", regions: [{ id: "home.hero.title", kind: "text", label: "Hero title" }] }],
  sections: {},
};\n`);
  await writeFile(join(projectDir, "app", "page.tsx"), `const fallbackContent = { title: "Local service" };
export default function Page() { return <main>{fallbackContent.title}</main>; }\n`);
  await writeFile(join(projectDir, "app", "admin", "editor", "page.tsx"),
    "export default function EditorPage() { return null; }\n");
  await writeFile(join(projectDir, "app", "api", "builder", "route.ts"), `import "server-only";
const privateKeyPath = ".builder/secrets/installation-private.jwk";
export function GET() { return Response.json({ configured: Boolean(privateKeyPath) }); }\n`);
  await writeFile(join(projectDir, "lib", "installation-worker.ts"), `import "server-only";
import { createInstallationWorker } from "@your-builder/next/control-plane";
export const workerFactory = createInstallationWorker;\n`);
  await writeFile(join(projectDir, "lib", "entitlement-snapshot.ts"), `import "server-only";
import { createEntitlementSnapshotCache } from "@your-builder/entitlements/server";
export const snapshotFactory = createEntitlementSnapshotCache;\n`);
  await writeFile(join(projectDir, "out", "index.html"), "<main><h1>Local service</h1></main>\n");
  await writeJson(join(projectDir, "package.json"), {
    dependencies: {
      "@your-builder/entitlements": "0.1.0",
      "@your-builder/next": "0.1.0",
      "@your-builder/reviews": "1.2.1",
    },
  });
  await writeJson(join(projectDir, ".builder", "installation-manifest.json"), {
    version: 1,
    packages: {},
    schemas: { reviews: 2 },
    routes: ["/", "/admin/editor", "/reviews", "/api/reviews/sync"],
    workerVersion: "0.3.1",
  });
  await writeJson(join(projectDir, ".builder", "module-manifest.json"), {
    manifestVersion: 1,
    moduleId: "growth.reviews",
    moduleVersion: "1.0.0",
    requirements: {
      packages: { "@your-builder/reviews": "1.2.0" },
      schemas: { reviews: 2 },
      routes: ["/reviews", "/api/reviews/sync"],
      minimumWorkerVersion: "0.3.0",
    },
  });

  const manifest = parseOnboardingManifest({
    version: 1,
    site: {
      siteId: "local-service-staging",
      stableSiteKey: "local-service",
      framework: "next-app-router",
      editorPath: "/admin/editor",
    },
    routes: [{ path: "/", pageSlug: "home", source: "app/page.tsx", renderedArtifact: "out/index.html" }],
    modules: [{ id: "growth.reviews", version: "1.0.0" }],
  });
  const report = await inspectOnboardingProject({ projectDir, manifest });
  const candidate = report.candidates.find((entry) => entry.kind === "text")!;
  const plan = planOnboardingAttachment({
    report,
    approval: {
      version: 1,
      reviewId: report.reviewId,
      mappings: [{ stableId: "home.hero.title", category: "editableRegion", kind: "text", candidateIds: [candidate.id] }],
      exclusions: report.candidates
        .filter((entry) => entry.id !== candidate.id)
        .map((entry) => ({ reason: "out-of-scope" as const, candidateIds: [entry.id] })),
    },
  });
  const patchPayload = {
    version: 1 as const,
    planId: plan.planId,
    files: [{ path: "adapter-marker.ts", expectedCurrentHash: null, contents: "export const attached = true;\n" }],
  };
  const patch = parseOnboardingSourcePatch({
    ...patchPayload,
    patchId: fingerprintSource(canonicalOnboardingValue(patchPayload)),
  });
  const applyReceipt = await applyOnboardingSourcePatch({ projectDir, planId: plan.planId, patch });
  const sourceSha256 = fingerprintSource(canonicalOnboardingValue({
    version: 1,
    reviewId: report.reviewId,
    planId: plan.planId,
    applyReceiptId: applyReceipt.receiptId,
    files: [...new Map([
      ...report.routes.map((route) => [route.source, route.sourceSha256] as const),
      ...applyReceipt.files.map((file) => [file.path, file.afterHash] as const),
    ]).entries()]
      .map(([path, sha256]) => ({ path, sha256 }))
      .sort((left, right) => left.path.localeCompare(right.path)),
  }));
  const buildPath = ".builder/evidence/production-build.json";
  const responsivePath = ".builder/evidence/responsive-smoke.json";
  const buildArtifactPath = ".builder/evidence/production-build-artifact.json";
  const buildArtifact = {
    version: 1,
    kind: "production-build-artifact",
    sourceSha256,
    outputs: [{
      path: "out/index.html",
      sha256: fingerprintSource(await readFile(join(projectDir, "out", "index.html"), "utf8")),
    }],
  };
  const buildArtifactContents = `${JSON.stringify(buildArtifact, null, 2)}\n`;
  await writeFile(join(projectDir, buildArtifactPath), buildArtifactContents);
  const buildContents = `${JSON.stringify({
    version: 1,
    kind: "production-build",
    sourceSha256,
    command: "npm run build",
    runner: "builder-cli",
    exitCode: 0,
    artifact: { path: buildArtifactPath, sha256: fingerprintSource(buildArtifactContents) },
  }, null, 2)}\n`;
  await writeFile(join(projectDir, buildPath), buildContents);

  const responsiveResults = [];
  for (const viewport of [390, 768, 1280]) {
    const artifactPath = `.builder/evidence/responsive-${viewport}.json`;
    const artifactContents = `${JSON.stringify({
      version: 1,
      kind: "responsive-viewport-artifact",
      sourceSha256,
      viewport,
      checks: { pageLoaded: true, noHorizontalOverflow: true },
    }, null, 2)}\n`;
    await writeFile(join(projectDir, artifactPath), artifactContents);
    responsiveResults.push({
      viewport,
      status: "passed",
      artifact: { path: artifactPath, sha256: fingerprintSource(artifactContents) },
    });
  }
  const responsiveContents = `${JSON.stringify({
    version: 1,
    kind: "responsive-smoke",
    sourceSha256,
    command: "npm run test:responsive-smoke",
    runner: "playwright",
    exitCode: 0,
    results: responsiveResults,
  }, null, 2)}\n`;
  await writeFile(join(projectDir, responsivePath), responsiveContents);
  const evidence = {
    version: 1 as const,
    reviewId: report.reviewId,
    planId: plan.planId,
    applyReceiptId: applyReceipt.receiptId,
    productionBuild: { path: buildPath, sha256: fingerprintSource(buildContents) },
    responsiveSmoke: { path: responsivePath, sha256: fingerprintSource(responsiveContents) },
  };
  return { projectDir, report, plan, applyReceipt, evidence, buildPath, buildArtifactPath, responsivePath };
}

afterEach(async () => {
  vi.unstubAllEnvs();
  await Promise.all(temporaryDirectories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })));
});

describe("Phase 2D aggregate onboarding verification", () => {
  it("aggregates existing source, config, manifest, compatibility, foundation, build, and responsive boundaries", async () => {
    const fixture = await verificationFixture();

    const first = await verifyOnboardingProject({
      ...fixture,
      env: { BUILDER_API_URL: "https://builder.example.test", BUILDER_SITE_TOKEN: "fixture-token" },
    });
    const second = await verifyOnboardingProject({
      ...fixture,
      env: { BUILDER_API_URL: "https://builder.example.test", BUILDER_SITE_TOKEN: "fixture-token" },
    });

    expect(first).toEqual(second);
    expect(first.ok).toBe(true);
    expect(first.verificationId).toMatch(/^[a-f0-9]{64}$/);
    expect(first.checks.map((check) => check.id)).toEqual([
      "source_hashes",
      "rendered_artifacts",
      "config_rendered_regions",
      "installation_manifest",
      "module_manifest",
      "package_compatibility",
      "protected_editor_and_growth_foundation",
      "production_build",
      "responsive_smoke",
    ]);
    expect(first.checks.every((check) => check.status === "pass")).toBe(true);
    expect(first.safety).toEqual({ clientSourceMutated: false, remoteSystemsMutated: false });
  });

  it("fails closed when responsive evidence omits a required viewport", async () => {
    const fixture = await verificationFixture();
    const responsiveReceipt = JSON.parse(await readFile(join(fixture.projectDir, fixture.responsivePath), "utf8"));
    responsiveReceipt.results = responsiveReceipt.results.filter((result: { viewport: number }) => result.viewport !== 1280);
    const responsiveContents = `${JSON.stringify(responsiveReceipt, null, 2)}\n`;
    await writeFile(join(fixture.projectDir, fixture.responsivePath), responsiveContents);
    const evidence = {
      ...fixture.evidence,
      responsiveSmoke: { ...fixture.evidence.responsiveSmoke, sha256: fingerprintSource(responsiveContents) },
    };

    const result = await verifyOnboardingProject({
      ...fixture,
      evidence,
      env: { BUILDER_API_URL: "https://builder.example.test", BUILDER_SITE_TOKEN: "fixture-token" },
    });

    expect(result.ok).toBe(false);
    expect(result.checks).toContainEqual(expect.objectContaining({ id: "responsive_smoke", status: "fail" }));
    expect(result.issues).toContainEqual(expect.objectContaining({ code: "RESPONSIVE_VIEWPORT_MISSING" }));
  });

  it("rejects a self-authored build status document even when its digest matches", async () => {
    const fixture = await verificationFixture();
    const fabricated = `${JSON.stringify({ status: "passed", command: "npm run build" })}\n`;
    await writeFile(join(fixture.projectDir, fixture.buildPath), fabricated);

    const result = await verifyOnboardingProject({
      ...fixture,
      evidence: {
        ...fixture.evidence,
        productionBuild: { ...fixture.evidence.productionBuild, sha256: fingerprintSource(fabricated) },
      },
      env: { BUILDER_API_URL: "https://builder.example.test", BUILDER_SITE_TOKEN: "fixture-token" },
    });

    expect(result.ok).toBe(false);
    expect(result.issues).toContainEqual(expect.objectContaining({ code: "PRODUCTION_BUILD_INVALID" }));
  });

  it("rejects a build receipt whose rehashed output does not match its artifact", async () => {
    const fixture = await verificationFixture();
    const artifact = JSON.parse(await readFile(join(fixture.projectDir, fixture.buildArtifactPath), "utf8"));
    artifact.outputs[0].sha256 = "b".repeat(64);
    const artifactContents = `${JSON.stringify(artifact, null, 2)}\n`;
    await writeFile(join(fixture.projectDir, fixture.buildArtifactPath), artifactContents);

    const receipt = JSON.parse(await readFile(join(fixture.projectDir, fixture.buildPath), "utf8"));
    receipt.artifact.sha256 = fingerprintSource(artifactContents);
    const receiptContents = `${JSON.stringify(receipt, null, 2)}\n`;
    await writeFile(join(fixture.projectDir, fixture.buildPath), receiptContents);

    const result = await verifyOnboardingProject({
      ...fixture,
      evidence: {
        ...fixture.evidence,
        productionBuild: { ...fixture.evidence.productionBuild, sha256: fingerprintSource(receiptContents) },
      },
      env: { BUILDER_API_URL: "https://builder.example.test", BUILDER_SITE_TOKEN: "fixture-token" },
    });

    expect(result.ok).toBe(false);
    expect(result.issues).toContainEqual(expect.objectContaining({ code: "PRODUCTION_BUILD_ARTIFACT_DRIFT" }));
  });

  it("detects changed rendered evidence after inspection", async () => {
    const fixture = await verificationFixture();
    await writeFile(join(fixture.projectDir, "out", "index.html"), "<main>changed</main>\n");

    const result = await verifyOnboardingProject({
      ...fixture,
      env: { BUILDER_API_URL: "https://builder.example.test", BUILDER_SITE_TOKEN: "fixture-token" },
    });

    expect(result.ok).toBe(false);
    expect(result.issues).toContainEqual(expect.objectContaining({ code: "RENDERED_ARTIFACT_DRIFT" }));
  });

  it("detects drift in inspected source that was not part of the approved patch", async () => {
    const fixture = await verificationFixture();
    await writeFile(join(fixture.projectDir, "app", "page.tsx"), "export default function Page() { return null; }\n");

    const result = await verifyOnboardingProject({
      ...fixture,
      env: { BUILDER_API_URL: "https://builder.example.test", BUILDER_SITE_TOKEN: "fixture-token" },
    });

    expect(result.ok).toBe(false);
    expect(result.issues).toContainEqual(expect.objectContaining({ code: "SOURCE_HASH_MISMATCH", path: "app/page.tsx" }));
  });

  it("dispatches the aggregate stage idempotently with a deterministic receipt", async () => {
    const fixture = await verificationFixture();
    const reviewPath = join(fixture.projectDir, ".builder", "review.json");
    const planPath = join(fixture.projectDir, ".builder", "plan.json");
    const applyPath = join(fixture.projectDir, ".builder", "apply-receipt.json");
    const evidencePath = join(fixture.projectDir, ".builder", "verification-evidence.json");
    const outputPath = join(fixture.projectDir, ".builder", "verification.json");
    await writeJson(reviewPath, fixture.report);
    await writeJson(planPath, fixture.plan);
    await writeJson(applyPath, fixture.applyReceipt);
    await writeJson(evidencePath, fixture.evidence);
    const output = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };
    vi.stubEnv("BUILDER_API_URL", "https://builder.example.test");
    vi.stubEnv("BUILDER_SITE_TOKEN", "fixture-token");
    const args = [
      "onboard", "--stage", "verify", "--project", fixture.projectDir,
      "--review", reviewPath, "--plan", planPath, "--receipt", applyPath,
      "--evidence", evidencePath, "--output", outputPath,
    ];

    await expect(dispatchBuilderCli(args, { output })).resolves.toBe(0);
    const first = await readFile(outputPath, "utf8");
    const verification = JSON.parse(first) as { verificationId: string };
    expect(parseOnboardingStageReceipt(JSON.parse(await readFile(`${outputPath}.receipt.json`, "utf8"))))
      .toMatchObject({ stage: "verify", outputId: verification.verificationId });
    await expect(dispatchBuilderCli(args, { output })).resolves.toBe(0);
    await expect(readFile(outputPath, "utf8")).resolves.toBe(first);
    expect(output.error).not.toHaveBeenCalled();
  });
});
