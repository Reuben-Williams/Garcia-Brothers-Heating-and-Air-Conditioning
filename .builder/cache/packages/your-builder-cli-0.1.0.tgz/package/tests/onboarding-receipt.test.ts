// @vitest-environment node

import { describe, expect, it } from "vitest";

import {
  createOnboardingStageReceipt,
  parseOnboardingStageReceipt,
} from "../src/onboarding/index.js";

describe("Phase 2D deterministic onboarding stage receipts", () => {
  it("creates the same secret-free receipt for the same stage inputs and output", () => {
    const input = {
      stage: "inspect" as const,
      inputIds: { manifestSha256: "a".repeat(64) },
      outputId: "b".repeat(64),
    };

    const first = createOnboardingStageReceipt(input);
    const second = createOnboardingStageReceipt(input);

    expect(second).toEqual(first);
    expect(first.receiptId).toMatch(/^[a-f0-9]{64}$/);
    expect(JSON.stringify(first)).not.toMatch(/token|private|secret/i);
    expect(parseOnboardingStageReceipt(first)).toEqual(first);
  });

  it("rejects tampered and non-digest identifiers", () => {
    const receipt = createOnboardingStageReceipt({
      stage: "verify",
      inputIds: { applyReceiptId: "a".repeat(64) },
      outputId: "b".repeat(64),
    });

    expect(() => parseOnboardingStageReceipt({ ...receipt, outputId: "c".repeat(64) }))
      .toThrowError(expect.objectContaining({ code: "verification_failed" }));
    expect(() => createOnboardingStageReceipt({
      stage: "verify",
      inputIds: { applyReceiptId: "not-a-digest" },
      outputId: "b".repeat(64),
    })).toThrowError(expect.objectContaining({ code: "verification_failed" }));
  });
});
