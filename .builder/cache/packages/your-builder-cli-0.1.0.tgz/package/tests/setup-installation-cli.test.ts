import { describe, expect, it, vi } from "vitest";

import { dispatchBuilderCli } from "../src/bin.js";
import type { ExchangeTokenSecret } from "../src/control-plane/secret-prompt.js";
import type { setupInstallation } from "../src/control-plane/setup-installation.js";

const TOKEN = "A".repeat(43);

function secret(): ExchangeTokenSecret {
  let consumed = false;
  return {
    async use(callback) {
      if (consumed) throw new Error("consumed");
      consumed = true;
      return callback(TOKEN);
    },
    toJSON: () => "[REDACTED]",
    toString: () => "[REDACTED]",
  };
}

describe("setup-installation command", () => {
  it("dispatches the generated one-line command through the one-use masked token callback", async () => {
    const lines: string[] = [];
    const errors: string[] = [];
    const setup = vi.fn<typeof setupInstallation>(async (input, dependencies) => {
      expect(input).toMatchObject({
        controlPlaneUrl: "https://control.example.com",
        stableSiteKey: "garcia-brothers",
        publicUrl: "https://garcia.example.com",
        hosting: "manual",
      });
      await expect(dependencies.withExchangeToken(async (token) => token)).resolves.toBe(TOKEN);
      return {
        status: "hosting_handoff_pending",
        installationId: "20000000-0000-4000-8000-000000000002",
        acceptedKeyId: "key-safe",
        receiptDigest: "a".repeat(64),
      };
    });

    await expect(dispatchBuilderCli([
      "setup-installation",
      "--project", ".",
      "--control-plane-url", "https://control.example.com",
      "--stable-site-key", "garcia-brothers",
      "--public-url", "https://garcia.example.com",
      "--hosting", "manual",
      "--exchange-token-stdin",
    ], {
      setup,
      exchangeTokenPrompt: async () => secret(),
      confirmHostingTarget: async () => true,
      output: {
        info: (line) => lines.push(line),
        warn: vi.fn(),
        error: (line) => errors.push(line),
      },
    })).resolves.toBe(0);

    expect(setup).toHaveBeenCalledOnce();
    expect(lines.join("\n")).toContain("hosting_handoff_pending");
    expect(lines.join("\n")).not.toContain(TOKEN);
    expect(errors).toEqual([]);
  });

  it.each([
    ["missing masked-input flag", []],
    ["legacy token value", ["--exchange-token", TOKEN]],
    ["unknown hosting mode", ["--exchange-token-stdin", "--hosting", "other"]],
  ])("rejects %s", async (_label, extra) => {
    const setup = vi.fn<typeof setupInstallation>();
    const error = vi.fn();
    const base = [
      "setup-installation",
      "--project", ".",
      "--control-plane-url", "https://control.example.com",
      "--stable-site-key", "garcia-brothers",
      "--public-url", "https://garcia.example.com",
    ];

    await expect(dispatchBuilderCli([...base, ...extra], {
      setup,
      output: { info: vi.fn(), warn: vi.fn(), error },
    })).resolves.toBe(1);

    expect(setup).not.toHaveBeenCalled();
    expect(error).toHaveBeenCalledWith("invalid_arguments");
  });

  it("passes the expected installation identity only on explicit rebind", async () => {
    const setup = vi.fn<typeof setupInstallation>(async (input) => {
      expect(input).toMatchObject({
        rebindExchange: true,
        expectedInstallationId: "20000000-0000-4000-8000-000000000002",
      });
      return {
        status: "hosting_handoff_pending",
        installationId: "20000000-0000-4000-8000-000000000002",
        acceptedKeyId: "key-safe",
        receiptDigest: "a".repeat(64),
      };
    });

    await expect(dispatchBuilderCli([
      "setup-installation",
      "--project", ".",
      "--control-plane-url", "https://control.example.com",
      "--stable-site-key", "garcia-brothers",
      "--public-url", "https://garcia.example.com",
      "--hosting", "manual",
      "--exchange-token-stdin",
      "--rebind-exchange",
      "--expected-installation-id", "20000000-0000-4000-8000-000000000002",
    ], {
      setup,
      exchangeTokenPrompt: async () => secret(),
      confirmHostingTarget: async () => true,
      output: { info: vi.fn(), warn: vi.fn(), error: vi.fn() },
    })).resolves.toBe(0);
    expect(setup).toHaveBeenCalledOnce();
  });
});
