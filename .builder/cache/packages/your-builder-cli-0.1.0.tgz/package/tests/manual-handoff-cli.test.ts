import { describe, expect, it, vi } from "vitest";

import { dispatchBuilderCli } from "../src/bin.js";
import type { ManualHandoffController } from "../src/hosting/manual/manual-adapter.js";

const NAMES = [
  "BUILDER_CONTROL_PLANE_URL",
  "BUILDER_INSTALLATION_ID",
  "BUILDER_INSTALLATION_KEY_ID",
  "BUILDER_INSTALLATION_PRIVATE_JWK",
] as const;

function dependencies(status: "pending" | "absent" = "pending") {
  const lines: string[] = [];
  const errors: string[] = [];
  const controller: ManualHandoffController = {
    status: vi.fn(async () => status === "pending"
      ? {
          status: "pending" as const,
          path: "C:\\pilot\\.builder\\secrets\\hosting-handoff\\environment.json",
          names: NAMES,
        }
      : { status: "absent" as const }),
    confirm: vi.fn(async () => ({
      status: "acknowledged" as const,
      target: {
        provider: "manual" as const,
        accountId: "manual",
        siteId: "a".repeat(64),
        siteName: "pilot",
        context: "staging",
        branch: null,
        scopes: ["server-runtime"],
      },
      names: NAMES,
    })),
    cleanup: vi.fn(async () => ({ status: "cleaned" as const })),
  };
  return {
    controller,
    lines,
    errors,
    cli: {
      manualHandoffController: controller,
      output: {
        info: (line: string) => lines.push(line),
        warn: vi.fn(),
        error: (line: string) => errors.push(line),
      },
    },
  };
}

describe("hosting-handoff command", () => {
  it.each(["--status", "--confirm", "--cleanup"])("runs the exact %s action", async (action) => {
    const fixture = dependencies();
    await expect(dispatchBuilderCli([
      "hosting-handoff",
      "--project",
      ".",
      action,
    ], fixture.cli)).resolves.toBe(0);

    const method = action.slice(2) as "status" | "confirm" | "cleanup";
    expect(fixture.controller[method]).toHaveBeenCalledOnce();
    expect(fixture.lines.join("\n")).not.toMatch(/private-jwk-canary|exchange-token/i);
    expect(fixture.errors).toEqual([]);
  });

  it("rejects multiple actions and any value-printing flag", async () => {
    for (const actions of [
      ["--status", "--confirm"],
      ["--show"],
      ["--print"],
    ]) {
      const fixture = dependencies();
      await expect(dispatchBuilderCli([
        "hosting-handoff",
        "--project",
        ".",
        ...actions,
      ], fixture.cli)).resolves.toBe(1);
      expect(fixture.errors).toEqual(["invalid_arguments"]);
      expect(fixture.controller.status).not.toHaveBeenCalled();
      expect(fixture.controller.confirm).not.toHaveBeenCalled();
      expect(fixture.controller.cleanup).not.toHaveBeenCalled();
    }
  });
});
