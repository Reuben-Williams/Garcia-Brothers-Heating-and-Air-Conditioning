// @vitest-environment node

import { mkdtemp, mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";

import { afterEach, describe, expect, it } from "vitest";

import {
  OnboardingError,
  inspectOnboardingProject,
  parseOnboardingManifest,
} from "../src/onboarding/index.js";

const temporaryDirectories: string[] = [];

function manifest() {
  return {
    version: 1,
    site: {
      siteId: "garcia-brothers-staging",
      stableSiteKey: "garcia-brothers-hvac",
      framework: "next-app-router",
      editorPath: "/admin/editor",
    },
    routes: [
      { path: "/", pageSlug: "home", source: "app/page.jsx", renderedArtifact: "out/index.html" },
      { path: "/contact", pageSlug: "contact", source: "app/contact/page.jsx", renderedArtifact: "out/contact.html" },
    ],
    modules: [
      { id: "growth.customers", version: "1.0.0" },
      { id: "growth.leads", version: "1.0.0" },
      { id: "growth.dashboard", version: "2.0.0" },
    ],
  } as const;
}

async function project() {
  const root = await mkdtemp(join(process.cwd(), ".tmp-onboarding-inspect-"));
  temporaryDirectories.push(root);
  await mkdir(join(root, "app", "contact"), { recursive: true });
  await mkdir(join(root, "out"), { recursive: true });
  await writeFile(join(root, "app", "page.jsx"), "export default function Home() {}\n");
  await writeFile(join(root, "app", "contact", "page.jsx"), "export default function Contact() {}\n");
  await writeFile(join(root, "out", "index.html"), "<main><h1>Reliable HVAC service</h1><a href=\"/contact\">Request service</a><img src=\"/one.png\" alt=\"\"><img src=\"/two.png\" alt=\"\"></main>");
  await writeFile(join(root, "out", "contact.html"), "<main><h1>Contact us</h1><form><input name=\"zip\"><button>Send request</button></form></main>");
  return root;
}

async function tree(root: string): Promise<Record<string, string>> {
  const result: Record<string, string> = {};
  async function visit(relativePath: string) {
    const current = join(root, relativePath);
    for (const entry of await readdir(current, { withFileTypes: true })) {
      const child = relativePath ? join(relativePath, entry.name) : entry.name;
      if (entry.isDirectory()) await visit(child);
      else result[child.replaceAll("\\", "/")] = await readFile(join(root, child), "utf8");
    }
  }
  await visit("");
  return result;
}

afterEach(async () => {
  await Promise.all(temporaryDirectories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })));
});

describe("Phase 2D onboarding inspection", () => {
  it("parses the strict public manifest and rejects unknown or secret-bearing fields", () => {
    expect(parseOnboardingManifest(manifest())).toEqual(manifest());
    expect(() => parseOnboardingManifest({ ...manifest(), exchangeToken: "do-not-store" }))
      .toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "invalid_manifest" }));
    expect(() => parseOnboardingManifest({ ...manifest(), routes: [{ ...manifest().routes[0], renderedArtifact: "../secret.html" }] }))
      .toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "unsafe_project_path" }));
  });

  it("scans every declared rendered route deterministically without changing the project", async () => {
    const projectDir = await project();
    const before = await tree(projectDir);

    const first = await inspectOnboardingProject({ projectDir, manifest: parseOnboardingManifest(manifest()) });
    const second = await inspectOnboardingProject({ projectDir, manifest: parseOnboardingManifest(manifest()) });

    expect(first).toEqual(second);
    expect(first.reviewId).toMatch(/^[a-f0-9]{64}$/);
    expect(first.routes.map((route) => route.path)).toEqual(["/", "/contact"]);
    expect(first.routes.every((route) => route.artifactSha256.match(/^[a-f0-9]{64}$/))).toBe(true);
    expect(first.candidates).toEqual(expect.arrayContaining([
      expect.objectContaining({ id: "region.home.text.h1.reliable-hvac-service" }),
      expect.objectContaining({ id: "contact.form", category: "form" }),
    ]));
    expect(new Set(first.candidates.map((candidate) => candidate.id)).size).toBe(first.candidates.length);
    expect(first.safety).toEqual({ clientSourceMutated: false, remoteSystemsMutated: false });
    expect(await tree(projectDir)).toEqual(before);
  });

  it("rejects missing, symlinked, and escaping route artifacts", async () => {
    const projectDir = await project();
    const missing = parseOnboardingManifest({
      ...manifest(),
      routes: [{ ...manifest().routes[0], renderedArtifact: "out/missing.html" }],
    });

    await expect(inspectOnboardingProject({ projectDir, manifest: missing }))
      .rejects.toMatchObject({ code: "artifact_unavailable" });
  });
});
