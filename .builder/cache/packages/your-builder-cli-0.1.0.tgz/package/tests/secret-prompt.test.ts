import { describe, expect, it, vi } from "vitest";

import {
  readExchangeTokenFromTty,
  SecretPromptError,
  type SecretPromptTerminal,
} from "../src/control-plane/secret-prompt.js";

const TOKEN = "AQIDBAUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB0eHyA";

function terminal(chunks: Array<string | null>, isTTY = true): {
  adapter: SecretPromptTerminal;
  output: string[];
  rawModes: boolean[];
  removals: ReturnType<typeof vi.fn>;
  signal(): void;
} {
  const output: string[] = [];
  const rawModes: boolean[] = [];
  const removals = vi.fn();
  let sigint: (() => void) | undefined;
  return {
    adapter: {
      isTTY,
      writeError: (value) => output.push(value),
      setRawMode: (enabled) => rawModes.push(enabled),
      read: async () => {
        const next = chunks.shift();
        return next === null || next === undefined ? null : new TextEncoder().encode(next);
      },
      onSigint: (listener) => {
        sigint = listener;
        return removals;
      },
    },
    output,
    rawModes,
    removals,
    signal: () => sigint?.(),
  };
}

async function captureCode(promise: Promise<unknown>): Promise<string | undefined> {
  return promise.then(
    () => undefined,
    (error: unknown) => (error as SecretPromptError).code,
  );
}

describe("exchange token TTY prompt", () => {
  it("reads a valid token without echoing token bytes or length", async () => {
    const fixture = terminal([TOKEN, "\r"]);
    const secret = await readExchangeTokenFromTty(fixture.adapter);
    const seen = await secret.use(async (value) => value);

    expect(seen).toBe(TOKEN);
    expect(fixture.output.join("")).toBe("Exchange token: \n");
    expect(fixture.output.join("")).not.toContain(TOKEN);
    expect(fixture.output.join("")).not.toContain(String(TOKEN.length));
    expect(JSON.stringify(secret)).toBe('"[REDACTED]"');
    expect(String(secret)).toBe("[REDACTED]");
    expect(fixture.rawModes).toEqual([true, false]);
    expect(fixture.removals).toHaveBeenCalledOnce();
  });

  it("supports backspace and LF completion", async () => {
    const fixture = terminal([`${TOKEN.slice(0, -1)}x\bA\n`]);
    const secret = await readExchangeTokenFromTty(fixture.adapter);

    await expect(secret.use(async (value) => value)).resolves.toBe(TOKEN);
  });

  it.each([
    ["empty", ["\r"], "exchange_token_invalid"],
    ["overlength", [`${TOKEN}x`], "exchange_token_too_long"],
    ["invalid base64url", [`${TOKEN.slice(0, -1)}+\r`], "exchange_token_invalid"],
    ["EOF", [null], "exchange_token_input_closed"],
    ["Ctrl+C", ["\u0003"], "exchange_token_cancelled"],
  ] as const)("fails safely for %s", async (_name, chunks, code) => {
    const fixture = terminal([...chunks]);

    expect(await captureCode(readExchangeTokenFromTty(fixture.adapter))).toBe(code);
    expect(fixture.output.join("")).not.toContain(TOKEN);
    expect(fixture.rawModes).toEqual([true, false]);
    expect(fixture.removals).toHaveBeenCalledOnce();
  });

  it("rejects redirected input before reading or changing raw mode", async () => {
    const fixture = terminal([TOKEN], false);
    const read = vi.spyOn(fixture.adapter, "read");

    expect(await captureCode(readExchangeTokenFromTty(fixture.adapter)))
      .toBe("exchange_token_tty_required");
    expect(read).not.toHaveBeenCalled();
    expect(fixture.rawModes).toEqual([]);
    expect(fixture.removals).not.toHaveBeenCalled();
  });

  it("restores raw mode and listeners when reading throws", async () => {
    const fixture = terminal([]);
    fixture.adapter.read = async () => { throw new Error(`reader failed ${TOKEN}`); };

    const error = await readExchangeTokenFromTty(fixture.adapter).catch((caught: unknown) => caught);

    expect(error).toMatchObject({ code: "exchange_token_read_failed" });
    expect(String(error)).not.toContain(TOKEN);
    expect(fixture.rawModes).toEqual([true, false]);
    expect(fixture.removals).toHaveBeenCalledOnce();
  });

  it("handles SIGINT through the injected signal adapter", async () => {
    let finishRead: ((value: Uint8Array | null) => void) | undefined;
    const fixture = terminal([]);
    fixture.adapter.read = () => new Promise((resolve) => { finishRead = resolve; });
    const pending = readExchangeTokenFromTty(fixture.adapter);
    await Promise.resolve();
    fixture.signal();
    finishRead?.(null);

    expect(await captureCode(pending)).toBe("exchange_token_cancelled");
    expect(fixture.rawModes).toEqual([true, false]);
    expect(fixture.removals).toHaveBeenCalledOnce();
  });

  it("wipes the mutable token after the callback returns or throws", async () => {
    const fixture = terminal([TOKEN, "\r"]);
    const secret = await readExchangeTokenFromTty(fixture.adapter);
    await secret.use(async () => undefined);

    await expect(secret.use(async () => undefined)).rejects.toMatchObject({
      code: "exchange_token_consumed",
    });
  });
});
