import { access } from "node:fs/promises";
import { join } from "node:path";

import { describe, expect, it } from "vitest";

describe("Netlify automatic API transport", () => {
  it("is absent while the credential and exact-scope gates are disabled", async () => {
    const modulePath = join(process.cwd(), "packages/cli/src/hosting/netlify/api-transport.ts");
    await expect(access(modulePath)).rejects.toMatchObject({ code: "ENOENT" });
  });
});
