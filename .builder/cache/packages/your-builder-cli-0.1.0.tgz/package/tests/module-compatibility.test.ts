import { describe, expect, it } from "vitest";

import { checkModuleCompatibility } from "../src/modules/compatibility.js";
import { parseModuleManifest } from "../src/modules/module-manifest.js";

function moduleManifest() {
  return parseModuleManifest({
    manifestVersion: 1,
    moduleId: "growth.reviews",
    moduleVersion: "1.0.0",
    requirements: {
      packages: { "@your-builder/reviews": "1.2.0" },
      schemas: { reviews: 2 },
      routes: ["/reviews", "/api/reviews/sync"],
      minimumWorkerVersion: "0.3.0",
    },
  });
}

function installation() {
  return {
    version: 1 as const,
    packages: { "@your-builder/reviews": "1.2.1" },
    schemas: { reviews: 2 },
    routes: ["/", "/reviews", "/api/reviews/sync"],
    workerVersion: "0.3.1",
  };
}

describe("module compatibility", () => {
  it("accepts an installation that satisfies every manifest requirement", () => {
    expect(checkModuleCompatibility({
      module: moduleManifest(),
      installation: installation(),
    })).toEqual({ compatible: true, mutatesFiles: false, issues: [] });
  });

  it("lists exact missing and outdated package, schema, route, and worker requirements", () => {
    const report = checkModuleCompatibility({
      module: moduleManifest(),
      installation: {
        version: 1,
        packages: {},
        schemas: { reviews: 1 },
        routes: ["/reviews"],
        workerVersion: "0.2.9",
      },
    });

    expect(report.mutatesFiles).toBe(false);
    expect(report.compatible).toBe(false);
    expect(report.issues).toEqual([
      expect.objectContaining({
        code: "MISSING_PACKAGE",
        requirement: "package:@your-builder/reviews",
        required: "1.2.0",
        installed: null,
      }),
      expect.objectContaining({
        code: "SCHEMA_VERSION_TOO_OLD",
        requirement: "schema:reviews",
        required: 2,
        installed: 1,
        migrationRequired: true,
      }),
      expect.objectContaining({
        code: "MISSING_ROUTE",
        requirement: "route:/api/reviews/sync",
      }),
      expect.objectContaining({
        code: "WORKER_VERSION_TOO_OLD",
        requirement: "worker",
        required: "0.3.0",
        installed: "0.2.9",
      }),
    ]);
  });

  it("rejects unknown manifest versions and unstable module identifiers", () => {
    expect(() => parseModuleManifest({
      manifestVersion: 2,
      moduleId: "growth.reviews",
      moduleVersion: "1.0.0",
      requirements: { packages: {}, schemas: {}, routes: [] },
    })).toThrowError(expect.objectContaining({ code: "INVALID_MODULE_MANIFEST" }));

    expect(() => parseModuleManifest({
      manifestVersion: 1,
      moduleId: "Reviews Module",
      moduleVersion: "1.0.0",
      requirements: { packages: {}, schemas: {}, routes: [] },
    })).toThrowError(expect.objectContaining({ code: "INVALID_MODULE_MANIFEST" }));

    expect(() => parseModuleManifest({
      manifestVersion: 1,
      moduleId: "growth.reviews",
      moduleVersion: "1.0.0-01",
      requirements: { packages: {}, schemas: {}, routes: [] },
    })).toThrowError(expect.objectContaining({ code: "INVALID_MODULE_MANIFEST" }));
  });

  it("compares semantic versions without numeric precision loss", () => {
    const module = parseModuleManifest({
      manifestVersion: 1,
      moduleId: "growth.reviews",
      moduleVersion: "1.0.0",
      requirements: {
        packages: { "@your-builder/reviews": "9007199254740993.0.0" },
        schemas: {},
        routes: [],
      },
    });

    expect(checkModuleCompatibility({
      module,
      installation: {
        version: 1,
        packages: { "@your-builder/reviews": "9007199254740992.999.999" },
        schemas: {},
        routes: [],
      },
    }).issues).toContainEqual(expect.objectContaining({
      code: "PACKAGE_VERSION_TOO_OLD",
    }));
  });
});
