import { access, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, describe, expect, it, vi } from "vitest";

import type { WindowsAclAdapter } from "../src/control-plane/protected-files.js";
import { createSetupJournalStore } from "../src/control-plane/setup-journal.js";
import { createServerEnvironmentInput } from "../src/hosting/contracts.js";
import {
  createManualHandoffController,
  createManualHostingAdapter,
} from "../src/hosting/manual/manual-adapter.js";

const directories: string[] = [];
const PRIVATE_JWK = "manual-private-jwk-canary";

afterEach(async () => {
  await Promise.all(directories.splice(0).map((directory) => rm(directory, {
    recursive: true,
    force: true,
  })));
});

async function project(): Promise<string> {
  const directory = await mkdtemp(join(tmpdir(), "builder-manual-hosting-"));
  directories.push(directory);
  await writeFile(join(directory, "package.json"), '{"name":"pilot-site"}\n');
  return directory;
}

function allowedAcl(): WindowsAclAdapter {
  return {
    currentUserSid: async () => "S-1-5-21-owner",
    protect: async () => undefined,
    inspect: async () => ({
      ownerSid: "S-1-5-21-owner",
      inheritanceDisabled: true,
      isReparsePoint: false,
      entries: [{
        sid: "S-1-5-21-owner",
        allow: true,
        inherited: false,
        fullControl: true,
      }],
    }),
  };
}

function environment() {
  return createServerEnvironmentInput({
    BUILDER_CONTROL_PLANE_URL: "https://control.example.com",
    BUILDER_INSTALLATION_ID: "11111111-1111-4111-8111-111111111111",
    BUILDER_INSTALLATION_KEY_ID: "installation:key",
    BUILDER_INSTALLATION_PRIVATE_JWK: PRIVATE_JWK,
  });
}

function adapter(overrides: Partial<Parameters<typeof createManualHostingAdapter>[0]> = {}) {
  const lines: string[] = [];
  return {
    lines,
    instance: createManualHostingAdapter({
      environmentLabel: "staging",
      reviewedMarkers: ["package.json"],
      now: () => new Date("2026-07-19T12:00:00.000Z"),
      confirmTarget: async () => true,
      output: { info: (line) => lines.push(line) },
      platform: "win32",
      protectedFiles: { windowsAcl: allowedAcl() },
      ...overrides,
    }),
  };
}

describe("manual hosting adapter", () => {
  it("detects and preflights an immutable project and environment target", async () => {
    const projectDir = await project();
    const { instance } = adapter();

    const detection = await instance.detect(projectDir);
    const receipt = await instance.preflight(projectDir, detection.target);

    expect(detection).toMatchObject({
      status: "detected",
      target: {
        provider: "manual",
        accountId: "manual",
        context: "staging",
        branch: null,
        scopes: ["server-runtime"],
      },
    });
    expect(detection.target.siteName).toMatch(/^builder-manual-hosting-/);
    expect(detection.target.siteId).toMatch(/^[a-f0-9]{64}$/);
    expect(receipt.expiresAt).toBe("2026-07-19T12:10:00.000Z");
    expect(JSON.stringify(receipt)).not.toContain(PRIVATE_JWK);
  });

  it("requires explicit target confirmation before creating a handoff", async () => {
    const projectDir = await project();
    const { instance } = adapter({ confirmTarget: async () => false });
    const detected = await instance.detect(projectDir);
    const receipt = await instance.preflight(projectDir, detected.target);

    await expect(instance.configure(environment(), receipt)).rejects.toMatchObject({
      code: "manual_confirmation_required",
    });
    await expect(access(join(projectDir, ".builder", "secrets", "hosting-handoff")))
      .rejects.toMatchObject({ code: "ENOENT" });
  });

  it("writes a protected resumable handoff while printing only its path", async () => {
    const projectDir = await project();
    const { instance, lines } = adapter();
    const detected = await instance.detect(projectDir);
    const receipt = await instance.preflight(projectDir, detected.target);

    await expect(instance.configure(environment(), receipt)).resolves.toMatchObject({
      status: "configured",
    });
    await expect(instance.configure(environment(), receipt)).resolves.toMatchObject({
      status: "configured",
    });
    const status = await instance.handoffStatus(projectDir);
    expect(status).toMatchObject({ status: "pending", names: expect.any(Array) });
    expect(status).not.toHaveProperty("values");
    expect(lines.join("\n")).toContain(".builder");
    expect(lines.join("\n")).not.toContain(PRIVATE_JWK);
    expect(JSON.stringify(status)).not.toContain(PRIVATE_JWK);
    expect(await readFile(join(projectDir, ".builder", "secrets", "hosting-handoff", "environment.json"), "utf8"))
      .toContain(PRIVATE_JWK);
  });

  it("records a redacted acknowledgment, cleans the handoff, and never claims automatic proof", async () => {
    const projectDir = await project();
    const { instance } = adapter();
    const detected = await instance.detect(projectDir);
    const receipt = await instance.preflight(projectDir, detected.target);
    await instance.configure(environment(), receipt);

    await expect(instance.confirmHandoff(projectDir, receipt)).resolves.toMatchObject({
      status: "acknowledged",
    });
    await expect(instance.verifyConfiguration(receipt)).resolves.toMatchObject({
      status: "acknowledged",
    });
    await expect(instance.handoffStatus(projectDir)).resolves.toEqual({ status: "absent" });
    const acknowledgment = await readFile(
      join(projectDir, ".builder", "hosting-handoff-acknowledgement.json"),
      "utf8",
    );
    expect(acknowledgment).not.toContain(PRIVATE_JWK);
    expect(acknowledgment).not.toContain("verified");
  });

  it("resumes status and confirmation in a separate handoff controller", async () => {
    const projectDir = await project();
    const { instance } = adapter();
    const detected = await instance.detect(projectDir);
    const receipt = await instance.preflight(projectDir, detected.target);
    await instance.configure(environment(), receipt);
    const controller = createManualHandoffController({
      now: () => new Date("2026-07-19T12:01:00.000Z"),
      platform: "win32",
      protectedFiles: { windowsAcl: allowedAcl() },
    });

    await expect(controller.status(projectDir)).resolves.toMatchObject({ status: "pending" });
    await expect(controller.confirm(projectDir)).resolves.toMatchObject({
      status: "acknowledged",
      target: detected.target,
    });
    await expect(controller.status(projectDir)).resolves.toEqual({ status: "absent" });
  });

  it("finalizes the matching setup journal and makes repeat confirmation idempotent", async () => {
    const projectDir = await project();
    const { instance } = adapter();
    const detected = await instance.detect(projectDir);
    const receipt = await instance.preflight(projectDir, detected.target);
    await instance.configure(environment(), receipt);
    const journal = await createSetupJournalStore(projectDir, {
      now: () => new Date("2026-07-19T12:00:00.000Z"),
      platform: "win32",
      protectedFiles: { windowsAcl: allowedAcl() },
    });
    await journal.initialize({
      projectFingerprint: receipt.projectFingerprint,
      stableSiteKey: "pilot-site",
      publicUrl: "https://pilot.example.com",
      controlPlaneUrl: "https://control.example.com",
      installationId: "11111111-1111-4111-8111-111111111111",
      acceptedKeyId: "installation:key",
      hostingMode: "manual",
    });
    await journal.update({
      stage: "hosting_verification_pending",
      receiptDigest: receipt.digest,
    });
    const controller = createManualHandoffController({
      now: () => new Date("2026-07-19T12:01:00.000Z"),
      platform: "win32",
      protectedFiles: { windowsAcl: allowedAcl() },
    });

    const first = await controller.confirm(projectDir);

    expect(first).toMatchObject({ status: "acknowledged", target: detected.target });
    await expect(journal.read()).resolves.toBeNull();
    await expect(controller.confirm(projectDir)).resolves.toEqual(first);
  });

  it("accepts an explicitly confirmed rerun receipt for the same hosting target", async () => {
    const projectDir = await project();
    const first = adapter().instance;
    const firstDetection = await first.detect(projectDir);
    const firstReceipt = await first.preflight(projectDir, firstDetection.target);
    await first.configure(environment(), firstReceipt);
    await first.confirmHandoff(projectDir, firstReceipt);

    const second = adapter({
      now: () => new Date("2026-07-19T12:02:00.000Z"),
    }).instance;
    const secondDetection = await second.detect(projectDir);
    const secondReceipt = await second.preflight(projectDir, secondDetection.target);
    expect(secondReceipt.digest).not.toBe(firstReceipt.digest);
    await second.configure(environment(), secondReceipt);
    const journal = await createSetupJournalStore(projectDir, {
      now: () => new Date("2026-07-19T12:02:00.000Z"),
      platform: "win32",
      protectedFiles: { windowsAcl: allowedAcl() },
    });
    await journal.initialize({
      projectFingerprint: secondReceipt.projectFingerprint,
      stableSiteKey: "pilot-site",
      publicUrl: "https://pilot.example.com",
      controlPlaneUrl: "https://control.example.com",
      installationId: "11111111-1111-4111-8111-111111111111",
      acceptedKeyId: "installation:key",
      hostingMode: "manual",
    });
    await journal.update({
      stage: "hosting_verification_pending",
      receiptDigest: secondReceipt.digest,
    });
    const controller = createManualHandoffController({
      now: () => new Date("2026-07-19T12:03:00.000Z"),
      platform: "win32",
      protectedFiles: { windowsAcl: allowedAcl() },
    });

    await expect(controller.confirm(projectDir)).resolves.toMatchObject({
      status: "acknowledged",
      target: secondDetection.target,
    });
    await expect(journal.read()).resolves.toBeNull();
    expect(JSON.parse(await readFile(
      join(projectDir, ".builder", "hosting-handoff-acknowledgement.json"),
      "utf8",
    ))).toMatchObject({ receiptDigest: secondReceipt.digest });
  });

  it("cleans a pending handoff and verifies absence", async () => {
    const projectDir = await project();
    const { instance } = adapter();
    const detected = await instance.detect(projectDir);
    const receipt = await instance.preflight(projectDir, detected.target);
    await instance.configure(environment(), receipt);

    await expect(instance.cleanupHandoff(projectDir)).resolves.toEqual({ status: "cleaned" });
    await expect(instance.handoffStatus(projectDir)).resolves.toEqual({ status: "absent" });
  });

  it("does not accept an acknowledgment while the secret handoff still exists", async () => {
    const projectDir = await project();
    const { instance } = adapter();
    const detected = await instance.detect(projectDir);
    const receipt = await instance.preflight(projectDir, detected.target);
    await instance.configure(environment(), receipt);
    await writeFile(
      join(projectDir, ".builder", "hosting-handoff-acknowledgement.json"),
      `${JSON.stringify({
        schemaVersion: 1,
        receiptDigest: receipt.digest,
        target: detected.target,
        names: [
          "BUILDER_CONTROL_PLANE_URL",
          "BUILDER_INSTALLATION_ID",
          "BUILDER_INSTALLATION_KEY_ID",
          "BUILDER_INSTALLATION_PRIVATE_JWK",
        ],
        acknowledgedAt: "2026-07-19T12:00:00.000Z",
      })}\n`,
    );

    await expect(instance.verifyConfiguration(receipt)).rejects.toMatchObject({
      code: "manual_acknowledgment_missing",
    });
  });

  it("fails before a secret write when owner-only protection cannot be proved", async () => {
    const projectDir = await project();
    const inspect = vi.fn(async () => { throw new Error(`unsafe ${PRIVATE_JWK}`); });
    const { instance, lines } = adapter({
      protectedFiles: {
        windowsAcl: {
          ...allowedAcl(),
          inspect,
        },
      },
    });
    const detected = await instance.detect(projectDir);
    const receipt = await instance.preflight(projectDir, detected.target);

    const error = await instance.configure(environment(), receipt).catch((caught: unknown) => caught);
    expect(error).toMatchObject({ code: "manual_protected_storage_unavailable" });
    expect(String(error)).not.toContain(PRIVATE_JWK);
    expect(lines.join("\n")).not.toContain(PRIVATE_JWK);
    await expect(access(join(projectDir, ".builder", "secrets", "hosting-handoff", "environment.json")))
      .rejects.toMatchObject({ code: "ENOENT" });
  });
});
