// @vitest-environment node

import { describe, expect, it, vi } from "vitest";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

vi.mock("server-only", () => ({}));

import {
  createEntitlementSnapshotCache,
} from "@your-builder/entitlements/server";
import {
  type EntitlementSnapshot,
  nextCompensationAction,
  nextProvisioningAction,
  provisioningFailureDisposition,
} from "@your-builder/entitlements";
import {
  signInstallationRequest,
  verifyInstallationRequest,
} from "@your-builder/entitlements/trust";
import {
  createMemorySiteCommandReceiptStore,
  createSiteCommandExecutor,
  type ProvisioningSiteCommandHandler,
  type SiteCommandExecutionContext,
  type SiteCommandReceiptStore,
} from "@your-builder/next/control-plane";

import {
  createFoundationFailureDrillReport,
  FOUNDATION_FAILURE_DRILL_IDS,
} from "../src/foundation/failure-drills.js";

const SITE_ID = "10000000-0000-4000-8000-000000000001";
const INSTALLATION_ID = "10000000-0000-4000-8000-000000000002";
const COMMAND_ID = "20000000-0000-4000-8000-000000000001";

function executionContext(): SiteCommandExecutionContext {
  return {
    signal: new AbortController().signal,
    lease: {
      siteId: SITE_ID,
      installationId: INSTALLATION_ID,
      leaseOwner: "40000000-0000-4000-8000-000000000001",
      fencingToken: "1",
      leaseExpiresAt: "2099-01-01T00:00:00.000Z",
    },
    validateLease: async () => undefined,
  };
}
const PRIVATE_JWK: JsonWebKey = {
  kty: "OKP", crv: "Ed25519", alg: "EdDSA",
  x: "11qYAYKxCrfVS_7TyWQHOg7hcvPapiMlrwIaaPcHURo",
  d: "nWGxne_9WmC6hEr0kuwsxERJxWl7MmkZcDusAxyuf2A",
};
const PUBLIC_JWK: JsonWebKey = {
  kty: "OKP", crv: "Ed25519", alg: "EdDSA",
  x: "11qYAYKxCrfVS_7TyWQHOg7hcvPapiMlrwIaaPcHURo",
};

function command() {
  return {
    id: COMMAND_ID,
    type: "module.configure",
    version: 1,
    payload: { moduleId: "growth.reviews" },
    idempotencyKey: "configure-growth-reviews-v1",
  };
}

function handler(effectIds: Set<string>, calls: { effects: number; compensation: number }) {
  return {
    type: "module.configure",
    version: 1,
    idempotency: "commandId",
    validate: (payload: unknown) => payload as { moduleId: string },
    execute: async ({ commandId }: { commandId: string }) => {
      if (!effectIds.has(commandId)) {
        effectIds.add(commandId);
        calls.effects += 1;
      }
      return { resultCode: "MODULE_CONFIGURED", evidence: { codes: ["CONFIG_CREATED"] } };
    },
    compensate: async () => {
      calls.compensation += 1;
      return { resultCode: "MODULE_CONFIGURATION_REMOVED" };
    },
  } satisfies ProvisioningSiteCommandHandler<{ moduleId: string }>;
}

function snapshot(sequence: number, expiresAt: string): EntitlementSnapshot {
  return {
    version: 1,
    siteId: SITE_ID,
    installationId: INSTALLATION_ID,
    issuedAt: "2026-07-17T00:00:00.000Z",
    expiresAt,
    sequence,
    modules: {
      "growth.reviews": {
        state: "active",
        moduleVersion: "1.0.0",
        setupComplete: true,
      },
    } as EntitlementSnapshot["modules"],
    incidentOverrides: [],
  };
}

describe("foundation failure drills", () => {
  it("rejects request replay while accepting overlapping active keys and denying a revoked key", async () => {
    const consumed = new Set<string>();
    const activeKeys = new Set(["key-current", "key-next"]);
    const verify = async (keyId: string, nonce: string) => {
      const headers = await signInstallationRequest({
        installationId: INSTALLATION_ID,
        keyId,
        method: "POST",
        path: "/api/platform/v1/installations/health",
        timestamp: "2026-07-17T12:00:00.000Z",
        nonce,
        bodyBytes: new Uint8Array(),
        privateJwk: PRIVATE_JWK,
      });
      return verifyInstallationRequest({
        headers,
        method: "POST",
        path: "/api/platform/v1/installations/health",
        bodyBytes: new Uint8Array(),
        now: new Date("2026-07-17T12:00:00.000Z"),
        resolvePublicKey: async (_installationId, requestedKeyId) =>
          activeKeys.has(requestedKeyId) ? PUBLIC_JWK : null,
        consumeNonce: async (_installationId, requestedNonce) => {
          if (consumed.has(requestedNonce)) return false;
          consumed.add(requestedNonce);
          return true;
        },
      });
    };

    await expect(verify("key-current", "AQIDBAUGBwgJCgsMDQ4PEA")).resolves.toBeDefined();
    await expect(verify("key-next", "AQIDBAUGBwgJCgsMDQ4PEQ")).resolves.toBeDefined();
    await expect(verify("key-next", "AQIDBAUGBwgJCgsMDQ4PEQ")).rejects.toMatchObject({ code: "nonce_replayed" });
    activeKeys.delete("key-current");
    await expect(verify("key-current", "AQIDBAUGBwgJCgsMDQ4PEg")).rejects.toMatchObject({ code: "unknown_key" });
  });

  it("replays commands and compensation without duplicate effects", async () => {
    const calls = { effects: 0, compensation: 0 };
    const executor = createSiteCommandExecutor({
      siteId: SITE_ID,
      handlers: [handler(new Set(), calls)],
      store: createMemorySiteCommandReceiptStore(),
    });

    const first = await executor.execute(command(), executionContext());
    await expect(executor.execute(command(), executionContext())).resolves.toEqual(first);
    const compensation = {
      ...command(),
      id: "20000000-0000-4000-8000-000000000002",
      type: "module.configure.compensate",
      idempotencyKey: "configure-growth-reviews-v1-compensate",
      payload: {
        commandId: COMMAND_ID,
        evidence: { version: 1, codes: ["CONFIG_CREATED"], metrics: {}, flags: {}, digests: {} },
      },
    };
    const compensated = await executor.execute(compensation, executionContext());
    await expect(executor.execute(compensation, executionContext())).resolves.toEqual(compensated);

    expect(calls).toEqual({ effects: 1, compensation: 1 });
  });

  it("recovers a worker crash after a side effect under the same command identity", async () => {
    let now = new Date("2026-07-17T12:00:00.000Z");
    const calls = { effects: 0, compensation: 0 };
    const durableStore = createMemorySiteCommandReceiptStore({
      now: () => now,
      leaseSeconds: 30,
      leaseToken: () => "30000000-0000-4000-8000-000000000001",
    });
    let crash = true;
    const crashStore: SiteCommandReceiptStore = {
      reserve: (input) => durableStore.reserve(input),
      find: (input) => durableStore.find(input),
      complete: async (input) => {
        if (crash) {
          crash = false;
          throw new Error("drill_crash_after_effect");
        }
        return durableStore.complete(input);
      },
    };
    const effects = new Set<string>();
    const firstWorker = createSiteCommandExecutor({
      siteId: SITE_ID, handlers: [handler(effects, calls)], store: crashStore, now: () => now,
    });
    await expect(firstWorker.execute(command(), executionContext())).rejects.toThrow(
      "drill_crash_after_effect",
    );
    now = new Date("2026-07-17T12:00:31.000Z");
    const restartedWorker = createSiteCommandExecutor({
      siteId: SITE_ID, handlers: [handler(effects, calls)], store: crashStore, now: () => now,
    });
    await expect(restartedWorker.execute(command(), executionContext())).resolves.toMatchObject({
      outcome: "succeeded",
    });
    expect(calls.effects).toBe(1);
  });

  it("pauses stale outbound work, resumes from a newer snapshot, and keeps public fallback independent", () => {
    const cache = createEntitlementSnapshotCache({ siteId: SITE_ID, installationId: INSTALLATION_ID });
    expect(cache.accept(snapshot(3, "2026-07-17T10:00:00.000Z"))).toBe(true);
    expect(cache.decide({
      moduleId: "growth.reviews",
      action: "outbound",
      now: new Date("2026-07-17T12:00:00.000Z"),
    })).toMatchObject({ allowed: false, reason: "snapshot_stale" });
    expect(cache.decide({
      moduleId: "growth.reviews",
      action: "read",
      now: new Date("2026-07-17T12:00:00.000Z"),
    })).toMatchObject({ allowed: true, reason: "stale_read_only" });
    expect(cache.accept(snapshot(4, "2026-07-18T00:00:00.000Z"))).toBe(true);
    expect(cache.decide({
      moduleId: "growth.reviews",
      action: "outbound",
      now: new Date("2026-07-17T12:00:00.000Z"),
    })).toMatchObject({ allowed: true, reason: "current" });
    const renderPublicPage = (fallback: string) => `<main>${fallback}</main>`;
    expect(() => renderPublicPage("Local service")).not.toThrow();
    expect(renderPublicPage("Local service")).toContain("Local service");
  });

  it("retries provisioning, compensates automatically, and fails closed when compensation fails", () => {
    const run = {
      id: "run-1", status: "running" as const, kind: "new_module" as const,
      currentModuleVersion: null, targetModuleVersion: "1.0.0",
    };
    const failedStep = {
      id: "step-1", order: 1, status: "failed" as const,
      commandId: "command-1", idempotencyKey: "provision:run-1:step-1",
      attempts: 1, retryAt: "2026-07-17T12:05:00.000Z",
      compensation: "automatic" as const, runbookId: null,
      compensationCommandId: "compensation-command-1",
      compensationIdempotencyKey: "provision:run-1:step-1:compensate",
    };
    expect(nextProvisioningAction(run, [failedStep], "2026-07-17T12:05:00.000Z"))
      .toMatchObject({ type: "execute", commandId: "command-1" });
    expect(nextCompensationAction([{ ...failedStep, status: "succeeded" }]))
      .toMatchObject({ type: "compensate", commandId: "compensation-command-1" });
    expect(provisioningFailureDisposition({
      kind: "new_module",
      previousEntitlementState: "provisioning",
      currentModuleVersion: null,
      compensationStatus: "failed",
      cleanupConfirmation: "failed",
    })).toMatchObject({ entitlementState: "termination_failed", incidentMode: null });
  });

  it("produces complete, non-mutating drill evidence", () => {
    const report = createFoundationFailureDrillReport(
      FOUNDATION_FAILURE_DRILL_IDS.map((id) => ({ id, passed: true, evidence: `${id}:passed` })),
    );

    expect(report.ok).toBe(true);
    expect(report.mutatesFiles).toBe(false);
    expect(report.drills).toHaveLength(FOUNDATION_FAILURE_DRILL_IDS.length);
    expect(report.drills.map((drill) => drill.id)).toEqual(FOUNDATION_FAILURE_DRILL_IDS);
  });

  it("ships a single runner for attach, replay, outage, and recovery evidence", async () => {
    const script = await readFile(resolve("scripts", "run-foundation-drills.mjs"), "utf8");

    expect(script).toContain("packages/cli/tests/growth-foundation-check.test.ts");
    expect(script).toContain("packages/cli/tests/failure-drills.test.ts");
    expect(script).toContain("packages/cli/tests/secret-boundary.test.ts");
    expect(script).toContain("run-foundation-secret-scan.mjs");
    expect(script).toContain("ComSpec");
    expect(script).not.toContain("npm.cmd");
  });
});
