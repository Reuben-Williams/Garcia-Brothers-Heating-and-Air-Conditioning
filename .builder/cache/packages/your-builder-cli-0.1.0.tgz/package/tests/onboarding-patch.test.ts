// @vitest-environment node

import { execFile } from "node:child_process";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { promisify } from "node:util";

import { afterEach, describe, expect, it, vi } from "vitest";

import { dispatchBuilderCli } from "../src/bin.js";
import {
  generateOnboardingSourcePatch,
  canonicalOnboardingValue,
  OnboardingError,
  parseOnboardingSourcePatch,
  parseOnboardingStageReceipt,
} from "../src/onboarding/index.js";
import { fingerprintSource } from "../src/scan/source-fingerprint.js";

const execFileAsync = promisify(execFile);
const temporaryDirectories: string[] = [];

async function git(cwd: string, ...args: string[]) {
  return execFileAsync("git", args, { cwd, encoding: "utf8" });
}

async function repositories() {
  const root = await mkdtemp(join(process.cwd(), ".tmp-onboarding-patch-"));
  temporaryDirectories.push(root);
  const projectDir = join(root, "project");
  const reviewDir = join(root, "review");
  await mkdir(projectDir);
  await git(projectDir, "init", "-b", "main");
  await git(projectDir, "config", "user.email", "test@example.com");
  await git(projectDir, "config", "user.name", "Builder Test");
  await mkdir(join(projectDir, "app"));
  await writeFile(join(projectDir, "app", "page.jsx"), "export default function Page() { return 'before'; }\n");
  await git(projectDir, "add", "app/page.jsx");
  await git(projectDir, "commit", "-m", "base");
  await execFileAsync("git", ["clone", "--no-hardlinks", projectDir, reviewDir], { encoding: "utf8" });
  return { projectDir, reviewDir };
}

afterEach(async () => {
  vi.unstubAllEnvs();
  await Promise.all(temporaryDirectories.splice(0).map((path) => rm(path, { recursive: true, force: true })));
});

describe("Phase 2D onboarding patch generation", () => {
  it("generates and dispatches a deterministic reviewed patch from an isolated Git checkout", async () => {
    const { projectDir, reviewDir } = await repositories();
    const planPath = join(projectDir, "plan.json");
    const outputPath = join(projectDir, "patch.json");
    const planPayload = {
      version: 1 as const,
      reviewId: "b".repeat(64),
      manifestSha256: "c".repeat(64),
      mappings: [],
      exclusions: [],
      generatedFiles: [],
      patchSummary: [],
      safety: { clientSourceMutated: false as const, remoteSystemsMutated: false as const },
    };
    const planId = fingerprintSource(canonicalOnboardingValue(planPayload));
    await writeFile(join(reviewDir, "app", "page.jsx"), "export default function Page() { return 'after'; }\n");
    await writeFile(join(reviewDir, "builder.config.mjs"), "export default { siteId: 'fixture' };\n");

    const patch = await generateOnboardingSourcePatch({ projectDir, reviewDir, planId });

    expect(parseOnboardingSourcePatch(patch)).toEqual(patch);
    expect(patch.files).toEqual([
      {
        path: "app/page.jsx",
        expectedCurrentHash: fingerprintSource("export default function Page() { return 'before'; }\n"),
        contents: "export default function Page() { return 'after'; }\n",
      },
      {
        path: "builder.config.mjs",
        expectedCurrentHash: null,
        contents: "export default { siteId: 'fixture' };\n",
      },
    ]);

    await writeFile(planPath, JSON.stringify({ ...planPayload, planId }));
    const output = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };
    await expect(dispatchBuilderCli([
      "onboard", "--stage", "patch", "--project", projectDir, "--review-project", reviewDir,
      "--plan", planPath, "--output", outputPath,
    ], { output })).resolves.toBe(0);
    expect(parseOnboardingSourcePatch(JSON.parse(await readFile(outputPath, "utf8")))).toEqual(patch);
    expect(parseOnboardingStageReceipt(JSON.parse(await readFile(`${outputPath}.receipt.json`, "utf8"))))
      .toMatchObject({ stage: "patch", outputId: patch.patchId });
    expect(output.info).toHaveBeenCalledWith(`Onboarding patch passed. Patch ID: ${patch.patchId}`);

    await expect(dispatchBuilderCli([
      "onboard", "--stage", "patch", "--project", projectDir, "--review-project", reviewDir,
      "--plan", planPath, "--output", outputPath,
    ], { output })).resolves.toBe(0);
  }, 15_000);

  it("fails closed when the target source drifted from the shared base commit", async () => {
    const { projectDir, reviewDir } = await repositories();
    await writeFile(join(reviewDir, "app", "page.jsx"), "reviewed\n");
    await writeFile(join(projectDir, "app", "page.jsx"), "owner edit\n");

    await expect(generateOnboardingSourcePatch({ projectDir, reviewDir, planId: "a".repeat(64) }))
      .rejects.toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "source_drift" }));
  }, 15_000);

  it("rejects deletions because onboarding reversal requires an explicit reviewed write", async () => {
    const { projectDir, reviewDir } = await repositories();
    await rm(join(reviewDir, "app", "page.jsx"));

    await expect(generateOnboardingSourcePatch({ projectDir, reviewDir, planId: "a".repeat(64) }))
      .rejects.toThrowError(expect.objectContaining<Partial<OnboardingError>>({ code: "invalid_patch" }));
  }, 15_000);
});
