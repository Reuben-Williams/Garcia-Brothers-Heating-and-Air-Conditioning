import { describe, expect, it } from "vitest";
import {
  classifyScanCandidates,
  createAttachReviewReport,
  getBuilderInitFiles,
  planApprovedMigration,
  runBuilderCheck,
  scanEditableRegionsFromHtml,
} from "@your-builder/cli";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("builder check", () => {
  it("reports missing env vars, duplicate regions, and unprotected editor route", () => {
    const result = runBuilderCheck({
      env: {},
      site: {
        siteId: "demo-site",
        adapter: "central",
        editor: { path: "/editor", protected: false },
        pages: [
          { path: "/", label: "Home", regions: ["home.hero.title"] },
          { path: "/about", label: "About", regions: ["home.hero.title"] },
        ],
        sections: {},
      },
    });

    expect(result.ok).toBe(false);
    expect(result.issues.map((issue) => issue.code)).toEqual(
      expect.arrayContaining([
        "env.missing.central.apiUrl",
        "env.missing.central.siteToken",
        "region.id.duplicate",
        "editor.route.unprotected",
      ]),
    );
  });

  it("reports rendered editable regions that are missing or conflicting with config", () => {
    const result = runBuilderCheck({
      env: {
        SUPABASE_URL: "https://demo.supabase.co",
        SUPABASE_SERVICE_ROLE_KEY: "server-secret",
      },
      renderedRegions: [
        { id: "home.hero.title", kind: "text", source: "app/page.tsx" },
        { id: "home.hero.image", kind: "text", source: "app/page.tsx" },
        { id: "home.footer.cta", kind: "link", source: "app/page.tsx" },
      ],
      site: {
        siteId: "demo-site",
        adapter: "supabase",
        editor: { path: "/admin/editor", protected: true },
        pages: [
          {
            path: "/",
            label: "Home",
            regions: [
              { id: "home.hero.title", kind: "text" },
              { id: "home.hero.image", kind: "image" },
            ],
          },
        ],
        sections: {},
      },
    });

    expect(result.issues).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ code: "rendered.region.kind.conflict", path: "app/page.tsx" }),
        expect.objectContaining({ code: "rendered.region.missing.config", path: "app/page.tsx" }),
      ]),
    );
  });

  it("accepts first-class rendered icon regions declared in config", () => {
    const result = runBuilderCheck({
      env: {
        SUPABASE_URL: "https://demo.supabase.co",
        SUPABASE_SERVICE_ROLE_KEY: "server-secret",
      },
      renderedRegions: [{ id: "home.service.icon", kind: "icon", source: "app/page.tsx" }],
      site: {
        siteId: "demo-site",
        adapter: "supabase",
        editor: { path: "/admin/editor", protected: true },
        pages: [
          {
            path: "/",
            label: "Home",
            regions: [{ id: "home.service.icon", kind: "icon" }],
          },
        ],
        sections: {},
      },
    });

    expect(result).toEqual({ ok: true, issues: [] });
  });

  it("accepts rendered global regions declared once for every page", () => {
    const result = runBuilderCheck({
      env: {
        SUPABASE_URL: "https://demo.supabase.co",
        SUPABASE_SERVICE_ROLE_KEY: "server-secret",
      },
      renderedRegions: [{ id: "global.navigation.home", kind: "link", source: "src/Header.tsx" }],
      site: {
        siteId: "demo-site",
        adapter: "supabase",
        editor: { path: "/admin/editor", protected: true },
        globalRegions: [{ id: "global.navigation.home", kind: "link" }],
        pages: [{ path: "/", label: "Home", regions: [] }],
        sections: {},
      },
    });

    expect(result).toEqual({ ok: true, issues: [] });
  });
});

describe("builder scan", () => {
  it("suggests separated text, image, icon, and link regions from static markup", () => {
    const result = scanEditableRegionsFromHtml({
      pageSlug: "home",
      source: "app/page.tsx",
      html: `
        <nav><a href="/">Home</a><a href="/about">About</a></nav>
        <section>
          <span class="material-symbols-outlined">work</span>
          <h1>Committed to Progress</h1>
          <p>Welcome to our official digital office.</p>
          <img src="/hero.jpg" alt="Hero" />
          <button>Get Help Now</button>
        </section>
      `,
    });

    expect(result.regions).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ id: "home.link.a.home", kind: "link", label: "Home" }),
        expect.objectContaining({ id: "home.link.a.about", kind: "link", label: "About" }),
        expect.objectContaining({ id: "home.icon.material.work", kind: "icon", label: "work" }),
        expect.objectContaining({ id: "home.text.h1.committed-to-progress", kind: "text" }),
        expect.objectContaining({ id: "home.text.p.welcome-to-our-official", kind: "text" }),
        expect.objectContaining({ id: "home.image.img.hero", kind: "image", label: "Hero" }),
        expect.objectContaining({ id: "home.link.button.get-help-now", kind: "link", label: "Get Help Now" }),
      ]),
    );
  });

  it("does not collapse nested headings and body copy into one group region", () => {
    const result = scanEditableRegionsFromHtml({
      pageSlug: "services",
      html: `
        <article>
          <h3>Unemployment Help</h3>
          <p>Navigate claims, appeals, and resources.</p>
          <a href="/services/unemployment">Learn More</a>
        </article>
      `,
    });

    expect(result.regions.map((region) => region.id)).toEqual([
      "services.text.h3.unemployment-help",
      "services.text.p.navigate-claims-appeals",
      "services.link.a.learn-more",
    ]);
  });

  it("classifies scan candidates for developer-assisted attach review", () => {
    const scan = scanEditableRegionsFromHtml({
      pageSlug: "home",
      source: "app/page.tsx",
      html: `
        <head><title>Morales Campaign</title><meta name="description" content="Progress for everyone" /></head>
        <nav><a href="/">Home</a><a href="/contact">Contact</a></nav>
        <section>
          <article><h3>Housing Help</h3><p>Support for tenants.</p><a href="/services/housing">Learn More</a></article>
          <article><h3>Benefits Help</h3><p>Support for claims.</p><a href="/services/benefits">Learn More</a></article>
          <form><input name="email" /><button>Join Updates</button></form>
          <img src="/divider.svg" alt="" />
        </section>
      `,
    });

    const candidates = classifyScanCandidates(scan);
    const categories = candidates.map((candidate) => candidate.category);

    expect(categories).toEqual(
      expect.arrayContaining([
        "seoMetadata",
        "navigation",
        "repeatedCollection",
        "form",
        "decorativeContent",
        "editableRegion",
      ]),
    );
    expect(candidates.some((candidate) => candidate.confidence === "manualReview")).toBe(true);
  });

  it("preserves approved stable identities and warns about ambiguous repeated renderings", () => {
    const result = scanEditableRegionsFromHtml({
      pageSlug: "contact",
      html: `
        <nav>
          <a data-builder-region="global.navigation.contact" data-builder-kind="link" data-builder-instance="desktop" href="/contact">Contact</a>
          <a data-builder-region="global.navigation.contact" data-builder-kind="link" href="/contact">Contact</a>
        </nav>
        <form data-builder-region="forms.service-request" data-builder-kind="sections" data-builder-protected="submission validation turnstile">
          <label data-builder-region="forms.service-request.email.label" data-builder-kind="text">Email</label>
          <input data-builder-region="forms.service-request.email.placeholder" data-builder-kind="text" data-builder-target="placeholder" placeholder="you@example.com" />
        </form>
      `,
    });

    expect(result.regions).toEqual(expect.arrayContaining([
      expect.objectContaining({ id: "global.navigation.contact", kind: "link" }),
      expect.objectContaining({ id: "forms.service-request.email.label", kind: "text" }),
      expect.objectContaining({ id: "forms.service-request.email.placeholder", kind: "text" }),
    ]));
    expect(result.warnings.map((warning) => warning.code)).toContain("scan.region.instance.missing");
  });

  it("generates an attach review report and an approved migration plan without mutating files", () => {
    const report = createAttachReviewReport({
      siteId: "morales-demo",
      framework: "next-app-router",
      routes: ["/", "/contact"],
      scan: scanEditableRegionsFromHtml({
        pageSlug: "home",
        source: "app/page.tsx",
        html: "<h1>Committed to Progress</h1><a href=\"/contact\">Contact</a>",
      }),
    });

    expect(report.siteId).toBe("morales-demo");
    expect(report.routes).toEqual(["/", "/contact"]);
    expect(report.instructions).toContain("Approve stable IDs before running migration");
    expect(report.candidates.length).toBeGreaterThan(0);

    const migration = planApprovedMigration({
      report,
      approvedCandidateIds: report.candidates.map((candidate) => candidate.id),
    });

    expect(migration.mutatesFiles).toBe(false);
    expect(migration.generatedFiles).toEqual(expect.arrayContaining(["builder.config.ts"]));
    expect(migration.nextSteps).toContain("Run builder check after applying the generated patch.");
  });
});

describe("builder init files", () => {
  it("generates the minimal files needed to attach a Next.js App Router site", () => {
    const files = getBuilderInitFiles({
      siteId: "garage-door-co",
      adapter: "central",
      editorPath: "/admin/editor",
    });

    expect(files.map((file) => file.path)).toEqual([
      "builder.config.ts",
      "app/api/builder/route.ts",
      "app/admin/editor/page.tsx",
      ".env.example",
    ]);
    expect(files[0].contents).toContain('siteId: "garage-door-co"');
    expect(files[0].contents).toContain('{ id: "home.hero.icon", kind: "icon", label: "Hero icon" }');
    expect(files[2].contents).toContain("EditorShell");
  });
});

describe("codex setup documentation", () => {
  it("documents the developer-assisted scan, approval, migration, and responsive verification workflow", () => {
    const readme = readFileSync(resolve(process.cwd(), "docs/codex-site-setup-readme.md"), "utf8");

    expect(readme).toContain("scanEditableRegionsFromHtml");
    expect(readme).toContain("classifyScanCandidates");
    expect(readme).toContain("createAttachReviewReport");
    expect(readme).toContain("planApprovedMigration");
    expect(readme).toContain("Verify real responsive preview behavior");
    expect(readme).toContain("Do not invent stable IDs after approval");
  });
});
