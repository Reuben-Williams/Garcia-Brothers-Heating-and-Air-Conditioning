import { describe, expect, it, vi } from "vitest";
import type { PostMigrationManifest } from "@your-builder/content";
import { seedPostDrafts, type PostSeedRepository } from "../src/migration/seed-posts.js";

function manifest(seedHash = "a".repeat(64)): PostMigrationManifest {
  return {
    schemaVersion: 1,
    toolVersion: "0.1.0",
    manifestId: "postmig_assembly-v1",
    seedHash,
    siteKey: "assembly",
    sourceScopeKey: "announcements",
    collectionRegionId: "home.announcements",
    sourceFiles: [{ path: "source.tsx", sha256: "b".repeat(64), astFingerprint: "c".repeat(64) }],
    reviewedPatchSpec: {
      candidates: [{ candidateId: "cards", sourceFile: "source.tsx", sourceSpan: { start: 0, end: 1 }, transform: "replace-post-collection", fieldMappings: [{ postField: "title", sourceExpression: "title" }], categoryMappings: {} }],
      detailRoute: { route: "/news/[postSlug]", sourceFile: "page.tsx", rendererExport: "Detail" },
      fallbackSource: { sourceFile: "fallback.ts", exportName: "posts" },
      collectionRenderer: { sourceFile: "Cards.tsx", exportName: "Cards", variant: "default" },
    },
    records: [{
      sourceRecordKey: "one",
      entryId: "06a80923-d9a6-4e46-8e7b-c7a475f7a915",
      fallbackEntryId: "06a80923-d9a6-4e46-8e7b-c7a475f7a915",
      approvedFields: {
        slug: "one",
        data: { title: "One", excerpt: "First", body: { version: 1, type: "doc", content: [] }, featuredImage: null, author: { key: null, name: "Office" }, featured: false, pinned: false, seo: { title: "One", description: "First", canonicalUrl: null, socialImage: null, noIndex: false } },
        taxonomyKeys: { categories: [], tags: [] }, taxonomySnapshot: {}, displayDate: "2026-07-14T12:00:00.000Z", expiresAt: null,
      },
    }],
    generatedArtifacts: [],
  };
}

function repository(): PostSeedRepository {
  return {
    getImport: vi.fn(async () => null),
    getEntryState: vi.fn(async () => null),
    createDraft: vi.fn(async () => ({ versionId: "draft-1" })),
    recordImport: vi.fn(async () => undefined),
  };
}

describe("post draft seeding", () => {
  it("requires explicit confirmation and creates drafts only", async () => {
    const repo = repository();
    await expect(seedPostDrafts(manifest(), repo, { confirmed: false })).rejects.toThrow(/confirmation/i);

    const result = await seedPostDrafts(manifest(), repo, { confirmed: true });
    expect(result).toMatchObject({ created: 1, skipped: 0, published: 0 });
    expect(repo.createDraft).toHaveBeenCalledTimes(1);
  });

  it("is idempotent for the same manifest and rejects changed seed payloads", async () => {
    const repo = repository();
    vi.mocked(repo.getImport).mockResolvedValue({ manifestId: "postmig_assembly-v1", seedHash: "a".repeat(64), entryIds: [manifest().records[0]!.entryId] });

    await expect(seedPostDrafts(manifest(), repo, { confirmed: true })).resolves.toMatchObject({ created: 0, skipped: 1 });
    await expect(seedPostDrafts(manifest("d".repeat(64)), repo, { confirmed: true })).rejects.toThrow(/seed payload/i);
  });

  it("refuses to overwrite an owner-edited draft", async () => {
    const repo = repository();
    vi.mocked(repo.getEntryState).mockResolvedValue({ entryId: manifest().records[0]!.entryId, importedSeedHash: "older", ownerEdited: true });

    await expect(seedPostDrafts(manifest(), repo, { confirmed: true })).rejects.toThrow(/owner-edited/i);
    expect(repo.createDraft).not.toHaveBeenCalled();
  });
});
