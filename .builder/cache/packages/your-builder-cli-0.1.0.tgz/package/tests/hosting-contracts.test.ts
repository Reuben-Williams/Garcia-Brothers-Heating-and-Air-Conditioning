import { mkdir, mkdtemp, realpath, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, describe, expect, it } from "vitest";

import {
  HostingContractError,
  assertCurrentPreflight,
  createPreflightReceipt,
  createServerEnvironmentInput,
  parseConfigureResult,
  parseHostingTarget,
  parsePreflightReceipt,
  parseProviderVerifyResult,
  type HostingTarget,
} from "../src/hosting/contracts.js";
import { createProjectFingerprint } from "../src/hosting/project-fingerprint.js";
import { createHostingAdapterRegistry } from "../src/hosting/adapter-registry.js";

const directories: string[] = [];

afterEach(async () => {
  await Promise.all(directories.splice(0).map((directory) => rm(directory, {
    recursive: true,
    force: true,
  })));
});

function target(overrides: Partial<HostingTarget> = {}): HostingTarget {
  return {
    provider: "netlify",
    accountId: "team_123",
    siteId: "01aafa12-cd7d-444e-b6dc-783ff60e014c",
    siteName: "garcia-brothers-private-staging",
    context: "branch-deploy",
    branch: "staging",
    scopes: ["builds", "functions", "runtime"],
    ...overrides,
  };
}

describe("hosting contracts", () => {
  it("parses exact targets and rejects unknown fields, wildcards, and empty scopes", () => {
    expect(parseHostingTarget(target())).toEqual(target());
    expect(() => parseHostingTarget({ ...target(), extra: true })).toThrowError(
      expect.objectContaining({ code: "invalid_hosting_target" }),
    );
    expect(() => parseHostingTarget(target({ scopes: [] }))).toThrowError(
      expect.objectContaining({ code: "invalid_hosting_target" }),
    );
    expect(() => parseHostingTarget(target({ scopes: ["*"] }))).toThrowError(
      expect.objectContaining({ code: "invalid_hosting_target" }),
    );
  });

  it("canonicalizes scope order and receipt hashing", () => {
    const first = createPreflightReceipt({
      target: target({ scopes: ["runtime", "builds", "functions"] }),
      projectFingerprint: "a".repeat(64),
      linkedStateHash: "b".repeat(64),
      issuedAt: "2026-07-19T12:00:00.000Z",
    });
    const second = createPreflightReceipt({
      linkedStateHash: "b".repeat(64),
      issuedAt: "2026-07-19T12:00:00.000Z",
      projectFingerprint: "a".repeat(64),
      target: {
        scopes: ["functions", "runtime", "builds"],
        branch: "staging",
        context: "branch-deploy",
        siteName: "garcia-brothers-private-staging",
        siteId: "01aafa12-cd7d-444e-b6dc-783ff60e014c",
        accountId: "team_123",
        provider: "netlify",
      },
    });

    expect(first.digest).toBe(second.digest);
    expect(first.target.scopes).toEqual(["builds", "functions", "runtime"]);
    expect(first.expiresAt).toBe("2026-07-19T12:10:00.000Z");
    expect(parsePreflightReceipt(first)).toEqual(first);
    expect(() => parsePreflightReceipt({ ...first, unknown: true })).toThrowError(
      expect.objectContaining({ code: "invalid_preflight_receipt" }),
    );
  });

  it.each([
    [599, true],
    [600, true],
    [601, false],
  ])("enforces the 600-second receipt boundary at %i seconds", (ageSeconds, accepted) => {
    const receipt = createPreflightReceipt({
      target: target(),
      projectFingerprint: "a".repeat(64),
      linkedStateHash: "b".repeat(64),
      issuedAt: "2026-07-19T12:00:00.000Z",
    });
    const verify = () => assertCurrentPreflight({
      receipt,
      detectedTarget: target(),
      projectFingerprint: "a".repeat(64),
      linkedStateHash: "b".repeat(64),
      now: new Date(new Date("2026-07-19T12:00:00.000Z").getTime() + ageSeconds * 1_000),
    });

    if (accepted) expect(verify()).toEqual({ siteNameChanged: false });
    else expect(verify).toThrowError(expect.objectContaining({ code: "preflight_expired" }));
  });

  it("rejects future-dated receipts", () => {
    const receipt = createPreflightReceipt({
      target: target(),
      projectFingerprint: "a".repeat(64),
      linkedStateHash: "b".repeat(64),
      issuedAt: "2026-07-19T12:00:01.000Z",
    });

    expect(() => assertCurrentPreflight({
      receipt,
      detectedTarget: target(),
      projectFingerprint: "a".repeat(64),
      linkedStateHash: "b".repeat(64),
      now: new Date("2026-07-19T12:00:00.000Z"),
    })).toThrowError(expect.objectContaining({ code: "preflight_future_dated" }));
  });

  it.each([
    ["provider", target({ provider: "manual" })],
    ["account", target({ accountId: "team_changed" })],
    ["site", target({ siteId: "11111111-1111-4111-8111-111111111111" })],
    ["context", target({ context: "production" })],
    ["branch", target({ branch: "main" })],
    ["scopes", target({ scopes: ["builds", "functions"] })],
  ])("rejects %s drift", (_dimension, detectedTarget) => {
    const receipt = createPreflightReceipt({
      target: target(),
      projectFingerprint: "a".repeat(64),
      linkedStateHash: "b".repeat(64),
      issuedAt: "2026-07-19T12:00:00.000Z",
    });

    expect(() => assertCurrentPreflight({
      receipt,
      detectedTarget,
      projectFingerprint: "a".repeat(64),
      linkedStateHash: "b".repeat(64),
      now: new Date("2026-07-19T12:05:00.000Z"),
    })).toThrowError(expect.objectContaining({ code: "preflight_drift" }));
  });

  it("rejects linked-state and project-directory drift independently", () => {
    const receipt = createPreflightReceipt({
      target: target(),
      projectFingerprint: "a".repeat(64),
      linkedStateHash: "b".repeat(64),
      issuedAt: "2026-07-19T12:00:00.000Z",
    });
    const base = {
      receipt,
      detectedTarget: target(),
      projectFingerprint: "a".repeat(64),
      linkedStateHash: "b".repeat(64),
      now: new Date("2026-07-19T12:05:00.000Z"),
    };

    expect(() => assertCurrentPreflight({ ...base, linkedStateHash: "c".repeat(64) }))
      .toThrowError(expect.objectContaining({ code: "preflight_drift" }));
    expect(() => assertCurrentPreflight({ ...base, projectFingerprint: "d".repeat(64) }))
      .toThrowError(expect.objectContaining({ code: "preflight_drift" }));
  });

  it("treats a changed display name as attention without changing immutable identity", () => {
    const receipt = createPreflightReceipt({
      target: target(),
      projectFingerprint: "a".repeat(64),
      linkedStateHash: "b".repeat(64),
      issuedAt: "2026-07-19T12:00:00.000Z",
    });

    expect(assertCurrentPreflight({
      receipt,
      detectedTarget: target({ siteName: "renamed-site" }),
      projectFingerprint: "a".repeat(64),
      linkedStateHash: "b".repeat(64),
      now: new Date("2026-07-19T12:05:00.000Z"),
    })).toEqual({ siteNameChanged: true });
  });

  it("parses exact value-free configuration and provider verification results", () => {
    expect(parseConfigureResult({
      status: "configured",
      names: [
        "BUILDER_CONTROL_PLANE_URL",
        "BUILDER_INSTALLATION_ID",
        "BUILDER_INSTALLATION_KEY_ID",
        "BUILDER_INSTALLATION_PRIVATE_JWK",
      ],
    })).toMatchObject({ status: "configured" });
    expect(parseProviderVerifyResult({
      status: "verified",
      target: target(),
      names: [
        "BUILDER_CONTROL_PLANE_URL",
        "BUILDER_INSTALLATION_ID",
        "BUILDER_INSTALLATION_KEY_ID",
        "BUILDER_INSTALLATION_PRIVATE_JWK",
      ],
    })).toMatchObject({ status: "verified" });
    expect(parseProviderVerifyResult({
      status: "acknowledged",
      target: target({ provider: "manual" }),
      names: [
        "BUILDER_CONTROL_PLANE_URL",
        "BUILDER_INSTALLATION_ID",
        "BUILDER_INSTALLATION_KEY_ID",
        "BUILDER_INSTALLATION_PRIVATE_JWK",
      ],
    })).toMatchObject({ status: "acknowledged" });
    expect(() => parseConfigureResult({ status: "configured", names: [], value: "secret" }))
      .toThrowError(expect.objectContaining({ code: "invalid_configure_result" }));
  });

  it("redacts the four exact server values from inspection and JSON serialization", () => {
    const environment = createServerEnvironmentInput({
      BUILDER_CONTROL_PLANE_URL: "https://control.example.com",
      BUILDER_INSTALLATION_ID: "11111111-1111-4111-8111-111111111111",
      BUILDER_INSTALLATION_KEY_ID: "installation:key",
      BUILDER_INSTALLATION_PRIVATE_JWK: "private-jwk-canary",
    });

    expect(JSON.stringify(environment)).toBe('"[REDACTED]"');
    expect(String(environment)).toBe("[REDACTED]");
    expect(environment.names()).toEqual([
      "BUILDER_CONTROL_PLANE_URL",
      "BUILDER_INSTALLATION_ID",
      "BUILDER_INSTALLATION_KEY_ID",
      "BUILDER_INSTALLATION_PRIVATE_JWK",
    ]);
    expect(() => createServerEnvironmentInput({
      BUILDER_CONTROL_PLANE_URL: "https://control.example.com",
      BUILDER_INSTALLATION_ID: "11111111-1111-4111-8111-111111111111",
      BUILDER_INSTALLATION_KEY_ID: "installation:key",
      BUILDER_INSTALLATION_PRIVATE_JWK: "private-jwk-canary",
      EXTRA_VALUE: "not-allowed",
    } as never)).toThrowError(HostingContractError);
  });

  it("fingerprints the canonical directory and reviewed marker files without reading secret paths", async () => {
    const directory = await mkdtemp(join(tmpdir(), "builder-hosting-contract-"));
    directories.push(directory);
    await mkdir(join(directory, ".netlify"));
    await mkdir(join(directory, ".builder", "secrets"), { recursive: true });
    await writeFile(join(directory, ".netlify", "state.json"), '{"siteId":"site_123"}\n');
    await writeFile(join(directory, "package.json"), '{"name":"pilot"}\n');
    await writeFile(join(directory, ".builder", "secrets", "private.jwk"), "secret-canary");

    const fingerprint = await createProjectFingerprint(directory, [
      ".netlify/state.json",
      "package.json",
    ]);

    expect(fingerprint.canonicalProjectDir).toBe(await realpath(directory));
    expect(fingerprint.digest).toMatch(/^[a-f0-9]{64}$/);
    await expect(createProjectFingerprint(directory, [".builder/secrets/private.jwk"]))
      .rejects.toMatchObject({ code: "unsafe_fingerprint_marker" });
  });

  it("registers only one adapter for each exact supported provider", () => {
    const manual = {
      id: "manual" as const,
      detect: async () => ({ status: "detected" as const, target: target({ provider: "manual" }) }),
      preflight: async () => { throw new Error("unused"); },
      configure: async () => { throw new Error("unused"); },
      verifyConfiguration: async () => { throw new Error("unused"); },
    };
    const registry = createHostingAdapterRegistry([manual]);

    expect(registry.ids()).toEqual(["manual"]);
    expect(registry.get("manual")).toBe(manual);
    expect(() => registry.get("netlify")).toThrowError(
      expect.objectContaining({ code: "hosting_adapter_unavailable" }),
    );
    expect(() => createHostingAdapterRegistry([manual, manual])).toThrowError(
      expect.objectContaining({ code: "duplicate_hosting_adapter" }),
    );
  });
});
