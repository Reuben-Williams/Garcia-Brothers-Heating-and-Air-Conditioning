import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";

import { afterEach, describe, expect, it, vi } from "vitest";

import { dispatchBuilderCli } from "../src/bin.js";
import { runModuleAttachCheck } from "../src/modules/compatibility.js";

const temporaryDirectories: string[] = [];

async function projectFixture(input: { schemaVersion?: number } = {}) {
  const projectDir = await mkdtemp(join(process.cwd(), ".tmp-builder-module-check-"));
  temporaryDirectories.push(projectDir);
  await mkdir(join(projectDir, ".builder"), { recursive: true });
  await mkdir(join(projectDir, "app"), { recursive: true });
  await writeFile(join(projectDir, "app", "page.tsx"), "export default function Page() { return null; }\n");
  await writeFile(join(projectDir, "builder.config.ts"), `export default {
  siteId: "module-check",
  adapter: "central",
  editor: { path: "/admin/editor", protected: true },
  pages: [{ path: "/", label: "Home", regions: [] }],
  sections: {},
};\n`);
  await writeFile(join(projectDir, "package.json"), JSON.stringify({
    dependencies: { "@your-builder/reviews": "1.2.1" },
  }, null, 2));
  await writeFile(join(projectDir, ".builder", "installation-manifest.json"), JSON.stringify({
    version: 1,
    packages: {},
    schemas: { reviews: input.schemaVersion ?? 2 },
    routes: ["/", "/reviews", "/api/reviews/sync"],
    workerVersion: "0.3.1",
  }, null, 2));
  await writeFile(join(projectDir, ".builder", "module-manifest.json"), JSON.stringify({
    manifestVersion: 1,
    moduleId: "growth.reviews",
    moduleVersion: "1.0.0",
    requirements: {
      packages: { "@your-builder/reviews": "1.2.0" },
      schemas: { reviews: 2 },
      routes: ["/reviews", "/api/reviews/sync"],
      minimumWorkerVersion: "0.3.0",
    },
  }, null, 2));
  return projectDir;
}

afterEach(async () => {
  vi.unstubAllEnvs();
  await Promise.all(temporaryDirectories.splice(0).map((path) => rm(path, { recursive: true, force: true })));
});

describe("module attach check", () => {
  it("returns a reviewable report without mutating project source", async () => {
    const projectDir = await projectFixture();
    const sourcePath = join(projectDir, "app", "page.tsx");
    const before = await readFile(sourcePath, "utf8");

    const report = await runModuleAttachCheck({ projectDir });

    expect(report).toEqual({ compatible: true, mutatesFiles: false, issues: [] });
    await expect(readFile(sourcePath, "utf8")).resolves.toBe(before);
  });

  it("reports a migration requirement and still leaves source unchanged", async () => {
    const projectDir = await projectFixture({ schemaVersion: 1 });
    const sourcePath = join(projectDir, "app", "page.tsx");
    const before = await readFile(sourcePath, "utf8");

    const report = await runModuleAttachCheck({ projectDir });

    expect(report.compatible).toBe(false);
    expect(report.issues).toContainEqual(expect.objectContaining({
      code: "SCHEMA_VERSION_TOO_OLD",
      migrationRequired: true,
    }));
    await expect(readFile(sourcePath, "utf8")).resolves.toBe(before);
  });

  it("extends builder check when an approved module manifest is present", async () => {
    const projectDir = await projectFixture({ schemaVersion: 1 });
    const output = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };

    await expect(dispatchBuilderCli(["check", "--project", projectDir], { output }))
      .resolves.toBe(1);

    expect(output.error).toHaveBeenCalledWith(expect.stringContaining("SCHEMA_VERSION_TOO_OLD"));
    expect(output.info).not.toHaveBeenCalledWith(expect.stringContaining("Builder check passed."));
  });

  it("fails closed when an approved module check is missing installation evidence", async () => {
    const projectDir = await projectFixture();
    await rm(join(projectDir, ".builder", "installation-manifest.json"));
    vi.stubEnv("BUILDER_API_URL", "https://builder.example.test");
    vi.stubEnv("BUILDER_SITE_TOKEN", "test-token");
    const output = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };

    await expect(dispatchBuilderCli(["check", "--project", projectDir], { output }))
      .resolves.toBe(1);

    expect(output.error).toHaveBeenCalledWith("command_failed");
    expect(output.info).not.toHaveBeenCalled();
  });
});
