// @vitest-environment node

import { mkdtemp, mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";

import { afterEach, describe, expect, it, vi } from "vitest";

import { dispatchBuilderCli } from "../src/bin.js";
import { runGrowthFoundationCheck } from "../src/foundation/growth-foundation-check.js";

const temporaryDirectories: string[] = [];

async function writeJson(path: string, value: unknown) {
  await writeFile(path, `${JSON.stringify(value, null, 2)}\n`);
}

async function foundationProject() {
  const projectDir = await mkdtemp(join(process.cwd(), ".tmp-growth-foundation-check-"));
  temporaryDirectories.push(projectDir);
  await mkdir(join(projectDir, ".builder"), { recursive: true });
  await mkdir(join(projectDir, "app", "admin", "editor"), { recursive: true });
  await mkdir(join(projectDir, "app", "api", "builder"), { recursive: true });
  await mkdir(join(projectDir, "lib"), { recursive: true });
  await writeFile(join(projectDir, "builder.config.ts"), `export default {
  siteId: "local-business-acceptance",
  adapter: "central",
  editor: { path: "/admin/editor", protected: true },
  pages: [{ path: "/", label: "Home", regions: [
    { id: "home.hero.title", kind: "text" },
    { id: "home.hero.image", kind: "image" }
  ] }],
  sections: {},
};\n`);
  await writeFile(join(projectDir, "app", "page.tsx"), `const fallbackContent = { title: "Local service" };
export default function Page() { return <main>{fallbackContent.title}</main>; }\n`);
  await writeFile(join(projectDir, "app", "admin", "editor", "page.tsx"),
    "export default function EditorPage() { return null; }\n");
  await writeFile(join(projectDir, "app", "api", "builder", "route.ts"), `import "server-only";
const privateKeyPath = ".builder/secrets/installation-private.jwk";
export function GET() { return Response.json({ configured: Boolean(privateKeyPath) }); }\n`);
  await writeFile(join(projectDir, "lib", "installation-worker.ts"), `import "server-only";
import { createInstallationWorker } from "@your-builder/next/control-plane";
export const workerFactory = createInstallationWorker;\n`);
  await writeFile(join(projectDir, "lib", "entitlement-snapshot.ts"), `import "server-only";
import { createEntitlementSnapshotCache } from "@your-builder/entitlements/server";
export const snapshotFactory = createEntitlementSnapshotCache;\n`);
  await writeJson(join(projectDir, "package.json"), {
    dependencies: {
      "@your-builder/entitlements": "0.1.0",
      "@your-builder/next": "0.1.0",
      "@your-builder/reviews": "1.2.1",
    },
  });
  await writeJson(join(projectDir, ".builder", "installation-manifest.json"), {
    version: 1,
    packages: {},
    schemas: { reviews: 2 },
    routes: ["/", "/admin/editor", "/reviews", "/api/reviews/sync"],
    workerVersion: "0.3.1",
  });
  await writeJson(join(projectDir, ".builder", "module-manifest.json"), {
    manifestVersion: 1,
    moduleId: "growth.reviews",
    moduleVersion: "1.0.0",
    requirements: {
      packages: { "@your-builder/reviews": "1.2.0" },
      schemas: { reviews: 2 },
      routes: ["/reviews", "/api/reviews/sync"],
      minimumWorkerVersion: "0.3.0",
    },
  });
  return projectDir;
}

async function sourceSnapshot(projectDir: string) {
  const paths = [
    "builder.config.ts",
    "app/page.tsx",
    "app/admin/editor/page.tsx",
    "app/api/builder/route.ts",
    "lib/installation-worker.ts",
    "lib/entitlement-snapshot.ts",
    "package.json",
    ".builder/installation-manifest.json",
    ".builder/module-manifest.json",
  ];
  return Object.fromEntries(await Promise.all(paths.map(async (path) => [
    path,
    await readFile(join(projectDir, path), "utf8"),
  ])));
}

afterEach(async () => {
  vi.unstubAllEnvs();
  await Promise.all(temporaryDirectories.splice(0).map((path) =>
    rm(path, { recursive: true, force: true })));
});

describe("growth foundation attach check", () => {
  it("returns a reviewable passing report without mutating any project file", async () => {
    const projectDir = await foundationProject();
    const before = await sourceSnapshot(projectDir);

    const report = await runGrowthFoundationCheck({ projectDir });

    expect(report.ok).toBe(true);
    expect(report.mutatesFiles).toBe(false);
    expect(report.issues).toEqual([]);
    expect(report.checks.map((check) => check.id)).toEqual([
      "module_manifest_version",
      "stable_ids",
      "unique_routes",
      "package_schema_compatibility",
      "server_only_trust",
      "protected_admin_route",
      "command_worker",
      "snapshot_cache",
      "public_fallback",
    ]);
    expect(report.checks.every((check) => check.status === "pass")).toBe(true);
    expect(await sourceSnapshot(projectDir)).toEqual(before);
  });

  it("runs the foundation report through builder check when the installation declares the editor route", async () => {
    const projectDir = await foundationProject();
    vi.stubEnv("BUILDER_API_URL", "https://control.example.test");
    vi.stubEnv("BUILDER_SITE_TOKEN", "fixture-site-token");
    const output = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };

    await expect(dispatchBuilderCli(["check", "--project", projectDir], { output })).resolves.toBe(0);

    expect(output.info).toHaveBeenCalledWith([
      "Builder check passed.",
      "Growth foundation check passed.",
    ].join("\n"));
    expect(output.error).not.toHaveBeenCalled();
  });

  it("does not execute top-level project code while reading builder config", async () => {
    const projectDir = await foundationProject();
    const marker = join(projectDir, "foundation-check-executed.txt");
    const configPath = join(projectDir, "builder.config.ts");
    const config = await readFile(configPath, "utf8");
    await writeFile(configPath, `import { writeFileSync } from "node:fs";
writeFileSync(${JSON.stringify(marker)}, "executed");
${config}`);

    await expect(runGrowthFoundationCheck({ projectDir })).resolves.toMatchObject({ ok: true });
    await expect(readFile(marker, "utf8")).rejects.toMatchObject({ code: "ENOENT" });
  });

  it("accepts a JavaScript App Router fallback and JavaScript builder config", async () => {
    const projectDir = await foundationProject();
    await rename(join(projectDir, "app", "page.tsx"), join(projectDir, "app", "page.jsx"));
    await rename(join(projectDir, "builder.config.ts"), join(projectDir, "builder.config.mjs"));

    const report = await runGrowthFoundationCheck({ projectDir });

    expect(report.checks.find((check) => check.id === "public_fallback")?.status).toBe("pass");
    expect(report.ok).toBe(true);
  });

  it("ignores generated Next.js build backup directories", async () => {
    const projectDir = await foundationProject();
    const generatedDir = join(projectDir, ".next-stale-package-refresh", "server");
    await mkdir(generatedDir, { recursive: true });
    await writeFile(join(generatedDir, "route.js"),
      "const key = process.env.SUPABASE_SERVICE_ROLE_KEY;\n");

    const report = await runGrowthFoundationCheck({ projectDir });

    expect(report.ok).toBe(true);
    expect(report.issues).toEqual([]);
  });

  it("ignores protected client-owned support directories", async () => {
    const projectDir = await foundationProject();
    for (const root of ["sales-package", "site-editor-platform"]) {
      const supportDir = join(projectDir, root, "packages");
      await mkdir(supportDir, { recursive: true });
      await writeFile(join(supportDir, "example.ts"),
        "const key = process.env.SUPABASE_SERVICE_ROLE_KEY;\n");
    }

    const report = await runGrowthFoundationCheck({ projectDir });

    expect(report.ok).toBe(true);
    expect(report.issues).toEqual([]);
  });

  it("reports missing manifests instead of throwing", async () => {
    const projectDir = await foundationProject();
    await rm(join(projectDir, ".builder", "module-manifest.json"));
    await rm(join(projectDir, ".builder", "installation-manifest.json"));

    const report = await runGrowthFoundationCheck({ projectDir });

    expect(report.ok).toBe(false);
    expect(report.mutatesFiles).toBe(false);
    expect(report.issues).toEqual(expect.arrayContaining([
      expect.objectContaining({ code: "MODULE_MANIFEST_MISSING" }),
      expect.objectContaining({ code: "INSTALLATION_MANIFEST_MISSING" }),
    ]));
  });

  it.each([
    ["unstable region IDs", "UNSTABLE_ID", async (projectDir: string) => {
      const path = join(projectDir, "builder.config.ts");
      await writeFile(path, (await readFile(path, "utf8")).replace("home.hero.title", "Home Hero Title"));
    }],
    ["duplicate installation routes", "DUPLICATE_ROUTE", async (projectDir: string) => {
      const path = join(projectDir, ".builder", "installation-manifest.json");
      const manifest = JSON.parse(await readFile(path, "utf8"));
      manifest.routes.push("/reviews");
      await writeJson(path, manifest);
    }],
    ["client-visible trust values", "TRUST_VALUE_CLIENT_EXPOSED", async (projectDir: string) => {
      await writeFile(join(projectDir, "app", "client.tsx"), `"use client";
export const leaked = process.env.BUILDER_INSTALLATION_PRIVATE_JWK;\n`);
    }],
    ["an unprotected editor", "ADMIN_ROUTE_UNPROTECTED", async (projectDir: string) => {
      const path = join(projectDir, "builder.config.ts");
      await writeFile(path, (await readFile(path, "utf8")).replace("protected: true", "protected: false"));
    }],
    ["a missing command worker", "COMMAND_WORKER_MISSING", async (projectDir: string) => {
      await rm(join(projectDir, "lib", "installation-worker.ts"));
    }],
    ["a missing snapshot cache", "SNAPSHOT_CACHE_MISSING", async (projectDir: string) => {
      await rm(join(projectDir, "lib", "entitlement-snapshot.ts"));
    }],
    ["a missing public fallback", "PUBLIC_FALLBACK_MISSING", async (projectDir: string) => {
      await writeFile(join(projectDir, "app", "page.tsx"),
        "export default async function Page() { return fetch(process.env.BUILDER_API_URL!).then(() => null); }\n");
    }],
  ])("reports %s and remains non-mutating", async (_label, code, alter) => {
    const projectDir = await foundationProject();
    await alter(projectDir);
    const before = await sourceSnapshot(projectDir).catch(() => ({}));

    const report = await runGrowthFoundationCheck({ projectDir });

    expect(report.ok).toBe(false);
    expect(report.mutatesFiles).toBe(false);
    expect(report.issues).toContainEqual(expect.objectContaining({ code }));
    expect(await sourceSnapshot(projectDir).catch(() => ({}))).toEqual(before);
  });
});
