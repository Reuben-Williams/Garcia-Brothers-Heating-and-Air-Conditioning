import { fingerprintSource } from "../scan/source-fingerprint.js";
import { ProjectFilesystem } from "../control-plane/project-filesystem.js";
import { parseInstallationManifest } from "../control-plane/register-installation.js";
import { loadBuilderSiteConfig, runGrowthFoundationCheck } from "../foundation/growth-foundation-check.js";
import { runModuleAttachCheck } from "../modules/compatibility.js";
import { parseModuleManifest } from "../modules/module-manifest.js";
import { runBuilderCheck } from "../index.js";
import { parseOnboardingApplyReceipt, verifyOnboardingApply, type OnboardingApplyReceipt } from "./apply.js";
import { OnboardingError } from "./contracts.js";
import {
  canonicalOnboardingValue,
  parseOnboardingInspectionReport,
  type OnboardingInspectionReport,
} from "./inspect.js";
import { parseOnboardingAttachmentPlan, type OnboardingAttachmentPlan } from "./plan.js";

const DIGEST = /^[a-f0-9]{64}$/;
const REQUIRED_VIEWPORTS = [390, 768, 1280] as const;

interface VerificationArtifactReference {
  readonly path: string;
  readonly sha256: string;
}

export interface OnboardingVerificationEvidence {
  readonly version: 1;
  readonly reviewId: string;
  readonly planId: string;
  readonly applyReceiptId: string;
  readonly productionBuild: VerificationArtifactReference;
  readonly responsiveSmoke: VerificationArtifactReference;
}

export type OnboardingAggregateCheckId =
  | "source_hashes"
  | "rendered_artifacts"
  | "config_rendered_regions"
  | "installation_manifest"
  | "module_manifest"
  | "package_compatibility"
  | "protected_editor_and_growth_foundation"
  | "production_build"
  | "responsive_smoke";

export interface OnboardingAggregateVerificationReport {
  readonly version: 1;
  readonly verificationId: string;
  readonly reviewId: string;
  readonly planId: string;
  readonly applyReceiptId: string;
  readonly checks: readonly { readonly id: OnboardingAggregateCheckId; readonly status: "pass" | "fail" }[];
  readonly issues: readonly { readonly code: string; readonly message: string; readonly path?: string }[];
  readonly ok: boolean;
  readonly safety: {
    readonly clientSourceMutated: false;
    readonly remoteSystemsMutated: false;
  };
}

function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new OnboardingError("verification_failed");
  return value as Record<string, unknown>;
}

function exact(value: Record<string, unknown>, keys: readonly string[]): void {
  if (Object.keys(value).some((key) => !keys.includes(key)) || keys.some((key) => !(key in value))) {
    throw new OnboardingError("verification_failed");
  }
}

function artifactPath(value: unknown): string {
  if (typeof value !== "string" || !value || value.length > 300 || value.includes("\\") || value.startsWith("/") ||
      /^[a-z]:/i.test(value) || value.split("/").some((segment) => !segment || segment === "." || segment === "..")) {
    throw new OnboardingError("verification_failed");
  }
  return value;
}

function parseArtifactReference(value: unknown): VerificationArtifactReference {
  const artifact = record(value);
  exact(artifact, ["path", "sha256"]);
  if (typeof artifact.sha256 !== "string" || !DIGEST.test(artifact.sha256)) {
    throw new OnboardingError("verification_failed");
  }
  return { path: artifactPath(artifact.path), sha256: artifact.sha256 };
}

export function parseOnboardingVerificationEvidence(value: unknown): OnboardingVerificationEvidence {
  const root = record(value);
  exact(root, ["version", "reviewId", "planId", "applyReceiptId", "productionBuild", "responsiveSmoke"]);
  if (root.version !== 1 ||
      typeof root.reviewId !== "string" || !DIGEST.test(root.reviewId) ||
      typeof root.planId !== "string" || !DIGEST.test(root.planId) ||
      typeof root.applyReceiptId !== "string" || !DIGEST.test(root.applyReceiptId)) {
    throw new OnboardingError("verification_failed");
  }
  return {
    version: 1,
    reviewId: root.reviewId,
    planId: root.planId,
    applyReceiptId: root.applyReceiptId,
    productionBuild: parseArtifactReference(root.productionBuild),
    responsiveSmoke: parseArtifactReference(root.responsiveSmoke),
  };
}

function verificationSourceSha256(input: {
  report: OnboardingInspectionReport;
  plan: OnboardingAttachmentPlan;
  applyReceipt: OnboardingApplyReceipt;
}): string {
  const files = new Map(input.report.routes.map((route) => [route.source, route.sourceSha256]));
  for (const file of input.applyReceipt.files) files.set(file.path, file.afterHash);
  return fingerprintSource(canonicalOnboardingValue({
    version: 1,
    reviewId: input.report.reviewId,
    planId: input.plan.planId,
    applyReceiptId: input.applyReceipt.receiptId,
    files: [...files.entries()]
      .map(([path, sha256]) => ({ path, sha256 }))
      .sort((left, right) => left.path.localeCompare(right.path)),
  }));
}

function parseBuildReceipt(value: unknown, sourceSha256: string): VerificationArtifactReference {
  const receipt = record(value);
  exact(receipt, ["version", "kind", "sourceSha256", "command", "runner", "exitCode", "artifact"]);
  if (receipt.version !== 1 || receipt.kind !== "production-build" || receipt.sourceSha256 !== sourceSha256 ||
      receipt.command !== "npm run build" || receipt.runner !== "builder-cli" || receipt.exitCode !== 0) {
    throw new OnboardingError("verification_failed");
  }
  return parseArtifactReference(receipt.artifact);
}

function parseBuildArtifact(value: unknown, sourceSha256: string): readonly VerificationArtifactReference[] {
  const artifact = record(value);
  exact(artifact, ["version", "kind", "sourceSha256", "outputs"]);
  if (artifact.version !== 1 || artifact.kind !== "production-build-artifact" ||
      artifact.sourceSha256 !== sourceSha256 || !Array.isArray(artifact.outputs) ||
      artifact.outputs.length === 0 || artifact.outputs.length > 200) {
    throw new OnboardingError("verification_failed");
  }
  const outputs = artifact.outputs.map(parseArtifactReference);
  if (new Set(outputs.map((output) => output.path)).size !== outputs.length) {
    throw new OnboardingError("verification_failed");
  }
  return outputs;
}

interface ResponsiveResult {
  readonly viewport: number;
  readonly artifact: VerificationArtifactReference;
}

function parseResponsiveReceipt(value: unknown, sourceSha256: string): readonly ResponsiveResult[] {
  const receipt = record(value);
  exact(receipt, ["version", "kind", "sourceSha256", "command", "runner", "exitCode", "results"]);
  if (receipt.version !== 1 || receipt.kind !== "responsive-smoke" || receipt.sourceSha256 !== sourceSha256 ||
      receipt.command !== "npm run test:responsive-smoke" || receipt.runner !== "playwright" || receipt.exitCode !== 0 ||
      !Array.isArray(receipt.results) || receipt.results.length > 32) {
    throw new OnboardingError("verification_failed");
  }
  const results = receipt.results.map((value) => {
    const result = record(value);
    exact(result, ["viewport", "status", "artifact"]);
    if (!Number.isSafeInteger(result.viewport) || (result.viewport as number) < 240 ||
        (result.viewport as number) > 4_096 || result.status !== "passed") {
      throw new OnboardingError("verification_failed");
    }
    return { viewport: result.viewport as number, artifact: parseArtifactReference(result.artifact) };
  });
  if (new Set(results.map((result) => result.viewport)).size !== results.length) {
    throw new OnboardingError("verification_failed");
  }
  return results;
}

function parseResponsiveArtifact(value: unknown, sourceSha256: string, viewport: number): void {
  const artifact = record(value);
  exact(artifact, ["version", "kind", "sourceSha256", "viewport", "checks"]);
  const checks = record(artifact.checks);
  exact(checks, ["pageLoaded", "noHorizontalOverflow"]);
  if (artifact.version !== 1 || artifact.kind !== "responsive-viewport-artifact" ||
      artifact.sourceSha256 !== sourceSha256 || artifact.viewport !== viewport ||
      checks.pageLoaded !== true || checks.noHorizontalOverflow !== true) {
    throw new OnboardingError("verification_failed");
  }
}

export async function verifyOnboardingProject(input: {
  readonly projectDir: string;
  readonly report: OnboardingInspectionReport;
  readonly plan: OnboardingAttachmentPlan;
  readonly applyReceipt: OnboardingApplyReceipt;
  readonly evidence: OnboardingVerificationEvidence;
  readonly env: Record<string, string | undefined>;
}): Promise<OnboardingAggregateVerificationReport> {
  const report = parseOnboardingInspectionReport(input.report);
  const plan = parseOnboardingAttachmentPlan(input.plan);
  const applyReceipt = parseOnboardingApplyReceipt(input.applyReceipt);
  const evidence = parseOnboardingVerificationEvidence(input.evidence);
  if (plan.reviewId !== report.reviewId || plan.manifestSha256 !== report.manifestSha256 ||
      applyReceipt.planId !== plan.planId || evidence.reviewId !== report.reviewId ||
      evidence.planId !== plan.planId || evidence.applyReceiptId !== applyReceipt.receiptId) {
    throw new OnboardingError("verification_failed");
  }
  const sourceSha256 = verificationSourceSha256({ report, plan, applyReceipt });

  const statuses = new Map<OnboardingAggregateCheckId, "pass" | "fail">();
  const issues: Array<{ code: string; message: string; path?: string }> = [];
  const pass = (id: OnboardingAggregateCheckId) => statuses.set(id, "pass");
  const fail = (id: OnboardingAggregateCheckId, code: string, message: string, path?: string) => {
    statuses.set(id, "fail");
    issues.push({ code, message, ...(path ? { path } : {}) });
  };

  try {
    await verifyOnboardingApply({ projectDir: input.projectDir, receipt: applyReceipt });
    const sourceFiles = await ProjectFilesystem.open(input.projectDir);
    const patched = new Set(applyReceipt.files.map((file) => file.path));
    for (const route of report.routes) {
      if (patched.has(route.source)) continue;
      const source = await sourceFiles.read(route.source);
      if (fingerprintSource(source) !== route.sourceSha256) {
        fail("source_hashes", "SOURCE_HASH_MISMATCH", "Inspected source changed outside the approved patch.", route.source);
        break;
      }
    }
    if (!statuses.has("source_hashes")) pass("source_hashes");
  } catch {
    if (!statuses.has("source_hashes")) {
      fail("source_hashes", "SOURCE_HASH_MISMATCH", "Applied or inspected source no longer matches approved evidence.");
    }
  }

  let files: ProjectFilesystem | undefined;
  try {
    files = await ProjectFilesystem.open(input.projectDir);
    for (const route of report.routes) {
      const artifact = await files.read(route.renderedArtifact);
      if (fingerprintSource(artifact) !== route.artifactSha256) {
        fail("rendered_artifacts", "RENDERED_ARTIFACT_DRIFT", "Rendered inspection evidence changed after review.", route.renderedArtifact);
        break;
      }
    }
    if (!statuses.has("rendered_artifacts")) pass("rendered_artifacts");
  } catch {
    fail("rendered_artifacts", "RENDERED_ARTIFACT_UNAVAILABLE", "Rendered inspection evidence is unavailable.");
  }

  try {
    const site = await loadBuilderSiteConfig(input.projectDir);
    const candidates = new Map(report.candidates.map((candidate) => [candidate.id, candidate]));
    const renderedRegions = plan.mappings.map((mapping) => {
      const kinds = new Set(mapping.candidateIds.map((id) => candidates.get(id)?.kind).filter(Boolean));
      const kind = mapping.kind ?? (kinds.size === 1 ? [...kinds][0] : undefined);
      if (!kind) throw new OnboardingError("verification_failed");
      return { id: mapping.stableId, kind, source: candidates.get(mapping.candidateIds[0]!)?.source };
    });
    const result = runBuilderCheck({ site, env: input.env, renderedRegions });
    if (result.ok) pass("config_rendered_regions");
    else fail("config_rendered_regions", "BUILDER_CHECK_FAILED", result.issues.map((issue) => issue.message).join(" "));
  } catch {
    fail("config_rendered_regions", "BUILDER_CHECK_FAILED", "Builder config and rendered regions could not be verified.");
  }

  try {
    parseInstallationManifest(JSON.parse(await files!.read(".builder/installation-manifest.json")));
    pass("installation_manifest");
  } catch {
    fail("installation_manifest", "INSTALLATION_MANIFEST_INVALID", "The installation manifest is missing or invalid.");
  }
  try {
    parseModuleManifest(JSON.parse(await files!.read(".builder/module-manifest.json")));
    pass("module_manifest");
  } catch {
    fail("module_manifest", "MODULE_MANIFEST_INVALID", "The module manifest is missing or invalid.");
  }
  try {
    const compatibility = await runModuleAttachCheck({ projectDir: input.projectDir });
    if (compatibility.compatible) pass("package_compatibility");
    else fail("package_compatibility", "MODULE_INCOMPATIBLE", compatibility.issues.map((issue) => issue.instruction).join(" "));
  } catch {
    fail("package_compatibility", "MODULE_INCOMPATIBLE", "Package and schema compatibility could not be verified.");
  }
  try {
    const foundation = await runGrowthFoundationCheck({ projectDir: input.projectDir });
    if (foundation.ok) pass("protected_editor_and_growth_foundation");
    else fail("protected_editor_and_growth_foundation", "GROWTH_FOUNDATION_FAILED", foundation.issues.map((issue) => issue.message).join(" "));
  } catch {
    fail("protected_editor_and_growth_foundation", "GROWTH_FOUNDATION_FAILED", "The protected editor and growth foundation could not be verified.");
  }

  try {
    const receiptContents = await files!.read(evidence.productionBuild.path);
    if (fingerprintSource(receiptContents) !== evidence.productionBuild.sha256) {
      fail("production_build", "PRODUCTION_BUILD_RECEIPT_DRIFT", "Production build receipt changed.", evidence.productionBuild.path);
    } else {
      let artifactReference: VerificationArtifactReference;
      try {
        artifactReference = parseBuildReceipt(JSON.parse(receiptContents), sourceSha256);
      } catch {
        fail("production_build", "PRODUCTION_BUILD_INVALID", "Production build receipt is invalid.", evidence.productionBuild.path);
        artifactReference = { path: evidence.productionBuild.path, sha256: evidence.productionBuild.sha256 };
      }
      if (!statuses.has("production_build")) {
        const artifactContents = await files!.read(artifactReference.path);
        if (fingerprintSource(artifactContents) !== artifactReference.sha256) {
          fail("production_build", "PRODUCTION_BUILD_ARTIFACT_DRIFT", "Production build artifact changed.", artifactReference.path);
        } else {
          const outputs = parseBuildArtifact(JSON.parse(artifactContents), sourceSha256);
          const outputPaths = new Set(outputs.map((output) => output.path));
          if (report.routes.some((route) => !outputPaths.has(route.renderedArtifact))) {
            fail("production_build", "PRODUCTION_BUILD_ARTIFACT_INVALID", "Production build artifact omits a reviewed rendered output.", artifactReference.path);
          } else {
            for (const output of outputs) {
              if (fingerprintSource(await files!.read(output.path)) !== output.sha256) {
                fail("production_build", "PRODUCTION_BUILD_ARTIFACT_DRIFT", "Production build output changed.", output.path);
                break;
              }
            }
            if (!statuses.has("production_build")) pass("production_build");
          }
        }
      }
    }
  } catch {
    if (!statuses.has("production_build")) {
      fail("production_build", "PRODUCTION_BUILD_INVALID", "Production build evidence is unavailable or invalid.", evidence.productionBuild.path);
    }
  }

  try {
    const receiptContents = await files!.read(evidence.responsiveSmoke.path);
    if (fingerprintSource(receiptContents) !== evidence.responsiveSmoke.sha256) {
      fail("responsive_smoke", "RESPONSIVE_SMOKE_RECEIPT_DRIFT", "Responsive smoke receipt changed.", evidence.responsiveSmoke.path);
    } else {
      const results = parseResponsiveReceipt(JSON.parse(receiptContents), sourceSha256);
      for (const width of REQUIRED_VIEWPORTS) {
        if (!results.some((result) => result.viewport === width)) {
          fail("responsive_smoke", "RESPONSIVE_VIEWPORT_MISSING", `Responsive smoke evidence is missing the ${width}px viewport.`, evidence.responsiveSmoke.path);
        }
      }
      if (!statuses.has("responsive_smoke")) {
        for (const result of results) {
          const artifactContents = await files!.read(result.artifact.path);
          if (fingerprintSource(artifactContents) !== result.artifact.sha256) {
            fail("responsive_smoke", "RESPONSIVE_SMOKE_ARTIFACT_DRIFT", "Responsive smoke artifact changed.", result.artifact.path);
            break;
          }
          parseResponsiveArtifact(JSON.parse(artifactContents), sourceSha256, result.viewport);
        }
        if (!statuses.has("responsive_smoke")) pass("responsive_smoke");
      }
    }
  } catch {
    if (!statuses.has("responsive_smoke")) {
      fail("responsive_smoke", "RESPONSIVE_SMOKE_INVALID", "Responsive smoke evidence is unavailable or invalid.", evidence.responsiveSmoke.path);
    }
  }

  const checkIds: OnboardingAggregateCheckId[] = [
    "source_hashes",
    "rendered_artifacts",
    "config_rendered_regions",
    "installation_manifest",
    "module_manifest",
    "package_compatibility",
    "protected_editor_and_growth_foundation",
    "production_build",
    "responsive_smoke",
  ];
  const payload = {
    version: 1 as const,
    reviewId: report.reviewId,
    planId: plan.planId,
    applyReceiptId: applyReceipt.receiptId,
    checks: checkIds.map((id) => ({ id, status: statuses.get(id) ?? "fail" as const })),
    issues,
    ok: issues.length === 0,
    safety: { clientSourceMutated: false as const, remoteSystemsMutated: false as const },
  };
  return { ...payload, verificationId: fingerprintSource(canonicalOnboardingValue(payload)) };
}
