import { isAbsolute } from "node:path";

const FRAMEWORKS = ["next-app-router", "next-pages-router", "react-vite", "other"] as const;
const ROOT_KEYS = ["version", "site", "routes", "modules"] as const;
const SITE_KEYS = ["siteId", "stableSiteKey", "framework", "editorPath", "publicUrl"] as const;
const ROUTE_KEYS = ["path", "pageSlug", "source", "renderedArtifact"] as const;
const MODULE_KEYS = ["id", "version"] as const;
const KEY = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const PAGE_SLUG = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const MODULE_ID = /^[a-z][a-z0-9]*(?:\.[a-z][a-z0-9-]*)+$/;
const VERSION = /^\d+\.\d+\.\d+$/;

export class OnboardingError extends Error {
  constructor(readonly code:
    | "invalid_manifest"
    | "invalid_approval"
    | "unsafe_project_path"
    | "artifact_unavailable"
    | "output_conflict"
    | "stale_review"
    | "incomplete_approval"
    | "duplicate_decision"
    | "unknown_candidate"
    | "kind_conflict"
    | "invalid_patch"
    | "source_drift"
    | "stale_patch"
    | "verification_failed") {
    super(code);
    this.name = "OnboardingError";
  }
}

export interface OnboardingManifest {
  readonly version: 1;
  readonly site: {
    readonly siteId: string;
    readonly stableSiteKey: string;
    readonly framework: typeof FRAMEWORKS[number];
    readonly editorPath: string;
    readonly publicUrl?: string;
  };
  readonly routes: readonly {
    readonly path: string;
    readonly pageSlug: string;
    readonly source: string;
    readonly renderedArtifact: string;
  }[];
  readonly modules: readonly {
    readonly id: string;
    readonly version: string;
  }[];
}

function object(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new OnboardingError("invalid_manifest");
  return value as Record<string, unknown>;
}

function exactKeys(value: Record<string, unknown>, allowed: readonly string[], required: readonly string[] = allowed): void {
  if (Object.keys(value).some((key) => !allowed.includes(key)) || required.some((key) => !(key in value))) {
    throw new OnboardingError("invalid_manifest");
  }
}

function text(value: unknown, pattern?: RegExp): string {
  if (typeof value !== "string" || !value || value.length > 255 || (pattern && !pattern.test(value))) {
    throw new OnboardingError("invalid_manifest");
  }
  return value;
}

function routePath(value: unknown): string {
  const path = text(value);
  if (!path.startsWith("/") || path.includes("?") || path.includes("#") || path.includes("//") || path.includes("\\")) {
    throw new OnboardingError("invalid_manifest");
  }
  return path;
}

function relativeProjectPath(value: unknown): string {
  const path = text(value);
  if (isAbsolute(path) || path.includes("\\") || path.split("/").some((segment) => !segment || segment === "." || segment === "..")) {
    throw new OnboardingError("unsafe_project_path");
  }
  return path;
}

function publicUrl(value: unknown): string {
  const raw = text(value);
  let parsed: URL;
  try {
    parsed = new URL(raw);
  } catch {
    throw new OnboardingError("invalid_manifest");
  }
  if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.search || parsed.hash) {
    throw new OnboardingError("invalid_manifest");
  }
  return parsed.toString().replace(/\/$/, "");
}

export function parseOnboardingManifest(value: unknown): OnboardingManifest {
  const root = object(value);
  exactKeys(root, ROOT_KEYS);
  if (root.version !== 1) throw new OnboardingError("invalid_manifest");

  const rawSite = object(root.site);
  exactKeys(rawSite, SITE_KEYS, ["siteId", "stableSiteKey", "framework", "editorPath"]);
  const framework = text(rawSite.framework);
  if (!FRAMEWORKS.includes(framework as typeof FRAMEWORKS[number])) throw new OnboardingError("invalid_manifest");
  const site = {
    siteId: text(rawSite.siteId, KEY),
    stableSiteKey: text(rawSite.stableSiteKey, KEY),
    framework: framework as typeof FRAMEWORKS[number],
    editorPath: routePath(rawSite.editorPath),
    ...(rawSite.publicUrl === undefined ? {} : { publicUrl: publicUrl(rawSite.publicUrl) }),
  };

  if (!Array.isArray(root.routes) || root.routes.length === 0 || root.routes.length > 100) {
    throw new OnboardingError("invalid_manifest");
  }
  const routes = root.routes.map((value) => {
    const route = object(value);
    exactKeys(route, ROUTE_KEYS);
    return {
      path: routePath(route.path),
      pageSlug: text(route.pageSlug, PAGE_SLUG),
      source: relativeProjectPath(route.source),
      renderedArtifact: relativeProjectPath(route.renderedArtifact),
    };
  });
  for (const values of [routes.map((route) => route.path), routes.map((route) => route.pageSlug), routes.map((route) => route.renderedArtifact)]) {
    if (new Set(values).size !== values.length) throw new OnboardingError("invalid_manifest");
  }

  if (!Array.isArray(root.modules) || root.modules.length === 0 || root.modules.length > 25) {
    throw new OnboardingError("invalid_manifest");
  }
  const modules = root.modules.map((value) => {
    const module = object(value);
    exactKeys(module, MODULE_KEYS);
    return { id: text(module.id, MODULE_ID), version: text(module.version, VERSION) };
  });
  if (new Set(modules.map((module) => module.id)).size !== modules.length) throw new OnboardingError("invalid_manifest");

  return { version: 1, site, routes, modules };
}
