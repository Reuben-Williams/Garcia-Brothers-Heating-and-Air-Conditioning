import { fingerprintSource } from "../scan/source-fingerprint.js";
import { applySourcePatch, recoverInterruptedApply } from "../migration/apply-source.js";
import { ProjectFilesystem, UnsafeProjectPathError } from "../control-plane/project-filesystem.js";
import { OnboardingError } from "./contracts.js";
import { canonicalOnboardingValue } from "./inspect.js";
import type { ApplyJournal } from "../migration/apply-journal.js";

const DIGEST = /^[a-f0-9]{64}$/;
const MAX_FILES = 200;
const MAX_FILE_BYTES = 2 * 1024 * 1024;
const MAX_PATCH_BYTES = 10 * 1024 * 1024;
const PROTECTED_ROOTS = new Set([".git", ".next", "node_modules", "out", "sales-package", "site-editor-platform"]);

export interface OnboardingSourcePatchFile {
  readonly path: string;
  readonly expectedCurrentHash: string | null;
  readonly contents: string;
}

export interface OnboardingSourcePatch {
  readonly version: 1;
  readonly patchId: string;
  readonly planId: string;
  readonly files: readonly OnboardingSourcePatchFile[];
}

export interface OnboardingApplyReceipt {
  readonly version: 1;
  readonly receiptId: string;
  readonly planId: string;
  readonly patchId: string;
  readonly journalPath: string;
  readonly reversalPath: string;
  readonly files: readonly {
    readonly path: string;
    readonly beforeHash: string | null;
    readonly afterHash: string;
  }[];
  readonly safety: {
    readonly clientSourceMutated: true;
    readonly remoteSystemsMutated: false;
  };
}

function record(value: unknown, code: "invalid_patch" | "verification_failed"): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new OnboardingError(code);
  return value as Record<string, unknown>;
}

function exact(value: Record<string, unknown>, allowed: readonly string[], code: "invalid_patch" | "verification_failed"): void {
  if (Object.keys(value).some((key) => !allowed.includes(key)) || allowed.some((key) => !(key in value))) {
    throw new OnboardingError(code);
  }
}

function exactWithOptional(
  value: Record<string, unknown>,
  required: readonly string[],
  optional: readonly string[],
): void {
  const allowed = [...required, ...optional];
  if (Object.keys(value).some((key) => !allowed.includes(key)) || required.some((key) => !(key in value))) {
    throw new OnboardingError("verification_failed");
  }
}

function isoTimestamp(value: unknown): string {
  if (typeof value !== "string") throw new OnboardingError("verification_failed");
  try {
    if (new Date(value).toISOString() !== value) throw new OnboardingError("verification_failed");
  } catch {
    throw new OnboardingError("verification_failed");
  }
  return value;
}

function recoveryPath(value: unknown): string {
  try {
    return safePatchPath(value);
  } catch {
    throw new OnboardingError("verification_failed");
  }
}

type BoundApplyJournal = ApplyJournal & { planId: string; patchId: string };

function parseRecoveryJournal(input: {
  value: unknown;
  planId: string;
  patch: OnboardingSourcePatch;
  approvedBefore: readonly { path: string; before: string | null }[];
}): BoundApplyJournal {
  const journal = record(input.value, "verification_failed");
  exactWithOptional(
    journal,
    ["version", "status", "createdAt", "planId", "patchId", "files"],
    ["completedAt"],
  );
  if (journal.version !== 1 ||
      !["pending", "complete", "failed", "reversed"].includes(String(journal.status)) ||
      journal.planId !== input.planId || journal.patchId !== input.patch.patchId ||
      !Array.isArray(journal.files) || journal.files.length !== input.patch.files.length) {
    throw new OnboardingError("verification_failed");
  }
  const createdAt = isoTimestamp(journal.createdAt);
  const terminal = journal.status === "complete" || journal.status === "reversed";
  if (terminal !== ("completedAt" in journal)) throw new OnboardingError("verification_failed");
  const completedAt = terminal ? isoTimestamp(journal.completedAt) : undefined;
  const files = journal.files.map((value, index) => {
    const entry = record(value, "verification_failed");
    exact(entry, ["path", "before", "afterHash"], "verification_failed");
    const patchFile = input.patch.files[index]!;
    const approved = input.approvedBefore[index]!;
    const path = recoveryPath(entry.path);
    if (path !== patchFile.path || path !== approved.path ||
        (entry.before !== null && typeof entry.before !== "string") || entry.before !== approved.before ||
        typeof entry.afterHash !== "string" || !DIGEST.test(entry.afterHash) ||
        entry.afterHash !== fingerprintSource(patchFile.contents)) {
      throw new OnboardingError("verification_failed");
    }
    return { path, before: entry.before as string | null, afterHash: entry.afterHash };
  });
  return {
    version: 1,
    status: journal.status as ApplyJournal["status"],
    createdAt,
    planId: input.planId,
    patchId: input.patch.patchId,
    files,
    ...(completedAt ? { completedAt } : {}),
  };
}

function safePatchPath(value: unknown): string {
  if (typeof value !== "string" || !value || value.length > 300 || value.includes("\\")) {
    throw new OnboardingError("unsafe_project_path");
  }
  const segments = value.split("/");
  if (segments.some((segment) => !segment || segment === "." || segment === "..")) {
    throw new OnboardingError("unsafe_project_path");
  }
  const first = segments[0]!.toLowerCase();
  const normalized = segments.map((segment) => segment.toLowerCase()).join("/");
  if (
    value.startsWith("/") ||
    /^[a-z]:/i.test(value) ||
    PROTECTED_ROOTS.has(first) ||
    first === ".env" || (first.startsWith(".env.") && first !== ".env.example") ||
    normalized === ".builder/onboarding" || normalized.startsWith(".builder/onboarding/") ||
    normalized === ".builder/secrets" || normalized.startsWith(".builder/secrets/")
  ) {
    throw new OnboardingError("unsafe_project_path");
  }
  return value;
}

export function parseOnboardingSourcePatch(value: unknown): OnboardingSourcePatch {
  const root = record(value, "invalid_patch");
  exact(root, ["version", "patchId", "planId", "files"], "invalid_patch");
  if (root.version !== 1 || typeof root.patchId !== "string" || !DIGEST.test(root.patchId) ||
      typeof root.planId !== "string" || !DIGEST.test(root.planId) ||
      !Array.isArray(root.files) || root.files.length === 0 || root.files.length > MAX_FILES) {
    throw new OnboardingError("invalid_patch");
  }
  let totalBytes = 0;
  const files = root.files.map((value) => {
    const file = record(value, "invalid_patch");
    exact(file, ["path", "expectedCurrentHash", "contents"], "invalid_patch");
    const path = safePatchPath(file.path);
    if (file.expectedCurrentHash !== null && (typeof file.expectedCurrentHash !== "string" || !DIGEST.test(file.expectedCurrentHash))) {
      throw new OnboardingError("invalid_patch");
    }
    if (typeof file.contents !== "string" || Buffer.byteLength(file.contents, "utf8") > MAX_FILE_BYTES) {
      throw new OnboardingError("invalid_patch");
    }
    totalBytes += Buffer.byteLength(file.contents, "utf8");
    return { path, expectedCurrentHash: file.expectedCurrentHash as string | null, contents: file.contents };
  });
  if (totalBytes > MAX_PATCH_BYTES || new Set(files.map((file) => file.path.toLowerCase())).size !== files.length) {
    throw new OnboardingError("invalid_patch");
  }
  const payload = { version: 1 as const, planId: root.planId, files };
  if (fingerprintSource(canonicalOnboardingValue(payload)) !== root.patchId) throw new OnboardingError("invalid_patch");
  return { ...payload, patchId: root.patchId };
}

export function parseOnboardingApplyReceipt(value: unknown): OnboardingApplyReceipt {
  const root = record(value, "verification_failed");
  exact(root, ["version", "receiptId", "planId", "patchId", "journalPath", "reversalPath", "files", "safety"], "verification_failed");
  if (root.version !== 1 || typeof root.receiptId !== "string" || !DIGEST.test(root.receiptId) ||
      typeof root.planId !== "string" || !DIGEST.test(root.planId) ||
      typeof root.patchId !== "string" || !DIGEST.test(root.patchId) ||
      typeof root.journalPath !== "string" || typeof root.reversalPath !== "string" || !Array.isArray(root.files)) {
    throw new OnboardingError("verification_failed");
  }
  const safety = record(root.safety, "verification_failed");
  exact(safety, ["clientSourceMutated", "remoteSystemsMutated"], "verification_failed");
  if (safety.clientSourceMutated !== true || safety.remoteSystemsMutated !== false) throw new OnboardingError("verification_failed");
  const files = root.files.map((value) => {
    const file = record(value, "verification_failed");
    exact(file, ["path", "beforeHash", "afterHash"], "verification_failed");
    if (typeof file.path !== "string" || (file.beforeHash !== null && (typeof file.beforeHash !== "string" || !DIGEST.test(file.beforeHash))) ||
        typeof file.afterHash !== "string" || !DIGEST.test(file.afterHash)) throw new OnboardingError("verification_failed");
    return { path: file.path, beforeHash: file.beforeHash as string | null, afterHash: file.afterHash };
  });
  const payload = {
    version: 1 as const,
    planId: root.planId,
    patchId: root.patchId,
    journalPath: root.journalPath,
    reversalPath: root.reversalPath,
    files,
    safety: { clientSourceMutated: true as const, remoteSystemsMutated: false as const },
  };
  if (fingerprintSource(canonicalOnboardingValue(payload)) !== root.receiptId) throw new OnboardingError("verification_failed");
  return { ...payload, receiptId: root.receiptId };
}

export async function applyOnboardingSourcePatch(input: {
  readonly projectDir: string;
  readonly planId: string;
  readonly patch: OnboardingSourcePatch;
}): Promise<OnboardingApplyReceipt> {
  if (input.patch.planId !== input.planId) throw new OnboardingError("stale_patch");
  let files: ProjectFilesystem;
  try {
    files = await ProjectFilesystem.open(input.projectDir);
  } catch (error) {
    if (error instanceof UnsafeProjectPathError) throw new OnboardingError("unsafe_project_path");
    throw error;
  }
  const snapshots: Array<{ path: string; before: string | null; beforeHash: string | null; afterHash: string }> = [];
  try {
    await files.ensureDirectory(".builder/onboarding");
    const reversalPath = `.builder/onboarding/reversal-${input.patch.patchId}.json`;
    const journalPath = `.builder/onboarding/apply-${input.patch.patchId}.json`;
    const existingReversalText = await files.readOptional(reversalPath);
    let approvedBefore: Array<{ path: string; before: string | null }> | undefined;
    if (existingReversalText !== null) {
      try {
        const reversal = record(JSON.parse(existingReversalText), "verification_failed");
        exact(reversal, ["version", "planId", "patchId", "files"], "verification_failed");
        if (reversal.version !== 1 || reversal.planId !== input.planId || reversal.patchId !== input.patch.patchId ||
            !Array.isArray(reversal.files) || reversal.files.length !== input.patch.files.length) {
          throw new OnboardingError("verification_failed");
        }
        approvedBefore = reversal.files.map((value, index) => {
          const entry = record(value, "verification_failed");
          exact(entry, ["path", "restoreContents"], "verification_failed");
          const patchFile = input.patch.files[index]!;
          if (recoveryPath(entry.path) !== patchFile.path ||
              (entry.restoreContents !== null && typeof entry.restoreContents !== "string")) {
            throw new OnboardingError("verification_failed");
          }
          const before = entry.restoreContents as string | null;
          const beforeHash = before === null ? null : fingerprintSource(before);
          if (beforeHash !== patchFile.expectedCurrentHash) throw new OnboardingError("verification_failed");
          return { path: patchFile.path, before };
        });
      } catch (error) {
        if (error instanceof OnboardingError) throw error;
        throw new OnboardingError("verification_failed");
      }

      const journalText = await files.readOptional(journalPath);
      if (journalText !== null) {
        let journal: BoundApplyJournal;
        try {
          journal = parseRecoveryJournal({
            value: JSON.parse(journalText),
            planId: input.planId,
            patch: input.patch,
            approvedBefore,
          });
        } catch {
          throw new OnboardingError("verification_failed");
        }
        if (journal.status === "complete") {
          for (const patchFile of input.patch.files) {
            const current = await files.readOptional(patchFile.path);
            if (current === null || fingerprintSource(current) !== fingerprintSource(patchFile.contents)) {
              throw new OnboardingError("verification_failed");
            }
          }
          const payload = {
            version: 1 as const,
            planId: input.planId,
            patchId: input.patch.patchId,
            journalPath,
            reversalPath,
            files: input.patch.files.map((patchFile, index) => ({
              path: patchFile.path,
              beforeHash: input.patch.files[index]!.expectedCurrentHash,
              afterHash: fingerprintSource(patchFile.contents),
            })),
            safety: { clientSourceMutated: true as const, remoteSystemsMutated: false as const },
          };
          return { ...payload, receiptId: fingerprintSource(canonicalOnboardingValue(payload)) };
        }
        if (journal.status === "pending" || journal.status === "failed") {
          await recoverInterruptedApply(input.projectDir, journalPath, { validatedJournal: journal });
        } else if (journal.status !== "reversed") {
          throw new OnboardingError("verification_failed");
        }
      }
    }

    for (const patchFile of input.patch.files) {
      const before = await files.readOptional(patchFile.path);
      const beforeHash = before === null ? null : fingerprintSource(before);
      if (beforeHash !== patchFile.expectedCurrentHash) throw new OnboardingError("source_drift");
      snapshots.push({ path: patchFile.path, before, beforeHash, afterHash: fingerprintSource(patchFile.contents) });
    }
    const reversal = {
      version: 1 as const,
      planId: input.planId,
      patchId: input.patch.patchId,
      files: snapshots.map((snapshot) => ({ path: snapshot.path, restoreContents: snapshot.before })),
    };
    if (!approvedBefore) await files.writeExclusive(reversalPath, `${JSON.stringify(reversal, null, 2)}\n`);
    try {
      await applySourcePatch({
        root: input.projectDir,
        journalPath,
        files: [...input.patch.files],
        journalBinding: { planId: input.planId, patchId: input.patch.patchId },
      });
    } catch (error) {
      if (/drift/i.test((error as Error).message)) throw new OnboardingError("source_drift");
      throw error;
    }
    const payload = {
      version: 1 as const,
      planId: input.planId,
      patchId: input.patch.patchId,
      journalPath,
      reversalPath,
      files: snapshots.map(({ path, beforeHash, afterHash }) => ({ path, beforeHash, afterHash })),
      safety: { clientSourceMutated: true as const, remoteSystemsMutated: false as const },
    };
    return { ...payload, receiptId: fingerprintSource(canonicalOnboardingValue(payload)) };
  } catch (error) {
    if (error instanceof UnsafeProjectPathError) throw new OnboardingError("unsafe_project_path");
    throw error;
  }
}

export async function verifyOnboardingApply(input: {
  readonly projectDir: string;
  readonly receipt: OnboardingApplyReceipt;
}): Promise<{ ok: true; checkedFiles: number; planId: string; patchId: string }> {
  const receipt = parseOnboardingApplyReceipt(input.receipt);
  try {
    const files = await ProjectFilesystem.open(input.projectDir);
    const journal = JSON.parse(await files.read(receipt.journalPath)) as { status?: unknown };
    if (journal.status !== "complete" || !(await files.exists(receipt.reversalPath))) throw new OnboardingError("verification_failed");
    for (const file of receipt.files) {
      const contents = await files.readOptional(file.path);
      if (contents === null || fingerprintSource(contents) !== file.afterHash) throw new OnboardingError("verification_failed");
    }
  } catch (error) {
    if (error instanceof OnboardingError) throw error;
    throw new OnboardingError("verification_failed");
  }
  return { ok: true, checkedFiles: receipt.files.length, planId: receipt.planId, patchId: receipt.patchId };
}
