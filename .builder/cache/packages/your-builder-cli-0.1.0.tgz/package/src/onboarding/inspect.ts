import type { ValidationIssue } from "@your-builder/core";

import { ProjectFilesystem, UnsafeProjectPathError } from "../control-plane/project-filesystem.js";
import {
  classifyScanCandidates,
  scanEditableRegionsFromHtml,
  type BuilderScanCandidate,
} from "../index.js";
import { fingerprintSource } from "../scan/source-fingerprint.js";
import { OnboardingError, type OnboardingManifest } from "./contracts.js";

export interface OnboardingInspectionRoute {
  readonly path: string;
  readonly pageSlug: string;
  readonly source: string;
  readonly renderedArtifact: string;
  readonly sourceSha256: string;
  readonly artifactSha256: string;
  readonly candidateIds: readonly string[];
  readonly warnings: readonly ValidationIssue[];
}

export interface OnboardingInspectionReport {
  readonly version: 1;
  readonly reviewId: string;
  readonly manifestSha256: string;
  readonly site: OnboardingManifest["site"];
  readonly modules: OnboardingManifest["modules"];
  readonly routes: readonly OnboardingInspectionRoute[];
  readonly candidates: readonly BuilderScanCandidate[];
  readonly warnings: readonly ValidationIssue[];
  readonly safety: {
    readonly clientSourceMutated: false;
    readonly remoteSystemsMutated: false;
  };
}

export function canonicalOnboardingValue(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalOnboardingValue).join(",")}]`;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${canonicalOnboardingValue(record[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function uniqueCandidateIds(
  values: readonly BuilderScanCandidate[],
  seen: Set<string>,
): BuilderScanCandidate[] {
  return values.map((candidate) => {
    let id = candidate.id;
    let suffix = 2;
    while (seen.has(id)) id = `${candidate.id}-${suffix++}`;
    seen.add(id);
    return id === candidate.id ? candidate : { ...candidate, id };
  });
}

export async function inspectOnboardingProject(input: {
  readonly projectDir: string;
  readonly manifest: OnboardingManifest;
}): Promise<OnboardingInspectionReport> {
  let files: ProjectFilesystem;
  try {
    files = await ProjectFilesystem.open(input.projectDir);
  } catch (error) {
    if (error instanceof UnsafeProjectPathError) throw new OnboardingError("unsafe_project_path");
    throw error;
  }

  const candidates: BuilderScanCandidate[] = [];
  const candidateIds = new Set<string>();
  const warnings: ValidationIssue[] = [];
  const routes: OnboardingInspectionRoute[] = [];
  try {
    for (const route of input.manifest.routes) {
      const [source, html] = await Promise.all([
        files.read(route.source),
        files.read(route.renderedArtifact),
      ]);
      const scan = scanEditableRegionsFromHtml({ html, pageSlug: route.pageSlug, source: route.source });
      const routeCandidates = uniqueCandidateIds(classifyScanCandidates(scan), candidateIds);
      candidates.push(...routeCandidates);
      warnings.push(...scan.warnings);
      routes.push({
        ...route,
        sourceSha256: fingerprintSource(source),
        artifactSha256: fingerprintSource(html),
        candidateIds: routeCandidates.map((candidate) => candidate.id),
        warnings: scan.warnings,
      });
    }
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") throw new OnboardingError("artifact_unavailable");
    if (error instanceof UnsafeProjectPathError) throw new OnboardingError("unsafe_project_path");
    throw error;
  }

  const manifestSha256 = fingerprintSource(canonicalOnboardingValue(input.manifest));
  const payload = {
    version: 1 as const,
    manifestSha256,
    site: input.manifest.site,
    modules: input.manifest.modules,
    routes,
    candidates,
    warnings,
    safety: { clientSourceMutated: false as const, remoteSystemsMutated: false as const },
  };
  return { ...payload, reviewId: fingerprintSource(canonicalOnboardingValue(payload)) };
}

export function parseOnboardingInspectionReport(value: unknown): OnboardingInspectionReport {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new OnboardingError("stale_review");
  const report = value as Record<string, unknown>;
  const keys = ["version", "reviewId", "manifestSha256", "site", "modules", "routes", "candidates", "warnings", "safety"];
  if (Object.keys(report).some((key) => !keys.includes(key)) || keys.some((key) => !(key in report))) {
    throw new OnboardingError("stale_review");
  }
  if (report.version !== 1 || typeof report.reviewId !== "string" || !/^[a-f0-9]{64}$/.test(report.reviewId)) {
    throw new OnboardingError("stale_review");
  }
  if (!Array.isArray(report.candidates) || report.candidates.some((candidate) =>
    !candidate || typeof candidate !== "object" || typeof (candidate as { id?: unknown }).id !== "string")) {
    throw new OnboardingError("stale_review");
  }
  const ids = report.candidates.map((candidate) => (candidate as { id: string }).id);
  if (new Set(ids).size !== ids.length) throw new OnboardingError("stale_review");
  const safety = report.safety as { clientSourceMutated?: unknown; remoteSystemsMutated?: unknown } | undefined;
  if (!safety || safety.clientSourceMutated !== false || safety.remoteSystemsMutated !== false) {
    throw new OnboardingError("stale_review");
  }
  const { reviewId, ...payload } = report;
  if (fingerprintSource(canonicalOnboardingValue(payload)) !== reviewId) throw new OnboardingError("stale_review");
  return value as OnboardingInspectionReport;
}
