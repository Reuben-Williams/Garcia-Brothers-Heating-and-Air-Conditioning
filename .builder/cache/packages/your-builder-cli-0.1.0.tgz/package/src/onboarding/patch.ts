import { execFile } from "node:child_process";
import { promisify } from "node:util";

import { ProjectFilesystem, UnsafeProjectPathError } from "../control-plane/project-filesystem.js";
import { fingerprintSource } from "../scan/source-fingerprint.js";
import { parseOnboardingSourcePatch, type OnboardingSourcePatch } from "./apply.js";
import { OnboardingError } from "./contracts.js";
import { canonicalOnboardingValue } from "./inspect.js";

const execFileAsync = promisify(execFile);
const DIGEST = /^[a-f0-9]{64}$/;

async function git(directory: string, args: readonly string[]): Promise<string> {
  try {
    const result = await execFileAsync("git", ["-C", directory, ...args], {
      encoding: "utf8",
      maxBuffer: 12 * 1024 * 1024,
      windowsHide: true,
    });
    return String(result.stdout);
  } catch {
    throw new OnboardingError("invalid_patch");
  }
}

function nulPaths(value: string): string[] {
  return value.split("\0").filter(Boolean);
}

export async function generateOnboardingSourcePatch(input: {
  readonly projectDir: string;
  readonly reviewDir: string;
  readonly planId: string;
}): Promise<OnboardingSourcePatch> {
  if (!DIGEST.test(input.planId) || input.projectDir === input.reviewDir) {
    throw new OnboardingError("invalid_patch");
  }

  const [projectHead, reviewHead] = await Promise.all([
    git(input.projectDir, ["rev-parse", "HEAD"]),
    git(input.reviewDir, ["rev-parse", "HEAD"]),
  ]);
  if (projectHead.trim() !== reviewHead.trim()) throw new OnboardingError("source_drift");

  const [changedText, untrackedText, deletedText, trackedText] = await Promise.all([
    git(input.reviewDir, ["diff", "--no-renames", "--name-only", "--diff-filter=AM", "-z", "HEAD", "--"]),
    git(input.reviewDir, ["ls-files", "--others", "--exclude-standard", "-z"]),
    git(input.reviewDir, ["diff", "--no-renames", "--name-only", "--diff-filter=D", "-z", "HEAD", "--"]),
    git(input.reviewDir, ["ls-tree", "-r", "--name-only", "-z", "HEAD"]),
  ]);
  if (nulPaths(deletedText).length > 0) throw new OnboardingError("invalid_patch");

  const paths = [...new Set([...nulPaths(changedText), ...nulPaths(untrackedText)])]
    .sort((left, right) => left.localeCompare(right));
  if (paths.length === 0) throw new OnboardingError("invalid_patch");
  const tracked = new Set(nulPaths(trackedText));

  let projectFiles: ProjectFilesystem;
  let reviewFiles: ProjectFilesystem;
  try {
    [projectFiles, reviewFiles] = await Promise.all([
      ProjectFilesystem.open(input.projectDir),
      ProjectFilesystem.open(input.reviewDir),
    ]);
  } catch (error) {
    if (error instanceof UnsafeProjectPathError) throw new OnboardingError("unsafe_project_path");
    throw error;
  }

  const files: Array<{ path: string; expectedCurrentHash: string | null; contents: string }> = [];
  try {
    for (const path of paths) {
      const contents = await reviewFiles.read(path);
      if (contents.includes("\0")) throw new OnboardingError("invalid_patch");
      if (!tracked.has(path)) {
        if (await projectFiles.readOptional(path) !== null) throw new OnboardingError("source_drift");
        files.push({ path, expectedCurrentHash: null, contents });
        continue;
      }

      const baseContents = await git(input.reviewDir, ["show", `HEAD:${path}`]);
      const currentContents = await projectFiles.readOptional(path);
      if (currentContents === null || fingerprintSource(currentContents) !== fingerprintSource(baseContents)) {
        throw new OnboardingError("source_drift");
      }
      files.push({ path, expectedCurrentHash: fingerprintSource(baseContents), contents });
    }
  } catch (error) {
    if (error instanceof UnsafeProjectPathError) throw new OnboardingError("unsafe_project_path");
    throw error;
  }

  const payload = { version: 1 as const, planId: input.planId, files };
  return parseOnboardingSourcePatch({
    ...payload,
    patchId: fingerprintSource(canonicalOnboardingValue(payload)),
  });
}
