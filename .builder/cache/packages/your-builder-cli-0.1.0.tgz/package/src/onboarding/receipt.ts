import { fingerprintSource } from "../scan/source-fingerprint.js";
import { OnboardingError } from "./contracts.js";
import { canonicalOnboardingValue } from "./inspect.js";

const DIGEST = /^[a-f0-9]{64}$/;
const INPUT_ID = /^[a-z][A-Za-z0-9]*$/;
const STAGES = ["inspect", "plan", "patch", "apply", "verify"] as const;

export type OnboardingStage = typeof STAGES[number];

export interface OnboardingStageReceipt {
  readonly version: 1;
  readonly receiptId: string;
  readonly stage: OnboardingStage;
  readonly inputIds: Readonly<Record<string, string>>;
  readonly outputId: string;
  readonly safety: {
    readonly clientSourceMutated: boolean;
    readonly remoteSystemsMutated: false;
  };
}

function fail(): never {
  throw new OnboardingError("verification_failed");
}

function normalizedInputIds(value: unknown): Record<string, string> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return fail();
  const entries = Object.entries(value as Record<string, unknown>);
  if (entries.length === 0 || entries.length > 16) return fail();
  const normalized: Record<string, string> = {};
  for (const [key, id] of entries.sort(([left], [right]) => left.localeCompare(right))) {
    if (!INPUT_ID.test(key) || /token|private|secret/i.test(key) || typeof id !== "string" || !DIGEST.test(id)) {
      return fail();
    }
    normalized[key] = id;
  }
  return normalized;
}

export function createOnboardingStageReceipt(input: {
  readonly stage: OnboardingStage;
  readonly inputIds: Readonly<Record<string, string>>;
  readonly outputId: string;
}): OnboardingStageReceipt {
  if (!STAGES.includes(input.stage) || !DIGEST.test(input.outputId)) return fail();
  const payload = {
    version: 1 as const,
    stage: input.stage,
    inputIds: normalizedInputIds(input.inputIds),
    outputId: input.outputId,
    safety: {
      clientSourceMutated: input.stage === "apply",
      remoteSystemsMutated: false as const,
    },
  };
  return { ...payload, receiptId: fingerprintSource(canonicalOnboardingValue(payload)) };
}

export function parseOnboardingStageReceipt(value: unknown): OnboardingStageReceipt {
  if (!value || typeof value !== "object" || Array.isArray(value)) return fail();
  const root = value as Record<string, unknown>;
  const keys = ["version", "receiptId", "stage", "inputIds", "outputId", "safety"];
  if (Object.keys(root).some((key) => !keys.includes(key)) || keys.some((key) => !(key in root)) ||
      root.version !== 1 || typeof root.receiptId !== "string" || !DIGEST.test(root.receiptId) ||
      typeof root.stage !== "string" || !STAGES.includes(root.stage as OnboardingStage) ||
      typeof root.outputId !== "string" || !DIGEST.test(root.outputId) ||
      !root.safety || typeof root.safety !== "object" || Array.isArray(root.safety)) return fail();
  const safety = root.safety as Record<string, unknown>;
  if (Object.keys(safety).sort().join(",") !== "clientSourceMutated,remoteSystemsMutated" ||
      safety.clientSourceMutated !== (root.stage === "apply") || safety.remoteSystemsMutated !== false) return fail();
  const receipt = createOnboardingStageReceipt({
    stage: root.stage as OnboardingStage,
    inputIds: normalizedInputIds(root.inputIds),
    outputId: root.outputId,
  });
  if (receipt.receiptId !== root.receiptId) return fail();
  return receipt;
}
