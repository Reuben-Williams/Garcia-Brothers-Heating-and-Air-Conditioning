import type { BuilderScanCategory } from "../index.js";
import { fingerprintSource } from "../scan/source-fingerprint.js";
import { OnboardingError } from "./contracts.js";
import { canonicalOnboardingValue, type OnboardingInspectionReport } from "./inspect.js";

const CATEGORIES: readonly BuilderScanCategory[] = [
  "editableRegion",
  "repeatedCollection",
  "globalContent",
  "navigation",
  "form",
  "mediaAsset",
  "seoMetadata",
  "decorativeContent",
  "manualReview",
];
const KINDS = ["text", "richText", "image", "link", "icon", "sections"] as const;
const REASONS = ["decorative", "duplicate-rendering", "managed-collection", "managed-global", "out-of-scope"] as const;
const STABLE_ID = /^[a-z0-9]+(?:[.-][a-z0-9]+)*$/;
const DIGEST = /^[a-f0-9]{64}$/;

export interface OnboardingApproval {
  readonly version: 1;
  readonly reviewId: string;
  readonly mappings: readonly {
    readonly stableId: string;
    readonly category: BuilderScanCategory;
    readonly kind?: typeof KINDS[number];
    readonly candidateIds: readonly string[];
  }[];
  readonly exclusions: readonly {
    readonly reason: typeof REASONS[number];
    readonly candidateIds: readonly string[];
  }[];
}

export interface OnboardingAttachmentPlan {
  readonly version: 1;
  readonly planId: string;
  readonly reviewId: string;
  readonly manifestSha256: string;
  readonly mappings: OnboardingApproval["mappings"];
  readonly exclusions: OnboardingApproval["exclusions"];
  readonly generatedFiles: readonly string[];
  readonly patchSummary: readonly string[];
  readonly safety: {
    readonly clientSourceMutated: false;
    readonly remoteSystemsMutated: false;
  };
}

export function parseOnboardingAttachmentPlan(value: unknown): OnboardingAttachmentPlan {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new OnboardingError("stale_review");
  const root = value as Record<string, unknown>;
  const keys = ["version", "planId", "reviewId", "manifestSha256", "mappings", "exclusions", "generatedFiles", "patchSummary", "safety"];
  if (Object.keys(root).some((key) => !keys.includes(key)) || keys.some((key) => !(key in root)) ||
      root.version !== 1 || typeof root.planId !== "string" || !DIGEST.test(root.planId) ||
      typeof root.reviewId !== "string" || !DIGEST.test(root.reviewId) ||
      typeof root.manifestSha256 !== "string" || !DIGEST.test(root.manifestSha256) ||
      !Array.isArray(root.generatedFiles) || root.generatedFiles.some((path) => typeof path !== "string" || !path) ||
      !Array.isArray(root.patchSummary) || root.patchSummary.some((summary) => typeof summary !== "string" || !summary)) {
    throw new OnboardingError("stale_review");
  }
  const approval = parseOnboardingApproval({
    version: 1,
    reviewId: root.reviewId,
    mappings: root.mappings,
    exclusions: root.exclusions,
  });
  const safety = root.safety as { clientSourceMutated?: unknown; remoteSystemsMutated?: unknown } | undefined;
  if (!safety || safety.clientSourceMutated !== false || safety.remoteSystemsMutated !== false || Object.keys(safety).length !== 2) {
    throw new OnboardingError("stale_review");
  }
  const payload = {
    version: 1 as const,
    reviewId: root.reviewId,
    manifestSha256: root.manifestSha256,
    mappings: approval.mappings,
    exclusions: approval.exclusions,
    generatedFiles: root.generatedFiles as string[],
    patchSummary: root.patchSummary as string[],
    safety: { clientSourceMutated: false as const, remoteSystemsMutated: false as const },
  };
  if (fingerprintSource(canonicalOnboardingValue(payload)) !== root.planId) throw new OnboardingError("stale_review");
  return { ...payload, planId: root.planId };
}

function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new OnboardingError("invalid_approval");
  return value as Record<string, unknown>;
}

function exact(value: Record<string, unknown>, allowed: readonly string[], required: readonly string[] = allowed): void {
  if (Object.keys(value).some((key) => !allowed.includes(key)) || required.some((key) => !(key in value))) {
    throw new OnboardingError("invalid_approval");
  }
}

function candidateIds(value: unknown): string[] {
  if (!Array.isArray(value) || value.length === 0 || value.length > 5_000 || value.some((id) => typeof id !== "string" || !id || id.length > 300)) {
    throw new OnboardingError("invalid_approval");
  }
  if (new Set(value).size !== value.length) throw new OnboardingError("duplicate_decision");
  return value;
}

export function parseOnboardingApproval(value: unknown): OnboardingApproval {
  const root = record(value);
  exact(root, ["version", "reviewId", "mappings", "exclusions"]);
  if (root.version !== 1 || typeof root.reviewId !== "string" || !DIGEST.test(root.reviewId)) {
    throw new OnboardingError("invalid_approval");
  }
  if (!Array.isArray(root.mappings) || !Array.isArray(root.exclusions) || root.mappings.length > 1_000 || root.exclusions.length > 1_000) {
    throw new OnboardingError("invalid_approval");
  }
  const mappings = root.mappings.map((value) => {
    const mapping = record(value);
    exact(mapping, ["stableId", "category", "kind", "candidateIds"], ["stableId", "category", "candidateIds"]);
    if (typeof mapping.stableId !== "string" || mapping.stableId.length > 200 || !STABLE_ID.test(mapping.stableId)) {
      throw new OnboardingError("invalid_approval");
    }
    if (typeof mapping.category !== "string" || !CATEGORIES.includes(mapping.category as BuilderScanCategory)) {
      throw new OnboardingError("invalid_approval");
    }
    if (mapping.kind !== undefined && (typeof mapping.kind !== "string" || !KINDS.includes(mapping.kind as typeof KINDS[number]))) {
      throw new OnboardingError("invalid_approval");
    }
    return {
      stableId: mapping.stableId,
      category: mapping.category as BuilderScanCategory,
      ...(mapping.kind === undefined ? {} : { kind: mapping.kind as typeof KINDS[number] }),
      candidateIds: candidateIds(mapping.candidateIds),
    };
  });
  if (new Set(mappings.map((mapping) => mapping.stableId)).size !== mappings.length) {
    throw new OnboardingError("invalid_approval");
  }
  const exclusions = root.exclusions.map((value) => {
    const exclusion = record(value);
    exact(exclusion, ["reason", "candidateIds"]);
    if (typeof exclusion.reason !== "string" || !REASONS.includes(exclusion.reason as typeof REASONS[number])) {
      throw new OnboardingError("invalid_approval");
    }
    return { reason: exclusion.reason as typeof REASONS[number], candidateIds: candidateIds(exclusion.candidateIds) };
  });
  return { version: 1, reviewId: root.reviewId, mappings, exclusions };
}

export function planOnboardingAttachment(input: {
  readonly report: OnboardingInspectionReport;
  readonly approval: OnboardingApproval;
}): OnboardingAttachmentPlan {
  if (input.approval.reviewId !== input.report.reviewId) throw new OnboardingError("stale_review");
  const candidatesById = new Map(input.report.candidates.map((candidate) => [candidate.id, candidate]));
  const known = new Set(candidatesById.keys());
  const decided = new Set<string>();
  for (const mapping of input.approval.mappings) {
    for (const candidateId of mapping.candidateIds) {
      const candidate = candidatesById.get(candidateId);
      if (!candidate) throw new OnboardingError("unknown_candidate");
      if (mapping.kind && candidate.kind && mapping.kind !== candidate.kind) throw new OnboardingError("kind_conflict");
    }
  }
  for (const decision of [...input.approval.mappings, ...input.approval.exclusions]) {
    for (const candidateId of decision.candidateIds) {
      if (!known.has(candidateId)) throw new OnboardingError("unknown_candidate");
      if (decided.has(candidateId)) throw new OnboardingError("duplicate_decision");
      decided.add(candidateId);
    }
  }
  if (decided.size !== known.size) throw new OnboardingError("incomplete_approval");

  const payload = {
    version: 1 as const,
    reviewId: input.report.reviewId,
    manifestSha256: input.report.manifestSha256,
    mappings: input.approval.mappings,
    exclusions: input.approval.exclusions,
    generatedFiles: ["builder.config.ts", ".builder/installation-manifest.json", ".builder/module-manifest.json", "app/api/builder/route.ts", "app/admin/editor/page.tsx"],
    patchSummary: input.approval.mappings.map((mapping) =>
      `${mapping.stableId}: ${mapping.category} from ${mapping.candidateIds.length} reviewed candidate${mapping.candidateIds.length === 1 ? "" : "s"}.`),
    safety: { clientSourceMutated: false as const, remoteSystemsMutated: false as const },
  };
  return { ...payload, planId: fingerprintSource(canonicalOnboardingValue(payload)) };
}
