#!/usr/bin/env node

import "tsx/esm";

const { dispatchBuilderCli } = await import("./bin.ts");

process.exitCode = await dispatchBuilderCli(process.argv.slice(2));
