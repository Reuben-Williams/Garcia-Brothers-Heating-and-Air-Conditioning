import type { BuilderSiteConfig, EditableKind, ValidationIssue, ValidationResult } from "@your-builder/core";
import { normalizeRegionDefinitions, validateBuilderSite } from "@your-builder/core";

export * from "./scan/html-source.js";
export * from "./scan/next-source.js";
export * from "./scan/post-candidates.js";
export * from "./scan/source-fingerprint.js";
export * from "./migration/apply-journal.js";
export * from "./migration/apply-source.js";
export * from "./migration/generate-posts.js";
export * from "./migration/reversal-patch.js";
export * from "./migration/review-manifest.js";
export * from "./migration/check-cutover.js";
export * from "./migration/seed-posts.js";
export * from "./control-plane/register-installation.js";
export * from "./modules/module-manifest.js";
export * from "./modules/compatibility.js";
export * from "./foundation/growth-foundation-check.js";
export * from "./foundation/failure-drills.js";
export * from "./foundation/secret-boundary.js";

export interface BuilderCheckInput {
  site: BuilderSiteConfig;
  env: Record<string, string | undefined>;
  renderedRegions?: Array<{
    id: string;
    kind: EditableKind;
    source?: string;
  }>;
}

export interface BuilderInitInput {
  siteId: string;
  adapter: "central" | "supabase";
  editorPath?: string;
}

export interface BuilderInitFile {
  path: string;
  contents: string;
}

export interface BuilderScanInput {
  html: string;
  pageSlug?: string;
  source?: string;
}

export interface BuilderScanRegion {
  id: string;
  kind: EditableKind;
  label: string;
  source?: string;
}

export interface BuilderScanResult {
  regions: BuilderScanRegion[];
  warnings: ValidationIssue[];
  html?: string;
  pageSlug?: string;
  source?: string;
}

export type BuilderScanCategory =
  | "editableRegion"
  | "repeatedCollection"
  | "globalContent"
  | "navigation"
  | "form"
  | "mediaAsset"
  | "seoMetadata"
  | "decorativeContent"
  | "manualReview";

export type BuilderScanConfidence = "high" | "medium" | "low" | "manualReview";

export interface BuilderScanCandidate {
  id: string;
  category: BuilderScanCategory;
  confidence: BuilderScanConfidence;
  label: string;
  source?: string;
  regionId?: string;
  kind?: EditableKind;
  recommendation: string;
}

export interface BuilderAttachReviewReport {
  siteId: string;
  framework: "next-app-router" | "next-pages-router" | "react-vite" | "other";
  routes: string[];
  candidates: BuilderScanCandidate[];
  warnings: ValidationIssue[];
  instructions: string[];
}

export interface BuilderAttachReviewInput {
  siteId: string;
  framework: BuilderAttachReviewReport["framework"];
  routes: string[];
  scan: BuilderScanResult;
}

export interface BuilderApprovedMigrationInput {
  report: BuilderAttachReviewReport;
  approvedCandidateIds: string[];
}

export interface BuilderApprovedMigrationPlan {
  mutatesFiles: false;
  approvedCandidateIds: string[];
  generatedFiles: string[];
  patchSummary: string[];
  nextSteps: string[];
}

export function runBuilderCheck(input: BuilderCheckInput): ValidationResult {
  const result = validateBuilderSite(input.site);
  const issues: ValidationIssue[] = [...result.issues];

  if (input.site.adapter === "central") {
    if (!input.env.BUILDER_API_URL) {
      issues.push({
        code: "env.missing.central.apiUrl",
        message: "BUILDER_API_URL is required for the central SaaS adapter.",
        path: "BUILDER_API_URL",
      });
    }
    if (!input.env.BUILDER_SITE_TOKEN) {
      issues.push({
        code: "env.missing.central.siteToken",
        message: "BUILDER_SITE_TOKEN is required for the central SaaS adapter.",
        path: "BUILDER_SITE_TOKEN",
      });
    }
  }

  if (input.site.adapter === "supabase") {
    if (!input.env.SUPABASE_URL) {
      issues.push({
        code: "env.missing.supabase.url",
        message: "SUPABASE_URL is required for the Supabase adapter.",
        path: "SUPABASE_URL",
      });
    }
    if (!input.env.SUPABASE_SERVICE_ROLE_KEY) {
      issues.push({
        code: "env.missing.supabase.serviceRole",
        message: "SUPABASE_SERVICE_ROLE_KEY is required on server-only editor routes.",
        path: "SUPABASE_SERVICE_ROLE_KEY",
      });
    }
  }

  if (input.site.editor?.protected !== true) {
    issues.push({
      code: "editor.route.unprotected",
      message: "The editor route must be protected before giving store owners access.",
      path: input.site.editor?.path ?? "/editor",
    });
  }

  const configured = new Map<string, EditableKind>();
  for (const region of normalizeRegionDefinitions(input.site.globalRegions ?? [])) {
    configured.set(region.id, region.kind);
  }
  for (const page of input.site.pages) {
    for (const region of normalizeRegionDefinitions(page.regions)) {
      configured.set(region.id, region.kind);
    }
  }

  for (const rendered of input.renderedRegions ?? []) {
    const expectedKind = configured.get(rendered.id);
    if (!expectedKind) {
      issues.push({
        code: "rendered.region.missing.config",
        message: `Rendered editable region "${rendered.id}" is not declared in builder.config.ts.`,
        path: rendered.source ?? rendered.id,
      });
      continue;
    }

    if (expectedKind !== rendered.kind) {
      issues.push({
        code: "rendered.region.kind.conflict",
        message: `Rendered editable region "${rendered.id}" is "${rendered.kind}" but config declares "${expectedKind}".`,
        path: rendered.source ?? rendered.id,
      });
    }
  }

  return { ok: issues.length === 0, issues };
}

export function formatBuilderCheck(result: ValidationResult): string {
  if (result.ok) return "Builder check passed.";
  return result.issues.map((issue) => `[${issue.code}] ${issue.message}`).join("\n");
}

export function getBuilderInitFiles(input: BuilderInitInput): BuilderInitFile[] {
  const editorPath = input.editorPath ?? "/admin/editor";
  const editorSegments = editorPath.replace(/^\/+/, "").split("/");
  const editorPagePath = `app/${editorSegments.join("/")}/page.tsx`;

  return [
    {
      path: "builder.config.ts",
      contents: `import { defineBuilderSite } from "@your-builder/core";

export default defineBuilderSite({
  siteId: "${input.siteId}",
  adapter: "${input.adapter}",
  editor: { path: "${editorPath}", protected: true },
  pages: [
    {
      path: "/",
      label: "Home",
      regions: [
        { id: "home.hero.title", kind: "text", label: "Hero title" },
        { id: "home.hero.icon", kind: "icon", label: "Hero icon" },
        { id: "home.hero.image", kind: "image", label: "Hero image" },
        { id: "home.sections", kind: "sections", label: "Home sections" },
      ],
    },
  ],
  sections: {},
});
`,
    },
    {
      path: "app/api/builder/route.ts",
      contents: `import { createCentralAdapter, createSupabaseAdapter } from "@your-builder/core";
import { createBuilderRouteHandlers } from "@your-builder/next/routes";
import site from "../../../builder.config";

const adapter = site.adapter === "supabase"
  ? createSupabaseAdapter({
      url: process.env.SUPABASE_URL!,
      serviceKey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
    })
  : createCentralAdapter({
      apiUrl: process.env.BUILDER_API_URL!,
      siteToken: process.env.BUILDER_SITE_TOKEN!,
    });

export const { GET, POST, PUT, PATCH } = createBuilderRouteHandlers({
  site,
  adapter,
  getUserId: () => "replace-with-auth-user-id",
});
`,
    },
    {
      path: editorPagePath,
      contents: `import { EditorShell } from "@your-builder/editor";
import site from "../../../builder.config";

export default function BuilderEditorPage() {
  return (
    <EditorShell
      siteId={site.siteId}
      currentPath="/"
      pages={site.pages}
      previewBaseUrl={process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"}
      auditLog={[]}
    />
  );
}
`,
    },
    {
      path: ".env.example",
      contents:
        input.adapter === "supabase"
          ? `SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
NEXT_PUBLIC_SITE_URL=http://localhost:3000
`
          : `BUILDER_API_URL=
BUILDER_SITE_TOKEN=
NEXT_PUBLIC_SITE_URL=http://localhost:3000
`,
    },
  ];
}

export function scanEditableRegionsFromHtml(input: BuilderScanInput): BuilderScanResult {
  const pageSlug = toSlug(input.pageSlug ?? "page", "page");
  const regions: BuilderScanRegion[] = [];
  const warnings: ValidationIssue[] = [];
  const seen = new Set<string>();
  const explicitInstances = new Map<string, Array<string>>();

  for (const match of input.html.matchAll(/<([a-z][a-z0-9-]*)\b([^>]*\bdata-builder-region\s*=\s*(?:"[^"]+"|'[^']+')[^>]*)>/gi)) {
    const attributes = match[2] ?? "";
    const id = readAttribute(attributes, "data-builder-region");
    const kind = readAttribute(attributes, "data-builder-kind") as EditableKind;
    if (!id || !["text", "richText", "image", "link", "sections", "icon", "postCollection"].includes(kind)) continue;
    pushScanRegion(regions, seen, {
      id,
      kind,
      label: readAttribute(attributes, "aria-label") || readAttribute(attributes, "placeholder") || id.split(".").join(" "),
      source: input.source,
    });
    const instances = explicitInstances.get(id) ?? [];
    instances.push(readAttribute(attributes, "data-builder-instance"));
    explicitInstances.set(id, instances);
  }

  for (const [id, instances] of explicitInstances) {
    if (instances.length > 1 && instances.some((instance) => !instance)) {
      warnings.push({
        code: "scan.region.instance.missing",
        message: `Repeated rendering of "${id}" requires a stable data-builder-instance value.`,
        path: input.source ?? id,
      });
    }
  }
  const elementPattern =
    /<img\b([^>]*)>|<(h[1-6]|p|span|small|strong|blockquote|time|a|button)\b([^>]*)>([\s\S]*?)<\/\2>/gi;

  for (const match of input.html.matchAll(elementPattern)) {
    const imageAttributes = match[1];
    const tag = match[2]?.toLowerCase();
    const attributes = imageAttributes ?? match[3] ?? "";
    const content = match[4] ?? "";
    if (readAttribute(attributes, "data-builder-region")) continue;

    if (imageAttributes !== undefined) {
      const alt = readAttribute(attributes, "alt");
      const src = readAttribute(attributes, "src");
      const label = alt || fileLabel(src) || "Image";
      pushScanRegion(regions, seen, {
        id: `${pageSlug}.image.img.${toSlug(label, String(regions.length + 1))}`,
        kind: "image",
        label,
        source: input.source,
      });
      continue;
    }

    if (!tag) continue;

    const className = readAttribute(attributes, "class");
    const label = stripTags(content);
    if (!label) continue;

    if (tag === "span" && /\bmaterial-symbols-outlined\b|\bmaterial-icons\b/.test(className)) {
      pushScanRegion(regions, seen, {
        id: `${pageSlug}.icon.material.${toSlug(label, String(regions.length + 1))}`,
        kind: "icon",
        label,
        source: input.source,
      });
      continue;
    }

    if (tag === "a" || tag === "button") {
      pushScanRegion(regions, seen, {
        id: `${pageSlug}.link.${tag}.${toSlug(label, String(regions.length + 1))}`,
        kind: "link",
        label,
        source: input.source,
      });
      continue;
    }

    pushScanRegion(regions, seen, {
      id: `${pageSlug}.text.${tag}.${toSlug(label, String(regions.length + 1))}`,
      kind: "text",
      label,
      source: input.source,
    });
  }

  if (regions.length === 0) {
    warnings.push({
      code: "scan.no.regions",
      message: "No likely editable text, image, icon, or link regions were found.",
      path: input.source,
    });
  }

  return { regions, warnings, html: input.html, pageSlug, source: input.source };
}

export function classifyScanCandidates(scan: BuilderScanResult): BuilderScanCandidate[] {
  const candidates: BuilderScanCandidate[] = [];
  const html = scan.html ?? "";
  const source = scan.source;

  if (/<title\b[^>]*>[\s\S]*?<\/title>|<meta\b[^>]+name=["']description["']/i.test(html)) {
    candidates.push({
      id: `${scan.pageSlug ?? "page"}.seo.metadata`,
      category: "seoMetadata",
      confidence: "medium",
      label: "SEO metadata",
      source,
      recommendation: "Review page title, description, canonical, and social metadata before exposing them in the editor.",
    });
  }

  if (/<nav\b/i.test(html)) {
    candidates.push({
      id: `${scan.pageSlug ?? "page"}.navigation`,
      category: "navigation",
      confidence: "manualReview",
      label: "Navigation links",
      source,
      recommendation: "Treat navigation as global content only after confirming it is shared across pages.",
    });
  }

  if (/<form\b/i.test(html)) {
    candidates.push({
      id: `${scan.pageSlug ?? "page"}.form`,
      category: "form",
      confidence: "medium",
      label: "Form or lead capture",
      source,
      recommendation: "Map this to a developer-defined form schema and leads inbox before wrapping fields.",
    });
  }

  const articleCount = (html.match(/<article\b/gi) ?? []).length;
  if (articleCount >= 2) {
    candidates.push({
      id: `${scan.pageSlug ?? "page"}.collection.repeated-cards`,
      category: "repeatedCollection",
      confidence: "manualReview",
      label: "Repeated card collection",
      source,
      recommendation: "Map repeated cards to a content collection such as services, testimonials, posts, or FAQs.",
    });
  }

  for (const match of html.matchAll(/<img\b([^>]*)>/gi)) {
    const attributes = match[1] ?? "";
    const alt = readAttribute(attributes, "alt");
    const src = readAttribute(attributes, "src");
    if (!alt.trim()) {
      candidates.push({
        id: `${scan.pageSlug ?? "page"}.decorative.${toSlug(fileLabel(src) || "image", "image")}`,
        category: "decorativeContent",
        confidence: "manualReview",
        label: fileLabel(src) || "Decorative image",
        source,
        recommendation: "Confirm this image is decorative before excluding it from editable media.",
      });
    }
  }

  for (const region of scan.regions) {
    const category = region.kind === "image" ? "mediaAsset" : "editableRegion";
    candidates.push({
      id: `region.${region.id}`,
      category,
      confidence: region.kind === "sections" ? "manualReview" : "high",
      label: region.label,
      source: region.source,
      regionId: region.id,
      kind: region.kind,
      recommendation: `Approve stable ID "${region.id}" before generating wrappers.`,
    });
  }

  if (candidates.length === 0) {
    candidates.push({
      id: `${scan.pageSlug ?? "page"}.manual-review`,
      category: "manualReview",
      confidence: "manualReview",
      label: "Manual review required",
      source,
      recommendation: "No safe automatic candidates were found; inspect the rendered page before migration.",
    });
  }

  return candidates;
}

export function createAttachReviewReport(input: BuilderAttachReviewInput): BuilderAttachReviewReport {
  return {
    siteId: input.siteId,
    framework: input.framework,
    routes: [...input.routes],
    candidates: classifyScanCandidates(input.scan),
    warnings: [...input.scan.warnings],
    instructions: [
      "Approve stable IDs before running migration",
      "Map repeated cards to collections before replacing fallback content.",
      "Verify desktop, tablet, and mobile editor previews against the live route.",
      "Keep generated changes as a reviewable patch; do not publish during attach.",
    ],
  };
}

export function planApprovedMigration(input: BuilderApprovedMigrationInput): BuilderApprovedMigrationPlan {
  const approved = new Set(input.approvedCandidateIds);
  const approvedCandidates = input.report.candidates.filter((candidate) => approved.has(candidate.id));
  return {
    mutatesFiles: false,
    approvedCandidateIds: approvedCandidates.map((candidate) => candidate.id),
    generatedFiles: ["builder.config.ts", "app/api/builder/route.ts", "app/admin/editor/page.tsx"],
    patchSummary: approvedCandidates.map((candidate) =>
      candidate.regionId
        ? `Wrap ${candidate.regionId} as ${candidate.kind ?? "editable"} content.`
        : `Prepare ${candidate.label} for ${candidate.category} review.`,
    ),
    nextSteps: [
      "Apply the generated patch only after developer approval.",
      "Run builder check after applying the generated patch.",
      "Compare editor mobile preview with the live/demo mobile route before handing off to an owner.",
    ],
  };
}

function pushScanRegion(regions: BuilderScanRegion[], seen: Set<string>, region: BuilderScanRegion) {
  let id = region.id;
  let suffix = 2;
  while (seen.has(id)) {
    id = `${region.id}-${suffix++}`;
  }
  seen.add(id);
  regions.push({ ...region, id });
}

function readAttribute(attributes: string, name: string): string {
  const match = attributes.match(new RegExp(`${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, "i"));
  return decodeEntities(match?.[1] ?? match?.[2] ?? match?.[3] ?? "");
}

function stripTags(value: string): string {
  return decodeEntities(value.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim());
}

function fileLabel(path: string): string {
  const file = path.split(/[/?#]/)[0]?.split("/").pop() ?? "";
  return file.replace(/\.[a-z0-9]+$/i, "").replace(/[-_]+/g, " ").trim();
}

function toSlug(value: string, fallback: string): string {
  const words = decodeEntities(value).toLowerCase().match(/[a-z0-9]+/g) ?? [];
  const selected: string[] = [];
  for (const word of words) {
    const next = [...selected, word].join("-");
    if (selected.length > 0 && next.length > 24) break;
    selected.push(word);
  }
  return selected.join("-") || fallback;
}

function decodeEntities(value: string): string {
  return value
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ");
}
