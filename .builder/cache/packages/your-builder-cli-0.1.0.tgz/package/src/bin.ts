import { access, mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { createInterface } from "node:readline/promises";

import {
  RegistrationCliError,
  parseInstallationManifest,
  registerInstallation,
  type RegisterInstallationInput,
} from "./control-plane/register-installation.js";
import { formatBuilderCheck, runBuilderCheck } from "./index.js";
import {
  formatGrowthFoundationCheck,
  runGrowthFoundationCheck,
} from "./foundation/growth-foundation-check.js";
import {
  formatModuleCompatibility,
  runModuleAttachCheck,
} from "./modules/compatibility.js";
import { ModuleManifestError } from "./modules/module-manifest.js";
import { fingerprintSource } from "./scan/source-fingerprint.js";
import {
  inspectOnboardingProject,
  OnboardingError,
  applyOnboardingSourcePatch,
  generateOnboardingSourcePatch,
  parseOnboardingApproval,
  parseOnboardingApplyReceipt,
  parseOnboardingAttachmentPlan,
  parseOnboardingInspectionReport,
  parseOnboardingManifest,
  parseOnboardingSourcePatch,
  planOnboardingAttachment,
  canonicalOnboardingValue,
  createOnboardingStageReceipt,
  parseOnboardingVerificationEvidence,
  verifyOnboardingProject,
} from "./onboarding/index.js";
import {
  readExchangeTokenFromTty,
  SecretPromptError,
  type ExchangeTokenSecret,
  type SecretPromptTerminal,
} from "./control-plane/secret-prompt.js";
import {
  setupInstallation,
  SetupInstallationError,
} from "./control-plane/setup-installation.js";
import {
  createManualHandoffController,
  createManualHostingAdapter,
  ManualHostingError,
  type ManualHandoffController,
} from "./hosting/manual/manual-adapter.js";
import { createHostingAdapterRegistry } from "./hosting/adapter-registry.js";
import type { HostingTarget } from "./hosting/contracts.js";

const CHECK_USAGE = "Usage: builder check --project <path>";
const REGISTER_USAGE =
  "Usage: builder register-installation --project <path> [--rotate] [--control-plane-url <url> --exchange-token-stdin --stable-site-key <key> --public-url <url>]\nTrust precondition: no other local process may modify the project directory while this command runs.";
const SETUP_USAGE =
  "Usage: builder setup-installation --project <path> --control-plane-url <url> --stable-site-key <key> --public-url <url> --hosting <manual|netlify> --exchange-token-stdin [--rebind-exchange --expected-installation-id <uuid>]";
const ONBOARD_USAGE = "Usage: builder onboard --stage <inspect|plan|patch|apply|verify> [inspect: --project <path> --manifest <path>] [plan: --review <path> --approval <path>] [patch: --project <path> --review-project <path> --plan <path>] [apply: --project <path> --plan <path> --patch <path>] [verify: --project <path> --review <path> --plan <path> --receipt <path> --evidence <path>] --output <path>";
const HANDOFF_USAGE = "Usage: builder hosting-handoff --project <path> <--status|--confirm|--cleanup>";
const USAGE = `${CHECK_USAGE}\n${REGISTER_USAGE}\n${SETUP_USAGE}\n${HANDOFF_USAGE}\n${ONBOARD_USAGE}`;

interface DispatcherOutput {
  info(line: string): void;
  warn(line: string): void;
  error(line: string): void;
}

export interface BuilderCliDependencies {
  register?: typeof registerInstallation;
  setup?: typeof setupInstallation;
  output?: DispatcherOutput;
  exchangeTokenPrompt?: () => Promise<ExchangeTokenSecret>;
  manualHandoffController?: ManualHandoffController;
  confirmHostingTarget?: (target: HostingTarget) => Promise<boolean>;
}

function parseArguments(args: readonly string[]): { command: string; flags: Map<string, string | true> } {
  const command = args[0] ?? "help";
  const flags = new Map<string, string | true>();
  for (let index = 1; index < args.length; index += 1) {
    const flag = args[index]!;
    if (!flag.startsWith("--") || flags.has(flag)) throw new RegistrationCliError("invalid_arguments");
    if (
      flag === "--rotate" ||
      flag === "--help" ||
      flag === "--exchange-token-stdin" ||
      flag === "--status" ||
      flag === "--confirm" ||
      flag === "--cleanup"
      || flag === "--rebind-exchange"
    ) {
      flags.set(flag, true);
      continue;
    }
    const value = args[index + 1];
    if (!value || value.startsWith("--")) throw new RegistrationCliError("invalid_arguments");
    flags.set(flag, value);
    index += 1;
  }
  return { command, flags };
}

function stringFlag(flags: Map<string, string | true>, name: string): string {
  const value = flags.get(name);
  if (typeof value !== "string") throw new RegistrationCliError("invalid_arguments");
  return value;
}

function createNodeSecretPromptTerminal(): SecretPromptTerminal {
  const input = process.stdin;
  return {
    isTTY: input.isTTY === true && typeof input.setRawMode === "function",
    writeError: (value) => { process.stderr.write(value); },
    setRawMode: (enabled) => {
      if (typeof input.setRawMode !== "function") throw new Error("tty_unavailable");
      input.setRawMode(enabled);
      if (enabled) input.resume();
      else input.pause();
    },
    read: () => new Promise<Uint8Array | null>((resolveRead, rejectRead) => {
      const cleanup = () => {
        input.off("data", onData);
        input.off("end", onEnd);
        input.off("error", onError);
      };
      const onData = (chunk: Buffer | string) => {
        cleanup();
        resolveRead(typeof chunk === "string" ? new TextEncoder().encode(chunk) : new Uint8Array(chunk));
      };
      const onEnd = () => { cleanup(); resolveRead(null); };
      const onError = () => { cleanup(); rejectRead(new Error("stdin_read_failed")); };
      input.once("data", onData);
      input.once("end", onEnd);
      input.once("error", onError);
    }),
    onSigint: (listener) => {
      process.on("SIGINT", listener);
      return () => { process.off("SIGINT", listener); };
    },
  };
}

function hasExchangeTokenEnvironment(): boolean {
  return Object.entries(process.env).some(([name, value]) =>
    Boolean(value) && /(?:^|_)EXCHANGE_TOKEN(?:_|$)/i.test(name));
}

async function confirmNodeHostingTarget(target: HostingTarget): Promise<boolean> {
  if (process.stdin.isTTY !== true || process.stdout.isTTY !== true) return false;
  const prompt = createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await prompt.question(
      `Configure ${target.provider} site "${target.siteName}" in ${target.context}? [y/N] `,
    );
    return /^(?:y|yes)$/i.test(answer.trim());
  } finally {
    prompt.close();
  }
}

async function writeIdempotentOutput(outputPath: string, value: unknown): Promise<void> {
  const contents = `${JSON.stringify(value, null, 2)}\n`;
  await mkdir(dirname(outputPath), { recursive: true });
  try {
    await writeFile(outputPath, contents, { flag: "wx" });
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
    if (await readFile(outputPath, "utf8") !== contents) throw new OnboardingError("output_conflict");
  }
}

async function writeOnboardingStageOutput(input: {
  outputPath: string;
  value: unknown;
  stage: "inspect" | "plan" | "patch" | "apply" | "verify";
  inputIds: Readonly<Record<string, string>>;
  outputId: string;
}): Promise<void> {
  await writeIdempotentOutput(input.outputPath, input.value);
  await writeIdempotentOutput(`${input.outputPath}.receipt.json`, createOnboardingStageReceipt({
    stage: input.stage,
    inputIds: input.inputIds,
    outputId: input.outputId,
  }));
}

export async function dispatchBuilderCli(
  args: readonly string[],
  dependencies: BuilderCliDependencies = {},
): Promise<number> {
  const output = dependencies.output ?? {
    info: console.log,
    warn: console.warn,
    error: console.error,
  };
  try {
    const parsed = parseArguments(args);
    if (parsed.command === "help" || parsed.command === "--help") {
      output.info(USAGE);
      return 0;
    }
    if (parsed.flags.get("--help") === true) {
      if (parsed.command === "check") output.info(CHECK_USAGE);
      else if (parsed.command === "register-installation") output.info(REGISTER_USAGE);
      else if (parsed.command === "setup-installation") output.info(SETUP_USAGE);
      else if (parsed.command === "hosting-handoff") output.info(HANDOFF_USAGE);
      else if (parsed.command === "onboard") output.info(ONBOARD_USAGE);
      else {
        output.error(USAGE);
        return 1;
      }
      return 0;
    }
    if (parsed.command === "hosting-handoff") {
      const allowed = new Set(["--project", "--status", "--confirm", "--cleanup"]);
      if ([...parsed.flags.keys()].some((flag) => !allowed.has(flag))) {
        throw new RegistrationCliError("invalid_arguments");
      }
      const actions = ["--status", "--confirm", "--cleanup"]
        .filter((flag) => parsed.flags.get(flag) === true);
      if (actions.length !== 1) throw new RegistrationCliError("invalid_arguments");
      const projectDir = resolve(stringFlag(parsed.flags, "--project"));
      const controller = dependencies.manualHandoffController ?? createManualHandoffController({
        now: () => new Date(),
      });
      if (actions[0] === "--status") {
        const status = await controller.status(projectDir);
        if (status.status === "absent") output.info("Manual hosting handoff: absent");
        else output.info([
          `Manual hosting handoff: pending at ${status.path}`,
          `Required names: ${status.names.join(", ")}`,
        ].join("\n"));
      } else if (actions[0] === "--confirm") {
        const result = await controller.confirm(projectDir);
        output.info([
          `Manual hosting handoff: ${result.status}`,
          `Acknowledged names: ${result.names.join(", ")}`,
          "Installation health remains attention until a fresh signed report arrives.",
        ].join("\n"));
      } else {
        await controller.cleanup(projectDir);
        output.info("Manual hosting handoff: cleaned");
      }
      return 0;
    }
    if (parsed.command === "setup-installation") {
      const allowed = new Set([
        "--project",
        "--control-plane-url",
        "--stable-site-key",
        "--public-url",
        "--hosting",
        "--exchange-token-stdin",
        "--rebind-exchange",
        "--expected-installation-id",
      ]);
      if (
        [...parsed.flags.keys()].some((flag) => !allowed.has(flag)) ||
        parsed.flags.get("--exchange-token-stdin") !== true ||
        hasExchangeTokenEnvironment()
      ) {
        throw new RegistrationCliError("invalid_arguments");
      }
      const hosting = stringFlag(parsed.flags, "--hosting");
      if (hosting !== "manual" && hosting !== "netlify") {
        throw new RegistrationCliError("invalid_arguments");
      }
      const rebindExchange = parsed.flags.get("--rebind-exchange") === true;
      const expectedInstallationId = parsed.flags.get("--expected-installation-id");
      if (
        rebindExchange !== (typeof expectedInstallationId === "string")
      ) {
        throw new RegistrationCliError("invalid_arguments");
      }
      const manual = createManualHostingAdapter({
        environmentLabel: "staging",
        reviewedMarkers: [
          "package.json",
          ".builder/installation-manifest.json",
          ".builder/site-runtime.json",
        ],
        now: () => new Date(),
        confirmTarget: dependencies.confirmHostingTarget ?? confirmNodeHostingTarget,
        output,
      });
      const result = await (dependencies.setup ?? setupInstallation)({
        projectDir: resolve(stringFlag(parsed.flags, "--project")),
        controlPlaneUrl: stringFlag(parsed.flags, "--control-plane-url"),
        stableSiteKey: stringFlag(parsed.flags, "--stable-site-key"),
        publicUrl: stringFlag(parsed.flags, "--public-url"),
        hosting,
        ...(rebindExchange
          ? {
              rebindExchange: true,
              expectedInstallationId: expectedInstallationId as string,
            }
          : {}),
      }, {
        adapterRegistry: createHostingAdapterRegistry([manual]),
        withExchangeToken: async (callback) => {
          const secret = await (dependencies.exchangeTokenPrompt ?? (() =>
            readExchangeTokenFromTty(createNodeSecretPromptTerminal())))();
          return secret.use(callback);
        },
        registerInstallation: dependencies.register,
        registration: { output },
      });
      output.info([
        `Installation setup: ${result.status}`,
        `Installation ID: ${result.installationId}`,
        `Accepted key ID: ${result.acceptedKeyId}`,
      ].join("\n"));
      return 0;
    }
    if (parsed.command === "check") {
      const allowed = new Set(["--project"]);
      if ([...parsed.flags.keys()].some((flag) => !allowed.has(flag))) {
        throw new RegistrationCliError("invalid_arguments");
      }
      const projectDir = resolve(stringFlag(parsed.flags, "--project"));
      const candidates = ["builder.config.ts", "builder.config.js", "builder.config.mjs"];
      let configPath: string | undefined;
      for (const candidate of candidates) {
        const next = join(projectDir, candidate);
        try {
          await access(next);
          configPath = next;
          break;
        } catch {
          // Continue to the next supported config extension.
        }
      }
      if (!configPath) throw new RegistrationCliError("invalid_arguments");
      const loaded = await import(`${pathToFileURL(configPath).href}?builder-check=${Date.now()}`);
      const result = runBuilderCheck({ site: loaded.default, env: process.env });
      let moduleReport: Awaited<ReturnType<typeof runModuleAttachCheck>> | undefined;
      let hasModuleManifest = true;
      try {
        await access(join(projectDir, ".builder", "module-manifest.json"));
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") hasModuleManifest = false;
        else throw error;
      }
      if (hasModuleManifest) moduleReport = await runModuleAttachCheck({ projectDir });
      let foundationReport: Awaited<ReturnType<typeof runGrowthFoundationCheck>> | undefined;
      if (hasModuleManifest && moduleReport?.compatible) {
        const installation = JSON.parse(await readFile(
          join(projectDir, ".builder", "installation-manifest.json"),
          "utf8",
        )) as { routes?: unknown };
        const editorPath = loaded.default?.editor?.path;
        if (
          typeof editorPath === "string" &&
          Array.isArray(installation.routes) &&
          installation.routes.includes(editorPath)
        ) {
          foundationReport = await runGrowthFoundationCheck({ projectDir });
        }
      }
      const formatted = [
        ...(result.ok ? [] : [formatBuilderCheck(result)]),
        ...(moduleReport && !moduleReport.compatible
          ? [formatModuleCompatibility(moduleReport)]
          : []),
        ...(foundationReport && !foundationReport.ok
          ? [formatGrowthFoundationCheck(foundationReport)]
          : []),
      ].join("\n");
      if (
        result.ok &&
        (!moduleReport || moduleReport.compatible) &&
        (!foundationReport || foundationReport.ok)
      ) {
        output.info([
          formatBuilderCheck(result),
          ...(foundationReport ? [formatGrowthFoundationCheck(foundationReport)] : []),
        ].join("\n"));
        return 0;
      }
      output.error(formatted);
      return 1;
    }
    if (parsed.command === "onboard") {
      const stage = stringFlag(parsed.flags, "--stage");
      const outputPath = resolve(stringFlag(parsed.flags, "--output"));
      if (stage === "inspect") {
        const allowed = new Set(["--stage", "--project", "--manifest", "--output"]);
        if ([...parsed.flags.keys()].some((flag) => !allowed.has(flag))) throw new OnboardingError("invalid_manifest");
        const projectDir = resolve(stringFlag(parsed.flags, "--project"));
        const manifestPath = resolve(stringFlag(parsed.flags, "--manifest"));
        const manifest = parseOnboardingManifest(JSON.parse(await readFile(manifestPath, "utf8")));
        const report = await inspectOnboardingProject({ projectDir, manifest });
        await writeOnboardingStageOutput({
          outputPath,
          value: report,
          stage: "inspect",
          inputIds: { manifestSha256: report.manifestSha256 },
          outputId: report.reviewId,
        });
        output.info(`Onboarding inspection passed. Review ID: ${report.reviewId}`);
        return 0;
      }
      if (stage === "plan") {
        const allowed = new Set(["--stage", "--review", "--approval", "--output"]);
        if ([...parsed.flags.keys()].some((flag) => !allowed.has(flag))) throw new OnboardingError("invalid_approval");
        const report = parseOnboardingInspectionReport(JSON.parse(await readFile(resolve(stringFlag(parsed.flags, "--review")), "utf8")));
        const approval = parseOnboardingApproval(JSON.parse(await readFile(resolve(stringFlag(parsed.flags, "--approval")), "utf8")));
        const plan = planOnboardingAttachment({ report, approval });
        await writeOnboardingStageOutput({
          outputPath,
          value: plan,
          stage: "plan",
          inputIds: {
            reviewId: report.reviewId,
            approvalSha256: fingerprintSource(canonicalOnboardingValue(approval)),
          },
          outputId: plan.planId,
        });
        output.info(`Onboarding plan passed. Plan ID: ${plan.planId}`);
        return 0;
      }
      if (stage === "patch") {
        const allowed = new Set(["--stage", "--project", "--review-project", "--plan", "--output"]);
        if ([...parsed.flags.keys()].some((flag) => !allowed.has(flag))) throw new OnboardingError("invalid_patch");
        const projectDir = resolve(stringFlag(parsed.flags, "--project"));
        const reviewDir = resolve(stringFlag(parsed.flags, "--review-project"));
        const plan = parseOnboardingAttachmentPlan(JSON.parse(await readFile(resolve(stringFlag(parsed.flags, "--plan")), "utf8")));
        const patch = await generateOnboardingSourcePatch({ projectDir, reviewDir, planId: plan.planId });
        await writeOnboardingStageOutput({
          outputPath,
          value: patch,
          stage: "patch",
          inputIds: { planId: plan.planId },
          outputId: patch.patchId,
        });
        output.info(`Onboarding patch passed. Patch ID: ${patch.patchId}`);
        return 0;
      }
      if (stage === "apply") {
        const allowed = new Set(["--stage", "--project", "--plan", "--patch", "--output"]);
        if ([...parsed.flags.keys()].some((flag) => !allowed.has(flag))) throw new OnboardingError("invalid_patch");
        const projectDir = resolve(stringFlag(parsed.flags, "--project"));
        const plan = parseOnboardingAttachmentPlan(JSON.parse(await readFile(resolve(stringFlag(parsed.flags, "--plan")), "utf8")));
        const patch = parseOnboardingSourcePatch(JSON.parse(await readFile(resolve(stringFlag(parsed.flags, "--patch")), "utf8")));
        const receipt = await applyOnboardingSourcePatch({ projectDir, planId: plan.planId, patch });
        await writeOnboardingStageOutput({
          outputPath,
          value: receipt,
          stage: "apply",
          inputIds: { planId: plan.planId, patchId: patch.patchId },
          outputId: receipt.receiptId,
        });
        output.info(`Onboarding apply passed. Patch ID: ${receipt.patchId}`);
        return 0;
      }
      if (stage === "verify") {
        const allowed = new Set(["--stage", "--project", "--review", "--plan", "--receipt", "--evidence", "--output"]);
        if ([...parsed.flags.keys()].some((flag) => !allowed.has(flag))) throw new OnboardingError("verification_failed");
        const projectDir = resolve(stringFlag(parsed.flags, "--project"));
        const report = parseOnboardingInspectionReport(JSON.parse(await readFile(resolve(stringFlag(parsed.flags, "--review")), "utf8")));
        const plan = parseOnboardingAttachmentPlan(JSON.parse(await readFile(resolve(stringFlag(parsed.flags, "--plan")), "utf8")));
        const applyReceipt = parseOnboardingApplyReceipt(JSON.parse(await readFile(resolve(stringFlag(parsed.flags, "--receipt")), "utf8")));
        const evidence = parseOnboardingVerificationEvidence(JSON.parse(await readFile(resolve(stringFlag(parsed.flags, "--evidence")), "utf8")));
        const verification = await verifyOnboardingProject({
          projectDir,
          report,
          plan,
          applyReceipt,
          evidence,
          env: process.env,
        });
        await writeOnboardingStageOutput({
          outputPath,
          value: verification,
          stage: "verify",
          inputIds: {
            reviewId: report.reviewId,
            planId: plan.planId,
            applyReceiptId: applyReceipt.receiptId,
            evidenceSha256: fingerprintSource(canonicalOnboardingValue(evidence)),
          },
          outputId: verification.verificationId,
        });
        if (!verification.ok) {
          output.error("verification_failed");
          return 1;
        }
        output.info(`Onboarding aggregate verification passed. Verification ID: ${verification.verificationId}`);
        return 0;
      }
      throw new OnboardingError("invalid_manifest");
    }
    if (parsed.command !== "register-installation") {
      output.error(USAGE);
      return 1;
    }
    const allowed = new Set([
      "--project",
      "--rotate",
      "--control-plane-url",
      "--exchange-token-stdin",
      "--stable-site-key",
      "--public-url",
      "--overlap-seconds",
    ]);
    if ([...parsed.flags.keys()].some((flag) => !allowed.has(flag))) {
      throw new RegistrationCliError("invalid_arguments");
    }
    const projectDir = resolve(stringFlag(parsed.flags, "--project"));
    let input: RegisterInstallationInput;
    if (parsed.flags.get("--rotate") === true) {
      if (parsed.flags.has("--exchange-token-stdin")) {
        throw new RegistrationCliError("invalid_arguments");
      }
      const overlap = parsed.flags.get("--overlap-seconds");
      input = {
        projectDir,
        rotate: true,
        ...(typeof overlap === "string" ? { overlapSeconds: Number(overlap) } : {}),
      };
    } else {
      if (parsed.flags.get("--exchange-token-stdin") !== true || hasExchangeTokenEnvironment()) {
        throw new RegistrationCliError("invalid_arguments");
      }
      const manifestText = await readFile(
        join(projectDir, ".builder", "installation-manifest.json"),
        "utf8",
      );
      const manifest = parseInstallationManifest(JSON.parse(manifestText));
      const secret = await (dependencies.exchangeTokenPrompt ?? (() =>
        readExchangeTokenFromTty(createNodeSecretPromptTerminal())))();
      return await secret.use(async (exchangeToken) => {
        input = {
          projectDir,
          controlPlaneUrl: stringFlag(parsed.flags, "--control-plane-url"),
          exchangeToken,
          stableSiteKey: stringFlag(parsed.flags, "--stable-site-key"),
          publicUrl: stringFlag(parsed.flags, "--public-url"),
          manifest,
        };
        await (dependencies.register ?? registerInstallation)(input, { output });
        return 0;
      });
    }
    await (dependencies.register ?? registerInstallation)(input, { output });
    return 0;
  } catch (error) {
    output.error(
      error instanceof RegistrationCliError || error instanceof SetupInstallationError || error instanceof ModuleManifestError || error instanceof OnboardingError || error instanceof SecretPromptError || error instanceof ManualHostingError
        ? error.code
        : "command_failed",
    );
    return 1;
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  process.exitCode = await dispatchBuilderCli(process.argv.slice(2));
}
