import type { PostMigrationManifest, PostSnapshot } from "@your-builder/content";

export interface PostImportRecord {
  manifestId: string;
  seedHash: string;
  entryIds: string[];
}

export interface SeedEntryState {
  entryId: string;
  importedSeedHash: string | null;
  ownerEdited: boolean;
}

export interface PostSeedRepository {
  getImport(manifestId: string): Promise<PostImportRecord | null>;
  getEntryState(entryId: string): Promise<SeedEntryState | null>;
  createDraft(input: {
    siteKey: string;
    manifestId: string;
    seedHash: string;
    entryId: string;
    sourceRecordKey: string;
    snapshot: PostSnapshot;
  }): Promise<{ versionId: string }>;
  recordImport(record: PostImportRecord): Promise<void>;
}

export async function seedPostDrafts(
  manifest: PostMigrationManifest,
  repository: PostSeedRepository,
  options: { confirmed: boolean },
) {
  if (!options.confirmed) throw new Error("Explicit confirmation is required before seeding drafts.");
  const existingImport = await repository.getImport(manifest.manifestId);
  if (existingImport) {
    if (existingImport.seedHash !== manifest.seedHash) {
      throw new Error("The seed payload changed under an existing manifest identity.");
    }
    return { created: 0, skipped: manifest.records.length, published: 0 };
  }

  let created = 0;
  let skipped = 0;
  for (const record of manifest.records) {
    const state = await repository.getEntryState(record.entryId);
    if (state?.ownerEdited) {
      throw new Error(`Refusing to overwrite owner-edited draft ${record.entryId}.`);
    }
    if (state?.importedSeedHash === manifest.seedHash) {
      skipped += 1;
      continue;
    }
    await repository.createDraft({
      siteKey: manifest.siteKey,
      manifestId: manifest.manifestId,
      seedHash: manifest.seedHash,
      entryId: record.entryId,
      sourceRecordKey: record.sourceRecordKey,
      snapshot: record.approvedFields,
    });
    created += 1;
  }
  await repository.recordImport({
    manifestId: manifest.manifestId,
    seedHash: manifest.seedHash,
    entryIds: manifest.records.map((record) => record.entryId),
  });
  return { created, skipped, published: 0 };
}
