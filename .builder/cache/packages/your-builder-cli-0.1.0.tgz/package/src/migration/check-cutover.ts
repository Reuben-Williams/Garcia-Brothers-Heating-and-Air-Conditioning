export interface PostCutoverEntry {
  entryId: string;
  published: boolean;
  projectionReady: boolean;
  mediaReady: boolean;
}

export interface PostCutoverIssue {
  code: "cutover.entry.unpublished" | "cutover.projection.missing" | "cutover.media.missing" | "cutover.detail-route.missing";
  message: string;
  entryId?: string;
}

export interface PostCutoverResult {
  sourceScopeKey: string;
  ready: boolean;
  issues: PostCutoverIssue[];
}

export function checkPostCutover(input: {
  sourceScopeKey: string;
  entries: readonly PostCutoverEntry[];
  detailRouteReady: boolean;
}): PostCutoverResult {
  const issues: PostCutoverIssue[] = [];
  for (const entry of input.entries) {
    if (!entry.published) issues.push({ code: "cutover.entry.unpublished", message: "Post is not published.", entryId: entry.entryId });
    if (!entry.projectionReady) issues.push({ code: "cutover.projection.missing", message: "Published projection is missing.", entryId: entry.entryId });
    if (!entry.mediaReady) issues.push({ code: "cutover.media.missing", message: "A referenced media revision is unavailable.", entryId: entry.entryId });
  }
  if (!input.detailRouteReady) issues.push({ code: "cutover.detail-route.missing", message: "The post detail route is not ready." });
  return { sourceScopeKey: input.sourceScopeKey, ready: issues.length === 0, issues };
}

export function generatePostCutoverPatch(result: PostCutoverResult) {
  if (!result.ready) throw new Error("Post source scope is not ready for live cutover.");
  return {
    sourceScopeKey: result.sourceScopeKey,
    from: "fallback" as const,
    to: "live" as const,
    requiresReview: true as const,
    publishesContent: false as const,
  };
}
