export interface ApplyJournalFile {
  path: string;
  before: string | null;
  afterHash: string;
}

export interface ApplyJournal {
  version: 1;
  status: "pending" | "complete" | "failed" | "reversed";
  createdAt: string;
  completedAt?: string;
  files: ApplyJournalFile[];
}
