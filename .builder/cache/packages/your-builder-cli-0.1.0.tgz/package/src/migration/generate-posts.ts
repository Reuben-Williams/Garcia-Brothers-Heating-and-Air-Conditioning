import {
  createSeedHash,
  parsePostMigrationManifest,
  type PostMigrationManifest,
} from "@your-builder/content";
import { fingerprintSource } from "../scan/source-fingerprint.js";

type ManifestCandidate = PostMigrationManifest["reviewedPatchSpec"]["candidates"][number];
type ManifestRecord = PostMigrationManifest["records"][number];

export interface PostReviewManifestInput {
  toolVersion: string;
  siteKey: string;
  sourceScopeKey: string;
  collectionRegionId: string;
  sourceFiles: Array<{ path: string; contents: string }>;
  candidates: ManifestCandidate[];
  detailRoute: PostMigrationManifest["reviewedPatchSpec"]["detailRoute"];
  fallbackSource: PostMigrationManifest["reviewedPatchSpec"]["fallbackSource"];
  collectionRenderer: PostMigrationManifest["reviewedPatchSpec"]["collectionRenderer"];
  records: ManifestRecord[];
}

export async function buildPostReviewManifest(input: PostReviewManifestInput): Promise<PostMigrationManifest> {
  const sourceFiles = input.sourceFiles.map((file) => ({
    path: file.path,
    sha256: fingerprintSource(file.contents),
    astFingerprint: fingerprintSource(file.contents.replace(/\s+/g, " ").trim()),
  }));
  const seedHash = await createSeedHash({
    schemaVersion: 1,
    siteKey: input.siteKey,
    sourceScopeKey: input.sourceScopeKey,
    records: input.records,
  });
  const manifestHash = await createSeedHash({
    siteKey: input.siteKey,
    sourceScopeKey: input.sourceScopeKey,
    sourceFiles,
    candidates: input.candidates,
    seedHash,
  });
  return parsePostMigrationManifest({
    schemaVersion: 1,
    toolVersion: input.toolVersion,
    manifestId: `postmig_${manifestHash}`,
    seedHash,
    siteKey: input.siteKey,
    sourceScopeKey: input.sourceScopeKey,
    collectionRegionId: input.collectionRegionId,
    sourceFiles,
    reviewedPatchSpec: {
      candidates: input.candidates,
      detailRoute: input.detailRoute,
      fallbackSource: input.fallbackSource,
      collectionRenderer: input.collectionRenderer,
    },
    records: input.records,
    generatedArtifacts: [],
  });
}

export interface GeneratedMigrationFile { path: string; contents: string }

export function generatePostMigrationArtifacts(manifest: PostMigrationManifest) {
  const fallbackContents = `import type { PostSnapshot } from "@your-builder/content";\n\nexport const fallbackPostSnapshots = ${JSON.stringify(manifest.records.map((record) => ({ entryId: record.entryId, snapshot: record.approvedFields })), null, 2)} satisfies readonly { entryId: string; snapshot: PostSnapshot }[];\n`;
  const collectionContents = `import { PostCollection } from "@your-builder/next/content";\n\nexport const generatedPostCollectionConfig = ${JSON.stringify({ regionId: manifest.collectionRegionId, sourceScopeKey: manifest.sourceScopeKey, contentSource: "fallback" }, null, 2)} as const;\n\nexport { PostCollection };\n`;
  const detailContents = `import { PostEntryPage } from "@your-builder/next/content";\n\nexport default PostEntryPage;\n`;
  const validation = {
    manifestId: manifest.manifestId,
    readyToApply: manifest.records.length > 0 && manifest.reviewedPatchSpec.candidates.length > 0,
    publishesContent: false,
    sourceScopeKey: manifest.sourceScopeKey,
    recordCount: manifest.records.length,
  };
  const files: GeneratedMigrationFile[] = [
    { path: manifest.reviewedPatchSpec.fallbackSource.sourceFile, contents: fallbackContents },
    { path: "src/components/posts/GeneratedPostCollection.tsx", contents: collectionContents },
    { path: manifest.reviewedPatchSpec.detailRoute.sourceFile, contents: detailContents },
    { path: ".builder/migrations/builder-config.patch.json", contents: JSON.stringify({ regionId: manifest.collectionRegionId, sourceScopeKey: manifest.sourceScopeKey, contentSource: "fallback" }, null, 2) },
    { path: ".builder/migrations/seed-posts.json", contents: JSON.stringify({ manifestId: manifest.manifestId, seedHash: manifest.seedHash, records: manifest.records }, null, 2) },
    { path: ".builder/migrations/validation-report.json", contents: JSON.stringify(validation, null, 2) },
  ];
  return { files, validation };
}
