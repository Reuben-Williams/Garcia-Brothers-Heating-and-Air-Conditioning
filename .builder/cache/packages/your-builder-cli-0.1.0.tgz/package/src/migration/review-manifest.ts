import type { PostMigrationManifest } from "@your-builder/content";

export type ReviewedPostMigrationManifest = PostMigrationManifest;
