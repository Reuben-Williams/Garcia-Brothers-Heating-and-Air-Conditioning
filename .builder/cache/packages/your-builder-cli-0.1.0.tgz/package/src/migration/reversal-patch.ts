export interface ReversalPatch {
  files: Array<{ path: string; restoreContents: string | null }>;
}
