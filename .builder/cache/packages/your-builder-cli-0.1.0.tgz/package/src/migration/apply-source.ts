import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { fingerprintSource } from "../scan/source-fingerprint.js";
import type { ApplyJournal } from "./apply-journal.js";
import type { ReversalPatch } from "./reversal-patch.js";

export interface SourcePatchFile {
  path: string;
  expectedCurrentHash: string | null;
  contents: string;
}

type BoundApplyJournal = ApplyJournal & {
  planId?: string;
  patchId?: string;
};

function resolveInside(root: string, relativePath: string): string {
  const resolvedRoot = path.resolve(root);
  const resolved = path.resolve(root, relativePath);
  if (resolved !== resolvedRoot && !resolved.startsWith(`${resolvedRoot}${path.sep}`)) {
    throw new Error(`Patch path escapes the project root: ${relativePath}`);
  }
  return resolved;
}

async function readOptional(filePath: string): Promise<string | null> {
  try {
    return await readFile(filePath, "utf8");
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw error;
  }
}

async function restoreJournalFiles(root: string, journal: ApplyJournal): Promise<void> {
  for (const file of [...journal.files].reverse()) {
    const target = resolveInside(root, file.path);
    if (file.before === null) await rm(target, { force: true });
    else {
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, file.before, "utf8");
    }
  }
}

export async function applySourcePatch(input: {
  root: string;
  journalPath: string;
  files: SourcePatchFile[];
  journalBinding?: { planId: string; patchId: string };
}) {
  const snapshots = [] as Array<{ patch: SourcePatchFile; before: string | null }>;
  for (const patchFile of input.files) {
    const target = resolveInside(input.root, patchFile.path);
    const before = await readOptional(target);
    const actualHash = before === null ? null : fingerprintSource(before);
    if (actualHash !== patchFile.expectedCurrentHash) {
      throw new Error(`Source drift detected for ${patchFile.path}; regenerate and review the patch.`);
    }
    snapshots.push({ patch: patchFile, before });
  }

  const journalPath = resolveInside(input.root, input.journalPath);
  const journal: BoundApplyJournal = {
    version: 1,
    status: "pending",
    createdAt: new Date().toISOString(),
    ...(input.journalBinding ?? {}),
    files: snapshots.map(({ patch: patchFile, before }) => ({
      path: patchFile.path,
      before,
      afterHash: fingerprintSource(patchFile.contents),
    })),
  };
  await mkdir(path.dirname(journalPath), { recursive: true });
  await writeFile(journalPath, JSON.stringify(journal, null, 2), "utf8");

  try {
    for (const { patch: patchFile } of snapshots) {
      const target = resolveInside(input.root, patchFile.path);
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, patchFile.contents, "utf8");
    }
    journal.status = "complete";
    journal.completedAt = new Date().toISOString();
    await writeFile(journalPath, JSON.stringify(journal, null, 2), "utf8");
  } catch (error) {
    await restoreJournalFiles(input.root, journal);
    journal.status = "failed";
    await writeFile(journalPath, JSON.stringify(journal, null, 2), "utf8");
    throw error;
  }

  const reversal: ReversalPatch = {
    files: journal.files.map((file) => ({ path: file.path, restoreContents: file.before })),
  };
  return { journalPath: input.journalPath, journal, reversal };
}

export async function recoverInterruptedApply(
  root: string,
  journalRelativePath: string,
  options: { forceCompleted?: boolean; validatedJournal?: ApplyJournal } = {},
): Promise<ApplyJournal> {
  const journalPath = resolveInside(root, journalRelativePath);
  const journal = options.validatedJournal ?? JSON.parse(await readFile(journalPath, "utf8")) as ApplyJournal;
  if (journal.status === "complete" && !options.forceCompleted) {
    throw new Error("The apply completed successfully; explicit forceCompleted is required to reverse it.");
  }
  if (journal.status === "reversed") return journal;
  await restoreJournalFiles(root, journal);
  journal.status = "reversed";
  journal.completedAt = new Date().toISOString();
  await writeFile(journalPath, JSON.stringify(journal, null, 2), "utf8");
  return journal;
}
