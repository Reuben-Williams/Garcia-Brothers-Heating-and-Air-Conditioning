import { readFile, readdir, stat } from "node:fs/promises";
import { resolve } from "node:path";

export const FOUNDATION_SECRET_SURFACES = [
  "browserHtml",
  "staticAssets",
  "pageData",
  "playwrightArtifacts",
  "vitestSnapshots",
  "capturedLogs",
] as const;

export type FoundationSecretSurface = typeof FOUNDATION_SECRET_SURFACES[number];

export interface FoundationSecretFinding {
  readonly surface: FoundationSecretSurface;
  readonly path: string;
  readonly canaryId: string;
}

export interface FoundationSecretBoundaryReport {
  readonly ok: boolean;
  readonly scannedFiles: number;
  readonly findings: readonly FoundationSecretFinding[];
}

async function filesBelow(path: string): Promise<string[]> {
  try {
    const metadata = await stat(path);
    if (metadata.isFile()) return [path];
    if (!metadata.isDirectory()) return [];
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
    throw error;
  }
  const files: string[] = [];
  for (const entry of await readdir(path, { withFileTypes: true })) {
    if (entry.isSymbolicLink()) continue;
    const child = resolve(path, entry.name);
    if (entry.isDirectory()) files.push(...await filesBelow(child));
    else if (entry.isFile()) files.push(child);
  }
  return files;
}

export async function scanFoundationSecretBoundaries(input: {
  canaries: Readonly<Record<string, string>>;
  surfaces: Readonly<Record<FoundationSecretSurface, readonly string[]>>;
}): Promise<FoundationSecretBoundaryReport> {
  const canaries = Object.entries(input.canaries);
  if (
    canaries.length === 0 ||
    canaries.some(([id, value]) => !id.trim() || value.length < 16) ||
    new Set(canaries.map(([, value]) => value)).size !== canaries.length
  ) {
    throw new TypeError("Secret canaries must be unique and at least 16 characters long");
  }
  const findings: FoundationSecretFinding[] = [];
  let scannedFiles = 0;
  for (const surface of FOUNDATION_SECRET_SURFACES) {
    const paths = (await Promise.all(input.surfaces[surface].map((path) => filesBelow(resolve(path)))))
      .flat()
      .sort();
    for (const path of paths) {
      scannedFiles += 1;
      const contents = await readFile(path);
      for (const [canaryId, canary] of canaries) {
        if (contents.includes(Buffer.from(canary, "utf8"))) findings.push({ surface, path, canaryId });
      }
    }
  }
  return {
    ok: findings.length === 0,
    scannedFiles,
    findings,
  };
}
