import { lstat, readFile, readdir } from "node:fs/promises";
import { extname, join, relative, resolve } from "node:path";
import ts from "typescript";

import { normalizeRegionDefinitions, validateBuilderSite, type BuilderSiteConfig } from "@your-builder/core";

import { parseInstallationManifest, type InstallationManifestInput } from "../control-plane/register-installation.js";
import { checkModuleCompatibility } from "../modules/compatibility.js";
import { parseModuleManifest, type BuilderModuleManifest } from "../modules/module-manifest.js";

export const GROWTH_FOUNDATION_CHECK_IDS = [
  "module_manifest_version",
  "stable_ids",
  "unique_routes",
  "package_schema_compatibility",
  "server_only_trust",
  "protected_admin_route",
  "command_worker",
  "snapshot_cache",
  "public_fallback",
] as const;

export type GrowthFoundationCheckId = typeof GROWTH_FOUNDATION_CHECK_IDS[number];

export interface GrowthFoundationIssue {
  readonly code: string;
  readonly checkId: GrowthFoundationCheckId;
  readonly message: string;
  readonly path?: string;
}

export interface GrowthFoundationCheckResult {
  readonly id: GrowthFoundationCheckId;
  readonly status: "pass" | "fail";
  readonly issueCodes: readonly string[];
}

export interface GrowthFoundationCheckReport {
  readonly ok: boolean;
  readonly mutatesFiles: false;
  readonly projectDir: string;
  readonly checks: readonly GrowthFoundationCheckResult[];
  readonly issues: readonly GrowthFoundationIssue[];
}

interface SourceFile {
  readonly path: string;
  readonly relativePath: string;
  readonly text: string;
}

const STABLE_SITE_ID = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const STABLE_REGION_ID = /^[a-z][a-z0-9-]*(?:\.[a-z][a-z0-9-]*)+$/;
const SOURCE_EXTENSIONS = new Set([".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx"]);
const SKIPPED_DIRECTORIES = new Set([
  ".git",
  ".next",
  "node_modules",
  "coverage",
  "test-results",
  "sales-package",
  "site-editor-platform",
]);
const PRIVATE_TRUST_REFERENCE =
  /BUILDER_INSTALLATION_PRIVATE_JWK|SUPABASE_SERVICE_ROLE_KEY|CONTROL_PLANE_PRIVATE_SIGNING_KEY|installation-private\.jwk/;

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function isGeneratedDirectory(name: string): boolean {
  return SKIPPED_DIRECTORIES.has(name) || /^\.next(?:-|$)/.test(name);
}

async function sourceFiles(projectDir: string): Promise<SourceFile[]> {
  const files: SourceFile[] = [];
  async function visit(directory: string) {
    const entries = await readdir(directory, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.isSymbolicLink() || isGeneratedDirectory(entry.name)) continue;
      const path = join(directory, entry.name);
      if (entry.isDirectory()) {
        if (entry.name === ".builder") continue;
        await visit(path);
      } else if (entry.isFile() && SOURCE_EXTENSIONS.has(extname(entry.name))) {
        files.push({
          path,
          relativePath: relative(projectDir, path).replaceAll("\\", "/"),
          text: await readFile(path, "utf8"),
        });
      }
    }
  }
  await visit(projectDir);
  return files;
}

function propertyName(name: ts.PropertyName): string {
  if (ts.isIdentifier(name) || ts.isStringLiteral(name) || ts.isNumericLiteral(name)) return name.text;
  throw new TypeError("builder_config_not_static");
}

function staticValue(expression: ts.Expression): unknown {
  if (
    ts.isAsExpression(expression) ||
    ts.isSatisfiesExpression(expression) ||
    ts.isParenthesizedExpression(expression)
  ) return staticValue(expression.expression);
  if (ts.isCallExpression(expression)) {
    if (expression.arguments.length !== 1) throw new TypeError("builder_config_not_static");
    return staticValue(expression.arguments[0]!);
  }
  if (ts.isObjectLiteralExpression(expression)) {
    const output: Record<string, unknown> = {};
    for (const property of expression.properties) {
      if (!ts.isPropertyAssignment(property)) throw new TypeError("builder_config_not_static");
      output[propertyName(property.name)] = staticValue(property.initializer);
    }
    return output;
  }
  if (ts.isArrayLiteralExpression(expression)) return expression.elements.map(staticValue);
  if (ts.isStringLiteral(expression) || ts.isNoSubstitutionTemplateLiteral(expression)) return expression.text;
  if (ts.isNumericLiteral(expression)) return Number(expression.text);
  if (expression.kind === ts.SyntaxKind.TrueKeyword) return true;
  if (expression.kind === ts.SyntaxKind.FalseKeyword) return false;
  if (expression.kind === ts.SyntaxKind.NullKeyword) return null;
  if (
    ts.isPrefixUnaryExpression(expression) &&
    expression.operator === ts.SyntaxKind.MinusToken &&
    ts.isNumericLiteral(expression.operand)
  ) return -Number(expression.operand.text);
  throw new TypeError("builder_config_not_static");
}

export async function loadBuilderSiteConfig(projectDir: string): Promise<BuilderSiteConfig> {
  for (const name of ["builder.config.ts", "builder.config.js", "builder.config.mjs"]) {
    const path = join(projectDir, name);
    try {
      const metadata = await lstat(path);
      if (!metadata.isFile() || metadata.isSymbolicLink()) continue;
      const source = ts.createSourceFile(
        path,
        await readFile(path, "utf8"),
        ts.ScriptTarget.Latest,
        true,
        name.endsWith(".ts") ? ts.ScriptKind.TS : ts.ScriptKind.JS,
      );
      const exported = source.statements.find(ts.isExportAssignment);
      if (!exported || exported.isExportEquals) throw new TypeError("builder_config_not_static");
      return staticValue(exported.expression) as BuilderSiteConfig;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") continue;
      throw error;
    }
  }
  throw new Error("builder_config_missing");
}

function duplicateValues(values: readonly string[]): string[] {
  const seen = new Set<string>();
  const duplicates = new Set<string>();
  for (const value of values) {
    if (seen.has(value)) duplicates.add(value);
    seen.add(value);
  }
  return [...duplicates];
}

function rawRoutes(value: unknown): string[] {
  if (!isRecord(value) || !Array.isArray(value.routes)) return [];
  return value.routes.filter((route): route is string => typeof route === "string");
}

function moduleRoutes(value: unknown): string[] {
  if (!isRecord(value) || !isRecord(value.requirements)) return [];
  return rawRoutes(value.requirements);
}

function issue(
  issues: GrowthFoundationIssue[],
  checkId: GrowthFoundationCheckId,
  code: string,
  message: string,
  path?: string,
) {
  issues.push({ code, checkId, message, ...(path ? { path } : {}) });
}

async function readOptional(path: string): Promise<string | null> {
  try {
    return await readFile(path, "utf8");
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw error;
  }
}

export async function runGrowthFoundationCheck(input: {
  projectDir: string;
  installationManifestPath?: string;
  moduleManifestPath?: string;
}): Promise<GrowthFoundationCheckReport> {
  const projectDir = resolve(input.projectDir);
  const installationPath = input.installationManifestPath ??
    join(projectDir, ".builder", "installation-manifest.json");
  const modulePath = input.moduleManifestPath ?? join(projectDir, ".builder", "module-manifest.json");
  const issues: GrowthFoundationIssue[] = [];
  const [site, sources, packageText, installationText, moduleText] = await Promise.all([
    loadBuilderSiteConfig(projectDir),
    sourceFiles(projectDir),
    readFile(join(projectDir, "package.json"), "utf8"),
    readOptional(installationPath),
    readOptional(modulePath),
  ]);
  const packageJson = JSON.parse(packageText) as unknown;
  const rawInstallation = installationText === null ? null : JSON.parse(installationText) as unknown;
  const rawModule = moduleText === null ? null : JSON.parse(moduleText) as unknown;

  let installation: InstallationManifestInput | undefined;
  let module: BuilderModuleManifest | undefined;
  if (moduleText === null) {
    issue(issues, "module_manifest_version", "MODULE_MANIFEST_MISSING",
      "The approved module manifest is missing.", relative(projectDir, modulePath));
  } else try {
    module = parseModuleManifest(rawModule);
  } catch {
    issue(issues, "module_manifest_version", "INVALID_MODULE_MANIFEST_VERSION",
      "The approved module manifest must use the supported version 1 schema.", relative(projectDir, modulePath));
  }
  if (installationText === null) {
    issue(issues, "package_schema_compatibility", "INSTALLATION_MANIFEST_MISSING",
      "The installation manifest is missing.", relative(projectDir, installationPath));
  } else try {
    installation = parseInstallationManifest(rawInstallation);
  } catch {
    issue(issues, "package_schema_compatibility", "INVALID_INSTALLATION_MANIFEST",
      "The installation manifest is invalid or unsupported.", relative(projectDir, installationPath));
  }

  const validation = validateBuilderSite(site);
  const configuredIds = site.pages.flatMap((page) =>
    normalizeRegionDefinitions(page.regions).map((region) => region.id));
  if (!STABLE_SITE_ID.test(site.siteId)) {
    issue(issues, "stable_ids", "UNSTABLE_ID", `Site ID "${site.siteId}" is not stable.`, "builder.config.ts");
  }
  for (const id of configuredIds) {
    if (!STABLE_REGION_ID.test(id)) {
      issue(issues, "stable_ids", "UNSTABLE_ID", `Region ID "${id}" is not stable.`, "builder.config.ts");
    }
  }
  for (const validationIssue of validation.issues.filter((entry) => entry.code === "region.id.duplicate")) {
    issue(issues, "stable_ids", "UNSTABLE_ID", validationIssue.message, validationIssue.path);
  }

  const routeGroups = [
    site.pages.map((page) => page.path),
    rawRoutes(rawInstallation),
    moduleRoutes(rawModule),
  ];
  for (const duplicate of routeGroups.flatMap(duplicateValues)) {
    issue(issues, "unique_routes", "DUPLICATE_ROUTE", `Route "${duplicate}" is duplicated.`);
  }

  if (module && installation) {
    const dependencyRecords = isRecord(packageJson)
      ? [packageJson.dependencies, packageJson.optionalDependencies, packageJson.devDependencies]
      : [];
    const packages: Record<string, string> = {};
    for (const record of dependencyRecords) {
      if (!isRecord(record)) continue;
      for (const [name, version] of Object.entries(record)) {
        if (typeof version === "string") packages[name] = version;
      }
    }
    const compatibility = checkModuleCompatibility({
      module,
      installation: { ...installation, packages: { ...packages, ...installation.packages } },
    });
    for (const entry of compatibility.issues) {
      issue(issues, "package_schema_compatibility", entry.code, entry.instruction, entry.requirement);
    }
  }

  for (const source of sources) {
    if (!PRIVATE_TRUST_REFERENCE.test(source.text)) continue;
    const clientVisible = /^\s*["']use client["'];/m.test(source.text) ||
      /NEXT_PUBLIC_[A-Z0-9_]*(?:PRIVATE|SECRET|SERVICE_ROLE|SIGNING_KEY)/.test(source.text);
    if (clientVisible) {
      issue(issues, "server_only_trust", "TRUST_VALUE_CLIENT_EXPOSED",
        "A server-only installation trust value is referenced by client-visible code.", source.relativePath);
    } else if (!/import\s+["']server-only["']/.test(source.text)) {
      issue(issues, "server_only_trust", "TRUST_VALUE_NOT_SERVER_ONLY",
        "Files that access installation trust values must import server-only.", source.relativePath);
    }
  }

  const editorPath = site.editor?.path;
  if (site.editor?.protected !== true || typeof editorPath !== "string" || !editorPath.startsWith("/admin/")) {
    issue(issues, "protected_admin_route", "ADMIN_ROUTE_UNPROTECTED",
      "The editor must use a protected route below /admin/.", editorPath ?? "builder.config.ts");
  }

  const allSource = sources.map((source) => source.text).join("\n");
  if (!installation?.workerVersion || !allSource.includes("createInstallationWorker")) {
    issue(issues, "command_worker", "COMMAND_WORKER_MISSING",
      "A versioned installation command worker must be wired into the site.");
  }
  if (!allSource.includes("createEntitlementSnapshotCache")) {
    issue(issues, "snapshot_cache", "SNAPSHOT_CACHE_MISSING",
      "A local entitlement snapshot cache must be wired into the site.");
  }
  const publicPage = sources.find((source) =>
    ["app/page.tsx", "app/page.jsx", "app/page.ts", "app/page.js"].includes(source.relativePath));
  if (
    !publicPage ||
    !/fallback/i.test(publicPage.text) ||
    /BUILDER_API_URL|control-plane/i.test(publicPage.text) ||
    /\bfetch\s*\(/.test(publicPage.text)
  ) {
    issue(issues, "public_fallback", "PUBLIC_FALLBACK_MISSING",
      "The public page must render local fallback content without a control-plane request.", publicPage?.relativePath ?? "app/page.{tsx,jsx,ts,js}");
  }

  const checks = GROWTH_FOUNDATION_CHECK_IDS.map((id) => {
    const issueCodes = issues.filter((entry) => entry.checkId === id).map((entry) => entry.code);
    return { id, status: issueCodes.length === 0 ? "pass" as const : "fail" as const, issueCodes };
  });
  return {
    ok: issues.length === 0,
    mutatesFiles: false,
    projectDir,
    checks,
    issues,
  };
}

export function formatGrowthFoundationCheck(report: GrowthFoundationCheckReport): string {
  if (report.ok) return "Growth foundation check passed.";
  return report.issues.map((entry) =>
    `[${entry.code}] ${entry.message}${entry.path ? ` (${entry.path})` : ""}`).join("\n");
}
