export const FOUNDATION_FAILURE_DRILL_IDS = [
  "request_replay",
  "command_replay",
  "crash_after_side_effect",
  "worker_restart",
  "key_overlap",
  "key_revocation",
  "stale_snapshot",
  "queue_pause_resume",
  "provisioning_retry",
  "automatic_compensation",
  "compensation_failure",
  "control_plane_outage",
] as const;

export type FoundationFailureDrillId = typeof FOUNDATION_FAILURE_DRILL_IDS[number];

export interface FoundationFailureDrillResult {
  readonly id: FoundationFailureDrillId;
  readonly passed: boolean;
  readonly evidence: string;
}

export interface FoundationFailureDrillReport {
  readonly ok: boolean;
  readonly mutatesFiles: false;
  readonly drills: readonly FoundationFailureDrillResult[];
  readonly missing: readonly FoundationFailureDrillId[];
  readonly duplicates: readonly FoundationFailureDrillId[];
}

export function createFoundationFailureDrillReport(
  results: readonly FoundationFailureDrillResult[],
): FoundationFailureDrillReport {
  const allowed = new Set<FoundationFailureDrillId>(FOUNDATION_FAILURE_DRILL_IDS);
  const byId = new Map<FoundationFailureDrillId, FoundationFailureDrillResult>();
  const duplicates = new Set<FoundationFailureDrillId>();
  for (const result of results) {
    if (!allowed.has(result.id)) throw new TypeError(`Unknown foundation drill: ${result.id}`);
    if (!result.evidence.trim()) throw new TypeError(`Missing drill evidence: ${result.id}`);
    if (byId.has(result.id)) duplicates.add(result.id);
    else byId.set(result.id, Object.freeze({ ...result }));
  }
  const missing = FOUNDATION_FAILURE_DRILL_IDS.filter((id) => !byId.has(id));
  const drills = FOUNDATION_FAILURE_DRILL_IDS.flatMap((id) => {
    const result = byId.get(id);
    return result ? [result] : [];
  });
  return Object.freeze({
    ok: missing.length === 0 && duplicates.size === 0 && drills.every((drill) => drill.passed),
    mutatesFiles: false,
    drills: Object.freeze(drills),
    missing: Object.freeze(missing),
    duplicates: Object.freeze([...duplicates]),
  });
}
