import { getAutomaticNetlifyCredentialSourceStatus } from "./credential-provider.js";
import { getNetlifyAutomaticScopeStatus } from "./scope-profile.js";

export type NetlifyAutomaticUnavailableCode =
  | "automatic_credential_source_unsupported"
  | "automatic_scope_proof_unavailable";

export class NetlifyAutomaticUnavailableError extends Error {
  constructor(public readonly code: NetlifyAutomaticUnavailableCode) {
    super(code);
    this.name = "NetlifyAutomaticUnavailableError";
  }
}

export interface DisabledNetlifyAdapterDependencies {
  spawn: (...args: never[]) => unknown;
  fetch: (...args: never[]) => unknown;
}

export function createNetlifyAdapter(_dependencies: DisabledNetlifyAdapterDependencies): never {
  const credential = getAutomaticNetlifyCredentialSourceStatus();
  if (!credential.enabled) throw new NetlifyAutomaticUnavailableError(credential.code);
  const scope = getNetlifyAutomaticScopeStatus();
  if (!scope.enabled) throw new NetlifyAutomaticUnavailableError(scope.code);
  throw new NetlifyAutomaticUnavailableError("automatic_scope_proof_unavailable");
}
