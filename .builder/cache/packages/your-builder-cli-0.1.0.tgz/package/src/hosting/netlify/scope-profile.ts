export interface DisabledNetlifyScopeStatus {
  enabled: false;
  profile: "netlify-next-server-v1";
  code: "automatic_scope_proof_unavailable";
}

const STATUS: DisabledNetlifyScopeStatus = Object.freeze({
  enabled: false,
  profile: "netlify-next-server-v1",
  code: "automatic_scope_proof_unavailable",
});

export function getNetlifyAutomaticScopeStatus(): DisabledNetlifyScopeStatus {
  return STATUS;
}
