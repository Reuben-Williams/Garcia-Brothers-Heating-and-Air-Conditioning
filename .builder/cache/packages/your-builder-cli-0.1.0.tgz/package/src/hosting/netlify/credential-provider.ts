export interface DisabledNetlifyCredentialSourceStatus {
  enabled: false;
  code: "automatic_credential_source_unsupported";
}

const STATUS: DisabledNetlifyCredentialSourceStatus = Object.freeze({
  enabled: false,
  code: "automatic_credential_source_unsupported",
});

export function getAutomaticNetlifyCredentialSourceStatus(): DisabledNetlifyCredentialSourceStatus {
  return STATUS;
}
