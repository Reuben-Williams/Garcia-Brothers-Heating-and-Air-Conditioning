import { createHash } from "node:crypto";
import { lstat, readFile, realpath } from "node:fs/promises";
import { isAbsolute, relative, resolve, sep } from "node:path";

import { canonicalSha256 } from "./canonical-receipt.js";

export interface ProjectFingerprint {
  canonicalProjectDir: string;
  digest: string;
}

export type ProjectFingerprintErrorCode =
  | "invalid_fingerprint_marker"
  | "unsafe_fingerprint_marker"
  | "fingerprint_marker_too_large";

export class ProjectFingerprintError extends Error {
  constructor(public readonly code: ProjectFingerprintErrorCode) {
    super(code);
    this.name = "ProjectFingerprintError";
  }
}

function fail(code: ProjectFingerprintErrorCode): never {
  throw new ProjectFingerprintError(code);
}

function safeRelativePath(projectDir: string, marker: string): string {
  if (
    !marker ||
    marker.trim() !== marker ||
    isAbsolute(marker) ||
    marker.includes("\0") ||
    marker.split(/[\\/]+/).some((part) => part === ".." || part === "")
  ) return fail("invalid_fingerprint_marker");
  const normalized = marker.replaceAll("\\", "/");
  if (normalized === ".builder/secrets" || normalized.startsWith(".builder/secrets/")) {
    return fail("unsafe_fingerprint_marker");
  }
  const absolute = resolve(projectDir, marker);
  const fromRoot = relative(projectDir, absolute);
  if (fromRoot.startsWith(`..${sep}`) || fromRoot === ".." || isAbsolute(fromRoot)) {
    return fail("invalid_fingerprint_marker");
  }
  return normalized;
}

export async function createProjectFingerprint(
  projectDir: string,
  reviewedMarkers: readonly string[],
): Promise<ProjectFingerprint> {
  const canonicalProjectDir = await realpath(projectDir);
  if (reviewedMarkers.length < 1 || reviewedMarkers.length > 32) {
    return fail("invalid_fingerprint_marker");
  }
  const markers = [];
  for (const requested of [...reviewedMarkers].sort()) {
    const marker = safeRelativePath(canonicalProjectDir, requested);
    const absolute = resolve(canonicalProjectDir, marker);
    const metadata = await lstat(absolute);
    if (!metadata.isFile() || metadata.isSymbolicLink()) return fail("unsafe_fingerprint_marker");
    if (metadata.size > 128 * 1024) return fail("fingerprint_marker_too_large");
    const bytes = await readFile(absolute);
    markers.push({
      path: marker,
      sha256: createHash("sha256").update(bytes).digest("hex"),
    });
  }
  return {
    canonicalProjectDir,
    digest: canonicalSha256({ canonicalProjectDir, markers }),
  };
}
