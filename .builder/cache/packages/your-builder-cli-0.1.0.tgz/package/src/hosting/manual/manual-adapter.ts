import { randomUUID } from "node:crypto";
import { basename, join } from "node:path";

import { ProjectFilesystem } from "../../control-plane/project-filesystem.js";
import {
  ProtectedFiles,
  ProtectedStorageError,
  type ProtectedFilesOptions,
} from "../../control-plane/protected-files.js";
import {
  SetupJournalError,
  createSetupJournalStore,
} from "../../control-plane/setup-journal.js";
import { canonicalSha256 } from "../canonical-receipt.js";
import {
  SERVER_ENVIRONMENT_NAMES,
  assertCurrentPreflight,
  createPreflightReceipt,
  parseHostingTarget,
  parsePreflightReceipt,
  type ConfigureResult,
  type DetectionResult,
  type HostingAdapter,
  type HostingTarget,
  type PreflightReceipt,
  type ProviderVerifyResult,
  type ServerEnvironmentInput,
  type ServerEnvironmentName,
  type ServerEnvironmentValues,
} from "../contracts.js";
import { createProjectFingerprint } from "../project-fingerprint.js";

const SECRETS_ROOT = join(".builder", "secrets");
const HANDOFF_DIRECTORY = join(SECRETS_ROOT, "hosting-handoff");
const HANDOFF_PATH = join(HANDOFF_DIRECTORY, "environment.json");
const ACKNOWLEDGMENT_PATH = join(".builder", "hosting-handoff-acknowledgement.json");

export interface ManualHostingAdapterOptions {
  environmentLabel: string;
  reviewedMarkers: readonly string[];
  now: () => Date;
  confirmTarget(target: HostingTarget): Promise<boolean>;
  output: { info(line: string): void };
  platform?: NodeJS.Platform;
  protectedFiles?: Omit<ProtectedFilesOptions, "platform">;
}

export interface ManualHandoffControllerOptions {
  now: () => Date;
  platform?: NodeJS.Platform;
  protectedFiles?: Omit<ProtectedFilesOptions, "platform">;
}

export interface ManualHandoffController {
  status(projectDir: string): Promise<ManualHandoffStatus>;
  confirm(projectDir: string): Promise<ProviderVerifyResult>;
  cleanup(projectDir: string): Promise<{ status: "cleaned" }>;
}

export type ManualHandoffStatus =
  | { status: "absent" }
  | { status: "pending"; names: readonly ServerEnvironmentName[]; path: string };

export interface ManualHostingAdapter extends HostingAdapter {
  id: "manual";
  detect(projectDir: string): Promise<DetectionResult>;
  preflight(projectDir: string, target: HostingTarget): Promise<PreflightReceipt>;
  configure(input: ServerEnvironmentInput, receipt: PreflightReceipt): Promise<ConfigureResult>;
  verifyConfiguration(receipt: PreflightReceipt): Promise<ProviderVerifyResult>;
  handoffStatus(projectDir: string): Promise<ManualHandoffStatus>;
  confirmHandoff(projectDir: string, receipt: PreflightReceipt): Promise<ProviderVerifyResult>;
  cleanupHandoff(projectDir: string): Promise<{ status: "cleaned" }>;
}

export type ManualHostingErrorCode =
  | "manual_target_invalid"
  | "manual_preflight_unknown"
  | "manual_confirmation_required"
  | "manual_handoff_conflict"
  | "manual_handoff_missing"
  | "manual_acknowledgment_missing"
  | "manual_protected_storage_unavailable";

export class ManualHostingError extends Error {
  constructor(public readonly code: ManualHostingErrorCode) {
    super(code);
    this.name = "ManualHostingError";
  }
}

interface ManualHandoffPayload {
  schemaVersion: 1;
  receiptDigest: string;
  target: HostingTarget;
  names: readonly ServerEnvironmentName[];
  environment: ServerEnvironmentValues;
}

interface ManualAcknowledgment {
  schemaVersion: 1;
  receiptDigest: string;
  target: HostingTarget;
  names: readonly ServerEnvironmentName[];
  acknowledgedAt: string;
}

function fail(code: ManualHostingErrorCode): never {
  throw new ManualHostingError(code);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function exactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join("\0") === [...keys].sort().join("\0");
}

function parseNames(value: unknown): readonly ServerEnvironmentName[] {
  if (!Array.isArray(value)) return fail("manual_handoff_conflict");
  const actual = value.every((name) => typeof name === "string") ? [...value].sort() : [];
  const expected = [...SERVER_ENVIRONMENT_NAMES].sort();
  if (actual.join("\0") !== expected.join("\0")) return fail("manual_handoff_conflict");
  return [...SERVER_ENVIRONMENT_NAMES];
}

function parseHandoff(value: unknown): ManualHandoffPayload {
  if (!isRecord(value) || !exactKeys(value, [
    "schemaVersion",
    "receiptDigest",
    "target",
    "names",
    "environment",
  ]) || value.schemaVersion !== 1 || typeof value.receiptDigest !== "string") {
    return fail("manual_handoff_conflict");
  }
  if (!isRecord(value.environment) || !exactKeys(value.environment, SERVER_ENVIRONMENT_NAMES)) {
    return fail("manual_handoff_conflict");
  }
  const rawEnvironment = value.environment;
  const environment = Object.fromEntries(SERVER_ENVIRONMENT_NAMES.map((name) => {
    const entry = rawEnvironment[name];
    if (typeof entry !== "string" || entry.length < 1) return fail("manual_handoff_conflict");
    return [name, entry];
  })) as ServerEnvironmentValues;
  try {
    return {
      schemaVersion: 1,
      receiptDigest: value.receiptDigest,
      target: parseHostingTarget(value.target),
      names: parseNames(value.names),
      environment,
    };
  } catch {
    return fail("manual_handoff_conflict");
  }
}

function parseAcknowledgment(value: unknown): ManualAcknowledgment {
  if (!isRecord(value) || !exactKeys(value, [
    "schemaVersion",
    "receiptDigest",
    "target",
    "names",
    "acknowledgedAt",
  ]) || value.schemaVersion !== 1 || typeof value.receiptDigest !== "string" ||
      typeof value.acknowledgedAt !== "string") {
    return fail("manual_acknowledgment_missing");
  }
  try {
    return {
      schemaVersion: 1,
      receiptDigest: value.receiptDigest,
      target: parseHostingTarget(value.target),
      names: parseNames(value.names),
      acknowledgedAt: value.acknowledgedAt,
    };
  } catch {
    return fail("manual_acknowledgment_missing");
  }
}

function sameTarget(left: HostingTarget, right: HostingTarget): boolean {
  return canonicalSha256(left) === canonicalSha256(right);
}

async function completeSetupJournal(
  projectDir: string,
  receiptDigest: string,
  options: ManualHandoffControllerOptions,
): Promise<void> {
  try {
    const journal = await createSetupJournalStore(projectDir, {
      now: options.now,
      platform: options.platform,
      protectedFiles: options.protectedFiles,
    });
    await journal.completeManualHandoff(receiptDigest);
  } catch (error) {
    if (
      error instanceof SetupJournalError &&
      (error.code === "setup_journal_conflict" || error.code === "setup_journal_invalid")
    ) return fail("manual_handoff_conflict");
    return fail("manual_protected_storage_unavailable");
  }
}

export function createManualHandoffController(
  options: ManualHandoffControllerOptions,
): ManualHandoffController {
  async function openStore(projectDir: string): Promise<{
    files: ProjectFilesystem;
    store: ProtectedFiles;
  }> {
    try {
      const files = await ProjectFilesystem.open(projectDir);
      const store = await ProtectedFiles.open(files, SECRETS_ROOT, {
        platform: options.platform,
        ...options.protectedFiles,
      });
      return { files, store };
    } catch {
      return fail("manual_protected_storage_unavailable");
    }
  }

  async function status(projectDir: string): Promise<ManualHandoffStatus> {
    const files = await ProjectFilesystem.open(projectDir);
    if (!await files.exists(SECRETS_ROOT) || !await files.exists(HANDOFF_DIRECTORY)) {
      return { status: "absent" };
    }
    try {
      const { store } = await openStore(projectDir);
      if (!await store.exists(HANDOFF_PATH)) return { status: "absent" };
      parseHandoff(JSON.parse(await store.read(HANDOFF_PATH)));
      return {
        status: "pending",
        names: [...SERVER_ENVIRONMENT_NAMES],
        path: store.path(HANDOFF_PATH),
      };
    } catch (error) {
      if (error instanceof ManualHostingError) throw error;
      return fail("manual_protected_storage_unavailable");
    }
  }

  return {
    status,
    async confirm(projectDir) {
      try {
        const { files, store } = await openStore(projectDir);
        if (!await files.exists(HANDOFF_DIRECTORY) || !await store.exists(HANDOFF_PATH)) {
          if (!await files.exists(ACKNOWLEDGMENT_PATH)) return fail("manual_handoff_missing");
          const existing = parseAcknowledgment(JSON.parse(await files.read(ACKNOWLEDGMENT_PATH)));
          await completeSetupJournal(projectDir, existing.receiptDigest, options);
          return {
            status: "acknowledged",
            target: existing.target,
            names: [...SERVER_ENVIRONMENT_NAMES],
          };
        }
        const handoff = parseHandoff(JSON.parse(await store.read(HANDOFF_PATH)));
        const acknowledgment: ManualAcknowledgment = {
          schemaVersion: 1,
          receiptDigest: handoff.receiptDigest,
          target: handoff.target,
          names: [...SERVER_ENVIRONMENT_NAMES],
          acknowledgedAt: options.now().toISOString(),
        };
        if (await files.exists(ACKNOWLEDGMENT_PATH)) {
          const existing = parseAcknowledgment(JSON.parse(await files.read(ACKNOWLEDGMENT_PATH)));
          if (!sameTarget(existing.target, handoff.target)) return fail("manual_handoff_conflict");
          if (existing.receiptDigest !== handoff.receiptDigest) {
            await files.writeAtomic(
              ACKNOWLEDGMENT_PATH,
              `${JSON.stringify(acknowledgment, null, 2)}\n`,
              `.hosting-handoff-acknowledgement.${randomUUID()}.tmp`,
            );
          }
        } else {
          await files.writeExclusive(
            ACKNOWLEDGMENT_PATH,
            `${JSON.stringify(acknowledgment, null, 2)}\n`,
          );
        }
        await store.remove(HANDOFF_DIRECTORY, true);
        if ((await status(projectDir)).status !== "absent") {
          return fail("manual_protected_storage_unavailable");
        }
        await completeSetupJournal(projectDir, handoff.receiptDigest, options);
        return {
          status: "acknowledged",
          target: handoff.target,
          names: [...SERVER_ENVIRONMENT_NAMES],
        };
      } catch (error) {
        if (error instanceof ManualHostingError) throw error;
        return fail("manual_protected_storage_unavailable");
      }
    },
    async cleanup(projectDir) {
      const files = await ProjectFilesystem.open(projectDir);
      if (!await files.exists(SECRETS_ROOT) || !await files.exists(HANDOFF_DIRECTORY)) {
        return { status: "cleaned" };
      }
      try {
        const { store } = await openStore(projectDir);
        await store.remove(HANDOFF_DIRECTORY, true);
        if ((await status(projectDir)).status !== "absent") {
          return fail("manual_protected_storage_unavailable");
        }
        return { status: "cleaned" };
      } catch (error) {
        if (error instanceof ManualHostingError) throw error;
        return fail("manual_protected_storage_unavailable");
      }
    },
  };
}

export function createManualHostingAdapter(options: ManualHostingAdapterOptions): ManualHostingAdapter {
  if (
    !/^[a-z0-9][a-z0-9-]{0,62}$/.test(options.environmentLabel) ||
    options.reviewedMarkers.length < 1
  ) return fail("manual_target_invalid");

  const projects = new Map<string, string>();

  async function fingerprint(projectDir: string) {
    return createProjectFingerprint(projectDir, options.reviewedMarkers);
  }

  async function detect(projectDir: string): Promise<DetectionResult> {
    const project = await fingerprint(projectDir);
    return {
      status: "detected",
      target: {
        provider: "manual",
        accountId: "manual",
        siteId: project.digest,
        siteName: basename(project.canonicalProjectDir),
        context: options.environmentLabel,
        branch: null,
        scopes: ["server-runtime"],
      },
    };
  }

  async function protectedFiles(projectDir: string): Promise<ProtectedFiles> {
    try {
      const files = await ProjectFilesystem.open(projectDir);
      return await ProtectedFiles.open(files, SECRETS_ROOT, {
        platform: options.platform,
        ...options.protectedFiles,
      });
    } catch {
      return fail("manual_protected_storage_unavailable");
    }
  }

  async function validateReceipt(receiptInput: PreflightReceipt): Promise<{
    receipt: PreflightReceipt;
    projectDir: string;
    target: HostingTarget;
  }> {
    const receipt = parsePreflightReceipt(receiptInput);
    const projectDir = projects.get(receipt.digest);
    if (!projectDir) return fail("manual_preflight_unknown");
    const [detection, project] = await Promise.all([detect(projectDir), fingerprint(projectDir)]);
    assertCurrentPreflight({
      receipt,
      detectedTarget: detection.target,
      projectFingerprint: project.digest,
      linkedStateHash: canonicalSha256({
        canonicalProjectDir: project.canonicalProjectDir,
        environmentLabel: options.environmentLabel,
      }),
      now: options.now(),
    });
    return { receipt, projectDir, target: detection.target };
  }

  async function handoffStatus(projectDir: string): Promise<ManualHandoffStatus> {
    const files = await ProjectFilesystem.open(projectDir);
    if (!await files.exists(SECRETS_ROOT)) return { status: "absent" };
    if (!await files.exists(HANDOFF_DIRECTORY)) return { status: "absent" };
    let protectedStore: ProtectedFiles;
    try {
      protectedStore = await protectedFiles(projectDir);
      if (!await protectedStore.exists(HANDOFF_PATH)) return { status: "absent" };
      parseHandoff(JSON.parse(await protectedStore.read(HANDOFF_PATH)));
    } catch (error) {
      if (error instanceof ManualHostingError) throw error;
      return fail("manual_protected_storage_unavailable");
    }
    return {
      status: "pending",
      names: [...SERVER_ENVIRONMENT_NAMES],
      path: protectedStore.path(HANDOFF_PATH),
    };
  }

  return {
    id: "manual",
    detect,
    async preflight(projectDir, target) {
      const detection = await detect(projectDir);
      if (!sameTarget(detection.target, parseHostingTarget(target))) return fail("manual_target_invalid");
      const project = await fingerprint(projectDir);
      const receipt = createPreflightReceipt({
        target: detection.target,
        projectFingerprint: project.digest,
        linkedStateHash: canonicalSha256({
          canonicalProjectDir: project.canonicalProjectDir,
          environmentLabel: options.environmentLabel,
        }),
        issuedAt: options.now().toISOString(),
      });
      projects.set(receipt.digest, project.canonicalProjectDir);
      return receipt;
    },
    async configure(input, receiptInput) {
      const { receipt, projectDir, target } = await validateReceipt(receiptInput);
      if (!await options.confirmTarget(target)) return fail("manual_confirmation_required");
      let store: ProtectedFiles;
      try {
        store = await protectedFiles(projectDir);
        await store.ensureDirectory(HANDOFF_DIRECTORY);
        const values = input.reveal();
        try {
          const payload: ManualHandoffPayload = {
            schemaVersion: 1,
            receiptDigest: receipt.digest,
            target,
            names: [...SERVER_ENVIRONMENT_NAMES],
            environment: values,
          };
          if (await store.exists(HANDOFF_PATH)) {
            const existing = parseHandoff(JSON.parse(await store.read(HANDOFF_PATH)));
            if (canonicalSha256(existing) !== canonicalSha256(payload)) {
              return fail("manual_handoff_conflict");
            }
          } else {
            await store.writeExclusive(HANDOFF_PATH, `${JSON.stringify(payload, null, 2)}\n`);
          }
        } finally {
          for (const name of SERVER_ENVIRONMENT_NAMES) values[name] = "";
        }
        options.output.info(`Protected hosting handoff: ${store.path(HANDOFF_PATH)}`);
        return { status: "configured", names: [...SERVER_ENVIRONMENT_NAMES] };
      } catch (error) {
        if (error instanceof ManualHostingError) throw error;
        if (error instanceof ProtectedStorageError) {
          return fail("manual_protected_storage_unavailable");
        }
        return fail("manual_protected_storage_unavailable");
      }
    },
    handoffStatus,
    async confirmHandoff(projectDir, receiptInput) {
      const { receipt, target } = await validateReceipt(receiptInput);
      if (projects.get(receipt.digest) !== (await ProjectFilesystem.open(projectDir)).root) {
        return fail("manual_handoff_conflict");
      }
      let store: ProtectedFiles;
      try {
        store = await protectedFiles(projectDir);
        if (!await store.exists(HANDOFF_PATH)) return fail("manual_handoff_missing");
        const handoff = parseHandoff(JSON.parse(await store.read(HANDOFF_PATH)));
        if (handoff.receiptDigest !== receipt.digest || !sameTarget(handoff.target, target)) {
          return fail("manual_handoff_conflict");
        }
        const acknowledgment: ManualAcknowledgment = {
          schemaVersion: 1,
          receiptDigest: receipt.digest,
          target,
          names: [...SERVER_ENVIRONMENT_NAMES],
          acknowledgedAt: options.now().toISOString(),
        };
        const files = await ProjectFilesystem.open(projectDir);
        if (await files.exists(ACKNOWLEDGMENT_PATH)) {
          const existing = parseAcknowledgment(JSON.parse(await files.read(ACKNOWLEDGMENT_PATH)));
          if (!sameTarget(existing.target, target)) return fail("manual_handoff_conflict");
          if (existing.receiptDigest !== receipt.digest) {
            await files.writeAtomic(
              ACKNOWLEDGMENT_PATH,
              `${JSON.stringify(acknowledgment, null, 2)}\n`,
              `.hosting-handoff-acknowledgement.${randomUUID()}.tmp`,
            );
          }
        } else {
          await files.writeExclusive(ACKNOWLEDGMENT_PATH, `${JSON.stringify(acknowledgment, null, 2)}\n`);
        }
        await store.remove(HANDOFF_DIRECTORY, true);
        if (await store.exists(HANDOFF_DIRECTORY)) return fail("manual_protected_storage_unavailable");
        await completeSetupJournal(projectDir, receipt.digest, options);
        return { status: "acknowledged", target, names: [...SERVER_ENVIRONMENT_NAMES] };
      } catch (error) {
        if (error instanceof ManualHostingError) throw error;
        return fail("manual_protected_storage_unavailable");
      }
    },
    async cleanupHandoff(projectDir) {
      const files = await ProjectFilesystem.open(projectDir);
      if (!await files.exists(SECRETS_ROOT)) return { status: "cleaned" };
      try {
        const store = await protectedFiles(projectDir);
        if (await store.exists(HANDOFF_DIRECTORY)) await store.remove(HANDOFF_DIRECTORY, true);
        if (await store.exists(HANDOFF_DIRECTORY)) return fail("manual_protected_storage_unavailable");
        return { status: "cleaned" };
      } catch (error) {
        if (error instanceof ManualHostingError) throw error;
        return fail("manual_protected_storage_unavailable");
      }
    },
    async verifyConfiguration(receiptInput) {
      const { receipt, projectDir, target } = await validateReceipt(receiptInput);
      if ((await handoffStatus(projectDir)).status !== "absent") {
        return fail("manual_acknowledgment_missing");
      }
      const files = await ProjectFilesystem.open(projectDir);
      if (!await files.exists(ACKNOWLEDGMENT_PATH)) return fail("manual_acknowledgment_missing");
      const acknowledgment = parseAcknowledgment(JSON.parse(await files.read(ACKNOWLEDGMENT_PATH)));
      if (acknowledgment.receiptDigest !== receipt.digest || !sameTarget(acknowledgment.target, target)) {
        return fail("manual_acknowledgment_missing");
      }
      return { status: "acknowledged", target, names: [...SERVER_ENVIRONMENT_NAMES] };
    },
  };
}
