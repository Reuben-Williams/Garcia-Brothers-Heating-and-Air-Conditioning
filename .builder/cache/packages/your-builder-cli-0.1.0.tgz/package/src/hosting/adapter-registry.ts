import type { HostingAdapter, HostingProvider } from "./contracts.js";

export type HostingAdapterRegistryErrorCode =
  | "duplicate_hosting_adapter"
  | "hosting_adapter_unavailable";

export class HostingAdapterRegistryError extends Error {
  constructor(public readonly code: HostingAdapterRegistryErrorCode) {
    super(code);
    this.name = "HostingAdapterRegistryError";
  }
}

export interface HostingAdapterRegistry {
  ids(): readonly HostingProvider[];
  get(id: HostingProvider): HostingAdapter;
}

export function createHostingAdapterRegistry(adapters: readonly HostingAdapter[]): HostingAdapterRegistry {
  const byId = new Map<HostingProvider, HostingAdapter>();
  for (const adapter of adapters) {
    if (adapter.id !== "netlify" && adapter.id !== "manual") {
      throw new HostingAdapterRegistryError("hosting_adapter_unavailable");
    }
    if (byId.has(adapter.id)) throw new HostingAdapterRegistryError("duplicate_hosting_adapter");
    byId.set(adapter.id, adapter);
  }
  return Object.freeze({
    ids: () => [...byId.keys()].sort(),
    get: (id: HostingProvider) => {
      const adapter = byId.get(id);
      if (!adapter) throw new HostingAdapterRegistryError("hosting_adapter_unavailable");
      return adapter;
    },
  });
}
