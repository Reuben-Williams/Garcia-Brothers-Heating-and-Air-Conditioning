import { inspect } from "node:util";

import { canonicalSha256 } from "./canonical-receipt.js";

export type HostingProvider = "netlify" | "manual";

export interface HostingTarget {
  provider: HostingProvider;
  accountId: string;
  siteId: string;
  siteName: string;
  context: string;
  branch: string | null;
  scopes: readonly string[];
}

export interface PreflightReceipt {
  schemaVersion: 1;
  target: HostingTarget;
  projectFingerprint: string;
  linkedStateHash: string;
  issuedAt: string;
  expiresAt: string;
  digest: string;
}

export interface ConfigureResult {
  status: "configured";
  names: readonly ServerEnvironmentName[];
}

export interface ProviderVerifyResult {
  status: "verified" | "acknowledged";
  target: HostingTarget;
  names: readonly ServerEnvironmentName[];
}

export interface DetectionResult {
  status: "detected";
  target: HostingTarget;
}

export interface HostingAdapter {
  id: HostingProvider;
  detect(projectDir: string): Promise<DetectionResult>;
  preflight(projectDir: string, target: HostingTarget): Promise<PreflightReceipt>;
  configure(input: ServerEnvironmentInput, receipt: PreflightReceipt): Promise<ConfigureResult>;
  verifyConfiguration(receipt: PreflightReceipt): Promise<ProviderVerifyResult>;
}

export const SERVER_ENVIRONMENT_NAMES = [
  "BUILDER_CONTROL_PLANE_URL",
  "BUILDER_INSTALLATION_ID",
  "BUILDER_INSTALLATION_KEY_ID",
  "BUILDER_INSTALLATION_PRIVATE_JWK",
] as const;

export type ServerEnvironmentName = typeof SERVER_ENVIRONMENT_NAMES[number];
export type ServerEnvironmentValues = Record<ServerEnvironmentName, string>;

export interface ServerEnvironmentInput {
  names(): readonly ServerEnvironmentName[];
  reveal(): ServerEnvironmentValues;
  toJSON(): "[REDACTED]";
  toString(): "[REDACTED]";
}

export type HostingContractErrorCode =
  | "invalid_hosting_target"
  | "invalid_preflight_receipt"
  | "invalid_configure_result"
  | "invalid_provider_verify_result"
  | "invalid_server_environment"
  | "preflight_expired"
  | "preflight_future_dated"
  | "preflight_drift";

export class HostingContractError extends Error {
  constructor(public readonly code: HostingContractErrorCode) {
    super(code);
    this.name = "HostingContractError";
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function hasExactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join("\0") === [...keys].sort().join("\0");
}

function fail(code: HostingContractErrorCode): never {
  throw new HostingContractError(code);
}

function parseBoundedString(value: unknown, code: HostingContractErrorCode): string {
  if (
    typeof value !== "string" ||
    value.length < 1 ||
    value.length > 256 ||
    value.trim() !== value ||
    /[\u0000-\u001f\u007f]/.test(value)
  ) {
    return fail(code);
  }
  return value;
}

function parseSha256(value: unknown, code: HostingContractErrorCode): string {
  if (typeof value !== "string" || !/^[a-f0-9]{64}$/.test(value)) return fail(code);
  return value;
}

function parseIsoTimestamp(value: unknown, code: HostingContractErrorCode): string {
  if (typeof value !== "string") return fail(code);
  const parsed = new Date(value);
  if (!Number.isFinite(parsed.getTime()) || parsed.toISOString() !== value) return fail(code);
  return value;
}

function parseScopes(value: unknown, code: HostingContractErrorCode): readonly string[] {
  if (!Array.isArray(value) || value.length < 1 || value.length > 16) return fail(code);
  const scopes = value.map((scope) => {
    if (
      typeof scope !== "string" ||
      !/^[a-z][a-z0-9:-]{0,63}$/.test(scope) ||
      scope.includes("*")
    ) {
      return fail(code);
    }
    return scope;
  }).sort();
  if (new Set(scopes).size !== scopes.length) return fail(code);
  return scopes;
}

function parseEnvironmentNames(value: unknown, code: HostingContractErrorCode): readonly ServerEnvironmentName[] {
  if (!Array.isArray(value)) return fail(code);
  const actual = value.every((name) => typeof name === "string") ? [...value].sort() : [];
  const expected = [...SERVER_ENVIRONMENT_NAMES].sort();
  if (actual.join("\0") !== expected.join("\0")) return fail(code);
  return [...SERVER_ENVIRONMENT_NAMES];
}

export function parseHostingTarget(value: unknown): HostingTarget {
  const code = "invalid_hosting_target";
  if (!isRecord(value) || !hasExactKeys(value, [
    "provider",
    "accountId",
    "siteId",
    "siteName",
    "context",
    "branch",
    "scopes",
  ])) return fail(code);
  if (value.provider !== "netlify" && value.provider !== "manual") return fail(code);
  if (value.branch !== null && typeof value.branch !== "string") return fail(code);
  const branch = value.branch === null ? null : parseBoundedString(value.branch, code);
  return {
    provider: value.provider,
    accountId: parseBoundedString(value.accountId, code),
    siteId: parseBoundedString(value.siteId, code),
    siteName: parseBoundedString(value.siteName, code),
    context: parseBoundedString(value.context, code),
    branch,
    scopes: parseScopes(value.scopes, code),
  };
}

function receiptBody(receipt: Omit<PreflightReceipt, "digest">): Omit<PreflightReceipt, "digest"> {
  return {
    schemaVersion: 1,
    target: parseHostingTarget(receipt.target),
    projectFingerprint: parseSha256(receipt.projectFingerprint, "invalid_preflight_receipt"),
    linkedStateHash: parseSha256(receipt.linkedStateHash, "invalid_preflight_receipt"),
    issuedAt: parseIsoTimestamp(receipt.issuedAt, "invalid_preflight_receipt"),
    expiresAt: parseIsoTimestamp(receipt.expiresAt, "invalid_preflight_receipt"),
  };
}

export function createPreflightReceipt(input: {
  target: HostingTarget;
  projectFingerprint: string;
  linkedStateHash: string;
  issuedAt: string;
}): PreflightReceipt {
  const issuedAt = parseIsoTimestamp(input.issuedAt, "invalid_preflight_receipt");
  const expiresAt = new Date(new Date(issuedAt).getTime() + 600_000).toISOString();
  const body = receiptBody({
    schemaVersion: 1,
    target: input.target,
    projectFingerprint: input.projectFingerprint,
    linkedStateHash: input.linkedStateHash,
    issuedAt,
    expiresAt,
  });
  return { ...body, digest: canonicalSha256(body) };
}

export function parsePreflightReceipt(value: unknown): PreflightReceipt {
  const code = "invalid_preflight_receipt";
  if (!isRecord(value) || !hasExactKeys(value, [
    "schemaVersion",
    "target",
    "projectFingerprint",
    "linkedStateHash",
    "issuedAt",
    "expiresAt",
    "digest",
  ]) || value.schemaVersion !== 1) return fail(code);
  let target: HostingTarget;
  try {
    target = parseHostingTarget(value.target);
  } catch {
    return fail(code);
  }
  const body = receiptBody({
    schemaVersion: 1,
    target,
    projectFingerprint: value.projectFingerprint as string,
    linkedStateHash: value.linkedStateHash as string,
    issuedAt: value.issuedAt as string,
    expiresAt: value.expiresAt as string,
  });
  const digest = parseSha256(value.digest, code);
  if (new Date(body.expiresAt).getTime() - new Date(body.issuedAt).getTime() !== 600_000) {
    return fail(code);
  }
  if (canonicalSha256(body) !== digest) return fail(code);
  return { ...body, digest };
}

export function assertCurrentPreflight(input: {
  receipt: PreflightReceipt;
  detectedTarget: HostingTarget;
  projectFingerprint: string;
  linkedStateHash: string;
  now: Date;
}): { siteNameChanged: boolean } {
  const receipt = parsePreflightReceipt(input.receipt);
  const detected = parseHostingTarget(input.detectedTarget);
  const now = input.now.getTime();
  const issued = new Date(receipt.issuedAt).getTime();
  const expires = new Date(receipt.expiresAt).getTime();
  if (!Number.isFinite(now)) return fail("invalid_preflight_receipt");
  if (now < issued) return fail("preflight_future_dated");
  if (now > expires) return fail("preflight_expired");

  const immutableReceipt = {
    provider: receipt.target.provider,
    accountId: receipt.target.accountId,
    siteId: receipt.target.siteId,
    context: receipt.target.context,
    branch: receipt.target.branch,
    scopes: receipt.target.scopes,
  };
  const immutableDetected = {
    provider: detected.provider,
    accountId: detected.accountId,
    siteId: detected.siteId,
    context: detected.context,
    branch: detected.branch,
    scopes: detected.scopes,
  };
  if (
    canonicalSha256(immutableReceipt) !== canonicalSha256(immutableDetected) ||
    input.projectFingerprint !== receipt.projectFingerprint ||
    input.linkedStateHash !== receipt.linkedStateHash
  ) return fail("preflight_drift");
  return { siteNameChanged: receipt.target.siteName !== detected.siteName };
}

export function parseConfigureResult(value: unknown): ConfigureResult {
  const code = "invalid_configure_result";
  if (!isRecord(value) || !hasExactKeys(value, ["status", "names"]) || value.status !== "configured") {
    return fail(code);
  }
  return { status: "configured", names: parseEnvironmentNames(value.names, code) };
}

export function parseProviderVerifyResult(value: unknown): ProviderVerifyResult {
  const code = "invalid_provider_verify_result";
  if (
    !isRecord(value) ||
    !hasExactKeys(value, ["status", "target", "names"]) ||
    (value.status !== "verified" && value.status !== "acknowledged")
  ) {
    return fail(code);
  }
  let target: HostingTarget;
  try {
    target = parseHostingTarget(value.target);
  } catch {
    return fail(code);
  }
  return { status: value.status, target, names: parseEnvironmentNames(value.names, code) };
}

class RedactedServerEnvironmentInput implements ServerEnvironmentInput {
  readonly #values: ServerEnvironmentValues;

  constructor(values: ServerEnvironmentValues) {
    this.#values = Object.freeze({ ...values });
  }

  names(): readonly ServerEnvironmentName[] {
    return [...SERVER_ENVIRONMENT_NAMES];
  }

  reveal(): ServerEnvironmentValues {
    return { ...this.#values };
  }

  toJSON(): "[REDACTED]" {
    return "[REDACTED]";
  }

  toString(): "[REDACTED]" {
    return "[REDACTED]";
  }

  [inspect.custom](): "[REDACTED]" {
    return "[REDACTED]";
  }
}

export function createServerEnvironmentInput(value: ServerEnvironmentValues): ServerEnvironmentInput {
  const code = "invalid_server_environment";
  if (!isRecord(value) || !hasExactKeys(value, SERVER_ENVIRONMENT_NAMES)) return fail(code);
  const parsed = Object.fromEntries(SERVER_ENVIRONMENT_NAMES.map((name) => [
    name,
    parseBoundedString(value[name], code),
  ])) as ServerEnvironmentValues;
  return new RedactedServerEnvironmentInput(parsed);
}
