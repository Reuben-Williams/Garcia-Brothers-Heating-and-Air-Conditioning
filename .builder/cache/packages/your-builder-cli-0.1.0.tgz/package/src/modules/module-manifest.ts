const MODULE_ID = /^[a-z][a-z0-9-]*(?:\.[a-z][a-z0-9-]*)+$/;
const PACKAGE_NAME = /^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*$/;
const SEMVER = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;
const SCHEMA_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
const ROUTE = /^\/(?!\/)[^\s?#\\\u0000-\u001f\u007f]*$/;
const MAX_ENTRIES = 256;

export interface ModuleCompatibilityRequirements {
  readonly packages: Readonly<Record<string, string>>;
  readonly schemas: Readonly<Record<string, number>>;
  readonly routes: readonly string[];
  readonly minimumWorkerVersion?: string;
}

export interface BuilderModuleManifest {
  readonly manifestVersion: 1;
  readonly moduleId: string;
  readonly moduleVersion: string;
  readonly requirements: ModuleCompatibilityRequirements;
}

export class ModuleManifestError extends Error {
  readonly code = "INVALID_MODULE_MANIFEST";

  constructor() {
    super("INVALID_MODULE_MANIFEST");
    this.name = "ModuleManifestError";
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function exactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join(",") === [...keys].sort().join(",");
}

function validRecord(
  value: unknown,
  keyPattern: RegExp,
  validate: (entry: unknown) => boolean,
): value is Record<string, never> {
  return isRecord(value) &&
    Object.keys(value).length <= MAX_ENTRIES &&
    Object.entries(value).every(([key, entry]) => keyPattern.test(key) && validate(entry));
}

export function parseModuleManifest(value: unknown): BuilderModuleManifest {
  if (!isRecord(value) || !exactKeys(value, [
    "manifestVersion", "moduleId", "moduleVersion", "requirements",
  ])) {
    throw new ModuleManifestError();
  }
  if (!isRecord(value.requirements)) throw new ModuleManifestError();
  const requirements = value.requirements;
  const requirementKeys = requirements.minimumWorkerVersion === undefined
    ? ["packages", "schemas", "routes"]
    : ["packages", "schemas", "routes", "minimumWorkerVersion"];
  if (
    value.manifestVersion !== 1 ||
    typeof value.moduleId !== "string" || !MODULE_ID.test(value.moduleId) ||
    typeof value.moduleVersion !== "string" || !SEMVER.test(value.moduleVersion) ||
    !exactKeys(requirements, requirementKeys) ||
    !validRecord(requirements.packages, PACKAGE_NAME, (entry) =>
      typeof entry === "string" && SEMVER.test(entry)) ||
    !validRecord(requirements.schemas, SCHEMA_ID, (entry) =>
      Number.isSafeInteger(entry) && (entry as number) >= 0 && (entry as number) <= 1_000_000) ||
    !Array.isArray(requirements.routes) || requirements.routes.length > MAX_ENTRIES ||
    requirements.routes.some((route) => typeof route !== "string" || !ROUTE.test(route)) ||
    new Set(requirements.routes).size !== requirements.routes.length ||
    (requirements.minimumWorkerVersion !== undefined &&
      (typeof requirements.minimumWorkerVersion !== "string" ||
        !SEMVER.test(requirements.minimumWorkerVersion)))
  ) {
    throw new ModuleManifestError();
  }
  return Object.freeze({
    manifestVersion: 1,
    moduleId: value.moduleId,
    moduleVersion: value.moduleVersion,
    requirements: Object.freeze({
      packages: Object.freeze({ ...requirements.packages }),
      schemas: Object.freeze({ ...requirements.schemas }),
      routes: Object.freeze([...requirements.routes]),
      ...(requirements.minimumWorkerVersion === undefined
        ? {}
        : { minimumWorkerVersion: requirements.minimumWorkerVersion }),
    }),
  });
}

export function parseReleaseVersion(value: string): readonly [bigint, bigint, bigint, string | undefined] | null {
  const match = SEMVER.exec(value);
  if (!match) return null;
  return [BigInt(match[1]!), BigInt(match[2]!), BigInt(match[3]!), match[4]];
}
