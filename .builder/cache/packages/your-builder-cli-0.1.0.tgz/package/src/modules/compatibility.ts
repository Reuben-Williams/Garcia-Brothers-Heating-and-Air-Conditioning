import { readFile } from "node:fs/promises";
import { join, resolve } from "node:path";

import {
  parseInstallationManifest,
  type InstallationManifestInput,
} from "../control-plane/register-installation.js";
import {
  parseModuleManifest,
  parseReleaseVersion,
  type BuilderModuleManifest,
} from "./module-manifest.js";

export type ModuleCompatibilityIssueCode =
  | "MISSING_PACKAGE"
  | "PACKAGE_VERSION_TOO_OLD"
  | "MISSING_SCHEMA"
  | "SCHEMA_VERSION_TOO_OLD"
  | "MISSING_ROUTE"
  | "MISSING_WORKER"
  | "WORKER_VERSION_TOO_OLD";

export interface ModuleCompatibilityIssue {
  readonly code: ModuleCompatibilityIssueCode;
  readonly requirement: string;
  readonly required: string | number;
  readonly installed: string | number | null;
  readonly migrationRequired: boolean;
  readonly instruction: string;
}

export interface ModuleCompatibilityReport {
  readonly compatible: boolean;
  readonly mutatesFiles: false;
  readonly issues: readonly ModuleCompatibilityIssue[];
}

function comparePrerelease(left: string | undefined, right: string | undefined): number {
  if (left === right) return 0;
  if (left === undefined) return 1;
  if (right === undefined) return -1;
  const leftParts = left.split(".");
  const rightParts = right.split(".");
  for (let index = 0; index < Math.max(leftParts.length, rightParts.length); index += 1) {
    const a = leftParts[index];
    const b = rightParts[index];
    if (a === b) continue;
    if (a === undefined) return -1;
    if (b === undefined) return 1;
    const aNumeric = /^\d+$/.test(a);
    const bNumeric = /^\d+$/.test(b);
    if (aNumeric && bNumeric) return Number(a) - Number(b);
    if (aNumeric !== bNumeric) return aNumeric ? -1 : 1;
    return a.localeCompare(b);
  }
  return 0;
}

function versionAtLeast(installed: string, required: string): boolean {
  const actual = parseReleaseVersion(installed);
  const minimum = parseReleaseVersion(required);
  if (!actual || !minimum) return false;
  for (let index = 0; index < 3; index += 1) {
    if (actual[index] !== minimum[index]) return (actual[index] as bigint) > (minimum[index] as bigint);
  }
  return comparePrerelease(actual[3], minimum[3]) >= 0;
}

function issue(
  code: ModuleCompatibilityIssueCode,
  requirement: string,
  required: string | number,
  installed: string | number | null,
  instruction: string,
  migrationRequired = false,
): ModuleCompatibilityIssue {
  return { code, requirement, required, installed, migrationRequired, instruction };
}

export function checkModuleCompatibility(input: {
  module: BuilderModuleManifest;
  installation: InstallationManifestInput;
}): ModuleCompatibilityReport {
  const issues: ModuleCompatibilityIssue[] = [];
  for (const [packageName, required] of Object.entries(input.module.requirements.packages)) {
    const installed = input.installation.packages[packageName];
    if (installed === undefined) {
      issues.push(issue("MISSING_PACKAGE", `package:${packageName}`, required, null,
        `Install ${packageName} at version ${required} or newer.`));
    } else if (!versionAtLeast(installed, required)) {
      issues.push(issue("PACKAGE_VERSION_TOO_OLD", `package:${packageName}`, required, installed,
        `Upgrade ${packageName} from ${installed} to ${required} or newer.`));
    }
  }
  for (const [schemaName, required] of Object.entries(input.module.requirements.schemas)) {
    const installed = input.installation.schemas[schemaName];
    if (installed === undefined) {
      issues.push(issue("MISSING_SCHEMA", `schema:${schemaName}`, required, null,
        `Apply the reviewed ${schemaName} schema migration through version ${required}.`, true));
    } else if (installed < required) {
      issues.push(issue("SCHEMA_VERSION_TOO_OLD", `schema:${schemaName}`, required, installed,
        `Apply the reviewed ${schemaName} schema migration from ${installed} through ${required}.`, true));
    }
  }
  const installedRoutes = new Set(input.installation.routes);
  for (const route of input.module.requirements.routes) {
    if (!installedRoutes.has(route)) {
      issues.push(issue("MISSING_ROUTE", `route:${route}`, route, null,
        `Add and review the required route ${route}.`));
    }
  }
  const requiredWorker = input.module.requirements.minimumWorkerVersion;
  if (requiredWorker !== undefined) {
    const installed = input.installation.workerVersion;
    if (installed === undefined) {
      issues.push(issue("MISSING_WORKER", "worker", requiredWorker, null,
        `Install the command worker at version ${requiredWorker} or newer.`));
    } else if (!versionAtLeast(installed, requiredWorker)) {
      issues.push(issue("WORKER_VERSION_TOO_OLD", "worker", requiredWorker, installed,
        `Upgrade the command worker from ${installed} to ${requiredWorker} or newer.`));
    }
  }
  return { compatible: issues.length === 0, mutatesFiles: false, issues };
}

function parseJson(text: string): unknown {
  return JSON.parse(text) as unknown;
}

function packageVersions(value: unknown): Record<string, string> {
  if (!value || Array.isArray(value) || typeof value !== "object") return {};
  const packageJson = value as Record<string, unknown>;
  const versions: Record<string, string> = {};
  for (const field of ["dependencies", "optionalDependencies", "devDependencies"] as const) {
    const entries = packageJson[field];
    if (!entries || Array.isArray(entries) || typeof entries !== "object") continue;
    for (const [name, version] of Object.entries(entries as Record<string, unknown>)) {
      if (typeof version === "string" && parseReleaseVersion(version)) versions[name] = version;
    }
  }
  return versions;
}

export async function runModuleAttachCheck(input: {
  projectDir: string;
  installationManifestPath?: string;
  moduleManifestPath?: string;
}): Promise<ModuleCompatibilityReport> {
  const projectDir = resolve(input.projectDir);
  const [installationText, moduleText, packageText] = await Promise.all([
    readFile(input.installationManifestPath ?? join(projectDir, ".builder", "installation-manifest.json"), "utf8"),
    readFile(input.moduleManifestPath ?? join(projectDir, ".builder", "module-manifest.json"), "utf8"),
    readFile(join(projectDir, "package.json"), "utf8"),
  ]);
  const installation = parseInstallationManifest(parseJson(installationText));
  const packages = { ...packageVersions(parseJson(packageText)), ...installation.packages };
  return checkModuleCompatibility({
    module: parseModuleManifest(parseJson(moduleText)),
    installation: { ...installation, packages },
  });
}

export function formatModuleCompatibility(report: ModuleCompatibilityReport): string {
  if (report.compatible) return "Module compatibility check passed.";
  return report.issues.map((entry) =>
    `[${entry.code}] ${entry.requirement}: required ${entry.required}, installed ${entry.installed ?? "missing"}. ${entry.instruction}`,
  ).join("\n");
}
