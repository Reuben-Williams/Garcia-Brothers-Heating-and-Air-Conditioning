import { createHash, generateKeyPairSync, randomBytes as nodeRandomBytes } from "node:crypto";
import { join } from "node:path";

import {
  INSTALLATION_REQUEST_HEADER_NAMES,
  REGISTRATION_REQUEST_HEADER_NAMES,
  normalizeExportedEd25519PublicJwk,
  parseInstallationManifest as parseSharedInstallationManifest,
  signInstallationRequest,
  signRegistrationProof,
  type InstallationManifestInput,
} from "@your-builder/entitlements/trust";

import { ProjectFilesystem, UnsafeProjectPathError } from "./project-filesystem.js";
import {
  ProtectedFiles,
  ProtectedStorageError,
  type ProtectedFilesOptions,
} from "./protected-files.js";

const REGISTER_PATH = "/api/platform/v1/installations/register";
const ROTATE_PATH = "/api/platform/v1/installations/credentials/rotate";
const BUILDER_DIRECTORY = ".builder";
const SECRETS_DIRECTORY = join(BUILDER_DIRECTORY, "secrets");
const PRIVATE_PATH = join(SECRETS_DIRECTORY, "installation-private.jwk");
const REVIEW_PATH = join(BUILDER_DIRECTORY, "installation-registration.json");
const REGISTRATION_PENDING = join(SECRETS_DIRECTORY, "installation-registration.pending");
const REGISTRATION_SECRET = join(REGISTRATION_PENDING, "installation-private.jwk");
const REGISTRATION_REQUEST = join(REGISTRATION_PENDING, "request.json");
const REGISTRATION_METADATA = join(REGISTRATION_PENDING, "metadata.json");
const REGISTRATION_REBIND = join(REGISTRATION_PENDING, "rebind.json");
const ROTATION_PENDING = join(SECRETS_DIRECTORY, "installation-rotation.pending");
const ROTATION_CURRENT_SECRET = join(ROTATION_PENDING, "current-private.jwk");
const ROTATION_NEXT_SECRET = join(ROTATION_PENDING, "next-private.jwk");
const ROTATION_REQUEST = join(ROTATION_PENDING, "request.json");
const ROTATION_METADATA = join(ROTATION_PENDING, "metadata.json");
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const KEY_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const STABLE_SITE_KEY_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const BASE64URL_32_PATTERN = /^[A-Za-z0-9_-]{43}$/;
const MAX_RESPONSE_BYTES = 256 * 1024;
const encoder = new TextEncoder();

export type { InstallationManifestInput } from "@your-builder/entitlements/trust";

export interface RegistrationCliOutput {
  info(line: string): void;
  warn(line: string): void;
}

export interface RegisterInstallationDependencies {
  fetch?: typeof globalThis.fetch;
  output?: RegistrationCliOutput;
  now?: () => Date;
  randomBytes?: (size: number) => Uint8Array;
  maxAttempts?: number;
  platform?: NodeJS.Platform;
  protectedFiles?: Omit<ProtectedFilesOptions, "platform">;
  generateKeyPair?: () => { publicJwk: JsonWebKey; privateJwk: JsonWebKey };
  rebindCheckpoint?: (checkpoint: RebindCheckpoint) => void | Promise<void>;
}

export type RebindCheckpoint = "binding_staged" | "binding_promoted";

export interface RebindInstallationInput {
  projectDir: string;
  exchangeToken: string;
  expectedInstallationId: string;
}

export type RegisterInstallationInput =
  | {
      projectDir: string;
      rotate?: false;
      controlPlaneUrl: string;
      exchangeToken: string;
      stableSiteKey: string;
      publicUrl: string;
      manifest: InstallationManifestInput;
    }
  | { projectDir: string; rotate: true; overlapSeconds?: number };

export type RegistrationCliErrorCode =
  | "invalid_arguments"
  | "invalid_manifest"
  | "invalid_control_plane_url"
  | "private_key_exists"
  | "pending_registration_mismatch"
  | "pending_state_invalid"
  | "registration_ambiguous"
  | "registration_failed"
  | "invalid_registration_response"
  | "installation_id_mismatch"
  | "registration_already_accepted"
  | "rotation_ambiguous"
  | "rotation_failed"
  | "invalid_rotation_response";

export class RegistrationCliError extends Error {
  constructor(public readonly code: RegistrationCliErrorCode, public readonly status?: number) {
    super(code);
    this.name = "RegistrationCliError";
  }
}

interface PublicJwk {
  kty: "OKP";
  crv: "Ed25519";
  alg: "EdDSA";
  x: string;
}

interface RegistrationResponse {
  installationId: string;
  acceptedKeyId: string;
  publicSigningKeys: unknown[];
  endpoints: {
    pullCommands: string;
    submitCommandResult: string;
    reportHealth: string;
    rotateCredential: string;
  };
}

interface ReviewManifest extends RegistrationResponse {
  version: 1;
  controlPlaneUrl: string;
  stableSiteKey: string;
  publicUrl: string;
  registeredAt: string;
}

interface ResolvedDependencies {
  fetch: typeof globalThis.fetch;
  output: RegistrationCliOutput;
  now: () => Date;
  randomBytes: (size: number) => Uint8Array;
  maxAttempts: number;
  platform: NodeJS.Platform;
  protectedFiles: Omit<ProtectedFilesOptions, "platform">;
  generateKeyPair: () => { publicJwk: JsonWebKey; privateJwk: JsonWebKey };
  rebindCheckpoint: (checkpoint: RebindCheckpoint) => Promise<void>;
}

interface RegistrationRequestBody {
  exchangeToken: string;
  stableSiteKey: string;
  publicUrl: string;
  keyId: string;
  publicJwk: PublicJwk;
  manifest: InstallationManifestInput;
}

interface RegistrationPendingMetadata {
  version: 2;
  operation: "register";
  keyId: string;
  controlPlaneUrl: string;
  stableSiteKey: string;
  publicUrl: string;
  manifestSha256: string;
  publicJwkSha256: string;
  identitySha256: string;
  bodySha256: string;
  createdAt: string;
}

interface RegistrationRebindBinding {
  version: 1;
  operation: "rebind";
  expectedInstallationId: string;
  identitySha256: string;
  bodySha256: string;
  body: string;
  proof: string;
  reboundAt: string;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function exactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join(",") === [...keys].sort().join(",");
}

function failure(code: RegistrationCliErrorCode, status?: number): never {
  throw new RegistrationCliError(code, status);
}

function normalizeControlPlaneUrl(value: unknown): string {
  if (typeof value !== "string" || value.trim() !== value || value.length > 2_048) {
    return failure("invalid_control_plane_url");
  }
  try {
    const url = new URL(value);
    const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
    if (
      (url.protocol !== "https:" && !(url.protocol === "http:" && loopback)) ||
      url.username ||
      url.password ||
      url.search ||
      url.hash
    ) {
      return failure("invalid_control_plane_url");
    }
    return url.href.replace(/\/$/, "");
  } catch {
    return failure("invalid_control_plane_url");
  }
}

export function parseInstallationManifest(value: unknown): InstallationManifestInput {
  try {
    return parseSharedInstallationManifest(value);
  } catch {
    return failure("invalid_manifest");
  }
}

function isCanonicalBase64Url32(value: unknown): value is string {
  if (typeof value !== "string" || !BASE64URL_32_PATTERN.test(value)) return false;
  try {
    const bytes = Buffer.from(value, "base64url");
    return bytes.byteLength === 32 && bytes.toString("base64url") === value;
  } catch {
    return false;
  }
}

function parsePrivateJwk(value: unknown): JsonWebKey {
  if (
    !isRecord(value) ||
    !exactKeys(value, ["alg", "crv", "d", "kty", "x"]) ||
    value.kty !== "OKP" ||
    value.crv !== "Ed25519" ||
    value.alg !== "EdDSA" ||
    !isCanonicalBase64Url32(value.x) ||
    !isCanonicalBase64Url32(value.d)
  ) {
    return failure("pending_state_invalid");
  }
  return value as JsonWebKey;
}

function publicFromPrivate(privateJwk: JsonWebKey): PublicJwk {
  return normalizeExportedEd25519PublicJwk({
    kty: privateJwk.kty,
    crv: privateJwk.crv,
    x: privateJwk.x,
  });
}

function defaultGenerateKeyPair(): { publicJwk: PublicJwk; privateJwk: JsonWebKey } {
  const pair = generateKeyPairSync("ed25519");
  const publicJwk = normalizeExportedEd25519PublicJwk(pair.publicKey.export({ format: "jwk" }));
  const privateJwk = parsePrivateJwk({
    ...pair.privateKey.export({ format: "jwk" }),
    alg: "EdDSA",
  });
  return { publicJwk, privateJwk };
}

function parseJson(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return failure("pending_state_invalid");
  }
}

async function readJson(files: Pick<ProjectFilesystem, "read">, path: string): Promise<unknown> {
  return parseJson(await files.read(path));
}

function sha256(value: string): string {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

function randomName(prefix: string, randomBytes: (size: number) => Uint8Array): string {
  return `${prefix}.${Buffer.from(randomBytes(8)).toString("hex")}.tmp`;
}

async function writeAtomic(
  files: ProjectFilesystem,
  path: string,
  contents: string,
  dependencies: ResolvedDependencies,
): Promise<void> {
  await files.writeAtomic(
    path,
    contents,
    randomName(".builder-write", dependencies.randomBytes),
  );
}

async function cleanupStaleTemps(files: ProtectedFiles, prefix: string): Promise<void> {
  for (const name of await files.list(SECRETS_DIRECTORY)) {
    if (name.startsWith(`.${prefix}.`) && name.endsWith(".tmp")) {
      await files.remove(join(SECRETS_DIRECTORY, name), true);
    }
  }
}

async function stageDirectory(input: {
  files: ProtectedFiles;
  canonical: string;
  prefix: string;
  entries: Array<{ name: string; contents: string; secret?: boolean }>;
  dependencies: ResolvedDependencies;
}): Promise<void> {
  const temporaryName = randomName(`.${input.prefix}`, input.dependencies.randomBytes);
  const temporary = join(SECRETS_DIRECTORY, temporaryName);
  await input.files.ensureDirectory(temporary);
  for (const entry of input.entries) {
    const path = join(temporary, entry.name);
    await input.files.writeExclusive(path, entry.contents);
  }
  await input.files.sync(temporary).catch(() => undefined);
  await input.files.rename(temporary, input.canonical);
}

function createKeyId(now: Date, randomBytes: (size: number) => Uint8Array): string {
  const date = now.toISOString().slice(0, 10).replaceAll("-", "");
  return `key-${date}-${Buffer.from(randomBytes(8)).toString("base64url")}`;
}

function parsePublicSigningKey(value: unknown): boolean {
  if (
    !isRecord(value) ||
    !exactKeys(value, ["keyId", "publicJwk", "algorithm", "validFrom", "validUntil"]) ||
    typeof value.keyId !== "string" ||
    !KEY_ID_PATTERN.test(value.keyId) ||
    value.algorithm !== "EdDSA" ||
    typeof value.validFrom !== "string" ||
    (value.validUntil !== null && typeof value.validUntil !== "string") ||
    !isRecord(value.publicJwk)
  ) return false;
  try {
    normalizeExportedEd25519PublicJwk(value.publicJwk as JsonWebKey);
    return exactKeys(value.publicJwk, ["kty", "crv", "alg", "x"]) && value.publicJwk.alg === "EdDSA";
  } catch {
    return false;
  }
}

function parseRegistrationResponse(value: unknown, expectedKeyId: string): RegistrationResponse {
  if (
    !isRecord(value) ||
    !exactKeys(value, ["installationId", "acceptedKeyId", "publicSigningKeys", "endpoints"]) ||
    typeof value.installationId !== "string" ||
    !UUID_PATTERN.test(value.installationId) ||
    value.acceptedKeyId !== expectedKeyId ||
    !Array.isArray(value.publicSigningKeys) ||
    value.publicSigningKeys.length > 64 ||
    !value.publicSigningKeys.every(parsePublicSigningKey) ||
    !isRecord(value.endpoints) ||
    !exactKeys(value.endpoints, ["pullCommands", "submitCommandResult", "reportHealth", "rotateCredential"]) ||
    value.endpoints.pullCommands !== "/api/platform/v1/installations/commands/pull" ||
    value.endpoints.submitCommandResult !== "/api/platform/v1/installations/commands/{commandId}/result" ||
    value.endpoints.reportHealth !== "/api/platform/v1/installations/health" ||
    value.endpoints.rotateCredential !== ROTATE_PATH
  ) return failure("invalid_registration_response");
  return value as unknown as RegistrationResponse;
}

function parseReview(value: unknown): ReviewManifest {
  if (
    !isRecord(value) ||
    !exactKeys(value, [
      "version", "controlPlaneUrl", "stableSiteKey", "publicUrl", "registeredAt",
      "installationId", "acceptedKeyId", "publicSigningKeys", "endpoints",
    ]) ||
    value.version !== 1 ||
    typeof value.controlPlaneUrl !== "string" ||
    typeof value.stableSiteKey !== "string" ||
    typeof value.publicUrl !== "string" ||
    typeof value.registeredAt !== "string" ||
    typeof value.installationId !== "string" ||
    !UUID_PATTERN.test(value.installationId) ||
    typeof value.acceptedKeyId !== "string" ||
    !KEY_ID_PATTERN.test(value.acceptedKeyId) ||
    !Array.isArray(value.publicSigningKeys) ||
    !isRecord(value.endpoints)
  ) return failure("pending_state_invalid");
  return value as unknown as ReviewManifest;
}

async function readBoundedJson(
  response: Response,
  code: "invalid_registration_response" | "invalid_rotation_response",
): Promise<unknown> {
  const length = response.headers.get("content-length");
  if (length && /^\d+$/.test(length) && Number(length) > MAX_RESPONSE_BYTES) return failure(code);
  if (!response.body) return failure(code);
  const chunks: Uint8Array[] = [];
  let total = 0;
  const reader = response.body.getReader();
  try {
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      total += next.value.byteLength;
      if (total > MAX_RESPONSE_BYTES) {
        await reader.cancel().catch(() => undefined);
        return failure(code);
      }
      chunks.push(next.value);
    }
  } catch (error) {
    if (error instanceof RegistrationCliError) throw error;
    return failure(code);
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    return failure(code);
  }
}

async function sendRegistration(input: {
  url: string;
  body: string;
  proof: string;
  dependencies: ResolvedDependencies;
}): Promise<Response> {
  for (let attempt = 1; attempt <= input.dependencies.maxAttempts; attempt += 1) {
    try {
      const response = await input.dependencies.fetch(new URL(REGISTER_PATH, `${input.url}/`), {
        method: "POST",
        headers: {
          "content-type": "application/json",
          [REGISTRATION_REQUEST_HEADER_NAMES.proof]: input.proof,
        },
        body: input.body,
      });
      if (response.status >= 500 && attempt < input.dependencies.maxAttempts) continue;
      if (!response.ok) {
        return failure(response.status >= 500 ? "registration_ambiguous" : "registration_failed", response.status);
      }
      return response;
    } catch (error) {
      if (error instanceof RegistrationCliError) throw error;
      if (attempt === input.dependencies.maxAttempts) return failure("registration_ambiguous");
    }
  }
  return failure("registration_ambiguous");
}

function safeOutput(output: RegistrationCliOutput, response: RegistrationResponse): void {
  output.info(`Installation ID: ${response.installationId}`);
  output.info(`Accepted key ID: ${response.acceptedKeyId}`);
  output.info(
    "Configure server environment names: BUILDER_CONTROL_PLANE_URL, BUILDER_INSTALLATION_ID, BUILDER_INSTALLATION_KEY_ID, BUILDER_INSTALLATION_PRIVATE_JWK",
  );
}

function normalizePublicUrl(value: unknown): string {
  if (typeof value !== "string") return failure("invalid_arguments");
  try {
    const url = new URL(value);
    const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
    if (
      url.username ||
      url.password ||
      url.search ||
      url.hash ||
      (url.protocol !== "https:" && !(url.protocol === "http:" && loopback))
    ) return failure("invalid_arguments");
    return url.href.replace(/\/$/, "");
  } catch {
    return failure("invalid_arguments");
  }
}

function sameJson(left: unknown, right: unknown): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

function normalizePendingPublicJwk(value: JsonWebKey): PublicJwk {
  try {
    return normalizeExportedEd25519PublicJwk({ kty: value.kty, crv: value.crv, x: value.x });
  } catch {
    return failure("pending_state_invalid");
  }
}

function normalizePendingPublicUrl(value: string): string {
  try {
    return normalizePublicUrl(value);
  } catch {
    return failure("pending_state_invalid");
  }
}

function normalizePendingControlPlaneUrl(value: string): string {
  try {
    return normalizeControlPlaneUrl(value);
  } catch {
    return failure("pending_state_invalid");
  }
}

function parseRegistrationRequestBody(value: unknown): RegistrationRequestBody {
  if (
    !isRecord(value) ||
    !exactKeys(value, ["exchangeToken", "stableSiteKey", "publicUrl", "keyId", "publicJwk", "manifest"]) ||
    !isCanonicalBase64Url32(value.exchangeToken) ||
    typeof value.stableSiteKey !== "string" ||
    !STABLE_SITE_KEY_PATTERN.test(value.stableSiteKey) ||
    typeof value.keyId !== "string" ||
    !KEY_ID_PATTERN.test(value.keyId) ||
    typeof value.publicUrl !== "string" ||
    normalizePendingPublicUrl(value.publicUrl) !== value.publicUrl ||
    !isRecord(value.publicJwk) ||
    !exactKeys(value.publicJwk, ["kty", "crv", "alg", "x"])
  ) return failure("pending_state_invalid");
  let publicJwk: PublicJwk;
  let manifest: InstallationManifestInput;
  try {
    publicJwk = normalizePendingPublicJwk(value.publicJwk as JsonWebKey);
    manifest = parseSharedInstallationManifest(value.manifest);
  } catch {
    return failure("pending_state_invalid");
  }
  if (value.publicJwk.alg !== "EdDSA") return failure("pending_state_invalid");
  return { ...value, publicJwk, manifest } as RegistrationRequestBody;
}

function registrationIdentity(input: {
  controlPlaneUrl: string;
  body: RegistrationRequestBody;
}) {
  const manifestSha256 = sha256(JSON.stringify(input.body.manifest));
  const publicJwkSha256 = sha256(JSON.stringify(input.body.publicJwk));
  const identitySha256 = sha256(JSON.stringify({
    controlPlaneUrl: input.controlPlaneUrl,
    stableSiteKey: input.body.stableSiteKey,
    publicUrl: input.body.publicUrl,
    keyId: input.body.keyId,
    publicJwkSha256,
    manifestSha256,
  }));
  return { manifestSha256, publicJwkSha256, identitySha256 };
}

function parseRegistrationPendingMetadata(
  value: unknown,
  requestBody: string,
  body: RegistrationRequestBody,
): RegistrationPendingMetadata {
  if (
    !isRecord(value) ||
    !exactKeys(value, [
      "version", "operation", "keyId", "controlPlaneUrl", "stableSiteKey", "publicUrl",
      "manifestSha256", "publicJwkSha256", "identitySha256", "bodySha256", "createdAt",
    ]) ||
    value.version !== 2 ||
    value.operation !== "register" ||
    typeof value.keyId !== "string" ||
    typeof value.controlPlaneUrl !== "string" ||
    typeof value.stableSiteKey !== "string" ||
    typeof value.publicUrl !== "string" ||
    typeof value.manifestSha256 !== "string" ||
    typeof value.publicJwkSha256 !== "string" ||
    typeof value.identitySha256 !== "string" ||
    typeof value.bodySha256 !== "string" ||
    typeof value.createdAt !== "string"
  ) return failure("pending_state_invalid");
  const controlPlaneUrl = normalizePendingControlPlaneUrl(value.controlPlaneUrl);
  const identity = registrationIdentity({ controlPlaneUrl, body });
  if (
    value.keyId !== body.keyId ||
    value.stableSiteKey !== body.stableSiteKey ||
    value.publicUrl !== body.publicUrl ||
    value.manifestSha256 !== identity.manifestSha256 ||
    value.publicJwkSha256 !== identity.publicJwkSha256 ||
    value.identitySha256 !== identity.identitySha256 ||
    value.bodySha256 !== sha256(requestBody)
  ) return failure("pending_state_invalid");
  return value as unknown as RegistrationPendingMetadata;
}

function parseRebindBinding(
  value: unknown,
  metadata: RegistrationPendingMetadata,
  privateJwk: JsonWebKey,
): Promise<RegistrationRebindBinding> {
  if (
    !isRecord(value) ||
    !exactKeys(value, [
      "version", "operation", "expectedInstallationId", "identitySha256", "bodySha256",
      "body", "proof", "reboundAt",
    ]) ||
    value.version !== 1 ||
    value.operation !== "rebind" ||
    typeof value.expectedInstallationId !== "string" ||
    !UUID_PATTERN.test(value.expectedInstallationId) ||
    typeof value.identitySha256 !== "string" ||
    value.identitySha256 !== metadata.identitySha256 ||
    typeof value.bodySha256 !== "string" ||
    typeof value.body !== "string" ||
    value.bodySha256 !== sha256(value.body) ||
    typeof value.proof !== "string" ||
    typeof value.reboundAt !== "string"
  ) return Promise.reject(new RegistrationCliError("pending_state_invalid"));
  const body = parseRegistrationRequestBody(parseJson(value.body));
  if (registrationIdentity({ controlPlaneUrl: metadata.controlPlaneUrl, body }).identitySha256 !== metadata.identitySha256) {
    return Promise.reject(new RegistrationCliError("pending_state_invalid"));
  }
  return signRegistrationProof({ bodyBytes: encoder.encode(value.body), privateJwk }).then((proof) => {
    if (proof !== value.proof) return failure("pending_state_invalid");
    return value as unknown as RegistrationRebindBinding;
  });
}

async function publishRebindBinding(input: {
  files: ProtectedFiles;
  binding: RegistrationRebindBinding;
  dependencies: ResolvedDependencies;
}): Promise<void> {
  const temporaryName = randomName(".installation-rebind", input.dependencies.randomBytes);
  const temporary = join(REGISTRATION_PENDING, temporaryName);
  await input.files.writeExclusive(temporary, `${JSON.stringify(input.binding)}\n`);
  await input.files.sync(REGISTRATION_PENDING).catch((error) => {
    if (input.dependencies.platform !== "win32") throw error;
  });
  await input.dependencies.rebindCheckpoint("binding_staged");
  await input.files.rename(temporary, REGISTRATION_REBIND);
  await input.files.sync(REGISTRATION_PENDING).catch((error) => {
    if (input.dependencies.platform !== "win32") throw error;
  });
  await input.dependencies.rebindCheckpoint("binding_promoted");
}

async function cleanupStaleRebindTemps(files: ProtectedFiles): Promise<void> {
  for (const name of await files.list(REGISTRATION_PENDING)) {
    if (name.startsWith(".installation-rebind.") && name.endsWith(".tmp")) {
      await files.remove(join(REGISTRATION_PENDING, name));
    }
  }
}

async function registerNew(
  input: Extract<RegisterInstallationInput, { rotate?: false }>,
  dependencies: ResolvedDependencies,
) {
  const manifest = parseInstallationManifest(input.manifest);
  const controlPlaneUrl = normalizeControlPlaneUrl(input.controlPlaneUrl);
  const publicUrl = normalizePublicUrl(input.publicUrl);
  if (
    !input.projectDir ||
    !isCanonicalBase64Url32(input.exchangeToken) ||
    typeof input.stableSiteKey !== "string" ||
    !STABLE_SITE_KEY_PATTERN.test(input.stableSiteKey)
  ) return failure("invalid_arguments");

  const files = await ProjectFilesystem.open(input.projectDir);
  const protectedFiles = await ProtectedFiles.open(files, SECRETS_DIRECTORY, {
    platform: dependencies.platform,
    ...dependencies.protectedFiles,
  });
  await cleanupStaleTemps(protectedFiles, "installation-registration");
  const hasPending = await protectedFiles.exists(REGISTRATION_PENDING);
  if (!hasPending && (await protectedFiles.exists(PRIVATE_PATH) || await files.exists(REVIEW_PATH))) {
    return failure("private_key_exists");
  }
  if (hasPending && await protectedFiles.exists(REGISTRATION_REBIND)) {
    return failure("pending_registration_mismatch");
  }

  let body: string;
  let proof: string;
  let keyId: string;
  if (!hasPending) {
    const pair = dependencies.generateKeyPair();
    keyId = createKeyId(dependencies.now(), dependencies.randomBytes);
    const requestBody: RegistrationRequestBody = {
      exchangeToken: input.exchangeToken,
      stableSiteKey: input.stableSiteKey,
      publicUrl,
      keyId,
      publicJwk: normalizePendingPublicJwk(pair.publicJwk),
      manifest,
    };
    body = JSON.stringify(requestBody);
    proof = await signRegistrationProof({ bodyBytes: encoder.encode(body), privateJwk: pair.privateJwk });
    const identity = registrationIdentity({ controlPlaneUrl, body: requestBody });
    await stageDirectory({
      files: protectedFiles,
      canonical: REGISTRATION_PENDING,
      prefix: "installation-registration",
      dependencies,
      entries: [
        { name: "installation-private.jwk", contents: `${JSON.stringify(pair.privateJwk)}\n`, secret: true },
        { name: "request.json", contents: `${JSON.stringify({ body, proof })}\n`, secret: true },
        {
          name: "metadata.json",
          contents: `${JSON.stringify({
            version: 2,
            operation: "register",
            keyId,
            controlPlaneUrl,
            stableSiteKey: input.stableSiteKey,
            publicUrl,
            ...identity,
            bodySha256: sha256(body),
            createdAt: dependencies.now().toISOString(),
          }, null, 2)}\n`,
        },
      ],
    });
  } else {
    const metadataValue = await readJson(protectedFiles, REGISTRATION_METADATA);
    const request = await readJson(protectedFiles, REGISTRATION_REQUEST);
    if (
      !isRecord(request) ||
      !exactKeys(request, ["body", "proof"]) ||
      typeof request.body !== "string" ||
      typeof request.proof !== "string"
    ) return failure("pending_state_invalid");
    const pendingBody = parseRegistrationRequestBody(parseJson(request.body));
    const metadata = parseRegistrationPendingMetadata(
      metadataValue,
      request.body,
      pendingBody,
    );
    keyId = metadata.keyId;
    const pendingSecret = await protectedFiles.readOptional(REGISTRATION_SECRET);
    const finalSecret = await protectedFiles.readOptional(PRIVATE_PATH);
    if ((pendingSecret === null) === (finalSecret === null)) return failure("pending_state_invalid");
    const privateJwk = parsePrivateJwk(parseJson(pendingSecret ?? finalSecret!));
    const expectedBody = JSON.stringify({
      exchangeToken: input.exchangeToken,
      stableSiteKey: input.stableSiteKey,
      publicUrl,
      keyId,
      publicJwk: publicFromPrivate(privateJwk),
      manifest,
    });
    const expectedProof = await signRegistrationProof({
      bodyBytes: encoder.encode(expectedBody),
      privateJwk,
    });
    if (
      metadata.controlPlaneUrl !== controlPlaneUrl ||
      request.body !== expectedBody ||
      request.proof !== expectedProof ||
      metadata.bodySha256 !== sha256(expectedBody)
    ) return failure("pending_registration_mismatch");
    body = request.body;
    proof = request.proof;
  }

  const preexistingReviewText = await files.readOptional(REVIEW_PATH);
  if (preexistingReviewText !== null) {
    const existing = parseReview(parseJson(preexistingReviewText));
    if (
      existing.controlPlaneUrl !== controlPlaneUrl ||
      existing.stableSiteKey !== input.stableSiteKey ||
      existing.publicUrl !== publicUrl ||
      existing.acceptedKeyId !== keyId
    ) return failure("pending_state_invalid");
  }

  const response = await sendRegistration({ url: controlPlaneUrl, body, proof, dependencies });
  const parsed = parseRegistrationResponse(
    await readBoundedJson(response, "invalid_registration_response"),
    keyId,
  );

  const pendingSecret = await protectedFiles.readOptional(REGISTRATION_SECRET);
  if (pendingSecret !== null) {
    if (await protectedFiles.exists(PRIVATE_PATH)) return failure("pending_state_invalid");
    await protectedFiles.rename(REGISTRATION_SECRET, PRIVATE_PATH);
  } else {
    const finalJwk = parsePrivateJwk(await readJson(protectedFiles, PRIVATE_PATH));
    const requestPublic = (parseJson(body) as Record<string, unknown>).publicJwk;
    if (!sameJson(publicFromPrivate(finalJwk), requestPublic)) return failure("pending_state_invalid");
  }

  const review: ReviewManifest = {
    version: 1,
    controlPlaneUrl,
    stableSiteKey: input.stableSiteKey,
    publicUrl,
    registeredAt: dependencies.now().toISOString(),
    ...parsed,
  };
  if (preexistingReviewText !== null) {
    const existing = parseReview(parseJson(preexistingReviewText));
    if (!sameJson({ ...existing, registeredAt: review.registeredAt }, review)) {
      return failure("pending_state_invalid");
    }
  } else {
    await writeAtomic(files, REVIEW_PATH, `${JSON.stringify(review, null, 2)}\n`, dependencies);
  }
  await protectedFiles.remove(REGISTRATION_PENDING, true);
  safeOutput(dependencies.output, parsed);
  return { installationId: parsed.installationId, acceptedKeyId: parsed.acceptedKeyId, rotated: false as const };
}

async function attemptRotation(input: {
  review: ReviewManifest;
  signingKeyId: string;
  signingPrivateJwk: JsonWebKey;
  body: string;
  dependencies: ResolvedDependencies;
}): Promise<Response | null> {
  const bodyBytes = encoder.encode(input.body);
  for (let attempt = 1; attempt <= input.dependencies.maxAttempts; attempt += 1) {
    const signed = await signInstallationRequest({
      installationId: input.review.installationId,
      keyId: input.signingKeyId,
      method: "POST",
      path: ROTATE_PATH,
      timestamp: input.dependencies.now().toISOString(),
      nonce: Buffer.from(input.dependencies.randomBytes(16)).toString("base64url"),
      bodyBytes,
      privateJwk: input.signingPrivateJwk,
    });
    try {
      const response = await input.dependencies.fetch(
        new URL(ROTATE_PATH, `${input.review.controlPlaneUrl}/`),
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            [INSTALLATION_REQUEST_HEADER_NAMES.installationId]: signed.installationId,
            [INSTALLATION_REQUEST_HEADER_NAMES.keyId]: signed.keyId,
            [INSTALLATION_REQUEST_HEADER_NAMES.timestamp]: signed.timestamp,
            [INSTALLATION_REQUEST_HEADER_NAMES.nonce]: signed.nonce,
            [INSTALLATION_REQUEST_HEADER_NAMES.signature]: signed.signature,
          },
          body: bodyBytes,
        },
      );
      if (response.status >= 500) {
        if (attempt < input.dependencies.maxAttempts) continue;
        return null;
      }
      return response;
    } catch (error) {
      if (error instanceof RegistrationCliError) throw error;
      if (attempt === input.dependencies.maxAttempts) return null;
    }
  }
  return null;
}

async function sendRotation(input: {
  review: ReviewManifest;
  previousKeyId: string;
  previousPrivateJwk: JsonWebKey;
  newKeyId: string;
  newPrivateJwk: JsonWebKey;
  body: string;
  dependencies: ResolvedDependencies;
}): Promise<Response> {
  const previousResponse = await attemptRotation({
    review: input.review,
    signingKeyId: input.previousKeyId,
    signingPrivateJwk: input.previousPrivateJwk,
    body: input.body,
    dependencies: input.dependencies,
  });
  if (previousResponse?.ok) return previousResponse;
  const previousWasAmbiguous = previousResponse === null;
  if (
    previousResponse &&
    previousResponse.status !== 401 &&
    previousResponse.status !== 403 &&
    previousResponse.status !== 409
  ) {
    return failure("rotation_failed", previousResponse.status);
  }

  const reconciliationResponse = await attemptRotation({
    review: input.review,
    signingKeyId: input.newKeyId,
    signingPrivateJwk: input.newPrivateJwk,
    body: input.body,
    dependencies: input.dependencies,
  });
  if (reconciliationResponse?.ok) return reconciliationResponse;
  if (reconciliationResponse === null) return failure("rotation_ambiguous");
  if (
    previousWasAmbiguous &&
    (reconciliationResponse.status === 401 || reconciliationResponse.status === 403)
  ) {
    return failure("rotation_ambiguous");
  }
  return failure("rotation_failed", reconciliationResponse.status);
}

async function rotateExisting(
  input: Extract<RegisterInstallationInput, { rotate: true }>,
  dependencies: ResolvedDependencies,
) {
  if (!input.projectDir) return failure("invalid_arguments");
  const files = await ProjectFilesystem.open(input.projectDir);
  const protectedFiles = await ProtectedFiles.open(files, SECRETS_DIRECTORY, {
    platform: dependencies.platform,
    ...dependencies.protectedFiles,
  });
  await cleanupStaleTemps(protectedFiles, "installation-rotation");
  let review = parseReview(await readJson(files, REVIEW_PATH));
  if (!await protectedFiles.exists(PRIVATE_PATH) && !await protectedFiles.exists(ROTATION_PENDING)) {
    return failure("pending_state_invalid");
  }

  const hasPending = await protectedFiles.exists(ROTATION_PENDING);
  if (!hasPending) {
    const overlapSeconds = input.overlapSeconds ?? 3_600;
    if (!Number.isSafeInteger(overlapSeconds) || overlapSeconds < 1 || overlapSeconds > 86_400) {
      return failure("invalid_arguments");
    }
    const currentPrivateJwk = parsePrivateJwk(await readJson(protectedFiles, PRIVATE_PATH));
    const pair = dependencies.generateKeyPair();
    let newKeyId = createKeyId(dependencies.now(), dependencies.randomBytes);
    for (let attempt = 0; newKeyId === review.acceptedKeyId && attempt < 4; attempt += 1) {
      newKeyId = createKeyId(dependencies.now(), dependencies.randomBytes);
    }
    if (newKeyId === review.acceptedKeyId) return failure("pending_state_invalid");
    const previousKeyId = review.acceptedKeyId;
    const body = JSON.stringify({
      previousKeyId,
      newKeyId,
      publicJwk: pair.publicJwk,
      overlapSeconds,
    });
    await stageDirectory({
      files: protectedFiles,
      canonical: ROTATION_PENDING,
      prefix: "installation-rotation",
      dependencies,
      entries: [
        { name: "current-private.jwk", contents: `${JSON.stringify(currentPrivateJwk)}\n`, secret: true },
        { name: "next-private.jwk", contents: `${JSON.stringify(pair.privateJwk)}\n`, secret: true },
        { name: "request.json", contents: `${JSON.stringify({ body })}\n`, secret: true },
        {
          name: "metadata.json",
          contents: `${JSON.stringify({
            version: 2,
            operation: "rotate",
            previousKeyId,
            newKeyId,
            overlapSeconds,
            bodySha256: sha256(body),
            createdAt: dependencies.now().toISOString(),
          }, null, 2)}\n`,
        },
      ],
    });
  }

  const metadata = await readJson(protectedFiles, ROTATION_METADATA);
  const request = await readJson(protectedFiles, ROTATION_REQUEST);
  if (
    !isRecord(metadata) ||
    !exactKeys(metadata, [
      "version", "operation", "previousKeyId", "newKeyId", "overlapSeconds", "bodySha256", "createdAt",
    ]) ||
    metadata.version !== 2 ||
    metadata.operation !== "rotate" ||
    typeof metadata.previousKeyId !== "string" ||
    !KEY_ID_PATTERN.test(metadata.previousKeyId) ||
    typeof metadata.newKeyId !== "string" ||
    !KEY_ID_PATTERN.test(metadata.newKeyId) ||
    !Number.isSafeInteger(metadata.overlapSeconds) ||
    (metadata.overlapSeconds as number) < 1 ||
    (metadata.overlapSeconds as number) > 86_400 ||
    !isRecord(request) ||
    !exactKeys(request, ["body"]) ||
    typeof request.body !== "string" ||
    metadata.bodySha256 !== sha256(request.body)
  ) return failure("pending_state_invalid");
  if (
    input.overlapSeconds !== undefined && input.overlapSeconds !== metadata.overlapSeconds ||
    ![metadata.previousKeyId, metadata.newKeyId].includes(review.acceptedKeyId)
  ) return failure("pending_state_invalid");

  const currentPrivateJwk = parsePrivateJwk(await readJson(protectedFiles, ROTATION_CURRENT_SECRET));
  const nextText = await protectedFiles.readOptional(ROTATION_NEXT_SECRET);
  const nextPrivateJwk = parsePrivateJwk(parseJson(nextText ?? await protectedFiles.read(PRIVATE_PATH)));
  const expectedBody = JSON.stringify({
    previousKeyId: metadata.previousKeyId,
    newKeyId: metadata.newKeyId,
    publicJwk: publicFromPrivate(nextPrivateJwk),
    overlapSeconds: metadata.overlapSeconds,
  });
  if (request.body !== expectedBody) return failure("pending_state_invalid");

  const response = await sendRotation({
    review,
    previousKeyId: metadata.previousKeyId,
    previousPrivateJwk: currentPrivateJwk,
    newKeyId: metadata.newKeyId,
    newPrivateJwk: nextPrivateJwk,
    body: request.body,
    dependencies,
  });
  const parsed = await readBoundedJson(response, "invalid_rotation_response");
  if (
    !isRecord(parsed) ||
    !exactKeys(parsed, ["acceptedKeyId"]) ||
    parsed.acceptedKeyId !== metadata.newKeyId
  ) return failure("invalid_rotation_response");

  if (nextText !== null) await protectedFiles.rename(ROTATION_NEXT_SECRET, PRIVATE_PATH);
  else if (!sameJson(publicFromPrivate(parsePrivateJwk(await readJson(protectedFiles, PRIVATE_PATH))), publicFromPrivate(nextPrivateJwk))) {
    return failure("pending_state_invalid");
  }

  if (review.acceptedKeyId !== metadata.newKeyId) {
    review = { ...review, acceptedKeyId: metadata.newKeyId };
    await writeAtomic(files, REVIEW_PATH, `${JSON.stringify(review, null, 2)}\n`, dependencies);
  }
  await protectedFiles.remove(ROTATION_PENDING, true);
  safeOutput(dependencies.output, review);
  return {
    installationId: review.installationId,
    acceptedKeyId: metadata.newKeyId,
    rotated: true as const,
  };
}

function resolveDependencies(
  dependencies: RegisterInstallationDependencies,
): ResolvedDependencies {
  return {
    fetch: dependencies.fetch ?? globalThis.fetch,
    output: dependencies.output ?? { info: console.log, warn: console.warn },
    now: dependencies.now ?? (() => new Date()),
    randomBytes: dependencies.randomBytes ?? ((size) => nodeRandomBytes(size)),
    maxAttempts: dependencies.maxAttempts ?? 3,
    platform: dependencies.platform ?? process.platform,
    protectedFiles: dependencies.protectedFiles ?? {},
    generateKeyPair: dependencies.generateKeyPair ?? defaultGenerateKeyPair,
    rebindCheckpoint: async (checkpoint) => dependencies.rebindCheckpoint?.(checkpoint),
  };
}

async function rebindPendingRegistration(
  input: RebindInstallationInput,
  dependencies: ResolvedDependencies,
) {
  if (
    !input.projectDir ||
    !isCanonicalBase64Url32(input.exchangeToken) ||
    typeof input.expectedInstallationId !== "string" ||
    !UUID_PATTERN.test(input.expectedInstallationId)
  ) return failure("invalid_arguments");
  const expectedInstallationId = input.expectedInstallationId.toLowerCase();
  const files = await ProjectFilesystem.open(input.projectDir);
  const reviewText = await files.readOptional(REVIEW_PATH);
  if (reviewText !== null) {
    parseReview(parseJson(reviewText));
    return failure("registration_already_accepted");
  }
  const protectedFiles = await ProtectedFiles.open(files, SECRETS_DIRECTORY, {
    platform: dependencies.platform,
    ...dependencies.protectedFiles,
  });
  if (!await protectedFiles.exists(REGISTRATION_PENDING)) return failure("pending_state_invalid");
  await cleanupStaleRebindTemps(protectedFiles);

  const request = await readJson(protectedFiles, REGISTRATION_REQUEST);
  if (
    !isRecord(request) ||
    !exactKeys(request, ["body", "proof"]) ||
    typeof request.body !== "string" ||
    typeof request.proof !== "string"
  ) return failure("pending_state_invalid");
  const originalBody = parseRegistrationRequestBody(parseJson(request.body));
  const metadata = parseRegistrationPendingMetadata(
    await readJson(protectedFiles, REGISTRATION_METADATA),
    request.body,
    originalBody,
  );
  const pendingSecret = await protectedFiles.readOptional(REGISTRATION_SECRET);
  const finalSecret = await protectedFiles.readOptional(PRIVATE_PATH);
  if ((pendingSecret === null) === (finalSecret === null)) return failure("pending_state_invalid");
  const privateJwk = parsePrivateJwk(parseJson(pendingSecret ?? finalSecret!));
  if (!sameJson(publicFromPrivate(privateJwk), originalBody.publicJwk)) {
    return failure("pending_state_invalid");
  }
  const originalProof = await signRegistrationProof({
    bodyBytes: encoder.encode(request.body),
    privateJwk,
  });
  if (originalProof !== request.proof) return failure("pending_state_invalid");

  let binding: RegistrationRebindBinding | null = null;
  const existingBindingText = await protectedFiles.readOptional(REGISTRATION_REBIND);
  if (existingBindingText !== null) {
    binding = await parseRebindBinding(parseJson(existingBindingText), metadata, privateJwk);
    if (binding.expectedInstallationId.toLowerCase() !== expectedInstallationId) {
      return failure("installation_id_mismatch");
    }
    const existingBody = parseRegistrationRequestBody(parseJson(binding.body));
    if (existingBody.exchangeToken !== input.exchangeToken) binding = null;
  }

  if (binding === null) {
    const body = JSON.stringify({ ...originalBody, exchangeToken: input.exchangeToken });
    const proof = await signRegistrationProof({ bodyBytes: encoder.encode(body), privateJwk });
    binding = {
      version: 1,
      operation: "rebind",
      expectedInstallationId,
      identitySha256: metadata.identitySha256,
      bodySha256: sha256(body),
      body,
      proof,
      reboundAt: dependencies.now().toISOString(),
    };
    await publishRebindBinding({ files: protectedFiles, binding, dependencies });
  }

  const response = await sendRegistration({
    url: metadata.controlPlaneUrl,
    body: binding.body,
    proof: binding.proof,
    dependencies,
  });
  const parsed = parseRegistrationResponse(
    await readBoundedJson(response, "invalid_registration_response"),
    metadata.keyId,
  );
  if (parsed.installationId.toLowerCase() !== expectedInstallationId) {
    return failure("installation_id_mismatch");
  }

  if (pendingSecret !== null) {
    if (await protectedFiles.exists(PRIVATE_PATH)) return failure("pending_state_invalid");
    await protectedFiles.rename(REGISTRATION_SECRET, PRIVATE_PATH);
  } else {
    const promoted = parsePrivateJwk(await readJson(protectedFiles, PRIVATE_PATH));
    if (!sameJson(publicFromPrivate(promoted), originalBody.publicJwk)) {
      return failure("pending_state_invalid");
    }
  }
  const review: ReviewManifest = {
    version: 1,
    controlPlaneUrl: metadata.controlPlaneUrl,
    stableSiteKey: metadata.stableSiteKey,
    publicUrl: metadata.publicUrl,
    registeredAt: dependencies.now().toISOString(),
    ...parsed,
  };
  await writeAtomic(files, REVIEW_PATH, `${JSON.stringify(review, null, 2)}\n`, dependencies);
  await protectedFiles.remove(REGISTRATION_PENDING, true);
  safeOutput(dependencies.output, parsed);
  return {
    installationId: parsed.installationId,
    acceptedKeyId: parsed.acceptedKeyId,
    rotated: false as const,
    rebound: true as const,
  };
}

export async function rebindInstallation(
  input: RebindInstallationInput,
  dependencies: RegisterInstallationDependencies = {},
) {
  const resolved = resolveDependencies(dependencies);
  if (!Number.isSafeInteger(resolved.maxAttempts) || resolved.maxAttempts < 1 || resolved.maxAttempts > 5) {
    return failure("invalid_arguments");
  }
  try {
    return await rebindPendingRegistration(input, resolved);
  } catch (error) {
    if (error instanceof RegistrationCliError) throw error;
    if (error instanceof UnsafeProjectPathError || error instanceof ProtectedStorageError) {
      return failure("pending_state_invalid");
    }
    return failure("pending_state_invalid");
  }
}

export async function registerInstallation(
  input: RegisterInstallationInput,
  dependencies: RegisterInstallationDependencies = {},
) {
  const resolved = resolveDependencies(dependencies);
  if (!Number.isSafeInteger(resolved.maxAttempts) || resolved.maxAttempts < 1 || resolved.maxAttempts > 5) {
    return failure("invalid_arguments");
  }
  try {
    return input.rotate === true
      ? await rotateExisting(input, resolved)
      : await registerNew(input, resolved);
  } catch (error) {
    if (error instanceof RegistrationCliError) throw error;
    if (error instanceof UnsafeProjectPathError || error instanceof ProtectedStorageError) {
      return failure("pending_state_invalid");
    }
    return failure("pending_state_invalid");
  }
}
