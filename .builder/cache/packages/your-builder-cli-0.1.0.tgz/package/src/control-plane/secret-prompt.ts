import { inspect } from "node:util";

const TOKEN_LENGTH = 43;
const TOKEN_PATTERN = /^[A-Za-z0-9_-]{43}$/;

export interface SecretPromptTerminal {
  isTTY: boolean;
  writeError(value: string): void;
  setRawMode(enabled: boolean): void;
  read(): Promise<Uint8Array | null>;
  onSigint(listener: () => void): () => void;
}

export type SecretPromptErrorCode =
  | "exchange_token_tty_required"
  | "exchange_token_invalid"
  | "exchange_token_too_long"
  | "exchange_token_input_closed"
  | "exchange_token_cancelled"
  | "exchange_token_read_failed"
  | "exchange_token_consumed";

export class SecretPromptError extends Error {
  constructor(public readonly code: SecretPromptErrorCode) {
    super(code);
    this.name = "SecretPromptError";
  }
}

export interface ExchangeTokenSecret {
  use<T>(callback: (token: string) => Promise<T>): Promise<T>;
  toJSON(): "[REDACTED]";
  toString(): "[REDACTED]";
}

class OneUseExchangeTokenSecret implements ExchangeTokenSecret {
  readonly #bytes: Uint8Array;
  #consumed = false;

  constructor(bytes: Uint8Array) {
    this.#bytes = bytes;
  }

  async use<T>(callback: (token: string) => Promise<T>): Promise<T> {
    if (this.#consumed) throw new SecretPromptError("exchange_token_consumed");
    this.#consumed = true;
    let token: string | undefined;
    try {
      token = new TextDecoder("utf-8", { fatal: true }).decode(this.#bytes);
      return await callback(token);
    } finally {
      token = undefined;
      this.#bytes.fill(0);
    }
  }

  toJSON(): "[REDACTED]" {
    return "[REDACTED]";
  }

  toString(): "[REDACTED]" {
    return "[REDACTED]";
  }

  [inspect.custom](): "[REDACTED]" {
    return "[REDACTED]";
  }
}

function fail(code: SecretPromptErrorCode): never {
  throw new SecretPromptError(code);
}

export async function readExchangeTokenFromTty(
  terminal: SecretPromptTerminal,
): Promise<ExchangeTokenSecret> {
  if (!terminal.isTTY) return fail("exchange_token_tty_required");

  const collected: number[] = [];
  let cancelled = false;
  let rawModeEnabled = false;
  let removeSigint: (() => void) | undefined;
  let promptWritten = false;
  try {
    terminal.writeError("Exchange token: ");
    promptWritten = true;
    terminal.setRawMode(true);
    rawModeEnabled = true;
    removeSigint = terminal.onSigint(() => { cancelled = true; });

    let complete = false;
    while (!complete) {
      let chunk: Uint8Array | null;
      try {
        chunk = await terminal.read();
      } catch {
        return fail("exchange_token_read_failed");
      }
      if (cancelled) return fail("exchange_token_cancelled");
      if (chunk === null) return fail("exchange_token_input_closed");
      for (const byte of chunk) {
        if (byte === 3) return fail("exchange_token_cancelled");
        if (byte === 13 || byte === 10) {
          complete = true;
          break;
        }
        if (byte === 8 || byte === 127) {
          collected.pop();
          continue;
        }
        if (collected.length >= TOKEN_LENGTH) return fail("exchange_token_too_long");
        collected.push(byte);
      }
    }
    const bytes = Uint8Array.from(collected);
    collected.fill(0);
    let token: string;
    try {
      token = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    } catch {
      bytes.fill(0);
      return fail("exchange_token_invalid");
    }
    if (!TOKEN_PATTERN.test(token)) {
      token = "";
      bytes.fill(0);
      return fail("exchange_token_invalid");
    }
    token = "";
    return new OneUseExchangeTokenSecret(bytes);
  } catch (error) {
    if (error instanceof SecretPromptError) throw error;
    throw new SecretPromptError("exchange_token_read_failed");
  } finally {
    collected.fill(0);
    try {
      removeSigint?.();
    } catch {
      // Cleanup is best-effort after the listener reference is dropped.
    }
    if (rawModeEnabled) {
      try {
        terminal.setRawMode(false);
      } catch {
        // Do not replace the stable prompt outcome with terminal implementation details.
      }
    }
    if (promptWritten) {
      try {
        terminal.writeError("\n");
      } catch {
        // The prompt result remains safe even when the terminal disappears during cleanup.
      }
    }
  }
}
