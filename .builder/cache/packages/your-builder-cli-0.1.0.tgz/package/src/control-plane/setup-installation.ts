import { randomUUID } from "node:crypto";
import { join } from "node:path";

import {
  installationManifestSha256,
  parseInstallationManifest,
  parseSiteRuntimeMarker,
  type InstallationManifestInput,
} from "@your-builder/entitlements/trust";

import {
  rebindInstallation as defaultRebindInstallation,
  registerInstallation as defaultRegisterInstallation,
  type RegisterInstallationDependencies,
} from "./register-installation.js";
import { ProjectFilesystem } from "./project-filesystem.js";
import {
  ProtectedFiles,
  type ProtectedFilesOptions,
} from "./protected-files.js";
import {
  createSetupJournalStore,
  type SetupJournalStore,
  type SetupJournalStoreOptions,
} from "./setup-journal.js";
import {
  createServerEnvironmentInput,
  type HostingProvider,
} from "../hosting/contracts.js";
import type { HostingAdapterRegistry } from "../hosting/adapter-registry.js";
import { createProjectFingerprint } from "../hosting/project-fingerprint.js";

const MANIFEST_PATH = join(".builder", "installation-manifest.json");
const RUNTIME_MARKER_PATH = join(".builder", "site-runtime.json");
const REVIEW_PATH = join(".builder", "installation-registration.json");
const SECRETS_DIRECTORY = join(".builder", "secrets");
const PRIVATE_PATH = join(SECRETS_DIRECTORY, "installation-private.jwk");
const SETUP_LOCK_PATH = join(SECRETS_DIRECTORY, "installation-setup.lock");
const SETUP_LOCK_RECOVERY_PATH = join(SECRETS_DIRECTORY, "installation-setup.lock.recovery");
const FINGERPRINT_MARKERS = ["package.json", MANIFEST_PATH, RUNTIME_MARKER_PATH] as const;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const KEY_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const BASE64URL_32_PATTERN = /^[A-Za-z0-9_-]{43}$/;

export interface SetupInstallationInput {
  projectDir: string;
  controlPlaneUrl: string;
  stableSiteKey: string;
  publicUrl: string;
  hosting: HostingProvider;
  rebindExchange?: boolean;
  expectedInstallationId?: string;
}

export interface SetupInstallationDependencies {
  adapterRegistry: HostingAdapterRegistry;
  withExchangeToken<T>(callback: (exchangeToken: string) => Promise<T>): Promise<T>;
  registerInstallation?: typeof defaultRegisterInstallation;
  rebindInstallation?: typeof defaultRebindInstallation;
  registration?: RegisterInstallationDependencies;
  now?: () => Date;
  platform?: NodeJS.Platform;
  protectedFiles?: Omit<ProtectedFilesOptions, "platform">;
  isProcessAlive?: (processId: number) => boolean;
  createJournalStore?: (
    projectDir: string,
    options: SetupJournalStoreOptions,
  ) => Promise<SetupJournalStore>;
}

export type SetupInstallationResult =
  | {
      status: "hosting_handoff_pending";
      installationId: string;
      acceptedKeyId: string;
      receiptDigest: string;
    }
  | {
      status: "configured";
      installationId: string;
      acceptedKeyId: string;
    };

export type SetupInstallationErrorCode =
  | "runtime_not_ready"
  | "setup_in_progress"
  | "accepted_registration_invalid"
  | "registration_unavailable"
  | "hosting_adapter_unavailable"
  | "hosting_setup_failed"
  | "protected_storage_unavailable";

export class SetupInstallationError extends Error {
  constructor(public readonly code: SetupInstallationErrorCode) {
    super(code);
    this.name = "SetupInstallationError";
  }
}

interface AcceptedRegistration {
  controlPlaneUrl: string;
  stableSiteKey: string;
  publicUrl: string;
  installationId: string;
  acceptedKeyId: string;
  privateJwk: string;
}

interface SetupLock {
  schemaVersion: 1;
  processId: number;
  createdAt: string;
  lockId: string;
}

function fail(code: SetupInstallationErrorCode): never {
  throw new SetupInstallationError(code);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function exactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join("\0") === [...keys].sort().join("\0");
}

function parseJson(text: string, code: SetupInstallationErrorCode): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return fail(code);
  }
}

function parseSetupLock(text: string): SetupLock | null {
  try {
    const value: unknown = JSON.parse(text);
    if (
      !isRecord(value) ||
      !exactKeys(value, ["schemaVersion", "processId", "createdAt", "lockId"]) ||
      value.schemaVersion !== 1 ||
      typeof value.processId !== "number" ||
      !Number.isSafeInteger(value.processId) ||
      value.processId < 1 ||
      value.processId > 2_147_483_647 ||
      typeof value.createdAt !== "string" ||
      typeof value.lockId !== "string" ||
      !UUID_PATTERN.test(value.lockId)
    ) return null;
    const createdAt = new Date(value.createdAt);
    if (!Number.isFinite(createdAt.getTime()) || createdAt.toISOString() !== value.createdAt) {
      return null;
    }
    return {
      schemaVersion: 1,
      processId: value.processId,
      createdAt: value.createdAt,
      lockId: value.lockId.toLowerCase(),
    };
  } catch {
    return null;
  }
}

function defaultIsProcessAlive(processId: number): boolean {
  try {
    process.kill(processId, 0);
    return true;
  } catch (error) {
    return (error as NodeJS.ErrnoException).code !== "ESRCH";
  }
}

async function acquireSetupLock(
  protectedFiles: ProtectedFiles,
  dependencies: SetupInstallationDependencies,
): Promise<SetupLock> {
  const lock: SetupLock = {
    schemaVersion: 1,
    processId: process.pid,
    createdAt: (dependencies.now?.() ?? new Date()).toISOString(),
    lockId: randomUUID(),
  };
  const serialized = `${JSON.stringify(lock)}\n`;
  try {
    await protectedFiles.writeExclusive(SETUP_LOCK_PATH, serialized);
    return lock;
  } catch (error) {
    if (
      (error as NodeJS.ErrnoException).code !== "EEXIST" &&
      !await protectedFiles.exists(SETUP_LOCK_PATH).catch(() => false)
    ) return fail("protected_storage_unavailable");
  }

  const observedText = await protectedFiles.readOptional(SETUP_LOCK_PATH)
    .catch(() => null);
  const observed = observedText === null ? null : parseSetupLock(observedText);
  if (!observed) return fail("setup_in_progress");
  let alive = true;
  try {
    alive = (dependencies.isProcessAlive ?? defaultIsProcessAlive)(observed.processId);
  } catch {
    return fail("setup_in_progress");
  }
  if (alive) return fail("setup_in_progress");

  const claimed = await protectedFiles.claimExisting(SETUP_LOCK_PATH, SETUP_LOCK_RECOVERY_PATH)
    .catch(() => false);
  if (!claimed) return fail("setup_in_progress");
  try {
    const [currentText, claimText] = await Promise.all([
      protectedFiles.readOptional(SETUP_LOCK_PATH),
      protectedFiles.readOptional(SETUP_LOCK_RECOVERY_PATH),
    ]);
    if (currentText === null || currentText !== observedText || claimText !== observedText) {
      return fail("setup_in_progress");
    }
    await protectedFiles.remove(SETUP_LOCK_PATH);
    await protectedFiles.writeExclusive(SETUP_LOCK_PATH, serialized);
    return lock;
  } catch {
    return fail("setup_in_progress");
  } finally {
    await protectedFiles.remove(SETUP_LOCK_RECOVERY_PATH).catch(() => undefined);
  }
}

async function releaseSetupLock(protectedFiles: ProtectedFiles, lock: SetupLock): Promise<void> {
  try {
    const currentText = await protectedFiles.readOptional(SETUP_LOCK_PATH);
    const current = currentText === null ? null : parseSetupLock(currentText);
    if (current?.lockId === lock.lockId && current.processId === lock.processId) {
      await protectedFiles.remove(SETUP_LOCK_PATH);
    }
  } catch {
    // A changed or unavailable lock is never removed by a process that cannot prove ownership.
  }
}

function normalizeUrl(value: unknown): string {
  if (typeof value !== "string" || value.trim() !== value || value.length > 2_048) {
    return fail("accepted_registration_invalid");
  }
  try {
    const url = new URL(value);
    const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
    if (
      (url.protocol !== "https:" && !(url.protocol === "http:" && loopback)) ||
      url.username ||
      url.password ||
      url.search ||
      url.hash
    ) return fail("accepted_registration_invalid");
    return url.href.replace(/\/$/, "");
  } catch {
    return fail("accepted_registration_invalid");
  }
}

function parsePrivateJwk(text: string): string {
  const value = parseJson(text, "accepted_registration_invalid");
  if (
    !isRecord(value) ||
    !exactKeys(value, ["alg", "crv", "d", "kty", "x"]) ||
    value.kty !== "OKP" ||
    value.crv !== "Ed25519" ||
    value.alg !== "EdDSA" ||
    typeof value.x !== "string" ||
    !BASE64URL_32_PATTERN.test(value.x) ||
    typeof value.d !== "string" ||
    !BASE64URL_32_PATTERN.test(value.d)
  ) return fail("accepted_registration_invalid");
  return JSON.stringify(value);
}

async function loadRuntime(files: ProjectFilesystem, stableSiteKey: string): Promise<InstallationManifestInput> {
  try {
    const manifest = parseInstallationManifest(parseJson(
      await files.read(MANIFEST_PATH),
      "runtime_not_ready",
    ));
    const marker = parseSiteRuntimeMarker(parseJson(
      await files.read(RUNTIME_MARKER_PATH),
      "runtime_not_ready",
    ));
    if (
      marker.expectedSiteKey !== stableSiteKey ||
      marker.installationManifestSha256 !== installationManifestSha256(manifest) ||
      marker.reachabilityEvidenceRevision === null ||
      manifest.workerVersion !== marker.workerVersion
    ) return fail("runtime_not_ready");
    return manifest;
  } catch (error) {
    if (error instanceof SetupInstallationError) throw error;
    return fail("runtime_not_ready");
  }
}

async function loadAcceptedRegistration(
  files: ProjectFilesystem,
  protectedFiles: ProtectedFiles,
  expected: Omit<SetupInstallationInput, "projectDir" | "hosting">,
): Promise<AcceptedRegistration | null> {
  const reviewText = await files.readOptional(REVIEW_PATH);
  if (reviewText === null) return null;
  try {
    const review = parseJson(reviewText, "accepted_registration_invalid");
    if (
      !isRecord(review) ||
      !exactKeys(review, [
        "version",
        "controlPlaneUrl",
        "stableSiteKey",
        "publicUrl",
        "registeredAt",
        "installationId",
        "acceptedKeyId",
        "publicSigningKeys",
        "endpoints",
      ]) ||
      review.version !== 1 ||
      normalizeUrl(review.controlPlaneUrl) !== normalizeUrl(expected.controlPlaneUrl) ||
      review.stableSiteKey !== expected.stableSiteKey ||
      normalizeUrl(review.publicUrl) !== normalizeUrl(expected.publicUrl) ||
      typeof review.installationId !== "string" ||
      !UUID_PATTERN.test(review.installationId) ||
      typeof review.acceptedKeyId !== "string" ||
      !KEY_ID_PATTERN.test(review.acceptedKeyId)
    ) return fail("accepted_registration_invalid");
    const privateText = await protectedFiles.readOptional(PRIVATE_PATH);
    if (privateText === null) return fail("accepted_registration_invalid");
    return {
      controlPlaneUrl: normalizeUrl(review.controlPlaneUrl),
      stableSiteKey: review.stableSiteKey,
      publicUrl: normalizeUrl(review.publicUrl),
      installationId: review.installationId.toLowerCase(),
      acceptedKeyId: review.acceptedKeyId,
      privateJwk: parsePrivateJwk(privateText),
    };
  } catch (error) {
    if (error instanceof SetupInstallationError) throw error;
    return fail("accepted_registration_invalid");
  }
}

export async function setupInstallation(
  input: SetupInstallationInput,
  dependencies: SetupInstallationDependencies,
): Promise<SetupInstallationResult> {
  if (
    (input.rebindExchange === true && !input.expectedInstallationId) ||
    (input.rebindExchange !== true && input.expectedInstallationId !== undefined)
  ) return fail("registration_unavailable");

  let files: ProjectFilesystem;
  let protectedFiles: ProtectedFiles;
  try {
    files = await ProjectFilesystem.open(input.projectDir);
    const manifest = await loadRuntime(files, input.stableSiteKey);
    protectedFiles = await ProtectedFiles.open(files, SECRETS_DIRECTORY, {
      platform: dependencies.platform,
      ...dependencies.protectedFiles,
    });

    const setupLock = await acquireSetupLock(protectedFiles, dependencies);

    try {
      let accepted = await loadAcceptedRegistration(files, protectedFiles, input);
      if (accepted !== null && input.rebindExchange === true) {
        return fail("registration_unavailable");
      }
      if (accepted === null) {
        const register = dependencies.registerInstallation ?? defaultRegisterInstallation;
        const rebind = dependencies.rebindInstallation ?? defaultRebindInstallation;
        try {
          await dependencies.withExchangeToken(async (exchangeToken) => {
            if (input.rebindExchange === true) {
              if (!input.expectedInstallationId) return fail("registration_unavailable");
              await rebind({
                projectDir: files.root,
                exchangeToken,
                expectedInstallationId: input.expectedInstallationId,
              }, dependencies.registration);
            } else {
              if (input.expectedInstallationId !== undefined) {
                return fail("registration_unavailable");
              }
              await register({
                projectDir: files.root,
                controlPlaneUrl: input.controlPlaneUrl,
                exchangeToken,
                stableSiteKey: input.stableSiteKey,
                publicUrl: input.publicUrl,
                manifest,
              }, dependencies.registration);
            }
          });
        } catch {
          return fail("registration_unavailable");
        }
        accepted = await loadAcceptedRegistration(files, protectedFiles, input);
        if (accepted === null) return fail("accepted_registration_invalid");
      }

      let adapter;
      try {
        adapter = dependencies.adapterRegistry.get(input.hosting);
      } catch {
        return fail("hosting_adapter_unavailable");
      }
      const fingerprint = await createProjectFingerprint(files.root, FINGERPRINT_MARKERS);
      const createJournal = dependencies.createJournalStore ?? createSetupJournalStore;
      const journal = await createJournal(files.root, {
        now: dependencies.now,
        platform: dependencies.platform,
        protectedFiles: dependencies.protectedFiles,
      });
      await journal.initialize({
        projectFingerprint: fingerprint.digest,
        stableSiteKey: accepted.stableSiteKey,
        publicUrl: accepted.publicUrl,
        controlPlaneUrl: accepted.controlPlaneUrl,
        installationId: accepted.installationId,
        acceptedKeyId: accepted.acceptedKeyId,
        hostingMode: input.hosting,
      });
      await journal.update({ stage: "hosting_detection_pending", lastErrorCode: null });
      const detection = await adapter.detect(files.root);
      await journal.update({ stage: "hosting_preflight_pending" });
      const receipt = await adapter.preflight(files.root, detection.target);
      await journal.update({
        stage: "hosting_confirmation_pending",
        receiptDigest: receipt.digest,
      });
      const environment = createServerEnvironmentInput({
        BUILDER_CONTROL_PLANE_URL: accepted.controlPlaneUrl,
        BUILDER_INSTALLATION_ID: accepted.installationId,
        BUILDER_INSTALLATION_KEY_ID: accepted.acceptedKeyId,
        BUILDER_INSTALLATION_PRIVATE_JWK: accepted.privateJwk,
      });
      await journal.update({ stage: "hosting_configuration_pending" });
      await adapter.configure(environment, receipt);
      await journal.update({ stage: "hosting_verification_pending" });

      if (input.hosting === "manual") {
        return {
          status: "hosting_handoff_pending",
          installationId: accepted.installationId,
          acceptedKeyId: accepted.acceptedKeyId,
          receiptDigest: receipt.digest,
        };
      }

      await adapter.verifyConfiguration(receipt);
      await journal.remove();
      return {
        status: "configured",
        installationId: accepted.installationId,
        acceptedKeyId: accepted.acceptedKeyId,
      };
    } catch (error) {
      if (error instanceof SetupInstallationError) throw error;
      return fail("hosting_setup_failed");
    } finally {
      await releaseSetupLock(protectedFiles, setupLock);
    }
  } catch (error) {
    if (error instanceof SetupInstallationError) throw error;
    return fail("protected_storage_unavailable");
  }
}
