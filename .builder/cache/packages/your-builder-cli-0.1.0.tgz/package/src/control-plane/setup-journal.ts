import { randomUUID } from "node:crypto";
import { join } from "node:path";

import { ProjectFilesystem } from "./project-filesystem.js";
import {
  ProtectedFiles,
  type ProtectedFilesOptions,
} from "./protected-files.js";

const SECRETS_DIRECTORY = join(".builder", "secrets");
export const SETUP_JOURNAL_DIRECTORY = join(SECRETS_DIRECTORY, "installation-setup");
export const SETUP_JOURNAL_PATH = join(SETUP_JOURNAL_DIRECTORY, "journal.json");

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const SHA256_PATTERN = /^[0-9a-f]{64}$/;
const STABLE_SITE_KEY_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const KEY_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;

export const SETUP_JOURNAL_STAGES = [
  "registration_accepted",
  "hosting_detection_pending",
  "hosting_preflight_pending",
  "hosting_confirmation_pending",
  "hosting_configuration_pending",
  "hosting_verification_pending",
] as const;

export type SetupJournalStage = typeof SETUP_JOURNAL_STAGES[number];

export const SETUP_JOURNAL_LAST_ERROR_CODES = [
  "protected_storage_unavailable",
  "registration_unavailable",
  "hosting_adapter_unavailable",
  "hosting_detection_failed",
  "hosting_preflight_failed",
  "hosting_confirmation_required",
  "hosting_configuration_failed",
  "hosting_verification_failed",
  "hosting_target_drift",
  "hosting_receipt_expired",
] as const;

export type SetupJournalLastErrorCode = typeof SETUP_JOURNAL_LAST_ERROR_CODES[number];
export type SetupJournalHostingMode = "netlify" | "manual";

export interface SetupJournalIdentity {
  projectFingerprint: string;
  stableSiteKey: string;
  publicUrl: string;
  controlPlaneUrl: string;
  installationId: string;
  acceptedKeyId: string;
  hostingMode: SetupJournalHostingMode;
}

export interface SetupJournal extends SetupJournalIdentity {
  schemaVersion: 1;
  stage: SetupJournalStage;
  receiptDigest: string | null;
  createdAt: string;
  updatedAt: string;
  lastErrorCode: SetupJournalLastErrorCode | null;
}

export interface SetupJournalUpdate {
  stage: SetupJournalStage;
  receiptDigest?: string | null;
  lastErrorCode?: SetupJournalLastErrorCode | null;
}

export type SetupJournalErrorCode =
  | "setup_journal_invalid"
  | "setup_journal_conflict"
  | "setup_journal_missing"
  | "setup_journal_protected_storage_unavailable";

export class SetupJournalError extends Error {
  constructor(public readonly code: SetupJournalErrorCode) {
    super(code);
    this.name = "SetupJournalError";
  }
}

export interface SetupJournalStore {
  initialize(identity: SetupJournalIdentity): Promise<SetupJournal>;
  read(): Promise<SetupJournal | null>;
  update(update: SetupJournalUpdate): Promise<SetupJournal>;
  completeManualHandoff(receiptDigest: string): Promise<boolean>;
  remove(): Promise<void>;
}

export interface SetupJournalStoreOptions {
  now?: () => Date;
  platform?: NodeJS.Platform;
  protectedFiles?: Omit<ProtectedFilesOptions, "platform">;
}

const JOURNAL_KEYS = [
  "schemaVersion",
  "projectFingerprint",
  "stableSiteKey",
  "publicUrl",
  "controlPlaneUrl",
  "installationId",
  "acceptedKeyId",
  "hostingMode",
  "stage",
  "receiptDigest",
  "createdAt",
  "updatedAt",
  "lastErrorCode",
] as const;

const IDENTITY_KEYS = [
  "projectFingerprint",
  "stableSiteKey",
  "publicUrl",
  "controlPlaneUrl",
  "installationId",
  "acceptedKeyId",
  "hostingMode",
] as const;

function fail(code: SetupJournalErrorCode): never {
  throw new SetupJournalError(code);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function hasExactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join("\0") === [...keys].sort().join("\0");
}

function isOneOf<const Values extends readonly string[]>(
  value: unknown,
  values: Values,
): value is Values[number] {
  return typeof value === "string" && (values as readonly string[]).includes(value);
}

function parseUrl(value: unknown): string {
  if (
    typeof value !== "string" ||
    value.length < 1 ||
    value.length > 2_048 ||
    value.trim() !== value ||
    /[\u0000-\u001f\u007f]/.test(value)
  ) {
    return fail("setup_journal_invalid");
  }
  try {
    const url = new URL(value);
    const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
    if (
      (url.protocol !== "https:" && !(url.protocol === "http:" && loopback)) ||
      url.username ||
      url.password ||
      url.search ||
      url.hash
    ) {
      return fail("setup_journal_invalid");
    }
  } catch {
    return fail("setup_journal_invalid");
  }
  return value;
}

function parseTimestamp(value: unknown): string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)) {
    return fail("setup_journal_invalid");
  }
  const timestamp = new Date(value);
  if (!Number.isFinite(timestamp.getTime()) || timestamp.toISOString() !== value) {
    return fail("setup_journal_invalid");
  }
  return value;
}

function parseIdentity(value: unknown): SetupJournalIdentity {
  if (!isRecord(value) || !hasExactKeys(value, IDENTITY_KEYS)) {
    return fail("setup_journal_invalid");
  }
  if (
    typeof value.projectFingerprint !== "string" ||
    !SHA256_PATTERN.test(value.projectFingerprint) ||
    typeof value.stableSiteKey !== "string" ||
    value.stableSiteKey.length > 128 ||
    !STABLE_SITE_KEY_PATTERN.test(value.stableSiteKey) ||
    typeof value.installationId !== "string" ||
    !UUID_PATTERN.test(value.installationId) ||
    typeof value.acceptedKeyId !== "string" ||
    !KEY_ID_PATTERN.test(value.acceptedKeyId) ||
    (value.hostingMode !== "netlify" && value.hostingMode !== "manual")
  ) {
    return fail("setup_journal_invalid");
  }
  return {
    projectFingerprint: value.projectFingerprint,
    stableSiteKey: value.stableSiteKey,
    publicUrl: parseUrl(value.publicUrl),
    controlPlaneUrl: parseUrl(value.controlPlaneUrl),
    installationId: value.installationId,
    acceptedKeyId: value.acceptedKeyId,
    hostingMode: value.hostingMode,
  };
}

export function parseSetupJournal(value: unknown): SetupJournal {
  if (!isRecord(value) || !hasExactKeys(value, JOURNAL_KEYS) || value.schemaVersion !== 1) {
    return fail("setup_journal_invalid");
  }
  const identity = parseIdentity(Object.fromEntries(
    IDENTITY_KEYS.map((key) => [key, value[key]]),
  ));
  if (
    !isOneOf(value.stage, SETUP_JOURNAL_STAGES) ||
    (value.receiptDigest !== null &&
      (typeof value.receiptDigest !== "string" || !SHA256_PATTERN.test(value.receiptDigest))) ||
    (value.lastErrorCode !== null &&
      !isOneOf(value.lastErrorCode, SETUP_JOURNAL_LAST_ERROR_CODES))
  ) {
    return fail("setup_journal_invalid");
  }
  const createdAt = parseTimestamp(value.createdAt);
  const updatedAt = parseTimestamp(value.updatedAt);
  if (new Date(updatedAt).getTime() < new Date(createdAt).getTime()) {
    return fail("setup_journal_invalid");
  }
  return {
    schemaVersion: 1,
    ...identity,
    stage: value.stage,
    receiptDigest: value.receiptDigest,
    createdAt,
    updatedAt,
    lastErrorCode: value.lastErrorCode,
  };
}

function sameIdentity(left: SetupJournal, right: SetupJournalIdentity): boolean {
  return IDENTITY_KEYS.every((key) => left[key] === right[key]);
}

function serialize(journal: SetupJournal): string {
  return `${JSON.stringify(journal, null, 2)}\n`;
}

function parseCurrentTime(now: () => Date, earliest?: string): string {
  let value: string;
  try {
    value = now().toISOString();
  } catch {
    return fail("setup_journal_invalid");
  }
  const parsed = parseTimestamp(value);
  if (earliest && new Date(parsed).getTime() < new Date(earliest).getTime()) {
    return fail("setup_journal_invalid");
  }
  return parsed;
}

function parseUpdate(value: unknown): SetupJournalUpdate {
  if (!isRecord(value)) return fail("setup_journal_invalid");
  const keys = Object.keys(value);
  if (
    !keys.includes("stage") ||
    keys.some((key) => !["stage", "receiptDigest", "lastErrorCode"].includes(key)) ||
    !isOneOf(value.stage, SETUP_JOURNAL_STAGES) ||
    ("receiptDigest" in value && value.receiptDigest !== null &&
      (typeof value.receiptDigest !== "string" || !SHA256_PATTERN.test(value.receiptDigest))) ||
    ("lastErrorCode" in value && value.lastErrorCode !== null &&
      !isOneOf(value.lastErrorCode, SETUP_JOURNAL_LAST_ERROR_CODES))
  ) {
    return fail("setup_journal_invalid");
  }
  return {
    stage: value.stage,
    ...(keys.includes("receiptDigest") ? { receiptDigest: value.receiptDigest as string | null } : {}),
    ...(keys.includes("lastErrorCode")
      ? { lastErrorCode: value.lastErrorCode as SetupJournalLastErrorCode | null }
      : {}),
  };
}

export async function createSetupJournalStore(
  projectDir: string,
  options: SetupJournalStoreOptions = {},
): Promise<SetupJournalStore> {
  const now = options.now ?? (() => new Date());
  let protectedFiles: ProtectedFiles;
  try {
    const files = await ProjectFilesystem.open(projectDir);
    protectedFiles = await ProtectedFiles.open(files, SECRETS_DIRECTORY, {
      platform: options.platform,
      ...options.protectedFiles,
    });
    await protectedFiles.ensureDirectory(SETUP_JOURNAL_DIRECTORY);
  } catch {
    return fail("setup_journal_protected_storage_unavailable");
  }

  async function read(): Promise<SetupJournal | null> {
    let text: string | null;
    try {
      text = await protectedFiles.readOptional(SETUP_JOURNAL_PATH);
    } catch {
      return fail("setup_journal_protected_storage_unavailable");
    }
    if (text === null) return null;
    try {
      return parseSetupJournal(JSON.parse(text));
    } catch (error) {
      if (error instanceof SetupJournalError) throw error;
      return fail("setup_journal_invalid");
    }
  }

  async function remove(): Promise<void> {
    try {
      if (await protectedFiles.exists(SETUP_JOURNAL_PATH)) {
        await protectedFiles.remove(SETUP_JOURNAL_PATH);
      }
    } catch {
      return fail("setup_journal_protected_storage_unavailable");
    }
  }

  return {
    async initialize(identityInput) {
      const identity = parseIdentity(identityInput);
      const current = await read();
      if (current) {
        if (!sameIdentity(current, identity)) return fail("setup_journal_conflict");
        return current;
      }
      const timestamp = parseCurrentTime(now);
      const journal = parseSetupJournal({
        schemaVersion: 1,
        ...identity,
        stage: "registration_accepted",
        receiptDigest: null,
        createdAt: timestamp,
        updatedAt: timestamp,
        lastErrorCode: null,
      });
      try {
        await protectedFiles.writeExclusive(SETUP_JOURNAL_PATH, serialize(journal));
      } catch {
        return fail("setup_journal_protected_storage_unavailable");
      }
      return journal;
    },
    read,
    async update(updateInput) {
      const update = parseUpdate(updateInput);
      const current = await read();
      if (!current) return fail("setup_journal_missing");
      const journal = parseSetupJournal({
        ...current,
        stage: update.stage,
        receiptDigest: update.receiptDigest === undefined
          ? current.receiptDigest
          : update.receiptDigest,
        lastErrorCode: update.lastErrorCode === undefined
          ? current.lastErrorCode
          : update.lastErrorCode,
        updatedAt: parseCurrentTime(now, current.updatedAt),
      });
      try {
        await protectedFiles.writeAtomic(
          SETUP_JOURNAL_PATH,
          serialize(journal),
          `.journal.${randomUUID()}.tmp`,
        );
      } catch {
        return fail("setup_journal_protected_storage_unavailable");
      }
      return journal;
    },
    async completeManualHandoff(receiptDigest) {
      if (!SHA256_PATTERN.test(receiptDigest)) return fail("setup_journal_invalid");
      const current = await read();
      if (current === null) return false;
      if (
        current.hostingMode !== "manual" ||
        current.stage !== "hosting_verification_pending" ||
        current.receiptDigest !== receiptDigest
      ) return fail("setup_journal_conflict");
      await remove();
      return true;
    },
    remove,
  };
}
