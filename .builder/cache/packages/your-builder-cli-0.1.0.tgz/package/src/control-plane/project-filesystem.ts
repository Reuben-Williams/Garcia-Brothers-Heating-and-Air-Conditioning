import {
  chmod,
  lstat,
  link,
  mkdir,
  open,
  readdir,
  realpath,
  rename,
  rm,
  stat,
} from "node:fs/promises";
import { constants } from "node:fs";
import { isAbsolute, relative, resolve, sep } from "node:path";

export class UnsafeProjectPathError extends Error {
  constructor() {
    super("unsafe_project_path");
    this.name = "UnsafeProjectPathError";
  }
}

function isMissing(error: unknown): boolean {
  return (error as NodeJS.ErrnoException).code === "ENOENT";
}

function isContained(root: string, candidate: string): boolean {
  const path = relative(root, candidate);
  return path === "" || (!path.startsWith(`..${sep}`) && path !== ".." && !isAbsolute(path));
}

function sameIdentity(
  left: { dev: number | bigint; ino: number | bigint },
  right: { dev: number | bigint; ino: number | bigint },
): boolean {
  const sameDevice = left.dev === 0 || right.dev === 0 || String(left.dev) === String(right.dev);
  return sameDevice && String(left.ino) === String(right.ino);
}

/**
 * Trust precondition: no other local process may modify the project tree during an operation.
 * Prepared links are rejected, but path checks cannot eliminate a concurrent symlink-swap race.
 */
export class ProjectFilesystem {
  private constructor(readonly root: string) {}

  static async open(projectDir: string): Promise<ProjectFilesystem> {
    const root = await realpath(resolve(projectDir));
    if (!(await stat(root)).isDirectory()) throw new UnsafeProjectPathError();
    return new ProjectFilesystem(root);
  }

  path(relativePath: string): string {
    if (!relativePath || isAbsolute(relativePath)) throw new UnsafeProjectPathError();
    const target = resolve(this.root, relativePath);
    if (!isContained(this.root, target)) throw new UnsafeProjectPathError();
    return target;
  }

  private async assertSafe(relativePath: string, leafMayBeFile = true): Promise<void> {
    const target = this.path(relativePath);
    const segments = relative(this.root, target).split(sep).filter(Boolean);
    let current = this.root;
    for (let index = 0; index < segments.length; index += 1) {
      current = resolve(current, segments[index]!);
      let entry;
      try {
        entry = await lstat(current);
      } catch (error) {
        if (isMissing(error)) return;
        throw new UnsafeProjectPathError();
      }
      if (entry.isSymbolicLink()) throw new UnsafeProjectPathError();
      const isLeaf = index === segments.length - 1;
      if (!entry.isDirectory() && !(isLeaf && leafMayBeFile && entry.isFile())) {
        throw new UnsafeProjectPathError();
      }
      const canonical = await realpath(current);
      if (!isContained(this.root, canonical)) throw new UnsafeProjectPathError();
    }
  }

  async ensureDirectory(relativePath: string): Promise<void> {
    const target = this.path(relativePath);
    const segments = relative(this.root, target).split(sep).filter(Boolean);
    let currentRelative = "";
    for (const segment of segments) {
      currentRelative = currentRelative ? `${currentRelative}${sep}${segment}` : segment;
      await this.assertSafe(currentRelative, false);
      try {
        await mkdir(this.path(currentRelative));
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "EEXIST") {
          throw new UnsafeProjectPathError();
        }
      }
      await this.assertSafe(currentRelative, false);
    }
  }

  async exists(relativePath: string): Promise<boolean> {
    await this.assertSafe(relativePath);
    try {
      await lstat(this.path(relativePath));
      return true;
    } catch (error) {
      if (isMissing(error)) return false;
      throw new UnsafeProjectPathError();
    }
  }

  async read(relativePath: string): Promise<string> {
    await this.assertSafe(relativePath);
    let handle: Awaited<ReturnType<typeof open>> | undefined;
    try {
      handle = await open(
        this.path(relativePath),
        constants.O_RDONLY | (process.platform === "win32" ? 0 : (constants.O_NOFOLLOW ?? 0)),
      );
      const [opened, linked] = await Promise.all([
        handle.stat(),
        lstat(this.path(relativePath)),
      ]);
      if (!linked.isFile() || linked.isSymbolicLink() || !sameIdentity(opened, linked)) {
        throw new UnsafeProjectPathError();
      }
      return await handle.readFile("utf8");
    } catch (error) {
      if (isMissing(error)) throw error;
      throw new UnsafeProjectPathError();
    } finally {
      await handle?.close().catch(() => undefined);
    }
  }

  async readOptional(relativePath: string): Promise<string | null> {
    try {
      return await this.read(relativePath);
    } catch (error) {
      if (isMissing(error)) return null;
      throw error;
    }
  }

  async writeExclusive(relativePath: string, contents: string, mode?: number): Promise<void> {
    await this.assertSafe(relativePath);
    let handle: Awaited<ReturnType<typeof open>> | undefined;
    let created = false;
    try {
      handle = await open(
        this.path(relativePath),
        constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL |
          (process.platform === "win32" ? 0 : (constants.O_NOFOLLOW ?? 0)),
        mode,
      );
      created = true;
      const [opened, linked] = await Promise.all([
        handle.stat(),
        lstat(this.path(relativePath)),
      ]);
      if (!linked.isFile() || linked.isSymbolicLink() || !sameIdentity(opened, linked)) {
        throw new UnsafeProjectPathError();
      }
      await handle.writeFile(contents, "utf8");
      await handle.sync();
    } catch (error) {
      if (created) await rm(this.path(relativePath), { force: true }).catch(() => undefined);
      if ((error as NodeJS.ErrnoException).code === "EEXIST") throw error;
      throw new UnsafeProjectPathError();
    } finally {
      await handle?.close().catch(() => undefined);
    }
    const parent = relativePath.split(/[\\/]/).slice(0, -1).join(sep);
    if (parent) await this.sync(parent).catch(() => undefined);
  }

  async linkExclusive(from: string, to: string): Promise<void> {
    await this.assertSafe(from);
    await this.assertSafe(to);
    let created = false;
    try {
      await link(this.path(from), this.path(to));
      created = true;
      const [source, claim] = await Promise.all([
        lstat(this.path(from)),
        lstat(this.path(to)),
      ]);
      if (
        !source.isFile() ||
        source.isSymbolicLink() ||
        !claim.isFile() ||
        claim.isSymbolicLink() ||
        !sameIdentity(source, claim)
      ) throw new UnsafeProjectPathError();
    } catch (error) {
      if (created) await rm(this.path(to), { force: true }).catch(() => undefined);
      if ((error as NodeJS.ErrnoException).code === "EEXIST") throw error;
      throw new UnsafeProjectPathError();
    }
  }

  async writeAtomic(relativePath: string, contents: string, temporaryName: string): Promise<void> {
    const parent = relativePath.split(/[\\/]/).slice(0, -1).join(sep);
    const temporary = parent ? `${parent}${sep}${temporaryName}` : temporaryName;
    await this.writeExclusive(temporary, contents);
    try {
      await this.rename(temporary, relativePath);
    } catch (error) {
      await this.remove(temporary).catch(() => undefined);
      throw error;
    }
  }

  async chmod(relativePath: string, mode: number): Promise<void> {
    await this.assertSafe(relativePath);
    await chmod(this.path(relativePath), mode);
  }

  async mode(relativePath: string): Promise<number> {
    await this.assertSafe(relativePath);
    return (await stat(this.path(relativePath))).mode & 0o777;
  }

  async rename(from: string, to: string): Promise<void> {
    await this.assertSafe(from);
    await this.assertSafe(to);
    await rename(this.path(from), this.path(to));
    await this.assertSafe(to);
    const parent = to.split(/[\\/]/).slice(0, -1).join(sep);
    if (parent) await this.sync(parent).catch(() => undefined);
  }

  async list(relativePath: string): Promise<string[]> {
    await this.assertSafe(relativePath, false);
    return readdir(this.path(relativePath));
  }

  async remove(relativePath: string, recursive = false): Promise<void> {
    await this.assertSafe(relativePath);
    if (recursive && await this.exists(relativePath)) await this.assertTreeSafe(relativePath);
    await rm(this.path(relativePath), { recursive, force: true });
  }

  async sync(relativePath: string): Promise<void> {
    await this.assertSafe(relativePath);
    const handle = await open(this.path(relativePath), "r");
    try {
      await handle.sync();
    } finally {
      await handle.close();
    }
  }

  private async assertTreeSafe(relativePath: string): Promise<void> {
    await this.assertSafe(relativePath, false);
    for (const entry of await this.list(relativePath)) {
      const child = `${relativePath}${sep}${entry}`;
      await this.assertSafe(child);
      const details = await lstat(this.path(child));
      if (details.isDirectory()) await this.assertTreeSafe(child);
    }
  }
}
