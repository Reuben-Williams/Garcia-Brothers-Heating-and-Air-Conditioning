import { execFile } from "node:child_process";
import { constants } from "node:fs";
import { lstat, open, realpath, rm, stat } from "node:fs/promises";
import { isAbsolute, relative, resolve, sep } from "node:path";
import { promisify } from "node:util";

import { ProjectFilesystem } from "./project-filesystem.js";

const execFileAsync = promisify(execFile);
const DIRECTORY_MODE = 0o700;
const FILE_MODE = 0o600;
const ACL_TIMEOUT_MS = 5_000;

export type ProtectedStorageErrorCode = "protected_storage_unavailable";

export class ProtectedStorageError extends Error {
  readonly code: ProtectedStorageErrorCode = "protected_storage_unavailable";

  constructor() {
    super("protected_storage_unavailable");
    this.name = "ProtectedStorageError";
  }
}

export interface WindowsAclEntry {
  sid: string;
  allow: boolean;
  inherited: boolean;
  fullControl: boolean;
}

export interface WindowsAclSnapshot {
  ownerSid: string;
  inheritanceDisabled: boolean;
  isReparsePoint: boolean;
  entries: readonly WindowsAclEntry[];
}

export interface WindowsAclAdapter {
  currentUserSid(): Promise<string>;
  protect(path: string, kind: "directory" | "file"): Promise<void>;
  inspect(path: string): Promise<WindowsAclSnapshot>;
}

export interface ProtectedFilesOptions {
  platform?: NodeJS.Platform;
  windowsAcl?: WindowsAclAdapter;
}

interface CommandResult {
  stdout: string;
}

export interface ProtectedFilesCommandAdapter {
  run(command: string, args: readonly string[], timeoutMs: number): Promise<CommandResult>;
}

const defaultCommandAdapter: ProtectedFilesCommandAdapter = {
  async run(command, args, timeoutMs) {
    const result = await execFileAsync(command, [...args], {
      encoding: "utf8",
      timeout: timeoutMs,
      windowsHide: true,
      maxBuffer: 128 * 1024,
    });
    return { stdout: result.stdout };
  },
};

const CURRENT_SID_SCRIPT = String.raw`
$ErrorActionPreference = 'Stop'
[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
`;

const PROTECT_ACL_SCRIPT = String.raw`
& {
param($target, $kind)
$ErrorActionPreference = 'Stop'
$sid = [Security.Principal.WindowsIdentity]::GetCurrent().User
function Invoke-Icacls([string[]]$arguments) {
  & icacls.exe @arguments | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'icacls failed' }
}
Invoke-Icacls @($target, '/inheritance:r')
$acl = Get-Acl -LiteralPath $target
$identities = @($acl.Access | ForEach-Object {
  $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
} | Sort-Object -Unique)
foreach ($identity in $identities) {
  Invoke-Icacls @($target, '/remove:d', "*$identity")
  if ($identity -ne $sid.Value) { Invoke-Icacls @($target, '/remove:g', "*$identity") }
}
$permission = if ($kind -eq 'directory') {
  "*$($sid.Value):(OI)(CI)F"
} else {
  "*$($sid.Value):F"
}
Invoke-Icacls @($target, '/grant:r', $permission)
}
`;

const INSPECT_ACL_SCRIPT = String.raw`
& {
param($target)
$ErrorActionPreference = 'Stop'
$acl = Get-Acl -LiteralPath $target
$item = Get-Item -LiteralPath $target -Force
$owner = New-Object System.Security.Principal.NTAccount($acl.Owner)
$rules = @($acl.Access | ForEach-Object {
  $identity = $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
  [pscustomobject]@{
    sid = $identity
    allow = $_.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow
    inherited = $_.IsInherited
    fullControl = ($_.FileSystemRights -band [Security.AccessControl.FileSystemRights]::FullControl) -eq [Security.AccessControl.FileSystemRights]::FullControl
  }
})
[pscustomobject]@{
  ownerSid = $owner.Translate([Security.Principal.SecurityIdentifier]).Value
  inheritanceDisabled = $acl.AreAccessRulesProtected
  isReparsePoint = ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0
  entries = $rules
} | ConvertTo-Json -Compress -Depth 4
}
`;

function quotePowerShellLiteral(value: string): string {
  return `'${value.replaceAll("'", "''")}'`;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function parseAclSnapshot(value: string): WindowsAclSnapshot {
  const parsed: unknown = JSON.parse(value);
  if (
    !isRecord(parsed) ||
    typeof parsed.ownerSid !== "string" ||
    typeof parsed.inheritanceDisabled !== "boolean" ||
    typeof parsed.isReparsePoint !== "boolean" ||
    !Array.isArray(parsed.entries) ||
    !parsed.entries.every((entry) =>
      isRecord(entry) &&
      typeof entry.sid === "string" &&
      typeof entry.allow === "boolean" &&
      typeof entry.inherited === "boolean" &&
      typeof entry.fullControl === "boolean")
  ) {
    throw new ProtectedStorageError();
  }
  return parsed as unknown as WindowsAclSnapshot;
}

export function createWindowsAclAdapter(
  commands: ProtectedFilesCommandAdapter = defaultCommandAdapter,
): WindowsAclAdapter {
  return {
    async currentUserSid() {
      const result = await commands.run(
        "powershell.exe",
        ["-NoLogo", "-NoProfile", "-NonInteractive", "-Command", CURRENT_SID_SCRIPT],
        ACL_TIMEOUT_MS,
      );
      const sid = result.stdout.trim();
      if (!sid) throw new ProtectedStorageError();
      return sid;
    },
    async protect(path, kind) {
      await commands.run(
        "powershell.exe",
        [
          "-NoLogo",
          "-NoProfile",
          "-NonInteractive",
          "-Command",
          PROTECT_ACL_SCRIPT.trim(),
          quotePowerShellLiteral(path),
          quotePowerShellLiteral(kind),
        ],
        ACL_TIMEOUT_MS,
      );
    },
    async inspect(path) {
      const result = await commands.run(
        "powershell.exe",
        [
          "-NoLogo",
          "-NoProfile",
          "-NonInteractive",
          "-Command",
          INSPECT_ACL_SCRIPT.trim(),
          quotePowerShellLiteral(path),
        ],
        ACL_TIMEOUT_MS,
      );
      return parseAclSnapshot(result.stdout);
    },
  };
}

function isMissing(error: unknown): boolean {
  return (error as NodeJS.ErrnoException).code === "ENOENT";
}

function isUnsupportedWindowsDirectorySync(error: unknown): boolean {
  return ["EACCES", "EBADF", "EINVAL", "EISDIR", "ENOTSUP", "EPERM"]
    .includes((error as NodeJS.ErrnoException).code ?? "");
}

function isContained(root: string, candidate: string): boolean {
  const path = relative(root, candidate);
  return path === "" || (!path.startsWith(`..${sep}`) && path !== ".." && !isAbsolute(path));
}

function sameIdentity(
  left: { dev: number | bigint; ino: number | bigint },
  right: { dev: number | bigint; ino: number | bigint },
): boolean {
  const sameDevice = left.dev === 0 || right.dev === 0 || String(left.dev) === String(right.dev);
  return sameDevice && String(left.ino) === String(right.ino);
}

export class ProtectedFiles {
  private readonly rootPath: string;

  private constructor(
    private readonly files: ProjectFilesystem,
    private readonly root: string,
    private readonly platform: NodeJS.Platform,
    private readonly windowsAcl: WindowsAclAdapter,
    private readonly currentSid: string | null,
  ) {
    this.rootPath = files.path(root);
  }

  static async open(
    files: ProjectFilesystem,
    root: string,
    options: ProtectedFilesOptions = {},
  ): Promise<ProtectedFiles> {
    const platform = options.platform ?? process.platform;
    const windowsAcl = options.windowsAcl ?? createWindowsAclAdapter();
    try {
      await files.ensureDirectory(root);
      const currentSid = platform === "win32" ? await windowsAcl.currentUserSid() : null;
      const protectedFiles = new ProtectedFiles(files, root, platform, windowsAcl, currentSid);
      await protectedFiles.applyDirectoryProtection(root);
      await protectedFiles.verifyDirectory(root);
      return protectedFiles;
    } catch {
      throw new ProtectedStorageError();
    }
  }

  path(relativePath: string): string {
    const target = this.files.path(relativePath);
    if (!isContained(this.rootPath, target)) throw new ProtectedStorageError();
    return target;
  }

  private parent(relativePath: string): string {
    const absolute = this.path(relativePath);
    const parent = resolve(absolute, "..");
    const projectRelative = relative(this.files.root, parent);
    if (!projectRelative || !isContained(this.rootPath, parent)) throw new ProtectedStorageError();
    return projectRelative;
  }

  private async applyDirectoryProtection(relativePath: string): Promise<void> {
    const path = this.path(relativePath);
    if (this.platform === "win32") await this.windowsAcl.protect(path, "directory");
    else await this.files.chmod(relativePath, DIRECTORY_MODE);
  }

  private async applyFileProtection(relativePath: string): Promise<void> {
    const path = this.path(relativePath);
    if (this.platform === "win32") await this.windowsAcl.protect(path, "file");
    else await this.files.chmod(relativePath, FILE_MODE);
  }

  private async verifyAcl(relativePath: string): Promise<void> {
    const snapshot = await this.windowsAcl.inspect(this.path(relativePath));
    if (
      !this.currentSid ||
      snapshot.ownerSid !== this.currentSid ||
      !snapshot.inheritanceDisabled ||
      snapshot.isReparsePoint ||
      snapshot.entries.length === 0 ||
      snapshot.entries.some((entry) =>
        entry.sid !== this.currentSid || entry.inherited || !entry.allow || !entry.fullControl)
    ) {
      throw new ProtectedStorageError();
    }
  }

  private async verifyOwner(details: { uid: number }): Promise<void> {
    const getuid = process.getuid;
    if (typeof getuid === "function" && details.uid !== getuid()) throw new ProtectedStorageError();
  }

  private async verifyDirectory(relativePath: string): Promise<void> {
    try {
      const path = this.path(relativePath);
      const details = await lstat(path);
      if (!details.isDirectory() || details.isSymbolicLink()) throw new ProtectedStorageError();
      const canonical = await realpath(path);
      if (!isContained(this.rootPath, canonical) && path !== this.rootPath) {
        throw new ProtectedStorageError();
      }
      if (this.platform === "win32") await this.verifyAcl(relativePath);
      else {
        await this.verifyOwner(details);
        if ((details.mode & 0o777) !== DIRECTORY_MODE) throw new ProtectedStorageError();
      }
    } catch {
      throw new ProtectedStorageError();
    }
  }

  private async verifyFile(relativePath: string): Promise<void> {
    try {
      const details = await lstat(this.path(relativePath));
      if (!details.isFile() || details.isSymbolicLink()) throw new ProtectedStorageError();
      if (this.platform === "win32") await this.verifyAcl(relativePath);
      else {
        await this.verifyOwner(details);
        if ((details.mode & 0o777) !== FILE_MODE) throw new ProtectedStorageError();
      }
    } catch {
      throw new ProtectedStorageError();
    }
  }

  private async verifyParents(relativePath: string): Promise<void> {
    const target = this.path(relativePath);
    const parent = resolve(target, "..");
    if (!isContained(this.rootPath, parent)) throw new ProtectedStorageError();
    await this.verifyDirectory(this.root);
    const nested = relative(this.rootPath, parent).split(sep).filter(Boolean);
    let current = this.root;
    for (const segment of nested) {
      current = `${current}${sep}${segment}`;
      await this.verifyDirectory(current);
    }
  }

  async ensureDirectory(relativePath: string): Promise<void> {
    try {
      this.path(relativePath);
      await this.verifyDirectory(this.root);
      const nested = relative(this.rootPath, this.path(relativePath)).split(sep).filter(Boolean);
      let current = this.root;
      for (const segment of nested) {
        current = `${current}${sep}${segment}`;
        await this.files.ensureDirectory(current);
        await this.applyDirectoryProtection(current);
        await this.verifyDirectory(current);
      }
    } catch {
      throw new ProtectedStorageError();
    }
  }

  async exists(relativePath: string): Promise<boolean> {
    try {
      await this.verifyParents(relativePath);
      if (!await this.files.exists(relativePath)) return false;
      const details = await lstat(this.path(relativePath));
      if (details.isDirectory()) await this.verifyDirectory(relativePath);
      else await this.verifyFile(relativePath);
      return true;
    } catch (error) {
      if (error instanceof ProtectedStorageError) throw error;
      throw new ProtectedStorageError();
    }
  }

  async writeExclusive(relativePath: string, contents: string): Promise<void> {
    let handle: Awaited<ReturnType<typeof open>> | undefined;
    let created = false;
    try {
      await this.verifyParents(relativePath);
      const noFollow = this.platform === "win32" ? 0 : (constants.O_NOFOLLOW ?? 0);
      const flags = constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | noFollow;
      handle = await open(this.path(relativePath), flags, FILE_MODE);
      created = true;
      const [opened, linked] = await Promise.all([handle.stat(), lstat(this.path(relativePath))]);
      if (!linked.isFile() || linked.isSymbolicLink() || !sameIdentity(opened, linked)) {
        throw new ProtectedStorageError();
      }
      await this.applyFileProtection(relativePath);
      await this.verifyParents(relativePath);
      await this.verifyFile(relativePath);
      await handle.writeFile(contents, "utf8");
      await handle.sync();
      await handle.close();
      handle = undefined;
      try {
        await this.files.sync(this.parent(relativePath));
      } catch (error) {
        if (this.platform !== "win32" || !isUnsupportedWindowsDirectorySync(error)) {
          throw new ProtectedStorageError();
        }
      }
    } catch {
      await handle?.close().catch(() => undefined);
      if (created) await rm(this.path(relativePath), { force: true }).catch(() => undefined);
      throw new ProtectedStorageError();
    }
  }

  async claimExisting(from: string, claim: string): Promise<boolean> {
    try {
      await this.verifyParents(from);
      await this.verifyFile(from);
      await this.verifyParents(claim);
      await this.files.linkExclusive(from, claim);
      await this.verifyFile(from);
      await this.verifyFile(claim);
      return true;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "EEXIST") return false;
      throw new ProtectedStorageError();
    }
  }

  async read(relativePath: string): Promise<string> {
    let handle: Awaited<ReturnType<typeof open>> | undefined;
    try {
      await this.verifyParents(relativePath);
      const flags = constants.O_RDONLY |
        (this.platform === "win32" ? 0 : (constants.O_NOFOLLOW ?? 0));
      handle = await open(this.path(relativePath), flags);
      const [opened, linked] = await Promise.all([handle.stat(), lstat(this.path(relativePath))]);
      if (!linked.isFile() || linked.isSymbolicLink() || !sameIdentity(opened, linked)) {
        throw new ProtectedStorageError();
      }
      await this.verifyParents(relativePath);
      await this.verifyFile(relativePath);
      return await handle.readFile("utf8");
    } catch (error) {
      if (isMissing(error)) throw error;
      throw new ProtectedStorageError();
    } finally {
      await handle?.close().catch(() => undefined);
    }
  }

  async readOptional(relativePath: string): Promise<string | null> {
    try {
      return await this.read(relativePath);
    } catch (error) {
      if (isMissing(error)) return null;
      throw error;
    }
  }

  async writeAtomic(relativePath: string, contents: string, temporaryName: string): Promise<void> {
    const parent = this.parent(relativePath);
    const temporary = `${parent}${sep}${temporaryName}`;
    await this.writeExclusive(temporary, contents);
    try {
      await this.rename(temporary, relativePath);
    } catch (error) {
      await this.remove(temporary).catch(() => undefined);
      throw error;
    }
  }

  async rename(from: string, to: string): Promise<void> {
    try {
      await this.verifyParents(from);
      const source = await lstat(this.path(from));
      const isDirectory = source.isDirectory() && !source.isSymbolicLink();
      if (isDirectory) await this.verifyDirectory(from);
      else await this.verifyFile(from);
      await this.verifyParents(to);
      await this.files.rename(from, to);
      await this.verifyParents(to);
      if (isDirectory) await this.verifyDirectory(to);
      else await this.verifyFile(to);
    } catch {
      throw new ProtectedStorageError();
    }
  }

  async list(relativePath: string): Promise<string[]> {
    try {
      await this.verifyParents(`${relativePath}${sep}child`);
      await this.verifyDirectory(relativePath);
      return await this.files.list(relativePath);
    } catch {
      throw new ProtectedStorageError();
    }
  }

  async remove(relativePath: string, recursive = false): Promise<void> {
    try {
      await this.verifyParents(relativePath);
      const parent = this.parent(relativePath);
      await this.files.remove(relativePath, recursive);
      try {
        await this.files.sync(parent);
      } catch (error) {
        if (this.platform !== "win32" || !isUnsupportedWindowsDirectorySync(error)) {
          throw new ProtectedStorageError();
        }
      }
      await this.verifyDirectory(parent);
    } catch {
      throw new ProtectedStorageError();
    }
  }

  async sync(relativePath: string): Promise<void> {
    try {
      const details = await stat(this.path(relativePath));
      if (details.isDirectory()) await this.verifyDirectory(relativePath);
      else await this.verifyFile(relativePath);
      await this.files.sync(relativePath);
    } catch {
      throw new ProtectedStorageError();
    }
  }
}
