import { createHash } from "node:crypto";

export function fingerprintSource(source: string): string {
  return createHash("sha256").update(source.replace(/\r\n/g, "\n"), "utf8").digest("hex");
}
