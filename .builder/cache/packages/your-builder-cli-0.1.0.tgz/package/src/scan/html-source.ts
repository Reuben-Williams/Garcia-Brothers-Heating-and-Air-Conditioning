import { parseFragment } from "parse5";
import { fingerprintSource } from "./source-fingerprint.js";
import { inferPostFieldMappings, mapCandidateRecord, type PostScanResult } from "./post-candidates.js";

interface HtmlAttribute { name: string; value: string }
interface HtmlNode {
  nodeName: string;
  tagName?: string;
  value?: string;
  attrs?: HtmlAttribute[];
  childNodes?: HtmlNode[];
}

function descendants(node: HtmlNode, tagName: string): HtmlNode[] {
  const matches: HtmlNode[] = [];
  for (const child of node.childNodes ?? []) {
    if (child.tagName === tagName) matches.push(child);
    matches.push(...descendants(child, tagName));
  }
  return matches;
}

function first(node: HtmlNode, tagNames: readonly string[]): HtmlNode | undefined {
  for (const tagName of tagNames) {
    const match = descendants(node, tagName)[0];
    if (match) return match;
  }
  return undefined;
}

function textContent(node: HtmlNode | undefined): string {
  if (!node) return "";
  if (node.nodeName === "#text") return node.value ?? "";
  return (node.childNodes ?? []).map(textContent).join(" ").replace(/\s+/g, " ").trim();
}

function attribute(node: HtmlNode | undefined, name: string): string {
  return node?.attrs?.find((item) => item.name === name)?.value ?? "";
}

export function scanHtmlPostCandidates(input: { html: string; filePath: string; route: string }): PostScanResult {
  const document = parseFragment(input.html) as unknown as HtmlNode;
  const articles = descendants(document, "article");
  if (articles.length < 2) return { collections: [], warnings: [] };

  const rawRecords = articles.map((article, index) => {
    const heading = first(article, ["h1", "h2", "h3", "h4", "h5", "h6"]);
    const paragraph = first(article, ["p"]);
    const image = first(article, ["img"]);
    const time = first(article, ["time"]);
    const link = first(article, ["a"]);
    const category = first(article, ["data", "small"]);
    return {
      id: attribute(article, "data-id") || attribute(article, "id") || `record-${index + 1}`,
      title: textContent(heading),
      excerpt: textContent(paragraph),
      image: attribute(image, "src"),
      date: attribute(time, "datetime") || textContent(time),
      category: textContent(category),
      href: attribute(link, "href"),
    };
  });
  const keys = Object.keys(rawRecords[0] ?? {});
  const fieldMappings = inferPostFieldMappings(keys);
  const records = rawRecords.map((record, index) => mapCandidateRecord(record, fieldMappings, index));
  const incomplete = records.some((record) => !record.title || (!record.excerpt && !record.image));

  return {
    collections: [{
      id: `${input.route}:html-articles`,
      recordName: "htmlArticles",
      route: input.route,
      filePath: input.filePath,
      itemCount: records.length,
      confidence: incomplete ? "medium" : "high",
      sourceFingerprint: fingerprintSource(input.html),
      fieldMappings,
      records,
    }],
    warnings: incomplete ? [{ code: "scan.post.incomplete-records", message: "Some article cards need manual field mapping.", filePath: input.filePath }] : [],
  };
}
