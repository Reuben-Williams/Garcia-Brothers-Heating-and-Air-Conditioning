export type PostScanConfidence = "high" | "medium" | "low" | "manualReview";

export interface PostScanWarning {
  code: string;
  message: string;
  filePath: string;
}

export interface PostCandidateRecord {
  sourceKey: string;
  title?: string;
  excerpt?: string;
  image?: string;
  displayDate?: string;
  category?: string;
  detailHref?: string;
  values: Record<string, string>;
}

export interface PostCollectionCandidate {
  id: string;
  recordName: string;
  route: string;
  filePath: string;
  itemCount: number;
  confidence: PostScanConfidence;
  sourceFingerprint: string;
  fieldMappings: Partial<Record<"title" | "excerpt" | "image" | "displayDate" | "category" | "detailHref", string>>;
  records: PostCandidateRecord[];
}

export interface PostScanResult {
  collections: PostCollectionCandidate[];
  warnings: PostScanWarning[];
}

const fieldAliases: Record<keyof PostCollectionCandidate["fieldMappings"], readonly string[]> = {
  title: ["title", "headline", "name"],
  excerpt: ["excerpt", "summary", "description", "copy"],
  image: ["image", "imageSrc", "imageUrl", "src", "photo"],
  displayDate: ["displayDate", "date", "publishedAt", "publishedOn"],
  category: ["category", "categoryKey", "type"],
  detailHref: ["href", "url", "detailHref", "link"],
};

export function inferPostFieldMappings(keys: readonly string[]) {
  const mappings: PostCollectionCandidate["fieldMappings"] = {};
  for (const [field, aliases] of Object.entries(fieldAliases) as Array<[keyof typeof fieldAliases, readonly string[]]>) {
    const match = aliases.find((alias) => keys.includes(alias));
    if (match) mappings[field] = match;
  }
  return mappings;
}

export function mapCandidateRecord(values: Record<string, string>, mappings: PostCollectionCandidate["fieldMappings"], index: number): PostCandidateRecord {
  const read = (field: keyof PostCollectionCandidate["fieldMappings"]) => {
    const key = mappings[field];
    return key ? values[key] : undefined;
  };
  return {
    sourceKey: values.id ?? values.key ?? values.slug ?? `record-${index + 1}`,
    title: read("title"),
    excerpt: read("excerpt"),
    image: read("image"),
    displayDate: read("displayDate"),
    category: read("category"),
    detailHref: read("detailHref"),
    values,
  };
}
