import ts from "typescript";
import { fingerprintSource } from "./source-fingerprint.js";
import { inferPostFieldMappings, mapCandidateRecord, type PostScanResult } from "./post-candidates.js";

export function scanNextPostCandidates(input: { source: string; filePath: string; route: string }): PostScanResult {
  const sourceFile = ts.createSourceFile(input.filePath, input.source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const arrays = new Map<string, ts.ArrayLiteralExpression>();
  const rendererCounts = new Map<string, number>();

  const visit = (node: ts.Node) => {
    if (ts.isVariableDeclaration(node) && ts.isIdentifier(node.name) && node.initializer && ts.isArrayLiteralExpression(node.initializer)) {
      if (node.initializer.elements.length >= 2 && node.initializer.elements.every(ts.isObjectLiteralExpression)) arrays.set(node.name.text, node.initializer);
    }
    if (
      ts.isCallExpression(node) &&
      ts.isPropertyAccessExpression(node.expression) &&
      node.expression.name.text === "map" &&
      ts.isIdentifier(node.expression.expression)
    ) {
      const name = node.expression.expression.text;
      rendererCounts.set(name, (rendererCounts.get(name) ?? 0) + 1);
    }
    ts.forEachChild(node, visit);
  };
  visit(sourceFile);

  const warnings: PostScanResult["warnings"] = [];
  const collections = Array.from(arrays, ([recordName, array]) => {
    const objectRecords = array.elements.filter(ts.isObjectLiteralExpression);
    const keys = objectRecords.flatMap((record) => record.properties.flatMap((property) => {
      if (!ts.isPropertyAssignment(property)) return [];
      return [property.name.getText(sourceFile).replace(/^['"]|['"]$/g, "")];
    }));
    const fieldMappings = inferPostFieldMappings([...new Set(keys)]);
    const records = objectRecords.map((record, index) => {
      const values: Record<string, string> = {};
      for (const property of record.properties) {
        if (!ts.isPropertyAssignment(property)) continue;
        const key = property.name.getText(sourceFile).replace(/^['"]|['"]$/g, "");
        const initializer = property.initializer;
        if (ts.isStringLiteralLike(initializer) || ts.isNumericLiteral(initializer)) values[key] = initializer.text;
        else if (initializer.kind === ts.SyntaxKind.TrueKeyword || initializer.kind === ts.SyntaxKind.FalseKeyword) values[key] = initializer.getText(sourceFile);
      }
      return mapCandidateRecord(values, fieldMappings, index);
    });
    const renderers = rendererCounts.get(recordName) ?? 0;
    if (renderers > 1) warnings.push({ code: "scan.post.multiple-renderers", message: `${recordName} is rendered in more than one JSX branch.`, filePath: input.filePath });
    const hasCoreFields = Boolean(fieldMappings.title && (fieldMappings.excerpt || fieldMappings.image));
    return {
      id: `${input.route}:${recordName}`,
      recordName,
      route: input.route,
      filePath: input.filePath,
      itemCount: records.length,
      confidence: renderers > 1 ? "manualReview" as const : hasCoreFields ? "high" as const : "medium" as const,
      sourceFingerprint: fingerprintSource(input.source),
      fieldMappings,
      records,
    };
  });

  return { collections, warnings };
}
