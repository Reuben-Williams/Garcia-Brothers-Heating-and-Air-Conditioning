import type {
  AppliedOrConflict,
  IdentityMatchingService,
  IdentityMatchResult,
} from "@your-builder/growth-core";
import type {
  AddLeadNoteCommand,
  AssignLeadCommand,
  BulkLeadAssignmentCommand,
  BulkLeadCommandResult,
  BulkLeadStatusCommand,
  BulkLeadTagCommand,
  LeadBulkRecordResult,
  ChangeLeadStatusCommand,
  CreateLeadTaskCommand,
  CreateManualLeadCommand,
  LeadCommandService,
  RecordLeadServiceEventCommand,
  SetLeadPriorityCommand,
} from "./commands.js";
import {
  MANUAL_LEAD_SOURCES,
  type Lead,
  type LeadDetail,
  type LeadEvent,
  type LeadListItem,
} from "./lead.js";
import type {
  GetLeadQuery,
  LeadPage,
  ListLeadsQuery,
} from "./queries.js";
import { transitionLead } from "./state-machine.js";
import {
  LEAD_INPUT_LIMITS,
  normalizeBoundedText,
  US_ZIP_PATTERN,
} from "./validation.js";

export type LeadServiceErrorCode =
  | "not_authorized"
  | "invalid_query"
  | "invalid_source"
  | "invalid_request"
  | "invalid_state"
  | "identity_conflict"
  | "not_found";

export class LeadServiceError extends Error {
  readonly code: LeadServiceErrorCode;

  constructor(code: LeadServiceErrorCode) {
    super(code);
    this.name = "LeadServiceError";
    this.code = code;
  }
}

export type LeadQueryScope = "site" | "assigned";
export type ScopedListLeadsQuery = ListLeadsQuery & { readonly scope: LeadQueryScope };
export type ScopedGetLeadQuery = GetLeadQuery & { readonly scope: LeadQueryScope };

export interface LeadQueryRepository {
  list(input: ScopedListLeadsQuery): Promise<LeadPage>;
  get(input: ScopedGetLeadQuery): Promise<import("./lead.js").LeadDetail | null>;
}

export interface ScopedLeadQueryService {
  list(input: ScopedListLeadsQuery): Promise<LeadPage>;
  get(input: ScopedGetLeadQuery): Promise<import("./lead.js").LeadDetail | null>;
}

export function createLeadQueryService(repository: LeadQueryRepository): ScopedLeadQueryService {
  return {
    async list(input) {
      if (!Number.isInteger(input.limit) || input.limit < 1 || input.limit > 100) {
        throw new LeadServiceError("invalid_query");
      }
      const page = await repository.list(input);
      return {
        items: page.items.map(projectLeadListItem),
        ...(page.nextCursor === undefined ? {} : { nextCursor: page.nextCursor }),
      };
    },
    async get(input) {
      const result = await repository.get(input);
      return result?.siteId === input.siteId ? projectLeadDetail(result) : null;
    },
  };
}

function projectLeadListItem(lead: LeadListItem): LeadListItem {
  return {
    id: lead.id,
    customerId: lead.customerId,
    customerDisplayName: lead.customerDisplayName,
    service: lead.service,
    urgency: lead.urgency,
    ...(lead.priority === undefined ? {} : { priority: lead.priority }),
    status: lead.status,
    displayLane: lead.displayLane,
    ...(lead.assigneeId === undefined ? {} : { assigneeId: lead.assigneeId }),
    createdAt: lead.createdAt,
    updatedAt: lead.updatedAt,
    version: lead.version,
  };
}

function projectLead(lead: Lead): Lead {
  return {
    id: lead.id,
    siteId: lead.siteId,
    contactId: lead.contactId,
    ...(lead.submissionId === undefined ? {} : { submissionId: lead.submissionId }),
    ...(lead.formId === undefined ? {} : { formId: lead.formId }),
    source: lead.source,
    service: lead.service,
    urgency: lead.urgency,
    ...(lead.priority === undefined ? {} : { priority: lead.priority }),
    status: lead.status,
    summary: lead.summary,
    ...(lead.primaryAssigneeId === undefined ? {} : { primaryAssigneeId: lead.primaryAssigneeId }),
    version: lead.version,
    createdAt: lead.createdAt,
    updatedAt: lead.updatedAt,
  };
}

function projectLeadEvent(event: LeadEvent): LeadEvent {
  return {
    ...(event.id === undefined ? {} : { id: event.id }),
    siteId: event.siteId,
    leadId: event.leadId,
    kind: event.kind,
    ...(event.actorId === undefined ? {} : { actorId: event.actorId }),
    ...(event.from === undefined ? {} : { from: event.from }),
    ...(event.to === undefined ? {} : { to: event.to }),
    ...(event.body === undefined ? {} : { body: event.body }),
    ...(event.relatedId === undefined ? {} : { relatedId: event.relatedId }),
    ...(event.correctionOfEventId === undefined ? {} : { correctionOfEventId: event.correctionOfEventId }),
    occurredAt: event.occurredAt,
  };
}

function projectLeadDetail(lead: LeadDetail): LeadDetail {
  return {
    ...projectLead(lead),
    timeline: lead.timeline.map(projectLeadEvent),
    ...(lead.duplicateWarning === undefined ? {} : {
      duplicateWarning: {
        suggestionId: lead.duplicateWarning.suggestionId,
        confidence: lead.duplicateWarning.confidence,
      },
    }),
    ...(lead.originalSubmissionId === undefined ? {} : { originalSubmissionId: lead.originalSubmissionId }),
  };
}

export interface LeadAtomicOutboxIntent {
  readonly topic: "growth.lead.created" | "growth.lead.assigned";
  readonly schemaVersion: 1;
  readonly correlationId: string;
}

export interface LeadAtomicNotificationIntent {
  readonly recipientMemberId: string;
  readonly eventType: "lead.assigned";
  readonly relatedType: "lead";
}

/** A non-authoritative preflight result. Persistence must re-resolve identities transactionally. */
export type AdvisoryIdentityMatchHint = IdentityMatchResult;

export interface CreateManualLeadAtomicCommand {
  readonly command: CreateManualLeadCommand;
  readonly identityMatchHint: AdvisoryIdentityMatchHint;
  readonly assigneeId: string;
  readonly event: Omit<LeadEvent, "leadId">;
  readonly outbox: LeadAtomicOutboxIntent;
  readonly notification: LeadAtomicNotificationIntent;
}

export interface ChangeLeadStatusAtomicCommand {
  readonly command: ChangeLeadStatusCommand;
  readonly nextLead: Lead;
  readonly event: LeadEvent;
}

export interface AssignLeadAtomicCommand {
  readonly command: AssignLeadCommand;
  readonly event: LeadEvent;
  readonly outbox: LeadAtomicOutboxIntent;
  readonly notification: LeadAtomicNotificationIntent;
}

export interface AddLeadNoteAtomicCommand {
  readonly command: AddLeadNoteCommand;
  readonly event: LeadEvent;
}

export interface SetLeadPriorityAtomicCommand {
  readonly command: SetLeadPriorityCommand;
  readonly event: LeadEvent;
}

export interface CreateLeadTaskAtomicCommand {
  readonly command: CreateLeadTaskCommand;
  readonly event: LeadEvent;
}

export interface RecordLeadServiceEventAtomicCommand {
  readonly command: RecordLeadServiceEventCommand;
  readonly event: LeadEvent;
}

export interface LeadCommandRepository {
  /** Re-resolves exact identities, membership, capability, scope, and assignment in its transaction. */
  createManualAtomic(input: CreateManualLeadAtomicCommand): Promise<Lead>;
  get(siteId: string, leadId: string): Promise<Lead | null>;
  assignAtomic(input: AssignLeadAtomicCommand): Promise<AppliedOrConflict<Lead>>;
  addNoteAtomic(input: AddLeadNoteAtomicCommand): Promise<AppliedOrConflict<Lead>>;
  changeStatusAtomic(input: ChangeLeadStatusAtomicCommand): Promise<AppliedOrConflict<Lead>>;
  setPriorityAtomic(input: SetLeadPriorityAtomicCommand): Promise<AppliedOrConflict<Lead>>;
  createTaskAtomic(input: CreateLeadTaskAtomicCommand): Promise<string>;
  recordServiceEventAtomic(input: RecordLeadServiceEventAtomicCommand): Promise<string>;
  /** Rechecks site, capability, assigned scope, target record, and expected version per transaction. */
  bulkStatusRecord(input: {
    readonly command: BulkLeadStatusCommand;
    readonly record: BulkLeadStatusCommand["records"][number];
    readonly scope: LeadQueryScope;
  }): Promise<LeadBulkRecordResult>;
  bulkAssignRecord(input: {
    readonly command: BulkLeadAssignmentCommand;
    readonly record: BulkLeadAssignmentCommand["records"][number];
    readonly scope: LeadQueryScope;
  }): Promise<LeadBulkRecordResult>;
  bulkTagRecord(input: {
    readonly command: BulkLeadTagCommand;
    readonly record: BulkLeadTagCommand["records"][number];
    readonly scope: LeadQueryScope;
  }): Promise<LeadBulkRecordResult>;
}

export interface LeadCommandAuthorization {
  readonly scope: "site" | "assigned";
  readonly canCreate: boolean;
  readonly canUpdate: boolean;
  readonly canAssignOthers: boolean;
}

export interface LeadAuthorizationQuery {
  readonly siteId: string;
  readonly actorId: string;
  readonly action: "create" | "assign" | "update" | "task" | "service_event" | "bulk";
  readonly leadId?: string;
}

export interface LeadCommandServiceDependencies {
  readonly identityMatching: IdentityMatchingService;
  readonly repository: LeadCommandRepository;
  readonly authorize: (input: LeadAuthorizationQuery) => Promise<LeadCommandAuthorization>;
  readonly isActiveSiteMember: (siteId: string, memberId: string) => Promise<boolean>;
  readonly now?: () => string;
}

function requireUpdate(authorization: LeadCommandAuthorization): void {
  if (!authorization.canUpdate) throw new LeadServiceError("not_authorized");
}

function requireMemberActor(actor: { readonly type: string; readonly id?: string }): string {
  if (actor.type !== "member" || !actor.id?.trim()) throw new LeadServiceError("not_authorized");
  return actor.id;
}

function validateManualLead(input: CreateManualLeadCommand): void {
  const firstName = normalizeBoundedText(input.firstName, 1, LEAD_INPUT_LIMITS.name);
  const lastName = normalizeBoundedText(input.lastName, 1, LEAD_INPUT_LIMITS.name);
  const zipCode = normalizeBoundedText(input.zipCode, 5, 10);
  const service = normalizeBoundedText(input.service, 1, LEAD_INPUT_LIMITS.service);
  const notes = input.notes === undefined
    ? undefined
    : normalizeBoundedText(input.notes, 0, LEAD_INPUT_LIMITS.notes);
  if (
    !firstName ||
    !lastName ||
    (!input.email && !input.phone) ||
    !zipCode ||
    !US_ZIP_PATTERN.test(zipCode) ||
    !service ||
    !["standard", "urgent", "emergency"].includes(input.urgency) ||
    notes === null
  ) {
    throw new LeadServiceError("invalid_request");
  }
}

const MAX_BULK_LEAD_RECORDS = 100;

function validateBulkRecords(
  records: readonly { readonly leadId: string; readonly expectedVersion: number }[],
): void {
  if (records.length > MAX_BULK_LEAD_RECORDS) throw new LeadServiceError("invalid_request");
  for (const record of records) {
    if (
      !record.leadId.trim() ||
      record.leadId.length > 128 ||
      !Number.isInteger(record.expectedVersion) ||
      record.expectedVersion < 0
    ) {
      throw new LeadServiceError("invalid_request");
    }
  }
}

function deniedBulkResult(
  leadId: string,
  reason: "not_authorized" | "invalid_request",
): LeadBulkRecordResult {
  return { leadId, status: "denied", reason };
}

async function aggregateBulkResults(
  records: readonly { readonly leadId: string; readonly expectedVersion: number }[],
  apply: (record: { readonly leadId: string; readonly expectedVersion: number }) => Promise<LeadBulkRecordResult>,
): Promise<BulkLeadCommandResult> {
  const results = await Promise.all(records.map(async record => {
    try {
      const result = await apply(record);
      return result.leadId === record.leadId
        ? result
        : deniedBulkResult(record.leadId, "invalid_request");
    } catch (error) {
      return deniedBulkResult(
        record.leadId,
        error instanceof LeadServiceError && error.code === "not_authorized"
          ? "not_authorized"
          : "invalid_request",
      );
    }
  }));
  return { requestedCount: records.length, results };
}

function denyBulkCommand(
  records: readonly { readonly leadId: string }[],
  reason: "not_authorized" | "invalid_request",
): BulkLeadCommandResult {
  return {
    requestedCount: records.length,
    results: records.map(record => deniedBulkResult(record.leadId, reason)),
  };
}

export function createLeadCommandService(
  dependencies: LeadCommandServiceDependencies,
): LeadCommandService {
  const now = dependencies.now ?? (() => new Date().toISOString());
  return {
    async createManual(input) {
      const actorId = requireMemberActor(input.actor);
      if (!MANUAL_LEAD_SOURCES.includes(input.source)) throw new LeadServiceError("invalid_source");
      validateManualLead(input);
      const authorization = await dependencies.authorize({
        siteId: input.siteId,
        actorId,
        action: "create",
      });
      if (!authorization.canCreate) throw new LeadServiceError("not_authorized");

      const assigneeId = input.assigneeId ?? actorId;
      if (assigneeId !== actorId && !authorization.canAssignOthers) {
        throw new LeadServiceError("not_authorized");
      }
      if (!await dependencies.isActiveSiteMember(input.siteId, assigneeId)) {
        throw new LeadServiceError("invalid_request");
      }

      const identityMatchHint = await dependencies.identityMatching.match({
        siteId: input.siteId,
        email: input.email,
        phone: input.phone,
        phoneRegion: "US",
        displayName: `${input.firstName.trim()} ${input.lastName.trim()}`,
        serviceAreaZip: input.zipCode,
      });
      const created = await dependencies.repository.createManualAtomic({
        command: input,
        identityMatchHint,
        assigneeId,
        event: {
          siteId: input.siteId,
          kind: "created",
          actorId,
          occurredAt: now(),
        },
        outbox: {
          topic: "growth.lead.created",
          schemaVersion: 1,
          correlationId: input.idempotencyKey,
        },
        notification: {
          recipientMemberId: assigneeId,
          eventType: "lead.assigned",
          relatedType: "lead",
        },
      });
      return projectLead(created);
    },
    async assign(input) {
      const actorId = requireMemberActor(input.actor);
      const authorization = await dependencies.authorize({ siteId: input.siteId, actorId, action: "assign", leadId: input.leadId });
      if (!authorization.canAssignOthers || !await dependencies.isActiveSiteMember(input.siteId, input.assigneeId)) {
        throw new LeadServiceError("not_authorized");
      }
      return dependencies.repository.assignAtomic({
        command: input,
        event: {
          siteId: input.siteId,
          leadId: input.leadId,
          kind: "assignment",
          actorId,
          relatedId: input.assigneeId,
          occurredAt: now(),
        },
        outbox: {
          topic: "growth.lead.assigned",
          schemaVersion: 1,
          correlationId: input.idempotencyKey,
        },
        notification: {
          recipientMemberId: input.assigneeId,
          eventType: "lead.assigned",
          relatedType: "lead",
        },
      });
    },
    async addNote(input) {
      const actorId = requireMemberActor(input.actor);
      const body = normalizeBoundedText(input.body, 1, LEAD_INPUT_LIMITS.notes);
      if (!body) throw new LeadServiceError("invalid_request");
      const authorization = await dependencies.authorize({ siteId: input.siteId, actorId, action: "update", leadId: input.leadId });
      requireUpdate(authorization);
      return dependencies.repository.addNoteAtomic({
        command: input,
        event: {
          siteId: input.siteId,
          leadId: input.leadId,
          kind: "note",
          actorId,
          body,
          occurredAt: now(),
        },
      });
    },
    async changeStatus(input) {
      const actorId = requireMemberActor(input.actor);
      const authorization = await dependencies.authorize({ siteId: input.siteId, actorId, action: "update", leadId: input.leadId });
      requireUpdate(authorization);
      const current = await dependencies.repository.get(input.siteId, input.leadId);
      if (!current || current.siteId !== input.siteId) throw new LeadServiceError("not_found");
      const transition = transitionLead(current, {
        to: input.to,
        expectedVersion: input.expectedVersion,
        occurredAt: now(),
        actorId,
        correction: input.correction,
        restore: input.restore,
      });
      if (transition.status === "conflict") {
        return {
          status: "conflict",
          reason: "version_conflict",
          resourceType: "lead",
          resourceId: input.leadId,
          expectedVersion: transition.expectedVersion,
          actualVersion: transition.actualVersion,
        };
      }
      if (transition.status === "denied") throw new LeadServiceError("invalid_state");
      return dependencies.repository.changeStatusAtomic({ command: input, nextLead: transition.lead, event: transition.event });
    },
    async setPriority(input) {
      const actorId = requireMemberActor(input.actor);
      requireUpdate(await dependencies.authorize({ siteId: input.siteId, actorId, action: "update", leadId: input.leadId }));
      return dependencies.repository.setPriorityAtomic({
        command: input,
        event: {
          siteId: input.siteId,
          leadId: input.leadId,
          kind: "correction",
          actorId,
          body: `priority:${input.priority}`,
          occurredAt: now(),
        },
      });
    },
    async createTask(input) {
      const actorId = requireMemberActor(input.actor);
      requireUpdate(await dependencies.authorize({ siteId: input.siteId, actorId, action: "task", leadId: input.leadId }));
      return dependencies.repository.createTaskAtomic({
        command: input,
        event: {
          siteId: input.siteId,
          leadId: input.leadId,
          kind: "task",
          actorId,
          occurredAt: now(),
        },
      });
    },
    async recordServiceEvent(input) {
      if (input.origin.type !== "manual") throw new LeadServiceError("not_authorized");
      const actorId = requireMemberActor(input.origin.actor);
      requireUpdate(await dependencies.authorize({ siteId: input.siteId, actorId, action: "service_event", leadId: input.leadId }));
      return dependencies.repository.recordServiceEventAtomic({
        command: input,
        event: {
          siteId: input.siteId,
          leadId: input.leadId,
          kind: "service_event",
          actorId,
          occurredAt: input.occurredAt,
        },
      });
    },
    async bulkStatus(input) {
      const actorId = requireMemberActor(input.actor);
      validateBulkRecords(input.records);
      const authorization = await dependencies.authorize({ siteId: input.siteId, actorId, action: "bulk" });
      if (!authorization.canUpdate) return denyBulkCommand(input.records, "not_authorized");
      return aggregateBulkResults(input.records, record => dependencies.repository.bulkStatusRecord({
        command: input,
        record,
        scope: authorization.scope,
      }));
    },
    async bulkAssign(input) {
      const actorId = requireMemberActor(input.actor);
      validateBulkRecords(input.records);
      if (!input.assigneeId.trim() || input.assigneeId.length > 128) {
        throw new LeadServiceError("invalid_request");
      }
      const authorization = await dependencies.authorize({ siteId: input.siteId, actorId, action: "bulk" });
      if (!authorization.canAssignOthers) return denyBulkCommand(input.records, "not_authorized");
      return aggregateBulkResults(input.records, record => dependencies.repository.bulkAssignRecord({
        command: input,
        record,
        scope: authorization.scope,
      }));
    },
    async bulkTag(input) {
      const actorId = requireMemberActor(input.actor);
      validateBulkRecords(input.records);
      if (!input.tagId.trim() || input.tagId.length > 128) throw new LeadServiceError("invalid_request");
      const authorization = await dependencies.authorize({ siteId: input.siteId, actorId, action: "bulk" });
      if (!authorization.canUpdate) return denyBulkCommand(input.records, "not_authorized");
      return aggregateBulkResults(input.records, record => dependencies.repository.bulkTagRecord({
        command: input,
        record,
        scope: authorization.scope,
      }));
    },
  };
}
