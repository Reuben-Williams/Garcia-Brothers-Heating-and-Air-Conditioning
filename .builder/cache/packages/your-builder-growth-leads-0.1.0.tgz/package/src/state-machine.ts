import type { Lead, LeadEvent, LeadStatus } from "./lead.js";

const transitions: Readonly<Record<Exclude<LeadStatus, "won" | "lost" | "spam">, readonly LeadStatus[]>> = {
  new: ["contacted", "qualified", "lost", "spam"],
  contacted: ["new", "qualified", "lost", "spam"],
  qualified: ["contacted", "won", "lost", "spam"],
};

export interface LeadTransitionInput {
  readonly to: LeadStatus;
  readonly expectedVersion: number;
  readonly occurredAt: string;
  readonly actorId?: string;
  readonly correction?: boolean;
  readonly restore?: boolean;
}

export type LeadTransitionResult =
  | { readonly status: "applied"; readonly lead: Lead; readonly event: LeadEvent }
  | { readonly status: "conflict"; readonly reason: "version_conflict"; readonly expectedVersion: number; readonly actualVersion: number }
  | { readonly status: "denied"; readonly reason: "invalid_transition"; readonly from: LeadStatus; readonly to: LeadStatus };

export function transitionLead(lead: Lead, input: LeadTransitionInput): LeadTransitionResult {
  if (input.expectedVersion !== lead.version) {
    return { status: "conflict", reason: "version_conflict", expectedVersion: input.expectedVersion, actualVersion: lead.version };
  }
  if (input.to === lead.status) return { status: "denied", reason: "invalid_transition", from: lead.status, to: input.to };

  const terminal = lead.status === "won" || lead.status === "lost";
  const spamRestore = lead.status === "spam" && input.restore === true && input.to !== "spam";
  const ordinary = !terminal && lead.status !== "spam" && transitions[lead.status].includes(input.to);
  const corrected = input.correction === true;
  if (!ordinary && !spamRestore && !corrected) {
    return { status: "denied", reason: "invalid_transition", from: lead.status, to: input.to };
  }

  const event: LeadEvent = {
    siteId: lead.siteId,
    leadId: lead.id,
    kind: corrected ? "correction" : "status_changed",
    actorId: input.actorId,
    from: lead.status,
    to: input.to,
    occurredAt: input.occurredAt,
  };
  return {
    status: "applied",
    lead: { ...lead, status: input.to, version: lead.version + 1, updatedAt: input.occurredAt },
    event,
  };
}

export interface LeadServiceLaneEvent {
  readonly kind: "appointment.scheduled" | "appointment.rescheduled" | "appointment.cancelled" | "appointment.completed";
  readonly purpose: "estimate" | "service";
  readonly live: boolean;
}

export function deriveLeadDisplayLane(lead: Lead, serviceEvents: readonly LeadServiceLaneEvent[]): LeadStatus | "estimate_scheduled" {
  if (lead.status === "qualified" && serviceEvents.some((event) => event.kind === "appointment.scheduled" && event.purpose === "estimate" && event.live)) {
    return "estimate_scheduled";
  }
  return lead.status;
}
