export const LEAD_STATUSES = Object.freeze(["new", "contacted", "qualified", "won", "lost", "spam"] as const);
export type LeadStatus = (typeof LEAD_STATUSES)[number];

export const MANUAL_LEAD_SOURCES = Object.freeze(["phone", "walk_in", "staff_entry"] as const);
export type ManualLeadSource = (typeof MANUAL_LEAD_SOURCES)[number];
export type LeadSource = "website_form" | ManualLeadSource;
export type LeadPriority = "low" | "normal" | "high" | "urgent";
export type LeadUrgency = "standard" | "urgent" | "emergency";

export interface Lead {
  readonly id: string;
  readonly siteId: string;
  readonly contactId: string;
  readonly submissionId?: string;
  readonly formId?: string;
  readonly source: LeadSource;
  readonly service: string;
  readonly urgency: LeadUrgency;
  readonly priority?: LeadPriority;
  readonly status: LeadStatus;
  readonly summary: string;
  readonly primaryAssigneeId?: string;
  readonly version: number;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export type LeadEventKind = "created" | "status_changed" | "assignment" | "note" | "task" | "service_event" | "correction" | "export" | "merge";

export interface LeadEvent {
  readonly id?: string;
  readonly siteId: string;
  readonly leadId: string;
  readonly kind: LeadEventKind;
  readonly actorId?: string;
  readonly from?: LeadStatus;
  readonly to?: LeadStatus;
  readonly body?: string;
  readonly relatedId?: string;
  readonly correctionOfEventId?: string;
  readonly occurredAt: string;
}

export interface LeadListItem {
  readonly id: string;
  readonly customerId: string;
  readonly customerDisplayName: string;
  readonly service: string;
  readonly urgency: LeadUrgency;
  readonly priority?: LeadPriority;
  readonly status: LeadStatus;
  readonly displayLane: LeadStatus | "estimate_scheduled";
  readonly assigneeId?: string;
  readonly createdAt: string;
  readonly updatedAt: string;
  readonly version: number;
}

export interface LeadDetail extends Lead {
  readonly timeline: readonly LeadEvent[];
  readonly duplicateWarning?: { readonly suggestionId: string; readonly confidence: "low" | "medium" | "high" };
  readonly originalSubmissionId?: string;
}
