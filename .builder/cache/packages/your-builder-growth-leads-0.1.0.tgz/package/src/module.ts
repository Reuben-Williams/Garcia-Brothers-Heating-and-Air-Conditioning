import { MODULE_IDS, type GrowthFeatureModule } from "@your-builder/feature-registry";

export const growthLeadsModule = Object.freeze({
  id: MODULE_IDS.leads,
  version: "1.0.0",
  label: "Leads",
  description: "Lead intake, assignment, pipeline, tasks, and service milestones.",
  icon: "contact-round",
  navigationGroup: "growth",
  routes: [{ id: "growth.leads.home", path: "/admin/editor/leads", label: "Leads" }],
  requiredEntitlement: MODULE_IDS.leads,
  requiredCapabilities: ["leads.read"],
  dependencies: [{ moduleId: MODULE_IDS.customers, optional: false }],
  setupSteps: [],
  demo: { fixtureId: "growth.leads.demo", allowMutations: true, allowsExternalEffects: false },
  healthChecks: [],
  mobileNavigationPriority: 20,
} as const satisfies GrowthFeatureModule);
