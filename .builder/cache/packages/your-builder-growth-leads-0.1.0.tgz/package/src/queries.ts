import type { JsonValue, OperationActor, ServiceEvent, TaskSummary } from "@your-builder/growth-core";
import type { CustomerIdentitySummary, CustomerTagSummary } from "@your-builder/growth-customers";
import type { LeadDetail, LeadListItem, LeadPriority, LeadSource, LeadStatus, LeadUrgency } from "./lead.js";

export interface LeadListFilter {
  readonly statuses?: readonly LeadStatus[];
  readonly services?: readonly string[];
  readonly assigneeIds?: readonly string[];
  readonly sources?: readonly LeadSource[];
  readonly priorities?: readonly LeadPriority[];
  readonly createdFrom?: string;
  readonly createdTo?: string;
  readonly estimateScheduled?: boolean;
  readonly unassigned?: boolean;
}

export interface ListLeadsQuery {
  readonly siteId: string;
  readonly actor: OperationActor;
  readonly search?: string;
  readonly filter?: LeadListFilter;
  readonly sort?: "created_at" | "updated_at" | "priority" | "status";
  readonly direction?: "asc" | "desc";
  readonly limit: number;
  readonly cursor?: string;
}

export interface LeadPage { readonly items: readonly LeadListItem[]; readonly nextCursor?: string; }
export interface GetLeadQuery { readonly siteId: string; readonly leadId: string; readonly actor: OperationActor; }

export interface LeadQueryService {
  list(input: ListLeadsQuery): Promise<LeadPage>;
  get(input: GetLeadQuery): Promise<LeadDetail | null>;
}

export interface LeadReadCustomerProjection {
  readonly id: string;
  readonly displayName: string;
  readonly lifecycleState: "active" | "inactive" | "merged" | "deleted";
  readonly preferredContactMethod?: "email" | "phone" | "none";
  readonly serviceZipCode?: string;
  readonly version: number;
}

export type LeadReadSource = LeadSource | "import" | "correction" | "integration";

export interface LeadReadIdentityProjection {
  readonly id: string;
  readonly kind: "email" | "phone" | "external";
  readonly value: string;
  readonly verificationState: string;
  readonly source: LeadReadSource;
  readonly createdAt: string;
}

export interface LeadReadTagProjection {
  readonly id: string;
  readonly key: string;
  readonly label: string;
  readonly colorToken?: string;
}

export interface LeadReadTaskProjection {
  readonly id: string;
  readonly title: string;
  readonly priority?: LeadPriority;
  readonly state: "open" | "in_progress" | "completed" | "cancelled";
  readonly assigneeId?: string;
  readonly dueAt?: string;
  readonly completedAt?: string;
  readonly version: number;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export interface LeadReadServiceEventProjection {
  readonly id: string;
  readonly eventKind: string;
  readonly purpose?: "estimate" | "service" | "follow_up";
  readonly scheduledAt?: string;
  readonly occurredAt: string;
  readonly source: LeadReadSource;
  readonly actorId?: string;
  readonly createdAt: string;
}

export interface LeadReadTimelineProjection {
  readonly id: string;
  readonly kind: string;
  readonly actorId?: string;
  readonly metadata: JsonValue;
  readonly createdAt: string;
}

export interface LeadReadSubmissionProjection {
  readonly id: string;
  readonly formId: string;
  readonly source: LeadReadSource;
  readonly zipCode?: string;
  readonly locale?: string;
  readonly receivedAt: string;
  readonly resultCode: "base_only" | "enhanced" | "review_required" | "identity_conflict" | "spam";
}

export interface LeadReadDuplicateWarningProjection {
  readonly id: string;
  readonly confidenceBand: "low" | "medium" | "high";
  readonly reviewState: "pending" | "accepted" | "merged" | "dismissed";
  readonly version: number;
}

export interface LeadReadListItem {
  readonly id: string;
  readonly contactId: string;
  readonly displayName: string;
  readonly source: LeadReadSource;
  readonly formId?: string;
  readonly service?: string;
  readonly urgency: LeadUrgency;
  readonly status: LeadStatus;
  readonly summary?: string;
  readonly primaryAssigneeId?: string;
  readonly priority: LeadPriority;
  readonly version: number;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export interface LeadReadRecordProjection {
  readonly id: string;
  readonly contactId: string;
  readonly source: LeadReadSource;
  readonly formId?: string;
  readonly service?: string;
  readonly urgency: LeadUrgency;
  readonly status: LeadStatus;
  readonly summary?: string;
  readonly primaryAssigneeId?: string;
  readonly priority: LeadPriority;
  readonly version: number;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export interface LeadReadPage {
  readonly items: readonly LeadReadListItem[];
  readonly nextCursor?: string;
}

export interface LeadReadDetail {
  readonly lead: LeadReadRecordProjection;
  readonly customer: LeadReadCustomerProjection;
  readonly identities: readonly LeadReadIdentityProjection[];
  readonly tags: readonly LeadReadTagProjection[];
  readonly tasks: readonly LeadReadTaskProjection[];
  readonly serviceEvents: readonly LeadReadServiceEventProjection[];
  readonly timeline: readonly LeadReadTimelineProjection[];
  readonly submission?: LeadReadSubmissionProjection;
  readonly duplicateWarning?: LeadReadDuplicateWarningProjection;
}

export interface LeadCustomerProjection {
  readonly id: string;
  readonly displayName: string;
  readonly identities: readonly CustomerIdentitySummary[];
}

export interface LeadSubmissionProjection {
  readonly id: string;
  readonly capturedAt: string;
  readonly safeCode?: string;
}

export interface LeadWorkspaceDetail {
  readonly lead: LeadDetail;
  readonly customer: LeadCustomerProjection;
  readonly tags: readonly CustomerTagSummary[];
  readonly tasks: readonly TaskSummary[];
  readonly serviceEvents: readonly ServiceEvent[];
  readonly submission?: LeadSubmissionProjection;
}
