import type {
  MemberOperationActor,
} from "@your-builder/growth-core";
import {
  createStoredIngestionResult,
  type ImportBaseSubmissionCommand,
  type ImportBaseSubmissionResult,
  type LeadIngestionService,
  type StoreIngestionResultInput,
  type StoredIngestionResult,
} from "./ingestion.js";
import { LeadServiceError } from "./services.js";
import {
  LEAD_INPUT_LIMITS,
  normalizeBoundedText,
  normalizeOptionalEmail,
  normalizeOptionalPhone,
  US_ZIP_PATTERN,
} from "./validation.js";

export interface PublicInquiryCommand {
  readonly siteId: string;
  readonly submissionId: string;
  readonly resultId: string;
  readonly idempotencyKey: string;
  readonly firstName: string;
  readonly lastName: string;
  readonly email?: string;
  readonly phone?: string;
  readonly zipCode: string;
  readonly service: string;
  readonly message: string;
}

export interface NormalizedPublicInquiryCommand extends Omit<
  PublicInquiryCommand,
  "firstName" | "lastName" | "email" | "phone" | "zipCode" | "service" | "message"
> {
  readonly firstName: string;
  readonly lastName: string;
  readonly email?: string;
  readonly phone?: string;
  readonly zipCode: string;
  readonly service: string;
  readonly message: string;
}

export interface PublicInquiryRepository {
  /** Performs authoritative identity matching and all writes in one database transaction. */
  ingestAtomic(input: NormalizedPublicInquiryCommand): Promise<StoreIngestionResultInput>;
}

export interface PublicInquiryResult {
  readonly status: "accepted";
  readonly submissionId: string;
  readonly resultId: string;
  readonly replayed: boolean;
}

export interface PublicInquiryOrchestrator {
  ingest(input: PublicInquiryCommand): Promise<PublicInquiryResult>;
}

export function createPublicInquiryOrchestrator(dependencies: {
  readonly repository: PublicInquiryRepository;
}): PublicInquiryOrchestrator {
  return {
    async ingest(command) {
      const firstName = normalizeBoundedText(command.firstName, 1, LEAD_INPUT_LIMITS.name);
      const lastName = normalizeBoundedText(command.lastName, 1, LEAD_INPUT_LIMITS.name);
      const email = normalizeOptionalEmail(command.email);
      const phone = normalizeOptionalPhone(command.phone);
      const zipCode = normalizeBoundedText(command.zipCode, 5, 10);
      const service = normalizeBoundedText(command.service, 1, LEAD_INPUT_LIMITS.service);
      const message = normalizeBoundedText(command.message, 1, LEAD_INPUT_LIMITS.message);
      if (
        !firstName ||
        !lastName ||
        email === null ||
        phone === null ||
        (!email && !phone) ||
        !zipCode ||
        !US_ZIP_PATTERN.test(zipCode) ||
        !service ||
        !message
      ) {
        throw new LeadServiceError("invalid_request");
      }
      const storedInput = await dependencies.repository.ingestAtomic({
        ...command,
        firstName,
        lastName,
        email,
        phone,
        zipCode,
        service,
        message,
      });
      const stored = createStoredIngestionResult(storedInput);
      return {
        status: "accepted",
        submissionId: stored.submissionId,
        resultId: stored.resultId,
        replayed: stored.replayed,
      };
    },
  };
}

export interface BaseSubmissionReviewState {
  readonly submissionId: string;
  readonly siteId: string;
  readonly classification: "active" | "spam";
  readonly version: number;
}

export interface BaseSubmissionReviewCommand {
  readonly siteId: string;
  readonly actor: MemberOperationActor;
  readonly submissionId: string;
  readonly expectedVersion: number;
  readonly idempotencyKey: string;
  readonly reasonCode?: string;
}

export interface AppendBaseSubmissionReviewEventCommand extends BaseSubmissionReviewCommand {
  readonly kind: "classified_spam" | "restored";
}

export interface BaseSubmissionReviewRepository {
  get(siteId: string, submissionId: string): Promise<BaseSubmissionReviewState | null>;
  appendEvent(input: AppendBaseSubmissionReviewEventCommand): Promise<BaseSubmissionReviewState>;
}

export interface BaseSubmissionReviewService {
  classifySpam(input: BaseSubmissionReviewCommand): Promise<BaseSubmissionReviewState>;
  restore(input: BaseSubmissionReviewCommand): Promise<BaseSubmissionReviewState>;
}

export function createBaseSubmissionReviewService(dependencies: {
  readonly repository: BaseSubmissionReviewRepository;
  readonly authorize: (input: BaseSubmissionReviewCommand) => Promise<{ readonly canReviewBaseSubmissions: boolean }>;
}): BaseSubmissionReviewService {
  async function loadAuthorized(input: BaseSubmissionReviewCommand): Promise<BaseSubmissionReviewState> {
    if (input.actor.type !== "member" || !input.actor.id.trim()) {
      throw new LeadServiceError("not_authorized");
    }
    const authorization = await dependencies.authorize(input);
    if (!authorization.canReviewBaseSubmissions) throw new LeadServiceError("not_authorized");
    const state = await dependencies.repository.get(input.siteId, input.submissionId);
    if (!state || state.siteId !== input.siteId) throw new LeadServiceError("not_found");
    if (state.version !== input.expectedVersion) throw new LeadServiceError("invalid_state");
    return state;
  }
  return {
    async classifySpam(input) {
      if (!input.reasonCode || !/^[a-z][a-z0-9_]{1,63}$/.test(input.reasonCode)) {
        throw new LeadServiceError("invalid_request");
      }
      const state = await loadAuthorized(input);
      if (state.classification === "spam") throw new LeadServiceError("invalid_state");
      return dependencies.repository.appendEvent({ ...input, kind: "classified_spam" });
    },
    async restore(input) {
      const state = await loadAuthorized(input);
      if (state.classification !== "spam") throw new LeadServiceError("invalid_state");
      return dependencies.repository.appendEvent({ ...input, kind: "restored" });
    },
  };
}

export interface LeadIngestionRepository {
  storeAcceptedInquiry(input: StoreIngestionResultInput): Promise<StoredIngestionResult>;
  importReviewedBaseSubmission(input: ImportBaseSubmissionCommand): Promise<ImportBaseSubmissionResult>;
}

export interface ImportAuthorization {
  readonly isOwner: boolean;
  readonly recentAal2: boolean;
  readonly enhancedWritesAllowed: boolean;
}

export function createLeadIngestionService(dependencies: {
  readonly repository: LeadIngestionRepository;
  readonly authorizeImport: (input: ImportBaseSubmissionCommand) => Promise<ImportAuthorization>;
}): LeadIngestionService {
  return {
    storeAcceptedInquiry(input) {
      return dependencies.repository.storeAcceptedInquiry(input);
    },
    async importReviewedBaseSubmission(input) {
      if (input.actor.type !== "member" || !input.actor.id.trim()) {
        return { status: "denied", submissionId: input.submissionId, safeCode: "not_authorized" };
      }
      const authorization = await dependencies.authorizeImport(input);
      if (!authorization.isOwner || !authorization.recentAal2) {
        return { status: "denied", submissionId: input.submissionId, safeCode: "not_authorized" };
      }
      if (!authorization.enhancedWritesAllowed) {
        return { status: "denied", submissionId: input.submissionId, safeCode: "enhancement_unavailable" };
      }
      return dependencies.repository.importReviewedBaseSubmission(input);
    },
  };
}
