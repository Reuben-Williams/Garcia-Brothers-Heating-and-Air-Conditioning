import {
  normalizeEmailIdentity,
  normalizePhoneIdentity,
} from "@your-builder/growth-core";

export const LEAD_INPUT_LIMITS = Object.freeze({
  name: 100,
  service: 160,
  notes: 2_000,
  message: 2_000,
});

export const US_ZIP_PATTERN = /^[0-9]{5}(?:-[0-9]{4})?$/;

export function normalizeBoundedText(
  value: string,
  minimum: number,
  maximum: number,
): string | null {
  const normalized = value.trim();
  if (
    normalized.length < minimum ||
    normalized.length > maximum ||
    normalized.includes("\0")
  ) {
    return null;
  }
  return normalized;
}

export function normalizeOptionalEmail(value: string | undefined): string | undefined | null {
  if (value === undefined) return undefined;
  const result = normalizeEmailIdentity(value);
  return result.ok ? result.value : null;
}

export function normalizeOptionalPhone(value: string | undefined): string | undefined | null {
  if (value === undefined) return undefined;
  const result = normalizePhoneIdentity(value, "US");
  return result.ok ? result.value : null;
}
