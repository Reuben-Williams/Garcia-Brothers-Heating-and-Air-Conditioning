import {
  AlertTriangle,
  CalendarClock,
  CheckSquare,
  Clock3,
  Mail,
  MessageSquarePlus,
  Phone,
  Tag,
  UserRound,
  X,
} from "lucide-react";
import type { FormEvent } from "react";

import type { LeadEvent, LeadPriority, LeadStatus, LeadWorkspaceDetail } from "../index.js";
import type { LeadAssigneeOption, LeadWorkspaceAccess } from "./types.js";
import styles from "./leads-workspace.module.css";

export interface LeadDetailSurfaceProps {
  readonly detail: LeadWorkspaceDetail;
  readonly access: LeadWorkspaceAccess;
  readonly assignees: readonly LeadAssigneeOption[];
  readonly busy: boolean;
  readonly onClose: () => void;
  readonly onStatus: (status: LeadStatus) => void;
  readonly onPriority: (priority: LeadPriority) => void;
  readonly onAssign: (assigneeId: string) => void;
  readonly onNote: (body: string) => void;
}

const statusLabels: Readonly<Record<LeadStatus, string>> = {
  new: "New",
  contacted: "Contacted",
  qualified: "Qualified",
  won: "Won",
  lost: "Lost",
  spam: "Spam Review",
};

function readable(value: string): string {
  const normalized = value.replace(/[._]/g, " ");
  return normalized[0]!.toUpperCase() + normalized.slice(1);
}

function eventLabel(event: LeadEvent): string {
  if (event.kind === "created") return "Lead created";
  if (event.kind === "status_changed") return `Status changed to ${event.to ? statusLabels[event.to] : "updated"}`;
  if (event.kind === "assignment") return "Assignment updated";
  if (event.kind === "service_event") return "Service milestone recorded";
  return readable(event.kind);
}

function formatDate(value?: string): string {
  if (!value) return "Not scheduled";
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(value));
}

function phoneHref(value: string): string {
  return `tel:${value.replace(/(?!^\+)\D/g, "")}`;
}

export function LeadDetailSurface({
  detail,
  access,
  assignees,
  busy,
  onClose,
  onStatus,
  onPriority,
  onAssign,
  onNote,
}: LeadDetailSurfaceProps) {
  const email = detail.customer.identities.find((identity) => identity.kind === "email");
  const phone = detail.customer.identities.find((identity) => identity.kind === "phone");
  const editable = access.canUpdate && !busy;

  function submitNote(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const body = String(new FormData(form).get("note") ?? "").trim();
    if (!body) return;
    onNote(body);
    form.reset();
  }

  return (
    <section className={styles.detailContent} data-builder-lead-detail data-builder-lead-id={detail.lead.id}>
      <header className={styles.detailHeader}>
        <div>
          <span className={styles.eyebrow}>Lead detail</span>
          <h2>{detail.customer.displayName}</h2>
          <p>{detail.lead.service}</p>
        </div>
        <button type="button" className={styles.iconButton} aria-label="Close lead detail" onClick={onClose}>
          <X size={20} aria-hidden="true" />
        </button>
      </header>

      {detail.lead.duplicateWarning ? (
        <div className={styles.warning} role="status">
          <AlertTriangle size={18} aria-hidden="true" />
          <div><strong>Possible duplicate</strong><span>{readable(detail.lead.duplicateWarning.confidence)} confidence match requires review.</span></div>
        </div>
      ) : null}

      <section className={styles.detailSection} aria-labelledby={`${detail.lead.id}-customer`}>
        <h3 id={`${detail.lead.id}-customer`}><UserRound size={17} aria-hidden="true" />Customer summary</h3>
        <p>{detail.lead.summary}</p>
        <div className={styles.contactActions}>
          {phone ? <a href={phoneHref(phone.display)}><Phone size={17} aria-hidden="true" />Call {phone.display}</a> : null}
          {email ? <a href={`mailto:${email.display}`}><Mail size={17} aria-hidden="true" />Email {email.display}</a> : null}
        </div>
        {detail.tags.length > 0 ? (
          <div className={styles.tagList} aria-label="Lead tags">
            {detail.tags.map((tag) => <span key={tag.id}><Tag size={13} aria-hidden="true" />{tag.label}</span>)}
          </div>
        ) : null}
      </section>

      <section className={styles.detailSection} aria-labelledby={`${detail.lead.id}-pipeline`}>
        <h3 id={`${detail.lead.id}-pipeline`}><Clock3 size={17} aria-hidden="true" />Pipeline</h3>
        <div className={styles.detailFields}>
          <label>
            <span>Status</span>
            <select
              aria-label="Lead status"
              value={detail.lead.status}
              disabled={!editable}
              onChange={(event) => onStatus(event.target.value as LeadStatus)}
            >
              {Object.entries(statusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
            </select>
          </label>
          <label>
            <span>Priority</span>
            <select
              aria-label="Lead priority"
              value={detail.lead.priority ?? "normal"}
              disabled={!editable}
              onChange={(event) => onPriority(event.target.value as LeadPriority)}
            >
              <option value="low">Low</option>
              <option value="normal">Normal</option>
              <option value="high">High</option>
              <option value="urgent">Urgent</option>
            </select>
          </label>
          <label className={styles.formWide}>
            <span>Assignee</span>
            <select
              aria-label="Lead assignee"
              value={detail.lead.primaryAssigneeId ?? ""}
              disabled={!editable || !access.canAssignOthers}
              onChange={(event) => onAssign(event.target.value)}
            >
              <option value="">Unassigned</option>
              {assignees.map((assignee) => <option key={assignee.id} value={assignee.id}>{assignee.label}</option>)}
            </select>
          </label>
        </div>
      </section>

      <section className={styles.detailSection} aria-labelledby={`${detail.lead.id}-tasks`}>
        <h3 id={`${detail.lead.id}-tasks`}><CheckSquare size={17} aria-hidden="true" />Tasks</h3>
        {detail.tasks.length > 0 ? (
          <ul className={styles.compactList}>
            {detail.tasks.map((task) => (
              <li key={task.id}><strong>{task.title}</strong><span>{readable(task.status)} - {formatDate(task.dueAt)}</span></li>
            ))}
          </ul>
        ) : <p className={styles.muted}>No tasks for this lead.</p>}
      </section>

      <section className={styles.detailSection} aria-labelledby={`${detail.lead.id}-milestones`}>
        <h3 id={`${detail.lead.id}-milestones`}><CalendarClock size={17} aria-hidden="true" />Service milestones</h3>
        {detail.serviceEvents.length > 0 ? (
          <ul className={styles.compactList}>
            {detail.serviceEvents.map((event) => (
              <li key={event.id}><strong>{readable(event.kind)}</strong><span>{event.purpose ? readable(event.purpose) : "Service"} - {formatDate(event.scheduledAt ?? event.occurredAt)}</span></li>
            ))}
          </ul>
        ) : <p className={styles.muted}>No service milestones recorded.</p>}
      </section>

      {access.canUpdate ? (
        <section className={styles.detailSection} aria-labelledby={`${detail.lead.id}-notes`}>
          <h3 id={`${detail.lead.id}-notes`}><MessageSquarePlus size={17} aria-hidden="true" />Add note</h3>
          <form className={styles.noteForm} onSubmit={submitNote}>
            <textarea name="note" aria-label="Lead note" rows={3} maxLength={2_000} disabled={busy} />
            <button type="submit" className={styles.secondaryButton} disabled={busy}>Add note</button>
          </form>
        </section>
      ) : null}

      <section className={styles.detailSection} aria-labelledby={`${detail.lead.id}-timeline`}>
        <h3 id={`${detail.lead.id}-timeline`}><Clock3 size={17} aria-hidden="true" />Timeline</h3>
        <ol className={styles.timeline}>
          {detail.lead.timeline.map((event, index) => (
            <li key={event.id ?? `${event.kind}-${index}`}>
              <strong>{eventLabel(event)}</strong>
              {event.body ? <span>{event.body}</span> : null}
              <time dateTime={event.occurredAt}>{formatDate(event.occurredAt)}</time>
            </li>
          ))}
        </ol>
      </section>

      {detail.submission ? (
        <section className={styles.detailSection} aria-labelledby={`${detail.lead.id}-submission`}>
          <h3 id={`${detail.lead.id}-submission`}>Original submission</h3>
          <p>Captured {formatDate(detail.submission.capturedAt)}</p>
          {detail.submission.safeCode ? <span className={styles.statusBadge}>{readable(detail.submission.safeCode)}</span> : null}
        </section>
      ) : null}
    </section>
  );
}
