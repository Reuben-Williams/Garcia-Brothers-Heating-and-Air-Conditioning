import type {
  LeadBulkRecordResult,
  LeadDetail,
  LeadListItem,
  LeadPage,
  LeadStatus,
  LeadWorkspaceDetail,
} from "../index.js";
import type {
  LeadWorkspaceApi,
  LeadWorkspaceListRequest,
  LeadWorkspaceMutationResult,
  ManualLeadInput,
} from "./types.js";

const DEMO_SITE_ID = "20000000-0000-4000-8000-00000000d001";
const DEMO_ASSIGNEE_ID = "20000000-0000-4000-8000-00000000d101";

const demoItems = [
  {
    id: "demo-lead-ada",
    customerId: "demo-customer-ada",
    customerDisplayName: "Ada Brooks",
    service: "Heating repair",
    urgency: "urgent",
    priority: "urgent",
    status: "new",
    displayLane: "new",
    createdAt: "2026-07-18T12:00:00.000Z",
    updatedAt: "2026-07-18T13:00:00.000Z",
    version: 1,
  },
  {
    id: "demo-lead-mateo",
    customerId: "demo-customer-mateo",
    customerDisplayName: "Mateo Reed",
    service: "AC repair",
    urgency: "standard",
    priority: "high",
    status: "contacted",
    displayLane: "contacted",
    assigneeId: DEMO_ASSIGNEE_ID,
    createdAt: "2026-07-17T15:00:00.000Z",
    updatedAt: "2026-07-18T11:30:00.000Z",
    version: 2,
  },
  {
    id: "demo-lead-priya",
    customerId: "demo-customer-priya",
    customerDisplayName: "Priya Shah",
    service: "System estimate",
    urgency: "standard",
    priority: "normal",
    status: "qualified",
    displayLane: "estimate_scheduled",
    assigneeId: DEMO_ASSIGNEE_ID,
    createdAt: "2026-07-16T10:00:00.000Z",
    updatedAt: "2026-07-18T10:00:00.000Z",
    version: 3,
  },
  {
    id: "demo-lead-jordan",
    customerId: "demo-customer-jordan",
    customerDisplayName: "Jordan Lee",
    service: "Maintenance plan",
    urgency: "standard",
    priority: "normal",
    status: "won",
    displayLane: "won",
    assigneeId: DEMO_ASSIGNEE_ID,
    createdAt: "2026-07-12T09:00:00.000Z",
    updatedAt: "2026-07-17T16:00:00.000Z",
    version: 5,
  },
  {
    id: "demo-lead-taylor",
    customerId: "demo-customer-taylor",
    customerDisplayName: "Taylor Morgan",
    service: "Duct inspection",
    urgency: "standard",
    priority: "low",
    status: "lost",
    displayLane: "lost",
    createdAt: "2026-07-11T14:00:00.000Z",
    updatedAt: "2026-07-16T12:00:00.000Z",
    version: 4,
  },
  {
    id: "demo-lead-casey",
    customerId: "demo-customer-casey",
    customerDisplayName: "Casey Nguyen",
    service: "General inquiry",
    urgency: "standard",
    status: "spam",
    displayLane: "spam",
    createdAt: "2026-07-15T08:00:00.000Z",
    updatedAt: "2026-07-15T08:10:00.000Z",
    version: 2,
  },
] as const satisfies readonly LeadListItem[];

export const LEADS_DEMO_PAGE: LeadPage = Object.freeze({
  items: Object.freeze(demoItems.map((item) => Object.freeze({ ...item }))),
});

function detailFor(item: LeadListItem, index: number): LeadWorkspaceDetail {
  const emailName = item.customerDisplayName.toLowerCase().replace(/[^a-z]+/g, ".").replace(/^\.|\.$/g, "");
  const lead: LeadDetail = {
    id: item.id,
    siteId: DEMO_SITE_ID,
    contactId: item.customerId,
    source: index % 2 === 0 ? "website_form" : "phone",
    service: item.service,
    urgency: item.urgency,
    ...(item.priority ? { priority: item.priority } : {}),
    status: item.status,
    summary: `Fictional ${item.service.toLowerCase()} request for the interactive preview.`,
    ...(item.assigneeId ? { primaryAssigneeId: item.assigneeId } : {}),
    version: item.version,
    createdAt: item.createdAt,
    updatedAt: item.updatedAt,
    timeline: [
      {
        id: `${item.id}-event-created`,
        siteId: DEMO_SITE_ID,
        leadId: item.id,
        kind: "created",
        occurredAt: item.createdAt,
      },
    ],
    ...(index === 0 ? {
      duplicateWarning: { suggestionId: "demo-duplicate-ada", confidence: "medium" },
      originalSubmissionId: "demo-submission-ada",
      submissionId: "demo-submission-ada",
    } : {}),
  };

  return {
    lead,
    customer: {
      id: item.customerId,
      displayName: item.customerDisplayName,
      identities: [
        { kind: "email", display: `${emailName}@example.test`, verified: true },
        { kind: "phone", display: `+1 973 555 01${String(index + 20).padStart(2, "0")}`, verified: true },
      ],
    },
    tags: index === 0 ? [{ id: "demo-tag-priority", label: "Priority follow-up", color: "#b42318" }] : [],
    tasks: index < 3 ? [{
      id: `${item.id}-task`,
      siteId: DEMO_SITE_ID,
      relatedType: "lead",
      relatedId: item.id,
      title: index === 0 ? "Confirm access window" : "Complete follow-up",
      status: "open",
      priority: item.priority ?? "normal",
      dueAt: "2026-07-20T14:00:00.000Z",
      assigneeId: item.assigneeId ?? DEMO_ASSIGNEE_ID,
      version: 1,
    }] : [],
    serviceEvents: item.displayLane === "estimate_scheduled" ? [{
      id: `${item.id}-appointment`,
      siteId: DEMO_SITE_ID,
      contactId: item.customerId,
      leadId: item.id,
      kind: "appointment.scheduled",
      purpose: "estimate",
      scheduledAt: "2026-07-21T15:00:00.000Z",
      origin: { type: "integration", integrationId: "demo", providerEventId: `${item.id}-provider` },
      occurredAt: "2026-07-18T10:00:00.000Z",
      correlationId: `${item.id}-correlation`,
    }] : [],
    ...(index === 0 ? {
      submission: {
        id: "demo-submission-ada",
        capturedAt: item.createdAt,
        safeCode: "enhanced",
      },
    } : {}),
  };
}

export const LEADS_DEMO_DETAILS: Readonly<Record<string, LeadWorkspaceDetail>> = Object.freeze(
  Object.fromEntries(LEADS_DEMO_PAGE.items.map((item, index) => [item.id, Object.freeze(detailFor(item, index))])),
);

export interface LeadsDemoApi extends LeadWorkspaceApi {
  readonly externalEffects: false;
  reset(): void;
}

function clone<T>(value: T): T {
  return structuredClone(value);
}

function mutation(leadId: string, version: number): LeadWorkspaceMutationResult {
  return { result: "applied", leadId, version };
}

export function createLeadsDemoApi(): LeadsDemoApi {
  let items = clone(LEADS_DEMO_PAGE.items) as LeadListItem[];
  let details = clone(LEADS_DEMO_DETAILS) as Record<string, LeadWorkspaceDetail>;

  function updateLead(leadId: string, patch: Partial<LeadListItem>) {
    const current = items.find((item) => item.id === leadId);
    if (!current) return null;
    const next = { ...current, ...patch, id: leadId, version: current.version + 1 };
    items = items.map((item) => item.id === leadId ? next : item);
    const detail = details[leadId];
    if (detail) {
      details[leadId] = {
        ...detail,
        lead: {
          ...detail.lead,
          ...(patch.status ? { status: patch.status } : {}),
          ...(patch.priority ? { priority: patch.priority } : {}),
          ...(patch.assigneeId ? { primaryAssigneeId: patch.assigneeId } : {}),
          version: next.version,
        },
      };
    }
    return next;
  }

  function updateMutation(
    leadId: string,
    expectedVersion: number,
    patch: Partial<LeadListItem>,
  ): LeadWorkspaceMutationResult {
    const current = items.find((item) => item.id === leadId);
    if (!current) return { result: "denied", reason: "invalid_request" };
    if (current.version !== expectedVersion) {
      return { result: "conflict", expectedVersion, actualVersion: current.version };
    }
    const next = updateLead(leadId, patch)!;
    return mutation(leadId, next.version);
  }

  function updateBulkRecord(
    record: { readonly leadId: string; readonly expectedVersion: number },
    patch: Partial<LeadListItem>,
  ): LeadBulkRecordResult {
    const current = items.find((item) => item.id === record.leadId);
    if (!current) return { leadId: record.leadId, status: "denied", reason: "invalid_request" };
    if (current.version !== record.expectedVersion) {
      return {
        leadId: record.leadId,
        status: "conflict",
        expectedVersion: record.expectedVersion,
        actualVersion: current.version,
      };
    }
    const next = updateLead(record.leadId, patch)!;
    return { leadId: record.leadId, status: "applied", version: next.version };
  }

  function list(request: LeadWorkspaceListRequest): LeadPage {
    const search = request.search?.trim().toLowerCase();
    let result = items.filter((item) => {
      if (search && !`${item.customerDisplayName} ${item.service}`.toLowerCase().includes(search)) return false;
      const filter = request.filter;
      if (filter?.statuses?.length && !filter.statuses.includes(item.status)) return false;
      if (filter?.services?.length && !filter.services.includes(item.service)) return false;
      if (filter?.assigneeIds?.length && (!item.assigneeId || !filter.assigneeIds.includes(item.assigneeId))) return false;
      if (filter?.priorities?.length && (!item.priority || !filter.priorities.includes(item.priority))) return false;
      if (filter?.estimateScheduled && item.displayLane !== "estimate_scheduled") return false;
      if (filter?.unassigned && item.assigneeId) return false;
      return true;
    });
    if (request.direction === "asc") result = [...result].reverse();
    return { items: clone(result.slice(0, request.limit)) };
  }

  return {
    externalEffects: false,
    list: async (request) => list(request),
    get: async (leadId) => clone(details[leadId] ?? null),
    createManual: async (input: ManualLeadInput) => {
      const leadId = `demo-lead-created-${items.length + 1}`;
      const now = "2026-07-18T14:00:00.000Z";
      const item: LeadListItem = {
        id: leadId,
        customerId: `demo-customer-created-${items.length + 1}`,
        customerDisplayName: `${input.firstName} ${input.lastName}`,
        service: input.service,
        urgency: input.urgency,
        status: "new",
        displayLane: "new",
        ...(input.assigneeId ? { assigneeId: input.assigneeId } : {}),
        createdAt: now,
        updatedAt: now,
        version: 1,
      };
      items = [item, ...items];
      details[leadId] = detailFor(item, items.length);
      return mutation(leadId, 1);
    },
    changeStatus: async ({ leadId, expectedVersion, status }) =>
      updateMutation(leadId, expectedVersion, { status, displayLane: status }),
    setPriority: async ({ leadId, expectedVersion, priority }) =>
      updateMutation(leadId, expectedVersion, { priority }),
    assign: async ({ leadId, expectedVersion, assigneeId }) =>
      updateMutation(leadId, expectedVersion, { assigneeId }),
    addNote: async ({ leadId, expectedVersion, body }) => {
      const detail = details[leadId];
      if (!detail) return { result: "denied", reason: "invalid_request" };
      const result = updateMutation(leadId, expectedVersion, {});
      if (result.result !== "applied") return result;
      details[leadId] = {
        ...details[leadId]!,
        lead: {
          ...details[leadId]!.lead,
          timeline: [...details[leadId]!.lead.timeline, {
            id: `${leadId}-note-${details[leadId]!.lead.timeline.length}`,
            siteId: DEMO_SITE_ID,
            leadId,
            kind: "note",
            body,
            occurredAt: "2026-07-18T14:00:00.000Z",
          }],
        },
      };
      return result;
    },
    bulkStatus: async ({ records, status }) => ({
      requestedCount: records.length,
      results: records.map((record) => updateBulkRecord(record, { status, displayLane: status })),
    }),
    bulkAssign: async ({ records, assigneeId }) => ({
      requestedCount: records.length,
      results: records.map((record) => updateBulkRecord(record, { assigneeId })),
    }),
    bulkTag: async ({ records, tagId, operation }) => ({
      requestedCount: records.length,
      results: records.map((record): LeadBulkRecordResult => {
        const detail = details[record.leadId];
        if (!detail) return { leadId: record.leadId, status: "denied", reason: "invalid_request" };
        const result = updateBulkRecord(record, {});
        if (result.status !== "applied") return result;
        const hasTag = detail.tags.some((tag) => tag.id === tagId);
        details[record.leadId] = {
          ...detail,
          tags: operation === "add" && !hasTag
            ? [...detail.tags, { id: tagId, label: "Demo tag" }]
            : operation === "remove"
              ? detail.tags.filter((tag) => tag.id !== tagId)
              : detail.tags,
        };
        return result;
      }),
    }),
    requestExport: async () => ({ status: "applied", resourceId: "demo-leads-export" }),
    saveView: async ({ viewId, expectedVersion }) => ({
      status: "applied",
      resourceId: viewId ?? "demo-leads-view",
      version: (expectedVersion ?? 0) + 1,
    }),
    removeView: async ({ expectedVersion }) => ({ status: "applied", version: expectedVersion + 1 }),
    reset: () => {
      items = clone(LEADS_DEMO_PAGE.items) as LeadListItem[];
      details = clone(LEADS_DEMO_DETAILS) as Record<string, LeadWorkspaceDetail>;
    },
  };
}
