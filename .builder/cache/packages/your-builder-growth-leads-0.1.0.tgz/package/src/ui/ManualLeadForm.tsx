import { Save } from "lucide-react";
import type { FormEvent } from "react";

import type {
  LeadAssigneeOption,
  LeadWorkspaceAccess,
  ManualLeadInput,
} from "./types.js";
import styles from "./leads-workspace.module.css";

export interface ManualLeadFormProps {
  readonly access: LeadWorkspaceAccess;
  readonly assignees: readonly LeadAssigneeOption[];
  readonly services: readonly string[];
  readonly busy: boolean;
  readonly onSubmit: (input: ManualLeadInput) => void;
}

function optional(form: FormData, name: string): string | undefined {
  const value = String(form.get(name) ?? "").trim();
  return value || undefined;
}

export function ManualLeadForm({ access, assignees, services, busy, onSubmit }: ManualLeadFormProps) {
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    onSubmit({
      firstName: String(form.get("firstName") ?? "").trim(),
      lastName: String(form.get("lastName") ?? "").trim(),
      ...(optional(form, "email") ? { email: optional(form, "email") } : {}),
      ...(optional(form, "phone") ? { phone: optional(form, "phone") } : {}),
      zipCode: String(form.get("zipCode") ?? "").trim(),
      service: String(form.get("service") ?? ""),
      urgency: String(form.get("urgency") ?? "standard") as ManualLeadInput["urgency"],
      source: String(form.get("source") ?? "staff_entry") as ManualLeadInput["source"],
      ...(optional(form, "notes") ? { notes: optional(form, "notes") } : {}),
      ...(access.canAssignOthers && optional(form, "assigneeId") ? { assigneeId: optional(form, "assigneeId") } : {}),
    });
  }

  return (
    <form className={styles.manualForm} data-builder-lead-manual-entry onSubmit={submit}>
      <div className={styles.formGrid}>
        <label>
          <span>First name</span>
          <input name="firstName" autoComplete="given-name" maxLength={100} required />
        </label>
        <label>
          <span>Last name</span>
          <input name="lastName" autoComplete="family-name" maxLength={100} required />
        </label>
        <label>
          <span>Phone</span>
          <input name="phone" type="tel" autoComplete="tel" maxLength={32} />
        </label>
        <label>
          <span>Email</span>
          <input name="email" type="email" autoComplete="email" maxLength={254} />
        </label>
        <label>
          <span>ZIP code</span>
          <input name="zipCode" inputMode="numeric" autoComplete="postal-code" pattern="[0-9]{5}(-[0-9]{4})?" maxLength={10} required />
        </label>
        <label>
          <span>Service</span>
          <select name="service" defaultValue="" required>
            <option value="" disabled>Select service</option>
            {services.map((service) => <option key={service} value={service}>{service}</option>)}
          </select>
        </label>
        <label>
          <span>Urgency</span>
          <select name="urgency" defaultValue="standard">
            <option value="standard">Standard</option>
            <option value="urgent">Urgent</option>
            <option value="emergency">Emergency</option>
          </select>
        </label>
        <label>
          <span>Source</span>
          <select name="source" defaultValue="staff_entry">
            <option value="phone">Phone</option>
            <option value="walk_in">Walk-in</option>
            <option value="staff_entry">Staff entry</option>
          </select>
        </label>
        {access.canAssignOthers ? (
          <label className={styles.formWide}>
            <span>Assignee</span>
            <select name="assigneeId" defaultValue="">
              <option value="">Assign to me</option>
              {assignees.map((assignee) => <option key={assignee.id} value={assignee.id}>{assignee.label}</option>)}
            </select>
          </label>
        ) : null}
        <label className={styles.formWide}>
          <span>Notes</span>
          <textarea name="notes" rows={4} maxLength={2_000} />
        </label>
      </div>
      <p className={styles.formHint}>Provide a phone number or email address.</p>
      <button type="submit" className={styles.primaryButton} disabled={busy}>
        <Save size={17} aria-hidden="true" />
        {busy ? "Creating lead" : "Create lead"}
      </button>
    </form>
  );
}
