"use client";

import {
  AlertTriangle,
  ArrowDownAZ,
  Bookmark,
  ChevronRight,
  Download,
  Filter,
  ListFilter,
  LoaderCircle,
  Plus,
  Search,
  UsersRound,
  X,
} from "lucide-react";
import React, { useEffect, useRef, useState, type FormEvent } from "react";
import { DemoBanner, MobileBottomSheet, WorkspaceHeader } from "@your-builder/editor";

import type {
  BulkLeadCommandResult,
  LeadListFilter,
  LeadListItem,
  LeadPage,
  LeadPriority,
  LeadSource,
  LeadStatus,
  LeadWorkspaceDetail,
} from "../index.js";
import { createLeadsDemoApi, LEADS_DEMO_PAGE, type LeadsDemoApi } from "./demo.js";
import { LeadDetailSurface } from "./LeadDetailSurface.js";
import { ManualLeadForm } from "./ManualLeadForm.js";
import { validateLeadSavedFilterAst } from "./types.js";
import type {
  BuiltInLeadView,
  LeadFilterDraft,
  LeadSavedViewOption,
  LeadSavedFilterAst,
  LeadsWorkspaceProps,
  LeadViewId,
  LeadWorkspaceMutationResult,
  LeadWorkspaceCommandResult,
  LeadWorkspaceUrlState,
  ManualLeadInput,
} from "./types.js";
import styles from "./leads-workspace.module.css";

const PAGE_SIZE = 50;
const MAX_SEARCH_LENGTH = 120;
const MAX_SELECTION = 100;
const MOBILE_QUERY = "(max-width: 767px)";

const builtInViews: readonly { readonly id: BuiltInLeadView; readonly label: string }[] = [
  { id: "all", label: "All" },
  { id: "mine", label: "My Leads" },
  { id: "new", label: "New" },
  { id: "unassigned", label: "Unassigned" },
  { id: "estimate_scheduled", label: "Estimate Scheduled" },
  { id: "won", label: "Won" },
  { id: "lost", label: "Lost" },
  { id: "spam", label: "Spam Review" },
];

const statusLabels: Readonly<Record<LeadStatus | "estimate_scheduled", string>> = {
  new: "New",
  contacted: "Contacted",
  qualified: "Qualified",
  estimate_scheduled: "Estimate scheduled",
  won: "Won",
  lost: "Lost",
  spam: "Spam Review",
};

const emptyFilterDraft: LeadFilterDraft = {
  status: "",
  service: "",
  assigneeId: "",
  source: "",
  priority: "",
  createdFrom: "",
  createdTo: "",
};

function selectedFilter(value: string): readonly string[] | undefined {
  return value ? [value] : undefined;
}

function useIsMobile(): boolean {
  const [isMobile, setIsMobile] = useState(() =>
    typeof window !== "undefined" && typeof window.matchMedia === "function"
      ? window.matchMedia(MOBILE_QUERY).matches
      : false,
  );

  useEffect(() => {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return;

    const query = window.matchMedia(MOBILE_QUERY);
    const update = (event: MediaQueryListEvent) => setIsMobile(event.matches);
    setIsMobile(query.matches);
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);

  return isMobile;
}

function filterFromDraft(draft: LeadFilterDraft): LeadListFilter | undefined {
  const filter: LeadListFilter = {
    ...(draft.status ? { statuses: selectedFilter(draft.status) as readonly LeadStatus[] } : {}),
    ...(draft.service ? { services: [draft.service] } : {}),
    ...(draft.assigneeId ? { assigneeIds: [draft.assigneeId] } : {}),
    ...(draft.source ? { sources: selectedFilter(draft.source) as readonly LeadSource[] } : {}),
    ...(draft.priority ? { priorities: selectedFilter(draft.priority) as readonly LeadPriority[] } : {}),
    ...(draft.createdFrom ? { createdFrom: draft.createdFrom } : {}),
    ...(draft.createdTo ? { createdTo: draft.createdTo } : {}),
  };
  return Object.keys(filter).length > 0 ? filter : undefined;
}

function filterToAst(filter?: LeadListFilter): LeadSavedFilterAst {
  const clauses: LeadSavedFilterAst["clauses"] = [
    ...(filter?.statuses?.length ? [{ field: "status" as const, operator: "in" as const, value: [...filter.statuses] }] : []),
    ...(filter?.services?.length ? [{ field: "service" as const, operator: "in" as const, value: [...filter.services] }] : []),
    ...(filter?.assigneeIds?.length ? [{ field: "assignee_id" as const, operator: "in" as const, value: [...filter.assigneeIds] }] : []),
    ...(filter?.sources?.length ? [{ field: "source" as const, operator: "in" as const, value: [...filter.sources] }] : []),
    ...(filter?.priorities?.length ? [{ field: "priority" as const, operator: "in" as const, value: [...filter.priorities] }] : []),
    ...(filter?.createdFrom ? [{ field: "created_at" as const, operator: "after" as const, value: filter.createdFrom }] : []),
    ...(filter?.createdTo ? [{ field: "created_at" as const, operator: "before" as const, value: filter.createdTo }] : []),
    ...(filter?.unassigned ? [{ field: "unassigned" as const, operator: "equals" as const, value: true }] : []),
    ...(filter?.estimateScheduled ? [{ field: "estimate_scheduled" as const, operator: "equals" as const, value: true }] : []),
  ];
  return { version: 1, conjunction: "all", clauses };
}

function cloneFilter(filter?: LeadListFilter): LeadListFilter | undefined {
  return filter ? JSON.parse(JSON.stringify(filter)) as LeadListFilter : undefined;
}

function workspaceCommandMessage(result: LeadWorkspaceCommandResult, success: string): string {
  if (result.status === "applied") return success;
  if (result.status === "conflict") return `This saved view changed elsewhere (current version ${result.actualVersion}).`;
  return result.message || "This action is not authorized.";
}

function filterForView(view: LeadViewId, memberId: string, savedViews: readonly LeadSavedViewOption[]): LeadListFilter | undefined {
  if (view.startsWith("saved:")) return savedViews.find((saved) => `saved:${saved.id}` === view)?.filter;
  switch (view) {
    case "mine": return { assigneeIds: [memberId] };
    case "new": return { statuses: ["new"] };
    case "unassigned": return { unassigned: true };
    case "estimate_scheduled": return { estimateScheduled: true };
    case "won": return { statuses: ["won"] };
    case "lost": return { statuses: ["lost"] };
    case "spam": return { statuses: ["spam"] };
    default: return undefined;
  }
}

function mergeFilters(base?: LeadListFilter, selected?: LeadListFilter): LeadListFilter | undefined {
  if (!base) return selected;
  if (!selected) return base;
  return { ...base, ...selected };
}

function effectiveFilter(state: LeadWorkspaceUrlState, memberId: string, savedViews: readonly LeadSavedViewOption[]): LeadListFilter | undefined {
  return mergeFilters(filterForView(state.view, memberId, savedViews), state.filter);
}

function listRequest(state: LeadWorkspaceUrlState, props: LeadsWorkspaceProps, cursor?: string) {
  return {
    view: state.view,
    ...(state.search ? { search: state.search } : {}),
    ...(mergeFilters(filterForView(state.view, props.access.memberId, props.savedViews), state.filter)
      ? { filter: mergeFilters(filterForView(state.view, props.access.memberId, props.savedViews), state.filter) }
      : {}),
    sort: state.sort,
    direction: state.direction,
    limit: PAGE_SIZE,
    ...(cursor ? { cursor } : {}),
  };
}

function formatDate(value: string): string {
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" }).format(new Date(value));
}

function priorityLabel(priority?: LeadPriority): string {
  if (!priority) return "Normal";
  return priority[0]!.toUpperCase() + priority.slice(1);
}

function StateMessage({
  kind,
  title,
  message,
}: {
  readonly kind: "loading" | "error" | "denied" | "empty";
  readonly title: string;
  readonly message: string;
}) {
  const Icon = kind === "loading" ? LoaderCircle : kind === "empty" ? UsersRound : AlertTriangle;
  return (
    <section
      className={styles.stateMessage}
      data-leads-state={kind}
      role={kind === "error" ? "alert" : "status"}
    >
      <Icon size={22} aria-hidden="true" />
      <div><h3>{title}</h3><p>{message}</p></div>
    </section>
  );
}

function LeadSelection({
  lead,
  selected,
  onToggle,
}: {
  readonly lead: LeadListItem;
  readonly selected: boolean;
  readonly onToggle: (lead: LeadListItem) => void;
}) {
  return (
    <input
      type="checkbox"
      checked={selected}
      aria-label={`Select ${lead.customerDisplayName}`}
      onChange={() => onToggle(lead)}
    />
  );
}

interface LeadRowsProps {
  readonly items: readonly LeadListItem[];
  readonly selected: ReadonlySet<string>;
  readonly selectable: boolean;
  readonly assignees: LeadsWorkspaceProps["assignees"];
  readonly onToggle: (lead: LeadListItem) => void;
  readonly onOpen: (lead: LeadListItem) => void;
}

function DesktopLeadTable({ items, selected, selectable, assignees, onToggle, onOpen }: LeadRowsProps) {
  const assigneeLabels = new Map(assignees.map((assignee) => [assignee.id, assignee.label]));
  return (
    <div className={styles.desktopList} data-builder-leads-list="desktop">
      <table>
        <thead><tr>
          {selectable ? <th scope="col"><span className={styles.visuallyHidden}>Select</span></th> : null}
          <th scope="col">Customer</th><th scope="col">Service</th><th scope="col">Status</th>
          <th scope="col">Priority</th><th scope="col">Assignee</th><th scope="col">Updated</th><th scope="col"><span className={styles.visuallyHidden}>Open</span></th>
        </tr></thead>
        <tbody>
          {items.map((lead) => (
            <tr key={lead.id} data-builder-lead-id={lead.id}>
              {selectable ? <td><LeadSelection lead={lead} selected={selected.has(lead.id)} onToggle={onToggle} /></td> : null}
              <th scope="row"><strong>{lead.customerDisplayName}</strong><span>{lead.urgency === "emergency" ? "Emergency" : lead.urgency === "urgent" ? "Urgent request" : "Standard request"}</span></th>
              <td>{lead.service}</td>
              <td><span className={styles.statusBadge} data-lead-status={lead.displayLane}>{statusLabels[lead.displayLane]}</span></td>
              <td>{priorityLabel(lead.priority)}</td>
              <td>{lead.assigneeId ? assigneeLabels.get(lead.assigneeId) ?? "Assigned" : "Unassigned"}</td>
              <td>{formatDate(lead.updatedAt)}</td>
              <td><button type="button" className={styles.rowAction} aria-label={`Open ${lead.customerDisplayName}`} onClick={() => onOpen(lead)}><ChevronRight size={18} aria-hidden="true" /></button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function MobileLeadList({ items, selected, selectable, assignees, onToggle, onOpen }: LeadRowsProps) {
  const assigneeLabels = new Map(assignees.map((assignee) => [assignee.id, assignee.label]));
  return (
    <ul className={styles.mobileList} data-builder-leads-list="mobile">
      {items.map((lead) => (
        <li key={lead.id} data-builder-lead-id={lead.id}>
          {selectable ? <LeadSelection lead={lead} selected={selected.has(lead.id)} onToggle={onToggle} /> : null}
          <button type="button" className={styles.mobileLeadButton} aria-label={`Open ${lead.customerDisplayName}`} onClick={() => onOpen(lead)}>
            <span className={styles.mobileLeadMain}><strong>{lead.customerDisplayName}</strong><span>{lead.service}</span></span>
            <span className={styles.mobileLeadMeta}><span className={styles.statusBadge} data-lead-status={lead.displayLane}>{statusLabels[lead.displayLane]}</span><span>{lead.assigneeId ? assigneeLabels.get(lead.assigneeId) ?? "Assigned" : "Unassigned"}</span></span>
            <ChevronRight size={18} aria-hidden="true" />
          </button>
        </li>
      ))}
    </ul>
  );
}

function FilterControls({
  draft,
  props,
  onChange,
  onClear,
}: {
  readonly draft: LeadFilterDraft;
  readonly props: LeadsWorkspaceProps;
  readonly onChange: (draft: LeadFilterDraft) => void;
  readonly onClear: () => void;
}) {
  function field<Key extends keyof LeadFilterDraft>(key: Key, value: LeadFilterDraft[Key]) {
    onChange({ ...draft, [key]: value });
  }
  return (
    <details className={styles.filters}>
      <summary><Filter size={17} aria-hidden="true" />Filters</summary>
      <div className={styles.filterGrid}>
        <label><span>Status</span><select value={draft.status} onChange={(event) => field("status", event.target.value as LeadFilterDraft["status"])}><option value="">Any status</option>{Object.entries(statusLabels).filter(([status]) => status !== "estimate_scheduled").map(([status, label]) => <option key={status} value={status}>{label}</option>)}</select></label>
        <label><span>Service</span><select value={draft.service} onChange={(event) => field("service", event.target.value)}><option value="">Any service</option>{props.services.map((service) => <option key={service} value={service}>{service}</option>)}</select></label>
        <label><span>Assignee</span><select value={draft.assigneeId} onChange={(event) => field("assigneeId", event.target.value)}><option value="">Any assignee</option>{props.assignees.map((assignee) => <option key={assignee.id} value={assignee.id}>{assignee.label}</option>)}</select></label>
        <label><span>Source</span><select value={draft.source} onChange={(event) => field("source", event.target.value as LeadFilterDraft["source"])}><option value="">Any source</option><option value="website_form">Website form</option><option value="phone">Phone</option><option value="walk_in">Walk-in</option><option value="staff_entry">Staff entry</option></select></label>
        <label><span>Priority</span><select value={draft.priority} onChange={(event) => field("priority", event.target.value as LeadFilterDraft["priority"])}><option value="">Any priority</option><option value="low">Low</option><option value="normal">Normal</option><option value="high">High</option><option value="urgent">Urgent</option></select></label>
        <label><span>From</span><input type="date" value={draft.createdFrom} onChange={(event) => field("createdFrom", event.target.value)} /></label>
        <label><span>To</span><input type="date" value={draft.createdTo} onChange={(event) => field("createdTo", event.target.value)} /></label>
        <button type="button" className={styles.secondaryButton} onClick={onClear}><X size={16} aria-hidden="true" />Clear filters</button>
      </div>
    </details>
  );
}

function BulkToolbar({
  selected,
  items,
  props,
  busy,
  result,
  onApply,
  onClear,
}: {
  readonly selected: ReadonlySet<string>;
  readonly items: readonly LeadListItem[];
  readonly props: LeadsWorkspaceProps;
  readonly busy: boolean;
  readonly result: BulkLeadCommandResult | null;
  readonly onApply: (action: string) => void;
  readonly onClear: () => void;
}) {
  const [action, setAction] = useState("");
  if (selected.size === 0) return null;
  const applied = result?.results.filter((item) => item.status === "applied").length ?? 0;
  const denied = result?.results.filter((item) => item.status === "denied").length ?? 0;
  const conflict = result?.results.filter((item) => item.status === "conflict").length ?? 0;
  return (
    <section className={styles.bulkToolbar} aria-label="Bulk lead actions">
      <strong data-builder-lead-selection-count>{selected.size} selected</strong>
      <select aria-label="Bulk action" value={action} onChange={(event) => setAction(event.target.value)}>
        <option value="">Choose action</option>
        {(["new", "contacted", "qualified", "won", "lost", "spam"] as const).map((status) => <option key={status} value={`status:${status}`}>Status: {statusLabels[status]}</option>)}
        {props.access.canAssignOthers ? props.assignees.map((assignee) => <option key={assignee.id} value={`assign:${assignee.id}`}>Assign: {assignee.label}</option>) : null}
        {props.tags.map((tag) => <option key={tag.id} value={`tag:add:${tag.id}`}>Add tag: {tag.label}</option>)}
      </select>
      <button type="button" className={styles.primaryButton} disabled={!action || busy} onClick={() => onApply(action)}>Apply bulk action</button>
      <button type="button" className={styles.iconButton} aria-label="Clear selection" onClick={onClear}><X size={18} aria-hidden="true" /></button>
      {result ? (
        <div className={styles.bulkResult} role="status" aria-live="polite">
          <strong>{applied} applied / {denied} denied / {conflict} conflict{conflict === 1 ? "" : "s"}</strong>
          {result.results.map((item) => item.status === "applied" ? null : (
            <span key={item.leadId}>{item.status === "conflict" ? `${item.leadId} changed elsewhere` : `${item.leadId} was denied`}</span>
          ))}
        </div>
      ) : null}
    </section>
  );
}

function SavedViewManager({
  views,
  name,
  selectedId,
  busy,
  clauseCount,
  onName,
  onSelect,
  onCreate,
  onUpdate,
  onRemove,
}: {
  readonly views: readonly LeadSavedViewOption[];
  readonly name: string;
  readonly selectedId: string;
  readonly busy: boolean;
  readonly clauseCount: number;
  readonly onName: (name: string) => void;
  readonly onSelect: (id: string) => void;
  readonly onCreate: () => void;
  readonly onUpdate: () => void;
  readonly onRemove: () => void;
}) {
  return (
    <section className={styles.savedViewManager} data-builder-lead-saved-view-manager>
      <div>
        <strong>User-saved views</strong>
        <span>{clauseCount} of 20 filter clauses</span>
      </div>
      <label><span>Saved view name</span><input aria-label="Saved view name" value={name} maxLength={80} onChange={(event) => onName(event.currentTarget.value)} /></label>
      <label><span>Edit existing</span><select aria-label="Saved view to edit" value={selectedId} onChange={(event) => onSelect(event.currentTarget.value)}><option value="">New view</option>{views.map((view) => <option key={view.id} value={view.id}>{view.label}</option>)}</select></label>
      <div className={styles.savedViewActions}>
        <button type="button" className={styles.primaryButton} disabled={busy || !name.trim() || Boolean(selectedId)} onClick={onCreate}>Create saved view</button>
        <button type="button" className={styles.secondaryButton} disabled={busy || !selectedId || !name.trim()} onClick={onUpdate}>Update saved view</button>
        <button type="button" className={styles.secondaryButton} disabled={busy || !selectedId} onClick={onRemove}>Remove saved view</button>
      </div>
    </section>
  );
}

export function LeadsWorkspace(props: LeadsWorkspaceProps) {
  const isMobile = useIsMobile();
  const demoApiRef = useRef<LeadsDemoApi | null>(null);
  if (demoApiRef.current === null) demoApiRef.current = createLeadsDemoApi();
  const activeApi = props.mode === "demo" ? demoApiRef.current : props.api;
  const [state, setState] = useState<LeadWorkspaceUrlState>(props.urlState);
  const [page, setPage] = useState<LeadPage | undefined>(() => props.mode === "demo" ? LEADS_DEMO_PAGE : props.initialPage);
  const [detail, setDetail] = useState<LeadWorkspaceDetail | null>(props.initialDetail ?? null);
  const [selected, setSelected] = useState<Set<string>>(() => new Set());
  const [filterDraft, setFilterDraft] = useState<LeadFilterDraft>(emptyFilterDraft);
  const [manualOpen, setManualOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [bulkResult, setBulkResult] = useState<BulkLeadCommandResult | null>(null);
  const [savedViews, setSavedViews] = useState<readonly LeadSavedViewOption[]>(props.savedViews);
  const [savedManagerOpen, setSavedManagerOpen] = useState(false);
  const [savedViewId, setSavedViewId] = useState("");
  const [savedViewName, setSavedViewName] = useState("");
  const [savedViewAst, setSavedViewAst] = useState<LeadSavedFilterAst>(() => filterToAst(effectiveFilter(props.urlState, props.access.memberId, props.savedViews)));

  useEffect(() => setState(props.urlState), [props.urlState]);
  useEffect(() => setSavedViews(props.savedViews), [props.savedViews]);
  useEffect(() => {
    if (props.mode === "demo") setPage(LEADS_DEMO_PAGE);
    else if (props.initialPage) setPage(props.initialPage);
  }, [props.initialPage, props.mode]);
  useEffect(() => {
    if (props.initialDetail) setDetail(props.initialDetail);
  }, [props.initialDetail]);

  useEffect(() => {
    if (props.mode !== "operational" && props.mode !== "read_only") return;
    if (props.initialPage) return;
    let active = true;
    void activeApi.list(listRequest(state, { ...props, savedViews })).then((nextPage) => {
      if (active) setPage(nextPage);
    }).catch(() => {
      if (active) setStatusMessage("Leads are temporarily unavailable.");
    });
    return () => { active = false; };
  }, [activeApi, props, state]);

  async function load(next: LeadWorkspaceUrlState, cursor?: string) {
    setBusy(true);
    setStatusMessage("");
    try {
      const nextPage = await activeApi.list(listRequest(next, { ...props, savedViews }, cursor));
      setPage((current) => {
        if (!cursor || !current) return nextPage;
        const itemsById = new Map(current.items.map((item) => [item.id, item]));
        for (const item of nextPage.items) itemsById.set(item.id, item);
        return {
          items: Array.from(itemsById.values()),
          ...(nextPage.nextCursor ? { nextCursor: nextPage.nextCursor } : {}),
        };
      });
    } catch {
      setStatusMessage("Leads are temporarily unavailable.");
    } finally {
      setBusy(false);
    }
  }

  function updateUrl(patch: Partial<LeadWorkspaceUrlState>, reload = true) {
    const next = { ...state, ...patch } as LeadWorkspaceUrlState;
    setState(next);
    props.onUrlStateChange?.(next);
    if (reload) void load(next);
  }

  function selectView(view: LeadViewId) {
    const saved = view.startsWith("saved:") ? savedViews.find((item) => `saved:${item.id}` === view) : undefined;
    updateUrl({ view, filter: saved?.filter, cursor: undefined });
    setSelected(new Set());
  }

  function submitSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const search = String(new FormData(event.currentTarget).get("search") ?? "").trim().slice(0, MAX_SEARCH_LENGTH);
    updateUrl({ search: search || undefined, cursor: undefined });
  }

  function updateFilters(nextDraft: LeadFilterDraft) {
    setFilterDraft(nextDraft);
    setSavedViewAst(filterToAst(mergeFilters(filterForView(state.view, props.access.memberId, savedViews), filterFromDraft(nextDraft))));
    updateUrl({ filter: filterFromDraft(nextDraft), cursor: undefined });
  }

  function toggleLead(lead: LeadListItem) {
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(lead.id)) next.delete(lead.id);
      else if (next.size < MAX_SELECTION) next.add(lead.id);
      return next;
    });
  }

  async function openDetail(lead: LeadListItem) {
    updateUrl({ detailId: lead.id }, false);
    setBusy(true);
    try {
      const nextDetail = await activeApi.get(lead.id);
      setDetail(nextDetail);
      if (!nextDetail) setStatusMessage("This lead is no longer available.");
    } catch {
      setStatusMessage("Lead detail is temporarily unavailable.");
    } finally {
      setBusy(false);
    }
  }

  function closeDetail() {
    setDetail(null);
    updateUrl({ detailId: undefined }, false);
  }

  async function mutate(operation: () => Promise<LeadWorkspaceMutationResult>, success: string) {
    setBusy(true);
    setStatusMessage("");
    try {
      const result = await operation();
      if (result.result === "applied") {
        if (detail) setDetail(await activeApi.get(detail.lead.id));
        await load(state);
        setStatusMessage(success);
      } else if (result.result === "conflict") {
        setStatusMessage("This lead changed elsewhere. Refresh and review before trying again.");
      } else {
        setStatusMessage("This action is not authorized.");
      }
    } catch {
      setStatusMessage("The lead action could not be completed.");
    } finally {
      setBusy(false);
    }
  }

  async function createManual(input: ManualLeadInput) {
    await mutate(() => activeApi.createManual(input), "Lead created");
    setManualOpen(false);
  }

  async function applyBulk(action: string) {
    const records = (page?.items ?? [])
      .filter((lead) => selected.has(lead.id))
      .slice(0, MAX_SELECTION)
      .map((lead) => ({ leadId: lead.id, expectedVersion: lead.version }));
    if (records.length === 0) return;
    setBusy(true);
    setBulkResult(null);
    try {
      let result: BulkLeadCommandResult;
      if (action.startsWith("status:")) {
        result = await activeApi.bulkStatus({ records, status: action.slice(7) as LeadStatus });
      } else if (action.startsWith("assign:")) {
        result = await activeApi.bulkAssign({ records, assigneeId: action.slice(7) });
      } else {
        const [, operation, tagId] = action.split(":");
        result = await activeApi.bulkTag({ records, tagId: tagId ?? "", operation: operation as "add" | "remove" });
      }
      setBulkResult(result);
      setStatusMessage("Bulk action completed with per-record results.");
    } catch {
      setStatusMessage("The bulk action could not be completed.");
    } finally {
      setBusy(false);
    }
  }

  async function requestExport() {
    const currentFilter = effectiveFilter(state, props.access.memberId, savedViews);
    const snapshot = {
      view: state.view,
      ...(state.search ? { search: state.search } : {}),
      ...(currentFilter ? { filter: cloneFilter(currentFilter)! } : {}),
      sort: state.sort,
      direction: state.direction,
    };
    setBusy(true);
    setStatusMessage("Requesting export...");
    try {
      const result = await activeApi.requestExport(snapshot);
      setStatusMessage(workspaceCommandMessage(result, "Export request queued."));
    } catch {
      setStatusMessage("The export request could not be completed.");
    } finally {
      setBusy(false);
    }
  }

  function selectSavedViewForEdit(id: string) {
    setSavedViewId(id);
    const selectedView = savedViews.find((view) => view.id === id);
    setSavedViewName(selectedView?.label ?? "");
    setSavedViewAst(selectedView?.ast ?? filterToAst(selectedView?.filter ?? state.filter));
  }

  async function saveView(update: boolean) {
    const validation = validateLeadSavedFilterAst(savedViewAst);
    if (!validation.ok) {
      setStatusMessage(validation.code === "too_many_clauses" ? "Saved views support at most 20 filter clauses." : "The saved view filter is invalid.");
      return;
    }
    const selectedView = savedViews.find((view) => view.id === savedViewId);
    setBusy(true);
    setStatusMessage(update ? "Updating saved view..." : "Creating saved view...");
    try {
      const result = await activeApi.saveView({
        ...(update && selectedView ? { viewId: selectedView.id, expectedVersion: selectedView.version ?? 1 } : {}),
        name: savedViewName.trim(),
        filter: validation.value,
      });
      setStatusMessage(workspaceCommandMessage(result, update ? "Saved view updated." : "Saved view created."));
      if (result.status === "applied") {
        const nextView: LeadSavedViewOption = {
          id: update && selectedView ? selectedView.id : result.resourceId ?? `local-view-${savedViews.length + 1}`,
          label: savedViewName.trim(),
          filter: cloneFilter(effectiveFilter(state, props.access.memberId, savedViews)) ?? {},
          ast: validation.value,
          version: result.version ?? (selectedView?.version ?? 0) + 1,
        };
        setSavedViews((current) => update
          ? current.map((view) => view.id === nextView.id ? nextView : view)
          : [...current, nextView]);
        if (!update) {
          setSavedViewId("");
          setSavedViewName("");
        }
      }
    } catch {
      setStatusMessage("The saved view action could not be completed.");
    } finally {
      setBusy(false);
    }
  }

  async function removeView() {
    const selectedView = savedViews.find((view) => view.id === savedViewId);
    if (!selectedView) return;
    setBusy(true);
    setStatusMessage("Removing saved view...");
    try {
      const result = await activeApi.removeView({ viewId: selectedView.id, expectedVersion: selectedView.version ?? 1 });
      setStatusMessage(workspaceCommandMessage(result, "Saved view removed."));
      if (result.status === "applied") {
        setSavedViews((current) => current.filter((view) => view.id !== selectedView.id));
        setSavedViewId("");
        setSavedViewName("");
        if (state.view === `saved:${selectedView.id}`) selectView("all");
      }
    } catch {
      setStatusMessage("The saved view could not be removed.");
    } finally {
      setBusy(false);
    }
  }

  function resetDemo() {
    demoApiRef.current?.reset();
    setPage(LEADS_DEMO_PAGE);
    setDetail(null);
    setSelected(new Set());
    setBulkResult(null);
    setStatusMessage("Sample data reset.");
    props.onResetDemo?.();
  }

  const selectable = props.mode !== "read_only" && props.access.canUpdate;
  const showOperational = props.mode === "operational" || props.mode === "read_only" || props.mode === "demo" || props.mode === "empty";
  const detailSurface = showOperational && props.access.canRead && detail ? (
    <LeadDetailSurface
      detail={detail}
      access={props.mode === "read_only" ? { ...props.access, canUpdate: false, canAssignOthers: false } : props.access}
      assignees={props.assignees}
      busy={busy}
      onClose={closeDetail}
      onStatus={(status) => void mutate(() => activeApi.changeStatus({ leadId: detail.lead.id, expectedVersion: detail.lead.version, status }), "Lead status updated")}
      onPriority={(priority) => void mutate(() => activeApi.setPriority({ leadId: detail.lead.id, expectedVersion: detail.lead.version, priority }), "Lead priority updated")}
      onAssign={(assigneeId) => void mutate(() => activeApi.assign({ leadId: detail.lead.id, expectedVersion: detail.lead.version, assigneeId }), "Lead assignment updated")}
      onNote={(body) => void mutate(() => activeApi.addNote({ leadId: detail.lead.id, expectedVersion: detail.lead.version, body }), "Note added")}
    />
  ) : null;

  return (
    <section
      className={styles.workspace}
      data-builder-leads-workspace
      data-builder-leads-demo={props.mode === "demo" ? "true" : undefined}
      data-leads-mode={props.mode}
    >
      <WorkspaceHeader
        eyebrow="Growth"
        title="Leads"
        description="Review inquiries, coordinate follow-up, and move work through the service pipeline."
        status={props.mode === "read_only" ? "Read-only access" : props.access.scope === "assigned" ? "Assigned leads" : undefined}
        actions={showOperational && props.mode !== "read_only" && props.access.canCreate ? (
          <button type="button" className={styles.primaryButton} onClick={() => setManualOpen(true)}>
            <Plus size={17} aria-hidden="true" />Add lead
          </button>
        ) : undefined}
      />

      {props.mode === "demo" ? <DemoBanner moduleName="Leads" onReset={resetDemo} /> : null}
      {props.mode === "loading" ? <StateMessage kind="loading" title="Loading leads" message="Retrieving the authorized lead queue." /> : null}
      {props.mode === "error" ? <StateMessage kind="error" title="Leads are temporarily unavailable" message={props.errorMessage ?? "Try again after the current service interruption."} /> : null}
      {props.mode === "denied" || !props.access.canRead ? <StateMessage kind="denied" title="Leads access is not available" message="Your current site access does not include lead records." /> : null}

      {showOperational && props.access.canRead ? (
        <>
          <div className={styles.viewToolbar}>
            <nav className={styles.viewButtons} aria-label="Lead views">
              {builtInViews.map((view) => <button key={view.id} type="button" aria-current={state.view === view.id ? "page" : undefined} onClick={() => selectView(view.id)}>{view.label}</button>)}
              {savedViews.map((view) => <button key={view.id} type="button" aria-current={state.view === `saved:${view.id}` ? "page" : undefined} onClick={() => selectView(`saved:${view.id}`)}>{view.label}</button>)}
            </nav>
            <label className={styles.mobileViewSelect}>
              <span>View</span>
              <select value={state.view} onChange={(event) => selectView(event.target.value as LeadViewId)}>
                {builtInViews.map((view) => <option key={view.id} value={view.id}>{view.label}</option>)}
                {savedViews.map((view) => <option key={view.id} value={`saved:${view.id}`}>{view.label}</option>)}
              </select>
            </label>
          </div>

          <div className={styles.searchRow}>
            <form className={styles.searchForm} role="search" onSubmit={submitSearch}>
              <Search size={18} aria-hidden="true" />
              <input type="search" name="search" aria-label="Search leads" placeholder="Search leads" defaultValue={state.search ?? ""} maxLength={MAX_SEARCH_LENGTH} />
              <button type="submit" className={styles.secondaryButton}>Search</button>
            </form>
            <button
              type="button"
              className={styles.secondaryButton}
              aria-label="Sort by updated"
              onClick={() => updateUrl({ sort: "updated_at", direction: state.direction === "desc" ? "asc" : "desc", cursor: undefined })}
            >
              <ArrowDownAZ size={17} aria-hidden="true" />Sort by updated
            </button>
            {props.access.canExport ? (
              <button type="button" className={styles.secondaryButton} disabled={busy} onClick={() => void requestExport()}>
                <Download size={17} aria-hidden="true" />Export current view
              </button>
            ) : null}
            {props.mode !== "read_only" && props.access.canUpdate ? (
              <button
                type="button"
                className={styles.secondaryButton}
                aria-expanded={savedManagerOpen}
                onClick={() => {
                  setSavedManagerOpen((open) => !open);
                  setSavedViewAst(filterToAst(effectiveFilter(state, props.access.memberId, savedViews)));
                }}
              >
                <Bookmark size={17} aria-hidden="true" />Manage saved views
              </button>
            ) : null}
          </div>

          {savedManagerOpen ? (
            <SavedViewManager
              views={savedViews}
              name={savedViewName}
              selectedId={savedViewId}
              busy={busy}
              clauseCount={savedViewAst.clauses.length}
              onName={setSavedViewName}
              onSelect={selectSavedViewForEdit}
              onCreate={() => void saveView(false)}
              onUpdate={() => void saveView(true)}
              onRemove={() => void removeView()}
            />
          ) : null}

          <FilterControls
            draft={filterDraft}
            props={props}
            onChange={updateFilters}
            onClear={() => updateFilters(emptyFilterDraft)}
          />

          <BulkToolbar
            selected={selected}
            items={page?.items ?? []}
            props={props}
            busy={busy}
            result={bulkResult}
            onApply={(action) => void applyBulk(action)}
            onClear={() => { setSelected(new Set()); setBulkResult(null); }}
          />

          {statusMessage ? <p className={styles.asyncStatus} role="status" aria-live="polite">{statusMessage}</p> : null}
          {!page && busy ? <StateMessage kind="loading" title="Loading leads" message="Retrieving the authorized lead queue." /> : null}
          {page && page.items.length === 0 ? <StateMessage kind="empty" title="No leads match this view" message="Adjust the active view, search, or filters." /> : null}
          {page && page.items.length > 0 ? (
            <div className={styles.listRegion} aria-busy={busy}>
              <DesktopLeadTable items={page.items} selected={selected} selectable={selectable} assignees={props.assignees} onToggle={toggleLead} onOpen={(lead) => void openDetail(lead)} />
              <MobileLeadList items={page.items} selected={selected} selectable={selectable} assignees={props.assignees} onToggle={toggleLead} onOpen={(lead) => void openDetail(lead)} />
            </div>
          ) : null}
          {page?.nextCursor ? (
            <div className={styles.loadMore}><button type="button" className={styles.secondaryButton} disabled={busy} onClick={() => void load(state, page.nextCursor)}>Load more</button></div>
          ) : null}
        </>
      ) : null}

      {detailSurface && !isMobile ? <aside className={styles.desktopDetailDrawer} aria-label="Lead detail drawer">{detailSurface}</aside> : null}
      {isMobile ? (
        <div className={styles.mobileSheetHost}>
          <MobileBottomSheet open={Boolean(detailSurface)} title="Lead detail" onClose={closeDetail}>{detailSurface}</MobileBottomSheet>
        </div>
      ) : null}

      {manualOpen && !isMobile ? (
        <div className={styles.desktopManualBackdrop}>
          <aside className={styles.desktopManualDrawer} role="dialog" aria-modal="true" aria-label="Add lead">
            <header><div><span className={styles.eyebrow}>Manual entry</span><h2>Add lead</h2></div><button type="button" className={styles.iconButton} aria-label="Close manual lead entry" onClick={() => setManualOpen(false)}><X size={20} aria-hidden="true" /></button></header>
            <ManualLeadForm access={props.access} assignees={props.assignees} services={props.services} busy={busy} onSubmit={(input) => void createManual(input)} />
          </aside>
        </div>
      ) : null}
      {isMobile ? (
        <div className={styles.mobileSheetHost}>
          <MobileBottomSheet open={manualOpen} title="Add lead" onClose={() => setManualOpen(false)}>
            <ManualLeadForm access={props.access} assignees={props.assignees} services={props.services} busy={busy} onSubmit={(input) => void createManual(input)} />
          </MobileBottomSheet>
        </div>
      ) : null}
    </section>
  );
}
