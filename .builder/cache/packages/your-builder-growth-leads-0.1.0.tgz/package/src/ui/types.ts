import type {
  BulkLeadCommandResult,
  LeadListFilter,
  LeadPage,
  LeadPriority,
  LeadSource,
  LeadStatus,
  LeadWorkspaceDetail,
  ManualLeadSource,
} from "../index.js";

export type LeadsWorkspaceMode =
  | "demo"
  | "loading"
  | "empty"
  | "error"
  | "denied"
  | "operational"
  | "read_only";

export type BuiltInLeadView =
  | "all"
  | "mine"
  | "new"
  | "unassigned"
  | "estimate_scheduled"
  | "won"
  | "lost"
  | "spam";

export type LeadViewId = BuiltInLeadView | `saved:${string}`;

export interface LeadWorkspaceUrlState {
  readonly view: LeadViewId;
  readonly search?: string;
  readonly filter?: LeadListFilter;
  readonly sort: "created_at" | "updated_at" | "priority" | "status";
  readonly direction: "asc" | "desc";
  readonly cursor?: string;
  readonly detailId?: string;
}

export interface LeadWorkspaceAccess {
  readonly memberId: string;
  readonly scope: "site" | "assigned";
  readonly canRead: boolean;
  readonly canCreate: boolean;
  readonly canUpdate: boolean;
  readonly canAssignOthers: boolean;
  readonly canManageTasks: boolean;
  readonly canExport: boolean;
}

export interface LeadAssigneeOption {
  readonly id: string;
  readonly label: string;
}

export interface LeadTagOption {
  readonly id: string;
  readonly label: string;
  readonly color?: string;
}

export interface LeadSavedViewOption {
  readonly id: string;
  readonly label: string;
  readonly filter: LeadListFilter;
  readonly ast?: LeadSavedFilterAst;
  readonly version?: number;
}

export type LeadSavedFilterField =
  | "status"
  | "service"
  | "assignee_id"
  | "source"
  | "priority"
  | "created_at"
  | "unassigned"
  | "estimate_scheduled";

export type LeadSavedFilterOperator =
  | "equals"
  | "not_equals"
  | "in"
  | "contains"
  | "before"
  | "after"
  | "is_empty";

export interface LeadSavedFilterClause {
  readonly field: LeadSavedFilterField;
  readonly operator: LeadSavedFilterOperator;
  readonly value?: string | boolean | readonly string[];
}

export interface LeadSavedFilterAst {
  readonly version: 1;
  readonly conjunction: "all" | "any";
  readonly clauses: readonly LeadSavedFilterClause[];
}

export type LeadSavedFilterValidation =
  | { readonly ok: true; readonly value: LeadSavedFilterAst }
  | { readonly ok: false; readonly code: "too_many_clauses" | "invalid_field" | "invalid_operator" };

const leadSavedFilterFields: readonly LeadSavedFilterField[] = [
  "status", "service", "assignee_id", "source", "priority", "created_at", "unassigned", "estimate_scheduled",
];
const leadSavedFilterOperators: readonly LeadSavedFilterOperator[] = [
  "equals", "not_equals", "in", "contains", "before", "after", "is_empty",
];

export function validateLeadSavedFilterAst(filter: LeadSavedFilterAst): LeadSavedFilterValidation {
  if (filter.clauses.length > 20) return { ok: false, code: "too_many_clauses" };
  for (const clause of filter.clauses) {
    if (!leadSavedFilterFields.includes(clause.field)) return { ok: false, code: "invalid_field" };
    if (!leadSavedFilterOperators.includes(clause.operator)) return { ok: false, code: "invalid_operator" };
  }
  return { ok: true, value: filter };
}

export interface LeadWorkspaceListRequest {
  readonly view?: LeadViewId;
  readonly search?: string;
  readonly filter?: LeadListFilter;
  readonly sort?: LeadWorkspaceUrlState["sort"];
  readonly direction?: LeadWorkspaceUrlState["direction"];
  readonly limit: number;
  readonly cursor?: string;
}

export type LeadWorkspaceMutationResult =
  | { readonly result: "applied"; readonly leadId: string; readonly version: number }
  | { readonly result: "conflict"; readonly expectedVersion: number; readonly actualVersion: number }
  | { readonly result: "denied"; readonly reason: "not_authorized" | "invalid_request" };

export type LeadWorkspaceCommandResult =
  | { readonly status: "applied"; readonly resourceId?: string; readonly version?: number }
  | { readonly status: "conflict"; readonly actualVersion: number }
  | { readonly status: "denied"; readonly message: string };

export interface ManualLeadInput {
  readonly firstName: string;
  readonly lastName: string;
  readonly email?: string;
  readonly phone?: string;
  readonly zipCode: string;
  readonly service: string;
  readonly urgency: "standard" | "urgent" | "emergency";
  readonly source: ManualLeadSource;
  readonly notes?: string;
  readonly assigneeId?: string;
}

export interface LeadWorkspaceApi {
  readonly externalEffects: boolean;
  list(input: LeadWorkspaceListRequest): Promise<LeadPage>;
  get(leadId: string): Promise<LeadWorkspaceDetail | null>;
  createManual(input: ManualLeadInput): Promise<LeadWorkspaceMutationResult>;
  changeStatus(input: {
    readonly leadId: string;
    readonly expectedVersion: number;
    readonly status: LeadStatus;
  }): Promise<LeadWorkspaceMutationResult>;
  setPriority(input: {
    readonly leadId: string;
    readonly expectedVersion: number;
    readonly priority: LeadPriority;
  }): Promise<LeadWorkspaceMutationResult>;
  assign(input: {
    readonly leadId: string;
    readonly expectedVersion: number;
    readonly assigneeId: string;
  }): Promise<LeadWorkspaceMutationResult>;
  addNote(input: {
    readonly leadId: string;
    readonly expectedVersion: number;
    readonly body: string;
  }): Promise<LeadWorkspaceMutationResult>;
  bulkStatus(input: {
    readonly records: readonly { readonly leadId: string; readonly expectedVersion: number }[];
    readonly status: LeadStatus;
  }): Promise<BulkLeadCommandResult>;
  bulkAssign(input: {
    readonly records: readonly { readonly leadId: string; readonly expectedVersion: number }[];
    readonly assigneeId: string;
  }): Promise<BulkLeadCommandResult>;
  bulkTag(input: {
    readonly records: readonly { readonly leadId: string; readonly expectedVersion: number }[];
    readonly tagId: string;
    readonly operation: "add" | "remove";
  }): Promise<BulkLeadCommandResult>;
  requestExport(input: {
    readonly view: LeadViewId;
    readonly search?: string;
    readonly filter?: LeadListFilter;
    readonly sort: LeadWorkspaceUrlState["sort"];
    readonly direction: LeadWorkspaceUrlState["direction"];
  }): Promise<LeadWorkspaceCommandResult>;
  saveView(input: {
    readonly viewId?: string;
    readonly expectedVersion?: number;
    readonly name: string;
    readonly filter: LeadSavedFilterAst;
  }): Promise<LeadWorkspaceCommandResult>;
  removeView(input: { readonly viewId: string; readonly expectedVersion: number }): Promise<LeadWorkspaceCommandResult>;
}

export interface LeadsWorkspaceProps {
  readonly mode: LeadsWorkspaceMode;
  readonly api: LeadWorkspaceApi;
  readonly access: LeadWorkspaceAccess;
  readonly assignees: readonly LeadAssigneeOption[];
  readonly tags: readonly LeadTagOption[];
  readonly services: readonly string[];
  readonly savedViews: readonly LeadSavedViewOption[];
  readonly initialPage?: LeadPage;
  readonly initialDetail?: LeadWorkspaceDetail;
  readonly urlState: LeadWorkspaceUrlState;
  readonly errorMessage?: string;
  readonly onUrlStateChange?: (state: LeadWorkspaceUrlState) => void;
  readonly onResetDemo?: () => void;
}

export interface LeadFilterDraft {
  readonly status: LeadStatus | "";
  readonly service: string;
  readonly assigneeId: string;
  readonly source: LeadSource | "";
  readonly priority: LeadPriority | "";
  readonly createdFrom: string;
  readonly createdTo: string;
}
