import type {
  AppliedOrConflict,
  CreateTaskCommand,
  MemberOperationActor,
  RecordServiceEventCommand,
  VersionedCommandContext,
} from "@your-builder/growth-core";
import type { Lead, LeadPriority, LeadStatus, ManualLeadSource } from "./lead.js";

export interface CreateManualLeadCommand {
  readonly siteId: string;
  readonly actor: MemberOperationActor;
  readonly idempotencyKey: string;
  readonly source: ManualLeadSource;
  readonly firstName: string;
  readonly lastName: string;
  readonly email?: string;
  readonly phone?: string;
  readonly zipCode: string;
  readonly service: string;
  readonly urgency: "standard" | "urgent" | "emergency";
  readonly notes?: string;
  readonly assigneeId?: string;
}

export interface AssignLeadCommand extends VersionedCommandContext { readonly leadId: string; readonly assigneeId: string; }
export interface AddLeadNoteCommand extends VersionedCommandContext { readonly leadId: string; readonly body: string; }
export interface ChangeLeadStatusCommand extends VersionedCommandContext { readonly leadId: string; readonly to: LeadStatus; readonly correction?: boolean; readonly restore?: boolean; }
export interface SetLeadPriorityCommand extends VersionedCommandContext { readonly leadId: string; readonly priority: LeadPriority; }
export interface CreateLeadTaskCommand extends CreateTaskCommand { readonly relatedType: "lead"; readonly leadId: string; }
export interface RecordLeadServiceEventCommand extends RecordServiceEventCommand { readonly leadId: string; }

export type LeadBulkRecordResult =
  | { readonly leadId: string; readonly status: "applied"; readonly version: number }
  | { readonly leadId: string; readonly status: "denied"; readonly reason: "not_authorized" | "invalid_request" }
  | { readonly leadId: string; readonly status: "conflict"; readonly expectedVersion: number; readonly actualVersion: number };

export interface BulkLeadCommandResult { readonly requestedCount: number; readonly results: readonly LeadBulkRecordResult[]; }
export interface BulkLeadStatusCommand {
  readonly siteId: string;
  readonly actor: MemberOperationActor;
  readonly idempotencyKey: string;
  readonly records: readonly { readonly leadId: string; readonly expectedVersion: number }[];
  readonly to: LeadStatus;
}
export interface BulkLeadAssignmentCommand extends Omit<BulkLeadStatusCommand, "to"> { readonly assigneeId: string; }
export interface BulkLeadTagCommand extends Omit<BulkLeadStatusCommand, "to"> { readonly tagId: string; readonly operation: "add" | "remove"; }

export interface LeadCommandService {
  createManual(input: CreateManualLeadCommand): Promise<Lead>;
  assign(input: AssignLeadCommand): Promise<AppliedOrConflict<Lead>>;
  addNote(input: AddLeadNoteCommand): Promise<AppliedOrConflict<Lead>>;
  changeStatus(input: ChangeLeadStatusCommand): Promise<AppliedOrConflict<Lead>>;
  setPriority(input: SetLeadPriorityCommand): Promise<AppliedOrConflict<Lead>>;
  createTask(input: CreateLeadTaskCommand): Promise<string>;
  recordServiceEvent(input: RecordLeadServiceEventCommand): Promise<string>;
  bulkStatus(input: BulkLeadStatusCommand): Promise<BulkLeadCommandResult>;
  bulkAssign(input: BulkLeadAssignmentCommand): Promise<BulkLeadCommandResult>;
  bulkTag(input: BulkLeadTagCommand): Promise<BulkLeadCommandResult>;
}
