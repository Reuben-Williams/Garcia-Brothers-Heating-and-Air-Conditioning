import type { MemberOperationActor } from "@your-builder/growth-core";

export type IngestionDecision =
  | { readonly kind: "enhanced"; readonly contactId: string; readonly leadId: string; readonly match?: "new_identity" | "exact_email" | "exact_phone" }
  | { readonly kind: "base_only"; readonly safeCode: "enhancement_unavailable" | "spam" }
  | { readonly kind: "review_required"; readonly safeCode: "identity_conflict" | "review_suggested" };

export interface StoreIngestionResultInput {
  readonly submissionId: string;
  readonly resultId: string;
  readonly resultVersion: number;
  readonly priorResultId?: string;
  readonly replayed: boolean;
  readonly decision: IngestionDecision;
}

export interface StoredIngestionResult {
  readonly submissionId: string;
  readonly resultId: string;
  readonly resultVersion: number;
  readonly priorResultId?: string;
  readonly baseRecordsCreated: true;
  readonly replayed: boolean;
  readonly outcome: IngestionDecision["kind"];
  readonly safeCode: "enhanced" | "enhancement_unavailable" | "spam" | "identity_conflict" | "review_suggested";
}

export function createStoredIngestionResult(input: StoreIngestionResultInput): StoredIngestionResult {
  if (!Number.isInteger(input.resultVersion) || input.resultVersion < 1) {
    throw new Error("Ingestion result version must be a positive integer.");
  }
  const safeCode = input.decision.kind === "enhanced" ? "enhanced" : input.decision.safeCode;
  return Object.freeze({
    submissionId: input.submissionId,
    resultId: input.resultId,
    resultVersion: input.resultVersion,
    priorResultId: input.priorResultId,
    baseRecordsCreated: true,
    replayed: input.replayed,
    outcome: input.decision.kind,
    safeCode,
  });
}

export interface ImportBaseSubmissionCommand {
  readonly siteId: string;
  readonly actor: MemberOperationActor;
  readonly submissionId: string;
  readonly expectedLatestResultVersion: number;
  readonly aal2VerifiedAt: string;
  readonly idempotencyKey: string;
}

export interface ImportBaseSubmissionResult {
  readonly status: "imported" | "replayed" | "conflict" | "denied";
  readonly submissionId: string;
  readonly resultVersion?: number;
  readonly safeCode: "enhanced" | "already_enhanced" | "version_conflict" | "not_authorized" | "enhancement_unavailable";
}

export interface LeadIngestionService {
  storeAcceptedInquiry(input: StoreIngestionResultInput): Promise<StoredIngestionResult>;
  importReviewedBaseSubmission(input: ImportBaseSubmissionCommand): Promise<ImportBaseSubmissionResult>;
}
