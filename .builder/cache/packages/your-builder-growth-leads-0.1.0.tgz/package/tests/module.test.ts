import { describe, expect, it } from "vitest";
import { GROWTH_LEADS_CONTRACT_VERSION, growthLeadsModule } from "../src/index.js";

describe("Leads module", () => {
  it("registers the frozen module definition and Customers dependency", () => {
    expect(GROWTH_LEADS_CONTRACT_VERSION).toBe(1);
    expect(growthLeadsModule).toMatchObject({
      id: "growth.leads",
      version: "1.0.0",
      requiredEntitlement: "growth.leads",
      requiredCapabilities: ["leads.read"],
      dependencies: [{ moduleId: "growth.customers", optional: false }],
      routes: [{ path: "/admin/editor/leads" }],
      demo: { allowsExternalEffects: false },
    });
  });
});
