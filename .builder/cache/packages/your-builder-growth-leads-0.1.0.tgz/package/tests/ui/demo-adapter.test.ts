import { describe, expect, it } from "vitest";

import {
  LEADS_DEMO_DETAILS,
  LEADS_DEMO_PAGE,
  createLeadsDemoApi,
} from "../../src/ui/index.js";

describe("Leads demo adapter", () => {
  it("uses deterministic fictional records and declares zero external effects", async () => {
    const demo = createLeadsDemoApi();

    expect(demo.externalEffects).toBe(false);
    await expect(demo.list({ limit: 50 })).resolves.toEqual(LEADS_DEMO_PAGE);
    expect(Object.values(LEADS_DEMO_DETAILS).every((detail) =>
      detail.customer.identities.every((identity) =>
        identity.kind !== "email" || identity.display.endsWith("@example.test"),
      ),
    )).toBe(true);
  });

  it("supports isolated local mutations and reset without changing the seed", async () => {
    const demo = createLeadsDemoApi();
    const first = LEADS_DEMO_PAGE.items[0];
    expect(first).toBeDefined();

    await expect(demo.changeStatus({
      leadId: first!.id,
      expectedVersion: first!.version + 10,
      status: "contacted",
    })).resolves.toEqual({
      result: "conflict",
      expectedVersion: first!.version + 10,
      actualVersion: first!.version,
    });
    expect((await demo.list({ limit: 50 })).items[0]?.status).toBe(first!.status);

    await demo.changeStatus({
      leadId: first!.id,
      expectedVersion: first!.version,
      status: "contacted",
    });
    expect((await demo.list({ limit: 50 })).items[0]?.status).toBe("contacted");

    demo.reset();
    expect((await demo.list({ limit: 50 })).items[0]?.status).toBe(first!.status);
    expect(LEADS_DEMO_PAGE.items[0]?.status).toBe(first!.status);
  });
});
