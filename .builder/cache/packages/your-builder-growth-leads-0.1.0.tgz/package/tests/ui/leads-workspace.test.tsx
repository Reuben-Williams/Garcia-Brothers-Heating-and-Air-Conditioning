// @vitest-environment jsdom

import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";

import type { LeadPage, LeadWorkspaceDetail } from "../../src/index.js";
import {
  LeadsWorkspace,
  type LeadWorkspaceApi,
  type LeadsWorkspaceProps,
} from "../../src/ui/index.js";

const page: LeadPage = {
  items: [
    {
      id: "lead-1",
      customerId: "customer-1",
      customerDisplayName: "Avery Stone",
      service: "Heating repair",
      urgency: "urgent",
      priority: "high",
      status: "new",
      displayLane: "new",
      assigneeId: "member-1",
      createdAt: "2026-07-17T13:00:00.000Z",
      updatedAt: "2026-07-18T13:00:00.000Z",
      version: 2,
    },
    {
      id: "lead-2",
      customerId: "customer-2",
      customerDisplayName: "Morgan Diaz",
      service: "AC estimate",
      urgency: "standard",
      status: "qualified",
      displayLane: "estimate_scheduled",
      createdAt: "2026-07-16T13:00:00.000Z",
      updatedAt: "2026-07-18T12:00:00.000Z",
      version: 4,
    },
  ],
  nextCursor: "cursor-2",
};

const detail: LeadWorkspaceDetail = {
  lead: {
    id: "lead-1",
    siteId: "site-1",
    contactId: "customer-1",
    submissionId: "submission-1",
    source: "website_form",
    service: "Heating repair",
    urgency: "urgent",
    priority: "high",
    status: "new",
    summary: "Furnace is not starting.",
    primaryAssigneeId: "member-1",
    version: 2,
    createdAt: "2026-07-17T13:00:00.000Z",
    updatedAt: "2026-07-18T13:00:00.000Z",
    timeline: [
      {
        id: "event-1",
        siteId: "site-1",
        leadId: "lead-1",
        kind: "created",
        occurredAt: "2026-07-17T13:00:00.000Z",
      },
    ],
    duplicateWarning: { suggestionId: "duplicate-1", confidence: "medium" },
    originalSubmissionId: "submission-1",
  },
  customer: {
    id: "customer-1",
    displayName: "Avery Stone",
    identities: [
      { kind: "email", display: "avery@example.test", verified: true },
      { kind: "phone", display: "+1 973 555 0142", verified: true },
    ],
  },
  tags: [{ id: "tag-1", label: "Priority follow-up", color: "#b42318" }],
  tasks: [
    {
      id: "task-1",
      siteId: "site-1",
      relatedType: "lead",
      relatedId: "lead-1",
      title: "Confirm access window",
      status: "open",
      priority: "high",
      dueAt: "2026-07-19T14:00:00.000Z",
      assigneeId: "member-1",
      version: 1,
    },
  ],
  serviceEvents: [
    {
      id: "service-1",
      siteId: "site-1",
      contactId: "customer-1",
      leadId: "lead-1",
      kind: "appointment.scheduled",
      purpose: "estimate",
      scheduledAt: "2026-07-20T15:00:00.000Z",
      origin: { type: "integration", integrationId: "demo", providerEventId: "provider-1" },
      occurredAt: "2026-07-18T13:00:00.000Z",
      correlationId: "correlation-1",
    },
  ],
  submission: {
    id: "submission-1",
    capturedAt: "2026-07-17T13:00:00.000Z",
    safeCode: "enhanced",
  },
};

function api(): LeadWorkspaceApi {
  return {
    externalEffects: true,
    list: vi.fn(async () => page),
    get: vi.fn(async () => detail),
    createManual: vi.fn(async () => ({ result: "applied" as const, leadId: "lead-created", version: 1 })),
    changeStatus: vi.fn(async () => ({ result: "applied" as const, leadId: "lead-1", version: 3 })),
    setPriority: vi.fn(async () => ({ result: "applied" as const, leadId: "lead-1", version: 3 })),
    assign: vi.fn(async () => ({ result: "applied" as const, leadId: "lead-1", version: 3 })),
    addNote: vi.fn(async () => ({ result: "applied" as const, leadId: "lead-1", version: 3 })),
    bulkStatus: vi.fn(async ({ records }: Parameters<LeadWorkspaceApi["bulkStatus"]>[0]) => ({
      requestedCount: records.length,
      results: records.map((record) => ({ leadId: record.leadId, status: "applied" as const, version: record.expectedVersion + 1 })),
    })),
    bulkAssign: vi.fn(async ({ records }) => ({ requestedCount: records.length, results: [] })),
    bulkTag: vi.fn(async ({ records }) => ({ requestedCount: records.length, results: [] })),
    requestExport: vi.fn(async () => ({ status: "applied" as const, resourceId: "lead-export-1" })),
    saveView: vi.fn(async () => ({ status: "applied" as const, resourceId: "view-created", version: 1 })),
    removeView: vi.fn(async () => ({ status: "applied" as const, version: 2 })),
  };
}

function props(overrides: Partial<LeadsWorkspaceProps> = {}): LeadsWorkspaceProps {
  return {
    mode: "operational",
    api: api(),
    access: {
      memberId: "member-1",
      scope: "site",
      canRead: true,
      canCreate: true,
      canUpdate: true,
      canAssignOthers: true,
      canManageTasks: true,
      canExport: true,
    },
    assignees: [
      { id: "member-1", label: "Jamie Rivera" },
      { id: "member-2", label: "Riley Chen" },
    ],
    tags: [{ id: "tag-1", label: "Priority follow-up", color: "#b42318" }],
    services: ["Heating repair", "AC estimate"],
    savedViews: [{ id: "saved-1", label: "Urgent follow-up", filter: { priorities: ["urgent"] } }],
    initialPage: page,
    initialDetail: detail,
    urlState: { view: "all", sort: "updated_at", direction: "desc", detailId: "lead-1" },
    onUrlStateChange: vi.fn(),
    ...overrides,
  };
}

describe("LeadsWorkspace", () => {
  it("renders the dense table, stable mobile list, views, filters, cursor, and audit selectors", () => {
    const html = renderToStaticMarkup(<LeadsWorkspace {...props({
      urlState: { view: "all", sort: "updated_at", direction: "desc" },
      initialDetail: undefined,
    })} />);

    expect(html).toContain("data-builder-leads-workspace");
    expect(html).toContain('data-leads-mode="operational"');
    expect(html).toContain('data-builder-leads-list="desktop"');
    expect(html).toContain('data-builder-leads-list="mobile"');
    expect(html).toContain('data-builder-lead-id="lead-1"');
    expect(html).toContain("All");
    expect(html).toContain("My Leads");
    expect(html).toContain("Estimate Scheduled");
    expect(html).toContain("Spam Review");
    expect(html).toContain("Urgent follow-up");
    expect(html).toContain("Search leads");
    expect(html).toContain("Load more");
  });

  it("renders the complete lead detail projection and safe contact actions", () => {
    const html = renderToStaticMarkup(<LeadsWorkspace {...props()} />);

    expect(html).toContain("data-builder-lead-detail");
    expect(html.match(/data-builder-lead-detail/g)).toHaveLength(1);
    expect(html).toContain("Avery Stone");
    expect(html).toContain('href="mailto:avery@example.test"');
    expect(html).toContain('href="tel:+19735550142"');
    expect(html).toContain("Confirm access window");
    expect(html).toContain("Appointment scheduled");
    expect(html).toContain("Original submission");
    expect(html).toContain("Possible duplicate");
    expect(html).toContain("Lead created");
  });

  it.each([
    ["loading", "Loading leads"],
    ["error", "Leads are temporarily unavailable"],
    ["denied", "Leads access is not available"],
  ] as const)("renders the %s state without operational records", (mode, message) => {
    const html = renderToStaticMarkup(<LeadsWorkspace {...props({ mode, initialPage: undefined })} />);

    expect(html).toContain(`data-leads-mode="${mode}"`);
    expect(html).toContain(message);
    expect(html).not.toContain('data-builder-lead-id="lead-1"');
  });

  it("renders an explicit empty state", () => {
    const html = renderToStaticMarkup(<LeadsWorkspace {...props({ initialPage: { items: [] } })} />);
    expect(html).toContain('data-leads-state="empty"');
    expect(html).toContain("No leads match this view");
  });

  it("keeps read-only records visible without mutation or selection controls", () => {
    const html = renderToStaticMarkup(<LeadsWorkspace {...props({
      mode: "read_only",
      access: { ...props().access, canCreate: false, canUpdate: false, canAssignOthers: false },
      urlState: { view: "all", sort: "updated_at", direction: "desc" },
      initialDetail: undefined,
    })} />);

    expect(html).toContain("Read-only access");
    expect(html).toContain("Avery Stone");
    expect(html).not.toContain("Add lead");
    expect(html).not.toContain('aria-label="Select Avery Stone"');
    expect(html).toContain("Export current view");
    expect(html).not.toContain("Manage saved views");
  });

  it("hides export from read-only users without export permission", () => {
    const base = props();
    const html = renderToStaticMarkup(<LeadsWorkspace {...props({
      mode: "read_only",
      access: { ...base.access, canCreate: false, canUpdate: false, canAssignOthers: false, canExport: false },
    })} />);

    expect(html).not.toContain("Export current view");
  });

  it("renders deterministic demo data through the existing disclosure", () => {
    const html = renderToStaticMarkup(<LeadsWorkspace {...props({
      mode: "demo",
      initialPage: undefined,
      initialDetail: undefined,
      urlState: { view: "all", sort: "updated_at", direction: "desc" },
    })} />);

    expect(html).toContain("Preview with sample data");
    expect(html).toContain("Reset demo");
    expect(html).toContain("Ada Brooks");
    expect(html).toContain("data-builder-leads-demo");
  });
});
