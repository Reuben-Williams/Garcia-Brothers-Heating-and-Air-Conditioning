// @vitest-environment jsdom

import React from "react";
import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";

import type { LeadPage } from "../../src/index.js";
import {
  LeadsWorkspace,
  type LeadWorkspaceApi,
  type LeadsWorkspaceProps,
  validateLeadSavedFilterAst,
} from "../../src/ui/index.js";

const page: LeadPage = {
  items: [
    {
      id: "lead-1",
      customerId: "customer-1",
      customerDisplayName: "Avery Stone",
      service: "Heating repair",
      urgency: "urgent",
      priority: "high",
      status: "new",
      displayLane: "new",
      assigneeId: "member-1",
      createdAt: "2026-07-17T13:00:00.000Z",
      updatedAt: "2026-07-18T13:00:00.000Z",
      version: 2,
    },
    {
      id: "lead-2",
      customerId: "customer-2",
      customerDisplayName: "Morgan Diaz",
      service: "AC estimate",
      urgency: "standard",
      status: "qualified",
      displayLane: "estimate_scheduled",
      createdAt: "2026-07-16T13:00:00.000Z",
      updatedAt: "2026-07-18T12:00:00.000Z",
      version: 4,
    },
  ],
  nextCursor: "cursor-2",
};

function api(): LeadWorkspaceApi {
  return {
    externalEffects: true,
    list: vi.fn(async () => page),
    get: vi.fn(async () => null),
    createManual: vi.fn(async () => ({ result: "applied" as const, leadId: "lead-created", version: 1 })),
    changeStatus: vi.fn(async () => ({ result: "applied" as const, leadId: "lead-1", version: 3 })),
    setPriority: vi.fn(async () => ({ result: "applied" as const, leadId: "lead-1", version: 3 })),
    assign: vi.fn(async () => ({ result: "applied" as const, leadId: "lead-1", version: 3 })),
    addNote: vi.fn(async () => ({ result: "applied" as const, leadId: "lead-1", version: 3 })),
    bulkStatus: vi.fn(async ({ records }: Parameters<LeadWorkspaceApi["bulkStatus"]>[0]) => ({
      requestedCount: records.length,
      results: [
        { leadId: records[0]!.leadId, status: "applied" as const, version: records[0]!.expectedVersion + 1 },
        { leadId: records[1]!.leadId, status: "conflict" as const, expectedVersion: records[1]!.expectedVersion, actualVersion: 8 },
      ],
    })),
    bulkAssign: vi.fn(async ({ records }) => ({ requestedCount: records.length, results: [] })),
    bulkTag: vi.fn(async ({ records }) => ({ requestedCount: records.length, results: [] })),
    requestExport: vi.fn(async () => ({ status: "applied" as const, resourceId: "lead-export-1" })),
    saveView: vi.fn(async (input) => ({ status: "applied" as const, resourceId: input.viewId ?? "view-created", version: input.viewId ? 4 : 1 })),
    removeView: vi.fn(async () => ({ status: "applied" as const, version: 2 })),
  };
}

function props(apiClient: LeadWorkspaceApi, onUrlStateChange = vi.fn()): LeadsWorkspaceProps {
  return {
    mode: "operational",
    api: apiClient,
    access: {
      memberId: "member-1",
      scope: "site",
      canRead: true,
      canCreate: true,
      canUpdate: true,
      canAssignOthers: true,
      canManageTasks: true,
      canExport: true,
    },
    assignees: [
      { id: "member-1", label: "Jamie Rivera" },
      { id: "member-2", label: "Riley Chen" },
    ],
    tags: [{ id: "tag-1", label: "Priority follow-up" }],
    services: ["Heating repair", "AC estimate"],
    savedViews: [{
      id: "saved-1",
      label: "Urgent follow-up",
      filter: { priorities: ["urgent"] },
      ast: { version: 1, conjunction: "all", clauses: [{ field: "priority", operator: "equals", value: "urgent" }] },
      version: 3,
    }],
    initialPage: page,
    urlState: { view: "all", sort: "updated_at", direction: "desc" },
    onUrlStateChange,
  };
}

let container: HTMLDivElement;
let root: Root;

beforeAll(() => {
  (globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
});

afterEach(async () => {
  if (root) await act(async () => root.unmount());
  container?.remove();
});

async function renderWorkspace(workspaceProps: LeadsWorkspaceProps) {
  container = document.createElement("div");
  document.body.append(container);
  root = createRoot(container);
  await act(async () => root.render(<LeadsWorkspace {...workspaceProps} />));
}

function button(name: string) {
  return Array.from(container.querySelectorAll<HTMLButtonElement>("button")).find((item) =>
    item.textContent?.trim() === name || item.getAttribute("aria-label") === name,
  );
}

describe("LeadsWorkspace interactions", () => {
  it("normalizes missing URL state instead of crashing the workspace", async () => {
    const input = props(api());
    await expect(renderWorkspace({
      ...input,
      urlState: {} as LeadsWorkspaceProps["urlState"],
      mode: "demo",
    })).resolves.toBeUndefined();
    expect(container.textContent).toContain("Leads");
    expect(container.textContent).toContain("Ada Brooks");
  });

  it("reports view, bounded search, sort, cursor, and detail changes through URL state", async () => {
    const apiClient = api();
    const onUrlStateChange = vi.fn();
    await renderWorkspace(props(apiClient, onUrlStateChange));

    await act(async () => button("My Leads")?.click());
    expect(onUrlStateChange).toHaveBeenCalledWith(expect.objectContaining({ view: "mine", cursor: undefined }));

    const search = container.querySelector<HTMLInputElement>('input[type="search"]')!;
    expect(search.maxLength).toBe(120);
    await act(async () => {
      search.value = `  ${"a".repeat(140)}  `;
      search.dispatchEvent(new Event("input", { bubbles: true }));
    });
    await act(async () => search.form?.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
    expect(onUrlStateChange).toHaveBeenCalledWith(expect.objectContaining({ search: "a".repeat(120), cursor: undefined }));

    await act(async () => button("Sort by updated")?.click());
    expect(onUrlStateChange).toHaveBeenCalledWith(expect.objectContaining({ sort: "updated_at", direction: "asc" }));

    await act(async () => button("Load more")?.click());
    expect(apiClient.list).toHaveBeenCalledWith(expect.objectContaining({ cursor: "cursor-2", limit: 50 }));
    expect(container.querySelectorAll('[data-builder-leads-list="desktop"] [data-builder-lead-id="lead-1"]')).toHaveLength(1);

    await act(async () => button("Open Avery Stone")?.click());
    expect(onUrlStateChange).toHaveBeenCalledWith(expect.objectContaining({ detailId: "lead-1" }));
  });

  it("maps manual entry to the injected API and announces success", async () => {
    const apiClient = api();
    await renderWorkspace(props(apiClient));

    await act(async () => button("Add lead")?.click());
    expect(container.querySelectorAll("[data-builder-lead-manual-entry]")).toHaveLength(1);

    const values: Record<string, string> = {
      firstName: "Sam",
      lastName: "Taylor",
      phone: "9735550199",
      zipCode: "07102",
      service: "Heating repair",
      urgency: "urgent",
      source: "phone",
      notes: "No heat since this morning.",
      assigneeId: "member-2",
    };
    for (const [name, value] of Object.entries(values)) {
      const field = container.querySelector<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>(`[name="${name}"]`)!;
      await act(async () => {
        field.value = value;
        field.dispatchEvent(new Event("input", { bubbles: true }));
        field.dispatchEvent(new Event("change", { bubbles: true }));
      });
    }
    const form = container.querySelector<HTMLFormElement>("[data-builder-lead-manual-entry]")!;
    await act(async () => form.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));

    expect(apiClient.createManual).toHaveBeenCalledWith(values);
    expect(container.textContent).toContain("Lead created");
  });

  it("bounds selection and announces every applied, denied, or conflict bulk result", async () => {
    const apiClient = api();
    await renderWorkspace(props(apiClient));

    const checks = Array.from(container.querySelectorAll<HTMLInputElement>('input[type="checkbox"][aria-label^="Select "]'));
    await act(async () => {
      checks[0]!.click();
      checks[1]!.click();
    });
    expect(container.querySelector("[data-builder-lead-selection-count]")?.textContent).toContain("2 selected");

    const action = container.querySelector<HTMLSelectElement>('[aria-label="Bulk action"]')!;
    await act(async () => {
      action.value = "status:contacted";
      action.dispatchEvent(new Event("change", { bubbles: true }));
    });
    await act(async () => button("Apply bulk action")?.click());

    expect(apiClient.bulkStatus).toHaveBeenCalledWith({
      records: [
        { leadId: "lead-1", expectedVersion: 2 },
        { leadId: "lead-2", expectedVersion: 4 },
      ],
      status: "contacted",
    });
    expect(container.textContent).toContain("1 applied");
    expect(container.textContent).toContain("1 conflict");
    expect(container.textContent).toContain("lead-2 changed elsewhere");
  });

  it("exports a frozen current filter without changing URL state", async () => {
    const apiClient = api();
    const onUrlStateChange = vi.fn();
    await renderWorkspace({
      ...props(apiClient, onUrlStateChange),
      urlState: {
        view: "new",
        search: "boiler",
        filter: { services: ["Heating repair"] },
        sort: "priority",
        direction: "asc",
        detailId: "lead-1",
      },
    });

    await act(async () => button("Export current view")?.click());

    expect(apiClient.requestExport).toHaveBeenCalledWith({
      view: "new",
      search: "boiler",
      filter: { statuses: ["new"], services: ["Heating repair"] },
      sort: "priority",
      direction: "asc",
    });
    expect(onUrlStateChange).not.toHaveBeenCalled();
    expect(container.textContent).toContain("Export request queued");
  });

  it("creates, updates, and removes user-saved views with versions", async () => {
    const apiClient = api();
    await renderWorkspace(props(apiClient));

    await act(async () => button("Manage saved views")?.click());
    const name = container.querySelector<HTMLInputElement>('[aria-label="Saved view name"]')!;
    await act(async () => {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      setter?.call(name, "Heating follow-up");
      name.dispatchEvent(new Event("input", { bubbles: true }));
    });
    await act(async () => button("Create saved view")?.click());
    expect(apiClient.saveView).toHaveBeenCalledWith(expect.objectContaining({
      name: "Heating follow-up",
      filter: expect.objectContaining({ version: 1, conjunction: "all" }),
    }));

    const saved = container.querySelector<HTMLSelectElement>('[aria-label="Saved view to edit"]')!;
    await act(async () => {
      const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value")?.set;
      setter?.call(saved, "saved-1");
      saved.dispatchEvent(new Event("change", { bubbles: true }));
    });
    await act(async () => button("Update saved view")?.click());
    expect(apiClient.saveView).toHaveBeenLastCalledWith(expect.objectContaining({ viewId: "saved-1", expectedVersion: 3 }));

    await act(async () => button("Remove saved view")?.click());
    expect(apiClient.removeView).toHaveBeenCalledWith({ viewId: "saved-1", expectedVersion: 4 });
  });

  it("rejects saved filters above twenty clauses", () => {
    expect(validateLeadSavedFilterAst({
      version: 1,
      conjunction: "all",
      clauses: Array.from({ length: 21 }, () => ({ field: "status" as const, operator: "equals" as const, value: "new" })),
    })).toEqual({ ok: false, code: "too_many_clauses" });
  });
});
