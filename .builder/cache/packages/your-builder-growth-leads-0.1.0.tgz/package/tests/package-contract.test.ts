import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("growth-leads package boundary", () => {
  it("pins only approved direct dependencies", () => {
    const manifest = JSON.parse(readFileSync(resolve(import.meta.dirname, "../package.json"), "utf8"));
    expect(manifest).toMatchObject({
      name: "@your-builder/growth-leads",
      version: "0.1.0",
      type: "module",
      main: "./src/index.ts",
      types: "./src/index.ts",
      dependencies: {
        "@your-builder/core": "0.1.0",
        "@your-builder/editor": "0.1.0",
        "@your-builder/feature-registry": "0.1.0",
        "@your-builder/growth-core": "0.1.0",
        "@your-builder/growth-customers": "0.1.0",
        "lucide-react": "^0.468.0",
      },
    });
    expect(Object.keys(manifest.dependencies).sort()).toEqual([
      "@your-builder/core",
      "@your-builder/editor",
      "@your-builder/feature-registry",
      "@your-builder/growth-core",
      "@your-builder/growth-customers",
      "lucide-react",
    ]);
  });
});
