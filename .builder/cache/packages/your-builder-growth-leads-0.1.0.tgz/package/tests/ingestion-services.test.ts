import { describe, expect, it, vi } from "vitest";
import type {
  BaseSubmissionReviewRepository,
  LeadIngestionRepository,
  PublicInquiryRepository,
} from "../src/index.js";
import {
  createBaseSubmissionReviewService,
  createLeadIngestionService,
  createPublicInquiryOrchestrator,
  LeadServiceError,
} from "../src/index.js";

const actor = { type: "member" as const, id: "owner-1" };

describe("public inquiry orchestrator", () => {
  it("passes only a normalized inquiry to the authoritative atomic repository", async () => {
    const exact = await runPublicInquiry({ kind: "enhanced", contactId: "contact-1", leadId: "lead-1", match: "exact_email" });

    expect(exact.result).toEqual({ status: "accepted", submissionId: "submission-1", resultId: "result-1", replayed: false });
    expect(exact.repository.ingestAtomic).toHaveBeenCalledWith(expect.objectContaining({
      firstName: "Synthetic",
      lastName: "Customer",
      email: "customer@example.com",
      phone: "+12025550123",
      zipCode: "07105",
      service: "repair",
      message: "Synthetic inquiry",
    }));
    expect(exact.ingestAtomic.mock.calls[0]?.[0]).not.toHaveProperty("identityMatch");
  });

  it("returns the same generic result when the atomic repository requires review", async () => {
    const enhanced = await runPublicInquiry({ kind: "enhanced", contactId: "contact-1", leadId: "lead-1", match: "exact_email" });
    const review = await runPublicInquiry({ kind: "review_required", safeCode: "review_suggested" });

    expect(review.result).toEqual(enhanced.result);
  });

  it("rejects unbounded public fields before calling the atomic repository", async () => {
    const repository: PublicInquiryRepository = {
      ingestAtomic: vi.fn(async () => { throw new Error("not used"); }),
    };
    const service = createPublicInquiryOrchestrator({ repository });
    const valid = publicInquiry();

    for (const command of [
      { ...valid, zipCode: "not-a-zip" },
      { ...valid, service: "s".repeat(161) },
      { ...valid, message: "m".repeat(2_001) },
    ]) {
      await expect(service.ingest(command))
        .rejects.toEqual(expect.objectContaining<Partial<LeadServiceError>>({ code: "invalid_request" }));
    }
    expect(repository.ingestAtomic).not.toHaveBeenCalled();
  });
});

describe("base submission review service", () => {
  it("appends spam and restoration events without rewriting the submission", async () => {
    const repository: BaseSubmissionReviewRepository = {
      get: vi.fn(async () => ({ submissionId: "submission-1", siteId: "site-1", classification: "spam" as const, version: 2 })),
      appendEvent: vi.fn(async (input) => ({ submissionId: input.submissionId, siteId: input.siteId, classification: input.kind === "restored" ? "active" as const : "spam" as const, version: input.expectedVersion + 1 })),
    };
    const service = createBaseSubmissionReviewService({
      repository,
      authorize: vi.fn(async () => ({ canReviewBaseSubmissions: true })),
    });

    await expect(service.restore({ siteId: "site-1", actor, submissionId: "submission-1", expectedVersion: 2, idempotencyKey: "restore-1" }))
      .resolves.toMatchObject({ classification: "active", version: 3 });
    expect(repository.appendEvent).toHaveBeenCalledWith(expect.objectContaining({ kind: "restored" }));
  });

  it("denies restoration unless the current append-only state is spam", async () => {
    const repository: BaseSubmissionReviewRepository = {
      get: vi.fn(async () => ({ submissionId: "submission-1", siteId: "site-1", classification: "active" as const, version: 1 })),
      appendEvent: vi.fn(async () => { throw new Error("not used"); }),
    };
    const service = createBaseSubmissionReviewService({ repository, authorize: vi.fn(async () => ({ canReviewBaseSubmissions: true })) });

    await expect(service.restore({ siteId: "site-1", actor, submissionId: "submission-1", expectedVersion: 1, idempotencyKey: "restore-1" }))
      .rejects.toEqual(expect.objectContaining<Partial<LeadServiceError>>({ code: "invalid_state" }));
  });

  it("requires a stable reason code before appending a spam classification", async () => {
    const repository: BaseSubmissionReviewRepository = {
      get: vi.fn(async () => ({ submissionId: "submission-1", siteId: "site-1", classification: "active" as const, version: 1 })),
      appendEvent: vi.fn(async () => { throw new Error("not used"); }),
    };
    const service = createBaseSubmissionReviewService({ repository, authorize: vi.fn(async () => ({ canReviewBaseSubmissions: true })) });

    await expect(service.classifySpam({ siteId: "site-1", actor, submissionId: "submission-1", expectedVersion: 1, idempotencyKey: "spam-1" }))
      .rejects.toEqual(expect.objectContaining<Partial<LeadServiceError>>({ code: "invalid_request" }));
    expect(repository.appendEvent).not.toHaveBeenCalled();
  });
});

describe("reviewed base-submission import", () => {
  it("requires owner authority, recent AAL2, and current enhanced writes before repository import", async () => {
    const repository: LeadIngestionRepository = {
      storeAcceptedInquiry: vi.fn(async (input) => ({ ...input, baseRecordsCreated: true as const, outcome: input.decision.kind, safeCode: "enhanced" as const })),
      importReviewedBaseSubmission: vi.fn(async (input) => ({ status: "imported" as const, submissionId: input.submissionId, resultVersion: 2, safeCode: "enhanced" as const })),
    };
    const command = { siteId: "site-1", actor, submissionId: "submission-1", expectedLatestResultVersion: 1, aal2VerifiedAt: "2026-07-18T00:55:00.000Z", idempotencyKey: "import-1" };
    const denied = createLeadIngestionService({
      repository,
      authorizeImport: vi.fn(async () => ({ isOwner: false, recentAal2: true, enhancedWritesAllowed: true })),
    });
    const allowed = createLeadIngestionService({
      repository,
      authorizeImport: vi.fn(async () => ({ isOwner: true, recentAal2: true, enhancedWritesAllowed: true })),
    });

    await expect(denied.importReviewedBaseSubmission(command)).resolves.toEqual({
      status: "denied",
      submissionId: "submission-1",
      safeCode: "not_authorized",
    });
    await expect(allowed.importReviewedBaseSubmission(command)).resolves.toMatchObject({ status: "imported", resultVersion: 2 });
    expect(repository.importReviewedBaseSubmission).toHaveBeenCalledTimes(1);
  });
});

async function runPublicInquiry(decision: Parameters<typeof createStoredResult>[0]) {
  const ingestAtomic = vi.fn(async (_input: Parameters<PublicInquiryRepository["ingestAtomic"]>[0]) => createStoredResult(decision));
  const repository: PublicInquiryRepository = {
    ingestAtomic,
  };
  const service = createPublicInquiryOrchestrator({ repository });
  const result = await service.ingest(publicInquiry());
  return { result, repository, ingestAtomic };
}

function publicInquiry() {
  return {
    siteId: "site-1",
    submissionId: "submission-1",
    resultId: "result-1",
    idempotencyKey: "inquiry-1",
    firstName: " Synthetic ",
    lastName: " Customer ",
    email: " Customer@Example.com ",
    phone: "(202) 555-0123",
    zipCode: "07105",
    service: " repair ",
    message: " Synthetic inquiry ",
  };
}

function createStoredResult(decision: import("../src/index.js").IngestionDecision) {
  return {
    submissionId: "submission-1",
    resultId: "result-1",
    resultVersion: 1,
    replayed: false,
    decision,
  };
}
