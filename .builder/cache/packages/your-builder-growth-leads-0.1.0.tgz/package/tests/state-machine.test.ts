import { describe, expect, it } from "vitest";
import {
  LEAD_STATUSES,
  deriveLeadDisplayLane,
  transitionLead,
  type Lead,
} from "../src/index.js";

const lead = (overrides: Partial<Lead> = {}): Lead => ({
  id: "lead-1",
  siteId: "site-1",
  contactId: "customer-1",
  source: "website_form",
  service: "repair",
  urgency: "standard",
  status: "new",
  summary: "No heat",
  version: 2,
  createdAt: "2026-07-18T12:00:00.000Z",
  updatedAt: "2026-07-18T12:00:00.000Z",
  ...overrides,
});

describe("lead state machine", () => {
  it("freezes the canonical statuses", () => {
    expect(LEAD_STATUSES).toEqual(["new", "contacted", "qualified", "won", "lost", "spam"]);
    expect(LEAD_STATUSES).not.toContain("estimate_scheduled");
  });

  it("accepts reviewed workflow transitions with compare-and-swap versioning", () => {
    expect(transitionLead(lead(), { to: "contacted", expectedVersion: 2, occurredAt: "2026-07-18T12:10:00.000Z" })).toMatchObject({
      status: "applied",
      lead: { status: "contacted", version: 3 },
      event: { kind: "status_changed", from: "new", to: "contacted" },
    });
  });

  it("rejects denied and stale transitions", () => {
    expect(transitionLead(lead(), { to: "won", expectedVersion: 1, occurredAt: "2026-07-18T12:10:00.000Z" })).toMatchObject({
      status: "conflict",
      reason: "version_conflict",
    });
    expect(transitionLead(lead(), { to: "won", expectedVersion: 2, occurredAt: "2026-07-18T12:10:00.000Z" })).toEqual({
      status: "denied",
      reason: "invalid_transition",
      from: "new",
      to: "won",
    });
  });

  it("requires correction intent to leave terminal outcomes", () => {
    const terminal = lead({ status: "won" });
    expect(transitionLead(terminal, { to: "qualified", expectedVersion: 2, occurredAt: "2026-07-18T12:10:00.000Z" })).toMatchObject({ status: "denied" });
    expect(transitionLead(terminal, { to: "qualified", expectedVersion: 2, correction: true, occurredAt: "2026-07-18T12:10:00.000Z" })).toMatchObject({
      status: "applied",
      event: { kind: "correction" },
    });
  });

  it("supports spam classification and restore without inventing a pipeline status", () => {
    expect(transitionLead(lead({ status: "contacted" }), { to: "spam", expectedVersion: 2, occurredAt: "2026-07-18T12:10:00.000Z" })).toMatchObject({ status: "applied" });
    expect(transitionLead(lead({ status: "spam" }), { to: "contacted", expectedVersion: 2, restore: true, occurredAt: "2026-07-18T12:10:00.000Z" })).toMatchObject({ status: "applied" });
  });

  it("derives Estimate Scheduled only from a live estimate appointment", () => {
    expect(deriveLeadDisplayLane(lead({ status: "qualified" }), [{ kind: "appointment.scheduled", purpose: "estimate", live: true }])).toBe("estimate_scheduled");
    expect(deriveLeadDisplayLane(lead({ status: "qualified" }), [{ kind: "appointment.cancelled", purpose: "estimate", live: false }])).toBe("qualified");
  });
});
