import { describe, expect, expectTypeOf, it } from "vitest";
import {
  createStoredIngestionResult,
  type ImportBaseSubmissionCommand,
  type StoredIngestionResult,
} from "../src/index.js";

describe("lead ingestion contracts", () => {
  it.each([
    [{ kind: "enhanced", contactId: "c1", leadId: "l1" }, "enhanced"],
    [{ kind: "base_only", safeCode: "enhancement_unavailable" }, "base_only"],
    [{ kind: "review_required", safeCode: "identity_conflict" }, "review_required"],
  ] as const)("always records accepted inquiry base records for %s", (decision, expected) => {
    const stored = createStoredIngestionResult({
      submissionId: "submission-1",
      resultId: "result-1",
      resultVersion: 1,
      replayed: false,
      decision,
    });
    expect(stored.baseRecordsCreated).toBe(true);
    expect(stored.outcome).toBe(expected);
  });

  it("represents exact matches, conflicts, fuzzy review, and replay without disclosure", () => {
    const stored: StoredIngestionResult = createStoredIngestionResult({
      submissionId: "submission-1",
      resultId: "result-1",
      resultVersion: 2,
      priorResultId: "result-0",
      replayed: true,
      decision: { kind: "review_required", safeCode: "review_suggested" },
    });
    expect(stored.replayed).toBe(true);
    expect(stored).not.toHaveProperty("turnstileToken");
    expect(stored).not.toHaveProperty("ipAddress");
    expect(stored).not.toHaveProperty("contactExists");
  });

  it("requires owner review context for reactivation import", () => {
    expectTypeOf<ImportBaseSubmissionCommand>().toMatchTypeOf<{
      siteId: string;
      actor: { type: "member"; id: string };
      submissionId: string;
      expectedLatestResultVersion: number;
      aal2VerifiedAt: string;
      idempotencyKey: string;
    }>();
  });
});
