import { describe, expect, it, vi } from "vitest";
import type {
  IdentityMatchingService,
  IdentityMatchResult,
} from "@your-builder/growth-core";
import type {
  Lead,
  LeadCommandAuthorization,
  LeadCommandRepository,
  LeadQueryRepository,
} from "../src/index.js";
import {
  createLeadCommandService,
  createLeadQueryService,
  LeadServiceError,
} from "../src/index.js";

const actor = { type: "member" as const, id: "staff-1" };
const lead = (overrides: Partial<Lead> = {}): Lead => ({
  id: "lead-1",
  siteId: "site-1",
  contactId: "contact-1",
  source: "staff_entry",
  service: "repair",
  urgency: "standard",
  status: "new",
  summary: "Manual inquiry",
  primaryAssigneeId: actor.id,
  version: 1,
  createdAt: "2026-07-18T00:00:00.000Z",
  updatedAt: "2026-07-18T00:00:00.000Z",
  ...overrides,
});

const manualCommand = {
  siteId: "site-1",
  actor,
  idempotencyKey: "manual-1",
  source: "staff_entry" as const,
  firstName: "Synthetic",
  lastName: "Customer",
  email: "customer@example.com",
  zipCode: "07105",
  service: "repair",
  urgency: "standard" as const,
};

describe("lead command service", () => {
  it("self-assigns an assigned-scope creator and sends atomic event intents", async () => {
    const dependencies = createDependencies({ scope: "assigned", canAssignOthers: false });
    const service = createLeadCommandService(dependencies);

    await expect(service.createManual(manualCommand)).resolves.toEqual(lead());

    expect(dependencies.repository.createManualAtomic).toHaveBeenCalledWith(expect.objectContaining({
      command: manualCommand,
      assigneeId: "staff-1",
      identityMatchHint: { kind: "new_identity" },
      event: expect.objectContaining({ kind: "created" }),
      outbox: expect.objectContaining({ topic: "growth.lead.created", correlationId: "manual-1" }),
      notification: expect.objectContaining({ eventType: "lead.assigned", recipientMemberId: "staff-1" }),
    }));
  });

  it("denies assignment to another member without site-wide assignment authority", async () => {
    const dependencies = createDependencies({ scope: "assigned", canAssignOthers: false });

    await expect(createLeadCommandService(dependencies).createManual({ ...manualCommand, assigneeId: "staff-2" }))
      .rejects.toEqual(expect.objectContaining<Partial<LeadServiceError>>({ code: "not_authorized" }));
    expect(dependencies.repository.createManualAtomic).not.toHaveBeenCalled();
  });

  it("passes review evidence only as an advisory hint and returns the atomic repository result", async () => {
    const dependencies = createDependencies({ scope: "site", canAssignOthers: true }, {
      kind: "review_suggested",
      evidence: ["name", "zip"],
    });
    vi.mocked(dependencies.repository.createManualAtomic).mockResolvedValue(lead({ contactId: "transaction-contact" }));
    const service = createLeadCommandService(dependencies);

    await expect(service.createManual(manualCommand)).resolves.toMatchObject({ contactId: "transaction-contact" });
    expect(dependencies.repository.createManualAtomic).toHaveBeenCalledWith(expect.objectContaining({
      identityMatchHint: { kind: "review_suggested", evidence: ["name", "zip"] },
    }));
  });

  it("validates runtime source and bounded manual fields before authorization", async () => {
    const dependencies = createDependencies({ scope: "site", canAssignOthers: true });
    const service = createLeadCommandService(dependencies);

    for (const command of [
      { ...manualCommand, source: "website_form" as never },
      { ...manualCommand, zipCode: "not-a-zip" },
      { ...manualCommand, service: "s".repeat(161) },
      { ...manualCommand, urgency: "critical" as never },
      { ...manualCommand, notes: "n".repeat(2_001) },
    ]) {
      await expect(service.createManual(command))
        .rejects.toEqual(expect.objectContaining<Partial<LeadServiceError>>({ code: expect.stringMatching(/^invalid_/) }));
    }
    await expect(service.addNote({
      siteId: "site-1", actor, idempotencyKey: "note-long", expectedVersion: 1, leadId: "lead-1", body: "n".repeat(2_001),
    })).rejects.toEqual(expect.objectContaining<Partial<LeadServiceError>>({ code: "invalid_request" }));
    expect(dependencies.authorize).not.toHaveBeenCalled();
    expect(dependencies.repository.createManualAtomic).not.toHaveBeenCalled();
  });

  it("rejects non-member actors before authorization for member-only lead commands", async () => {
    const dependencies = createDependencies({ scope: "site", canAssignOthers: true });
    const service = createLeadCommandService(dependencies);
    const visitor = { type: "visitor" as const, id: "visitor-1" };
    const versioned = { siteId: "site-1", actor: visitor, idempotencyKey: "forged", expectedVersion: 1, leadId: "lead-1" };

    const commands = [
      () => service.createManual({ ...manualCommand, actor: visitor as never }),
      () => service.assign({ ...versioned, assigneeId: "staff-2" }),
      () => service.addNote({ ...versioned, body: "note" }),
      () => service.changeStatus({ ...versioned, to: "contacted" }),
      () => service.setPriority({ ...versioned, priority: "high" }),
      () => service.createTask({
        siteId: "site-1", actor: visitor, idempotencyKey: "task-forged", relatedType: "lead", relatedId: "lead-1", leadId: "lead-1",
        title: "Call", authorizationParents: [{ type: "lead", id: "lead-1" }], selfAssignmentIntent: true,
      }),
      () => service.recordServiceEvent({
        siteId: "site-1", contactId: "contact-1", leadId: "lead-1", kind: "appointment.scheduled",
        origin: { type: "manual", actor: { type: "system" } }, occurredAt: "2026-07-18T01:00:00.000Z",
        correlationId: "service-forged", idempotencyKey: "service-forged",
      }),
      () => service.bulkStatus({ siteId: "site-1", actor: visitor as never, idempotencyKey: "bulk-forged", records: [], to: "contacted" }),
    ];

    for (const command of commands) {
      await expect(command()).rejects.toEqual(expect.objectContaining<Partial<LeadServiceError>>({ code: "not_authorized" }));
    }
    expect(dependencies.authorize).not.toHaveBeenCalled();
  });

  it("validates runtime sources independently of advisory identity matching", async () => {
    const dependencies = createDependencies({ scope: "site", canAssignOthers: true });
    const service = createLeadCommandService(dependencies);

    await expect(service.createManual({ ...manualCommand, source: "website_form" as never }))
      .rejects.toEqual(expect.objectContaining<Partial<LeadServiceError>>({ code: "invalid_source" }));
    expect(dependencies.repository.createManualAtomic).not.toHaveBeenCalled();
  });

  it("validates versioned status changes before the atomic repository command", async () => {
    const dependencies = createDependencies({ scope: "assigned", canAssignOthers: false });
    const service = createLeadCommandService(dependencies);
    const command = {
      siteId: "site-1",
      actor,
      idempotencyKey: "status-1",
      expectedVersion: 1,
      leadId: "lead-1",
      to: "contacted" as const,
    };

    await expect(service.changeStatus(command)).resolves.toMatchObject({ status: "applied", value: { status: "contacted", version: 2 } });
    expect(dependencies.repository.changeStatusAtomic).toHaveBeenCalledWith(expect.objectContaining({
      command,
      nextLead: expect.objectContaining({ status: "contacted", version: 2 }),
      event: expect.objectContaining({ from: "new", to: "contacted" }),
    }));

    await expect(service.changeStatus({ ...command, expectedVersion: 0 })).resolves.toEqual({
      status: "conflict",
      reason: "version_conflict",
      resourceType: "lead",
      resourceId: "lead-1",
      expectedVersion: 0,
      actualVersion: 1,
    });
  });

  it("carries assignment, note, priority, task, and service-event timeline intents into atomic commands", async () => {
    const dependencies = createDependencies({ scope: "site", canAssignOthers: true });
    const service = createLeadCommandService(dependencies);
    const versioned = { siteId: "site-1", actor, expectedVersion: 1, leadId: "lead-1" };

    await service.assign({ ...versioned, idempotencyKey: "assign-1", assigneeId: "staff-2" });
    await service.addNote({ ...versioned, idempotencyKey: "note-1", body: "Follow-up requested" });
    await service.setPriority({ ...versioned, idempotencyKey: "priority-1", priority: "high" });
    await service.createTask({
      siteId: "site-1", actor, idempotencyKey: "task-1", relatedType: "lead", relatedId: "lead-1", leadId: "lead-1",
      title: "Call customer", authorizationParents: [{ type: "lead", id: "lead-1" }], selfAssignmentIntent: true,
    });
    await service.recordServiceEvent({
      siteId: "site-1", contactId: "contact-1", leadId: "lead-1", kind: "appointment.scheduled", purpose: "estimate",
      scheduledAt: "2026-07-19T14:00:00.000Z", origin: { type: "manual", actor }, occurredAt: "2026-07-18T01:00:00.000Z",
      correlationId: "service-1", idempotencyKey: "service-1",
    });

    expect(dependencies.repository.assignAtomic).toHaveBeenCalledWith(expect.objectContaining({ command: expect.objectContaining({ expectedVersion: 1 }), event: expect.objectContaining({ kind: "assignment" }), notification: expect.objectContaining({ recipientMemberId: "staff-2" }) }));
    expect(dependencies.repository.addNoteAtomic).toHaveBeenCalledWith(expect.objectContaining({ command: expect.objectContaining({ body: "Follow-up requested" }), event: expect.objectContaining({ kind: "note" }) }));
    expect(dependencies.repository.setPriorityAtomic).toHaveBeenCalledWith(expect.objectContaining({ command: expect.objectContaining({ priority: "high" }), event: expect.objectContaining({ kind: "correction" }) }));
    expect(dependencies.repository.createTaskAtomic).toHaveBeenCalledWith(expect.objectContaining({ command: expect.objectContaining({ title: "Call customer" }), event: expect.objectContaining({ kind: "task" }) }));
    expect(dependencies.repository.recordServiceEventAtomic).toHaveBeenCalledWith(expect.objectContaining({ command: expect.objectContaining({ purpose: "estimate" }), event: expect.objectContaining({ kind: "service_event" }) }));
  });

  it("aggregates bounded bulk outcomes without failing the remaining records", async () => {
    const dependencies = createDependencies({ scope: "assigned", canAssignOthers: false });
    const bulkStatusRecord = vi.fn(async ({ record }: { record: { leadId: string; expectedVersion: number } }) => {
      if (record.leadId === "lead-1") return { leadId: record.leadId, status: "applied" as const, version: 3 };
      if (record.leadId === "lead-2") return {
        leadId: record.leadId,
        status: "conflict" as const,
        expectedVersion: record.expectedVersion,
        actualVersion: 4,
      };
      throw new LeadServiceError("not_authorized");
    });
    Object.assign(dependencies.repository, { bulkStatusRecord });
    const service = createLeadCommandService(dependencies);
    const command = {
      siteId: "site-1",
      actor,
      idempotencyKey: "bulk-status-1",
      records: [
        { leadId: "lead-1", expectedVersion: 2 },
        { leadId: "lead-2", expectedVersion: 3 },
        { leadId: "lead-3", expectedVersion: 1 },
      ],
      to: "contacted" as const,
    };

    await expect(service.bulkStatus(command)).resolves.toEqual({
      requestedCount: 3,
      results: [
        { leadId: "lead-1", status: "applied", version: 3 },
        { leadId: "lead-2", status: "conflict", expectedVersion: 3, actualVersion: 4 },
        { leadId: "lead-3", status: "denied", reason: "not_authorized" },
      ],
    });
    expect(bulkStatusRecord).toHaveBeenNthCalledWith(1, { command, record: command.records[0], scope: "assigned" });
    expect(bulkStatusRecord).toHaveBeenCalledTimes(3);
  });

  it("rejects oversized bulk commands before authorization or repository access", async () => {
    const dependencies = createDependencies({ scope: "site", canAssignOthers: true });
    const bulkStatusRecord = vi.fn();
    Object.assign(dependencies.repository, { bulkStatusRecord });

    await expect(createLeadCommandService(dependencies).bulkStatus({
      siteId: "site-1",
      actor,
      idempotencyKey: "bulk-too-large",
      records: Array.from({ length: 101 }, (_, index) => ({ leadId: `lead-${index}`, expectedVersion: 1 })),
      to: "contacted",
    })).rejects.toEqual(expect.objectContaining<Partial<LeadServiceError>>({ code: "invalid_request" }));
    expect(dependencies.authorize).not.toHaveBeenCalled();
    expect(bulkStatusRecord).not.toHaveBeenCalled();
  });

  it("projects manual repository results to the public lead contract", async () => {
    const dependencies = createDependencies({ scope: "site", canAssignOthers: true });
    vi.mocked(dependencies.repository.createManualAtomic).mockResolvedValue({
      ...lead(),
      transactionMetadata: { internalContactMatch: "exact" },
    } as Lead);

    await expect(createLeadCommandService(dependencies).createManual(manualCommand)).resolves.toEqual(lead());
  });
});

describe("lead query service", () => {
  it("requires bounded pagination and rejects cross-site detail projections", async () => {
    const repository: LeadQueryRepository = {
      list: vi.fn(async () => ({ items: [] })),
      get: vi.fn(async () => ({ ...lead(), siteId: "site-2", timeline: [] })),
    };
    const service = createLeadQueryService(repository);

    await service.list({ siteId: "site-1", actor, scope: "assigned", limit: 100 });
    await expect(service.list({ siteId: "site-1", actor, scope: "site", limit: 0 }))
      .rejects.toEqual(expect.objectContaining<Partial<LeadServiceError>>({ code: "invalid_query" }));
    await expect(service.get({ siteId: "site-1", actor, scope: "site", leadId: "lead-1" })).resolves.toBeNull();
  });

  it("strips persistence and transport metadata from list, detail, and timeline projections", async () => {
    const rawItem = {
      id: "lead-1", customerId: "customer-1", customerDisplayName: "Synthetic Customer", service: "repair",
      urgency: "standard" as const, status: "new" as const, displayLane: "new" as const, createdAt: lead().createdAt,
      updatedAt: lead().updatedAt, version: 1, databaseRank: 7,
    };
    const rawDetail = {
      ...lead(),
      timeline: [{
        id: "event-1", siteId: "site-1", leadId: "lead-1", kind: "created" as const,
        occurredAt: lead().createdAt, transportOffset: 99,
      }],
      rawRow: { internal: true },
    };
    const repository: LeadQueryRepository = {
      list: vi.fn(async () => ({ items: [rawItem], nextCursor: "opaque", queryPlan: "private" })),
      get: vi.fn(async () => rawDetail),
    };
    const service = createLeadQueryService(repository);

    await expect(service.list({ siteId: "site-1", actor, scope: "assigned", limit: 25 })).resolves.toEqual({
      items: [{
        id: "lead-1", customerId: "customer-1", customerDisplayName: "Synthetic Customer", service: "repair",
        urgency: "standard", status: "new", displayLane: "new", createdAt: lead().createdAt,
        updatedAt: lead().updatedAt, version: 1,
      }],
      nextCursor: "opaque",
    });
    await expect(service.get({ siteId: "site-1", actor, scope: "site", leadId: "lead-1" })).resolves.toEqual({
      ...lead(),
      timeline: [{ id: "event-1", siteId: "site-1", leadId: "lead-1", kind: "created", occurredAt: lead().createdAt }],
    });
  });
});

function createDependencies(
  authorization: Pick<LeadCommandAuthorization, "scope" | "canAssignOthers">,
  match: IdentityMatchResult = { kind: "new_identity" },
) {
  const identityMatching: IdentityMatchingService = { match: vi.fn(async () => match) };
  const repository: LeadCommandRepository = {
    createManualAtomic: vi.fn(async () => lead()),
    get: vi.fn(async () => lead()),
    assignAtomic: vi.fn(async () => ({ status: "applied" as const, value: lead() })),
    addNoteAtomic: vi.fn(async () => ({ status: "applied" as const, value: lead({ version: 2 }) })),
    changeStatusAtomic: vi.fn(async (input) => ({ status: "applied" as const, value: input.nextLead })),
    setPriorityAtomic: vi.fn(async () => ({ status: "applied" as const, value: lead({ priority: "high", version: 2 }) })),
    createTaskAtomic: vi.fn(async () => "task-1"),
    recordServiceEventAtomic: vi.fn(async () => "service-event-1"),
    bulkStatusRecord: vi.fn(async ({ record }) => ({ leadId: record.leadId, status: "applied" as const, version: record.expectedVersion + 1 })),
    bulkAssignRecord: vi.fn(async ({ record }) => ({ leadId: record.leadId, status: "applied" as const, version: record.expectedVersion + 1 })),
    bulkTagRecord: vi.fn(async ({ record }) => ({ leadId: record.leadId, status: "applied" as const, version: record.expectedVersion + 1 })),
  };
  return {
    identityMatching,
    repository,
    authorize: vi.fn(async () => ({ ...authorization, canCreate: true, canUpdate: true })),
    isActiveSiteMember: vi.fn(async () => true),
    now: () => "2026-07-18T01:00:00.000Z",
  };
}
