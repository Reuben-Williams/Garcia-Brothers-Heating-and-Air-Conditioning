import { describe, expect, expectTypeOf, it } from "vitest";
import type {
  AddLeadNoteCommand,
  AssignLeadCommand,
  BulkLeadCommandResult,
  CreateManualLeadCommand,
  LeadCommandService,
  LeadListFilter,
  LeadQueryService,
  ListLeadsQuery,
} from "../src/index.js";
import { MANUAL_LEAD_SOURCES } from "../src/index.js";

describe("Leads public contracts", () => {
  it("freezes manual sources", () => {
    expect(MANUAL_LEAD_SOURCES).toEqual(["phone", "walk_in", "staff_entry"]);
  });

  it("defines versioned manual, assignment, and note commands", () => {
    expectTypeOf<CreateManualLeadCommand>().toMatchTypeOf<{
      source: "phone" | "walk_in" | "staff_entry";
      siteId: string;
      idempotencyKey: string;
      zipCode: string;
    }>();
    expectTypeOf<AssignLeadCommand>().toMatchTypeOf<{ leadId: string; assigneeId: string; expectedVersion: number }>();
    expectTypeOf<AddLeadNoteCommand>().toMatchTypeOf<{ leadId: string; body: string; expectedVersion: number }>();
  });

  it("defines bounded per-record bulk outcomes", () => {
    const result: BulkLeadCommandResult = {
      requestedCount: 3,
      results: [
        { leadId: "l1", status: "applied", version: 2 },
        { leadId: "l2", status: "denied", reason: "not_authorized" },
        { leadId: "l3", status: "conflict", expectedVersion: 1, actualVersion: 2 },
      ],
    };
    expect(result.results).toHaveLength(result.requestedCount);
  });

  it("defines cursor pagination and operational filters", () => {
    expectTypeOf<LeadListFilter>().toMatchTypeOf<{
      statuses?: readonly ("new" | "contacted" | "qualified" | "won" | "lost" | "spam")[];
      services?: readonly string[];
      assigneeIds?: readonly string[];
      sources?: readonly string[];
      priorities?: readonly string[];
    }>();
    expectTypeOf<ListLeadsQuery>().toMatchTypeOf<{ siteId: string; limit: number; cursor?: string }>();
    expectTypeOf<LeadQueryService>().toBeObject();
    expectTypeOf<LeadCommandService>().toBeObject();
  });
});
