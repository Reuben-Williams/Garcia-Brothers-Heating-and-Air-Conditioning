"use client";

import React, {
  createContext,
  useContext,
  useEffect,
  type CSSProperties,
  type HTMLAttributes,
  type ElementType,
  type ReactNode,
} from "react";
import { createBuilderPreviewMessage } from "@your-builder/core";
import type {
  BuilderContentAdapter,
  BuilderSiteConfig,
  EditableKind,
  EditableValue,
  MediaAsset,
  PageContent,
  PublishInput,
  RollbackInput,
  SaveDraftInput,
  UndoRollbackInput,
} from "@your-builder/core";

type BuilderMode = "public" | "editor";

interface BuilderContextValue {
  siteId: string;
  mode: BuilderMode;
  content: PageContent;
}

const BuilderContext = createContext<BuilderContextValue | null>(null);

export interface BuilderProviderProps {
  siteId: string;
  mode?: BuilderMode;
  content?: PageContent;
  children: ReactNode;
}

export function BuilderProvider({ siteId, mode = "public", content, children }: BuilderProviderProps) {
  return (
    <BuilderContext.Provider value={{ siteId, mode, content: content ?? { path: "/", regions: {} } }}>
      {children}
    </BuilderContext.Provider>
  );
}

function useBuilderRegion(id: string, kind: EditableValue["type"]) {
  const context = useContext(BuilderContext);
  const value = context?.content.regions[id];
  const editorProps =
    context?.mode === "editor"
      ? {
          "data-builder-region": id,
          "data-builder-kind": kind,
          style: {
            outline: "2px dashed rgba(37, 99, 235, 0.6)",
            outlineOffset: "3px",
            cursor: "pointer",
          } satisfies CSSProperties,
        }
      : {};

  return { value, editorProps };
}

export interface EditableTextProps {
  id: string;
  fallback: string;
  as?: ElementType;
  className?: string;
}

export function EditableText({ id, fallback, as = "span", className }: EditableTextProps) {
  const { value, editorProps } = useBuilderRegion(id, "text");
  const Component = as;
  const text = value?.type === "text" || value?.type === "richText" ? value.value : fallback;

  return (
    <Component className={className} {...editorProps}>
      {text}
    </Component>
  );
}

export interface EditableRichTextProps {
  id: string;
  fallbackHtml: string;
  className?: string;
}

export function EditableRichText({ id, fallbackHtml, className }: EditableRichTextProps) {
  const { value, editorProps } = useBuilderRegion(id, "richText");
  const html = value?.type === "richText" ? value.value : fallbackHtml;

  return <div className={className} dangerouslySetInnerHTML={{ __html: html }} {...editorProps} />;
}

export interface EditableImageProps {
  id: string;
  fallback: string;
  alt: string;
  className?: string;
}

export function EditableImage({ id, fallback, alt, className }: EditableImageProps) {
  const { value, editorProps } = useBuilderRegion(id, "image");
  const src = value?.type === "image" ? value.src : fallback;
  const imageAlt = value?.type === "image" ? value.alt ?? alt : alt;

  return <img src={src} alt={imageAlt} className={className} {...editorProps} />;
}

export interface EditableIconProps {
  id: string;
  fallback: string;
  label?: string;
  className?: string;
}

export function EditableIcon({ id, fallback, label, className }: EditableIconProps) {
  const { value, editorProps } = useBuilderRegion(id, "icon");
  const icon = value?.type === "icon" ? value.icon : fallback;
  const iconLabel = value?.type === "icon" ? value.label ?? label : label;
  const ariaLabel = iconLabel ?? icon.replace(/_/g, " ");
  const classes = ["material-symbols-outlined", className].filter(Boolean).join(" ");

  return (
    <span className={classes} aria-label={ariaLabel} {...editorProps}>
      {icon}
    </span>
  );
}

export interface EditableNextImageRenderInput {
  src: string;
  alt: string;
  editorProps: HTMLAttributes<HTMLElement>;
  value?: Extract<EditableValue, { type: "image" }>;
}

export interface EditableNextImageProps {
  id: string;
  fallback: string;
  alt: string;
  children: (image: EditableNextImageRenderInput) => ReactNode;
}

export function EditableNextImage({ id, fallback, alt, children }: EditableNextImageProps) {
  const { value, editorProps } = useBuilderRegion(id, "image");
  const imageValue = value?.type === "image" ? value : undefined;

  return (
    <>
      {children({
        src: imageValue?.src ?? fallback,
        alt: imageValue?.alt ?? alt,
        value: imageValue,
        editorProps,
      })}
    </>
  );
}

export interface EditableLinkProps {
  id: string;
  fallbackHref: string;
  fallbackLabel: string;
  className?: string;
}

export function EditableLink({ id, fallbackHref, fallbackLabel, className }: EditableLinkProps) {
  const { value, editorProps } = useBuilderRegion(id, "link");
  const href = value?.type === "link" ? value.href : fallbackHref;
  const label = value?.type === "link" ? value.label : fallbackLabel;

  return (
    <a href={href} className={className} {...editorProps}>
      {label}
    </a>
  );
}

export interface EditableSectionListProps {
  id: string;
  allowed: string[];
  fallback: string[];
  renderSection: (sectionId: string) => ReactNode;
  className?: string;
}

export function EditableSectionList({ id, allowed, fallback, renderSection, className }: EditableSectionListProps) {
  const { value, editorProps } = useBuilderRegion(id, "sections");
  const sectionIds = value?.type === "sections" ? value.value.filter((section) => allowed.includes(section)) : fallback;

  return (
    <div className={className} {...editorProps}>
      {sectionIds.map((sectionId) => (
        <React.Fragment key={sectionId}>{renderSection(sectionId)}</React.Fragment>
      ))}
    </div>
  );
}

export interface BuilderPreviewBridgeProps {
  siteId?: string;
  parentOrigin?: string;
}

function safeContentUrl(value: string) {
  const normalized = value.trim();
  return /^(?:\/|#|https:\/\/|mailto:|tel:|data:image\/)/i.test(normalized) ? normalized : "";
}

export function applyPageContentToDocument(
  root: Pick<Document, "querySelectorAll">,
  content: PageContent,
) {
  const elements = root.querySelectorAll<HTMLElement>("[data-builder-region]");
  for (const element of elements) {
    const regionId = element.dataset.builderRegion;
    const value = regionId ? content.regions[regionId] : undefined;
    if (!value) continue;
    if (value.type === "image") {
      const images = element instanceof HTMLImageElement ? [element] : Array.from(element.querySelectorAll("img"));
      const source = safeContentUrl(value.src);
      if (source) {
        for (const image of images) image.src = source;
        const accessibleImage = images.find((image) => image.getAttribute("aria-hidden") !== "true");
        if (accessibleImage) accessibleImage.alt = value.alt ?? "";
      }
    } else if (value.type === "link") {
      const link = element instanceof HTMLAnchorElement ? element : element.querySelector("a[href]");
      const href = safeContentUrl(value.href);
      if (link && href) {
        link.textContent = value.label;
        link.setAttribute("href", href);
      }
    } else if (value.type === "icon") {
      element.textContent = value.icon;
    } else if (value.type === "text" || value.type === "richText") {
      element.textContent = value.value;
    }
  }
}

export function BuilderDomContentBridge({
  mode,
  apiBaseUrl = "/api/builder",
}: {
  mode: "draft" | "published";
  apiBaseUrl?: string;
}) {
  useEffect(() => {
    const controller = new AbortController();
    const query = new URLSearchParams({ path: window.location.pathname, mode });
    void fetch(`${apiBaseUrl}?${query}`, {
      credentials: "same-origin",
      cache: "no-store",
      signal: controller.signal,
      headers: { accept: "application/json" },
    }).then(async (response) => {
      if (!response.ok) return;
      applyPageContentToDocument(document, await response.json() as PageContent);
    }).catch(() => undefined);
    return () => controller.abort();
  }, [apiBaseUrl, mode]);
  return <span data-builder-dom-content-bridge data-builder-content-mode={mode} hidden />;
}

function readRegionSelection(element: HTMLElement, kind: EditableKind) {
  const image = element instanceof HTMLImageElement
    ? element
    : element.querySelector<HTMLImageElement>('img:not([aria-hidden="true"])') ?? element.querySelector("img");
  const link = element instanceof HTMLAnchorElement ? element : element.querySelector("a[href]");
  if (kind === "image" && image) return { value: image.currentSrc || image.src, alt: image.alt };
  if (kind === "link" && link) return { value: link.textContent?.trim() ?? "", href: link.getAttribute("href") ?? "" };
  if (kind === "richText") return { value: element.textContent?.trim() ?? "" };
  return { value: element.textContent?.trim() ?? "" };
}

export function BuilderPreviewBridge({ siteId, parentOrigin }: BuilderPreviewBridgeProps = {}) {
  useEffect(() => {
    const params = new URL(window.location.href).searchParams;
    const resolvedSiteId = siteId ?? params.get("builderSiteId") ?? "";
    const targetOrigin = parentOrigin ?? window.location.origin;
    if (!resolvedSiteId || params.get("builderPreview") !== "1") return;

    window.parent.postMessage(
      createBuilderPreviewMessage(resolvedSiteId, {
        type: "builder:ready",
        pagePath: window.location.pathname,
      }),
      targetOrigin,
    );

    function handleClick(event: MouseEvent) {
      const target = event.target instanceof Element ? event.target : null;
      if (!target) return;

      const postEntry = target.closest<HTMLElement>("[data-builder-entry-id]");
      if (postEntry?.dataset.builderEntryId) {
        event.preventDefault();
        event.stopPropagation();
        window.parent.postMessage(
          createBuilderPreviewMessage(resolvedSiteId, {
            type: "builder:select-entry",
            pagePath: window.location.pathname,
            entryId: postEntry.dataset.builderEntryId,
            contentType: "post",
            regionId: postEntry.dataset.builderRegion,
            anchor: { x: event.clientX, y: event.clientY },
          }),
          targetOrigin,
        );
        return;
      }

      const matches = Array.from(document.querySelectorAll<HTMLElement>("[data-builder-region]")).filter((element) =>
        element.contains(target),
      );
      const deepestRegion = matches.at(-1);
      if (deepestRegion) {
        event.preventDefault();
        event.stopPropagation();
        const kind = (deepestRegion.dataset.builderKind ?? "text") as EditableKind;
        window.parent.postMessage(
          createBuilderPreviewMessage(resolvedSiteId, {
            type: "builder:select-region",
            pagePath: window.location.pathname,
            regionId: deepestRegion.dataset.builderRegion ?? "",
            kind,
            ...readRegionSelection(deepestRegion, kind),
          }),
          targetOrigin,
        );
        return;
      }

      const anchor = target.closest<HTMLAnchorElement>("a[href]");
      if (anchor && new URL(window.location.href).searchParams.get("builderPreview") === "1") {
        const href = new URL(anchor.href);
        if (href.origin === window.location.origin) {
          event.preventDefault();
          window.parent.postMessage(
            createBuilderPreviewMessage(resolvedSiteId, {
              type: "builder:navigate",
              pagePath: `${href.pathname}${href.search}${href.hash}`,
            }),
            targetOrigin,
          );
        }
      }
    }

    document.addEventListener("click", handleClick, true);
    return () => document.removeEventListener("click", handleClick, true);
  }, [parentOrigin, siteId]);

  return <span data-builder-preview-bridge data-builder-site-id={siteId} hidden />;
}

export interface BuilderRouteHandlerOptions {
  site: BuilderSiteConfig;
  adapter: BuilderContentAdapter;
  getUserId?: (request: Request) => string | Promise<string>;
}

export interface LoadBuilderPageContentInput {
  adapter: BuilderContentAdapter;
  siteId: string;
  pagePath: string;
  mode?: "draft" | "published";
  fallback?: PageContent;
}

export async function loadBuilderPageContent({
  adapter,
  siteId,
  pagePath,
  mode = "published",
  fallback,
}: LoadBuilderPageContentInput): Promise<PageContent> {
  try {
    return mode === "draft"
      ? await adapter.getDraftContent(siteId, pagePath)
      : await adapter.getPublishedContent(siteId, pagePath);
  } catch {
    return fallback ?? { path: pagePath, regions: {} };
  }
}

async function readJson<T>(request: Request): Promise<T> {
  return (await request.json()) as T;
}

export function createBuilderRouteHandlers({ site, adapter, getUserId }: BuilderRouteHandlerOptions) {
  async function userId(request: Request) {
    return (await getUserId?.(request)) ?? "system";
  }

  return {
    async GET(request: Request) {
      const url = new URL(request.url);
      const resource = url.searchParams.get("resource") ?? "content";
      const path = url.searchParams.get("path") ?? "/";
      const mode = url.searchParams.get("mode") ?? "published";

      if (resource === "audit") {
        return Response.json(await adapter.listAuditLog(site.siteId, path));
      }

      if (resource === "media") {
        return Response.json(await adapter.listMediaAssets(site.siteId));
      }

      const content =
        mode === "draft"
          ? await adapter.getDraftContent(site.siteId, path)
          : await adapter.getPublishedContent(site.siteId, path);

      return Response.json(content);
    },

    async POST(request: Request) {
      const url = new URL(request.url);
      const resource = url.searchParams.get("resource") ?? "draft";

      if (resource === "media") {
        const input = await readJson<Omit<Parameters<BuilderContentAdapter["createMediaAsset"]>[0], "siteId" | "userId">>(
          request,
        );
        const asset: MediaAsset = await adapter.createMediaAsset({
          ...input,
          siteId: site.siteId,
          userId: await userId(request),
        });

        return Response.json(asset);
      }

      const input = await readJson<Omit<SaveDraftInput, "siteId" | "userId">>(request);
      const version = await adapter.saveDraft({
        ...input,
        siteId: site.siteId,
        userId: await userId(request),
      });

      return Response.json(version);
    },

    async PUT(request: Request) {
      const input = await readJson<Omit<PublishInput, "siteId" | "userId">>(request);
      const version = await adapter.publishVersion({
        ...input,
        siteId: site.siteId,
        userId: await userId(request),
      });

      return Response.json(version);
    },

    async PATCH(request: Request) {
      const url = new URL(request.url);
      const resource = url.searchParams.get("resource") ?? "rollback";
      const version =
        resource === "undo-rollback"
          ? await adapter.undoRollback({
              ...(await readJson<Omit<UndoRollbackInput, "siteId" | "userId">>(request)),
              siteId: site.siteId,
              userId: await userId(request),
            })
          : await adapter.rollbackToVersion({
              ...(await readJson<Omit<RollbackInput, "siteId" | "userId">>(request)),
              siteId: site.siteId,
              userId: await userId(request),
            });

      return Response.json(version);
    },
  };
}
