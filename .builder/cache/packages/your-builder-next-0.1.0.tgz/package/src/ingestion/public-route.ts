import { createHash } from "node:crypto";

import {
  GROWTH_INGESTION_CONTRACT_VERSION,
  type PublicIngestionAcceptance,
} from "./contracts.js";
import { PublicIngestionRequestError } from "./errors.js";
import type { HmacFingerprintService } from "./fingerprints.js";
import {
  validatePublicIngestionRequest,
  type PublicIngestionValidationOptions,
} from "./request-validation.js";
import type { TurnstileVerificationSafeCode, TurnstileVerifier } from "./turnstile.js";
import type { TrustedHostNetworkAdapter } from "./trusted-network.js";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const HEX_SHA256_PATTERN = /^[a-f0-9]{64}$/;
const LOCALE_PATTERN = /^[A-Za-z]{2}(?:-[A-Za-z0-9]{2,8})?$/;
const POLICY_VALUE_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$/;
const RESPONSE_HEADERS = { "cache-control": "no-store" } as const;

export interface PublicIngestionPayload {
  readonly firstName: string;
  readonly lastName: string;
  readonly email?: string;
  readonly phone?: string;
  readonly service: string;
  readonly urgency: "normal" | "high" | "emergency";
  readonly message: string;
}

function toStoredUrgency(
  urgency: "standard" | "urgent" | "emergency",
): PublicIngestionPayload["urgency"] {
  if (urgency === "standard") return "normal";
  if (urgency === "urgent") return "high";
  return "emergency";
}

export interface PublicConsentEvidence {
  readonly policyVersion: string;
  readonly purpose: string;
  readonly languageDigest: string;
  readonly source: "public_form";
  readonly capturedAt: string;
}

export interface PublicIngestionRateLimit {
  readonly bucketKeyHmac: string;
  readonly windowStartedAt: string;
  readonly windowEndsAt: string;
  readonly limit: number;
}

export interface TrustedPublicIngestionCommand {
  readonly version: typeof GROWTH_INGESTION_CONTRACT_VERSION;
  readonly siteId: string;
  readonly formId: string;
  readonly idempotencyKey: string;
  readonly submittedAt: string;
  readonly zipCode: string;
  readonly locale: string;
  readonly payload: PublicIngestionPayload;
  readonly consentEvidence: PublicConsentEvidence;
  readonly securityReceiptId: string;
  readonly requestFingerprint: string;
  readonly rateLimits: readonly [PublicIngestionRateLimit, PublicIngestionRateLimit];
}

export interface PublicIngestionService {
  ingest(command: TrustedPublicIngestionCommand): Promise<PublicIngestionAcceptance>;
}

export interface PublicIngestionRateLimitPolicy {
  readonly limit: number;
  readonly windowMs: number;
}

export interface PublicIngestionRouteDependencies extends PublicIngestionValidationOptions {
  readonly siteId: string;
  readonly locale: string;
  readonly allowedFormIds: readonly string[];
  readonly consentPolicy: {
    readonly version: string;
    readonly purpose: string;
    readonly acknowledgementText: string;
  };
  readonly rateLimits: {
    readonly network: PublicIngestionRateLimitPolicy;
    readonly identity: PublicIngestionRateLimitPolicy;
  };
  readonly network: TrustedHostNetworkAdapter;
  readonly fingerprints: HmacFingerprintService;
  readonly turnstile: TurnstileVerifier;
  readonly ingestion: PublicIngestionService;
  readonly now: () => Date;
  readonly uuid: () => string;
}

export interface PublicIngestionRouteContext {
  readonly formId: string;
}

function errorResponse(status: number, code: string, message: string, headers?: Record<string, string>): Response {
  return Response.json(
    { error: { code, message } },
    { status, headers: { ...RESPONSE_HEADERS, ...headers } },
  );
}

function turnstileErrorResponse(safeCode: Exclude<TurnstileVerificationSafeCode, "TURNSTILE_VERIFIED">): Response {
  const temporary = safeCode === "TURNSTILE_TIMEOUT" || safeCode === "TURNSTILE_UNAVAILABLE";
  return errorResponse(
    temporary ? 503 : 400,
    safeCode,
    temporary
      ? "Verification is temporarily unavailable. Please try again or call us."
      : "Verification failed. Please try again or call us.",
  );
}

function validateRateLimitPolicy(policy: PublicIngestionRateLimitPolicy): void {
  if (
    !Number.isInteger(policy.limit) ||
    policy.limit < 1 ||
    policy.limit > 100 ||
    !Number.isInteger(policy.windowMs) ||
    policy.windowMs < 60_000 ||
    policy.windowMs > 86_400_000
  ) {
    throw new TypeError("Public ingestion rate limits must use fixed bounded values.");
  }
}

function createRateLimit(
  bucketKeyHmac: string,
  policy: PublicIngestionRateLimitPolicy,
  timestampMs: number,
): PublicIngestionRateLimit {
  if (!HEX_SHA256_PATTERN.test(bucketKeyHmac)) throw new Error("Invalid rate-limit HMAC.");
  const windowStartedAt = Math.floor(timestampMs / policy.windowMs) * policy.windowMs;
  return Object.freeze({
    bucketKeyHmac,
    windowStartedAt: new Date(windowStartedAt).toISOString(),
    windowEndsAt: new Date(windowStartedAt + policy.windowMs).toISOString(),
    limit: policy.limit,
  });
}

export function createPublicIngestionRouteHandler(dependencies: PublicIngestionRouteDependencies) {
  if (!LOCALE_PATTERN.test(dependencies.locale)) throw new TypeError("A valid server locale is required.");
  if (
    !POLICY_VALUE_PATTERN.test(dependencies.consentPolicy.version) ||
    !POLICY_VALUE_PATTERN.test(dependencies.consentPolicy.purpose) ||
    !dependencies.consentPolicy.acknowledgementText
  ) {
    throw new TypeError("A valid server consent policy is required.");
  }
  validateRateLimitPolicy(dependencies.rateLimits.network);
  validateRateLimitPolicy(dependencies.rateLimits.identity);

  return {
    async handle(request: Request, context: PublicIngestionRouteContext): Promise<Response> {
      if (request.method !== "POST") {
        return errorResponse(405, "METHOD_NOT_ALLOWED", "Only POST requests are accepted.", { allow: "POST" });
      }
      if (!dependencies.allowedFormIds.includes(context.formId)) {
        return errorResponse(404, "FORM_NOT_FOUND", "The requested form was not found.");
      }

      try {
        const input = await validatePublicIngestionRequest(request, dependencies);
        const network = await dependencies.network.resolve(request);
        const verification = await dependencies.turnstile.verify({
          token: input.turnstileToken,
          remoteAddress: network.address,
          idempotencyKey: input.idempotencyKey,
        });
        if (!verification.ok) return turnstileErrorResponse(verification.safeCode);

        const now = dependencies.now();
        const timestampMs = now.getTime();
        if (!Number.isFinite(timestampMs)) throw new Error("Invalid server timestamp.");
        const capturedAt = now.toISOString();
        const securityReceiptId = dependencies.uuid();
        if (!UUID_PATTERN.test(securityReceiptId)) throw new Error("Invalid security receipt.");

        const fingerprints = dependencies.fingerprints.create({
          networkAddress: network.address,
          ...(input.email ? { email: input.email } : {}),
          ...(input.phone ? { phone: input.phone } : {}),
        });
        const payload: PublicIngestionPayload = Object.freeze({
          firstName: input.firstName,
          lastName: input.lastName,
          ...(input.email ? { email: input.email } : {}),
          ...(input.phone ? { phone: input.phone } : {}),
          service: input.serviceId,
          urgency: toStoredUrgency(input.urgency),
          message: input.message,
        });
        const languageDigest = createHash("sha256")
          .update(dependencies.consentPolicy.acknowledgementText, "utf8")
          .digest("hex");
        const consentForFingerprint = Object.freeze({
          policyVersion: dependencies.consentPolicy.version,
          purpose: dependencies.consentPolicy.purpose,
          languageDigest,
          source: "public_form" as const,
        });
        const requestFingerprint = dependencies.fingerprints.createRequestFingerprint({
          siteId: dependencies.siteId,
          formId: context.formId,
          zipCode: input.zipCode,
          locale: dependencies.locale,
          payload,
          consentEvidence: consentForFingerprint,
        });
        if (!HEX_SHA256_PATTERN.test(requestFingerprint)) throw new Error("Invalid request HMAC.");

        const acceptance = await dependencies.ingestion.ingest({
          version: GROWTH_INGESTION_CONTRACT_VERSION,
          siteId: dependencies.siteId,
          formId: context.formId,
          idempotencyKey: input.idempotencyKey,
          submittedAt: capturedAt,
          zipCode: input.zipCode,
          locale: dependencies.locale,
          payload,
          consentEvidence: {
            ...consentForFingerprint,
            capturedAt,
          },
          securityReceiptId,
          requestFingerprint,
          rateLimits: [
            createRateLimit(fingerprints.networkFingerprint, dependencies.rateLimits.network, timestampMs),
            createRateLimit(fingerprints.identityFingerprint, dependencies.rateLimits.identity, timestampMs),
          ],
        });
        if (
          acceptance.version !== 1 ||
          acceptance.accepted !== true ||
          !UUID_PATTERN.test(acceptance.receiptId) ||
          (acceptance.result !== "accepted" && acceptance.result !== "replayed")
        ) {
          throw new Error("Invalid ingestion acceptance.");
        }
        return Response.json({
          version: 1,
          accepted: true,
          receiptId: acceptance.receiptId,
          result: acceptance.result,
        } satisfies PublicIngestionAcceptance, { status: 202, headers: RESPONSE_HEADERS });
      } catch (error) {
        if (error instanceof PublicIngestionRequestError) {
          return errorResponse(error.status, error.safeCode, error.message);
        }
        return errorResponse(
          503,
          "INGESTION_UNAVAILABLE",
          "The form is temporarily unavailable. Please try again or call us.",
        );
      }
    },
  };
}
