export const GROWTH_INGESTION_CONTRACT_VERSION = 1 as const;

export interface GrowthIngestionCommand<Payload, ConsentEvidence> {
  readonly version: typeof GROWTH_INGESTION_CONTRACT_VERSION;
  readonly siteId: string;
  readonly formId: string;
  readonly idempotencyKey: string;
  readonly submittedAt: string;
  readonly zipCode: string;
  readonly payload: Payload;
  readonly consentEvidence: ConsentEvidence;
  readonly securityReceiptId: string;
}

export type GrowthIngestionSafeCode =
  | "accepted"
  | "growth_unavailable"
  | "identity_conflict"
  | "review_suggested"
  | "spam_review";

export type GrowthIngestionOutcome<BaseSubmission, EnhancedResult> =
  | {
      readonly kind: "enhanced";
      readonly baseSubmission: BaseSubmission;
      readonly enhancedResult: EnhancedResult;
    }
  | {
      readonly kind: "base_only" | "review" | "replay";
      readonly baseSubmission: BaseSubmission;
      readonly safeCode: GrowthIngestionSafeCode;
    };

export interface PublicIngestionAcceptance {
  readonly version: typeof GROWTH_INGESTION_CONTRACT_VERSION;
  readonly accepted: true;
  readonly receiptId: string;
  readonly result: "accepted" | "replayed";
}
