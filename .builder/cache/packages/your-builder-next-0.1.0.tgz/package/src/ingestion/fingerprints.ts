import { createHmac } from "node:crypto";

import {
  normalizeEmail,
  normalizeNetworkAddress,
  normalizeNorthAmericanPhone,
} from "./normalization.js";

export interface HmacFingerprintServiceOptions {
  readonly keyId: string;
  readonly secret: string | Uint8Array;
}

export interface PublicIngestionFingerprintInput {
  readonly networkAddress: string;
  readonly email?: string;
  readonly phone?: string;
}

export interface PublicIngestionFingerprints {
  readonly keyId: string;
  readonly networkFingerprint: string;
  readonly identityFingerprint: string;
}

export interface HmacFingerprintService {
  create(input: PublicIngestionFingerprintInput): PublicIngestionFingerprints;
  createRequestFingerprint(normalizedSubmission: unknown): string;
}

function canonicalJson(value: unknown): string {
  if (value === null || typeof value === "string" || typeof value === "boolean") {
    return JSON.stringify(value);
  }
  if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    const object = value as Record<string, unknown>;
    return `{${Object.keys(object).sort().map((key) => (
      `${JSON.stringify(key)}:${canonicalJson(object[key])}`
    )).join(",")}}`;
  }
  throw new TypeError("Request fingerprint input must contain only JSON values.");
}

export function createHmacFingerprintService(
  options: HmacFingerprintServiceOptions,
): HmacFingerprintService {
  const keyId = options.keyId.trim();
  const secret = typeof options.secret === "string"
    ? new TextEncoder().encode(options.secret)
    : Uint8Array.from(options.secret);
  if (!keyId || keyId.length > 100 || secret.byteLength < 32) {
    throw new TypeError("A key ID and a site-scoped secret of at least 32 bytes are required.");
  }

  function digest(domain: "network" | "identity" | "request", normalizedValue: string): string {
    return createHmac("sha256", secret)
      .update(`builder-public-ingestion-v1\0${domain}\0${normalizedValue}`)
      .digest("hex");
  }

  return {
    create(input) {
      const networkAddress = normalizeNetworkAddress(input.networkAddress);
      const email = input.email ? normalizeEmail(input.email) : undefined;
      const phone = input.phone ? normalizeNorthAmericanPhone(input.phone) : undefined;
      if (!networkAddress || (!email && !phone)) {
        throw new TypeError("Normalized network and identity inputs are required.");
      }
      const identity = JSON.stringify({ email: email ?? null, phone: phone ?? null });
      return Object.freeze({
        keyId,
        networkFingerprint: digest("network", networkAddress),
        identityFingerprint: digest("identity", identity),
      });
    },
    createRequestFingerprint(normalizedSubmission) {
      return digest("request", canonicalJson(normalizedSubmission));
    },
  };
}
