import { PublicIngestionRequestError } from "./errors.js";
import { normalizeEmail, normalizeNorthAmericanPhone } from "./normalization.js";

const DEFAULT_MAX_BODY_BYTES = 16_384;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ZIP_PATTERN = /^\d{5}(?:-\d{4})?$/;
const FIELD_NAMES = new Set([
  "firstName",
  "lastName",
  "email",
  "phone",
  "zipCode",
  "serviceId",
  "urgency",
  "message",
  "consentAcknowledged",
  "consentPolicyVersion",
  "consentAcknowledgement",
  "turnstileToken",
  "idempotencyKey",
]);

export interface PublicIngestionValidationOptions {
  readonly allowedOrigins: readonly string[];
  readonly allowedServiceIds: readonly string[];
  readonly consentPolicy: {
    readonly version: string;
    readonly acknowledgementText: string;
  };
  readonly maxBodyBytes?: number;
}

export interface ValidatedPublicIngestionInput {
  readonly firstName: string;
  readonly lastName: string;
  readonly email?: string;
  readonly phone?: string;
  readonly zipCode: string;
  readonly serviceId: string;
  readonly urgency: "standard" | "urgent" | "emergency";
  readonly message: string;
  readonly consentAcknowledged: true;
  readonly consentPolicyVersion: string;
  readonly turnstileToken: string;
  readonly idempotencyKey: string;
}

function invalidSubmission(): never {
  throw new PublicIngestionRequestError(
    400,
    "INVALID_SUBMISSION",
    "The form submission is invalid.",
  );
}

function boundedText(value: unknown, minimum: number, maximum: number): string | undefined {
  if (typeof value !== "string") return undefined;
  const normalized = value.trim();
  if (normalized.length < minimum || normalized.length > maximum || normalized.includes("\0")) {
    return undefined;
  }
  return normalized;
}

function assertSameOrigin(request: Request, allowedOrigins: readonly string[]): void {
  const origin = request.headers.get("origin");
  if (!origin) {
    throw new PublicIngestionRequestError(403, "ORIGIN_REQUIRED", "A same-origin request is required.");
  }

  let normalizedOrigin: string;
  try {
    const parsed = new URL(origin);
    if (parsed.origin !== origin || (parsed.protocol !== "https:" && parsed.protocol !== "http:")) {
      throw new Error("invalid origin");
    }
    normalizedOrigin = parsed.origin;
  } catch {
    throw new PublicIngestionRequestError(403, "ORIGIN_REJECTED", "The request origin is not allowed.");
  }

  const fetchSite = request.headers.get("sec-fetch-site");
  const requestOrigin = new URL(request.url).origin;
  const allowed = allowedOrigins.some((value) => {
    try {
      return new URL(value).origin === normalizedOrigin;
    } catch {
      return false;
    }
  });
  if (!allowed || requestOrigin !== normalizedOrigin || (fetchSite && fetchSite !== "same-origin")) {
    throw new PublicIngestionRequestError(403, "ORIGIN_REJECTED", "The request origin is not allowed.");
  }
}

async function readBoundedJson(request: Request, maximumBytes: number): Promise<unknown> {
  if (!Number.isInteger(maximumBytes) || maximumBytes < 1 || maximumBytes > 1_048_576) {
    throw new TypeError("maxBodyBytes must be an integer between 1 and 1048576.");
  }

  const contentLength = request.headers.get("content-length");
  if (contentLength && (!/^\d+$/.test(contentLength) || Number(contentLength) > maximumBytes)) {
    throw new PublicIngestionRequestError(413, "REQUEST_TOO_LARGE", "The request body is too large.");
  }

  const reader = request.body?.getReader();
  if (!reader) {
    throw new PublicIngestionRequestError(400, "INVALID_JSON", "A JSON request body is required.");
  }

  const chunks: Uint8Array[] = [];
  let bytes = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    bytes += value.byteLength;
    if (bytes > maximumBytes) {
      await reader.cancel().catch(() => undefined);
      throw new PublicIngestionRequestError(413, "REQUEST_TOO_LARGE", "The request body is too large.");
    }
    chunks.push(value);
  }

  const body = new Uint8Array(bytes);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }

  try {
    const text = new TextDecoder("utf-8", { fatal: true }).decode(body);
    return JSON.parse(text) as unknown;
  } catch {
    throw new PublicIngestionRequestError(400, "INVALID_JSON", "A valid JSON request body is required.");
  }
}

export async function validatePublicIngestionRequest(
  request: Request,
  options: PublicIngestionValidationOptions,
): Promise<ValidatedPublicIngestionInput> {
  assertSameOrigin(request, options.allowedOrigins);

  const mediaType = request.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase();
  if (mediaType !== "application/json") {
    throw new PublicIngestionRequestError(415, "JSON_REQUIRED", "A JSON request body is required.");
  }

  const value = await readBoundedJson(request, options.maxBodyBytes ?? DEFAULT_MAX_BODY_BYTES);
  if (!value || typeof value !== "object" || Array.isArray(value)) invalidSubmission();
  const input = value as Record<string, unknown>;
  if (Object.keys(input).some((key) => !FIELD_NAMES.has(key))) invalidSubmission();

  const firstName = boundedText(input.firstName, 1, 80);
  const lastName = boundedText(input.lastName, 1, 80);
  const emailSupplied = input.email !== undefined;
  const phoneSupplied = input.phone !== undefined;
  const email = typeof input.email === "string" ? normalizeEmail(input.email) : undefined;
  const phone = typeof input.phone === "string" ? normalizeNorthAmericanPhone(input.phone) : undefined;
  const zipCode = boundedText(input.zipCode, 5, 10);
  const serviceId = boundedText(input.serviceId, 1, 100);
  const urgency = boundedText(input.urgency, 6, 9);
  const message = boundedText(input.message, 1, 2_000);
  const consentPolicyVersion = typeof input.consentPolicyVersion === "string"
    && input.consentPolicyVersion.length >= 1
    && input.consentPolicyVersion.length <= 64
    && !input.consentPolicyVersion.includes("\0")
    ? input.consentPolicyVersion
    : undefined;
  const consentAcknowledgement = typeof input.consentAcknowledgement === "string"
    && input.consentAcknowledgement.length >= 1
    && input.consentAcknowledgement.length <= 1_000
    && !input.consentAcknowledgement.includes("\0")
    ? input.consentAcknowledgement
    : undefined;
  const turnstileToken = boundedText(input.turnstileToken, 1, 2_048);
  const idempotencyKey = boundedText(input.idempotencyKey, 36, 36);

  if (
    !firstName ||
    !lastName ||
    (emailSupplied && !email) ||
    (phoneSupplied && !phone) ||
    (!email && !phone) ||
    !zipCode ||
    !ZIP_PATTERN.test(zipCode) ||
    !serviceId ||
    !options.allowedServiceIds.includes(serviceId) ||
    !urgency ||
    !["standard", "urgent", "emergency"].includes(urgency) ||
    !message ||
    input.consentAcknowledged !== true ||
    consentPolicyVersion !== options.consentPolicy.version ||
    consentAcknowledgement !== options.consentPolicy.acknowledgementText ||
    !turnstileToken ||
    !idempotencyKey ||
    !UUID_PATTERN.test(idempotencyKey)
  ) {
    invalidSubmission();
  }

  return Object.freeze({
    firstName,
    lastName,
    ...(email ? { email } : {}),
    ...(phone ? { phone } : {}),
    zipCode,
    serviceId,
    urgency: urgency as ValidatedPublicIngestionInput["urgency"],
    message,
    consentAcknowledged: true,
    consentPolicyVersion,
    turnstileToken,
    idempotencyKey,
  });
}
