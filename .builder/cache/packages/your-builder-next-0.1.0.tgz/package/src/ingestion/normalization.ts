import { isIP } from "node:net";

export function normalizeNetworkAddress(value: string): string | undefined {
  const address = value.trim();
  const version = isIP(address);
  if (version === 4) return address;
  if (version !== 6) return undefined;

  const hostname = new URL(`http://[${address}]/`).hostname;
  return hostname.slice(1, -1).toLowerCase();
}

export function normalizeEmail(value: string): string | undefined {
  const email = value.trim().toLowerCase();
  if (email.length < 3 || email.length > 254 || /\s/.test(email)) return undefined;
  const separator = email.indexOf("@");
  if (separator < 1 || separator !== email.lastIndexOf("@") || separator === email.length - 1) {
    return undefined;
  }
  if (!email.slice(separator + 1).includes(".")) return undefined;
  return email;
}

export function normalizeNorthAmericanPhone(value: string): string | undefined {
  const digits = value.replace(/\D/g, "");
  if (digits.length === 10) return `+1${digits}`;
  if (digits.length === 11 && digits.startsWith("1")) return `+${digits}`;
  return undefined;
}
