import { normalizeNetworkAddress } from "./normalization.js";

const SITEVERIFY_URL = "https://challenges.cloudflare.com/turnstile/v0/siteverify";
const MAX_PROVIDER_RESPONSE_BYTES = 16_384;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ACTION_PATTERN = /^[a-z0-9_-]{1,32}$/i;
const REJECTED_TOKEN_CODES = new Set([
  "missing-input-response",
  "invalid-input-response",
  "timeout-or-duplicate",
]);

export const CLOUDFLARE_TURNSTILE_TEST_KEYS = Object.freeze({
  alwaysPass: Object.freeze({
    siteKey: "1x00000000000000000000AA",
    secretKey: "1x0000000000000000000000000000000AA",
  }),
  alwaysFail: Object.freeze({
    siteKey: "2x00000000000000000000AB",
    secretKey: "2x0000000000000000000000000000000AA",
  }),
  duplicate: Object.freeze({
    siteKey: "1x00000000000000000000AA",
    secretKey: "3x0000000000000000000000000000000AA",
  }),
  dummyToken: "XXXX.DUMMY.TOKEN.XXXX",
});

export type TurnstileVerificationSafeCode =
  | "TURNSTILE_VERIFIED"
  | "TURNSTILE_REJECTED"
  | "TURNSTILE_HOSTNAME_MISMATCH"
  | "TURNSTILE_ACTION_MISMATCH"
  | "TURNSTILE_TIMEOUT"
  | "TURNSTILE_UNAVAILABLE";

export type TurnstileVerificationResult =
  | { readonly ok: true; readonly safeCode: "TURNSTILE_VERIFIED" }
  | { readonly ok: false; readonly safeCode: Exclude<TurnstileVerificationSafeCode, "TURNSTILE_VERIFIED"> };

export interface TurnstileVerificationInput {
  readonly token: string;
  readonly remoteAddress: string;
  readonly idempotencyKey: string;
}

export interface TurnstileVerifier {
  verify(input: TurnstileVerificationInput): Promise<TurnstileVerificationResult>;
}

export interface CloudflareTurnstileVerifierOptions {
  readonly secret: string;
  readonly expectedHostname: string;
  readonly expectedAction: string;
  readonly timeoutMs?: number;
  readonly fetch?: typeof fetch;
}

interface SiteverifyResponse {
  readonly success: boolean;
  readonly hostname?: string;
  readonly action?: string;
  readonly errorCodes?: readonly string[];
}

function failure(
  safeCode: Exclude<TurnstileVerificationSafeCode, "TURNSTILE_VERIFIED">,
): TurnstileVerificationResult {
  return Object.freeze({ ok: false, safeCode });
}

function parseProviderResponse(text: string): SiteverifyResponse | undefined {
  if (new TextEncoder().encode(text).byteLength > MAX_PROVIDER_RESPONSE_BYTES) return undefined;
  try {
    const value = JSON.parse(text) as unknown;
    if (!value || typeof value !== "object" || Array.isArray(value)) return undefined;
    const response = value as Record<string, unknown>;
    if (typeof response.success !== "boolean") return undefined;
    if (response.hostname !== undefined && typeof response.hostname !== "string") return undefined;
    if (response.action !== undefined && typeof response.action !== "string") return undefined;
    const errorCodes = response["error-codes"];
    if (
      errorCodes !== undefined &&
      (!Array.isArray(errorCodes) ||
        errorCodes.length > 10 ||
        errorCodes.some((code) => typeof code !== "string" || code.length < 1 || code.length > 100))
    ) {
      return undefined;
    }
    return {
      success: response.success,
      ...(typeof response.hostname === "string" ? { hostname: response.hostname } : {}),
      ...(typeof response.action === "string" ? { action: response.action } : {}),
      ...(Array.isArray(errorCodes) ? { errorCodes: errorCodes as string[] } : {}),
    };
  } catch {
    return undefined;
  }
}

export function createCloudflareTurnstileVerifier(
  options: CloudflareTurnstileVerifierOptions,
): TurnstileVerifier {
  const secret = options.secret.trim();
  const expectedHostname = options.expectedHostname.trim().toLowerCase();
  const expectedAction = options.expectedAction.trim();
  const timeoutMs = options.timeoutMs ?? 5_000;
  const fetchImplementation = options.fetch ?? globalThis.fetch;
  if (!secret) throw new TypeError("A Turnstile secret is required.");
  if (!expectedHostname || expectedHostname.includes(":") || expectedHostname.includes("/")) {
    throw new TypeError("A valid expected Turnstile hostname is required.");
  }
  if (!ACTION_PATTERN.test(expectedAction)) {
    throw new TypeError("A valid expected Turnstile action is required.");
  }
  if (!Number.isInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 15_000) {
    throw new TypeError("Turnstile timeoutMs must be between 100 and 15000.");
  }

  return {
    async verify(input) {
      const token = input.token.trim();
      const remoteAddress = normalizeNetworkAddress(input.remoteAddress);
      if (
        token.length < 1 ||
        token.length > 2_048 ||
        !remoteAddress ||
        !UUID_PATTERN.test(input.idempotencyKey)
      ) {
        return failure("TURNSTILE_REJECTED");
      }

      const controller = new AbortController();
      let timedOut = false;
      const timeout = setTimeout(() => {
        timedOut = true;
        controller.abort(new Error("Turnstile verification timeout"));
      }, timeoutMs);
      try {
        const response = await fetchImplementation(SITEVERIFY_URL, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            secret,
            response: token,
            remoteip: remoteAddress,
            idempotency_key: input.idempotencyKey,
          }),
          cache: "no-store",
          signal: controller.signal,
        });
        if (!response.ok) return failure("TURNSTILE_UNAVAILABLE");
        const contentLength = response.headers.get("content-length");
        if (contentLength && Number(contentLength) > MAX_PROVIDER_RESPONSE_BYTES) {
          return failure("TURNSTILE_UNAVAILABLE");
        }
        const provider = parseProviderResponse(await response.text());
        if (!provider) return failure("TURNSTILE_UNAVAILABLE");
        if (!provider.success) {
          const rejectedToken = provider.errorCodes?.length &&
            provider.errorCodes.every((code) => REJECTED_TOKEN_CODES.has(code));
          return failure(rejectedToken ? "TURNSTILE_REJECTED" : "TURNSTILE_UNAVAILABLE");
        }
        if (provider.hostname?.toLowerCase() !== expectedHostname) {
          return failure("TURNSTILE_HOSTNAME_MISMATCH");
        }
        if (provider.action !== expectedAction) return failure("TURNSTILE_ACTION_MISMATCH");
        return Object.freeze({ ok: true, safeCode: "TURNSTILE_VERIFIED" });
      } catch {
        return failure(timedOut ? "TURNSTILE_TIMEOUT" : "TURNSTILE_UNAVAILABLE");
      } finally {
        clearTimeout(timeout);
      }
    },
  };
}
