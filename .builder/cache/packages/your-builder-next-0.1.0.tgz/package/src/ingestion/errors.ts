export type PublicIngestionRequestSafeCode =
  | "ORIGIN_REQUIRED"
  | "ORIGIN_REJECTED"
  | "JSON_REQUIRED"
  | "REQUEST_TOO_LARGE"
  | "INVALID_JSON"
  | "INVALID_SUBMISSION"
  | "NETWORK_CONTEXT_REJECTED";

export class PublicIngestionRequestError extends Error {
  constructor(
    public readonly status: number,
    public readonly safeCode: PublicIngestionRequestSafeCode,
    message: string,
  ) {
    super(message);
    this.name = "PublicIngestionRequestError";
  }
}
