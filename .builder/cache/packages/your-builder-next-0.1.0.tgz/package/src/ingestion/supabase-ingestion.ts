import type { PublicIngestionAcceptance } from "./contracts.js";
import type { PublicIngestionService, TrustedPublicIngestionCommand } from "./public-route.js";

const INGESTION_RPC = "builder_ingest_form_submission_v1";
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export type PublicIngestionRpcSafeCode =
  | "INGESTION_RPC_UNAVAILABLE"
  | "INGESTION_RPC_INVALID_RESPONSE";

const errorMessage: Record<PublicIngestionRpcSafeCode, string> = {
  INGESTION_RPC_UNAVAILABLE: "Public ingestion is temporarily unavailable.",
  INGESTION_RPC_INVALID_RESPONSE: "Public ingestion returned an invalid response.",
};

export class PublicIngestionRpcError extends Error {
  constructor(public readonly safeCode: PublicIngestionRpcSafeCode) {
    super(errorMessage[safeCode]);
    this.name = "PublicIngestionRpcError";
  }
}

export interface PublicIngestionRpcClient {
  rpc(
    functionName: string,
    parameters: { readonly p_request: TrustedPublicIngestionCommand },
  ): PromiseLike<{ readonly data: unknown; readonly error: unknown }>;
}

function mapAcceptance(data: unknown): PublicIngestionAcceptance {
  if (!data || typeof data !== "object" || Array.isArray(data)) {
    throw new PublicIngestionRpcError("INGESTION_RPC_INVALID_RESPONSE");
  }
  const value = data as Record<string, unknown>;
  if (
    value.version !== 1 ||
    value.accepted !== true ||
    typeof value.receiptId !== "string" ||
    !UUID_PATTERN.test(value.receiptId) ||
    (value.result !== "accepted" && value.result !== "replayed")
  ) {
    throw new PublicIngestionRpcError("INGESTION_RPC_INVALID_RESPONSE");
  }
  return Object.freeze({
    version: 1,
    accepted: true,
    receiptId: value.receiptId,
    result: value.result,
  });
}

export function createSupabasePublicIngestionService(
  client: PublicIngestionRpcClient,
): PublicIngestionService {
  return {
    async ingest(command) {
      let response: { readonly data: unknown; readonly error: unknown };
      try {
        response = await client.rpc(INGESTION_RPC, { p_request: command });
      } catch {
        throw new PublicIngestionRpcError("INGESTION_RPC_UNAVAILABLE");
      }
      if (response.error) {
        throw new PublicIngestionRpcError("INGESTION_RPC_UNAVAILABLE");
      }
      return mapAcceptance(response.data);
    },
  };
}
