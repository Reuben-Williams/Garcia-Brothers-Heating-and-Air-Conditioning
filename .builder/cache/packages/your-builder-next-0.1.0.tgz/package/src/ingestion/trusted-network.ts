import { PublicIngestionRequestError } from "./errors.js";
import { normalizeNetworkAddress } from "./normalization.js";

export interface TrustedNetworkContext {
  readonly address: string;
}

export interface TrustedHostNetworkAdapter {
  resolve(request: Request): Promise<TrustedNetworkContext>;
}

interface TrustedHeaderNetworkAdapterOptions {
  readonly headerName: string;
}

function createTrustedHeaderNetworkAdapter(
  options: TrustedHeaderNetworkAdapterOptions,
): TrustedHostNetworkAdapter {
  const headerName = options.headerName.trim().toLowerCase();
  if (!headerName || !/^[a-z0-9-]+$/.test(headerName)) {
    throw new TypeError("A valid trusted host header name is required.");
  }

  return {
    async resolve(request) {
      const supplied = request.headers.get(headerName)?.trim();
      const address = supplied && !supplied.includes(",")
        ? normalizeNetworkAddress(supplied)
        : undefined;
      if (!address) {
        throw new PublicIngestionRequestError(
          400,
          "NETWORK_CONTEXT_REJECTED",
          "The request network context could not be verified.",
        );
      }
      return Object.freeze({ address });
    },
  };
}

export function createNetlifyTrustedNetworkAdapter(): TrustedHostNetworkAdapter {
  return createTrustedHeaderNetworkAdapter({ headerName: "x-nf-client-connection-ip" });
}

export function createVercelTrustedNetworkAdapter(): TrustedHostNetworkAdapter {
  return createTrustedHeaderNetworkAdapter({ headerName: "x-forwarded-for" });
}
