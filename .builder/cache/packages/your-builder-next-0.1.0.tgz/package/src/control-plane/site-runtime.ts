import "server-only";

import { randomUUID } from "node:crypto";

import {
  installationManifestSha256,
  parseInstallationManifest,
  type InstallationManifestInput,
} from "@your-builder/entitlements/trust";

import {
  createSiteCommandExecutor,
  type SiteCommandExecutionContext,
  type SiteCommandHandler,
  type SiteCommandLeaseContext,
} from "./command-executor.js";
import type { InstallationClientConfig } from "./config.js";
import { loadInstallationClientConfig } from "./config.js";
import {
  createSupabaseSiteCommandReceiptStore,
  type SiteCommandReceiptRpcClient,
  type SiteCommandReceiptStore,
} from "./idempotency-store.js";
import {
  createInstallationClient,
  type AcknowledgeCommandResultInput,
  type InstallationClient,
  type InstallationCommandEnvelope,
} from "./installation-client.js";
import {
  SiteDataPlaneIdentityError,
  parseExpectedSiteKey,
  parseSiteDataPlaneSiteUuid,
  type SiteDataPlaneIdentityStore,
  type SiteDataPlaneRpcClient,
  type SiteDataPlaneSiteUuid,
  createSupabaseSiteDataPlaneIdentityStore,
} from "./site-data-plane-identity.js";
import { buildSiteHealthReport, type SiteHealthSource } from "./site-health.js";
import {
  createSupabaseSiteInstallationRunLeaseStore,
  type SiteInstallationRunLeaseStore,
} from "./site-run-lease.js";
import {
  parseSiteRuntimeMarker,
  siteCommandHandlerRegistrySha256,
  type SiteRuntimeMarker,
} from "./runtime-marker.js";

export interface SiteInstallationRuntimeInput {
  config: InstallationClientConfig;
  siteDataPlaneSiteId: SiteDataPlaneSiteUuid;
  expectedSiteKey: string;
  installationManifest: InstallationManifestInput;
  workerVersion: string | null;
  receiptStore: SiteCommandReceiptStore;
  runLeaseStore: SiteInstallationRunLeaseStore;
  identityStore: SiteDataPlaneIdentityStore;
  handlers: readonly SiteCommandHandler<any>[];
  healthSource: SiteHealthSource;
}

export interface SiteInstallationRuntimeResult {
  pulled: number;
  acknowledged: number;
  healthReported: boolean;
}

export interface SiteInstallationRuntime {
  runScheduled(options?: { signal?: AbortSignal }): Promise<SiteInstallationRuntimeResult>;
}

type RuntimeInstallationClient = Pick<
  InstallationClient,
  "pullCommands" | "acknowledgeResult" | "reportHealth"
>;

export interface SiteInstallationRuntimeOptions {
  leaseSeconds?: number;
  leaseOwner?: () => string;
  now?: () => Date;
  installationClientFactory?: (config: InstallationClientConfig) => RuntimeInstallationClient;
}

export type SiteInstallationRuntimeErrorCode =
  | "site_installation_invocation_aborted"
  | "site_installation_lease_lost"
  | "site_installation_pull_failed"
  | "site_installation_command_execution_failed"
  | "site_installation_acknowledgment_failed"
  | "site_installation_health_report_failed";

export class SiteInstallationRuntimeError extends Error {
  constructor(public readonly code: SiteInstallationRuntimeErrorCode) {
    super(code);
    this.name = "SiteInstallationRuntimeError";
  }
}

export class SiteRuntimeMarkerMismatchError extends Error {
  readonly code = "site_runtime_marker_mismatch";

  constructor() {
    super("site_runtime_marker_mismatch");
    this.name = "SiteRuntimeMarkerMismatchError";
  }
}

export interface CreateSupabaseSiteInstallationRuntimeInput {
  env: Readonly<Record<string, string | undefined>>;
  marker: SiteRuntimeMarker;
  installationManifest: InstallationManifestInput;
  handlers: readonly SiteCommandHandler<any>[];
  healthSource: SiteHealthSource;
  supabaseClient: SiteDataPlaneRpcClient & SiteCommandReceiptRpcClient;
}

function runtimeError(code: SiteInstallationRuntimeErrorCode): SiteInstallationRuntimeError {
  return new SiteInstallationRuntimeError(code);
}

function assertNotAborted(signal: AbortSignal | undefined): void {
  if (signal?.aborted) throw runtimeError("site_installation_invocation_aborted");
}

function runtimeHealthCode(error: SiteInstallationRuntimeError): string {
  switch (error.code) {
    case "site_installation_pull_failed":
      return "CONTROL_PLANE_PULL_FAILED";
    case "site_installation_command_execution_failed":
      return "COMMAND_EXECUTION_FAILED";
    case "site_installation_acknowledgment_failed":
      return "COMMAND_ACKNOWLEDGMENT_FAILED";
    default:
      return "SCHEDULED_EXECUTION_FAILED";
  }
}

function commandInput(command: InstallationCommandEnvelope) {
  return {
    id: command.id,
    type: command.type,
    version: command.version,
    payload: command.payload,
    idempotencyKey: command.idempotencyKey,
  };
}

export function createSiteInstallationRuntime(
  input: SiteInstallationRuntimeInput,
  options: SiteInstallationRuntimeOptions = {},
): SiteInstallationRuntime {
  const installationId = input.config.installationId.toLowerCase();
  const siteId = parseSiteDataPlaneSiteUuid(input.siteDataPlaneSiteId, {
    centralInstallationId: installationId,
  });
  const expectedSiteKey = parseExpectedSiteKey(input.expectedSiteKey);
  const manifest = parseInstallationManifest(input.installationManifest);
  const leaseSeconds = options.leaseSeconds ?? 120;
  if (!Number.isSafeInteger(leaseSeconds) || leaseSeconds < 60 || leaseSeconds > 300) {
    throw new TypeError("Runtime lease must be between 60 and 300 seconds");
  }
  const nextLeaseOwner = options.leaseOwner ?? randomUUID;
  const now = options.now ?? (() => new Date());
  const clientFactory = options.installationClientFactory ?? createInstallationClient;
  const clientConfig = installationId === input.config.installationId
    ? input.config
    : { ...input.config, installationId };

  return {
    async runScheduled(runOptions = {}) {
      const signal = runOptions.signal;
      assertNotAborted(signal);
      const identity = await input.identityStore.getSiteIdentity(siteId);
      assertNotAborted(signal);
      if (identity.siteId !== siteId || identity.siteKey !== expectedSiteKey) {
        throw new SiteDataPlaneIdentityError();
      }

      const leaseOwner = parseSiteDataPlaneSiteUuid(nextLeaseOwner());
      const leaseIdentity = {
        siteId,
        expectedSiteKey,
        installationId,
        leaseOwner,
      };
      assertNotAborted(signal);
      const acquired = await input.runLeaseStore.acquire({ ...leaseIdentity, leaseSeconds });
      if (!acquired.acquired) {
        assertNotAborted(signal);
        return { pulled: 0, acknowledged: 0, healthReported: false };
      }
      if (
        acquired.fencingToken === null ||
        acquired.leaseExpiresAt === null ||
        acquired.leaseOwner !== leaseOwner ||
        acquired.siteId !== siteId ||
        acquired.installationId !== installationId
      ) {
        throw runtimeError("site_installation_lease_lost");
      }

      const fencingToken = acquired.fencingToken;
      const executionAbort = new AbortController();
      const invocationAborted = () => {
        const reason = signal?.reason instanceof Error
          ? signal.reason
          : runtimeError("site_installation_invocation_aborted");
        if (!executionAbort.signal.aborted) executionAbort.abort(reason);
      };
      if (signal?.aborted) invocationAborted();
      else signal?.addEventListener("abort", invocationAborted, { once: true });

      let leaseExpiresAt = acquired.leaseExpiresAt;
      let leaseDeadline: ReturnType<typeof setTimeout> | undefined;
      const leaseSafetyMs = Math.min(5_000, Math.max(1_000, leaseSeconds * 100));
      const heartbeatMs = Math.max(1_000, Math.floor(leaseSeconds * 1_000 / 3));

      const throwExecutionAbort = (): never => {
        if (executionAbort.signal.reason instanceof Error) {
          throw executionAbort.signal.reason;
        }
        throw runtimeError("site_installation_invocation_aborted");
      };
      const assertExecutionActive = () => {
        if (executionAbort.signal.aborted) throwExecutionAbort();
      };
      const loseLease = (): never => {
        const error = runtimeError("site_installation_lease_lost");
        if (!executionAbort.signal.aborted) executionAbort.abort(error);
        return throwExecutionAbort();
      };
      const armLeaseDeadline = () => {
        if (leaseDeadline !== undefined) clearTimeout(leaseDeadline);
        const delay = Date.parse(leaseExpiresAt) - now().getTime() - leaseSafetyMs;
        if (!Number.isFinite(delay) || delay <= 0) loseLease();
        leaseDeadline = setTimeout(() => {
          if (!executionAbort.signal.aborted) {
            executionAbort.abort(runtimeError("site_installation_lease_lost"));
          }
        }, delay);
        leaseDeadline.unref?.();
      };
      const leaseContext: SiteCommandLeaseContext = Object.freeze({
        siteId,
        installationId,
        leaseOwner,
        fencingToken,
        get leaseExpiresAt() {
          return leaseExpiresAt;
        },
      });
      let renewal: Promise<void> | null = null;
      const renew = (): Promise<void> => {
        if (renewal) return renewal;
        renewal = (async () => {
          assertExecutionActive();
          let renewed;
          try {
            renewed = await input.runLeaseStore.renew({
              ...leaseIdentity,
              fencingToken,
              leaseSeconds,
            });
          } catch {
            assertExecutionActive();
            return loseLease();
          }
          assertExecutionActive();
          if (
            !renewed.acquired ||
            renewed.fencingToken !== fencingToken ||
            renewed.leaseOwner !== leaseOwner ||
            renewed.siteId !== siteId ||
            renewed.installationId !== installationId ||
            renewed.leaseExpiresAt === null
          ) {
            return loseLease();
          }
          leaseExpiresAt = renewed.leaseExpiresAt;
          armLeaseDeadline();
        })().finally(() => {
          renewal = null;
        });
        return renewal;
      };
      const executionContext: SiteCommandExecutionContext = Object.freeze({
        signal: executionAbort.signal,
        lease: leaseContext,
        validateLease: renew,
      });
      const withLeaseHeartbeat = async <T>(operation: () => Promise<T>): Promise<T> => {
        let stopped = false;
        let timer: ReturnType<typeof setTimeout> | undefined;
        let heartbeat: Promise<void> | undefined;
        const schedule = () => {
          timer = setTimeout(() => {
            heartbeat = renew()
              .then(() => {
                if (!stopped && !executionAbort.signal.aborted) schedule();
              })
              .catch(() => undefined);
          }, heartbeatMs);
          timer.unref?.();
        };
        schedule();
        try {
          return await operation();
        } finally {
          stopped = true;
          if (timer !== undefined) clearTimeout(timer);
          await heartbeat;
        }
      };

      try {
        armLeaseDeadline();
        assertExecutionActive();
        const executor = createSiteCommandExecutor({
          siteId,
          handlers: input.handlers,
          store: input.receiptStore,
        });
        const client = clientFactory(clientConfig);
        let pulled = 0;
        let acknowledged = 0;
        let fatal: SiteInstallationRuntimeError | null = null;
        const healthErrors: string[] = [];

        let commands: InstallationCommandEnvelope[] = [];
        try {
          assertExecutionActive();
          commands = await client.pullCommands();
          pulled = commands.length;
        } catch {
          fatal = runtimeError("site_installation_pull_failed");
        }
        assertExecutionActive();

        for (const command of commands) {
          if (fatal) break;
          assertExecutionActive();
          await renew();
          let result: Awaited<ReturnType<typeof executor.execute>>;
          try {
            result = await withLeaseHeartbeat(() =>
              executor.execute(commandInput(command), executionContext));
          } catch {
            assertExecutionActive();
            fatal = runtimeError("site_installation_command_execution_failed");
            break;
          }
          assertExecutionActive();
          if (result.outcome === "failed") healthErrors.push("COMMAND_TERMINAL_FAILURE");
          const acknowledgment: AcknowledgeCommandResultInput = {
            commandId: command.id,
            attempt: command.attempt,
            leaseToken: command.leaseToken,
            ...result,
          };
          try {
            assertExecutionActive();
            await client.acknowledgeResult(acknowledgment);
            assertExecutionActive();
            acknowledged += 1;
          } catch {
            assertExecutionActive();
            fatal = runtimeError("site_installation_acknowledgment_failed");
          }
        }

        if (fatal) healthErrors.push(runtimeHealthCode(fatal));
        assertExecutionActive();
        await renew();
        assertExecutionActive();
        const report = await buildSiteHealthReport({
          installationManifest: manifest,
          workerVersion: input.workerVersion,
          runtimeInitialized: true,
          scheduledExecutionSucceeded: fatal === null,
          healthSource: input.healthSource,
          runtimeErrorCodes: healthErrors,
        });
        assertExecutionActive();
        try {
          await client.reportHealth(report);
          assertExecutionActive();
        } catch {
          assertExecutionActive();
          throw runtimeError("site_installation_health_report_failed");
        }
        if (fatal) throw fatal;
        return { pulled, acknowledged, healthReported: true };
      } finally {
        if (leaseDeadline !== undefined) clearTimeout(leaseDeadline);
        signal?.removeEventListener("abort", invocationAborted);
        await input.runLeaseStore.release({
          ...leaseIdentity,
          fencingToken,
        }).catch(() => false);
      }
    },
  };
}

export function createSupabaseSiteInstallationRuntime(
  input: CreateSupabaseSiteInstallationRuntimeInput,
  options: Omit<SiteInstallationRuntimeOptions, "leaseSeconds"> = {},
): SiteInstallationRuntime {
  const marker = parseSiteRuntimeMarker(input.marker);
  const manifest = parseInstallationManifest(input.installationManifest);
  if (
    installationManifestSha256(manifest) !== marker.installationManifestSha256 ||
    siteCommandHandlerRegistrySha256(input.handlers) !== marker.handlerRegistrySha256 ||
    (manifest.workerVersion ?? null) !== (marker.workerVersion ?? null)
  ) {
    throw new SiteRuntimeMarkerMismatchError();
  }
  const config = loadInstallationClientConfig(input.env);
  return createSiteInstallationRuntime({
    config,
    siteDataPlaneSiteId: parseSiteDataPlaneSiteUuid(marker.siteDataPlaneSiteId, {
      centralInstallationId: config.installationId,
    }),
    expectedSiteKey: marker.expectedSiteKey,
    installationManifest: manifest,
    workerVersion: marker.workerVersion ?? null,
    receiptStore: createSupabaseSiteCommandReceiptStore(input.supabaseClient),
    identityStore: createSupabaseSiteDataPlaneIdentityStore(input.supabaseClient),
    runLeaseStore: createSupabaseSiteInstallationRunLeaseStore(input.supabaseClient),
    handlers: input.handlers,
    healthSource: input.healthSource,
  }, {
    ...options,
    leaseSeconds: marker.leaseSeconds,
  });
}
