import "server-only";

import { randomUUID } from "node:crypto";

import {
  validateCommandExecutionResult,
  type CommandExecutionResult,
} from "./installation-client.js";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export interface SiteCommandReceiptIdentity {
  siteId: string;
  commandId: string;
  idempotencyKey: string;
}

export interface SiteCommandReceipt extends SiteCommandReceiptIdentity {
  type: string;
  version: number;
  payloadHash: string;
  result: CommandExecutionResult;
}

export interface SiteCommandReceiptCompletion extends SiteCommandReceipt {
  leaseToken: string;
}

export type SiteCommandReservation =
  | { status: "acquired"; leaseToken: string; leaseExpiresAt: string }
  | { status: "in_progress"; retryAt: string }
  | { status: "conflict" }
  | { status: "replay"; result: CommandExecutionResult };

export interface SiteCommandReceiptStore {
  reserve(input: Omit<SiteCommandReceipt, "result">): Promise<SiteCommandReservation>;
  complete(input: SiteCommandReceiptCompletion): Promise<boolean>;
  find(input: SiteCommandReceiptIdentity): Promise<SiteCommandReceipt | null>;
}

export interface SiteCommandReceiptRpcClient {
  rpc(
    name: string,
    args: Record<string, unknown>,
  ): PromiseLike<{ data: unknown; error: { message?: string } | null }>;
}

export class SiteCommandReceiptStoreError extends Error {
  readonly code = "site_command_receipt_store_error";

  constructor() {
    super("Site command receipt store operation failed");
    this.name = "SiteCommandReceiptStoreError";
  }
}

interface PendingReceipt extends Omit<SiteCommandReceipt, "result"> {
  status: "received" | "succeeded" | "failed" | "retry";
  result?: CommandExecutionResult;
  leaseToken?: string;
  leaseExpiresAt?: string;
  retryAt?: string;
  attempt: number;
}

function copyResult(result: CommandExecutionResult): CommandExecutionResult {
  return structuredClone(result);
}

function sameCommand(receipt: PendingReceipt, input: Omit<SiteCommandReceipt, "result">): boolean {
  return receipt.siteId === input.siteId &&
    receipt.commandId === input.commandId &&
    receipt.idempotencyKey === input.idempotencyKey &&
    receipt.type === input.type &&
    receipt.version === input.version &&
    receipt.payloadHash === input.payloadHash;
}

export function createMemorySiteCommandReceiptStore(options: {
  now?: () => Date;
  leaseSeconds?: number;
  leaseToken?: () => string;
} = {}): SiteCommandReceiptStore {
  const now = options.now ?? (() => new Date());
  const leaseSeconds = options.leaseSeconds ?? 30;
  const nextLeaseToken = options.leaseToken ?? randomUUID;
  if (!Number.isSafeInteger(leaseSeconds) || leaseSeconds < 5 || leaseSeconds > 300) {
    throw new TypeError("Receipt lease must be between 5 and 300 seconds");
  }
  const byCommand = new Map<string, PendingReceipt>();
  const byIdempotencyKey = new Map<string, PendingReceipt>();
  const commandKey = (siteId: string, commandId: string) => `${siteId}\u0000${commandId}`;
  const idempotencyKey = (siteId: string, key: string) => `${siteId}\u0000${key}`;

  function acquire(receipt: PendingReceipt): SiteCommandReservation {
    const acquiredAt = now();
    receipt.status = "received";
    receipt.result = undefined;
    receipt.retryAt = undefined;
    receipt.leaseToken = nextLeaseToken();
    receipt.leaseExpiresAt = new Date(acquiredAt.getTime() + leaseSeconds * 1_000).toISOString();
    return {
      status: "acquired",
      leaseToken: receipt.leaseToken,
      leaseExpiresAt: receipt.leaseExpiresAt,
    };
  }

  return {
    async reserve(input) {
      const existing = byCommand.get(commandKey(input.siteId, input.commandId)) ??
        byIdempotencyKey.get(idempotencyKey(input.siteId, input.idempotencyKey));
      if (existing) {
        if (!sameCommand(existing, input)) return { status: "conflict" };
        if (existing.status === "received") {
          if (existing.leaseExpiresAt && Date.parse(existing.leaseExpiresAt) <= now().getTime()) {
            existing.attempt += 1;
            return acquire(existing);
          }
          return { status: "in_progress", retryAt: existing.leaseExpiresAt! };
        }
        if (existing.status === "retry" && existing.retryAt) {
          if (Date.parse(existing.retryAt) <= now().getTime()) {
            existing.attempt += 1;
            return acquire(existing);
          }
          return { status: "replay", result: copyResult(existing.result!) };
        }
        return { status: "replay", result: copyResult(existing.result!) };
      }
      const pending = {
        ...structuredClone(input),
        status: "received" as const,
        attempt: 1,
      };
      byCommand.set(commandKey(input.siteId, input.commandId), pending);
      byIdempotencyKey.set(idempotencyKey(input.siteId, input.idempotencyKey), pending);
      return acquire(pending);
    },

    async complete(input) {
      const existing = byCommand.get(commandKey(input.siteId, input.commandId));
      if (
        !existing ||
        !sameCommand(existing, input) ||
        existing.status !== "received" ||
        existing.leaseToken !== input.leaseToken ||
        !existing.leaseExpiresAt ||
        Date.parse(existing.leaseExpiresAt) <= now().getTime()
      ) return false;
      existing.status = input.result.outcome;
      existing.result = copyResult(input.result);
      existing.retryAt = input.result.outcome === "retry" ? input.result.retryAt : undefined;
      existing.leaseToken = undefined;
      existing.leaseExpiresAt = undefined;
      return true;
    },

    async find(input) {
      const receipt = byCommand.get(commandKey(input.siteId, input.commandId)) ??
        byIdempotencyKey.get(idempotencyKey(input.siteId, input.idempotencyKey));
      if (!receipt?.result) return null;
      return {
        ...structuredClone(receipt),
        result: copyResult(receipt.result),
      } as SiteCommandReceipt;
    },
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

async function rpc(
  client: SiteCommandReceiptRpcClient,
  name: string,
  args: Record<string, unknown>,
): Promise<unknown> {
  const response = await client.rpc(name, args);
  if (response.error) throw new SiteCommandReceiptStoreError();
  return response.data;
}

function receiptArguments(input: Omit<SiteCommandReceipt, "result">): Record<string, unknown> {
  return {
    p_site_id: input.siteId,
    p_command_id: input.commandId,
    p_idempotency_key: input.idempotencyKey,
    p_command_type: input.type,
    p_command_version: input.version,
    p_payload_hash: input.payloadHash,
  };
}

export function createSupabaseSiteCommandReceiptStore(
  client: SiteCommandReceiptRpcClient,
  options: { leaseSeconds?: number } = {},
): SiteCommandReceiptStore {
  const leaseSeconds = options.leaseSeconds ?? 30;
  if (!Number.isSafeInteger(leaseSeconds) || leaseSeconds < 5 || leaseSeconds > 300) {
    throw new TypeError("Receipt lease must be between 5 and 300 seconds");
  }
  return {
    async reserve(input) {
      const data = await rpc(
        client,
        "builder_reserve_command_receipt",
        { ...receiptArguments(input), p_lease_seconds: leaseSeconds },
      );
      if (!isRecord(data) || typeof data.status !== "string") {
        throw new SiteCommandReceiptStoreError();
      }
      if (data.status === "acquired") {
        if (
          typeof data.leaseToken !== "string" ||
          !UUID.test(data.leaseToken) ||
          typeof data.leaseExpiresAt !== "string" ||
          !Number.isFinite(Date.parse(data.leaseExpiresAt))
        ) throw new SiteCommandReceiptStoreError();
        return {
          status: "acquired",
          leaseToken: data.leaseToken,
          leaseExpiresAt: data.leaseExpiresAt,
        };
      }
      if (data.status === "in_progress") {
        if (typeof data.retryAt !== "string" || !Number.isFinite(Date.parse(data.retryAt))) {
          throw new SiteCommandReceiptStoreError();
        }
        return { status: "in_progress", retryAt: data.retryAt };
      }
      if (data.status === "conflict") return { status: "conflict" };
      if (data.status === "replay") {
        try {
          return { status: "replay", result: validateCommandExecutionResult(data.result) };
        } catch {
          throw new SiteCommandReceiptStoreError();
        }
      }
      throw new SiteCommandReceiptStoreError();
    },

    async complete(input) {
      const data = await rpc(client, "builder_complete_command_receipt", {
        ...receiptArguments(input),
        p_lease_token: input.leaseToken,
        p_result: copyResult(input.result),
      });
      if (typeof data !== "boolean") throw new SiteCommandReceiptStoreError();
      return data;
    },

    async find(input) {
      const data = await rpc(client, "builder_find_command_receipt", {
        p_site_id: input.siteId,
        p_command_id: input.commandId,
        p_idempotency_key: input.idempotencyKey,
      });
      if (data === null) return null;
      if (
        !isRecord(data) ||
        typeof data.siteId !== "string" ||
        typeof data.commandId !== "string" ||
        typeof data.idempotencyKey !== "string" ||
        typeof data.type !== "string" ||
        !Number.isSafeInteger(data.version) ||
        typeof data.payloadHash !== "string"
      ) {
        throw new SiteCommandReceiptStoreError();
      }
      try {
        return {
          siteId: data.siteId,
          commandId: data.commandId,
          idempotencyKey: data.idempotencyKey,
          type: data.type,
          version: data.version as number,
          payloadHash: data.payloadHash,
          result: validateCommandExecutionResult(data.result),
        };
      } catch {
        throw new SiteCommandReceiptStoreError();
      }
    },
  };
}
