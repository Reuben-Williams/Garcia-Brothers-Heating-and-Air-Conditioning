import "server-only";

import { createHash, randomUUID } from "node:crypto";

import {
  validateCommandExecutionResult,
  type CommandExecutionResult,
  type InstallationClient,
  type InstallationCommandEnvelope,
} from "./installation-client.js";

export interface SiteCommandHandler {
  type: string;
  version: number;
  /** External side effects must independently honor idempotencyKey across crash takeovers. */
  execute(input: {
    commandId: string;
    idempotencyKey: string;
    attempt: number;
    payload: Record<string, unknown>;
  }): Promise<CommandExecutionResult>;
}

export type CommandReservation =
  | { status: "acquired"; generation: number }
  | { status: "in_progress" }
  | { status: "conflict" }
  | { status: "attempt_completed"; result: CommandExecutionResult }
  | { status: "terminal_completed"; result: CommandExecutionResult };

export interface CommandExecutionOwnership {
  installationId: string;
  idempotencyKey: string;
  commandId: string;
  semanticDigest: string;
  attempt: number;
  executionToken: string;
  generation: number;
}

export interface CommandExecutionStore {
  /** Atomically acquires a new attempt or reclaims only an expired reservation. */
  reserve(input: {
    installationId: string;
    idempotencyKey: string;
    commandId: string;
    semanticDigest: string;
    attempt: number;
    executionToken: string;
    reservationExpiresAt: string;
  }): Promise<CommandReservation>;
  /** Persists an attempt result only while token and generation still own the reservation. */
  complete(input: CommandExecutionOwnership & {
    result: CommandExecutionResult;
  }): Promise<boolean>;
  /** Releases only while token and generation still own the reservation. */
  release(input: CommandExecutionOwnership): Promise<boolean>;
}

export class CommandExecutionConflictError extends Error {
  readonly code = "idempotency_payload_mismatch";

  constructor() {
    super("Command idempotency evidence conflicts with the leased command");
    this.name = "CommandExecutionConflictError";
  }
}

export class CommandExecutionOwnershipError extends Error {
  readonly code = "command_execution_ownership_lost";

  constructor() {
    super("Command execution reservation ownership was lost");
    this.name = "CommandExecutionOwnershipError";
  }
}

function canonicalJson(value: unknown): string {
  if (value === null || typeof value === "string" || typeof value === "boolean") {
    return JSON.stringify(value);
  }
  if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${canonicalJson(record[key])}`)
      .join(",")}}`;
  }
  throw new TypeError("Command payload must contain only JSON values");
}

function semanticDigest(command: InstallationCommandEnvelope): string {
  return createHash("sha256")
    .update(canonicalJson({
      type: command.type,
      version: command.version,
      payload: command.payload,
    }), "utf8")
    .digest("hex");
}

function terminalError(errorCode: string): CommandExecutionResult {
  return {
    outcome: "failed",
    errorCode,
    evidence: { version: 1, codes: [], metrics: {}, flags: {}, digests: {} },
  };
}

export function createInstallationWorker(input: {
  installationId: string;
  client: Pick<InstallationClient, "pullCommands" | "acknowledgeResult">;
  store: CommandExecutionStore;
  handlers: readonly SiteCommandHandler[];
  pull?: { limit?: number; leaseSeconds?: number };
  now?: () => Date;
  executionToken?: () => string;
  reservationSeconds?: number;
}) {
  const now = input.now ?? (() => new Date());
  const nextExecutionToken = input.executionToken ?? randomUUID;
  const reservationSeconds = input.reservationSeconds ?? 30;
  if (
    !Number.isSafeInteger(reservationSeconds) ||
    reservationSeconds < 1 ||
    reservationSeconds > 300
  ) {
    throw new TypeError("Invalid command reservation duration");
  }
  const handlers = new Map<string, SiteCommandHandler>();
  const knownTypes = new Set<string>();
  for (const handler of input.handlers) {
    const key = `${handler.type}@${handler.version}`;
    if (handlers.has(key)) throw new TypeError("Duplicate command handler registration");
    handlers.set(key, handler);
    knownTypes.add(handler.type);
  }

  async function execute(command: InstallationCommandEnvelope): Promise<boolean> {
    const currentTime = now();
    const leaseExpiresAt = Date.parse(command.leaseExpiresAt);
    if (leaseExpiresAt <= currentTime.getTime()) return false;

    const digest = semanticDigest(command);
    const executionToken = nextExecutionToken();
    if (typeof executionToken !== "string" || executionToken.length < 1 || executionToken.length > 256) {
      throw new TypeError("Invalid command execution token");
    }
    const reservationExpiresAt = new Date(Math.min(
      currentTime.getTime() + reservationSeconds * 1000,
      leaseExpiresAt,
    )).toISOString();
    const reservation = await input.store.reserve({
      installationId: input.installationId,
      idempotencyKey: command.idempotencyKey,
      commandId: command.id,
      semanticDigest: digest,
      attempt: command.attempt,
      executionToken,
      reservationExpiresAt,
    });
    if (reservation.status === "conflict") throw new CommandExecutionConflictError();
    if (reservation.status === "in_progress") return false;

    let result: CommandExecutionResult;
    if (
      reservation.status === "attempt_completed" ||
      reservation.status === "terminal_completed"
    ) {
      result = validateCommandExecutionResult(reservation.result);
    } else {
      const handler = handlers.get(`${command.type}@${command.version}`);
      if (!handler) {
        result = terminalError(
          knownTypes.has(command.type)
            ? "UNSUPPORTED_COMMAND_VERSION"
            : "UNSUPPORTED_COMMAND_TYPE",
        );
      } else {
        try {
          result = validateCommandExecutionResult(
            await handler.execute({
              commandId: command.id,
              idempotencyKey: command.idempotencyKey,
              attempt: command.attempt,
              payload: command.payload,
            }),
          );
        } catch {
          result = terminalError("COMMAND_EXECUTION_FAILED");
        }
      }
      const completed = await input.store.complete({
        installationId: input.installationId,
        idempotencyKey: command.idempotencyKey,
        commandId: command.id,
        semanticDigest: digest,
        attempt: command.attempt,
        executionToken,
        generation: reservation.generation,
        result,
      });
      if (!completed) throw new CommandExecutionOwnershipError();
    }
    await input.client.acknowledgeResult({
      commandId: command.id,
      attempt: command.attempt,
      leaseToken: command.leaseToken,
      ...result,
    });
    return true;
  }

  async function runOnce(): Promise<{ pulled: number; acknowledged: number }> {
    const commands = await input.client.pullCommands(input.pull);
    let acknowledged = 0;
    for (const command of commands) {
      if (await execute(command)) acknowledged += 1;
    }
    return { pulled: commands.length, acknowledged };
  }

  return {
    runOnce,
    wake: async (): Promise<void> => {
      await runOnce();
    },
  };
}
