import "server-only";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const SITE_KEY_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

export type SiteDataPlaneSiteUuid = string & {
  readonly __siteDataPlaneSiteUuid: unique symbol;
};

export interface SiteDataPlaneIdentityStore {
  getSiteIdentity(siteId: SiteDataPlaneSiteUuid): Promise<{
    siteId: SiteDataPlaneSiteUuid;
    siteKey: string;
  }>;
}

export interface SiteDataPlaneRpcClient {
  rpc(
    name: string,
    args: Record<string, unknown>,
  ): PromiseLike<{ data: unknown; error: { message?: string } | null }>;
}

export class SiteDataPlaneIdentityError extends Error {
  readonly code = "site_data_plane_identity_mismatch";

  constructor() {
    super("site_data_plane_identity_mismatch");
    this.name = "SiteDataPlaneIdentityError";
  }
}

function mismatch(): never {
  throw new SiteDataPlaneIdentityError();
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function hasExactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join(",") === [...keys].sort().join(",");
}

export function parseSiteDataPlaneSiteUuid(
  value: unknown,
  options: { centralInstallationId?: string } = {},
): SiteDataPlaneSiteUuid {
  if (
    typeof value !== "string" ||
    !UUID_PATTERN.test(value) ||
    value.toLowerCase() === options.centralInstallationId?.toLowerCase()
  ) {
    return mismatch();
  }
  return value.toLowerCase() as SiteDataPlaneSiteUuid;
}

export function parseExpectedSiteKey(value: unknown): string {
  if (
    typeof value !== "string" ||
    value.length < 1 ||
    value.length > 128 ||
    !SITE_KEY_PATTERN.test(value)
  ) {
    return mismatch();
  }
  return value;
}

export function createSupabaseSiteDataPlaneIdentityStore(
  client: SiteDataPlaneRpcClient,
): SiteDataPlaneIdentityStore {
  return {
    async getSiteIdentity(siteId) {
      const normalizedSiteId = parseSiteDataPlaneSiteUuid(siteId);
      let response: Awaited<ReturnType<SiteDataPlaneRpcClient["rpc"]>>;
      try {
        response = await client.rpc("builder_get_runtime_site_identity", {
          p_site_id: normalizedSiteId,
        });
      } catch {
        return mismatch();
      }
      const value = response.data;
      if (
        response.error ||
        !isRecord(value) ||
        !hasExactKeys(value, ["version", "siteId", "siteKey"]) ||
        value.version !== 1 ||
        typeof value.siteId !== "string" ||
        typeof value.siteKey !== "string"
      ) {
        return mismatch();
      }
      return {
        siteId: parseSiteDataPlaneSiteUuid(value.siteId),
        siteKey: parseExpectedSiteKey(value.siteKey),
      };
    },
  };
}
