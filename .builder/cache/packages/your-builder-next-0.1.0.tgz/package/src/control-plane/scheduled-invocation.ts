import "server-only";

import type {
  SiteInstallationRuntime,
  SiteInstallationRuntimeResult,
} from "./site-runtime.js";

export class SiteInstallationInvocationTimeoutError extends Error {
  readonly code = "site_installation_invocation_timeout";

  constructor() {
    super("site_installation_invocation_timeout");
    this.name = "SiteInstallationInvocationTimeoutError";
  }
}

export async function runScheduledInvocation(
  runtime: SiteInstallationRuntime,
  options: { timeoutSeconds: number },
): Promise<SiteInstallationRuntimeResult> {
  if (
    !Number.isSafeInteger(options.timeoutSeconds) ||
    options.timeoutSeconds < 1 ||
    options.timeoutSeconds > 299
  ) {
    throw new TypeError("Scheduled invocation timeout must be between 1 and 299 seconds");
  }
  const abort = new AbortController();
  let timeout: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      runtime.runScheduled({ signal: abort.signal }),
      new Promise<never>((_resolve, reject) => {
        timeout = setTimeout(() => {
          const error = new SiteInstallationInvocationTimeoutError();
          abort.abort(error);
          reject(error);
        }, options.timeoutSeconds * 1_000);
      }),
    ]);
  } finally {
    if (timeout !== undefined) clearTimeout(timeout);
  }
}
