import "server-only";

import {
  parseInstallationManifest,
  parseSanitizedHealthReport,
  type InstallationManifestInput,
  type SanitizedHealthReport,
} from "@your-builder/entitlements/trust";

const SAFE_IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._:/+@-]{0,127}$/;
const SAFE_ERROR_CODE = /^[A-Z][A-Z0-9_]{0,63}$/;
const MAX_SQL_INTEGER = 9_999_999_999;

export interface SiteQueueHealth {
  depth: number;
  oldestAgeSeconds: number | null;
  deadLetters: number;
}

export interface SiteHealthSource {
  probeDurableStore(): Promise<boolean>;
  readQueues(): Promise<Record<string, SiteQueueHealth>>;
  probeIntegrations(): Promise<Record<string, "connected" | "degraded" | "disconnected">>;
  readEntitlementSnapshotAgeSeconds?(): Promise<number | null>;
  readBackupAgeSeconds?(): Promise<number | null>;
}

export interface BuildSiteHealthReportInput {
  installationManifest: InstallationManifestInput;
  workerVersion: string | null;
  runtimeInitialized: boolean;
  scheduledExecutionSucceeded: boolean;
  healthSource: SiteHealthSource;
  runtimeErrorCodes: readonly string[];
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function isAge(value: unknown): value is number | null {
  return value === null || (
    Number.isSafeInteger(value) && (value as number) >= 0 && (value as number) <= MAX_SQL_INTEGER
  );
}

function parseQueues(value: unknown): Record<string, SiteQueueHealth> {
  if (!isRecord(value)) throw new TypeError("invalid_queue_health");
  const entries = Object.entries(value);
  if (entries.length > 256) throw new TypeError("invalid_queue_health");
  for (const [key, entry] of entries) {
    if (
      !SAFE_IDENTIFIER.test(key) ||
      !isRecord(entry) ||
      Object.keys(entry).sort().join(",") !== "deadLetters,depth,oldestAgeSeconds" ||
      !isAge(entry.depth) ||
      entry.depth === null ||
      !isAge(entry.oldestAgeSeconds) ||
      !isAge(entry.deadLetters) ||
      entry.deadLetters === null
    ) {
      throw new TypeError("invalid_queue_health");
    }
  }
  return value as Record<string, SiteQueueHealth>;
}

function parseIntegrations(
  value: unknown,
): Record<string, "connected" | "degraded" | "disconnected"> {
  if (!isRecord(value)) throw new TypeError("invalid_integration_health");
  const entries = Object.entries(value);
  if (
    entries.length > 256 ||
    entries.some(([key, state]) =>
      !SAFE_IDENTIFIER.test(key) ||
      (state !== "connected" && state !== "degraded" && state !== "disconnected"))
  ) {
    throw new TypeError("invalid_integration_health");
  }
  return value as Record<string, "connected" | "degraded" | "disconnected">;
}

function safeErrorCodes(values: readonly string[]): string[] {
  return [...new Set(values.filter((value) => SAFE_ERROR_CODE.test(value)))].slice(0, 64);
}

export async function buildSiteHealthReport(
  input: BuildSiteHealthReportInput,
): Promise<SanitizedHealthReport> {
  const manifest = parseInstallationManifest(input.installationManifest);
  const errors = safeErrorCodes(input.runtimeErrorCodes);
  let durableStoreAvailable = false;
  let queues: Record<string, SiteQueueHealth> = {};
  let integrations: Record<string, "connected" | "degraded" | "disconnected"> = {};
  let entitlementSnapshotAgeSeconds: number | null = null;
  let backupAgeSeconds: number | null = null;

  try {
    durableStoreAvailable = await input.healthSource.probeDurableStore();
    if (durableStoreAvailable !== true) errors.push("DURABLE_STORE_UNAVAILABLE");
  } catch {
    errors.push("DURABLE_STORE_UNAVAILABLE");
  }
  try {
    queues = parseQueues(await input.healthSource.readQueues());
  } catch {
    errors.push("QUEUE_SOURCE_UNAVAILABLE");
  }
  try {
    integrations = parseIntegrations(await input.healthSource.probeIntegrations());
  } catch {
    errors.push("INTEGRATION_SOURCE_UNAVAILABLE");
  }
  if (input.healthSource.readEntitlementSnapshotAgeSeconds) {
    try {
      const age = await input.healthSource.readEntitlementSnapshotAgeSeconds();
      if (!isAge(age)) throw new TypeError("invalid_entitlement_age");
      entitlementSnapshotAgeSeconds = age;
    } catch {
      errors.push("ENTITLEMENT_SOURCE_UNAVAILABLE");
    }
  }
  if (input.healthSource.readBackupAgeSeconds) {
    try {
      const age = await input.healthSource.readBackupAgeSeconds();
      if (!isAge(age)) throw new TypeError("invalid_backup_age");
      backupAgeSeconds = age;
    } catch {
      errors.push("BACKUP_SOURCE_UNAVAILABLE");
    }
  }
  if (!input.scheduledExecutionSucceeded && errors.length === 0) {
    errors.push("SCHEDULED_EXECUTION_FAILED");
  }
  if (
    input.workerVersion !== null &&
    manifest.workerVersion !== undefined &&
    input.workerVersion !== manifest.workerVersion
  ) {
    errors.push("WORKER_VERSION_MISMATCH");
  }

  const boundedErrors = safeErrorCodes(errors);
  const healthy = input.runtimeInitialized &&
    input.scheduledExecutionSucceeded &&
    durableStoreAvailable &&
    boundedErrors.length === 0;
  const worker: SanitizedHealthReport["worker"] = {
    status: healthy ? "healthy" : input.runtimeInitialized ? "degraded" : "stopped",
  };
  if (
    healthy &&
    input.workerVersion !== null &&
    manifest.workerVersion !== undefined &&
    input.workerVersion === manifest.workerVersion
  ) {
    worker.version = input.workerVersion;
  }

  return parseSanitizedHealthReport({
    manifestVersion: manifest.version,
    packages: structuredClone(manifest.packages),
    schemas: structuredClone(manifest.schemas),
    worker,
    queues,
    integrations,
    entitlementSnapshotAgeSeconds,
    backupAgeSeconds,
    errorCodes: boundedErrors,
  });
}
