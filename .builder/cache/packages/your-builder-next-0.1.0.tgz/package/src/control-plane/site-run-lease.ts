import "server-only";

import {
  parseExpectedSiteKey,
  parseSiteDataPlaneSiteUuid,
  type SiteDataPlaneRpcClient,
  type SiteDataPlaneSiteUuid,
} from "./site-data-plane-identity.js";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const DECIMAL_PATTERN = /^[1-9][0-9]{0,18}$/;
const MAX_SIGNED_BIGINT = "9223372036854775807";

export interface RunLeaseIdentity {
  siteId: SiteDataPlaneSiteUuid;
  expectedSiteKey: string;
  installationId: string;
  leaseOwner: string;
}

export interface RunLeaseResult {
  version: 1;
  acquired: boolean;
  siteId: SiteDataPlaneSiteUuid;
  installationId: string;
  leaseOwner: string | null;
  fencingToken: string | null;
  leaseExpiresAt: string | null;
}

export interface SiteInstallationRunLeaseStore {
  acquire(input: RunLeaseIdentity & { leaseSeconds: number }): Promise<RunLeaseResult>;
  renew(input: RunLeaseIdentity & {
    fencingToken: string;
    leaseSeconds: number;
  }): Promise<RunLeaseResult>;
  release(input: RunLeaseIdentity & { fencingToken: string }): Promise<boolean>;
}

export class SiteInstallationRunLeaseError extends Error {
  readonly code = "site_installation_run_lease_error";

  constructor() {
    super("site_installation_run_lease_error");
    this.name = "SiteInstallationRunLeaseError";
  }
}

function invalid(): never {
  throw new SiteInstallationRunLeaseError();
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function hasExactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join(",") === [...keys].sort().join(",");
}

function parseUuid(value: unknown): string {
  if (typeof value !== "string" || !UUID_PATTERN.test(value)) return invalid();
  return value.toLowerCase();
}

function parseLeaseSeconds(value: unknown): number {
  if (!Number.isSafeInteger(value) || (value as number) < 60 || (value as number) > 300) {
    return invalid();
  }
  return value as number;
}

export function parseFencingToken(value: unknown): string {
  if (
    typeof value !== "string" ||
    !DECIMAL_PATTERN.test(value) ||
    (value.length === MAX_SIGNED_BIGINT.length && value > MAX_SIGNED_BIGINT)
  ) {
    return invalid();
  }
  return value;
}

function validateIdentity(input: RunLeaseIdentity): RunLeaseIdentity {
  return {
    siteId: parseSiteDataPlaneSiteUuid(input.siteId),
    expectedSiteKey: parseExpectedSiteKey(input.expectedSiteKey),
    installationId: parseUuid(input.installationId),
    leaseOwner: parseUuid(input.leaseOwner),
  };
}

function parseLeaseResult(value: unknown, expected: RunLeaseIdentity): RunLeaseResult {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, [
      "version",
      "acquired",
      "siteId",
      "installationId",
      "leaseOwner",
      "fencingToken",
      "leaseExpiresAt",
    ]) ||
    value.version !== 1 ||
    typeof value.acquired !== "boolean"
  ) {
    return invalid();
  }
  const siteId = parseSiteDataPlaneSiteUuid(value.siteId);
  const installationId = parseUuid(value.installationId);
  if (siteId !== expected.siteId || installationId !== expected.installationId) return invalid();
  if (!value.acquired) {
    if (value.leaseOwner !== null || value.fencingToken !== null || value.leaseExpiresAt !== null) {
      return invalid();
    }
    return {
      version: 1,
      acquired: false,
      siteId,
      installationId,
      leaseOwner: null,
      fencingToken: null,
      leaseExpiresAt: null,
    };
  }
  const leaseOwner = parseUuid(value.leaseOwner);
  if (
    leaseOwner !== expected.leaseOwner ||
    typeof value.leaseExpiresAt !== "string" ||
    !Number.isFinite(Date.parse(value.leaseExpiresAt))
  ) {
    return invalid();
  }
  const fencingToken = parseFencingToken(value.fencingToken);
  return {
    version: 1,
    acquired: true,
    siteId,
    installationId,
    leaseOwner,
    fencingToken,
    leaseExpiresAt: value.leaseExpiresAt,
  };
}

async function rpc(
  client: SiteDataPlaneRpcClient,
  name: string,
  args: Record<string, unknown>,
): Promise<unknown> {
  try {
    const response = await client.rpc(name, args);
    if (response.error) return invalid();
    return response.data;
  } catch (error) {
    if (error instanceof SiteInstallationRunLeaseError) throw error;
    return invalid();
  }
}

export function createSupabaseSiteInstallationRunLeaseStore(
  client: SiteDataPlaneRpcClient,
): SiteInstallationRunLeaseStore {
  return {
    async acquire(input) {
      const identity = validateIdentity(input);
      const leaseSeconds = parseLeaseSeconds(input.leaseSeconds);
      return parseLeaseResult(await rpc(client, "builder_acquire_installation_worker_lease", {
        p_site_id: identity.siteId,
        p_expected_site_key: identity.expectedSiteKey,
        p_installation_id: identity.installationId,
        p_lease_owner: identity.leaseOwner,
        p_lease_seconds: leaseSeconds,
      }), identity);
    },

    async renew(input) {
      const identity = validateIdentity(input);
      const fencingToken = parseFencingToken(input.fencingToken);
      const leaseSeconds = parseLeaseSeconds(input.leaseSeconds);
      return parseLeaseResult(await rpc(client, "builder_renew_installation_worker_lease", {
        p_site_id: identity.siteId,
        p_expected_site_key: identity.expectedSiteKey,
        p_installation_id: identity.installationId,
        p_lease_owner: identity.leaseOwner,
        p_fencing_token: fencingToken,
        p_lease_seconds: leaseSeconds,
      }), identity);
    },

    async release(input) {
      const identity = validateIdentity(input);
      const fencingToken = parseFencingToken(input.fencingToken);
      const value = await rpc(client, "builder_release_installation_worker_lease", {
        p_site_id: identity.siteId,
        p_expected_site_key: identity.expectedSiteKey,
        p_installation_id: identity.installationId,
        p_lease_owner: identity.leaseOwner,
        p_fencing_token: fencingToken,
      });
      if (typeof value !== "boolean") return invalid();
      return value;
    },
  };
}
