import "server-only";

import { createHash } from "node:crypto";

import type {
  CommandExecutionResult,
  InstallationCommandEvidence,
} from "./installation-client.js";
import type { SiteCommandReceiptStore } from "./idempotency-store.js";

const SAFE_CODE = /^[A-Z][A-Z0-9_]{0,63}$/;
const SAFE_KEY = /^[A-Za-z0-9][A-Za-z0-9._:/+@-]{0,63}$/;
const SHA256 = /^[a-f0-9]{64}$/;
const MAX_EVIDENCE_ENTRIES = 64;
const COMPENSATION_SUFFIX = ".compensate";
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const FENCING_TOKEN = /^[1-9][0-9]{0,18}$/;
const MAX_SIGNED_BIGINT = "9223372036854775807";

export interface SiteCommandLeaseContext {
  readonly siteId: string;
  readonly installationId: string;
  readonly leaseOwner: string;
  readonly fencingToken: string;
  readonly leaseExpiresAt: string;
}

export interface SiteCommandExecutionContext {
  readonly signal: AbortSignal;
  readonly lease: SiteCommandLeaseContext;
  readonly validateLease: () => Promise<void>;
}

export interface SiteCommandHandler<TPayload = unknown> {
  type: string;
  version: number;
  /** Site effects must use commandId for idempotency and enforce the fencing token. */
  idempotency: "commandId";
  validate(payload: unknown): TPayload;
  execute(input: {
    commandId: string;
    idempotencyKey: string;
    payload: TPayload;
    signal: AbortSignal;
    lease: SiteCommandLeaseContext;
  }): Promise<
    | { resultCode: string; evidence: Record<string, unknown>; outcome?: "succeeded" }
    | {
        outcome: "retry";
        errorCode: string;
        retryAt: string;
        evidence: Record<string, unknown>;
      }
  >;
  compensate?: (input: {
    commandId: string;
    evidence: Record<string, unknown>;
    signal: AbortSignal;
    lease: SiteCommandLeaseContext;
  }) => Promise<{ resultCode: string }>;
}

export interface SiteCommandInput {
  id: string;
  type: string;
  version: number;
  payload: Record<string, unknown>;
  idempotencyKey: string;
}

function canonicalJson(value: unknown): string {
  if (value === null || typeof value === "string" || typeof value === "boolean") {
    return JSON.stringify(value);
  }
  if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record).sort().map((key) =>
      `${JSON.stringify(key)}:${canonicalJson(record[key])}`).join(",")}}`;
  }
  throw new TypeError("Command payload must contain only JSON values");
}

function payloadHash(input: SiteCommandInput): string {
  return createHash("sha256")
    .update(canonicalJson({ type: input.type, version: input.version, payload: input.payload }), "utf8")
    .digest("hex");
}

function emptyEvidence(): InstallationCommandEvidence {
  return { version: 1, codes: [], metrics: {}, flags: {}, digests: {} };
}

function failure(errorCode: string): CommandExecutionResult {
  return { outcome: "failed", errorCode, evidence: emptyEvidence() };
}

function throwAbortReason(signal: AbortSignal): never {
  if (signal.reason instanceof Error) throw signal.reason;
  throw new Error("Site command execution was aborted");
}

function assertExecutionContext(
  context: SiteCommandExecutionContext | undefined,
  expectedSiteId: string,
): asserts context is SiteCommandExecutionContext {
  const lease = context?.lease;
  if (
    !context ||
    !context.signal ||
    typeof context.signal.aborted !== "boolean" ||
    typeof context.signal.addEventListener !== "function" ||
    typeof context.validateLease !== "function" ||
    !lease ||
    lease.siteId !== expectedSiteId ||
    !UUID.test(lease.siteId) ||
    !UUID.test(lease.installationId) ||
    !UUID.test(lease.leaseOwner) ||
    !FENCING_TOKEN.test(lease.fencingToken) ||
    (lease.fencingToken.length === MAX_SIGNED_BIGINT.length &&
      lease.fencingToken > MAX_SIGNED_BIGINT) ||
    !Number.isFinite(Date.parse(lease.leaseExpiresAt))
  ) {
    throw new TypeError("Site command execution requires an active lease context");
  }
  if (context.signal.aborted) throwAbortReason(context.signal);
}

function safeEntries(value: unknown): [string, unknown][] {
  if (!value || Array.isArray(value) || typeof value !== "object") return [];
  return Object.entries(value as Record<string, unknown>)
    .filter(([key]) => SAFE_KEY.test(key))
    .slice(0, MAX_EVIDENCE_ENTRIES);
}

export function sanitizeCommandEvidence(value: Record<string, unknown>): InstallationCommandEvidence {
  const codes = Array.isArray(value.codes)
    ? value.codes.filter((code): code is string => typeof code === "string" && SAFE_CODE.test(code))
      .slice(0, MAX_EVIDENCE_ENTRIES)
    : [];
  const metrics = Object.fromEntries(safeEntries(value.metrics).filter(([, metric]) =>
    Number.isSafeInteger(metric) && (metric as number) >= 0 && (metric as number) <= 1_000_000_000));
  const flags = Object.fromEntries(safeEntries(value.flags).filter(([, flag]) => typeof flag === "boolean"));
  const digests = Object.fromEntries(safeEntries(value.digests).filter(([, digest]) =>
    typeof digest === "string" && SHA256.test(digest)));
  return { version: 1, codes, metrics, flags, digests } as InstallationCommandEvidence;
}

async function runHandler<TPayload>(
  handler: SiteCommandHandler<TPayload>,
  command: SiteCommandInput,
  now: () => Date,
  context: SiteCommandExecutionContext,
): Promise<CommandExecutionResult> {
  let payload: TPayload;
  try {
    payload = handler.validate(command.payload);
  } catch {
    return failure("INVALID_COMMAND_PAYLOAD");
  }
  try {
    const output = await handler.execute({
      commandId: command.id,
      idempotencyKey: command.idempotencyKey,
      payload,
      signal: context.signal,
      lease: context.lease,
    });
    if (context.signal.aborted) throwAbortReason(context.signal);
    if (output.outcome === "retry") {
      const evidence = sanitizeCommandEvidence(output.evidence);
      if (
        !SAFE_CODE.test(output.errorCode) ||
        !Number.isFinite(Date.parse(output.retryAt)) ||
        new Date(output.retryAt).toISOString() !== output.retryAt ||
        Date.parse(output.retryAt) <= now().getTime()
      ) return failure("INVALID_HANDLER_RESULT");
      return {
        outcome: "retry",
        errorCode: output.errorCode,
        retryAt: output.retryAt,
        evidence,
      };
    }
    if (!SAFE_CODE.test(output.resultCode) || !output.evidence || typeof output.evidence !== "object") {
      return failure("INVALID_HANDLER_RESULT");
    }
    return {
      outcome: "succeeded",
      resultCode: output.resultCode,
      evidence: sanitizeCommandEvidence(output.evidence),
    };
  } catch {
    if (context.signal.aborted) throwAbortReason(context.signal);
    return failure("COMMAND_EXECUTION_FAILED");
  }
}

async function runCompensator(
  handler: SiteCommandHandler<any>,
  command: SiteCommandInput,
  context: SiteCommandExecutionContext,
): Promise<CommandExecutionResult> {
  if (typeof handler.compensate !== "function") {
    return failure("COMPENSATOR_UNAVAILABLE");
  }
  const commandId = command.payload.commandId;
  const rawEvidence = command.payload.evidence;
  if (
    typeof commandId !== "string" ||
    !UUID.test(commandId) ||
    !rawEvidence ||
    Array.isArray(rawEvidence) ||
    typeof rawEvidence !== "object"
  ) {
    return failure("INVALID_COMMAND_PAYLOAD");
  }
  const evidence = sanitizeCommandEvidence(rawEvidence as Record<string, unknown>);
  if (canonicalJson(rawEvidence) !== canonicalJson(evidence)) {
    return failure("INVALID_COMMAND_PAYLOAD");
  }
  try {
    const output = await handler.compensate({
      commandId,
      evidence: structuredClone(evidence) as unknown as Record<string, unknown>,
      signal: context.signal,
      lease: context.lease,
    });
    if (context.signal.aborted) throwAbortReason(context.signal);
    if (!SAFE_CODE.test(output.resultCode)) return failure("INVALID_HANDLER_RESULT");
    return {
      outcome: "succeeded",
      resultCode: output.resultCode,
      evidence: emptyEvidence(),
    };
  } catch {
    if (context.signal.aborted) throwAbortReason(context.signal);
    return failure("COMMAND_EXECUTION_FAILED");
  }
}

export function createSiteCommandExecutor(input: {
  siteId: string;
  handlers: readonly SiteCommandHandler<any>[];
  store: SiteCommandReceiptStore;
  now?: () => Date;
}) {
  const handlers = new Map<string, SiteCommandHandler<any>>();
  const knownTypes = new Set<string>();
  for (const handler of input.handlers) {
    if (handler.idempotency !== "commandId") {
      throw new TypeError("Site command handlers must be idempotent on commandId");
    }
    const key = `${handler.type}@${handler.version}`;
    if (handlers.has(key)) throw new TypeError("Duplicate site command handler registration");
    handlers.set(key, handler);
    knownTypes.add(handler.type);
  }
  const now = input.now ?? (() => new Date());

  return {
    async execute(
      command: SiteCommandInput,
      context: SiteCommandExecutionContext,
    ): Promise<CommandExecutionResult> {
      assertExecutionContext(context, input.siteId);
      let digest: string;
      try {
        digest = payloadHash(command);
      } catch {
        return failure("INVALID_COMMAND_PAYLOAD");
      }
      const receipt = {
        siteId: input.siteId,
        commandId: command.id,
        idempotencyKey: command.idempotencyKey,
        type: command.type,
        version: command.version,
        payloadHash: digest,
      };
      const reservation = await input.store.reserve(receipt);
      assertExecutionContext(context, input.siteId);
      if (reservation.status !== "acquired") {
        await context.validateLease();
        assertExecutionContext(context, input.siteId);
      }
      if (reservation.status === "replay") return reservation.result;
      if (reservation.status === "conflict") return failure("IDEMPOTENCY_CONFLICT");
      if (reservation.status === "in_progress") {
        return {
          outcome: "retry",
          errorCode: "COMMAND_IN_PROGRESS",
          retryAt: reservation.retryAt,
          evidence: emptyEvidence(),
        };
      }

      const isCompensation = command.type.endsWith(COMPENSATION_SUFFIX);
      const baseType = isCompensation
        ? command.type.slice(0, -COMPENSATION_SUFFIX.length)
        : command.type;
      const handler = handlers.get(`${baseType}@${command.version}`);
      const result = handler
        ? isCompensation
          ? await runCompensator(handler, command, context)
          : await runHandler(handler, command, now, context)
        : failure(knownTypes.has(baseType)
          ? "UNSUPPORTED_COMMAND_VERSION"
          : "UNSUPPORTED_COMMAND_TYPE");
      assertExecutionContext(context, input.siteId);
      await context.validateLease();
      assertExecutionContext(context, input.siteId);
      if (!await input.store.complete({ ...receipt, leaseToken: reservation.leaseToken, result })) {
        throw new Error("Site command receipt ownership was lost");
      }
      assertExecutionContext(context, input.siteId);
      return result;
    },
  };
}
