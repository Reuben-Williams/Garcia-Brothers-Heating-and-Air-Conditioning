import "server-only";

import { createPrivateKey, createPublicKey } from "node:crypto";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const KEY_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const BASE64URL_32_PATTERN = /^[A-Za-z0-9_-]{43}$/;
const PRIVATE_JWK_FIELDS = "alg,crv,d,kty,x";

export interface InstallationClientConfig {
  controlPlaneUrl: string;
  installationId: string;
  keyId: string;
  privateJwk: JsonWebKey;
}

export type InstallationConfigErrorCode = "invalid_installation_config";

export class InstallationConfigError extends Error {
  readonly code: InstallationConfigErrorCode = "invalid_installation_config";

  constructor() {
    super("Installation client configuration is invalid");
    this.name = "InstallationConfigError";
  }
}

function invalid(): never {
  throw new InstallationConfigError();
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function isCanonicalBase64Url32(value: unknown): value is string {
  if (typeof value !== "string" || !BASE64URL_32_PATTERN.test(value)) return false;
  try {
    const bytes = Buffer.from(value, "base64url");
    return bytes.byteLength === 32 && bytes.toString("base64url") === value;
  } catch {
    return false;
  }
}

export function parsePrivateEd25519Jwk(value: unknown): JsonWebKey {
  if (!isRecord(value) || Object.keys(value).sort().join(",") !== PRIVATE_JWK_FIELDS) {
    return invalid();
  }
  if (
    value.kty !== "OKP" ||
    value.crv !== "Ed25519" ||
    value.alg !== "EdDSA" ||
    !isCanonicalBase64Url32(value.x) ||
    !isCanonicalBase64Url32(value.d)
  ) {
    return invalid();
  }
  const privateJwk = {
    kty: "OKP",
    crv: "Ed25519",
    alg: "EdDSA",
    x: value.x,
    d: value.d,
  };
  try {
    const privateKey = createPrivateKey({ key: privateJwk, format: "jwk" });
    const derived = createPublicKey(privateKey).export({ format: "jwk" });
    if (derived.x !== value.x) return invalid();
  } catch {
    return invalid();
  }
  return privateJwk;
}

function parseControlPlaneUrl(value: unknown): string {
  if (typeof value !== "string" || value.trim() !== value || value.length > 2_048) {
    return invalid();
  }
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    return invalid();
  }
  const isLoopback =
    url.hostname === "localhost" ||
    url.hostname === "127.0.0.1" ||
    url.hostname === "[::1]";
  if (
    (url.protocol !== "https:" && !(url.protocol === "http:" && isLoopback)) ||
    url.username !== "" ||
    url.password !== "" ||
    url.search !== "" ||
    url.hash !== ""
  ) {
    return invalid();
  }
  return url.href.replace(/\/$/, "");
}

export function parseInstallationClientConfig(value: unknown): InstallationClientConfig {
  if (
    !isRecord(value) ||
    Object.keys(value).sort().join(",") !==
      "controlPlaneUrl,installationId,keyId,privateJwk"
  ) {
    return invalid();
  }
  const { controlPlaneUrl, installationId, keyId, privateJwk } = value;
  if (
    typeof installationId !== "string" ||
    !UUID_PATTERN.test(installationId) ||
    typeof keyId !== "string" ||
    !KEY_ID_PATTERN.test(keyId)
  ) {
    return invalid();
  }
  return {
    controlPlaneUrl: parseControlPlaneUrl(controlPlaneUrl),
    installationId,
    keyId,
    privateJwk: parsePrivateEd25519Jwk(privateJwk),
  };
}

export function loadInstallationClientConfig(
  env: Readonly<Record<string, string | undefined>> = process.env,
): InstallationClientConfig {
  const privateJwkText = env.BUILDER_INSTALLATION_PRIVATE_JWK;
  let privateJwk: unknown;
  try {
    privateJwk = typeof privateJwkText === "string" ? JSON.parse(privateJwkText) : undefined;
  } catch {
    return invalid();
  }
  return parseInstallationClientConfig({
    controlPlaneUrl: env.BUILDER_CONTROL_PLANE_URL,
    installationId: env.BUILDER_INSTALLATION_ID,
    keyId: env.BUILDER_INSTALLATION_KEY_ID,
    privateJwk,
  });
}
