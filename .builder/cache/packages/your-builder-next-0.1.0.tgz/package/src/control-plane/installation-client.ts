import "server-only";

import {
  INSTALLATION_REQUEST_HEADER_NAMES,
  MAX_INSTALLATION_COMMAND_PULL_LIMIT,
  parseSanitizedHealthReport,
  signInstallationRequest,
  type SanitizedHealthReport,
} from "@your-builder/entitlements/trust";

export type { SanitizedHealthReport } from "@your-builder/entitlements/trust";

import type { InstallationClientConfig } from "./config.js";
import { isEntitlementState, type EntitlementState } from "@your-builder/entitlements";
import { MODULE_IDS, type GrowthModuleId } from "@your-builder/feature-registry";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const SAFE_CODE_PATTERN = /^[A-Z][A-Z0-9_]{0,63}$/;
const KEY_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const SAFE_IDENTIFIER_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:/+@-]{0,127}$/;
const LOWERCASE_SHA256_PATTERN = /^[a-f0-9]{64}$/;
const STRICT_TIMESTAMP_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
const MAX_RESPONSE_BYTES = 1024 * 1024;
const MAX_JSONB_BYTES = 32 * 1024;
const MAX_EVIDENCE_ENTRIES = 64;
const BASE64URL_32_PATTERN = /^[A-Za-z0-9_-]{43}$/;
const encoder = new TextEncoder();
const decoder = new TextDecoder("utf-8", { fatal: true });

export interface InstallationCommandEnvelope {
  id: string;
  type: string;
  version: number;
  payload: Record<string, unknown>;
  idempotencyKey: string;
  createdAt: string;
  leaseToken: string;
  attempt: number;
  leaseExpiresAt: string;
}

export interface InstallationCommandEvidence {
  version: 1;
  codes: readonly string[];
  metrics: Readonly<Record<string, number>>;
  flags: Readonly<Record<string, boolean>>;
  digests: Readonly<Record<string, string>>;
}

export type CommandExecutionResult =
  | {
      outcome: "succeeded";
      resultCode: string;
      evidence: InstallationCommandEvidence;
    }
  | {
      outcome: "failed";
      errorCode: string;
      evidence: InstallationCommandEvidence;
    }
  | {
      outcome: "retry";
      errorCode: string;
      retryAt: string;
      evidence: InstallationCommandEvidence;
    };

export type InstallationClientErrorCode =
  | "invalid_request"
  | "network_error"
  | "http_error"
  | "response_too_large"
  | "invalid_response";

export class InstallationClientError extends Error {
  constructor(
    public readonly code: InstallationClientErrorCode,
    public readonly status?: number,
  ) {
    super(code);
    this.name = "InstallationClientError";
  }
}

export interface InstallationClientDependencies {
  fetch?: typeof globalThis.fetch;
  now?: () => Date;
  nonce?: () => string;
  maxAttempts?: number;
}

export type AcknowledgeCommandResultInput = CommandExecutionResult & {
  commandId: string;
  attempt: number;
  leaseToken: string;
};

export interface InstallationClient {
  pullCommands(input?: { limit?: number; leaseSeconds?: number }): Promise<InstallationCommandEnvelope[]>;
  acknowledgeResult(input: AcknowledgeCommandResultInput): Promise<void>;
  reportHealth(report: SanitizedHealthReport): Promise<void>;
  rotateCredential(input: {
    previousKeyId: string;
    newKeyId: string;
    publicJwk: JsonWebKey;
    overlapSeconds: number;
  }): Promise<{ acceptedKeyId: string }>;
  requestActivation(input: {
    commandId: string;
    action: "create" | "withdraw";
    moduleId: GrowthModuleId;
  }): Promise<InstallationActivationResult>;
}

export interface InstallationActivationResult {
  requestId: string;
  moduleId: GrowthModuleId;
  status: "requested" | "withdrawn" | "provisioning";
  entitlementState: EntitlementState;
  idempotent: boolean;
}

const MODULE_ID_SET = new Set<string>(Object.values(MODULE_IDS));

function parseActivationResult(value: unknown): InstallationActivationResult {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, ["requestId", "moduleId", "status", "entitlementState", "idempotent"]) ||
    typeof value.requestId !== "string" ||
    !UUID_PATTERN.test(value.requestId) ||
    typeof value.moduleId !== "string" ||
    !MODULE_ID_SET.has(value.moduleId) ||
    (value.status !== "requested" && value.status !== "withdrawn" && value.status !== "provisioning") ||
    !isEntitlementState(value.entitlementState) ||
    typeof value.idempotent !== "boolean"
  ) {
    throw new InstallationClientError("invalid_response");
  }
  return value as unknown as InstallationActivationResult;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function hasExactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join(",") === [...keys].sort().join(",");
}

function isTimestamp(value: unknown): value is string {
  return (
    typeof value === "string" &&
    STRICT_TIMESTAMP_PATTERN.test(value) &&
    Number.isFinite(Date.parse(value)) &&
    new Date(value).toISOString() === value
  );
}

function parseCommand(value: unknown): InstallationCommandEnvelope {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, [
      "id",
      "type",
      "version",
      "payload",
      "idempotencyKey",
      "createdAt",
      "leaseToken",
      "attempt",
      "leaseExpiresAt",
    ]) ||
    typeof value.id !== "string" ||
    !UUID_PATTERN.test(value.id) ||
    typeof value.type !== "string" ||
    !SAFE_IDENTIFIER_PATTERN.test(value.type) ||
    !Number.isSafeInteger(value.version) ||
    (value.version as number) < 1 ||
    !isRecord(value.payload) ||
    typeof value.idempotencyKey !== "string" ||
    !SAFE_IDENTIFIER_PATTERN.test(value.idempotencyKey) ||
    !isTimestamp(value.createdAt) ||
    typeof value.leaseToken !== "string" ||
    !UUID_PATTERN.test(value.leaseToken) ||
    !Number.isSafeInteger(value.attempt) ||
    (value.attempt as number) < 1 ||
    !isTimestamp(value.leaseExpiresAt)
  ) {
    throw new InstallationClientError("invalid_response");
  }
  return value as unknown as InstallationCommandEnvelope;
}

async function readBoundedResponse(response: Response): Promise<unknown> {
  const contentLength = response.headers.get("content-length");
  if (contentLength && /^\d+$/.test(contentLength) && Number(contentLength) > MAX_RESPONSE_BYTES) {
    throw new InstallationClientError("response_too_large");
  }
  if (!response.body) throw new InstallationClientError("invalid_response");

  const chunks: Uint8Array[] = [];
  let total = 0;
  const reader = response.body.getReader();
  try {
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      total += next.value.byteLength;
      if (total > MAX_RESPONSE_BYTES) {
        await reader.cancel().catch(() => undefined);
        throw new InstallationClientError("response_too_large");
      }
      chunks.push(next.value);
    }
  } catch (error) {
    if (error instanceof InstallationClientError) throw error;
    throw new InstallationClientError("invalid_response");
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return JSON.parse(decoder.decode(bytes));
  } catch {
    throw new InstallationClientError("invalid_response");
  }
}

function defaultNonce(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Buffer.from(bytes).toString("base64url");
}

function parseAccepted(value: unknown): void {
  if (!isRecord(value) || !hasExactKeys(value, ["accepted"]) || value.accepted !== true) {
    throw new InstallationClientError("invalid_response");
  }
}

function parseHealthAccepted(value: unknown): void {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, ["accepted", "reportId"]) ||
    value.accepted !== true ||
    typeof value.reportId !== "string" ||
    !UUID_PATTERN.test(value.reportId)
  ) {
    throw new InstallationClientError("invalid_response");
  }
}

function isSafeIdentifier(value: string, maxLength = 128): boolean {
  return value.length >= 1 && value.length <= maxLength && SAFE_IDENTIFIER_PATTERN.test(value);
}

function isNonNegativeSqlInteger(value: unknown): value is number {
  return Number.isSafeInteger(value) && (value as number) >= 0 && (value as number) <= 9_999_999_999;
}

function postgresJsonbText(value: unknown): string {
  if (value === null || typeof value === "boolean" || typeof value === "string") {
    return JSON.stringify(value);
  }
  if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(postgresJsonbText).join(", ")}]`;
  if (isRecord(value)) {
    return `{${Object.entries(value)
      .map(([key, child]) => `${JSON.stringify(key)}: ${postgresJsonbText(child)}`)
      .join(", ")}}`;
  }
  throw new TypeError("Value is not JSON-compatible");
}

function isSqlSizedJsonb(value: unknown, maximum: number): boolean {
  try {
    return Buffer.byteLength(postgresJsonbText(value), "utf8") <= maximum;
  } catch {
    return false;
  }
}

export function validateSanitizedHealthReport(value: unknown): SanitizedHealthReport {
  try {
    return parseSanitizedHealthReport(value);
  } catch {
    throw new InstallationClientError("invalid_request");
  }
}

function validatePublicEd25519Jwk(value: unknown): JsonWebKey {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, ["kty", "crv", "alg", "x"]) ||
    value.kty !== "OKP" ||
    value.crv !== "Ed25519" ||
    value.alg !== "EdDSA" ||
    typeof value.x !== "string" ||
    !BASE64URL_32_PATTERN.test(value.x)
  ) {
    throw new InstallationClientError("invalid_request");
  }
  try {
    const bytes = Buffer.from(value.x, "base64url");
    if (bytes.byteLength !== 32 || bytes.toString("base64url") !== value.x) {
      throw new InstallationClientError("invalid_request");
    }
  } catch (error) {
    if (error instanceof InstallationClientError) throw error;
    throw new InstallationClientError("invalid_request");
  }
  return value as JsonWebKey;
}

export function createInstallationClient(
  config: InstallationClientConfig,
  dependencies: InstallationClientDependencies = {},
): InstallationClient {
  const requestFetch = dependencies.fetch ?? globalThis.fetch;
  const now = dependencies.now ?? (() => new Date());
  const nonce = dependencies.nonce ?? defaultNonce;
  const maxAttempts = dependencies.maxAttempts ?? 3;
  if (!Number.isSafeInteger(maxAttempts) || maxAttempts < 1 || maxAttempts > 5) {
    throw new InstallationClientError("invalid_request");
  }

  async function post<T>(
    path: string,
    body: unknown,
    parse: (value: unknown) => T,
  ): Promise<T> {
    let bodyBytes: Uint8Array;
    try {
      bodyBytes = encoder.encode(JSON.stringify(body));
    } catch {
      throw new InstallationClientError("invalid_request");
    }
    const requestUrl = new URL(path, `${config.controlPlaneUrl}/`);

    for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
      const timestamp = now().toISOString();
      const requestNonce = nonce();
      const signed = await signInstallationRequest({
        installationId: config.installationId,
        keyId: config.keyId,
        method: "POST",
        path: requestUrl.pathname,
        timestamp,
        nonce: requestNonce,
        bodyBytes,
        privateJwk: config.privateJwk,
      });
      let response: Response;
      try {
        response = await requestFetch(requestUrl, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            [INSTALLATION_REQUEST_HEADER_NAMES.installationId]: signed.installationId,
            [INSTALLATION_REQUEST_HEADER_NAMES.keyId]: signed.keyId,
            [INSTALLATION_REQUEST_HEADER_NAMES.timestamp]: signed.timestamp,
            [INSTALLATION_REQUEST_HEADER_NAMES.nonce]: signed.nonce,
            [INSTALLATION_REQUEST_HEADER_NAMES.signature]: signed.signature,
          },
          body: bodyBytes.buffer as ArrayBuffer,
        });
      } catch {
        if (attempt < maxAttempts) continue;
        throw new InstallationClientError("network_error");
      }
      if (!response.ok) {
        if (response.status >= 500 && attempt < maxAttempts) continue;
        throw new InstallationClientError("http_error", response.status);
      }
      return parse(await readBoundedResponse(response));
    }
    throw new InstallationClientError("network_error");
  }

  return {
    async pullCommands(input = {}) {
      const limit = input.limit ?? 10;
      const leaseSeconds = input.leaseSeconds ?? 30;
      if (
        !Number.isSafeInteger(limit) ||
        limit < 1 ||
        limit > MAX_INSTALLATION_COMMAND_PULL_LIMIT ||
        !Number.isSafeInteger(leaseSeconds) ||
        leaseSeconds < 1 ||
        leaseSeconds > 300
      ) {
        throw new InstallationClientError("invalid_request");
      }
      return post("/api/platform/v1/installations/commands/pull", { limit, leaseSeconds }, (value) => {
        if (
          !isRecord(value) ||
          !hasExactKeys(value, ["commands"]) ||
          !Array.isArray(value.commands) ||
          value.commands.length > MAX_INSTALLATION_COMMAND_PULL_LIMIT
        ) {
          throw new InstallationClientError("invalid_response");
        }
        return value.commands.map(parseCommand);
      });
    },

    async acknowledgeResult(input) {
      if (!UUID_PATTERN.test(input.commandId)) {
        throw new InstallationClientError("invalid_request");
      }
      const { commandId, ...body } = input;
      validateCommandExecutionResult(
        input.outcome === "succeeded"
          ? { outcome: input.outcome, resultCode: input.resultCode, evidence: input.evidence }
          : input.outcome === "retry"
            ? {
                outcome: input.outcome,
                errorCode: input.errorCode,
                retryAt: input.retryAt,
                evidence: input.evidence,
              }
            : { outcome: input.outcome, errorCode: input.errorCode, evidence: input.evidence },
      );
      await post(
        `/api/platform/v1/installations/commands/${commandId}/result`,
        body,
        (value) => parseAccepted(value),
      );
    },

    async reportHealth(report) {
      await post(
        "/api/platform/v1/installations/health",
        validateSanitizedHealthReport(report),
        (value) => parseHealthAccepted(value),
      );
    },

    async rotateCredential(input) {
      if (
        !KEY_ID_PATTERN.test(input.previousKeyId) ||
        !KEY_ID_PATTERN.test(input.newKeyId) ||
        input.previousKeyId === input.newKeyId ||
        (config.keyId !== input.previousKeyId && config.keyId !== input.newKeyId) ||
        !Number.isSafeInteger(input.overlapSeconds) ||
        input.overlapSeconds < 1 ||
        input.overlapSeconds > 86_400
      ) {
        throw new InstallationClientError("invalid_request");
      }
      const rotation = {
        previousKeyId: input.previousKeyId,
        newKeyId: input.newKeyId,
        publicJwk: validatePublicEd25519Jwk(input.publicJwk),
        overlapSeconds: input.overlapSeconds,
      };
      return post("/api/platform/v1/installations/credentials/rotate", rotation, (value) => {
        if (
          !isRecord(value) ||
          !hasExactKeys(value, ["acceptedKeyId"]) ||
          typeof value.acceptedKeyId !== "string" ||
          !SAFE_IDENTIFIER_PATTERN.test(value.acceptedKeyId)
        ) {
          throw new InstallationClientError("invalid_response");
        }
        return { acceptedKeyId: value.acceptedKeyId };
      });
    },

    async requestActivation(input) {
      if (
        !UUID_PATTERN.test(input.commandId) ||
        (input.action !== "create" && input.action !== "withdraw") ||
        !MODULE_ID_SET.has(input.moduleId)
      ) {
        throw new InstallationClientError("invalid_request");
      }
      return post(
        "/api/platform/v1/installations/activation-requests",
        input,
        parseActivationResult,
      );
    },
  };
}

export function validateCommandExecutionResult(value: unknown): CommandExecutionResult {
  if (!isRecord(value) || !isRecord(value.evidence)) {
    throw new InstallationClientError("invalid_request");
  }
  const evidence = value.evidence;
  if (
    !hasExactKeys(evidence, ["version", "codes", "metrics", "flags", "digests"]) ||
    !isSqlSizedJsonb(evidence, MAX_JSONB_BYTES) ||
    evidence.version !== 1 ||
    !Array.isArray(evidence.codes) ||
    evidence.codes.length > MAX_EVIDENCE_ENTRIES ||
    !evidence.codes.every(
      (code) => typeof code === "string" && isSafeIdentifier(code, 64),
    ) ||
    !isRecord(evidence.metrics) ||
    Object.keys(evidence.metrics).length > MAX_EVIDENCE_ENTRIES ||
    !Object.keys(evidence.metrics).every((key) => isSafeIdentifier(key, 64)) ||
    !Object.values(evidence.metrics).every(
      (metric) => isNonNegativeSqlInteger(metric) && metric <= 1_000_000_000,
    ) ||
    !isRecord(evidence.flags) ||
    Object.keys(evidence.flags).length > MAX_EVIDENCE_ENTRIES ||
    !Object.keys(evidence.flags).every((key) => isSafeIdentifier(key, 64)) ||
    !Object.values(evidence.flags).every((flag) => typeof flag === "boolean") ||
    !isRecord(evidence.digests) ||
    Object.keys(evidence.digests).length > MAX_EVIDENCE_ENTRIES ||
    !Object.keys(evidence.digests).every((key) => isSafeIdentifier(key, 64)) ||
    !Object.values(evidence.digests).every(
      (digest) => typeof digest === "string" && LOWERCASE_SHA256_PATTERN.test(digest),
    )
  ) {
    throw new InstallationClientError("invalid_request");
  }
  if (
    value.outcome === "succeeded" &&
    hasExactKeys(value, ["outcome", "resultCode", "evidence"]) &&
    typeof value.resultCode === "string" &&
    SAFE_CODE_PATTERN.test(value.resultCode)
  ) {
    return value as unknown as CommandExecutionResult;
  }
  if (
    value.outcome === "failed" &&
    hasExactKeys(value, ["outcome", "errorCode", "evidence"]) &&
    typeof value.errorCode === "string" &&
    SAFE_CODE_PATTERN.test(value.errorCode)
  ) {
    return value as unknown as CommandExecutionResult;
  }
  if (
    value.outcome === "retry" &&
    hasExactKeys(value, ["outcome", "errorCode", "retryAt", "evidence"]) &&
    typeof value.errorCode === "string" &&
    SAFE_CODE_PATTERN.test(value.errorCode) &&
    isTimestamp(value.retryAt)
  ) {
    return value as unknown as CommandExecutionResult;
  }
  throw new InstallationClientError("invalid_request");
}
