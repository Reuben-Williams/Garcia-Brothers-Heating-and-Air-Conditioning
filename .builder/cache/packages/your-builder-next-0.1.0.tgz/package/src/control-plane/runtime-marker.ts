import "server-only";

import { createHash } from "node:crypto";

import {
  installationManifestSha256,
  parseSiteRuntimeMarker,
  SiteRuntimeMarkerValidationError,
  type InstallationManifestInput,
  type SiteRuntimeMarker,
} from "@your-builder/entitlements/trust";

import type { SiteCommandHandler } from "./command-executor.js";

const SAFE_IDENTIFIER_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:/+@-]{0,127}$/;

export interface CreateSiteRuntimeMarkerInput {
  siteDataPlaneSiteId: string;
  expectedSiteKey: string;
  installationManifest: InstallationManifestInput;
  handlers: readonly SiteCommandHandler<any>[];
  leaseSeconds: number;
  invocationTimeoutSeconds: number;
  workerVersion: string | null;
  reachabilityEvidenceRevision: string | null;
}

function invalid(): never {
  throw new SiteRuntimeMarkerValidationError();
}

export function siteCommandHandlerRegistrySha256(
  handlers: readonly SiteCommandHandler<any>[],
): string {
  const entries = handlers.map((handler) => {
    if (
      typeof handler.type !== "string" ||
      !SAFE_IDENTIFIER_PATTERN.test(handler.type) ||
      !Number.isSafeInteger(handler.version) ||
      handler.version < 1 ||
      handler.idempotency !== "commandId"
    ) {
      return invalid();
    }
    return { type: handler.type, version: handler.version, idempotency: handler.idempotency };
  }).sort((left, right) =>
    left.type.localeCompare(right.type) || left.version - right.version);
  if (new Set(entries.map((entry) => `${entry.type}@${entry.version}`)).size !== entries.length) {
    return invalid();
  }
  return createHash("sha256").update(JSON.stringify(entries), "utf8").digest("hex");
}

export function createSiteRuntimeMarker(input: CreateSiteRuntimeMarkerInput): SiteRuntimeMarker {
  const marker: Record<string, unknown> = {
    version: 1,
    siteDataPlaneSiteId: input.siteDataPlaneSiteId,
    expectedSiteKey: input.expectedSiteKey,
    installationManifestSha256: installationManifestSha256(input.installationManifest),
    configLoaderContract: "installation-client-config-v1",
    durableStoreContract: "supabase-command-receipts-v1",
    leaseContract: "site-installation-run-lease-v1",
    leaseSeconds: input.leaseSeconds,
    invocationTimeoutSeconds: input.invocationTimeoutSeconds,
    scheduledInvocationContract: "direct-in-process-v1",
    handlerRegistrySha256: siteCommandHandlerRegistrySha256(input.handlers),
    reachabilityEvidenceRevision: input.reachabilityEvidenceRevision,
  };
  if (input.workerVersion !== null) marker.workerVersion = input.workerVersion;
  return parseSiteRuntimeMarker(marker);
}

export { parseSiteRuntimeMarker, type SiteRuntimeMarker };
