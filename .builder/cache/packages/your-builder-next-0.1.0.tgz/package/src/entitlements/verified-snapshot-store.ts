import "server-only";

import type { EntitlementSnapshot } from "@your-builder/entitlements";

export const VERIFIED_SNAPSHOT_STORE_RPC = "builder_store_verified_entitlement_snapshot_v1" as const;

export interface VerifiedSnapshotStoreReceipt {
  readonly version: 1;
  readonly status: "stored" | "replayed";
  readonly snapshotId: string;
  readonly siteId: string;
  readonly installationId: string;
  readonly sequence: number;
  readonly digest: string;
}

export type PersistVerifiedSnapshot = (
  snapshot: EntitlementSnapshot,
) => Promise<VerifiedSnapshotStoreReceipt>;

export interface VerifiedSnapshotStoreRpcClient {
  readonly rpc: (
    name: typeof VERIFIED_SNAPSHOT_STORE_RPC,
    args: { readonly p_snapshot: EntitlementSnapshot },
  ) => PromiseLike<{ readonly data: unknown; readonly error: { readonly message?: string } | null }>;
}

export class VerifiedSnapshotStoreError extends Error {
  readonly code = "verified_snapshot_store_failed" as const;

  constructor() {
    super("Verified entitlement snapshot storage failed");
    this.name = "VerifiedSnapshotStoreError";
  }
}

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const DIGEST_PATTERN = /^[0-9a-f]{64}$/;
const RECEIPT_KEYS = Object.freeze([
  "version",
  "status",
  "snapshotId",
  "siteId",
  "installationId",
  "sequence",
  "digest",
].sort());

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function parseReceipt(
  value: unknown,
  snapshot: EntitlementSnapshot,
): VerifiedSnapshotStoreReceipt {
  if (!isRecord(value)) throw new VerifiedSnapshotStoreError();
  const keys = Object.keys(value).sort();
  if (
    keys.length !== RECEIPT_KEYS.length ||
    !keys.every((key, index) => key === RECEIPT_KEYS[index]) ||
    value.version !== 1 ||
    (value.status !== "stored" && value.status !== "replayed") ||
    typeof value.snapshotId !== "string" || !UUID_PATTERN.test(value.snapshotId) ||
    value.siteId !== snapshot.siteId ||
    value.installationId !== snapshot.installationId ||
    value.sequence !== snapshot.sequence ||
    typeof value.digest !== "string" || !DIGEST_PATTERN.test(value.digest)
  ) {
    throw new VerifiedSnapshotStoreError();
  }
  return Object.freeze(value as unknown as VerifiedSnapshotStoreReceipt);
}

export function createSupabaseVerifiedSnapshotStore(
  client: VerifiedSnapshotStoreRpcClient,
): PersistVerifiedSnapshot {
  return async (snapshot) => {
    try {
      const response = await client.rpc(VERIFIED_SNAPSHOT_STORE_RPC, { p_snapshot: snapshot });
      if (response.error) throw new VerifiedSnapshotStoreError();
      return parseReceipt(response.data, snapshot);
    } catch (error) {
      if (error instanceof VerifiedSnapshotStoreError) throw error;
      throw new VerifiedSnapshotStoreError();
    }
  };
}
