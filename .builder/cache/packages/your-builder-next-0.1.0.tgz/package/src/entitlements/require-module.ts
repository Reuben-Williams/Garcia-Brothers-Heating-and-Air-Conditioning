import "server-only";

import type { GrowthCapability } from "@your-builder/core";
import type { GrowthModuleId } from "@your-builder/feature-registry";
import {
  decideSnapshotAccess,
  verifyEntitlementSnapshot,
  type EntitlementSnapshotAction,
  type EntitlementSnapshotSigningKey,
} from "@your-builder/entitlements/server";
import { requireSiteCapability } from "./capability-authorization.js";
import type { PersistVerifiedSnapshot } from "./verified-snapshot-store.js";

export interface ModuleAccessResource {
  readonly type: string;
  readonly id: string;
}

export interface RequireModuleAccessInput {
  readonly token: string;
  readonly siteId: string;
  readonly installationId: string;
  readonly moduleId: GrowthModuleId;
  readonly action: EntitlementSnapshotAction;
  readonly capability: GrowthCapability;
  readonly resource?: ModuleAccessResource;
  readonly resolveSigningKey: (keyId: string) => Promise<EntitlementSnapshotSigningKey | null>;
  readonly persistVerifiedSnapshot: PersistVerifiedSnapshot;
  readonly checkSite: (siteId: string, capability: GrowthCapability) => Promise<boolean>;
  readonly checkRecord: (
    siteId: string,
    capability: GrowthCapability,
    resourceType: string,
    resourceId: string,
  ) => Promise<boolean>;
  readonly now?: Date;
}

export async function requireModuleAccess(input: RequireModuleAccessInput) {
  const snapshot = await verifyEntitlementSnapshot({
    token: input.token,
    expectedSiteId: input.siteId,
    expectedInstallationId: input.installationId,
    resolveSigningKey: input.resolveSigningKey,
    now: input.now,
  });
  try {
    await input.persistVerifiedSnapshot(snapshot);
  } catch {
    throw new Response("Module access temporarily unavailable", {
      status: 503,
      headers: {
        "content-type": "text/plain; charset=utf-8",
        "x-builder-health-code": "verified_snapshot_store_failed",
      },
    });
  }
  const decision = decideSnapshotAccess({
    snapshot,
    moduleId: input.moduleId,
    action: input.action,
    now: input.now,
  });
  if (!decision.allowed) {
    throw new Response("Module access denied", {
      status: 403,
      headers: { "content-type": "text/plain; charset=utf-8" },
    });
  }

  await requireSiteCapability({
    siteId: input.siteId,
    capability: input.capability,
    resource: input.resource,
    checkSite: input.checkSite,
    checkRecord: input.checkRecord,
  });
  return snapshot;
}
