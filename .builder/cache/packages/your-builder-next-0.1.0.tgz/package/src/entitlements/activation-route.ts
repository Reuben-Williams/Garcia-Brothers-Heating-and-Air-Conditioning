import "server-only";

import { canBuilderRole, type GrowthCapability } from "@your-builder/core";
import type { EntitlementState } from "@your-builder/entitlements";
import { RequestBodyReadError, readBoundedRequestBody } from "@your-builder/entitlements/trust";
import { MODULE_IDS, type GrowthModuleId } from "@your-builder/feature-registry";
import { BuilderAuthError } from "../auth/require-member.js";
import type { BuilderRequestContext, ResolveBuilderRequestContext } from "../content/request-context.js";
import { BuilderHttpError } from "../content/http-errors.js";
import type { InstallationClient } from "../control-plane/installation-client.js";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const MODULE_ID_SET = new Set<string>(Object.values(MODULE_IDS));
const ALLOWED_KEYS = new Set(["siteId", "moduleId", "requestId", "note"]);
const ACTIVATION_PATH = "/api/builder/entitlements/activation";
const MAX_BODY_BYTES = 8 * 1024;
const decoder = new TextDecoder("utf-8", { fatal: true });

export interface ActivationRequestInput {
  readonly siteId: string;
  readonly moduleId: GrowthModuleId;
  readonly requestId: string;
  readonly note?: string;
}

export interface ActivationRequestResult {
  readonly state: "requested" | "request_withdrawn";
  readonly requestId: string;
  readonly updatedAt: string;
  readonly withdrawalAllowed: boolean;
  readonly correlationId: string;
}

export interface ActivationSnapshotBoundary {
  readonly status: "fresh" | "stale" | "missing" | "invalid";
  readonly siteId: string;
  readonly installationId: string;
  readonly moduleState: EntitlementState;
}

export interface ActivationAuditEvent {
  readonly correlationId: string;
  readonly siteId: string;
  readonly actorId: string;
  readonly moduleId: GrowthModuleId;
  readonly action: "create" | "withdraw";
  readonly note?: string;
  readonly centralRequestId: string;
  readonly idempotent: boolean;
}

export interface ActivationRouteDependencies {
  readonly resolveContext: ResolveBuilderRequestContext;
  readonly verifyCsrf?: (request: Request, context: BuilderRequestContext) => void | Promise<void>;
  readonly rateLimit?: (
    request: Request,
    context: BuilderRequestContext,
    capability: GrowthCapability,
  ) => void | Promise<void>;
  readonly installationId: string;
  readonly loadSnapshot: (
    context: BuilderRequestContext,
    moduleId: GrowthModuleId,
  ) => Promise<ActivationSnapshotBoundary>;
  readonly installationClient: Pick<InstallationClient, "requestActivation">;
  readonly now?: () => Date;
  readonly correlationId?: () => string;
  readonly audit?: (event: ActivationAuditEvent) => void | Promise<void>;
}

function parsePayload(value: unknown): ActivationRequestInput {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new BuilderHttpError(400, "INVALID_ACTIVATION_REQUEST", "The activation request is invalid.");
  }
  const record = value as Record<string, unknown>;
  if (Object.keys(record).some((key) => !ALLOWED_KEYS.has(key))) {
    throw new BuilderHttpError(400, "INVALID_ACTIVATION_REQUEST", "The activation request is invalid.");
  }
  if (
    typeof record.siteId !== "string" || !UUID_PATTERN.test(record.siteId) ||
    typeof record.moduleId !== "string" || !MODULE_ID_SET.has(record.moduleId) ||
    typeof record.requestId !== "string" || !UUID_PATTERN.test(record.requestId) ||
    (record.note !== undefined && (typeof record.note !== "string" || record.note.trim().length > 500))
  ) {
    throw new BuilderHttpError(400, "INVALID_ACTIVATION_REQUEST", "The activation request is invalid.");
  }
  const note = typeof record.note === "string" ? record.note.trim() : undefined;
  return {
    siteId: record.siteId,
    moduleId: record.moduleId as GrowthModuleId,
    requestId: record.requestId,
    ...(note ? { note } : {}),
  };
}

function correlatedError(status: number, code: string, message: string, correlationId: string): Response {
  return Response.json({ error: { code, message, correlationId } }, { status });
}

export function createActivationRouteHandler(dependencies: ActivationRouteDependencies) {
  return {
    async handle(request: Request): Promise<Response> {
      const correlationId = dependencies.correlationId?.() ?? crypto.randomUUID();
      try {
        const url = new URL(request.url);
        if (url.pathname !== ACTIVATION_PATH || url.search !== "") {
          throw new BuilderHttpError(400, "INVALID_REQUEST_TARGET", "The activation request target is invalid.");
        }
        if (request.method !== "POST" && request.method !== "DELETE") {
          throw new BuilderHttpError(405, "METHOD_NOT_ALLOWED", "This activation method is not supported.");
        }
        if (request.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() !== "application/json") {
          throw new BuilderHttpError(415, "UNSUPPORTED_MEDIA_TYPE", "A JSON request body is required.");
        }
        const context = await dependencies.resolveContext(request);
        if (!canBuilderRole(context.role, "billing.manage")) {
          throw new BuilderHttpError(403, "ACTIVATION_PERMISSION_DENIED", "Only a site owner can request activation.");
        }
        await dependencies.verifyCsrf?.(request, context);
        await dependencies.rateLimit?.(request, context, "billing.manage");

        let raw: unknown;
        try {
          const bytes = await readBoundedRequestBody(request, MAX_BODY_BYTES);
          raw = JSON.parse(decoder.decode(bytes));
        } catch (error) {
          if (error instanceof RequestBodyReadError && error.code === "payload_too_large") {
            throw new BuilderHttpError(413, "ACTIVATION_PAYLOAD_TOO_LARGE", "The activation request is too large.");
          }
          throw new BuilderHttpError(400, "INVALID_ACTIVATION_REQUEST", "The activation request is invalid.");
        }
        const input = parsePayload(raw);
        if (request.headers.get("x-idempotency-key")?.trim() !== input.requestId) {
          throw new BuilderHttpError(400, "IDEMPOTENCY_KEY_MISMATCH", "The idempotency key must match the request identifier.");
        }
        if (input.siteId !== context.siteId) {
          throw new BuilderHttpError(403, "ACTIVATION_SITE_MISMATCH", "The activation request does not match this site.");
        }

        const snapshot = await dependencies.loadSnapshot(context, input.moduleId);
        if (snapshot.status !== "fresh") {
          throw new BuilderHttpError(409, "ENTITLEMENT_SNAPSHOT_STALE", "Refresh access before changing activation.");
        }
        if (snapshot.siteId !== context.siteId || snapshot.installationId !== dependencies.installationId) {
          throw new BuilderHttpError(409, "ENTITLEMENT_SCOPE_MISMATCH", "The site installation could not be verified.");
        }

        const action = request.method === "DELETE" ? "withdraw" : "create";
        if (action === "withdraw" && snapshot.moduleState !== "requested") {
          throw new BuilderHttpError(409, "ACTIVATION_WITHDRAWAL_UNAVAILABLE", "This request can no longer be withdrawn.");
        }
        const result = await dependencies.installationClient.requestActivation({
          commandId: input.requestId,
          action,
          moduleId: input.moduleId,
        });
        if (result.moduleId !== input.moduleId) {
          throw new Error("Activation response scope mismatch");
        }

        await dependencies.audit?.({
          correlationId,
          siteId: context.siteId,
          actorId: context.userId,
          moduleId: input.moduleId,
          action,
          ...(input.note ? { note: input.note } : {}),
          centralRequestId: result.requestId,
          idempotent: result.idempotent,
        });

        const state = result.status === "withdrawn" ? "request_withdrawn" : "requested";
        return Response.json({
          state,
          requestId: result.requestId,
          updatedAt: (dependencies.now?.() ?? new Date()).toISOString(),
          withdrawalAllowed: state === "requested" && result.status !== "provisioning",
          correlationId,
        } satisfies ActivationRequestResult, { headers: { "cache-control": "no-store" } });
      } catch (error) {
        if (error instanceof BuilderHttpError || error instanceof BuilderAuthError) {
          return correlatedError(error.status, error.code, error.message, correlationId);
        }
        return correlatedError(
          503,
          "ACTIVATION_UNAVAILABLE",
          "The activation request could not be updated. Try again.",
          correlationId,
        );
      }
    },
  };
}
