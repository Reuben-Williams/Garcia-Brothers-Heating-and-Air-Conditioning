import type { GrowthCapability } from "@your-builder/core";

export async function requireSiteCapability(input: {
  siteId: string;
  capability: GrowthCapability;
  resource?: { type: string; id: string };
  checkSite: (siteId: string, capability: GrowthCapability) => Promise<boolean>;
  checkRecord: (
    siteId: string,
    capability: GrowthCapability,
    type: string,
    id: string,
  ) => Promise<boolean>;
}): Promise<void> {
  const allowed = input.resource
    ? await input.checkRecord(
        input.siteId,
        input.capability,
        input.resource.type,
        input.resource.id,
      )
    : await input.checkSite(input.siteId, input.capability);

  if (!allowed) throw new Response("Capability denied", { status: 403 });
}
