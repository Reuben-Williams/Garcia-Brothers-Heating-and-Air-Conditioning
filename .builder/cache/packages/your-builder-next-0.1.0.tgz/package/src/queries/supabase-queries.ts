import type {
  AssignmentMemberListProjection,
  AssignmentMemberListRequest,
  CustomerDetailProjection,
  CustomerListProjection,
  CustomerListRequest,
  DashboardFactsQueryProjection,
  FormSubmissionDetailProjection,
  FormSubmissionListProjection,
  FormSubmissionListRequest,
  InAppNotificationListRequest,
  InAppNotificationListProjection,
  LeadDetailProjection,
  LeadListProjection,
  LeadListRequest,
  MemberInvitationListProjection,
  QueryPageRequest,
  QueryProjectionEnvelope,
} from "./contracts.js";

const RPC_NAMES = Object.freeze({
  listLeads: "builder_list_leads_v1",
  getLeadDetail: "builder_get_lead_detail_v1",
  listCustomers: "builder_list_customers_v1",
  getCustomerDetail: "builder_get_customer_detail_v1",
  getDashboardFacts: "builder_get_dashboard_facts_v1",
  listFormSubmissions: "builder_list_form_submissions_v1",
  getFormSubmissionDetail: "builder_get_form_submission_detail_v1",
  listInAppNotifications: "builder_list_in_app_notifications_v1",
  listAssignmentMembers: "builder_list_assignment_members_v1",
  listMemberInvitations: "builder_list_member_invitations_v1",
} as const);

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const CURSOR_PATTERN = /^[A-Za-z0-9_-]{16,2048}$/;

export interface TrustedQueryContext {
  readonly siteId: string;
  readonly actorId: string;
}

export interface QueryRpcClient {
  rpc(
    functionName: string,
    parameters: { readonly p_request: unknown },
  ): PromiseLike<{ readonly data: unknown; readonly error: unknown }>;
}

export type QueryRpcSafeCode = "QUERY_RPC_UNAVAILABLE" | "QUERY_RPC_INVALID_RESPONSE";

export class QueryRpcError extends Error {
  constructor(public readonly safeCode: QueryRpcSafeCode) {
    super(safeCode === "QUERY_RPC_UNAVAILABLE"
      ? "The requested data is temporarily unavailable."
      : "The query returned an invalid response.");
    this.name = "QueryRpcError";
  }
}

type TrustedLeadListQuery = TrustedQueryContext & LeadListRequest & { readonly limit: number };
type TrustedCustomerListQuery = TrustedQueryContext & CustomerListRequest & { readonly limit: number };
type TrustedSubmissionListQuery = TrustedQueryContext & FormSubmissionListRequest & { readonly limit: number };
type TrustedPageQuery = TrustedQueryContext & QueryPageRequest & { readonly limit: number };
type TrustedNotificationQuery = TrustedQueryContext & InAppNotificationListRequest & { readonly limit: number };
type TrustedAssignmentMemberQuery = TrustedQueryContext & AssignmentMemberListRequest;

export interface QueryPersistence {
  listLeads(input: TrustedLeadListQuery): Promise<LeadListProjection>;
  getLeadDetail(input: TrustedQueryContext & { readonly leadId: string }): Promise<LeadDetailProjection>;
  listCustomers(input: TrustedCustomerListQuery): Promise<CustomerListProjection>;
  getCustomerDetail(input: TrustedQueryContext & { readonly customerId: string }): Promise<CustomerDetailProjection>;
  getDashboardFacts(input: TrustedQueryContext): Promise<DashboardFactsQueryProjection>;
  listFormSubmissions(input: TrustedSubmissionListQuery): Promise<FormSubmissionListProjection>;
  getFormSubmissionDetail(input: TrustedQueryContext & { readonly submissionId: string }): Promise<FormSubmissionDetailProjection>;
  listInAppNotifications(input: TrustedNotificationQuery): Promise<InAppNotificationListProjection>;
  listAssignmentMembers(input: TrustedAssignmentMemberQuery): Promise<AssignmentMemberListProjection>;
  listMemberInvitations(input: TrustedPageQuery): Promise<MemberInvitationListProjection>;
}

function invalid(): never {
  throw new QueryRpcError("QUERY_RPC_INVALID_RESPONSE");
}

function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) invalid();
  return value as Record<string, unknown>;
}

function text(value: unknown, maximum = 4096): string {
  if (typeof value !== "string" || value.length === 0 || value.length > maximum) invalid();
  return value;
}

function optionalText(value: unknown, maximum = 4096): string | undefined {
  return value === undefined || value === null ? undefined : text(value, maximum);
}

function id(value: unknown): string {
  const result = text(value, 36);
  if (!UUID_PATTERN.test(result)) invalid();
  return result;
}

function integer(value: unknown, minimum = 0, maximum = 2_147_483_647): number {
  if (!Number.isInteger(value) || (value as number) < minimum || (value as number) > maximum) invalid();
  return value as number;
}

function optionalInteger(value: unknown, minimum = 0): number | undefined {
  return value === undefined || value === null ? undefined : integer(value, minimum);
}

function boolean(value: unknown): boolean {
  if (typeof value !== "boolean") invalid();
  return value;
}

function oneOf<T extends string>(value: unknown, values: readonly T[]): T {
  if (typeof value !== "string" || !(values as readonly string[]).includes(value)) invalid();
  return value as T;
}

function date(value: unknown): string {
  const result = text(value, 64);
  if (!Number.isFinite(Date.parse(result))) invalid();
  return result;
}

function optionalDate(value: unknown): string | undefined {
  return value === undefined || value === null ? undefined : date(value);
}

function array<T>(value: unknown, parser: (item: unknown) => T, maximum = 100): readonly T[] {
  if (!Array.isArray(value) || value.length > maximum) invalid();
  return value.map(parser);
}

function optionalCursor(value: unknown): string | undefined {
  if (value === undefined || value === null) return undefined;
  const result = text(value, 2048);
  if (!CURSOR_PATTERN.test(result)) invalid();
  return result;
}

type CursorKind = "sort" | "received" | "created";

function cursorField(kind: CursorKind): "sortValue" | "receivedAt" | "createdAt" {
  return kind === "sort" ? "sortValue" : kind === "received" ? "receivedAt" : "createdAt";
}

function parseCursorValue(value: unknown, kind: CursorKind): Record<string, unknown> {
  const item = record(value);
  const field = cursorField(kind);
  const expected = new Set(["version", field, "id"]);
  if (item.version !== 1 || Object.keys(item).length !== 3 || Object.keys(item).some((key) => !expected.has(key))) invalid();
  return { version: 1, [field]: kind === "sort" ? text(item[field], 256) : date(item[field]), id: id(item.id) };
}

function decodeCursor(value: string | undefined, kind: CursorKind): Record<string, unknown> | undefined {
  if (value === undefined) return undefined;
  if (!CURSOR_PATTERN.test(value)) invalid();
  try {
    return parseCursorValue(JSON.parse(Buffer.from(value, "base64url").toString("utf8")), kind);
  } catch (error) {
    if (error instanceof QueryRpcError) throw error;
    return invalid();
  }
}

function encodeCursor(value: unknown, kind: CursorKind): string | undefined {
  if (value === undefined || value === null) return undefined;
  return Buffer.from(JSON.stringify(parseCursorValue(value, kind))).toString("base64url");
}

function optionalId(value: unknown): string | undefined {
  return value === undefined || value === null ? undefined : id(value);
}

function jsonValue(value: unknown, depth = 0): unknown {
  if (depth > 8) invalid();
  if (value === null || typeof value === "boolean") return value;
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.length <= 8192) return value;
  if (Array.isArray(value)) {
    if (value.length > 64) invalid();
    return value.map((item) => jsonValue(item, depth + 1));
  }
  const input = record(value);
  const entries = Object.entries(input);
  if (entries.length > 64) invalid();
  return Object.fromEntries(entries.map(([key, item]) => {
    if (!key || key.length > 64) invalid();
    return [key, jsonValue(item, depth + 1)];
  }));
}

export function mapStoredLeadSource(value: unknown): "website_form" | "phone" | "walk_in" | "staff_entry" | "import" | "correction" | "integration" {
  if (value === "public_form" || value === "website_form") return "website_form";
  if (value === "staff") return "staff_entry";
  return oneOf(value, ["phone", "walk_in", "staff_entry", "import", "correction", "integration"] as const);
}

export function mapStoredLeadUrgency(value: unknown): "standard" | "urgent" | "emergency" {
  if (value === "low" || value === "normal" || value === "standard") return "standard";
  if (value === "high" || value === "urgent") return "urgent";
  if (value === "emergency") return "emergency";
  return invalid();
}

function identity(value: unknown) {
  const item = record(value);
  return { id: id(item.id), kind: oneOf(item.kind, ["email", "phone", "external"] as const), value: text(item.value, 1000), verificationState: text(item.verificationState, 64), source: mapStoredLeadSource(item.source), createdAt: date(item.createdAt) };
}

function tag(value: unknown) {
  const item = record(value);
  return { id: id(item.id), key: text(item.key, 100), label: text(item.label, 100), ...(optionalText(item.colorToken, 64) ? { colorToken: optionalText(item.colorToken, 64) } : {}) };
}

function task(value: unknown) {
  const item = record(value);
  return { id: id(item.id), title: text(item.title, 500), ...(item.priority === undefined || item.priority === null ? {} : { priority: oneOf(item.priority, ["low", "normal", "high", "urgent"] as const) }), state: oneOf(item.state, ["open", "in_progress", "completed", "cancelled"] as const), ...(optionalId(item.assigneeId) ? { assigneeId: optionalId(item.assigneeId) } : {}), ...(optionalDate(item.dueAt) ? { dueAt: optionalDate(item.dueAt) } : {}), ...(optionalDate(item.completedAt) ? { completedAt: optionalDate(item.completedAt) } : {}), version: integer(item.version, 1), createdAt: date(item.createdAt), updatedAt: date(item.updatedAt) };
}

function serviceEvent(value: unknown) {
  const item = record(value);
  return { id: id(item.id), eventKind: text(item.eventKind, 100), ...(item.purpose === undefined || item.purpose === null ? {} : { purpose: oneOf(item.purpose, ["estimate", "service", "follow_up"] as const) }), ...(optionalDate(item.scheduledAt) ? { scheduledAt: optionalDate(item.scheduledAt) } : {}), occurredAt: date(item.occurredAt), source: mapStoredLeadSource(item.source), ...(optionalId(item.actorId) ? { actorId: optionalId(item.actorId) } : {}), createdAt: date(item.createdAt) };
}

function leadEvent(value: unknown) {
  const item = record(value);
  return { id: id(item.id), kind: text(item.kind, 100), ...(optionalId(item.actorId) ? { actorId: optionalId(item.actorId) } : {}), metadata: jsonValue(item.metadata) as never, createdAt: date(item.createdAt) };
}

function lead(value: unknown) {
  const item = record(value);
  return { id: id(item.id), contactId: id(item.contactId), ...(optionalText(item.formId, 200) ? { formId: optionalText(item.formId, 200) } : {}), source: mapStoredLeadSource(item.source), ...(optionalText(item.service, 200) ? { service: optionalText(item.service, 200) } : {}), urgency: mapStoredLeadUrgency(item.urgency), priority: oneOf(item.priority, ["low", "normal", "high", "urgent"] as const), status: oneOf(item.status, ["new", "contacted", "qualified", "won", "lost", "spam"] as const), ...(optionalText(item.summary, 4096) ? { summary: optionalText(item.summary, 4096) } : {}), ...(optionalId(item.primaryAssigneeId) ? { primaryAssigneeId: optionalId(item.primaryAssigneeId) } : {}), version: integer(item.version, 1), createdAt: date(item.createdAt), updatedAt: date(item.updatedAt) };
}

function duplicateWarning(value: unknown) {
  const item = record(value);
  return { id: id(item.id), confidenceBand: oneOf(item.confidenceBand, ["low", "medium", "high"] as const), reviewState: oneOf(item.reviewState, ["pending", "accepted", "merged", "dismissed"] as const), version: integer(item.version, 1) };
}

function leadListItem(value: unknown) {
  const item = record(value);
  return { id: id(item.id), contactId: id(item.contactId), displayName: text(item.displayName, 320), source: mapStoredLeadSource(item.source), ...(optionalText(item.formId, 200) ? { formId: optionalText(item.formId, 200) } : {}), ...(optionalText(item.service, 200) ? { service: optionalText(item.service, 200) } : {}), urgency: mapStoredLeadUrgency(item.urgency), status: oneOf(item.status, ["new", "contacted", "qualified", "won", "lost", "spam"] as const), ...(optionalText(item.summary, 4096) ? { summary: optionalText(item.summary, 4096) } : {}), ...(optionalId(item.primaryAssigneeId) ? { primaryAssigneeId: optionalId(item.primaryAssigneeId) } : {}), priority: oneOf(item.priority, ["low", "normal", "high", "urgent"] as const), version: integer(item.version, 1), createdAt: date(item.createdAt), updatedAt: date(item.updatedAt) };
}

function leadPage(value: unknown) {
  const item = record(value);
  const nextCursor = encodeCursor(item.nextCursor, "sort");
  return { items: array(item.items, leadListItem), ...(nextCursor ? { nextCursor } : {}) };
}

function leadDetail(value: unknown) {
  const item = record(value);
  const customer = record(item.customer);
  const submission = item.submission === undefined || item.submission === null ? undefined : record(item.submission);
  return {
    lead: lead(item.lead),
    customer: { id: id(customer.id), displayName: text(customer.displayName, 320), lifecycleState: oneOf(customer.lifecycleState, ["active", "inactive", "merged", "deleted"] as const), ...(customer.preferredContactMethod === undefined || customer.preferredContactMethod === null ? {} : { preferredContactMethod: oneOf(customer.preferredContactMethod, ["email", "phone", "none"] as const) }), ...(optionalText(customer.serviceZipCode, 20) ? { serviceZipCode: optionalText(customer.serviceZipCode, 20) } : {}), version: integer(customer.version, 1) },
    identities: array(item.identities, identity, 50), tags: array(item.tags, tag, 100), tasks: array(item.tasks, task, 200), serviceEvents: array(item.serviceEvents, serviceEvent, 200), timeline: array(item.timeline, leadEvent, 500),
    ...(submission ? { submission: { id: id(submission.id), formId: text(submission.formId, 200), source: mapStoredLeadSource(submission.source), ...(optionalText(submission.zipCode, 20) ? { zipCode: optionalText(submission.zipCode, 20) } : {}), ...(optionalText(submission.locale, 64) ? { locale: optionalText(submission.locale, 64) } : {}), receivedAt: date(submission.receivedAt), resultCode: oneOf(submission.resultCode, ["base_only", "enhanced", "review_required", "identity_conflict", "spam"] as const) } } : {}),
    ...(item.duplicateWarning === undefined || item.duplicateWarning === null ? {} : { duplicateWarning: duplicateWarning(item.duplicateWarning) }),
  };
}

function customerListItem(value: unknown) {
  const item = record(value);
  return { id: id(item.id), displayName: text(item.displayName, 320), lifecycleState: oneOf(item.lifecycleState, ["active", "inactive", "merged", "deleted"] as const), ...(item.preferredContactMethod === undefined || item.preferredContactMethod === null ? {} : { preferredContactMethod: oneOf(item.preferredContactMethod, ["email", "phone", "none"] as const) }), ...(optionalText(item.serviceZipCode, 20) ? { serviceZipCode: optionalText(item.serviceZipCode, 20) } : {}), latestActivityAt: date(item.latestActivityAt), version: integer(item.version, 1), createdAt: date(item.createdAt), updatedAt: date(item.updatedAt) };
}

function customerPage(value: unknown) {
  const item = record(value);
  const nextCursor = encodeCursor(item.nextCursor, "sort");
  return { items: array(item.items, customerListItem), ...(nextCursor ? { nextCursor } : {}) };
}

function customerProfile(value: unknown) {
  const item = record(value);
  return { id: id(item.id), displayName: text(item.displayName, 320), lifecycleState: oneOf(item.lifecycleState, ["active", "inactive", "merged", "deleted"] as const), ...(item.preferredContactMethod === undefined || item.preferredContactMethod === null ? {} : { preferredContactMethod: oneOf(item.preferredContactMethod, ["email", "phone", "none"] as const) }), ...(optionalText(item.serviceZipCode, 20) ? { serviceZipCode: optionalText(item.serviceZipCode, 20) } : {}), version: integer(item.version, 1), createdAt: date(item.createdAt), updatedAt: date(item.updatedAt) };
}

function customerDetail(value: unknown) {
  const item = record(value);
  return {
    customer: customerProfile(item.customer),
    identities: array(item.identities, identity, 50),
    preferences: array(item.preferences, (value) => { const row = record(value); return { key: text(row.key, 100), value: jsonValue(row.value) as never, version: integer(row.version, 1), updatedAt: date(row.updatedAt) }; }, 100),
    suppressions: array(item.suppressions, (value) => { const row = record(value); return { id: id(row.id), channel: oneOf(row.channel, ["email", "sms"] as const), reason: text(row.reason, 500), active: boolean(row.active), createdAt: date(row.createdAt), ...(optionalDate(row.endedAt) ? { endedAt: optionalDate(row.endedAt) } : {}) }; }, 100),
    tags: array(item.tags, tag, 100),
    leads: array(item.leads, (value) => { const row = record(value); return { id: id(row.id), source: mapStoredLeadSource(row.source), ...(optionalText(row.service, 200) ? { service: optionalText(row.service, 200) } : {}), urgency: mapStoredLeadUrgency(row.urgency), status: oneOf(row.status, ["new", "contacted", "qualified", "won", "lost", "spam"] as const), version: integer(row.version, 1), createdAt: date(row.createdAt), updatedAt: date(row.updatedAt) }; }, 200),
    serviceEvents: array(item.serviceEvents, (value) => { const row = record(value); return { id: id(row.id), ...(optionalId(row.leadId) ? { leadId: optionalId(row.leadId) } : {}), eventKind: text(row.eventKind, 100), ...(row.purpose === undefined || row.purpose === null ? {} : { purpose: oneOf(row.purpose, ["estimate", "service", "follow_up"] as const) }), ...(optionalDate(row.scheduledAt) ? { scheduledAt: optionalDate(row.scheduledAt) } : {}), occurredAt: date(row.occurredAt), createdAt: date(row.createdAt) }; }, 200),
    mergeSuggestions: array(item.mergeSuggestions, (value) => { const row = record(value); return { id: id(row.id), leftCustomerId: id(row.leftCustomerId), rightCustomerId: id(row.rightCustomerId), evidenceCategories: array(row.evidenceCategories, (entry) => text(entry, 100), 20), confidenceBand: oneOf(row.confidenceBand, ["low", "medium", "high"] as const), reviewState: oneOf(row.reviewState, ["pending", "accepted", "merged", "dismissed"] as const), version: integer(row.version, 1), createdAt: date(row.createdAt), updatedAt: date(row.updatedAt) }; }, 100),
    exports: array(item.exports, (value) => { const row = record(value); return { id: id(row.id), domain: text(row.domain, 64), state: text(row.state, 64), schemaVersion: integer(row.schemaVersion, 1), ...(optionalDate(row.expiresAt) ? { expiresAt: optionalDate(row.expiresAt) } : {}), createdAt: date(row.createdAt), updatedAt: date(row.updatedAt) }; }, 100),
    deletionRequests: array(item.deletionRequests, (value) => { const row = record(value); return { id: id(row.id), scope: text(row.scope, 100), state: text(row.state, 64), legalHold: boolean(row.legalHold), version: integer(row.version, 1), createdAt: date(row.createdAt), updatedAt: date(row.updatedAt) }; }, 100),
  };
}

function gatedFact<T>(value: unknown, parser: (item: Record<string, unknown>) => T): { status: "restricted" } | ({ status: "allowed" } & T) {
  const item = record(value);
  if (item.status === "restricted") return { status: "restricted" };
  if (item.status !== "allowed") invalid();
  return { status: "allowed", ...parser(item) };
}

function dashboard(value: unknown) {
  const item = record(value);
  const facts = record(item.facts);
  return {
    leads: gatedFact(facts.leads, (row) => ({ newCount: integer(row.newCount), agingCount: integer(row.agingCount), unassignedCount: integer(row.unassignedCount) })),
    customers: gatedFact(facts.customers, (row) => ({ activeCount: integer(row.activeCount), recentActivityCount: integer(row.recentActivityCount) })),
    tasks: gatedFact(facts.tasks, (row) => ({ dueTodayCount: integer(row.dueTodayCount), overdueCount: integer(row.overdueCount) })),
    notifications: gatedFact(facts.notifications, (row) => ({ unreadCount: integer(row.unreadCount) })),
    baseSubmissions: gatedFact(facts.baseSubmissions, (row) => ({ recentCount: integer(row.recentCount), spamReviewCount: integer(row.spamReviewCount) })),
    health: gatedFact(facts.health, (row) => ({ items: array(row.items, (value) => { const health = record(value); return { checkKind: text(health.checkKind, 100), status: text(health.status, 64), ...(optionalText(health.observedVersion, 100) ? { observedVersion: optionalText(health.observedVersion, 100) } : {}), ...(optionalInteger(health.queueAgeSeconds) === undefined ? {} : { queueAgeSeconds: optionalInteger(health.queueAgeSeconds) }), ...(optionalInteger(health.snapshotAgeSeconds) === undefined ? {} : { snapshotAgeSeconds: optionalInteger(health.snapshotAgeSeconds) }), ...(optionalText(health.safeCode, 100) ? { safeCode: optionalText(health.safeCode, 100) } : {}), observedAt: date(health.observedAt) }; }, 100) })),
  };
}

function resultSummary(value: unknown) {
  const item = record(value);
  return {
    id: id(item.id), version: integer(item.version, 1),
    ...(optionalId(item.priorResultId) ? { priorResultId: optionalId(item.priorResultId) } : {}),
    resultCode: oneOf(item.resultCode, ["base_only", "enhanced", "review_required", "identity_conflict", "spam"] as const),
    ...(optionalId(item.contactId) ? { contactId: optionalId(item.contactId) } : {}),
    ...(optionalId(item.leadId) ? { leadId: optionalId(item.leadId) } : {}),
    safeMetadata: jsonValue(item.safeMetadata) as never, createdAt: date(item.createdAt),
  };
}

function submissionListItem(value: unknown) {
  const item = record(value);
  return { id: id(item.id), formId: text(item.formId, 200), source: text(item.source, 64), ...(optionalText(item.zipCode, 20) ? { zipCode: optionalText(item.zipCode, 20) } : {}), ...(optionalText(item.locale, 64) ? { locale: optionalText(item.locale, 64) } : {}), receivedAt: date(item.receivedAt), ...(item.currentResult === undefined || item.currentResult === null ? {} : { currentResult: resultSummary(item.currentResult) }) };
}

function submissionPage(value: unknown) {
  const item = record(value);
  const nextCursor = encodeCursor(item.nextCursor, "received");
  return { items: array(item.items, submissionListItem), ...(nextCursor ? { nextCursor } : {}) };
}

function submissionDetail(value: unknown) {
  const item = record(value);
  const submission = record(item.submission);
  return {
    submission: { id: id(submission.id), formId: text(submission.formId, 200), payload: jsonValue(submission.payload) as never, source: text(submission.source, 64), ...(optionalText(submission.zipCode, 20) ? { zipCode: optionalText(submission.zipCode, 20) } : {}), ...(optionalText(submission.locale, 64) ? { locale: optionalText(submission.locale, 64) } : {}), receivedAt: date(submission.receivedAt), createdAt: date(submission.createdAt) },
    consents: array(item.consents, (value) => { const row = record(value); return { id: id(row.id), policyVersion: text(row.policyVersion, 100), purpose: text(row.purpose, 200), languageDigest: text(row.languageDigest, 128), source: text(row.source, 64), capturedAt: date(row.capturedAt) }; }, 100),
    events: array(item.events, (value) => { const row = record(value); return { id: id(row.id), eventKind: oneOf(row.eventKind, ["spam", "restore", "review", "correction"] as const), ...(optionalId(row.actorId) ? { actorId: optionalId(row.actorId) } : {}), metadata: jsonValue(row.metadata) as never, createdAt: date(row.createdAt) }; }, 500),
    results: array(item.results, resultSummary, 100),
  };
}

function notificationPage(value: unknown) {
  const item = record(value);
  const nextCursor = encodeCursor(item.nextCursor, "created");
  return {
    items: array(item.items, (value) => { const row = record(value); return { id: id(row.id), eventType: text(row.eventType, 100), ...(row.resourceType === undefined || row.resourceType === null ? {} : { resourceType: oneOf(row.resourceType, ["lead", "customer", "task"] as const) }), ...(optionalId(row.resourceId) ? { resourceId: optionalId(row.resourceId) } : {}), previewText: text(row.previewText, 500), createdAt: date(row.createdAt), ...(optionalDate(row.readAt) ? { readAt: optionalDate(row.readAt) } : {}) }; }),
    unreadCount: integer(item.unreadCount),
    ...(nextCursor ? { nextCursor } : {}),
  };
}

function assignmentMemberPage(value: unknown) {
  const item = record(value);
  return { items: array(item.items, (value) => { const row = record(value); return { id: id(row.id), role: oneOf(row.role, ["owner", "editor", "contributor", "viewer"] as const), displayLabel: text(row.displayLabel, 200) }; }) };
}

function invitationPage(value: unknown) {
  const item = record(value);
  const nextCursor = encodeCursor(item.nextCursor, "created");
  return { items: array(item.items, (value) => { const row = record(value); return { id: id(row.id), templateId: oneOf(row.templateId, ["growth_manager_v1", "growth_staff_v1", "growth_read_only_v1"] as const), templateVersion: integer(row.templateVersion, 1), state: oneOf(row.state, ["pending", "accepted", "revoked", "expired"] as const), invitedBy: id(row.invitedBy), ...(optionalId(row.acceptedBy) ? { acceptedBy: optionalId(row.acceptedBy) } : {}), expiresAt: date(row.expiresAt), createdAt: date(row.createdAt), ...(optionalDate(row.acceptedAt) ? { acceptedAt: optionalDate(row.acceptedAt) } : {}), ...(optionalDate(row.revokedAt) ? { revokedAt: optionalDate(row.revokedAt) } : {}), version: integer(row.version, 1), updatedAt: date(row.updatedAt) }; }), ...(nextCursor ? { nextCursor } : {}) };
}

function envelope<T>(value: unknown, parseData: (data: unknown) => T): QueryProjectionEnvelope<T> {
  const item = record(value);
  if (item.version !== 1) invalid();
  if (item.status === "restricted" || item.status === "not_found") return { version: 1, status: item.status };
  if (item.status !== "allowed" && item.status !== "read_only" && item.status !== "stale") invalid();
  return { version: 1, status: item.status, data: parseData(item) };
}

function rpcRequest(input: TrustedQueryContext & object): Record<string, unknown> {
  id(input.siteId);
  id(input.actorId);
  return { version: 1, ...input };
}

function errorCode(value: unknown): string | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) return undefined;
  const code = (value as Record<string, unknown>).code;
  return typeof code === "string" && code.length <= 32 ? code : undefined;
}

function clean(value: Record<string, unknown>): Record<string, unknown> {
  return Object.fromEntries(Object.entries(value).filter(([, item]) => item !== undefined));
}

export function createSupabaseQueryPersistence(client: QueryRpcClient): QueryPersistence {
  async function invoke<T>(
    rpcName: string,
    input: TrustedQueryContext & object,
    parseData: (data: unknown) => T,
    concealMissing = false,
  ): Promise<QueryProjectionEnvelope<T>> {
    let response: { readonly data: unknown; readonly error: unknown };
    try {
      response = await client.rpc(rpcName, { p_request: rpcRequest(input) });
    } catch {
      throw new QueryRpcError("QUERY_RPC_UNAVAILABLE");
    }
    if (response.error) {
      if (errorCode(response.error) === "42501") {
        return { version: 1, status: concealMissing ? "not_found" : "restricted" };
      }
      throw new QueryRpcError("QUERY_RPC_UNAVAILABLE");
    }
    return envelope(response.data, parseData);
  }

  return {
    listLeads: (input) => {
      const { cursor, ...rest } = input;
      return invoke(RPC_NAMES.listLeads, clean({ ...rest, cursor: decodeCursor(cursor, "sort") }) as unknown as TrustedQueryContext, leadPage);
    },
    getLeadDetail: (input) => invoke(RPC_NAMES.getLeadDetail, input, leadDetail, true),
    listCustomers: (input) => {
      const { cursor, filter, ...rest } = input;
      return invoke(RPC_NAMES.listCustomers, clean({ ...rest, segment: filter, cursor: decodeCursor(cursor, "sort") }) as unknown as TrustedQueryContext, customerPage);
    },
    getCustomerDetail: (input) => invoke(RPC_NAMES.getCustomerDetail, input, customerDetail, true),
    getDashboardFacts: (input) => invoke(RPC_NAMES.getDashboardFacts, input, dashboard),
    listFormSubmissions: (input) => {
      const { cursor, ...rest } = input;
      return invoke(RPC_NAMES.listFormSubmissions, clean({ ...rest, cursor: decodeCursor(cursor, "received") }) as unknown as TrustedQueryContext, submissionPage);
    },
    getFormSubmissionDetail: (input) => invoke(RPC_NAMES.getFormSubmissionDetail, input, submissionDetail, true),
    listInAppNotifications: (input) => {
      const { cursor, ...rest } = input;
      return invoke(RPC_NAMES.listInAppNotifications, clean({ ...rest, cursor: decodeCursor(cursor, "created") }) as unknown as TrustedQueryContext, notificationPage);
    },
    listAssignmentMembers: (input) => invoke(RPC_NAMES.listAssignmentMembers, input, assignmentMemberPage),
    listMemberInvitations: (input) => {
      const { cursor, ...rest } = input;
      return invoke(RPC_NAMES.listMemberInvitations, clean({ ...rest, cursor: decodeCursor(cursor, "created") }) as unknown as TrustedQueryContext, invitationPage);
    },
  };
}
