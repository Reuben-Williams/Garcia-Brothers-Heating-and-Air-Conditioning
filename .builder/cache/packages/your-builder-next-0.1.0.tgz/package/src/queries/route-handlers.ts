import type { BuilderCapabilityScope, BuilderRole, GrowthCapability } from "@your-builder/core";
import { RequestBodyReadError, readBoundedRequestBody } from "@your-builder/entitlements/trust";
import type {
  AssignmentMemberListRequest,
  AssignmentMemberPurpose,
  CustomerListRequest,
  FormSubmissionListRequest,
  LeadListRequest,
  QueryPageRequest,
} from "./contracts.js";
import { MAX_QUERY_PAGE_SIZE, MAX_QUERY_SEARCH_LENGTH } from "./contracts.js";
import { QueryRpcError, type QueryPersistence } from "./supabase-queries.js";

const MAX_BODY_BYTES = 16 * 1024;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const CURSOR_PATTERN = /^[A-Za-z0-9_-]{16,2048}$/;
const decoder = new TextDecoder("utf-8", { fatal: true });
const RESPONSE_HEADERS = { "cache-control": "no-store" } as const;

export type QueryAccessMode =
  | "growth_leads_read"
  | "growth_customers_read"
  | "growth_dashboard_read"
  | "base_submission_read"
  | "recipient_notification_read"
  | "assignment_member_read"
  | "member_invitation_read";

export interface QueryAuthorizationRequirement {
  readonly siteId: string;
  readonly capability?: GrowthCapability;
  readonly allowedRoles?: readonly BuilderRole[];
  readonly allowedScopes: readonly BuilderCapabilityScope[];
  readonly accessMode: QueryAccessMode;
  readonly resource?: {
    readonly type: "lead" | "customer" | "form_submission";
    readonly id: string;
  };
}

export interface TrustedQueryAuthorizationContext {
  readonly siteId: string;
  readonly memberId: string;
  readonly role: BuilderRole;
  readonly scope: BuilderCapabilityScope;
  readonly entitlementVerification: "current" | "stale" | "missing" | "invalid";
}

export interface QueryAuthorizer {
  authorize(request: Request, requirement: QueryAuthorizationRequirement): Promise<TrustedQueryAuthorizationContext>;
  requireRecentAal2(request: Request, context: TrustedQueryAuthorizationContext): Promise<{ readonly verifiedAt: string }>;
}

export interface QueryRouteDependencies {
  readonly siteId: string;
  readonly authorizer: QueryAuthorizer;
  readonly persistence: QueryPersistence;
  readonly now: () => Date;
}

export type QueryAuthorizationErrorCode = "AUTH_REQUIRED" | "SITE_ACCESS_DENIED" | "QUERY_DENIED" | "AAL2_REQUIRED";

export class QueryAuthorizationError extends Error {
  constructor(public readonly code: QueryAuthorizationErrorCode) {
    super(code);
    this.name = "QueryAuthorizationError";
  }
}

class QueryRequestError extends Error {
  constructor(readonly status: 400 | 403 | 405 | 413 | 415, readonly code: string, message: string) {
    super(message);
    this.name = "QueryRequestError";
  }
}

function errorResponse(status: number, code: string, message: string): Response {
  return Response.json({ error: { code, message } }, { status, headers: RESPONSE_HEADERS });
}

function invalidRequest(): never {
  throw new QueryRequestError(400, "INVALID_REQUEST", "The query request is invalid.");
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function exactKeys(value: Record<string, unknown>, allowed: readonly string[]): void {
  const keys = new Set(allowed);
  if (Object.keys(value).some((key) => !keys.has(key))) invalidRequest();
}

function uuid(value: unknown): string {
  if (typeof value !== "string" || !UUID_PATTERN.test(value)) invalidRequest();
  return value;
}

function optionalSearch(value: unknown): string | undefined {
  if (value === undefined) return undefined;
  if (typeof value !== "string") invalidRequest();
  const result = value.trim();
  if (!result || result.length > MAX_QUERY_SEARCH_LENGTH) invalidRequest();
  return result;
}

function limit(value: unknown): number {
  const result = value === undefined ? 50 : value;
  if (!Number.isInteger(result) || (result as number) < 1 || (result as number) > MAX_QUERY_PAGE_SIZE) invalidRequest();
  return result as number;
}

type CursorKind = "sort" | "received" | "created";

function cursor(value: unknown, kind: CursorKind): string | undefined {
  if (value === undefined) return undefined;
  if (typeof value !== "string" || !CURSOR_PATTERN.test(value)) invalidRequest();
  try {
    const decoded = JSON.parse(Buffer.from(value, "base64url").toString("utf8"));
    if (!isRecord(decoded)) invalidRequest();
    const field = kind === "sort" ? "sortValue" : kind === "received" ? "receivedAt" : "createdAt";
    const expected = new Set(["version", field, "id"]);
    if (decoded.version !== 1 || Object.keys(decoded).length !== 3 || Object.keys(decoded).some((key) => !expected.has(key))) invalidRequest();
    uuid(decoded.id);
    if (typeof decoded[field] !== "string" || !decoded[field]) invalidRequest();
    if (kind !== "sort" && !Number.isFinite(Date.parse(decoded[field] as string))) invalidRequest();
  } catch (error) {
    if (error instanceof QueryRequestError) throw error;
    invalidRequest();
  }
  return value;
}

function enumValue<T extends string>(value: unknown, values: readonly T[]): T {
  if (typeof value !== "string" || !(values as readonly string[]).includes(value)) invalidRequest();
  return value as T;
}

function optionalEnum<T extends string>(value: unknown, values: readonly T[]): T | undefined {
  return value === undefined ? undefined : enumValue(value, values);
}

function stringArray(value: unknown, maximum = 20): readonly string[] | undefined {
  if (value === undefined) return undefined;
  if (!Array.isArray(value) || value.length > maximum) invalidRequest();
  return value.map((item) => {
    if (typeof item !== "string" || !item || item.length > 200) invalidRequest();
    return item;
  });
}

function enumArray<T extends string>(value: unknown, values: readonly T[]): readonly T[] | undefined {
  const items = stringArray(value);
  return items?.map((item) => enumValue(item, values));
}

function optionalBoolean(value: unknown): boolean | undefined {
  if (value === undefined) return undefined;
  if (typeof value !== "boolean") invalidRequest();
  return value;
}

function optionalDate(value: unknown): string | undefined {
  if (value === undefined) return undefined;
  if (typeof value !== "string" || value.length > 64 || !Number.isFinite(Date.parse(value))) invalidRequest();
  return value;
}

function compact<T extends Record<string, unknown>>(value: T): T {
  return Object.fromEntries(Object.entries(value).filter(([, item]) => item !== undefined)) as T;
}

function parsePage(value: Record<string, unknown>, kind: CursorKind): QueryPageRequest & { readonly limit: number } {
  return compact({ limit: limit(value.limit), cursor: cursor(value.cursor, kind) });
}

function parseLeadFilter(value: unknown): LeadListRequest["filter"] {
  if (value === undefined) return undefined;
  if (!isRecord(value)) invalidRequest();
  exactKeys(value, ["statuses", "services", "assigneeIds", "sources", "priorities", "createdFrom", "createdTo", "unassigned"]);
  return compact({
    statuses: enumArray(value.statuses, ["new", "contacted", "qualified", "won", "lost", "spam"] as const),
    services: stringArray(value.services),
    assigneeIds: stringArray(value.assigneeIds)?.map(uuid),
    sources: enumArray(value.sources, ["website_form", "phone", "walk_in", "staff_entry"] as const),
    priorities: enumArray(value.priorities, ["low", "normal", "high", "urgent"] as const),
    createdFrom: optionalDate(value.createdFrom), createdTo: optionalDate(value.createdTo), unassigned: optionalBoolean(value.unassigned),
  });
}

function parseLeadList(value: Record<string, unknown>): LeadListRequest & { readonly limit: number } {
  exactKeys(value, ["search", "filter", "sort", "direction", "limit", "cursor"]);
  return compact({
    search: optionalSearch(value.search), filter: parseLeadFilter(value.filter),
    sort: optionalEnum(value.sort, ["created_at", "updated_at", "priority", "status"] as const),
    direction: optionalEnum(value.direction, ["asc", "desc"] as const),
    ...parsePage(value, "sort"),
  });
}

function parseSegmentFilter(value: unknown): CustomerListRequest["filter"] {
  if (value === undefined) return undefined;
  if (!isRecord(value)) invalidRequest();
  exactKeys(value, ["version", "conjunction", "clauses"]);
  if (value.version !== 1 || !Array.isArray(value.clauses) || value.clauses.length > 20) invalidRequest();
  return {
    version: 1,
    conjunction: enumValue(value.conjunction, ["all", "any"] as const),
    clauses: value.clauses.map((item) => {
      if (!isRecord(item)) invalidRequest();
      exactKeys(item, ["field", "operator", "value"]);
      return compact({
        field: enumValue(item.field, ["lifecycle_state", "preferred_contact_method", "tag_id", "service_area_zip", "created_at", "updated_at"] as const),
        operator: enumValue(item.operator, ["equals", "not_equals", "in", "contains", "before", "after", "is_empty"] as const),
        value: item.value as never,
      });
    }),
  };
}

function parseCustomerList(value: Record<string, unknown>): CustomerListRequest & { readonly limit: number } {
  exactKeys(value, ["search", "filter", "sort", "direction", "limit", "cursor"]);
  return compact({
    search: optionalSearch(value.search), filter: parseSegmentFilter(value.filter),
    sort: optionalEnum(value.sort, ["display_name", "updated_at", "latest_activity"] as const),
    direction: optionalEnum(value.direction, ["asc", "desc"] as const),
    ...parsePage(value, "sort"),
  });
}

function parseSubmissionList(value: Record<string, unknown>): FormSubmissionListRequest & { readonly limit: number } {
  exactKeys(value, ["search", "resultCodes", "limit", "cursor"]);
  return compact({
    search: optionalSearch(value.search),
    resultCodes: enumArray(value.resultCodes, ["base_only", "enhanced", "review_required", "identity_conflict", "spam"] as const),
    ...parsePage(value, "received"),
  });
}

function parseSimplePage(value: Record<string, unknown>): QueryPageRequest & { readonly limit: number } {
  exactKeys(value, ["limit", "cursor"]);
  return parsePage(value, "created");
}

function parseAssignmentMembers(value: Record<string, unknown>): AssignmentMemberListRequest {
  exactKeys(value, ["purpose"]);
  return { purpose: enumValue(value.purpose, ["lead_assignment", "customer_assignment", "task_assignment"] as const) };
}

function parseNotificationList(value: Record<string, unknown>) {
  exactKeys(value, ["unreadOnly", "limit", "cursor"]);
  return compact({ unreadOnly: optionalBoolean(value.unreadOnly), ...parsePage(value, "created") });
}

async function readBody(request: Request): Promise<Record<string, unknown>> {
  if (request.method !== "POST") throw new QueryRequestError(405, "METHOD_NOT_ALLOWED", "Use POST for query requests.");
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) {
    throw new QueryRequestError(415, "UNSUPPORTED_MEDIA_TYPE", "Use application/json.");
  }
  const origin = request.headers.get("origin");
  if (!origin || origin !== new URL(request.url).origin || request.headers.get("sec-fetch-site") === "cross-site") {
    throw new QueryRequestError(403, "ORIGIN_REJECTED", "The request origin is not allowed.");
  }
  let bytes: Uint8Array;
  try {
    bytes = await readBoundedRequestBody(request, MAX_BODY_BYTES);
  } catch (error) {
    if (error instanceof RequestBodyReadError && error.code === "payload_too_large") {
      throw new QueryRequestError(413, "PAYLOAD_TOO_LARGE", "The query request is too large.");
    }
    invalidRequest();
  }
  try {
    const value = JSON.parse(decoder.decode(bytes));
    if (!isRecord(value)) invalidRequest();
    return value;
  } catch (error) {
    if (error instanceof QueryRequestError) throw error;
    invalidRequest();
  }
}

function validateTrustedContext(context: TrustedQueryAuthorizationContext, siteId: string): void {
  if (context.siteId !== siteId || !UUID_PATTERN.test(context.memberId)) {
    throw new QueryAuthorizationError("SITE_ACCESS_DENIED");
  }
}

async function execute<TParsed extends object>(
  request: Request,
  dependencies: QueryRouteDependencies,
  parse: (body: Record<string, unknown>) => TParsed,
  requirement: (parsed: TParsed) => QueryAuthorizationRequirement,
  invoke: (parsed: TParsed, context: TrustedQueryAuthorizationContext) => Promise<unknown>,
  requireAal2 = false,
): Promise<Response> {
  try {
    const parsed = parse(await readBody(request));
    const context = await dependencies.authorizer.authorize(request, requirement(parsed));
    validateTrustedContext(context, dependencies.siteId);
    if (requireAal2) await dependencies.authorizer.requireRecentAal2(request, context);
    return Response.json(await invoke(parsed, context), { status: 200, headers: RESPONSE_HEADERS });
  } catch (error) {
    if (error instanceof QueryRequestError) return errorResponse(error.status, error.code, error.message);
    if (error instanceof QueryAuthorizationError) {
      if (error.code === "AUTH_REQUIRED") return errorResponse(401, "AUTH_REQUIRED", "A verified member session is required.");
      if (error.code === "AAL2_REQUIRED") return errorResponse(403, "AAL2_REQUIRED", "Recent verification is required.");
      return errorResponse(404, "NOT_FOUND", "The requested data is not available.");
    }
    if (error instanceof QueryRpcError) return errorResponse(503, error.safeCode, error.message);
    return errorResponse(503, "QUERY_UNAVAILABLE", "The requested data is temporarily unavailable.");
  }
}

const leadRequirement = (siteId: string, resource?: string): QueryAuthorizationRequirement => ({
  siteId, capability: "leads.read", allowedScopes: ["site", "assigned"], accessMode: "growth_leads_read",
  ...(resource ? { resource: { type: "lead", id: resource } as const } : {}),
});
const customerRequirement = (siteId: string, resource?: string): QueryAuthorizationRequirement => ({
  siteId, capability: "customers.read", allowedScopes: ["site", "assigned"], accessMode: "growth_customers_read",
  ...(resource ? { resource: { type: "customer", id: resource } as const } : {}),
});
const baseRequirement = (siteId: string, resource?: string): QueryAuthorizationRequirement => ({
  siteId, allowedRoles: ["owner", "editor"], allowedScopes: ["site"], accessMode: "base_submission_read",
  ...(resource ? { resource: { type: "form_submission", id: resource } as const } : {}),
});

export function createLeadListQueryRouteHandler(dependencies: QueryRouteDependencies) {
  return { handle: (request: Request) => execute(request, dependencies, parseLeadList, () => leadRequirement(dependencies.siteId), (parsed, context) => dependencies.persistence.listLeads({ ...parsed, siteId: dependencies.siteId, actorId: context.memberId })) };
}

export function createLeadDetailQueryRouteHandler(dependencies: QueryRouteDependencies) {
  return { handle: (request: Request, params: { readonly leadId: string }) => execute(request, dependencies, (body) => { exactKeys(body, []); return { leadId: uuid(params.leadId) }; }, (parsed) => leadRequirement(dependencies.siteId, parsed.leadId as string), (parsed, context) => dependencies.persistence.getLeadDetail({ siteId: dependencies.siteId, actorId: context.memberId, leadId: parsed.leadId as string })) };
}

export function createCustomerListQueryRouteHandler(dependencies: QueryRouteDependencies) {
  return { handle: (request: Request) => execute(request, dependencies, parseCustomerList, () => customerRequirement(dependencies.siteId), (parsed, context) => dependencies.persistence.listCustomers({ ...parsed, siteId: dependencies.siteId, actorId: context.memberId })) };
}

export function createCustomerDetailQueryRouteHandler(dependencies: QueryRouteDependencies) {
  return { handle: (request: Request, params: { readonly customerId: string }) => execute(request, dependencies, (body) => { exactKeys(body, []); return { customerId: uuid(params.customerId) }; }, (parsed) => customerRequirement(dependencies.siteId, parsed.customerId as string), (parsed, context) => dependencies.persistence.getCustomerDetail({ siteId: dependencies.siteId, actorId: context.memberId, customerId: parsed.customerId as string })) };
}

export function createDashboardFactsQueryRouteHandler(dependencies: QueryRouteDependencies) {
  return { handle: (request: Request) => execute(request, dependencies, (body) => { exactKeys(body, []); return {}; }, () => ({ siteId: dependencies.siteId, capability: "dashboard.read", allowedScopes: ["site"], accessMode: "growth_dashboard_read" }), (_parsed, context) => dependencies.persistence.getDashboardFacts({ siteId: dependencies.siteId, actorId: context.memberId })) };
}

export function createFormSubmissionListQueryRouteHandler(dependencies: QueryRouteDependencies) {
  return { handle: (request: Request) => execute(request, dependencies, parseSubmissionList, () => baseRequirement(dependencies.siteId), (parsed, context) => dependencies.persistence.listFormSubmissions({ ...parsed, siteId: dependencies.siteId, actorId: context.memberId })) };
}

export function createFormSubmissionDetailQueryRouteHandler(dependencies: QueryRouteDependencies) {
  return { handle: (request: Request, params: { readonly submissionId: string }) => execute(request, dependencies, (body) => { exactKeys(body, []); return { submissionId: uuid(params.submissionId) }; }, (parsed) => baseRequirement(dependencies.siteId, parsed.submissionId as string), (parsed, context) => dependencies.persistence.getFormSubmissionDetail({ siteId: dependencies.siteId, actorId: context.memberId, submissionId: parsed.submissionId as string })) };
}

export function createInAppNotificationListQueryRouteHandler(dependencies: QueryRouteDependencies) {
  return { handle: (request: Request) => execute(request, dependencies, parseNotificationList, () => ({ siteId: dependencies.siteId, allowedScopes: ["site"], accessMode: "recipient_notification_read" }), (parsed, context) => dependencies.persistence.listInAppNotifications({ ...parsed, siteId: dependencies.siteId, actorId: context.memberId })) };
}

export function createAssignmentMemberListQueryRouteHandler(dependencies: QueryRouteDependencies) {
  return { handle: (request: Request) => execute(request, dependencies, parseAssignmentMembers, (parsed) => {
    const capability: GrowthCapability = parsed.purpose === "lead_assignment" ? "leads.assign" : parsed.purpose === "customer_assignment" ? "customers.update" : "tasks.manage";
    return { siteId: dependencies.siteId, capability, allowedScopes: ["site"], accessMode: "assignment_member_read" };
  }, (parsed, context) => dependencies.persistence.listAssignmentMembers({ ...parsed, siteId: dependencies.siteId, actorId: context.memberId })) };
}

export function createMemberInvitationListQueryRouteHandler(dependencies: QueryRouteDependencies) {
  return { handle: (request: Request) => execute(request, dependencies, parseSimplePage, () => ({ siteId: dependencies.siteId, capability: "members.manage", allowedRoles: ["owner"], allowedScopes: ["site"], accessMode: "member_invitation_read" }), (parsed, context) => dependencies.persistence.listMemberInvitations({ ...parsed, siteId: dependencies.siteId, actorId: context.memberId }), true) };
}
