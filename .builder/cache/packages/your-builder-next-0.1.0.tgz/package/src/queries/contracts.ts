import type {
  BaseFormSubmissionQueryDetail,
  BaseFormSubmissionQueryPage,
  BaseFormSubmissionQueryResultCode,
  BuilderRole,
  GrowthInvitationTemplateId,
  MemberInvitationStatus,
} from "@your-builder/core";
import type { CustomerSegmentFilter, CustomerWorkspaceDetail, CustomerWorkspacePage } from "@your-builder/growth-customers";
import type { DashboardFactsProjection } from "@your-builder/growth-dashboard";
import type { LeadListFilter, LeadReadDetail, LeadReadPage } from "@your-builder/growth-leads";

export const QUERY_CONTRACT_VERSION = 1 as const;
export const MAX_QUERY_PAGE_SIZE = 100 as const;
export const MAX_QUERY_SEARCH_LENGTH = 200 as const;
export const QUERY_PROJECTION_STATUSES = Object.freeze([
  "allowed",
  "read_only",
  "restricted",
  "stale",
  "not_found",
] as const);

export type QueryProjectionStatus = (typeof QUERY_PROJECTION_STATUSES)[number];
export type QueryReadableStatus = Extract<QueryProjectionStatus, "allowed" | "read_only" | "stale">;

export type QueryProjectionEnvelope<T> =
  | { readonly version: 1; readonly status: QueryReadableStatus; readonly data: T }
  | { readonly version: 1; readonly status: "restricted" | "not_found" };

export interface QueryPageRequest {
  readonly limit?: number;
  readonly cursor?: string;
}

export interface LeadListRequest extends QueryPageRequest {
  readonly search?: string;
  readonly filter?: Omit<LeadListFilter, "estimateScheduled">;
  readonly sort?: "created_at" | "updated_at" | "priority" | "status";
  readonly direction?: "asc" | "desc";
}

export interface CustomerListRequest extends QueryPageRequest {
  readonly search?: string;
  readonly filter?: CustomerSegmentFilter;
  readonly sort?: "display_name" | "updated_at" | "latest_activity";
  readonly direction?: "asc" | "desc";
}

export interface FormSubmissionListRequest extends QueryPageRequest {
  readonly search?: string;
  readonly resultCodes?: readonly BaseFormSubmissionQueryResultCode[];
}

export interface InAppNotificationProjection {
  readonly id: string;
  readonly eventType: string;
  readonly resourceType?: "lead" | "customer" | "task";
  readonly resourceId?: string;
  readonly previewText: string;
  readonly createdAt: string;
  readonly readAt?: string;
}

export interface InAppNotificationPage {
  readonly items: readonly InAppNotificationProjection[];
  readonly unreadCount: number;
  readonly nextCursor?: string;
}

export type AssignmentMemberPurpose = "lead_assignment" | "customer_assignment" | "task_assignment";

export interface AssignmentMemberListRequest {
  readonly purpose: AssignmentMemberPurpose;
}

export interface AssignmentMemberProjection {
  readonly id: string;
  readonly role: BuilderRole;
  readonly displayLabel: string;
}

export interface AssignmentMemberPage {
  readonly items: readonly AssignmentMemberProjection[];
  readonly nextCursor?: string;
}

export interface MemberInvitationProjection {
  readonly id: string;
  readonly templateId: GrowthInvitationTemplateId;
  readonly templateVersion: number;
  readonly state: MemberInvitationStatus;
  readonly invitedBy: string;
  readonly acceptedBy?: string;
  readonly expiresAt: string;
  readonly createdAt: string;
  readonly acceptedAt?: string;
  readonly revokedAt?: string;
  readonly version: number;
  readonly updatedAt: string;
}

export interface MemberInvitationPage {
  readonly items: readonly MemberInvitationProjection[];
  readonly nextCursor?: string;
}

export interface InAppNotificationListRequest extends QueryPageRequest {
  readonly unreadOnly?: boolean;
}

export type LeadListProjection = QueryProjectionEnvelope<LeadReadPage>;
export type LeadDetailProjection = QueryProjectionEnvelope<LeadReadDetail>;
export type CustomerListProjection = QueryProjectionEnvelope<CustomerWorkspacePage>;
export type CustomerDetailProjection = QueryProjectionEnvelope<CustomerWorkspaceDetail>;
export type DashboardFactsQueryProjection = QueryProjectionEnvelope<DashboardFactsProjection>;
export type FormSubmissionListProjection = QueryProjectionEnvelope<BaseFormSubmissionQueryPage>;
export type FormSubmissionDetailProjection = QueryProjectionEnvelope<BaseFormSubmissionQueryDetail>;
export type InAppNotificationListProjection = QueryProjectionEnvelope<InAppNotificationPage>;
export type AssignmentMemberListProjection = QueryProjectionEnvelope<AssignmentMemberPage>;
export type MemberInvitationListProjection = QueryProjectionEnvelope<MemberInvitationPage>;
