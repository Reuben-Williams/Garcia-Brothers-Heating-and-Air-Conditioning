import type {
  AddLeadNoteCommand,
  AssignLeadCommand,
  BaseSubmissionReviewCommand,
  ChangeLeadStatusCommand,
  CreateLeadTaskCommand,
  CreateManualLeadCommand,
  ImportBaseSubmissionCommand,
  RecordLeadServiceEventCommand,
  SetLeadPriorityCommand,
} from "@your-builder/growth-leads";
import type { GrowthInvitationTemplateId } from "@your-builder/core";
import type { MarkInAppNotificationReadCommand } from "@your-builder/growth-core";
import type {
  RequestCustomerDeletionCommand,
  RequestCustomerExportCommand,
  ReviewCustomerMergeCommand,
  UpdateCustomerProfileCommand,
} from "@your-builder/growth-customers";
import type { OperationalMutationResult, OperationalResourceType } from "./contracts.js";

const RPC_NAMES = Object.freeze({
  createManualLead: "builder_create_manual_lead_v1",
  applyLeadCommand: "builder_apply_lead_command_v1",
  createLeadTask: "builder_create_lead_task_v1",
  recordLeadServiceEvent: "builder_record_lead_service_event_v1",
  reviewFormSubmission: "builder_review_form_submission_v1",
  importFormSubmission: "builder_import_form_submission_v1",
  updateCustomerProfile: "builder_update_customer_profile_v1",
  reviewCustomerMerge: "builder_review_customer_merge_v1",
  executeCustomerMerge: "builder_execute_customer_merge_v1",
  requestCustomerExport: "builder_request_customer_export_v1",
  requestCustomerDeletion: "builder_request_customer_deletion_v1",
  markNotificationRead: "builder_mark_notification_read_v1",
  createMemberInvitation: "builder_create_member_invitation_v1",
  revokeMemberInvitation: "builder_revoke_member_invitation_v1",
  acceptMemberInvitation: "builder_accept_member_invitation_v1",
} as const);

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const DENIED_REASONS = new Set([
  "not_authorized",
  "entitlement_restricted",
  "invalid_request",
  "not_found",
  "enhancement_unavailable",
]);

export type LeadApplyOperation = "status" | "priority" | "note" | "assignment";
export type LeadApplyCommand =
  | ChangeLeadStatusCommand
  | SetLeadPriorityCommand
  | AddLeadNoteCommand
  | AssignLeadCommand;

export interface VersionedLeadTaskCommand {
  readonly expectedLeadVersion: number;
  readonly command: CreateLeadTaskCommand;
}

export interface VersionedLeadServiceEventCommand {
  readonly expectedLeadVersion: number;
  readonly command: RecordLeadServiceEventCommand;
}

export interface OperationalPersistence {
  createManualLead(command: CreateManualLeadCommand): Promise<OperationalMutationResult>;
  applyLeadCommand(input: {
    readonly operation: LeadApplyOperation;
    readonly command: LeadApplyCommand;
  }): Promise<OperationalMutationResult>;
  createLeadTask(input: VersionedLeadTaskCommand): Promise<OperationalMutationResult>;
  recordLeadServiceEvent(input: VersionedLeadServiceEventCommand): Promise<OperationalMutationResult>;
  reviewFormSubmission(input: {
    readonly operation: "spam" | "restore";
    readonly command: BaseSubmissionReviewCommand;
  }): Promise<OperationalMutationResult>;
  importFormSubmission(command: ImportBaseSubmissionCommand): Promise<OperationalMutationResult>;
  updateCustomerProfile(command: UpdateCustomerProfileCommand): Promise<OperationalMutationResult>;
  reviewCustomerMerge(command: ReviewCustomerMergeCommand): Promise<OperationalMutationResult>;
  executeCustomerMerge(command: ExecuteCustomerMergePersistenceCommand): Promise<OperationalMutationResult>;
  requestCustomerExport(command: CustomerExportPersistenceCommand): Promise<OperationalMutationResult>;
  requestCustomerDeletion(command: CustomerDeletionPersistenceCommand): Promise<OperationalMutationResult>;
  markNotificationRead(command: MarkInAppNotificationReadCommand): Promise<OperationalMutationResult>;
  createMemberInvitation(command: CreateMemberInvitationPersistenceCommand): Promise<OperationalMutationResult>;
  revokeMemberInvitation(command: RevokeMemberInvitationPersistenceCommand): Promise<OperationalMutationResult>;
  acceptMemberInvitation(command: AcceptMemberInvitationPersistenceCommand): Promise<OperationalMutationResult>;
}

export interface CustomerExportPersistenceCommand extends RequestCustomerExportCommand {
  readonly aal2VerifiedAt: string;
}

export interface ExecuteCustomerMergePersistenceCommand {
  readonly siteId: string;
  readonly actor: { readonly type: "member"; readonly id: string };
  readonly idempotencyKey: string;
  readonly suggestionId: string;
  readonly expectedSuggestionVersion: number;
  readonly sourceId: string;
  readonly targetId: string;
  readonly expectedSourceVersion: number;
  readonly expectedTargetVersion: number;
}

export interface CustomerDeletionPersistenceCommand extends RequestCustomerDeletionCommand {
  readonly aal2VerifiedAt: string;
}

export interface CreateMemberInvitationPersistenceCommand {
  readonly siteId: string;
  readonly actorId: string;
  readonly idempotencyKey: string;
  readonly canonicalEmailDigest: string;
  readonly tokenHash: string;
  readonly templateId: GrowthInvitationTemplateId;
  readonly templateVersion: 1;
  readonly expiresAt: string;
  readonly aal2VerifiedAt: string;
}

export interface RevokeMemberInvitationPersistenceCommand {
  readonly siteId: string;
  readonly actorId: string;
  readonly invitationId: string;
  readonly expectedVersion: number;
  readonly reason: string;
  readonly idempotencyKey: string;
  readonly aal2VerifiedAt: string;
}

export interface AcceptMemberInvitationPersistenceCommand {
  readonly siteId: string;
  readonly authenticatedUserId: string;
  readonly canonicalEmailDigest: string;
  readonly tokenHash: string;
  readonly idempotencyKey: string;
}

export interface OperationalRpcClient {
  rpc(
    functionName: string,
    parameters: { readonly p_request: unknown },
  ): PromiseLike<{ readonly data: unknown; readonly error: unknown }>;
}

export type OperationalRpcSafeCode =
  | "OPERATION_RPC_UNAVAILABLE"
  | "OPERATION_RPC_INVALID_RESPONSE";

export class OperationalRpcError extends Error {
  constructor(public readonly safeCode: OperationalRpcSafeCode) {
    super(safeCode === "OPERATION_RPC_UNAVAILABLE"
      ? "The operation is temporarily unavailable."
      : "The operation returned an invalid response.");
    this.name = "OperationalRpcError";
  }
}

function isVersion(value: unknown, minimum = 1): value is number {
  return Number.isInteger(value) && (value as number) >= minimum && (value as number) <= 2_147_483_647;
}

type RpcRequest = Readonly<Record<string, unknown>>;

function trustedMemberId(actor: { readonly type: string; readonly id?: string }): string {
  if (actor.type !== "member" || typeof actor.id !== "string" || !UUID_PATTERN.test(actor.id)) {
    throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
  }
  return actor.id;
}

function baseRequest(command: {
  readonly siteId: string;
  readonly actor: { readonly type: string; readonly id?: string };
  readonly idempotencyKey: string;
}): RpcRequest {
  return {
    version: 1,
    commandId: command.idempotencyKey,
    siteId: command.siteId,
    actorId: trustedMemberId(command.actor),
    idempotencyKey: command.idempotencyKey,
  };
}

function appliedResource(
  data: Record<string, unknown>,
  functionName: string,
): { resourceType: OperationalResourceType; resourceId: string } | null {
  const mappings = new Map<string, readonly [OperationalResourceType, string]>([
    [RPC_NAMES.createLeadTask, ["task", "taskId"]],
    [RPC_NAMES.recordLeadServiceEvent, ["service_event", "serviceEventId"]],
    [RPC_NAMES.reviewFormSubmission, ["form_submission", "submissionId"]],
    [RPC_NAMES.updateCustomerProfile, ["customer", "customerId"]],
    [RPC_NAMES.reviewCustomerMerge, ["merge_suggestion", "suggestionId"]],
    [RPC_NAMES.executeCustomerMerge, ["customer", "customerId"]],
    [RPC_NAMES.requestCustomerExport, ["data_export", "exportId"]],
    [RPC_NAMES.requestCustomerDeletion, ["deletion_request", "deletionRequestId"]],
    [RPC_NAMES.markNotificationRead, ["notification", "notificationId"]],
    [RPC_NAMES.createMemberInvitation, ["member_invitation", "invitationId"]],
    [RPC_NAMES.revokeMemberInvitation, ["member_invitation", "invitationId"]],
    [RPC_NAMES.acceptMemberInvitation, ["member", "memberId"]],
  ]);
  const mapping = mappings.get(functionName) ?? ["lead", "leadId"] as const;
  const resourceId = data[mapping[1]];
  return typeof resourceId === "string" && UUID_PATTERN.test(resourceId)
    ? { resourceType: mapping[0], resourceId }
    : null;
}

function expectedVersion(request: RpcRequest): number | undefined {
  const value = request.expectedVersion ?? request.expectedLatestResultVersion;
  return isVersion(value, 0) ? value : undefined;
}

function mapResult(data: unknown, request: RpcRequest, functionName: string): OperationalMutationResult {
  if (!data || typeof data !== "object" || Array.isArray(data)) {
    throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
  }
  const value = data as Record<string, unknown>;
  if (["applied", "created", "updated", "requested", "recorded", "read", "revoked", "accepted", "imported", "replayed"].includes(String(value.status))) {
    const resource = appliedResource(value, functionName);
    const resultVersion = value.resultVersion ?? value.version;
    if (!resource || (resultVersion !== undefined && !isVersion(resultVersion))) {
      throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
    }
    return Object.freeze({
      status: "applied",
      ...resource,
      ...(resultVersion === undefined ? {} : { version: resultVersion as number }),
      replayed: value.status === "replayed",
    });
  }
  if (value.status === "conflict") {
    const expected = expectedVersion(request);
    const actual = isVersion(value.actualVersion, 0) ? value.actualVersion : undefined;
    return Object.freeze({
      status: "conflict",
      ...(expected === undefined ? {} : { expectedVersion: expected }),
      ...(actual === undefined ? {} : { actualVersion: actual }),
    });
  }
  if (value.status === "identity_conflict" || value.status === "review_required") {
    return Object.freeze({ status: "denied", reason: "invalid_request" });
  }
  if (value.status === "denied" && typeof value.reason === "string" && DENIED_REASONS.has(value.reason)) {
    return Object.freeze({
      status: "denied",
      reason: value.reason as "not_authorized" | "entitlement_restricted" | "invalid_request" | "not_found" | "enhancement_unavailable",
    });
  }
  throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
}

export function createSupabaseOperationalPersistence(client: OperationalRpcClient): OperationalPersistence {
  async function invoke(functionName: string, request: RpcRequest): Promise<OperationalMutationResult> {
    let response: { readonly data: unknown; readonly error: unknown };
    try {
      response = await client.rpc(functionName, { p_request: request });
    } catch {
      throw new OperationalRpcError("OPERATION_RPC_UNAVAILABLE");
    }
    if (response.error) {
      const code = isRecord(response.error) ? response.error.code : undefined;
      if (code === "42501") return { status: "denied", reason: "not_authorized" };
      if (code === "22023") return { status: "denied", reason: "invalid_request" };
      throw new OperationalRpcError("OPERATION_RPC_UNAVAILABLE");
    }
    return mapResult(response.data, request, functionName);
  }

  return {
    createManualLead: (command) => invoke(RPC_NAMES.createManualLead, {
      ...baseRequest(command),
      source: command.source,
      firstName: command.firstName,
      lastName: command.lastName,
      ...(command.email ? { email: command.email } : {}),
      ...(command.phone ? { phone: command.phone } : {}),
      zipCode: command.zipCode,
      service: command.service,
      urgency: command.urgency,
      ...(command.notes ? { notes: command.notes } : {}),
      ...(command.assigneeId ? { assigneeId: command.assigneeId } : {}),
    }),
    applyLeadCommand: ({ operation, command }) => {
      const value = command as unknown as Record<string, unknown>;
      return invoke(RPC_NAMES.applyLeadCommand, {
        ...baseRequest(command),
        expectedVersion: command.expectedVersion,
        leadId: command.leadId,
        action: operation,
        ...(operation === "status" ? { status: value.to } : {}),
        ...(operation === "priority" ? { priority: value.priority } : {}),
        ...(operation === "note" ? { body: value.body } : {}),
        ...(operation === "assignment" ? { assigneeId: value.assigneeId } : {}),
      });
    },
    createLeadTask: ({ expectedLeadVersion, command }) => invoke(RPC_NAMES.createLeadTask, {
      ...baseRequest(command),
      expectedVersion: expectedLeadVersion,
      leadId: command.leadId,
      title: command.title,
      ...(command.assigneeId ? { assigneeId: command.assigneeId } : {}),
      ...(command.priority ? { priority: command.priority } : {}),
      ...(command.dueAt ? { dueAt: command.dueAt } : {}),
    }),
    recordLeadServiceEvent: ({ expectedLeadVersion, command }) => invoke(RPC_NAMES.recordLeadServiceEvent, {
      ...baseRequest({
        siteId: command.siteId,
        actor: command.origin.type === "manual" ? command.origin.actor : { type: "provider" },
        idempotencyKey: command.idempotencyKey,
      }),
      expectedVersion: expectedLeadVersion,
      leadId: command.leadId,
      eventKind: command.kind,
      ...(command.purpose ? { purpose: command.purpose } : {}),
      ...(command.scheduledAt ? { scheduledAt: command.scheduledAt } : {}),
      occurredAt: command.occurredAt,
    }),
    reviewFormSubmission: ({ operation, command }) => invoke(RPC_NAMES.reviewFormSubmission, {
      ...baseRequest(command),
      submissionId: command.submissionId,
      action: operation,
      expectedVersion: command.expectedVersion,
      ...(command.reasonCode ? { reasonCode: command.reasonCode } : {}),
    }),
    importFormSubmission: (command) => invoke(RPC_NAMES.importFormSubmission, {
      ...baseRequest(command),
      submissionId: command.submissionId,
      expectedLatestResultVersion: command.expectedLatestResultVersion,
      aal2VerifiedAt: command.aal2VerifiedAt,
    }),
    updateCustomerProfile: (command) => invoke(RPC_NAMES.updateCustomerProfile, {
      ...baseRequest(command),
      expectedVersion: command.expectedVersion,
      customerId: command.customerId,
      patch: command.patch,
    }),
    reviewCustomerMerge: (command) => invoke(RPC_NAMES.reviewCustomerMerge, {
      ...baseRequest(command),
      expectedVersion: command.expectedVersion,
      suggestionId: command.suggestionId,
      decision: command.decision,
    }),
    executeCustomerMerge: (command) => invoke(RPC_NAMES.executeCustomerMerge, {
      ...baseRequest(command),
      suggestionId: command.suggestionId,
      expectedSuggestionVersion: command.expectedSuggestionVersion,
      sourceId: command.sourceId,
      targetId: command.targetId,
      expectedSourceVersion: command.expectedSourceVersion,
      expectedTargetVersion: command.expectedTargetVersion,
    }),
    requestCustomerExport: (command) => invoke(RPC_NAMES.requestCustomerExport, {
      ...baseRequest(command),
      filters: {
        ...(command.filter ?? {}),
        ...(command.customerIds ? { customerIds: command.customerIds } : {}),
      },
      aal2VerifiedAt: command.aal2VerifiedAt,
    }),
    requestCustomerDeletion: (command) => invoke(RPC_NAMES.requestCustomerDeletion, {
      ...baseRequest(command),
      customerId: command.customerId,
      reason: command.reason,
      aal2VerifiedAt: command.aal2VerifiedAt,
    }),
    markNotificationRead: (command) => invoke(RPC_NAMES.markNotificationRead, {
      version: 1,
      commandId: command.idempotencyKey,
      siteId: command.siteId,
      actorId: command.recipientMemberId,
      idempotencyKey: command.idempotencyKey,
      notificationId: command.notificationId,
      readAt: command.readAt,
    }),
    createMemberInvitation: async (command) => {
      requireSha256Hex(command.canonicalEmailDigest);
      requireSha256Hex(command.tokenHash);
      return invoke(RPC_NAMES.createMemberInvitation, {
      version: 1,
      commandId: command.idempotencyKey,
      siteId: command.siteId,
      actorId: command.actorId,
      idempotencyKey: command.idempotencyKey,
      canonicalEmailDigest: command.canonicalEmailDigest,
      tokenHash: command.tokenHash,
      templateId: command.templateId,
      templateVersion: command.templateVersion,
      expiresAt: command.expiresAt,
      aal2VerifiedAt: command.aal2VerifiedAt,
      });
    },
    revokeMemberInvitation: (command) => invoke(RPC_NAMES.revokeMemberInvitation, {
      version: 1,
      commandId: command.idempotencyKey,
      siteId: command.siteId,
      actorId: command.actorId,
      idempotencyKey: command.idempotencyKey,
      invitationId: command.invitationId,
      expectedVersion: command.expectedVersion,
      reason: command.reason,
      aal2VerifiedAt: command.aal2VerifiedAt,
    }),
    acceptMemberInvitation: async (command) => {
      requireSha256Hex(command.canonicalEmailDigest);
      requireSha256Hex(command.tokenHash);
      return invoke(RPC_NAMES.acceptMemberInvitation, {
      version: 1,
      commandId: command.idempotencyKey,
      siteId: command.siteId,
      authenticatedUserId: command.authenticatedUserId,
      canonicalEmailDigest: command.canonicalEmailDigest,
      tokenHash: command.tokenHash,
      idempotencyKey: command.idempotencyKey,
      });
    },
  };
}

const SHA256_HEX_PATTERN = /^[0-9a-f]{64}$/;

function requireSha256Hex(value: string): void {
  if (!SHA256_HEX_PATTERN.test(value)) {
    throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}
