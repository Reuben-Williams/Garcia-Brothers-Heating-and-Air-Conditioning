export const RESIDUAL_OPERATION_LIMITS = Object.freeze({
  maxBulkRecords: 100,
  maxSavedViewClauses: 20,
  maxSearchLength: 200,
} as const);

export type ResidualJsonValue =
  | null
  | boolean
  | number
  | string
  | readonly ResidualJsonValue[]
  | { readonly [key: string]: ResidualJsonValue };

export type ResidualLeadStatus = "new" | "contacted" | "qualified" | "won" | "lost" | "spam";
export type ResidualLeadPriority = "low" | "normal" | "high" | "urgent";
export type ResidualLeadSource = "website_form" | "phone" | "walk_in" | "staff_entry" | "import";

export interface ResidualBulkLeadRecord {
  readonly leadId: string;
  readonly expectedVersion: number;
}

interface ResidualBulkLeadRequestBase {
  readonly idempotencyKey: string;
  readonly records: readonly ResidualBulkLeadRecord[];
}

export type ResidualBulkLeadOperationRequest =
  | (ResidualBulkLeadRequestBase & { readonly action: "status"; readonly status: ResidualLeadStatus })
  | (ResidualBulkLeadRequestBase & { readonly action: "assignment"; readonly assigneeId: string })
  | (ResidualBulkLeadRequestBase & {
      readonly action: "tag";
      readonly tagId: string;
      readonly tagAction: "add" | "remove";
    });

export type ResidualBulkLeadRecordResult =
  | { readonly leadId: string; readonly status: "applied"; readonly version: number }
  | { readonly leadId: string; readonly status: "denied"; readonly reason: "not_authorized" | "invalid_request" }
  | {
      readonly leadId: string;
      readonly status: "conflict";
      readonly expectedVersion: number;
      readonly actualVersion: number;
    };

export interface ResidualBulkLeadOperationResult {
  readonly requestedCount: number;
  readonly results: readonly ResidualBulkLeadRecordResult[];
}

export interface ResidualBulkLeadResponseEnvelope extends ResidualBulkLeadOperationResult {
  readonly result: "completed";
}

export type ResidualSavedViewDomain = "leads" | "customers";
export type ResidualSavedViewOperator =
  | "equals"
  | "not_equals"
  | "in"
  | "contains"
  | "before"
  | "after"
  | "is_empty";

export interface ResidualSavedViewFilterClause {
  readonly field: string;
  readonly operator: ResidualSavedViewOperator;
  readonly value?: ResidualJsonValue;
}

export interface ResidualSavedViewFilter {
  readonly version: 1;
  readonly conjunction: "all" | "any";
  readonly clauses: readonly ResidualSavedViewFilterClause[];
}

export interface ResidualSavedViewSaveRequest {
  readonly idempotencyKey: string;
  readonly expectedVersion: number;
  readonly viewId: string;
  readonly domain: ResidualSavedViewDomain;
  readonly name: string;
  readonly shared: boolean;
  readonly filter: ResidualSavedViewFilter;
}

export interface ResidualSavedViewRemoveRequest {
  readonly idempotencyKey: string;
  readonly expectedVersion: number;
  readonly domain: ResidualSavedViewDomain;
  readonly shared: boolean;
}

export interface ResidualCustomerPreferenceSetRequest {
  readonly idempotencyKey: string;
  readonly expectedVersion: number;
  readonly key: string;
  readonly value: ResidualJsonValue;
}

export interface ResidualCustomerPreferenceClearRequest {
  readonly idempotencyKey: string;
  readonly expectedVersion: number;
  readonly key: string;
}

export interface ResidualCustomerSuppressionSetRequest {
  readonly idempotencyKey: string;
  readonly suppressionId: string;
  readonly channel: "email" | "sms" | "phone";
  readonly reason: "unsubscribe" | "bounce" | "complaint" | "manual";
  readonly active: boolean;
}

export interface ResidualRecordTagRequest {
  readonly idempotencyKey: string;
  readonly tagId: string;
  readonly action: "add" | "remove";
}

export interface ResidualLeadsExportFilter {
  readonly search?: string;
  readonly statuses?: readonly ResidualLeadStatus[];
  readonly services?: readonly string[];
  readonly assigneeIds?: readonly string[];
  readonly sources?: readonly ResidualLeadSource[];
  readonly priorities?: readonly ResidualLeadPriority[];
  readonly createdFrom?: string;
  readonly createdTo?: string;
  readonly unassigned?: boolean;
}

export interface ResidualLeadsExportRequest {
  readonly idempotencyKey: string;
  readonly filter?: ResidualLeadsExportFilter;
}
