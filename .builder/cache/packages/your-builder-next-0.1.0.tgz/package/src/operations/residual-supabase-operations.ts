import type { OperationalMutationResult, OperationalResourceType } from "./contracts.js";
import type {
  ResidualBulkLeadOperationResult,
  ResidualBulkLeadRecord,
  ResidualJsonValue,
  ResidualLeadPriority,
  ResidualLeadSource,
  ResidualLeadStatus,
  ResidualLeadsExportFilter,
  ResidualSavedViewDomain,
  ResidualSavedViewFilter,
} from "./residual-contracts.js";
import {
  OperationalRpcError,
  type OperationalRpcClient,
} from "./supabase-operations.js";

const RPC_NAMES = Object.freeze({
  bulkApplyLeads: "builder_bulk_apply_leads_v1",
  saveView: "builder_save_view_v1",
  removeSavedView: "builder_remove_saved_view_v1",
  setCustomerPreference: "builder_set_customer_preference_v1",
  clearCustomerPreference: "builder_clear_customer_preference_v1",
  setCustomerSuppression: "builder_set_customer_suppression_v1",
  setRecordTag: "builder_set_record_tag_v1",
  requestLeadsExport: "builder_request_leads_export_v1",
} as const);

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const DENIED_REASONS = new Set(["not_authorized", "invalid_request"]);

type MemberActor = { readonly type: "member"; readonly id: string };
type RpcRequest = Readonly<Record<string, unknown>>;

interface ResidualCommandContext {
  readonly siteId: string;
  readonly actor: MemberActor;
  readonly idempotencyKey: string;
}

export type BulkApplyLeadsPersistenceCommand = ResidualCommandContext & (
  | {
      readonly action: "status";
      readonly records: readonly ResidualBulkLeadRecord[];
      readonly status: ResidualLeadStatus;
    }
  | {
      readonly action: "assignment";
      readonly records: readonly ResidualBulkLeadRecord[];
      readonly assigneeId: string;
    }
  | {
      readonly action: "tag";
      readonly records: readonly ResidualBulkLeadRecord[];
      readonly tagId: string;
      readonly tagAction: "add" | "remove";
    }
);

export interface SaveViewPersistenceCommand extends ResidualCommandContext {
  readonly expectedVersion: number;
  readonly viewId: string;
  readonly domain: ResidualSavedViewDomain;
  readonly name: string;
  readonly shared: boolean;
  readonly filter: ResidualSavedViewFilter;
  readonly aal2VerifiedAt?: string;
}

export interface RemoveSavedViewPersistenceCommand extends ResidualCommandContext {
  readonly expectedVersion: number;
  readonly viewId: string;
  readonly domain: ResidualSavedViewDomain;
  readonly shared: boolean;
  readonly aal2VerifiedAt?: string;
}

export interface SetCustomerPreferencePersistenceCommand extends ResidualCommandContext {
  readonly expectedVersion: number;
  readonly customerId: string;
  readonly key: string;
  readonly value: ResidualJsonValue;
}

export interface ClearCustomerPreferencePersistenceCommand extends ResidualCommandContext {
  readonly expectedVersion: number;
  readonly customerId: string;
  readonly key: string;
}

export interface SetCustomerSuppressionPersistenceCommand extends ResidualCommandContext {
  readonly customerId: string;
  readonly suppressionId: string;
  readonly channel: "email" | "sms" | "phone";
  readonly reason: "unsubscribe" | "bounce" | "complaint" | "manual";
  readonly active: boolean;
}

export interface SetRecordTagPersistenceCommand extends ResidualCommandContext {
  readonly recordType: "lead" | "customer";
  readonly recordId: string;
  readonly tagId: string;
  readonly action: "add" | "remove";
}

export interface RequestLeadsExportPersistenceCommand extends ResidualCommandContext {
  readonly filter?: ResidualLeadsExportFilter;
  readonly aal2VerifiedAt: string;
}

export interface ResidualOperationalPersistence {
  bulkApplyLeads(command: BulkApplyLeadsPersistenceCommand): Promise<ResidualBulkLeadOperationResult>;
  saveView(command: SaveViewPersistenceCommand): Promise<OperationalMutationResult>;
  removeSavedView(command: RemoveSavedViewPersistenceCommand): Promise<OperationalMutationResult>;
  setCustomerPreference(command: SetCustomerPreferencePersistenceCommand): Promise<OperationalMutationResult>;
  clearCustomerPreference(command: ClearCustomerPreferencePersistenceCommand): Promise<OperationalMutationResult>;
  setCustomerSuppression(command: SetCustomerSuppressionPersistenceCommand): Promise<OperationalMutationResult>;
  setRecordTag(command: SetRecordTagPersistenceCommand): Promise<OperationalMutationResult>;
  requestLeadsExport(command: RequestLeadsExportPersistenceCommand): Promise<OperationalMutationResult>;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function isVersion(value: unknown, minimum = 1): value is number {
  return Number.isInteger(value) && (value as number) >= minimum && (value as number) <= 2_147_483_647;
}

function requireUuid(value: string): string {
  if (!UUID_PATTERN.test(value)) throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
  return value;
}

function baseRequest(command: ResidualCommandContext): RpcRequest {
  return {
    version: 1,
    commandId: requireUuid(command.idempotencyKey),
    siteId: requireUuid(command.siteId),
    actorId: requireUuid(command.actor.id),
    idempotencyKey: command.idempotencyKey,
  };
}

function expectedVersion(request: RpcRequest): number | undefined {
  return isVersion(request.expectedVersion, 0) ? request.expectedVersion : undefined;
}

function mapMutationResult(
  data: unknown,
  request: RpcRequest,
  resourceType: OperationalResourceType,
  idKey: string,
): OperationalMutationResult {
  if (!isRecord(data)) throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
  const successStatuses = new Set([
    "applied", "created", "updated", "saved", "removed", "cleared", "set", "requested", "replayed",
  ]);
  if (successStatuses.has(String(data.status))) {
    const resourceId = data[idKey];
    const resultVersion = data.resultVersion;
    if (typeof resourceId !== "string" || !UUID_PATTERN.test(resourceId)) {
      throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
    }
    if (resultVersion !== undefined && !isVersion(resultVersion)) {
      throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
    }
    return Object.freeze({
      status: "applied",
      resourceType,
      resourceId,
      ...(resultVersion === undefined ? {} : { version: resultVersion }),
      replayed: data.status === "replayed",
    });
  }
  if (data.status === "conflict") {
    const expected = expectedVersion(request);
    const actual = isVersion(data.actualVersion, 0) ? data.actualVersion : undefined;
    return Object.freeze({
      status: "conflict",
      ...(expected === undefined ? {} : { expectedVersion: expected }),
      ...(actual === undefined ? {} : { actualVersion: actual }),
    });
  }
  if (data.status === "denied" && typeof data.reason === "string" && DENIED_REASONS.has(data.reason)) {
    return Object.freeze({ status: "denied", reason: data.reason as "not_authorized" | "invalid_request" });
  }
  throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
}

function mapBulkResult(
  data: unknown,
  records: readonly ResidualBulkLeadRecord[],
): ResidualBulkLeadOperationResult {
  if (isRecord(data) && data.status === "denied" && typeof data.reason === "string" && DENIED_REASONS.has(data.reason)) {
    const reason = data.reason as "not_authorized" | "invalid_request";
    return Object.freeze({
      requestedCount: records.length,
      results: Object.freeze(records.map((record) => Object.freeze({
        leadId: record.leadId,
        status: "denied" as const,
        reason,
      }))),
    });
  }
  if (!isRecord(data) || !["applied", "replayed"].includes(String(data.status)) || !Array.isArray(data.results)) {
    throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
  }
  if (data.results.length !== records.length) throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
  const requested = new Map(records.map((record) => [record.leadId, record]));
  const mapped = new Map<string, ResidualBulkLeadOperationResult["results"][number]>();
  for (const item of data.results) {
    if (!isRecord(item) || typeof item.leadId !== "string" || !UUID_PATTERN.test(item.leadId)) {
      throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
    }
    const record = requested.get(item.leadId);
    if (!record || mapped.has(item.leadId)) throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
    if (item.status === "applied" && isVersion(item.resultVersion)) {
      mapped.set(item.leadId, Object.freeze({ leadId: item.leadId, status: "applied", version: item.resultVersion }));
      continue;
    }
    if (
      item.status === "denied"
      && typeof item.reason === "string"
      && ["not_authorized", "invalid_request", "not_found", "invalid_transition"].includes(item.reason)
    ) {
      mapped.set(item.leadId, Object.freeze({
        leadId: item.leadId,
        status: "denied",
        reason: item.reason === "not_authorized" ? "not_authorized" : "invalid_request",
      }));
      continue;
    }
    if (
      item.status === "conflict"
      && item.expectedVersion === record.expectedVersion
      && isVersion(item.expectedVersion, 0)
      && isVersion(item.actualVersion, 0)
    ) {
      mapped.set(item.leadId, Object.freeze({
        leadId: item.leadId,
        status: "conflict",
        expectedVersion: item.expectedVersion,
        actualVersion: item.actualVersion,
      }));
      continue;
    }
    throw new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE");
  }
  return Object.freeze({
    requestedCount: records.length,
    results: Object.freeze(records.map((record) => mapped.get(record.leadId)!)),
  });
}

function serializeLeadsExportFilter(filter: ResidualLeadsExportFilter | undefined): RpcRequest {
  if (!filter) return {};
  const { search, ...fields } = filter;
  return { ...fields, ...(search ? { query: search } : {}) };
}

export function createSupabaseResidualOperationalPersistence(
  client: OperationalRpcClient,
): ResidualOperationalPersistence {
  async function call(functionName: string, request: RpcRequest): Promise<unknown> {
    let response: { readonly data: unknown; readonly error: unknown };
    try {
      response = await client.rpc(functionName, { p_request: request });
    } catch {
      throw new OperationalRpcError("OPERATION_RPC_UNAVAILABLE");
    }
    if (response.error) {
      const code = isRecord(response.error) ? response.error.code : undefined;
      if (code === "42501") return { status: "denied", reason: "not_authorized" };
      if (code === "22023") return { status: "denied", reason: "invalid_request" };
      throw new OperationalRpcError("OPERATION_RPC_UNAVAILABLE");
    }
    return response.data;
  }

  async function mutate(
    functionName: string,
    request: RpcRequest,
    resourceType: OperationalResourceType,
    idKey: string,
  ): Promise<OperationalMutationResult> {
    return mapMutationResult(await call(functionName, request), request, resourceType, idKey);
  }

  return {
    bulkApplyLeads: async (command) => {
      const request: RpcRequest = {
        ...baseRequest(command),
        operation: command.action === "tag" ? `tag_${command.tagAction}` : command.action,
        records: command.records.map((record) => ({ id: record.leadId, expectedVersion: record.expectedVersion })),
        ...(command.action === "status" ? { status: command.status } : {}),
        ...(command.action === "assignment" ? { assigneeId: command.assigneeId } : {}),
        ...(command.action === "tag" ? { tagId: command.tagId } : {}),
      };
      return mapBulkResult(await call(RPC_NAMES.bulkApplyLeads, request), command.records);
    },
    saveView: (command) => {
      const request: RpcRequest = {
        ...baseRequest(command),
        expectedVersion: command.expectedVersion,
        viewId: command.viewId,
        domain: command.domain,
        name: command.name,
        visibility: command.shared ? "site" : "private",
        filterAst: command.filter,
      };
      return mutate(RPC_NAMES.saveView, request, "saved_view", "viewId");
    },
    removeSavedView: (command) => {
      const request: RpcRequest = {
        ...baseRequest(command),
        expectedVersion: command.expectedVersion,
        viewId: command.viewId,
      };
      return mutate(RPC_NAMES.removeSavedView, request, "saved_view", "viewId");
    },
    setCustomerPreference: (command) => {
      const request: RpcRequest = {
        ...baseRequest(command),
        expectedVersion: command.expectedVersion,
        customerId: command.customerId,
        key: command.key,
        value: command.value,
      };
      return mutate(RPC_NAMES.setCustomerPreference, request, "customer_preference", "customerId");
    },
    clearCustomerPreference: (command) => {
      const request: RpcRequest = {
        ...baseRequest(command),
        expectedVersion: command.expectedVersion,
        customerId: command.customerId,
        key: command.key,
      };
      return mutate(RPC_NAMES.clearCustomerPreference, request, "customer_preference", "customerId");
    },
    setCustomerSuppression: (command) => {
      const request: RpcRequest = {
        ...baseRequest(command),
        customerId: command.customerId,
        suppressionId: command.suppressionId,
        operation: command.active ? "suppress" : "unsuppress",
        channel: command.channel,
        reason: command.reason,
        expectedState: command.active ? "absent" : "active",
      };
      return mutate(RPC_NAMES.setCustomerSuppression, request, "customer_suppression", "suppressionId");
    },
    setRecordTag: (command) => {
      const request: RpcRequest = {
        ...baseRequest(command),
        resourceType: command.recordType,
        resourceId: command.recordId,
        tagId: command.tagId,
        operation: command.action,
      };
      return mutate(RPC_NAMES.setRecordTag, request, "record_tag", "resourceId");
    },
    requestLeadsExport: (command) => {
      const request: RpcRequest = {
        ...baseRequest(command),
        filters: serializeLeadsExportFilter(command.filter),
      };
      return mutate(RPC_NAMES.requestLeadsExport, request, "data_export", "exportId");
    },
  };
}

export type {
  ResidualLeadPriority,
  ResidualLeadSource,
};
