import type { BuilderCapabilityScope, GrowthCapability } from "@your-builder/core";
import { RequestBodyReadError, readBoundedRequestBody } from "@your-builder/entitlements/trust";
import { CUSTOMER_SEGMENT_FIELDS } from "@your-builder/growth-customers";
import { SAVED_VIEW_FILTER_OPERATORS } from "@your-builder/growth-core";
import { LEAD_STATUSES } from "@your-builder/growth-leads";
import type { OperationalMutationResult, OperationalResponseEnvelope } from "./contracts.js";
import type {
  ResidualBulkLeadRecord,
  ResidualBulkLeadResponseEnvelope,
  ResidualJsonValue,
  ResidualLeadPriority,
  ResidualLeadSource,
  ResidualLeadsExportFilter,
  ResidualSavedViewDomain,
  ResidualSavedViewFilter,
  ResidualSavedViewFilterClause,
  ResidualSavedViewOperator,
} from "./residual-contracts.js";
import { RESIDUAL_OPERATION_LIMITS } from "./residual-contracts.js";
import type {
  BulkApplyLeadsPersistenceCommand,
  ResidualOperationalPersistence,
} from "./residual-supabase-operations.js";
import {
  OperationalAuthorizationError,
  type OperationalAuthorizationRequirement,
  type OperationalAuthorizer,
  type TrustedOperationalContext,
} from "./route-handlers.js";

const MAX_BODY_BYTES = 16 * 1024;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const KEY_PATTERN = /^[a-z][a-z0-9._-]{0,63}$/;
const decoder = new TextDecoder("utf-8", { fatal: true });
const encoder = new TextEncoder();
const RESPONSE_HEADERS = { "cache-control": "no-store" } as const;
const LEAD_SAVED_VIEW_FIELDS = Object.freeze([
  "status", "service", "assignee_id", "source", "priority", "created_at", "updated_at",
  "unassigned", "estimate_scheduled",
] as const);
const LEAD_PRIORITIES = Object.freeze(["low", "normal", "high", "urgent"] as const);
const LEAD_SOURCES = Object.freeze(["website_form", "phone", "walk_in", "staff_entry", "import"] as const);
const SUPPRESSION_REASONS = Object.freeze(["unsubscribe", "bounce", "complaint", "manual"] as const);

export interface ResidualOperationalRouteDependencies {
  readonly siteId: string;
  readonly authorizer: OperationalAuthorizer;
  readonly persistence: ResidualOperationalPersistence;
}

type RequestErrorCode =
  | "METHOD_NOT_ALLOWED"
  | "UNSUPPORTED_MEDIA_TYPE"
  | "PAYLOAD_TOO_LARGE"
  | "INVALID_REQUEST"
  | "IDEMPOTENCY_KEY_MISMATCH"
  | "ORIGIN_REQUIRED"
  | "ORIGIN_REJECTED";

class ResidualRequestError extends Error {
  constructor(
    readonly status: 400 | 403 | 405 | 413 | 415,
    readonly code: RequestErrorCode,
    message: string,
  ) {
    super(message);
    this.name = "ResidualRequestError";
  }
}

function invalidRequest(): never {
  throw new ResidualRequestError(400, "INVALID_REQUEST", "The operation request is invalid.");
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function requireExactKeys(record: Record<string, unknown>, keys: readonly string[]): void {
  const allowed = new Set(keys);
  if (Object.keys(record).some((key) => !allowed.has(key))) invalidRequest();
}

function uuid(value: unknown): string {
  if (typeof value !== "string" || !UUID_PATTERN.test(value)) invalidRequest();
  return value;
}

function version(value: unknown, minimum = 1): number {
  if (!Number.isInteger(value) || (value as number) < minimum || (value as number) > 2_147_483_647) invalidRequest();
  return value as number;
}

function requiredText(value: unknown, maximum: number): string {
  if (typeof value !== "string") invalidRequest();
  const normalized = value.trim();
  if (!normalized || normalized.length > maximum) invalidRequest();
  return normalized;
}

function strictBoolean(value: unknown): boolean {
  if (typeof value !== "boolean") invalidRequest();
  return value;
}

function optionalBoolean(value: unknown): boolean | undefined {
  return value === undefined ? undefined : strictBoolean(value);
}

function enumValue<const T extends readonly string[]>(value: unknown, values: T): T[number] {
  if (typeof value !== "string" || !(values as readonly string[]).includes(value)) invalidRequest();
  return value as T[number];
}

function isoTimestamp(value: unknown): string {
  if (typeof value !== "string") invalidRequest();
  const milliseconds = Date.parse(value);
  if (!Number.isFinite(milliseconds) || new Date(milliseconds).toISOString() !== value) invalidRequest();
  return value;
}

function requireSameOrigin(request: Request): void {
  const origin = request.headers.get("origin");
  if (!origin) throw new ResidualRequestError(403, "ORIGIN_REQUIRED", "A same-origin request is required.");
  let normalizedOrigin: string;
  try {
    const parsed = new URL(origin);
    if (parsed.origin !== origin || !["https:", "http:"].includes(parsed.protocol)) throw new Error("invalid");
    normalizedOrigin = parsed.origin;
  } catch {
    throw new ResidualRequestError(403, "ORIGIN_REJECTED", "The request origin is not allowed.");
  }
  const fetchSite = request.headers.get("sec-fetch-site");
  if (new URL(request.url).origin !== normalizedOrigin || (fetchSite && fetchSite !== "same-origin")) {
    throw new ResidualRequestError(403, "ORIGIN_REJECTED", "The request origin is not allowed.");
  }
}

async function readJson(request: Request): Promise<Record<string, unknown>> {
  if (request.method !== "POST") {
    throw new ResidualRequestError(405, "METHOD_NOT_ALLOWED", "Only POST requests are accepted.");
  }
  if (request.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() !== "application/json") {
    throw new ResidualRequestError(415, "UNSUPPORTED_MEDIA_TYPE", "A JSON request body is required.");
  }
  requireSameOrigin(request);
  let value: unknown;
  try {
    value = JSON.parse(decoder.decode(await readBoundedRequestBody(request, MAX_BODY_BYTES)));
  } catch (error) {
    if (error instanceof RequestBodyReadError && error.code === "payload_too_large") {
      throw new ResidualRequestError(413, "PAYLOAD_TOO_LARGE", "The operation request is too large.");
    }
    invalidRequest();
  }
  if (!isRecord(value)) invalidRequest();
  return value;
}

function verifyIdempotency(request: Request, idempotencyKey: string): void {
  if (request.headers.get("x-idempotency-key")?.trim() !== idempotencyKey) {
    throw new ResidualRequestError(
      400,
      "IDEMPOTENCY_KEY_MISMATCH",
      "The idempotency key must match the request identifier.",
    );
  }
}

function validateJsonValue(value: unknown, depth = 0): value is ResidualJsonValue {
  if (depth > 10) return false;
  if (value === null || typeof value === "boolean" || typeof value === "string") return true;
  if (typeof value === "number") return Number.isFinite(value);
  if (Array.isArray(value)) return value.length <= 100 && value.every((item) => validateJsonValue(item, depth + 1));
  if (!isRecord(value) || Object.keys(value).length > 100) return false;
  return Object.values(value).every((item) => validateJsonValue(item, depth + 1));
}

function jsonValue(value: unknown, maximumBytes: number): ResidualJsonValue {
  if (!validateJsonValue(value) || encoder.encode(JSON.stringify(value)).byteLength > maximumBytes) invalidRequest();
  return value;
}

function savedViewClauseValue(value: unknown): ResidualJsonValue {
  if (typeof value === "string") {
    if (value.length > 240) invalidRequest();
    return value;
  }
  if (typeof value === "number") {
    if (!Number.isFinite(value)) invalidRequest();
    return value;
  }
  if (typeof value === "boolean") return value;
  if (!Array.isArray(value) || value.length > 100) invalidRequest();
  return Object.freeze(value.map((item) => {
    if (typeof item === "string") {
      if (item.length > 240) invalidRequest();
      return item;
    }
    if (typeof item === "number") {
      if (!Number.isFinite(item)) invalidRequest();
      return item;
    }
    if (typeof item !== "boolean") invalidRequest();
    return item;
  }));
}

function bulkRecords(value: unknown): readonly ResidualBulkLeadRecord[] {
  if (!Array.isArray(value) || value.length < 1 || value.length > RESIDUAL_OPERATION_LIMITS.maxBulkRecords) {
    invalidRequest();
  }
  const records = value.map((item) => {
    if (!isRecord(item)) invalidRequest();
    requireExactKeys(item, ["leadId", "expectedVersion"]);
    return Object.freeze({ leadId: uuid(item.leadId), expectedVersion: version(item.expectedVersion) });
  });
  if (new Set(records.map((record) => record.leadId)).size !== records.length) invalidRequest();
  return Object.freeze(records);
}

function savedViewDomain(value: unknown): ResidualSavedViewDomain {
  return enumValue(value, ["leads", "customers"] as const);
}

function savedViewFilter(value: unknown, domain: ResidualSavedViewDomain): ResidualSavedViewFilter {
  if (!isRecord(value)) invalidRequest();
  requireExactKeys(value, ["version", "conjunction", "clauses"]);
  if (value.version !== 1 || (value.conjunction !== "all" && value.conjunction !== "any") || !Array.isArray(value.clauses)) {
    invalidRequest();
  }
  if (value.clauses.length > RESIDUAL_OPERATION_LIMITS.maxSavedViewClauses) invalidRequest();
  const allowedFields: readonly string[] = domain === "leads" ? LEAD_SAVED_VIEW_FIELDS : CUSTOMER_SEGMENT_FIELDS;
  const clauses: ResidualSavedViewFilterClause[] = value.clauses.map((clause) => {
    if (!isRecord(clause)) invalidRequest();
    requireExactKeys(clause, ["field", "operator", "value"]);
    const field = requiredText(clause.field, 64);
    const operator = enumValue(clause.operator, SAVED_VIEW_FILTER_OPERATORS) as ResidualSavedViewOperator;
    if (!allowedFields.includes(field)) invalidRequest();
    if (operator === "is_empty" && clause.value !== undefined) invalidRequest();
    if (operator !== "is_empty" && clause.value === undefined) invalidRequest();
    return Object.freeze({
      field,
      operator,
      ...(clause.value === undefined ? {} : { value: savedViewClauseValue(clause.value) }),
    });
  });
  const filter = Object.freeze({ version: 1 as const, conjunction: value.conjunction, clauses: Object.freeze(clauses) });
  if (encoder.encode(JSON.stringify(filter)).byteLength > 16_384) invalidRequest();
  return filter;
}

function uniqueTextArray(value: unknown, values?: readonly string[]): readonly string[] | undefined {
  if (value === undefined) return undefined;
  if (!Array.isArray(value) || value.length < 1 || value.length > 20) invalidRequest();
  const result = value.map((item) => requiredText(item, 100));
  if (new Set(result).size !== result.length || (values && result.some((item) => !values.includes(item)))) invalidRequest();
  return Object.freeze(result);
}

function uniqueUuidArray(value: unknown): readonly string[] | undefined {
  if (value === undefined) return undefined;
  if (!Array.isArray(value) || value.length < 1 || value.length > 100) invalidRequest();
  const result = value.map(uuid);
  if (new Set(result).size !== result.length) invalidRequest();
  return Object.freeze(result);
}

function leadsExportFilter(value: unknown): ResidualLeadsExportFilter | undefined {
  if (value === undefined) return undefined;
  if (!isRecord(value)) invalidRequest();
  requireExactKeys(value, [
    "search", "statuses", "services", "assigneeIds", "sources", "priorities", "createdFrom", "createdTo",
    "unassigned",
  ]);
  const search = value.search === undefined ? undefined : requiredText(value.search, RESIDUAL_OPERATION_LIMITS.maxSearchLength);
  const statuses = uniqueTextArray(value.statuses, LEAD_STATUSES);
  const services = uniqueTextArray(value.services);
  const assigneeIds = uniqueUuidArray(value.assigneeIds);
  const sources = uniqueTextArray(value.sources, LEAD_SOURCES);
  const priorities = uniqueTextArray(value.priorities, LEAD_PRIORITIES);
  const createdFrom = value.createdFrom === undefined ? undefined : isoTimestamp(value.createdFrom);
  const createdTo = value.createdTo === undefined ? undefined : isoTimestamp(value.createdTo);
  const unassigned = optionalBoolean(value.unassigned);
  if (createdFrom && createdTo && createdFrom > createdTo) invalidRequest();
  return Object.freeze({
    ...(search ? { search } : {}),
    ...(statuses ? { statuses: statuses as readonly (typeof LEAD_STATUSES)[number][] } : {}),
    ...(services ? { services } : {}),
    ...(assigneeIds ? { assigneeIds } : {}),
    ...(sources ? { sources: sources as readonly ResidualLeadSource[] } : {}),
    ...(priorities ? { priorities: priorities as readonly ResidualLeadPriority[] } : {}),
    ...(createdFrom ? { createdFrom } : {}),
    ...(createdTo ? { createdTo } : {}),
    ...(unassigned === undefined ? {} : { unassigned }),
  });
}

async function authorize(
  dependencies: ResidualOperationalRouteDependencies,
  request: Request,
  requirement: OperationalAuthorizationRequirement,
): Promise<TrustedOperationalContext> {
  const context = await dependencies.authorizer.authorize(request, requirement);
  if (context.siteId !== dependencies.siteId) throw new OperationalAuthorizationError("SITE_ACCESS_DENIED");
  if (!UUID_PATTERN.test(context.memberId)) throw new Error("Invalid trusted member identity.");
  if (!requirement.allowedScopes.includes(context.scope)) throw new OperationalAuthorizationError("OPERATION_DENIED");
  if (context.entitlementVerification !== "current" || context.entitlementMode !== requirement.entitlementMode) {
    throw new OperationalAuthorizationError("ENTITLEMENT_RESTRICTED");
  }
  return context;
}

function actor(context: TrustedOperationalContext): { readonly type: "member"; readonly id: string } {
  return Object.freeze({ type: "member", id: context.memberId });
}

function errorResponse(status: number, code: string, message: string): Response {
  return Response.json({ error: { code, message } }, { status, headers: RESPONSE_HEADERS });
}

function mutationResponse(result: OperationalMutationResult): Response {
  if (result.status === "conflict") {
    return Response.json({
      result: "conflict",
      ...(result.expectedVersion === undefined ? {} : { expectedVersion: result.expectedVersion }),
      ...(result.actualVersion === undefined ? {} : { actualVersion: result.actualVersion }),
    } satisfies OperationalResponseEnvelope, { status: 409, headers: RESPONSE_HEADERS });
  }
  if (result.status === "denied") {
    return Response.json(
      { result: "denied", code: "OPERATION_DENIED" } satisfies OperationalResponseEnvelope,
      { status: 403, headers: RESPONSE_HEADERS },
    );
  }
  return Response.json({
    result: "applied",
    resource: { type: result.resourceType, id: result.resourceId },
    ...(result.version === undefined ? {} : { version: result.version }),
    replayed: result.replayed,
  } satisfies OperationalResponseEnvelope, { status: 200, headers: RESPONSE_HEADERS });
}

async function execute(operation: () => Promise<Response>): Promise<Response> {
  try {
    return await operation();
  } catch (error) {
    if (error instanceof ResidualRequestError || error instanceof OperationalAuthorizationError) {
      return errorResponse(error.status, error.code, error.message);
    }
    return errorResponse(503, "OPERATION_UNAVAILABLE", "The operation is temporarily unavailable. Try again.");
  }
}

function requirement(
  dependencies: ResidualOperationalRouteDependencies,
  capability: GrowthCapability,
  allowedScopes: readonly BuilderCapabilityScope[],
  resource?: OperationalAuthorizationRequirement["resource"],
): OperationalAuthorizationRequirement {
  return {
    siteId: dependencies.siteId,
    capability,
    allowedScopes,
    entitlementMode: "operational_write",
    ...(resource ? { resource } : {}),
  };
}

async function recentAal2(
  dependencies: ResidualOperationalRouteDependencies,
  request: Request,
  context: TrustedOperationalContext,
): Promise<string> {
  return isoTimestamp((await dependencies.authorizer.requireRecentAal2(request, context)).verifiedAt);
}

export function createBulkLeadOperationRouteHandler(dependencies: ResidualOperationalRouteDependencies) {
  return {
    handle(request: Request): Promise<Response> {
      return execute(async () => {
        const body = await readJson(request);
        const action = enumValue(body.action, ["status", "assignment", "tag"] as const);
        requireExactKeys(body, action === "status"
          ? ["idempotencyKey", "action", "records", "status"]
          : action === "assignment"
            ? ["idempotencyKey", "action", "records", "assigneeId"]
            : ["idempotencyKey", "action", "records", "tagId", "tagAction"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const records = bulkRecords(body.records);
        const authRequirement = action === "assignment"
          ? requirement(dependencies, "leads.assign", ["site"])
          : requirement(dependencies, "leads.update", ["site", "assigned"]);
        const context = await authorize(dependencies, request, authRequirement);
        let command: BulkApplyLeadsPersistenceCommand;
        if (action === "status") {
          command = {
            siteId: dependencies.siteId,
            actor: actor(context),
            idempotencyKey,
            action,
            records,
            status: enumValue(body.status, LEAD_STATUSES),
          };
        } else if (action === "assignment") {
          command = {
            siteId: dependencies.siteId,
            actor: actor(context),
            idempotencyKey,
            action,
            records,
            assigneeId: uuid(body.assigneeId),
          };
        } else {
          command = {
            siteId: dependencies.siteId,
            actor: actor(context),
            idempotencyKey,
            action,
            records,
            tagId: uuid(body.tagId),
            tagAction: enumValue(body.tagAction, ["add", "remove"] as const),
          };
        }
        const result = await dependencies.persistence.bulkApplyLeads(command);
        return Response.json({ result: "completed", ...result } satisfies ResidualBulkLeadResponseEnvelope, {
          status: 200,
          headers: RESPONSE_HEADERS,
        });
      });
    },
  };
}

function savedViewRequirement(
  dependencies: ResidualOperationalRouteDependencies,
  domain: ResidualSavedViewDomain,
  shared: boolean,
  viewId?: string,
): OperationalAuthorizationRequirement {
  const capability: GrowthCapability = domain === "leads"
    ? (shared ? "leads.update" : "leads.read")
    : (shared ? "customers.update" : "customers.read");
  return requirement(
    dependencies,
    capability,
    shared ? ["site"] : ["site", "assigned"],
    viewId ? { type: "saved_view", id: viewId } : undefined,
  );
}

export function createSavedViewSaveRouteHandler(dependencies: ResidualOperationalRouteDependencies) {
  return {
    handle(request: Request): Promise<Response> {
      return execute(async () => {
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "expectedVersion", "viewId", "domain", "name", "shared", "filter"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const viewId = uuid(body.viewId);
        const expectedVersion = version(body.expectedVersion, 0);
        const domain = savedViewDomain(body.domain);
        const shared = strictBoolean(body.shared);
        const name = requiredText(body.name, 100);
        const filter = savedViewFilter(body.filter, domain);
        const context = await authorize(
          dependencies,
          request,
          savedViewRequirement(dependencies, domain, shared, expectedVersion === 0 ? undefined : viewId),
        );
        const aal2VerifiedAt = shared || expectedVersion > 0
          ? await recentAal2(dependencies, request, context)
          : undefined;
        return mutationResponse(await dependencies.persistence.saveView({
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey,
          expectedVersion,
          viewId,
          domain,
          name,
          shared,
          filter,
          ...(aal2VerifiedAt ? { aal2VerifiedAt } : {}),
        }));
      });
    },
  };
}

type SavedViewRouteContext = { readonly viewId: string };

export function createSavedViewRemoveRouteHandler(dependencies: ResidualOperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: SavedViewRouteContext): Promise<Response> {
      return execute(async () => {
        const viewId = uuid(routeContext.viewId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "expectedVersion", "domain", "shared"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const expectedVersion = version(body.expectedVersion);
        const domain = savedViewDomain(body.domain);
        const shared = strictBoolean(body.shared);
        const context = await authorize(dependencies, request, savedViewRequirement(dependencies, domain, shared, viewId));
        const aal2VerifiedAt = await recentAal2(dependencies, request, context);
        return mutationResponse(await dependencies.persistence.removeSavedView({
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey,
          expectedVersion,
          viewId,
          domain,
          shared,
          ...(aal2VerifiedAt ? { aal2VerifiedAt } : {}),
        }));
      });
    },
  };
}

type CustomerRouteContext = { readonly customerId: string };

function preferenceRequirement(
  dependencies: ResidualOperationalRouteDependencies,
  customerId: string,
  scopes: readonly BuilderCapabilityScope[] = ["site", "assigned"],
): OperationalAuthorizationRequirement {
  return requirement(dependencies, "customers.update", scopes, { type: "customer", id: customerId });
}

export function createCustomerPreferenceSetRouteHandler(dependencies: ResidualOperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: CustomerRouteContext): Promise<Response> {
      return execute(async () => {
        const customerId = uuid(routeContext.customerId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "expectedVersion", "key", "value"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const expectedVersion = version(body.expectedVersion, 0);
        const key = requiredText(body.key, 64);
        if (!KEY_PATTERN.test(key)) invalidRequest();
        const value = jsonValue(body.value, 4_096);
        const context = await authorize(dependencies, request, preferenceRequirement(dependencies, customerId));
        return mutationResponse(await dependencies.persistence.setCustomerPreference({
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey,
          expectedVersion,
          customerId,
          key,
          value,
        }));
      });
    },
  };
}

export function createCustomerPreferenceClearRouteHandler(dependencies: ResidualOperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: CustomerRouteContext): Promise<Response> {
      return execute(async () => {
        const customerId = uuid(routeContext.customerId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "expectedVersion", "key"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const key = requiredText(body.key, 64);
        if (!KEY_PATTERN.test(key)) invalidRequest();
        const context = await authorize(dependencies, request, preferenceRequirement(dependencies, customerId));
        return mutationResponse(await dependencies.persistence.clearCustomerPreference({
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey,
          expectedVersion: version(body.expectedVersion),
          customerId,
          key,
        }));
      });
    },
  };
}

export function createCustomerSuppressionSetRouteHandler(dependencies: ResidualOperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: CustomerRouteContext): Promise<Response> {
      return execute(async () => {
        const customerId = uuid(routeContext.customerId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "suppressionId", "channel", "reason", "active"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const context = await authorize(dependencies, request, preferenceRequirement(dependencies, customerId, ["site"]));
        return mutationResponse(await dependencies.persistence.setCustomerSuppression({
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey,
          customerId,
          suppressionId: uuid(body.suppressionId),
          channel: enumValue(body.channel, ["email", "sms", "phone"] as const),
          reason: enumValue(body.reason, SUPPRESSION_REASONS),
          active: strictBoolean(body.active),
        }));
      });
    },
  };
}

type RecordTagRouteContext = { readonly recordType: string; readonly recordId: string };

export function createRecordTagRouteHandler(dependencies: ResidualOperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: RecordTagRouteContext): Promise<Response> {
      return execute(async () => {
        const recordType = enumValue(routeContext.recordType, ["lead", "customer"] as const);
        const recordId = uuid(routeContext.recordId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "tagId", "action"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const capability: GrowthCapability = recordType === "lead" ? "leads.update" : "customers.update";
        const context = await authorize(dependencies, request, requirement(
          dependencies,
          capability,
          ["site", "assigned"],
          { type: recordType, id: recordId },
        ));
        return mutationResponse(await dependencies.persistence.setRecordTag({
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey,
          recordType,
          recordId,
          tagId: uuid(body.tagId),
          action: enumValue(body.action, ["add", "remove"] as const),
        }));
      });
    },
  };
}

export function createLeadsExportRouteHandler(dependencies: ResidualOperationalRouteDependencies) {
  return {
    handle(request: Request): Promise<Response> {
      return execute(async () => {
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "filter"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const filter = leadsExportFilter(body.filter);
        const context = await authorize(dependencies, request, requirement(dependencies, "leads.export", ["site"]));
        const aal2VerifiedAt = await recentAal2(dependencies, request, context);
        return mutationResponse(await dependencies.persistence.requestLeadsExport({
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey,
          ...(filter ? { filter } : {}),
          aal2VerifiedAt,
        }));
      });
    },
  };
}
