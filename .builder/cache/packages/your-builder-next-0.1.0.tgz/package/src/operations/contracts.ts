export type OperationalResourceType =
  | "lead"
  | "task"
  | "service_event"
  | "form_submission"
  | "customer"
  | "merge_suggestion"
  | "data_export"
  | "deletion_request"
  | "notification"
  | "member_invitation"
  | "member"
  | "saved_view"
  | "customer_preference"
  | "customer_suppression"
  | "record_tag";

export interface OperationalAppliedResult {
  readonly status: "applied";
  readonly resourceType: OperationalResourceType;
  readonly resourceId: string;
  readonly version?: number;
  readonly replayed: boolean;
}

export interface OperationalConflictResult {
  readonly status: "conflict";
  readonly expectedVersion?: number;
  readonly actualVersion?: number;
}

export type OperationalDeniedReason =
  | "not_authorized"
  | "entitlement_restricted"
  | "invalid_request"
  | "not_found"
  | "enhancement_unavailable";

export interface OperationalDeniedResult {
  readonly status: "denied";
  readonly reason: OperationalDeniedReason;
}

export type OperationalMutationResult =
  | OperationalAppliedResult
  | OperationalConflictResult
  | OperationalDeniedResult;

export type OperationalResponseEnvelope =
  | {
      readonly result: "applied";
      readonly resource: { readonly type: OperationalResourceType; readonly id: string };
      readonly version?: number;
      readonly replayed: boolean;
    }
  | { readonly result: "conflict"; readonly expectedVersion?: number; readonly actualVersion?: number }
  | { readonly result: "denied"; readonly code: "OPERATION_DENIED" };

export type MemberInvitationCreateResponseEnvelope =
  | {
      readonly result: "applied";
      readonly invitation: { readonly id: string; readonly token: string };
      readonly version?: number;
      readonly replayed: boolean;
    }
  | Extract<OperationalResponseEnvelope, { readonly result: "conflict" | "denied" }>;
