import type { BuilderCapabilityScope, BuilderRole, GrowthCapability } from "@your-builder/core";
import { RequestBodyReadError, readBoundedRequestBody } from "@your-builder/entitlements/trust";
import {
  SERVICE_EVENT_KINDS,
  type MarkInAppNotificationReadCommand,
  type MemberOperationActor,
} from "@your-builder/growth-core";
import type {
  RequestCustomerDeletionCommand,
  RequestCustomerExportCommand,
  ReviewCustomerMergeCommand,
  UpdateCustomerProfileCommand,
} from "@your-builder/growth-customers";
import {
  LEAD_STATUSES,
  MANUAL_LEAD_SOURCES,
  type AddLeadNoteCommand,
  type AssignLeadCommand,
  type BaseSubmissionReviewCommand,
  type ChangeLeadStatusCommand,
  type CreateLeadTaskCommand,
  type CreateManualLeadCommand,
  type ImportBaseSubmissionCommand,
  type RecordLeadServiceEventCommand,
  type SetLeadPriorityCommand,
} from "@your-builder/growth-leads";
import { normalizeNorthAmericanPhone } from "../ingestion/normalization.js";
import type {
  MemberInvitationCreateResponseEnvelope,
  OperationalMutationResult,
  OperationalResponseEnvelope,
} from "./contracts.js";
import type {
  ExecuteCustomerMergePersistenceCommand,
  OperationalPersistence,
} from "./supabase-operations.js";

const MAX_BODY_BYTES = 16 * 1024;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ZIP_PATTERN = /^\d{5}(?:-\d{4})?$/;
const REASON_PATTERN = /^[a-z][a-z0-9_]{1,63}$/;
const FILTER_KEY_PATTERN = /^[A-Za-z][A-Za-z0-9_]{0,63}$/;
const decoder = new TextDecoder("utf-8", { fatal: true });
const RESPONSE_HEADERS = { "cache-control": "no-store" } as const;

export type OperationalEntitlementMode = "operational_write" | "base_submission_review";

export interface OperationalAuthorizationRequirement {
  readonly siteId: string;
  readonly capability?: GrowthCapability;
  readonly allowedRoles?: readonly BuilderRole[];
  readonly allowedScopes: readonly BuilderCapabilityScope[];
  readonly entitlementMode: OperationalEntitlementMode;
  readonly resource?: {
    readonly type: "lead" | "form_submission" | "customer" | "merge_suggestion" | "notification" | "member_invitation" | "saved_view";
    readonly id: string;
  };
}

export interface TrustedOperationalContext {
  readonly siteId: string;
  readonly memberId: string;
  readonly role: BuilderRole;
  readonly scope: BuilderCapabilityScope;
  readonly entitlementVerification: "current" | "stale" | "missing" | "invalid";
  readonly entitlementMode: OperationalEntitlementMode;
}

export interface OperationalAuthorizer {
  authorize(
    request: Request,
    requirement: OperationalAuthorizationRequirement,
  ): Promise<TrustedOperationalContext>;
  requireRecentAal2(
    request: Request,
    context: TrustedOperationalContext,
  ): Promise<{ readonly verifiedAt: string }>;
  requireAuthenticatedUser(
    request: Request,
    requirement: { readonly siteId: string; readonly entitlementMode: OperationalEntitlementMode },
  ): Promise<TrustedAuthenticatedUserContext>;
}

export interface TrustedAuthenticatedUserContext {
  readonly siteId: string;
  readonly userId: string;
  readonly email: string | null;
  readonly entitlementVerification: "current" | "stale" | "missing" | "invalid";
  readonly entitlementMode: OperationalEntitlementMode;
}

export interface InvitationSecretAdapter {
  digestCanonicalEmail(canonicalEmail: string): Promise<string>;
  /** Must deterministically reproduce the token for an idempotency key within this adapter's site scope. */
  generateToken(idempotencyKey: string): Promise<string>;
  hashToken(token: string): Promise<string>;
}

export interface OperationalRouteDependencies {
  readonly siteId: string;
  readonly allowedServices: readonly string[];
  readonly authorizer: OperationalAuthorizer;
  readonly persistence: OperationalPersistence;
  readonly invitationSecrets: InvitationSecretAdapter;
  readonly now: () => Date;
}

export type OperationalAuthorizationErrorCode =
  | "AUTH_REQUIRED"
  | "SITE_ACCESS_DENIED"
  | "OPERATION_DENIED"
  | "ENTITLEMENT_RESTRICTED"
  | "AAL2_REQUIRED";

const authorizationErrors: Record<OperationalAuthorizationErrorCode, { status: 401 | 403 | 409; message: string }> = {
  AUTH_REQUIRED: { status: 401, message: "A verified member session is required." },
  SITE_ACCESS_DENIED: { status: 403, message: "This account cannot access the requested site." },
  OPERATION_DENIED: { status: 403, message: "This operation is not permitted." },
  ENTITLEMENT_RESTRICTED: { status: 409, message: "This operation is not available in the current access mode." },
  AAL2_REQUIRED: { status: 403, message: "Recent verification is required for this operation." },
};

export class OperationalAuthorizationError extends Error {
  readonly status: 401 | 403 | 409;

  constructor(public readonly code: OperationalAuthorizationErrorCode) {
    super(authorizationErrors[code].message);
    this.name = "OperationalAuthorizationError";
    this.status = authorizationErrors[code].status;
  }
}

type RequestErrorCode =
  | "METHOD_NOT_ALLOWED"
  | "UNSUPPORTED_MEDIA_TYPE"
  | "PAYLOAD_TOO_LARGE"
  | "INVALID_REQUEST"
  | "IDEMPOTENCY_KEY_MISMATCH"
  | "ORIGIN_REQUIRED"
  | "ORIGIN_REJECTED";

class OperationalRequestError extends Error {
  constructor(
    readonly status: 400 | 403 | 405 | 413 | 415,
    readonly code: RequestErrorCode,
    message: string,
  ) {
    super(message);
    this.name = "OperationalRequestError";
  }
}

function errorResponse(status: number, code: string, message: string): Response {
  return Response.json({ error: { code, message } }, { status, headers: RESPONSE_HEADERS });
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function requireExactKeys(record: Record<string, unknown>, allowed: readonly string[]): void {
  const allowedSet = new Set(allowed);
  if (Object.keys(record).some((key) => !allowedSet.has(key))) invalidRequest();
}

function invalidRequest(): never {
  throw new OperationalRequestError(400, "INVALID_REQUEST", "The operation request is invalid.");
}

function requiredText(value: unknown, maximum: number): string {
  if (typeof value !== "string") invalidRequest();
  const normalized = value.trim();
  if (!normalized || normalized.length > maximum) invalidRequest();
  return normalized;
}

function optionalText(value: unknown, maximum: number): string | undefined {
  if (value === undefined) return undefined;
  return requiredText(value, maximum);
}

function uuid(value: unknown): string {
  if (typeof value !== "string" || !UUID_PATTERN.test(value)) invalidRequest();
  return value;
}

function version(value: unknown, minimum = 1): number {
  if (!Number.isInteger(value) || (value as number) < minimum || (value as number) > 2_147_483_647) invalidRequest();
  return value as number;
}

function optionalBoolean(value: unknown): boolean | undefined {
  if (value === undefined) return undefined;
  if (typeof value !== "boolean") invalidRequest();
  return value;
}

function timestamp(value: unknown): string {
  if (typeof value !== "string") invalidRequest();
  const milliseconds = Date.parse(value);
  if (!Number.isFinite(milliseconds) || new Date(milliseconds).toISOString() !== value) invalidRequest();
  return value;
}

function requireSameOrigin(request: Request): void {
  const origin = request.headers.get("origin");
  if (!origin) {
    throw new OperationalRequestError(403, "ORIGIN_REQUIRED", "A same-origin request is required.");
  }
  let normalizedOrigin: string;
  try {
    const parsed = new URL(origin);
    if (parsed.origin !== origin || !["https:", "http:"].includes(parsed.protocol)) throw new Error("invalid");
    normalizedOrigin = parsed.origin;
  } catch {
    throw new OperationalRequestError(403, "ORIGIN_REJECTED", "The request origin is not allowed.");
  }
  const fetchSite = request.headers.get("sec-fetch-site");
  if (new URL(request.url).origin !== normalizedOrigin || (fetchSite && fetchSite !== "same-origin")) {
    throw new OperationalRequestError(403, "ORIGIN_REJECTED", "The request origin is not allowed.");
  }
}

async function readJson(request: Request): Promise<Record<string, unknown>> {
  if (request.method !== "POST") {
    throw new OperationalRequestError(405, "METHOD_NOT_ALLOWED", "Only POST requests are accepted.");
  }
  if (request.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() !== "application/json") {
    throw new OperationalRequestError(415, "UNSUPPORTED_MEDIA_TYPE", "A JSON request body is required.");
  }
  requireSameOrigin(request);
  let value: unknown;
  try {
    value = JSON.parse(decoder.decode(await readBoundedRequestBody(request, MAX_BODY_BYTES)));
  } catch (error) {
    if (error instanceof RequestBodyReadError && error.code === "payload_too_large") {
      throw new OperationalRequestError(413, "PAYLOAD_TOO_LARGE", "The operation request is too large.");
    }
    invalidRequest();
  }
  if (!isRecord(value)) invalidRequest();
  return value;
}

function canonicalEmail(value: unknown): string {
  const email = requiredText(value, 254).toLowerCase();
  if (!EMAIL_PATTERN.test(email)) invalidRequest();
  return email;
}

function boundedCustomerIds(value: unknown): readonly string[] | undefined {
  if (value === undefined) return undefined;
  if (!Array.isArray(value) || value.length < 1 || value.length > 100) invalidRequest();
  const ids = value.map(uuid);
  if (new Set(ids).size !== ids.length) invalidRequest();
  return ids;
}

function boundedExportFilter(value: unknown): Record<string, string | readonly string[]> | undefined {
  if (value === undefined) return undefined;
  if (!isRecord(value) || Object.keys(value).length > 10) invalidRequest();
  const output: Record<string, string | readonly string[]> = {};
  for (const [key, field] of Object.entries(value)) {
    if (!FILTER_KEY_PATTERN.test(key)) invalidRequest();
    if (typeof field === "string") {
      output[key] = requiredText(field, 100);
      continue;
    }
    if (!Array.isArray(field) || field.length < 1 || field.length > 20) invalidRequest();
    output[key] = field.map((item) => requiredText(item, 100));
  }
  return output;
}

function trustedNow(dependencies: OperationalRouteDependencies): string {
  const value = dependencies.now();
  if (!(value instanceof Date) || !Number.isFinite(value.getTime())) throw new Error("Invalid trusted clock.");
  return value.toISOString();
}

function commonCommand(
  record: Record<string, unknown>,
  minimumVersion = 1,
): { idempotencyKey: string; expectedVersion: number } {
  const idempotencyKey = uuid(record.idempotencyKey);
  return { idempotencyKey, expectedVersion: version(record.expectedVersion, minimumVersion) };
}

function verifyIdempotency(request: Request, idempotencyKey: string): void {
  if (request.headers.get("x-idempotency-key")?.trim() !== idempotencyKey) {
    throw new OperationalRequestError(
      400,
      "IDEMPOTENCY_KEY_MISMATCH",
      "The idempotency key must match the request identifier.",
    );
  }
}

async function authorize(
  dependencies: OperationalRouteDependencies,
  request: Request,
  requirement: OperationalAuthorizationRequirement,
): Promise<TrustedOperationalContext> {
  const context = await dependencies.authorizer.authorize(request, requirement);
  if (context.siteId !== dependencies.siteId) throw new OperationalAuthorizationError("SITE_ACCESS_DENIED");
  if (!UUID_PATTERN.test(context.memberId)) throw new Error("Invalid trusted member identity.");
  if (!requirement.allowedScopes.includes(context.scope)) throw new OperationalAuthorizationError("OPERATION_DENIED");
  if (requirement.allowedRoles && !requirement.allowedRoles.includes(context.role)) {
    throw new OperationalAuthorizationError("OPERATION_DENIED");
  }
  if (
    context.entitlementVerification !== "current" ||
    context.entitlementMode !== requirement.entitlementMode
  ) {
    throw new OperationalAuthorizationError("ENTITLEMENT_RESTRICTED");
  }
  return context;
}

function actor(context: TrustedOperationalContext): MemberOperationActor {
  return Object.freeze({ type: "member", id: context.memberId });
}

function resultResponse(result: OperationalMutationResult): Response {
  if (result.status === "conflict") {
    return Response.json({
      result: "conflict",
      ...(result.expectedVersion === undefined ? {} : { expectedVersion: result.expectedVersion }),
      ...(result.actualVersion === undefined ? {} : { actualVersion: result.actualVersion }),
    } satisfies OperationalResponseEnvelope, { status: 409, headers: RESPONSE_HEADERS });
  }
  if (result.status === "denied") {
    return Response.json(
      { result: "denied", code: "OPERATION_DENIED" } satisfies OperationalResponseEnvelope,
      { status: 403, headers: RESPONSE_HEADERS },
    );
  }
  return Response.json({
    result: "applied",
    resource: { type: result.resourceType, id: result.resourceId },
    ...(result.version === undefined ? {} : { version: result.version }),
    replayed: result.replayed,
  } satisfies OperationalResponseEnvelope, { status: 200, headers: RESPONSE_HEADERS });
}

async function execute(operation: () => Promise<OperationalMutationResult>): Promise<Response> {
  try {
    return resultResponse(await operation());
  } catch (error) {
    if (error instanceof OperationalRequestError || error instanceof OperationalAuthorizationError) {
      return errorResponse(error.status, error.code, error.message);
    }
    return errorResponse(503, "OPERATION_UNAVAILABLE", "The operation is temporarily unavailable. Try again.");
  }
}

async function executeInvitationCreate(
  operation: () => Promise<{ readonly result: OperationalMutationResult; readonly token: string }>,
): Promise<Response> {
  try {
    const { result, token } = await operation();
    return invitationCreateResponse(result, token);
  } catch (error) {
    if (error instanceof OperationalRequestError || error instanceof OperationalAuthorizationError) {
      return errorResponse(error.status, error.code, error.message);
    }
    return errorResponse(503, "OPERATION_UNAVAILABLE", "The operation is temporarily unavailable. Try again.");
  }
}

function leadRequirement(
  dependencies: OperationalRouteDependencies,
  leadId: string,
  capability: GrowthCapability,
  allowedScopes: readonly BuilderCapabilityScope[],
): OperationalAuthorizationRequirement {
  return {
    siteId: dependencies.siteId,
    capability,
    allowedScopes,
    entitlementMode: "operational_write",
    resource: { type: "lead", id: leadId },
  };
}

export function createManualLeadRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request): Promise<Response> {
      return execute(async () => {
        const body = await readJson(request);
        requireExactKeys(body, [
          "idempotencyKey", "source", "firstName", "lastName", "email", "phone", "zipCode",
          "service", "urgency", "notes", "assigneeId",
        ]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const source = requiredText(body.source, 32);
        const firstName = requiredText(body.firstName, 100);
        const lastName = requiredText(body.lastName, 100);
        const email = optionalText(body.email, 254)?.toLowerCase();
        const phoneInput = optionalText(body.phone, 32);
        const phone = phoneInput === undefined ? undefined : normalizeNorthAmericanPhone(phoneInput);
        const zipCode = requiredText(body.zipCode, 10);
        const service = requiredText(body.service, 100);
        const urgency = requiredText(body.urgency, 16);
        const notes = optionalText(body.notes, 2_000);
        const assigneeId = body.assigneeId === undefined ? undefined : uuid(body.assigneeId);
        if (
          !MANUAL_LEAD_SOURCES.includes(source as never) ||
          (!email && !phone) ||
          (email !== undefined && !EMAIL_PATTERN.test(email)) ||
          (phoneInput !== undefined && phone === undefined) ||
          !ZIP_PATTERN.test(zipCode) ||
          !dependencies.allowedServices.includes(service) ||
          !["standard", "urgent", "emergency"].includes(urgency)
        ) invalidRequest();

        const context = await authorize(dependencies, request, {
          siteId: dependencies.siteId,
          capability: "leads.create",
          allowedScopes: ["site"],
          entitlementMode: "operational_write",
        });
        const command: CreateManualLeadCommand = {
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey,
          source: source as CreateManualLeadCommand["source"],
          firstName,
          lastName,
          ...(email ? { email } : {}),
          ...(phone ? { phone } : {}),
          zipCode,
          service,
          urgency: urgency as CreateManualLeadCommand["urgency"],
          ...(notes ? { notes } : {}),
          ...(assigneeId ? { assigneeId } : {}),
        };
        return dependencies.persistence.createManualLead(command);
      });
    },
  };
}

type LeadRouteContext = { readonly leadId: string };

function createLeadApplyRoute(
  dependencies: OperationalRouteDependencies,
  operation: "status" | "priority" | "note" | "assignment",
) {
  return {
    handle(request: Request, routeContext: LeadRouteContext): Promise<Response> {
      return execute(async () => {
        const leadId = uuid(routeContext.leadId);
        const body = await readJson(request);
        const keys = operation === "status"
          ? ["idempotencyKey", "expectedVersion", "to", "correction", "restore"]
          : operation === "priority"
            ? ["idempotencyKey", "expectedVersion", "priority"]
            : operation === "note"
              ? ["idempotencyKey", "expectedVersion", "body"]
              : ["idempotencyKey", "expectedVersion", "assigneeId"];
        requireExactKeys(body, keys);
        const common = commonCommand(body);
        verifyIdempotency(request, common.idempotencyKey);
        const requirement = leadRequirement(
          dependencies,
          leadId,
          operation === "assignment" ? "leads.assign" : "leads.update",
          operation === "assignment" ? ["site"] : ["site", "assigned"],
        );

        let fields: Record<string, unknown>;
        if (operation === "status") {
          const to = requiredText(body.to, 32);
          if (!LEAD_STATUSES.includes(to as never)) invalidRequest();
          const correction = optionalBoolean(body.correction);
          const restore = optionalBoolean(body.restore);
          fields = { to, ...(correction === undefined ? {} : { correction }), ...(restore === undefined ? {} : { restore }) };
        } else if (operation === "priority") {
          const priority = requiredText(body.priority, 16);
          if (!["low", "normal", "high", "urgent"].includes(priority)) invalidRequest();
          fields = { priority };
        } else if (operation === "note") {
          fields = { body: requiredText(body.body, 2_000) };
        } else {
          fields = { assigneeId: uuid(body.assigneeId) };
        }

        const context = await authorize(dependencies, request, requirement);
        const command = {
          siteId: dependencies.siteId,
          actor: actor(context),
          ...common,
          leadId,
          ...fields,
        } as ChangeLeadStatusCommand | SetLeadPriorityCommand | AddLeadNoteCommand | AssignLeadCommand;
        return dependencies.persistence.applyLeadCommand({ operation, command });
      });
    },
  };
}

export const createLeadStatusRouteHandler = (dependencies: OperationalRouteDependencies) =>
  createLeadApplyRoute(dependencies, "status");
export const createLeadPriorityRouteHandler = (dependencies: OperationalRouteDependencies) =>
  createLeadApplyRoute(dependencies, "priority");
export const createLeadNoteRouteHandler = (dependencies: OperationalRouteDependencies) =>
  createLeadApplyRoute(dependencies, "note");
export const createLeadAssignmentRouteHandler = (dependencies: OperationalRouteDependencies) =>
  createLeadApplyRoute(dependencies, "assignment");

export function createLeadTaskRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: LeadRouteContext): Promise<Response> {
      return execute(async () => {
        const leadId = uuid(routeContext.leadId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "expectedVersion", "title", "assigneeId", "priority", "dueAt"]);
        const common = commonCommand(body);
        verifyIdempotency(request, common.idempotencyKey);
        const title = requiredText(body.title, 200);
        const requestedAssigneeId = body.assigneeId === undefined ? undefined : uuid(body.assigneeId);
        const priority = optionalText(body.priority, 16);
        if (priority !== undefined && !["low", "normal", "high", "urgent"].includes(priority)) invalidRequest();
        const dueAt = body.dueAt === undefined ? undefined : timestamp(body.dueAt);
        const context = await authorize(
          dependencies,
          request,
          leadRequirement(dependencies, leadId, "tasks.manage", ["site", "assigned"]),
        );
        if (context.scope === "assigned" && requestedAssigneeId && requestedAssigneeId !== context.memberId) {
          throw new OperationalAuthorizationError("OPERATION_DENIED");
        }
        const assigneeId = context.scope === "assigned" ? context.memberId : requestedAssigneeId;
        const command: CreateLeadTaskCommand = {
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey: common.idempotencyKey,
          relatedType: "lead",
          relatedId: leadId,
          leadId,
          title,
          ...(assigneeId ? { assigneeId } : {}),
          ...(priority ? { priority: priority as CreateLeadTaskCommand["priority"] } : {}),
          ...(dueAt ? { dueAt } : {}),
          authorizationParents: [{ type: "lead", id: leadId }],
          selfAssignmentIntent: assigneeId === context.memberId,
        };
        return dependencies.persistence.createLeadTask({ expectedLeadVersion: common.expectedVersion, command });
      });
    },
  };
}

export function createLeadServiceEventRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: LeadRouteContext): Promise<Response> {
      return execute(async () => {
        const leadId = uuid(routeContext.leadId);
        const body = await readJson(request);
        requireExactKeys(body, [
          "idempotencyKey", "expectedVersion", "contactId", "kind", "purpose", "scheduledAt",
          "occurredAt", "correlationId", "replacesEventId",
        ]);
        const common = commonCommand(body);
        verifyIdempotency(request, common.idempotencyKey);
        const contactId = uuid(body.contactId);
        const kind = requiredText(body.kind, 64);
        if (!SERVICE_EVENT_KINDS.includes(kind as never)) invalidRequest();
        const purpose = optionalText(body.purpose, 16);
        if (purpose !== undefined && purpose !== "estimate" && purpose !== "service") invalidRequest();
        const scheduledAt = body.scheduledAt === undefined ? undefined : timestamp(body.scheduledAt);
        const occurredAt = timestamp(body.occurredAt);
        const correlationId = uuid(body.correlationId);
        const replacesEventId = body.replacesEventId === undefined ? undefined : uuid(body.replacesEventId);
        const context = await authorize(
          dependencies,
          request,
          leadRequirement(dependencies, leadId, "leads.update", ["site", "assigned"]),
        );
        const command: RecordLeadServiceEventCommand = {
          siteId: dependencies.siteId,
          contactId,
          leadId,
          kind: kind as RecordLeadServiceEventCommand["kind"],
          ...(purpose ? { purpose: purpose as "estimate" | "service" } : {}),
          ...(scheduledAt ? { scheduledAt } : {}),
          origin: { type: "manual", actor: actor(context) },
          occurredAt,
          correlationId,
          ...(replacesEventId ? { replacesEventId } : {}),
          idempotencyKey: common.idempotencyKey,
        };
        return dependencies.persistence.recordLeadServiceEvent({
          expectedLeadVersion: common.expectedVersion,
          command,
        });
      });
    },
  };
}

type SubmissionRouteContext = { readonly submissionId: string };

function submissionRequirement(
  dependencies: OperationalRouteDependencies,
  submissionId: string,
  mode: OperationalEntitlementMode,
): OperationalAuthorizationRequirement {
  return {
    siteId: dependencies.siteId,
    ...(mode === "operational_write" ? { capability: "leads.create" as const, allowedRoles: ["owner"] as const } : {
      allowedRoles: ["owner", "editor"] as const,
    }),
    allowedScopes: ["site"],
    entitlementMode: mode,
    resource: { type: "form_submission", id: submissionId },
  };
}

function createSubmissionReviewRoute(
  dependencies: OperationalRouteDependencies,
  operation: "spam" | "restore",
) {
  return {
    handle(request: Request, routeContext: SubmissionRouteContext): Promise<Response> {
      return execute(async () => {
        const submissionId = uuid(routeContext.submissionId);
        const body = await readJson(request);
        requireExactKeys(body, operation === "spam"
          ? ["idempotencyKey", "expectedVersion", "reasonCode"]
          : ["idempotencyKey", "expectedVersion"]);
        const common = commonCommand(body, 0);
        verifyIdempotency(request, common.idempotencyKey);
        const reasonCode = operation === "spam" ? requiredText(body.reasonCode, 64) : undefined;
        if (reasonCode !== undefined && !REASON_PATTERN.test(reasonCode)) invalidRequest();
        const context = await authorize(
          dependencies,
          request,
          submissionRequirement(dependencies, submissionId, "base_submission_review"),
        );
        const command: BaseSubmissionReviewCommand = {
          siteId: dependencies.siteId,
          actor: actor(context),
          submissionId,
          expectedVersion: common.expectedVersion,
          idempotencyKey: common.idempotencyKey,
          ...(reasonCode ? { reasonCode } : {}),
        };
        return dependencies.persistence.reviewFormSubmission({ operation, command });
      });
    },
  };
}

export const createSubmissionSpamRouteHandler = (dependencies: OperationalRouteDependencies) =>
  createSubmissionReviewRoute(dependencies, "spam");
export const createSubmissionRestoreRouteHandler = (dependencies: OperationalRouteDependencies) =>
  createSubmissionReviewRoute(dependencies, "restore");

export function createReviewedSubmissionImportRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: SubmissionRouteContext): Promise<Response> {
      return execute(async () => {
        const submissionId = uuid(routeContext.submissionId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "expectedLatestResultVersion"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        const expectedLatestResultVersion = version(body.expectedLatestResultVersion);
        verifyIdempotency(request, idempotencyKey);
        const context = await authorize(
          dependencies,
          request,
          submissionRequirement(dependencies, submissionId, "operational_write"),
        );
        const aal2 = await dependencies.authorizer.requireRecentAal2(request, context);
        const aal2VerifiedAt = timestamp(aal2.verifiedAt);
        const command: ImportBaseSubmissionCommand = {
          siteId: dependencies.siteId,
          actor: actor(context),
          submissionId,
          expectedLatestResultVersion,
          aal2VerifiedAt,
          idempotencyKey,
        };
        return dependencies.persistence.importFormSubmission(command);
      });
    },
  };
}

type CustomerRouteContext = { readonly customerId: string };
type MergeSuggestionRouteContext = { readonly suggestionId: string };
type NotificationRouteContext = { readonly notificationId: string };
type InvitationRouteContext = { readonly invitationId: string };

export function createCustomerProfileUpdateRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: CustomerRouteContext): Promise<Response> {
      return execute(async () => {
        const customerId = uuid(routeContext.customerId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "expectedVersion", "patch"]);
        const common = commonCommand(body);
        verifyIdempotency(request, common.idempotencyKey);
        if (!isRecord(body.patch)) invalidRequest();
        requireExactKeys(body.patch, ["displayName", "preferredContactMethod", "serviceAreaZip"]);
        if (Object.keys(body.patch).length === 0) invalidRequest();
        const displayName = optionalText(body.patch.displayName, 200);
        const preferredContactMethod = optionalText(body.patch.preferredContactMethod, 16);
        if (preferredContactMethod !== undefined && !["email", "phone", "none"].includes(preferredContactMethod)) {
          invalidRequest();
        }
        let serviceAreaZip: string | null | undefined;
        if (body.patch.serviceAreaZip === null) serviceAreaZip = null;
        else if (body.patch.serviceAreaZip !== undefined) {
          serviceAreaZip = requiredText(body.patch.serviceAreaZip, 10);
          if (!ZIP_PATTERN.test(serviceAreaZip)) invalidRequest();
        }
        const context = await authorize(dependencies, request, {
          siteId: dependencies.siteId,
          capability: "customers.update",
          allowedScopes: ["site", "assigned"],
          entitlementMode: "operational_write",
          resource: { type: "customer", id: customerId },
        });
        const command: UpdateCustomerProfileCommand = {
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey: common.idempotencyKey,
          expectedVersion: common.expectedVersion,
          customerId,
          patch: {
            ...(displayName === undefined ? {} : { displayName }),
            ...(preferredContactMethod === undefined ? {} : {
              preferredContactMethod: preferredContactMethod as "email" | "phone" | "none",
            }),
            ...(serviceAreaZip === undefined ? {} : { serviceAreaZip }),
          },
        };
        return dependencies.persistence.updateCustomerProfile(command);
      });
    },
  };
}

export function createCustomerMergeReviewRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: MergeSuggestionRouteContext): Promise<Response> {
      return execute(async () => {
        const suggestionId = uuid(routeContext.suggestionId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "expectedVersion", "decision"]);
        const common = commonCommand(body);
        verifyIdempotency(request, common.idempotencyKey);
        const decision = requiredText(body.decision, 16);
        if (decision !== "accept" && decision !== "reject") invalidRequest();
        const context = await authorize(dependencies, request, {
          siteId: dependencies.siteId,
          capability: "customers.update",
          allowedScopes: ["site"],
          entitlementMode: "operational_write",
          resource: { type: "merge_suggestion", id: suggestionId },
        });
        const command: ReviewCustomerMergeCommand = {
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey: common.idempotencyKey,
          expectedVersion: common.expectedVersion,
          suggestionId,
          decision,
        };
        return dependencies.persistence.reviewCustomerMerge(command);
      });
    },
  };
}

export function createCustomerMergeExecuteRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: MergeSuggestionRouteContext): Promise<Response> {
      return execute(async () => {
        const suggestionId = uuid(routeContext.suggestionId);
        const body = await readJson(request);
        requireExactKeys(body, [
          "idempotencyKey",
          "expectedSuggestionVersion",
          "sourceId",
          "targetId",
          "expectedSourceVersion",
          "expectedTargetVersion",
        ]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const expectedSuggestionVersion = version(body.expectedSuggestionVersion);
        const sourceId = uuid(body.sourceId);
        const targetId = uuid(body.targetId);
        if (sourceId === targetId) invalidRequest();
        const expectedSourceVersion = version(body.expectedSourceVersion);
        const expectedTargetVersion = version(body.expectedTargetVersion);
        const context = await authorize(dependencies, request, {
          siteId: dependencies.siteId,
          capability: "customers.update",
          allowedScopes: ["site"],
          entitlementMode: "operational_write",
          resource: { type: "merge_suggestion", id: suggestionId },
        });
        const command: ExecuteCustomerMergePersistenceCommand = {
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey,
          suggestionId,
          expectedSuggestionVersion,
          sourceId,
          targetId,
          expectedSourceVersion,
          expectedTargetVersion,
        };
        return dependencies.persistence.executeCustomerMerge(command);
      });
    },
  };
}

export function createCustomerExportRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request): Promise<Response> {
      return execute(async () => {
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "customerIds", "filter"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const customerIds = boundedCustomerIds(body.customerIds);
        const filter = boundedExportFilter(body.filter);
        const context = await authorize(dependencies, request, {
          siteId: dependencies.siteId,
          capability: "customers.export",
          allowedScopes: ["site"],
          entitlementMode: "operational_write",
        });
        const aal2VerifiedAt = timestamp((await dependencies.authorizer.requireRecentAal2(request, context)).verifiedAt);
        const command: RequestCustomerExportCommand & { readonly aal2VerifiedAt: string } = {
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey,
          ...(customerIds ? { customerIds } : {}),
          ...(filter ? { filter } : {}),
          aal2VerifiedAt,
        };
        return dependencies.persistence.requestCustomerExport(command);
      });
    },
  };
}

export function createCustomerDeletionRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: CustomerRouteContext): Promise<Response> {
      return execute(async () => {
        const customerId = uuid(routeContext.customerId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "reason"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const reason = requiredText(body.reason, 500);
        const context = await authorize(dependencies, request, {
          siteId: dependencies.siteId,
          capability: "customers.deleteRequest",
          allowedRoles: ["owner"],
          allowedScopes: ["site"],
          entitlementMode: "operational_write",
          resource: { type: "customer", id: customerId },
        });
        const aal2VerifiedAt = timestamp((await dependencies.authorizer.requireRecentAal2(request, context)).verifiedAt);
        const command: RequestCustomerDeletionCommand & { readonly aal2VerifiedAt: string } = {
          siteId: dependencies.siteId,
          actor: actor(context),
          idempotencyKey,
          customerId,
          reason,
          aal2VerifiedAt,
        };
        return dependencies.persistence.requestCustomerDeletion(command);
      });
    },
  };
}

export function createNotificationReadRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: NotificationRouteContext): Promise<Response> {
      return execute(async () => {
        const notificationId = uuid(routeContext.notificationId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const context = await authorize(dependencies, request, {
          siteId: dependencies.siteId,
          capability: "dashboard.read",
          allowedScopes: ["site"],
          entitlementMode: "operational_write",
          resource: { type: "notification", id: notificationId },
        });
        const command: MarkInAppNotificationReadCommand = {
          siteId: dependencies.siteId,
          notificationId,
          recipientMemberId: context.memberId,
          readAt: trustedNow(dependencies),
          idempotencyKey,
        };
        return dependencies.persistence.markNotificationRead(command);
      });
    },
  };
}

const INVITATION_TEMPLATES = Object.freeze({
  manager: "growth_manager_v1",
  staff: "growth_staff_v1",
  "read-only": "growth_read_only_v1",
} as const);

function invitationRequirement(dependencies: OperationalRouteDependencies, invitationId?: string): OperationalAuthorizationRequirement {
  return {
    siteId: dependencies.siteId,
    capability: "members.manage",
    allowedRoles: ["owner"],
    allowedScopes: ["site"],
    entitlementMode: "operational_write",
    ...(invitationId ? { resource: { type: "member_invitation" as const, id: invitationId } } : {}),
  };
}

function invitationCreateResponse(result: OperationalMutationResult, token: string): Response {
  if (result.status !== "applied") return resultResponse(result);
  return Response.json({
    result: "applied",
    invitation: { id: result.resourceId, token },
    ...(result.version === undefined ? {} : { version: result.version }),
    replayed: result.replayed,
  } satisfies MemberInvitationCreateResponseEnvelope, { status: 200, headers: RESPONSE_HEADERS });
}

export function createMemberInvitationRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request): Promise<Response> {
      return executeInvitationCreate(async () => {
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "email", "template"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const email = canonicalEmail(body.email);
        const template = requiredText(body.template, 16);
        if (!Object.hasOwn(INVITATION_TEMPLATES, template)) invalidRequest();
        const context = await authorize(dependencies, request, invitationRequirement(dependencies));
        const aal2VerifiedAt = timestamp((await dependencies.authorizer.requireRecentAal2(request, context)).verifiedAt);
        const token = await dependencies.invitationSecrets.generateToken(idempotencyKey);
        if (typeof token !== "string" || token.length < 16 || token.length > 512) throw new Error("Invalid generated token.");
        const [canonicalEmailDigest, tokenHash] = await Promise.all([
          dependencies.invitationSecrets.digestCanonicalEmail(email),
          dependencies.invitationSecrets.hashToken(token),
        ]);
        const expiresAt = new Date(Date.parse(trustedNow(dependencies)) + 7 * 24 * 60 * 60 * 1000).toISOString();
        const result = await dependencies.persistence.createMemberInvitation({
          siteId: dependencies.siteId,
          actorId: context.memberId,
          idempotencyKey,
          canonicalEmailDigest,
          tokenHash,
          templateId: INVITATION_TEMPLATES[template as keyof typeof INVITATION_TEMPLATES],
          templateVersion: 1,
          expiresAt,
          aal2VerifiedAt,
        });
        return { result, token };
      });
    },
  };
}

export function createMemberInvitationRevokeRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request, routeContext: InvitationRouteContext): Promise<Response> {
      return execute(async () => {
        const invitationId = uuid(routeContext.invitationId);
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "expectedVersion", "reason"]);
        const common = commonCommand(body);
        verifyIdempotency(request, common.idempotencyKey);
        const reason = requiredText(body.reason, 500);
        const context = await authorize(dependencies, request, invitationRequirement(dependencies, invitationId));
        const aal2VerifiedAt = timestamp((await dependencies.authorizer.requireRecentAal2(request, context)).verifiedAt);
        return dependencies.persistence.revokeMemberInvitation({
          siteId: dependencies.siteId,
          actorId: context.memberId,
          invitationId,
          expectedVersion: common.expectedVersion,
          reason,
          idempotencyKey: common.idempotencyKey,
          aal2VerifiedAt,
        });
      });
    },
  };
}

export function createMemberInvitationAcceptRouteHandler(dependencies: OperationalRouteDependencies) {
  return {
    handle(request: Request): Promise<Response> {
      return execute(async () => {
        const body = await readJson(request);
        requireExactKeys(body, ["idempotencyKey", "token"]);
        const idempotencyKey = uuid(body.idempotencyKey);
        verifyIdempotency(request, idempotencyKey);
        const token = requiredText(body.token, 512);
        if (token.length < 16) invalidRequest();
        const trusted = await dependencies.authorizer.requireAuthenticatedUser(request, {
          siteId: dependencies.siteId,
          entitlementMode: "operational_write",
        });
        if (trusted.siteId !== dependencies.siteId) throw new OperationalAuthorizationError("SITE_ACCESS_DENIED");
        if (
          trusted.entitlementVerification !== "current" ||
          trusted.entitlementMode !== "operational_write"
        ) throw new OperationalAuthorizationError("ENTITLEMENT_RESTRICTED");
        if (!UUID_PATTERN.test(trusted.userId) || typeof trusted.email !== "string") {
          throw new OperationalAuthorizationError("AUTH_REQUIRED");
        }
        const email = trusted.email.trim().toLowerCase();
        if (!EMAIL_PATTERN.test(email)) throw new OperationalAuthorizationError("AUTH_REQUIRED");
        const [canonicalEmailDigest, tokenHash] = await Promise.all([
          dependencies.invitationSecrets.digestCanonicalEmail(email),
          dependencies.invitationSecrets.hashToken(token),
        ]);
        return dependencies.persistence.acceptMemberInvitation({
          siteId: dependencies.siteId,
          authenticatedUserId: trusted.userId,
          canonicalEmailDigest,
          tokenHash,
          idempotencyKey,
        });
      });
    },
  };
}
