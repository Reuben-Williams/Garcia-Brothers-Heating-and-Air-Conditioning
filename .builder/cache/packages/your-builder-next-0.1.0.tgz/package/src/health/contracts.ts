export const GROWTH_HEALTH_CONTRACT_VERSION = 1 as const;

export type GrowthHealthCheckKind =
  | "authenticated_shell"
  | "public_form_base"
  | "entitlement_snapshot"
  | "growth_queue"
  | "backup";

export type GrowthHealthStatus = "healthy" | "degraded" | "unhealthy" | "unknown";

export interface SanitizedGrowthHealthProjection {
  readonly version: typeof GROWTH_HEALTH_CONTRACT_VERSION;
  readonly siteId: string;
  readonly kind: GrowthHealthCheckKind;
  readonly status: GrowthHealthStatus;
  readonly checkedAt: string;
  readonly observedVersion: string | null;
  readonly queueAgeSeconds: number | null;
  readonly snapshotAgeSeconds: number | null;
  readonly safeErrorCode: string | null;
}

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const SAFE_CODE_PATTERN = /^[a-z][a-z0-9_]{0,63}$/;
const VERSION_PATTERN = /^[A-Za-z0-9][A-Za-z0-9.+_-]{0,63}$/;
const KINDS = new Set<GrowthHealthCheckKind>([
  "authenticated_shell",
  "public_form_base",
  "entitlement_snapshot",
  "growth_queue",
  "backup",
]);
const STATUSES = new Set<GrowthHealthStatus>(["healthy", "degraded", "unhealthy", "unknown"]);
const KEYS = Object.freeze([
  "version",
  "siteId",
  "kind",
  "status",
  "checkedAt",
  "observedVersion",
  "queueAgeSeconds",
  "snapshotAgeSeconds",
  "safeErrorCode",
].sort());

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function hasExactKeys(value: Record<string, unknown>): boolean {
  const keys = Object.keys(value).sort();
  return keys.length === KEYS.length && keys.every((key, index) => key === KEYS[index]);
}

function isCanonicalTimestamp(value: unknown): value is string {
  if (typeof value !== "string") return false;
  const milliseconds = Date.parse(value);
  return Number.isFinite(milliseconds) && new Date(milliseconds).toISOString() === value;
}

function isNullableAge(value: unknown): value is number | null {
  return value === null || (Number.isSafeInteger(value) && Number(value) >= 0);
}

export function isSanitizedGrowthHealthProjection(
  value: unknown,
): value is SanitizedGrowthHealthProjection {
  return isRecord(value) &&
    hasExactKeys(value) &&
    value.version === GROWTH_HEALTH_CONTRACT_VERSION &&
    typeof value.siteId === "string" && UUID_PATTERN.test(value.siteId) &&
    typeof value.kind === "string" && KINDS.has(value.kind as GrowthHealthCheckKind) &&
    typeof value.status === "string" && STATUSES.has(value.status as GrowthHealthStatus) &&
    isCanonicalTimestamp(value.checkedAt) &&
    (value.observedVersion === null ||
      (typeof value.observedVersion === "string" && VERSION_PATTERN.test(value.observedVersion))) &&
    isNullableAge(value.queueAgeSeconds) &&
    isNullableAge(value.snapshotAgeSeconds) &&
    (value.safeErrorCode === null ||
      (typeof value.safeErrorCode === "string" && SAFE_CODE_PATTERN.test(value.safeErrorCode)));
}
