import type { BuilderRole } from "@your-builder/core";

export interface BuilderMembership {
  siteId: string;
  siteKey: string;
  userId: string;
  email: string | null;
  role: BuilderRole;
  previewGeneration: number;
}

export type BuilderMembershipLookup = (
  siteKey: string,
  userId: string,
) => Promise<BuilderMembership | null>;

export interface ClaimsClient {
  auth: {
    getClaims(): Promise<{
      data: { claims?: { sub?: unknown } } | null;
      error: unknown;
    }>;
  };
}

export class BuilderAuthError extends Error {
  constructor(
    public readonly code: "AUTH_REQUIRED" | "SITE_ACCESS_DENIED" | "ROLE_DENIED",
    public readonly status: 401 | 403,
    message: string,
  ) {
    super(message);
    this.name = "BuilderAuthError";
  }
}

export async function requireBuilderMember(input: {
  client: ClaimsClient;
  siteKey: string;
  lookup: BuilderMembershipLookup;
  allowedRoles?: readonly BuilderRole[];
}): Promise<BuilderMembership> {
  const { data, error } = await input.client.auth.getClaims();
  const subject = data?.claims?.sub;

  if (error || typeof subject !== "string" || !subject) {
    throw new BuilderAuthError("AUTH_REQUIRED", 401, "A verified editor session is required.");
  }

  const membership = await input.lookup(input.siteKey, subject);
  if (!membership || membership.siteKey !== input.siteKey || membership.userId !== subject) {
    throw new BuilderAuthError("SITE_ACCESS_DENIED", 403, "This account cannot access the requested site.");
  }

  if (input.allowedRoles && !input.allowedRoles.includes(membership.role)) {
    throw new BuilderAuthError("ROLE_DENIED", 403, "This account does not have permission for that action.");
  }

  return membership;
}
