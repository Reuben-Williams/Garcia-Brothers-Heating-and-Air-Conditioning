import { createBrowserClient } from "@supabase/ssr";

export function createBuilderBrowserClient(input: { url: string; publishableKey: string }) {
  return createBrowserClient(input.url, input.publishableKey);
}
