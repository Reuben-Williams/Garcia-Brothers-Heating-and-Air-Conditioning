import { isBuilderPreviewMessage, type BuilderPreviewMessage } from "@your-builder/core";

const PREVIEW_TOKEN_VERSION = 1;

interface PreviewSessionPayload {
  version: typeof PREVIEW_TOKEN_VERSION;
  siteKey: string;
  userId: string;
  generation: number;
  allowedOrigins: string[];
  csrfToken: string;
  issuedAt: number;
  expiresAt: number;
  nonce: string;
}

export class PreviewSessionError extends Error {
  constructor(
    public readonly code:
      | "INVALID_TOKEN"
      | "EXPIRED_TOKEN"
      | "SESSION_MISMATCH"
      | "CSRF_MISMATCH"
      | "INVALID_MESSAGE",
    message: string,
  ) {
    super(message);
    this.name = "PreviewSessionError";
  }
}

function encodeBase64Url(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function decodeBase64Url(value: string): Uint8Array<ArrayBuffer> {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
  const binary = atob(padded);
  const bytes = new Uint8Array(new ArrayBuffer(binary.length));
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

async function importHmacKey(secret: string) {
  return crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
}

async function signPayload(encodedPayload: string, secret: string): Promise<string> {
  const signature = await crypto.subtle.sign(
    "HMAC",
    await importHmacKey(secret),
    new TextEncoder().encode(encodedPayload),
  );
  return encodeBase64Url(new Uint8Array(signature));
}

export async function issuePreviewSession(input: {
  siteKey: string;
  userId: string;
  generation: number;
  allowedOrigins: readonly string[];
  csrfToken: string;
  secret: string;
  now?: number;
  ttlSeconds?: number;
}): Promise<string> {
  const issuedAt = input.now ?? Math.floor(Date.now() / 1000);
  const nonceBytes = crypto.getRandomValues(new Uint8Array(16));
  const payload: PreviewSessionPayload = {
    version: PREVIEW_TOKEN_VERSION,
    siteKey: input.siteKey,
    userId: input.userId,
    generation: input.generation,
    allowedOrigins: [...new Set(input.allowedOrigins)],
    csrfToken: input.csrfToken,
    issuedAt,
    expiresAt: issuedAt + (input.ttlSeconds ?? 300),
    nonce: encodeBase64Url(nonceBytes),
  };
  const encodedPayload = encodeBase64Url(new TextEncoder().encode(JSON.stringify(payload)));
  return `${encodedPayload}.${await signPayload(encodedPayload, input.secret)}`;
}

export async function verifyPreviewSession(
  token: string,
  expected: {
    secret: string;
    siteKey: string;
    userId: string;
    generation: number;
    origin: string;
    now?: number;
  },
): Promise<PreviewSessionPayload> {
  const [encodedPayload, encodedSignature, extra] = token.split(".");
  if (!encodedPayload || !encodedSignature || extra) {
    throw new PreviewSessionError("INVALID_TOKEN", "The preview session is malformed.");
  }

  const validSignature = await crypto.subtle.verify(
    "HMAC",
    await importHmacKey(expected.secret),
    decodeBase64Url(encodedSignature),
    new TextEncoder().encode(encodedPayload),
  );
  if (!validSignature) {
    throw new PreviewSessionError("INVALID_TOKEN", "The preview session signature is invalid.");
  }

  let payload: PreviewSessionPayload;
  try {
    payload = JSON.parse(new TextDecoder().decode(decodeBase64Url(encodedPayload))) as PreviewSessionPayload;
  } catch {
    throw new PreviewSessionError("INVALID_TOKEN", "The preview session payload is invalid.");
  }

  const now = expected.now ?? Math.floor(Date.now() / 1000);
  if (payload.version !== PREVIEW_TOKEN_VERSION || payload.expiresAt < now) {
    throw new PreviewSessionError("EXPIRED_TOKEN", "The preview session has expired.");
  }
  if (
    payload.siteKey !== expected.siteKey ||
    payload.userId !== expected.userId ||
    payload.generation !== expected.generation ||
    !payload.allowedOrigins.includes(expected.origin)
  ) {
    throw new PreviewSessionError("SESSION_MISMATCH", "The preview session does not match this request.");
  }

  return payload;
}

export function verifyPreviewCsrf(expectedToken: string, suppliedToken: string | null): void {
  if (!suppliedToken || suppliedToken.length !== expectedToken.length) {
    throw new PreviewSessionError("CSRF_MISMATCH", "The preview request could not be verified.");
  }

  let difference = 0;
  for (let index = 0; index < expectedToken.length; index += 1) {
    difference |= expectedToken.charCodeAt(index) ^ suppliedToken.charCodeAt(index);
  }
  if (difference !== 0) {
    throw new PreviewSessionError("CSRF_MISMATCH", "The preview request could not be verified.");
  }
}

export function validatePreviewMessageEvent(
  event: { origin: string; source: MessageEventSource | null; data: unknown },
  expected: {
    expectedOrigin: string;
    expectedSource: MessageEventSource;
    siteKey: string;
    pagePath?: string;
  },
): BuilderPreviewMessage {
  if (
    event.origin !== expected.expectedOrigin ||
    event.source !== expected.expectedSource ||
    !isBuilderPreviewMessage(event.data, expected.siteKey) ||
    (expected.pagePath !== undefined && event.data.pagePath !== expected.pagePath)
  ) {
    throw new PreviewSessionError("INVALID_MESSAGE", "The preview message failed validation.");
  }
  return event.data;
}
