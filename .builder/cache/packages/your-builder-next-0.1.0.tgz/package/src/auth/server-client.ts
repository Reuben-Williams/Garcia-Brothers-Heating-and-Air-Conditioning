import { createServerClient } from "@supabase/ssr";

export interface BuilderCookieAdapter {
  getAll(): Array<{ name: string; value: string }>;
  setAll(cookies: Array<{ name: string; value: string; options?: Record<string, unknown> }>): void;
}

export function createBuilderServerClient(input: {
  url: string;
  publishableKey: string;
  cookies: BuilderCookieAdapter;
}) {
  return createServerClient(input.url, input.publishableKey, {
    cookies: {
      getAll: () => input.cookies.getAll(),
      setAll: (cookies) => input.cookies.setAll(cookies),
    },
  });
}
