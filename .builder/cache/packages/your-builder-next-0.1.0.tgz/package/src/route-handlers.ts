import type {
  BuilderContentAdapter,
  BuilderSiteConfig,
  MediaAsset,
  PageContent,
  PublishInput,
  RollbackInput,
  SaveDraftInput,
  UndoRollbackInput,
} from "@your-builder/core";

export const BUILDER_GLOBAL_CONTENT_PATH = "/__builder/global";

function globalRegionIds(site: BuilderSiteConfig) {
  return new Set((site.globalRegions ?? []).map((region) => typeof region === "string" ? region : region.id));
}

async function mergedContent(
  adapter: BuilderContentAdapter,
  siteId: string,
  pagePath: string,
  mode: "draft" | "published",
): Promise<PageContent> {
  const read = mode === "draft" ? adapter.getDraftContent.bind(adapter) : adapter.getPublishedContent.bind(adapter);
  const [globalContent, pageContent] = await Promise.all([
    read(siteId, BUILDER_GLOBAL_CONTENT_PATH),
    read(siteId, pagePath),
  ]);
  return {
    ...pageContent,
    path: pagePath,
    regions: { ...globalContent.regions, ...pageContent.regions },
  };
}

export interface BuilderRouteHandlerOptions {
  readonly site: BuilderSiteConfig;
  readonly adapter: BuilderContentAdapter;
  readonly getUserId?: (request: Request) => string | Promise<string>;
}

export interface LoadBuilderPageContentInput {
  readonly adapter: BuilderContentAdapter;
  readonly siteId: string;
  readonly pagePath: string;
  readonly mode?: "draft" | "published";
  readonly fallback?: PageContent;
}

export async function loadBuilderPageContent({
  adapter,
  siteId,
  pagePath,
  mode = "published",
  fallback,
}: LoadBuilderPageContentInput): Promise<PageContent> {
  try {
    return mode === "draft"
      ? await adapter.getDraftContent(siteId, pagePath)
      : await adapter.getPublishedContent(siteId, pagePath);
  } catch {
    return fallback ?? { path: pagePath, regions: {} };
  }
}

async function readJson<T>(request: Request): Promise<T> {
  return (await request.json()) as T;
}

export function createBuilderRouteHandlers({
  site,
  adapter,
  getUserId,
}: BuilderRouteHandlerOptions) {
  async function userId(request: Request) {
    return (await getUserId?.(request)) ?? "system";
  }

  return {
    async GET(request: Request) {
      const url = new URL(request.url);
      const resource = url.searchParams.get("resource") ?? "content";
      const path = url.searchParams.get("path") ?? "/";
      const mode = url.searchParams.get("mode") ?? "published";
      if (resource === "audit") {
        const [globalAudit, pageAudit] = await Promise.all([
          adapter.listAuditLog(site.siteId, BUILDER_GLOBAL_CONTENT_PATH),
          adapter.listAuditLog(site.siteId, path),
        ]);
        return Response.json([...globalAudit, ...pageAudit].sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
      }
      if (resource === "media") return Response.json(await adapter.listMediaAssets(site.siteId));
      const content = await mergedContent(adapter, site.siteId, path, mode === "draft" ? "draft" : "published");
      return Response.json(content);
    },

    async POST(request: Request) {
      const resource = new URL(request.url).searchParams.get("resource") ?? "draft";
      if (resource === "media") {
        const input = await readJson<
          Omit<Parameters<BuilderContentAdapter["createMediaAsset"]>[0], "siteId" | "userId">
        >(request);
        const asset: MediaAsset = await adapter.createMediaAsset({
          ...input,
          siteId: site.siteId,
          userId: await userId(request),
        });
        return Response.json(asset);
      }
      const input = await readJson<Omit<SaveDraftInput, "siteId" | "userId">>(request);
      const pagePath = globalRegionIds(site).has(input.regionId) ? BUILDER_GLOBAL_CONTENT_PATH : input.pagePath;
      return Response.json(await adapter.saveDraft({
        ...input,
        pagePath,
        siteId: site.siteId,
        userId: await userId(request),
      }));
    },

    async PUT(request: Request) {
      const input = await readJson<Omit<PublishInput, "siteId" | "userId">>(request);
      const actor = await userId(request);
      if ((site.globalRegions?.length ?? 0) > 0) {
        await adapter.publishVersion({ siteId: site.siteId, pagePath: BUILDER_GLOBAL_CONTENT_PATH, userId: actor });
      }
      return Response.json(await adapter.publishVersion({
        ...input,
        siteId: site.siteId,
        userId: actor,
      }));
    },

    async PATCH(request: Request) {
      const resource = new URL(request.url).searchParams.get("resource") ?? "rollback";
      const version = resource === "undo-rollback"
        ? await adapter.undoRollback({
            ...(await readJson<Omit<UndoRollbackInput, "siteId" | "userId">>(request)),
            siteId: site.siteId,
            userId: await userId(request),
          })
        : await adapter.rollbackToVersion({
            ...(await readJson<Omit<RollbackInput, "siteId" | "userId">>(request)),
            siteId: site.siteId,
            userId: await userId(request),
          });
      return Response.json(version);
    },
  };
}
