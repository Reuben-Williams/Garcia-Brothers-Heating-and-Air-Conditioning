import {
  ContentConflictError,
  ContentPermissionError,
  ContentScheduleError,
  ContentSchemaError,
  IdempotencyConflictError,
  MediaReferenceError,
  SlugConflictError,
} from "@your-builder/content";
import { BuilderAuthError } from "../auth/require-member.js";

export class BuilderHttpError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = "BuilderHttpError";
  }
}

export function toBuilderErrorResponse(error: unknown): Response {
  if (error instanceof BuilderHttpError || error instanceof BuilderAuthError) {
    return Response.json({ error: { code: error.code, message: error.message } }, { status: error.status });
  }
  if (error instanceof ContentConflictError || error instanceof IdempotencyConflictError) {
    return Response.json({ error: { code: error.code, message: error.message } }, { status: 409 });
  }
  if (error instanceof ContentPermissionError) {
    return Response.json({ error: { code: error.code, message: error.message } }, { status: 403 });
  }
  if (
    error instanceof ContentSchemaError ||
    error instanceof ContentScheduleError ||
    error instanceof MediaReferenceError ||
    error instanceof SlugConflictError
  ) {
    return Response.json({ error: { code: error.code, message: error.message } }, { status: 400 });
  }

  return Response.json(
    { error: { code: "INTERNAL_ERROR", message: "The content request could not be completed." } },
    { status: 500 },
  );
}
