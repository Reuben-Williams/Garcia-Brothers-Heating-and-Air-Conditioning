import React, { Fragment, type ReactNode } from "react";
import type { PostCollectionQuery, PublishedPost } from "@your-builder/content";
import type { ContentSourceScope } from "@your-builder/core";
import { loadPostCollection, type PublicPostReader } from "./load-posts.js";
import { withPostPreviewMetadata } from "./post-preview-metadata.js";

export interface PostCollectionProps {
  id: string;
  siteKey: string;
  scope: ContentSourceScope;
  fallbackEntries: PublishedPost[];
  query: PostCollectionQuery;
  repository: Pick<PublicPostReader, "listPublishedPosts" | "listDraftPosts">;
  render(post: PublishedPost, index: number): ReactNode;
  renderEmpty(): ReactNode;
  renderUnavailable(): ReactNode;
  previewMode?: boolean;
}

export async function PostCollection(props: PostCollectionProps): Promise<ReactNode> {
  const result = await loadPostCollection({ ...props, previewMode: props.previewMode });
  if (result.status === "unavailable") return props.renderUnavailable();
  if (result.posts.length === 0) return props.renderEmpty();
  return (
    <Fragment>
      {result.posts.map((post, index) => (
        <Fragment key={post.entryId}>
          {withPostPreviewMetadata(props.render(post, index), post, props.id, props.previewMode ?? false)}
        </Fragment>
      ))}
    </Fragment>
  );
}
