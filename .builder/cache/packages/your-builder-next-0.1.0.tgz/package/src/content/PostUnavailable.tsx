import React from "react";

export function PostUnavailable({ message = "Content is temporarily unavailable." }: { message?: string }) {
  return <p role="status">{message}</p>;
}

