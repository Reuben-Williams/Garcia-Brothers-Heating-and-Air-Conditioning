import type { ReactNode } from "react";
import type { PublishedPost } from "@your-builder/content";
import type { ContentSourceScope } from "@your-builder/core";
import { loadPostEntry, type PublicPostReader } from "./load-posts.js";

export interface PostEntryPageProps {
  siteKey: string;
  slug: string;
  scopes: ContentSourceScope[];
  fallbackEntries: PublishedPost[];
  repository: Required<Pick<PublicPostReader, "getPublishedPostBySlug">> & Pick<PublicPostReader, "getDraftPostBySlug">;
  previewMode?: boolean;
  render(post: PublishedPost): ReactNode;
  renderNotFound(): ReactNode;
  renderUnavailable(input: { status: 503; retryAfter: number }): ReactNode;
}

export async function PostEntryPage(props: PostEntryPageProps): Promise<ReactNode> {
  const result = await loadPostEntry(props);
  if (result.status === "ready") return props.render(result.post);
  if (result.status === "notFound") return props.renderNotFound();
  return props.renderUnavailable({ status: 503, retryAfter: result.retryAfter });
}
