import type { BuilderMembership } from "../auth/require-member.js";

export type BuilderRequestContext = BuilderMembership;

export type ResolveBuilderRequestContext = (
  request: Request,
) => Promise<BuilderRequestContext>;
