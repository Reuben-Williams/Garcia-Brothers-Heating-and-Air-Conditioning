import { canBuilderRole, type BuilderCapability } from "@your-builder/core";
import type { BuilderRequestContext, ResolveBuilderRequestContext } from "./request-context.js";
import { BuilderHttpError, toBuilderErrorResponse } from "./http-errors.js";

export type PostRouteTransition =
  | "saveDraft"
  | "publish"
  | "schedule"
  | "cancelSchedule"
  | "reschedule"
  | "archive"
  | "restoreDraft"
  | "rollback"
  | "undoRollback";

export interface PostRouteRepository {
  listPosts(context: BuilderRequestContext, query: URLSearchParams): Promise<unknown>;
  getPost(context: BuilderRequestContext, entryId: string): Promise<unknown>;
  createPost(context: BuilderRequestContext, payload: Record<string, unknown>): Promise<unknown>;
  duplicatePost(context: BuilderRequestContext, entryId: string): Promise<unknown>;
  transitionPost(
    context: BuilderRequestContext,
    operation: PostRouteTransition,
    entryId: string,
    payload: Record<string, unknown>,
    idempotencyKey: string,
  ): Promise<unknown>;
  listVersions(context: BuilderRequestContext, entryId: string): Promise<unknown>;
  listTaxonomies(context: BuilderRequestContext, query: URLSearchParams): Promise<unknown>;
  saveTaxonomy(context: BuilderRequestContext, payload: Record<string, unknown>): Promise<unknown>;
}

export interface PostRouteHandlerOptions {
  repository: PostRouteRepository;
  resolveContext: ResolveBuilderRequestContext;
  verifyCsrf?: (request: Request, context: BuilderRequestContext) => void | Promise<void>;
  rateLimit?: (
    request: Request,
    context: BuilderRequestContext,
    capability: BuilderCapability,
  ) => void | Promise<void>;
}

const forbiddenIdentityKeys = new Set(["siteId", "siteKey", "tenantId", "organizationId", "userId", "role"]);

async function readPayload(request: Request): Promise<Record<string, unknown>> {
  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    throw new BuilderHttpError(400, "INVALID_JSON", "A JSON request body is required.");
  }
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    throw new BuilderHttpError(400, "INVALID_PAYLOAD", "The request body must be a JSON object.");
  }
  const suppliedIdentity = Object.keys(payload).find((key) => forbiddenIdentityKeys.has(key));
  if (suppliedIdentity) {
    throw new BuilderHttpError(
      400,
      "TENANT_IDENTITY_FORBIDDEN",
      `${suppliedIdentity} must come from the authenticated request context.`,
    );
  }
  return payload as Record<string, unknown>;
}

function requireCapability(context: BuilderRequestContext, capability: BuilderCapability): void {
  if (!canBuilderRole(context.role, capability)) {
    throw new BuilderHttpError(403, "CONTENT_PERMISSION_DENIED", "This account cannot perform that action.");
  }
}

const transitionByRoute: Record<string, { operation: PostRouteTransition; capability: BuilderCapability }> = {
  draft: { operation: "saveDraft", capability: "post.editDraft" },
  publish: { operation: "publish", capability: "post.publish" },
  schedule: { operation: "schedule", capability: "post.schedule" },
  cancel: { operation: "cancelSchedule", capability: "post.schedule" },
  reschedule: { operation: "reschedule", capability: "post.schedule" },
  archive: { operation: "archive", capability: "post.archive" },
  "restore-draft": { operation: "restoreDraft", capability: "post.editDraft" },
  rollback: { operation: "rollback", capability: "post.rollback" },
  undo: { operation: "undoRollback", capability: "post.rollback" },
};

export function createPostRouteHandlers(options: PostRouteHandlerOptions) {
  async function prepareMutation(
    request: Request,
    context: BuilderRequestContext,
    capability: BuilderCapability,
  ) {
    requireCapability(context, capability);
    await options.verifyCsrf?.(request, context);
    await options.rateLimit?.(request, context, capability);
  }

  return {
    async handle(request: Request, segments: readonly string[]): Promise<Response> {
      try {
        const context = await options.resolveContext(request);
        const url = new URL(request.url);
        const [resource, entryId, action] = segments;

        if (request.method === "GET" && resource === "posts" && !entryId) {
          requireCapability(context, "preview.read");
          return Response.json(await options.repository.listPosts(context, url.searchParams));
        }
        if (request.method === "GET" && resource === "posts" && entryId && action === "versions") {
          requireCapability(context, "history.read");
          return Response.json(await options.repository.listVersions(context, entryId));
        }
        if (request.method === "GET" && resource === "posts" && entryId) {
          requireCapability(context, "preview.read");
          const result = await options.repository.getPost(context, entryId);
          return result === null
            ? Response.json({ error: { code: "POST_NOT_FOUND", message: "Post not found." } }, { status: 404 })
            : Response.json(result);
        }
        if (request.method === "GET" && resource === "taxonomies") {
          requireCapability(context, "preview.read");
          return Response.json(await options.repository.listTaxonomies(context, url.searchParams));
        }

        if (request.method === "POST" && resource === "posts" && !entryId) {
          await prepareMutation(request, context, "post.create");
          const payload = await readPayload(request);
          return Response.json(await options.repository.createPost(context, payload), { status: 201 });
        }
        if (request.method === "POST" && resource === "posts" && entryId && action === "duplicate") {
          await prepareMutation(request, context, "post.create");
          return Response.json(await options.repository.duplicatePost(context, entryId), { status: 201 });
        }
        if (request.method === "POST" && resource === "taxonomies") {
          await prepareMutation(request, context, "post.editDraft");
          return Response.json(await options.repository.saveTaxonomy(context, await readPayload(request)));
        }

        const transition = action ? transitionByRoute[action] : undefined;
        if (request.method === "POST" && resource === "posts" && entryId && transition) {
          await prepareMutation(request, context, transition.capability);
          const idempotencyKey = request.headers.get("x-idempotency-key")?.trim();
          if (!idempotencyKey) {
            throw new BuilderHttpError(400, "IDEMPOTENCY_KEY_REQUIRED", "An idempotency key is required.");
          }
          const payload = await readPayload(request);
          return Response.json(
            await options.repository.transitionPost(
              context,
              transition.operation,
              entryId,
              payload,
              idempotencyKey,
            ),
          );
        }

        throw new BuilderHttpError(404, "ROUTE_NOT_FOUND", "The builder API route was not found.");
      } catch (error) {
        return toBuilderErrorResponse(error);
      }
    },
  };
}
