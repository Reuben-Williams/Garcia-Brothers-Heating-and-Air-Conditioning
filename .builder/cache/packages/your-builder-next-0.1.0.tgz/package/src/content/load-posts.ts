import {
  filterAndSortPublishedPosts,
  type PostCollectionQuery,
  type PublishedPost,
} from "@your-builder/content";
import type { ContentSourceScope } from "@your-builder/core";

export interface PublicPostReader {
  listPublishedPosts(siteKey: string, query: PostCollectionQuery): Promise<PublishedPost[]>;
  listDraftPosts?(siteKey: string, query: PostCollectionQuery): Promise<PublishedPost[]>;
  getDraftPostBySlug?(siteKey: string, slug: string): Promise<PublishedPost | null>;
  getPublishedPostBySlug?(siteKey: string, slug: string): Promise<PublishedPost | null>;
}

export type PostCollectionLoadResult =
  | { status: "ready"; posts: PublishedPost[] }
  | { status: "unavailable"; posts: [] };

export interface LoadPostCollectionInput {
  siteKey: string;
  scope: ContentSourceScope;
  fallbackEntries: PublishedPost[];
  query: PostCollectionQuery;
  repository: Pick<PublicPostReader, "listPublishedPosts" | "listDraftPosts">;
  previewMode?: boolean;
}

export async function loadPostCollection(input: LoadPostCollectionInput): Promise<PostCollectionLoadResult> {
  if (input.previewMode && "listDraftPosts" in input.repository && typeof input.repository.listDraftPosts === "function") {
    try {
      return {
        status: "ready",
        posts: filterAndSortPublishedPosts(await input.repository.listDraftPosts(input.siteKey, input.query), input.query),
      };
    } catch {
      // Keep the typed fallback available if an authenticated preview read fails.
    }
  }
  if (input.scope.contentSource === "fallback") {
    const entryIds = new Set(input.scope.entryIds);
    const scoped = input.fallbackEntries.filter((post) => entryIds.size === 0 || entryIds.has(post.entryId));
    return { status: "ready", posts: filterAndSortPublishedPosts(scoped, input.query) };
  }
  try {
    return { status: "ready", posts: await input.repository.listPublishedPosts(input.siteKey, input.query) };
  } catch {
    return { status: "unavailable", posts: [] };
  }
}

export type PostEntryLoadResult =
  | { status: "ready"; post: PublishedPost }
  | { status: "notFound"; httpStatus: 404 }
  | { status: "unavailable"; httpStatus: 503; retryAfter: number };

export interface LoadPostEntryInput {
  siteKey: string;
  slug: string;
  scopes: ContentSourceScope[];
  fallbackEntries: PublishedPost[];
  repository: Required<Pick<PublicPostReader, "getPublishedPostBySlug">> & Pick<PublicPostReader, "getDraftPostBySlug">;
  previewMode?: boolean;
}

export async function loadPostEntry(input: LoadPostEntryInput): Promise<PostEntryLoadResult> {
  if (input.previewMode && input.repository.getDraftPostBySlug) {
    try {
      const draft = await input.repository.getDraftPostBySlug(input.siteKey, input.slug);
      if (draft) return { status: "ready", post: draft };
    } catch {
      // Continue to the stable fallback or fail-closed live source.
    }
  }
  const fallback = input.fallbackEntries.find((post) => post.slug === input.slug);
  const fallbackScope = fallback
    ? input.scopes.find((scope) => scope.entryIds.includes(fallback.entryId))
    : undefined;

  if (fallback && fallbackScope?.contentSource === "fallback") return { status: "ready", post: fallback };
  if (!fallback && input.scopes.some((scope) => scope.contentSource === "fallback")) {
    return { status: "notFound", httpStatus: 404 };
  }

  try {
    const post = await input.repository.getPublishedPostBySlug(input.siteKey, input.slug);
    return post ? { status: "ready", post } : { status: "notFound", httpStatus: 404 };
  } catch {
    return { status: "unavailable", httpStatus: 503, retryAfter: 60 };
  }
}
