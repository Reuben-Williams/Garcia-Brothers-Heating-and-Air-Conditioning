import React, { isValidElement, cloneElement, type ReactNode } from "react";
import type { PublishedPost } from "@your-builder/content";

export function withPostPreviewMetadata(
  node: ReactNode,
  post: PublishedPost,
  regionId: string,
  previewMode: boolean,
): ReactNode {
  if (!previewMode || !isValidElement<Record<string, unknown>>(node)) return node;
  return cloneElement(node, {
    "data-builder-content-type": "post",
    "data-builder-entry-id": post.entryId,
    "data-builder-version-id": post.versionId,
    "data-builder-region": regionId,
  });
}

