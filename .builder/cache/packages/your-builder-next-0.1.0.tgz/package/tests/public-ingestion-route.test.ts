// @vitest-environment node

import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  createPublicIngestionRouteHandler,
  type PublicIngestionRouteDependencies,
} from "../src/ingestion/server/index.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const IDEMPOTENCY_KEY = "22222222-2222-4222-8222-222222222222";
const RECEIPT_ID = "33333333-3333-4333-8333-333333333333";
const REPLAY_RECEIPT_ID = "44444444-4444-4444-8444-444444444444";
const NETWORK_HMAC = "a".repeat(64);
const IDENTITY_HMAC = "b".repeat(64);
const REQUEST_HMAC = "c".repeat(64);
const CONSENT_TEXT = "I agree to be contacted about this request.";
const LANGUAGE_DIGEST = createHash("sha256").update(CONSENT_TEXT, "utf8").digest("hex");

function body(overrides: Record<string, unknown> = {}) {
  return {
    firstName: "Synthetic",
    lastName: "Customer",
    email: "user@example.test",
    phone: "302-555-0100",
    zipCode: "19713",
    serviceId: "ac-repair",
    urgency: "urgent",
    message: "The system is not cooling.",
    consentAcknowledged: true,
    consentPolicyVersion: "privacy-v1",
    consentAcknowledgement: CONSENT_TEXT,
    turnstileToken: "private-turnstile-token",
    idempotencyKey: IDEMPOTENCY_KEY,
    ...overrides,
  };
}

function request(value: unknown = body(), init: RequestInit = {}) {
  return new Request("https://garciabrothers.test/api/builder/forms/contact/submit", {
    ...init,
    method: init.method ?? "POST",
    headers: {
      "content-type": "application/json",
      origin: "https://garciabrothers.test",
      "sec-fetch-site": "same-origin",
      "x-nf-client-connection-ip": "203.0.113.10",
      ...init.headers,
    },
    body: init.method === "GET" ? undefined : JSON.stringify(value),
  });
}

function dependencies(
  overrides: Partial<PublicIngestionRouteDependencies> = {},
): PublicIngestionRouteDependencies {
  return {
    siteId: SITE_ID,
    locale: "en-US",
    allowedOrigins: ["https://garciabrothers.test"],
    allowedFormIds: ["contact"],
    allowedServiceIds: ["ac-repair"],
    consentPolicy: {
      version: "privacy-v1",
      purpose: "service_request",
      acknowledgementText: CONSENT_TEXT,
    },
    rateLimits: {
      network: { limit: 20, windowMs: 3_600_000 },
      identity: { limit: 5, windowMs: 900_000 },
    },
    network: {
      resolve: vi.fn(async () => ({ address: "203.0.113.10" })),
    },
    fingerprints: {
      create: vi.fn(() => ({
        keyId: "site-key-2026-07",
        networkFingerprint: NETWORK_HMAC,
        identityFingerprint: IDENTITY_HMAC,
      })),
      createRequestFingerprint: vi.fn(() => REQUEST_HMAC),
    },
    turnstile: {
      verify: vi.fn(async () => ({ ok: true as const, safeCode: "TURNSTILE_VERIFIED" as const })),
    },
    ingestion: {
      ingest: vi.fn(async () => ({
        version: 1 as const,
        accepted: true as const,
        receiptId: RECEIPT_ID,
        result: "accepted" as const,
        contactId: "must-not-escape",
        enhanced: true,
      })),
    },
    now: () => new Date("2026-07-18T12:07:30.000Z"),
    uuid: () => RECEIPT_ID,
    ...overrides,
  };
}

describe("public ingestion route factory", () => {
  it("passes one complete trusted command to the transactional ingestion boundary", async () => {
    const deps = dependencies();
    const response = await createPublicIngestionRouteHandler(deps).handle(request(), { formId: "contact" });

    expect(response.status).toBe(202);
    await expect(response.json()).resolves.toEqual({
      version: 1,
      accepted: true,
      receiptId: RECEIPT_ID,
      result: "accepted",
    });
    expect(deps).not.toHaveProperty("securityPolicy");
    expect(deps.turnstile.verify).toHaveBeenCalledWith({
      token: "private-turnstile-token",
      remoteAddress: "203.0.113.10",
      idempotencyKey: IDEMPOTENCY_KEY,
    });
    expect(deps.fingerprints.createRequestFingerprint).toHaveBeenCalledWith({
      siteId: SITE_ID,
      formId: "contact",
      zipCode: "19713",
      locale: "en-US",
      payload: {
        firstName: "Synthetic",
        lastName: "Customer",
        email: "user@example.test",
        phone: "+13025550100",
        service: "ac-repair",
        urgency: "high",
        message: "The system is not cooling.",
      },
      consentEvidence: {
        policyVersion: "privacy-v1",
        purpose: "service_request",
        languageDigest: LANGUAGE_DIGEST,
        source: "public_form",
      },
    });
    expect(deps.ingestion.ingest).toHaveBeenCalledOnce();
    expect(deps.ingestion.ingest).toHaveBeenCalledWith({
      version: 1,
      siteId: SITE_ID,
      formId: "contact",
      idempotencyKey: IDEMPOTENCY_KEY,
      submittedAt: "2026-07-18T12:07:30.000Z",
      zipCode: "19713",
      locale: "en-US",
      payload: {
        firstName: "Synthetic",
        lastName: "Customer",
        email: "user@example.test",
        phone: "+13025550100",
        service: "ac-repair",
        urgency: "high",
        message: "The system is not cooling.",
      },
      consentEvidence: {
        policyVersion: "privacy-v1",
        purpose: "service_request",
        languageDigest: LANGUAGE_DIGEST,
        source: "public_form",
        capturedAt: "2026-07-18T12:07:30.000Z",
      },
      securityReceiptId: RECEIPT_ID,
      requestFingerprint: REQUEST_HMAC,
      rateLimits: [
        {
          bucketKeyHmac: NETWORK_HMAC,
          windowStartedAt: "2026-07-18T12:00:00.000Z",
          windowEndsAt: "2026-07-18T13:00:00.000Z",
          limit: 20,
        },
        {
          bucketKeyHmac: IDENTITY_HMAC,
          windowStartedAt: "2026-07-18T12:00:00.000Z",
          windowEndsAt: "2026-07-18T12:15:00.000Z",
          limit: 5,
        },
      ],
    });
  });

  it("uses the database replay receipt and never exposes stored matching facts", async () => {
    const deps = dependencies({
      ingestion: {
        ingest: vi.fn(async () => ({
          version: 1 as const,
          accepted: true as const,
          receiptId: REPLAY_RECEIPT_ID,
          result: "replayed" as const,
        })),
      },
    });
    const response = await createPublicIngestionRouteHandler(deps).handle(request(), { formId: "contact" });

    await expect(response.json()).resolves.toEqual({
      version: 1,
      accepted: true,
      receiptId: REPLAY_RECEIPT_ID,
      result: "replayed",
    });
  });

  it("rejects mismatched consent text or version before Turnstile and persistence", async () => {
    for (const invalid of [
      body({ consentPolicyVersion: "privacy-v0" }),
      body({ consentAcknowledgement: "Different terms" }),
    ]) {
      const deps = dependencies();
      const response = await createPublicIngestionRouteHandler(deps).handle(request(invalid), { formId: "contact" });
      expect(response.status).toBe(400);
      await expect(response.json()).resolves.toMatchObject({ error: { code: "INVALID_SUBMISSION" } });
      expect(deps.turnstile.verify).not.toHaveBeenCalled();
      expect(deps.ingestion.ingest).not.toHaveBeenCalled();
    }
  });

  it("rejects method, form, origin, and schema before persistence", async () => {
    const deps = dependencies();
    const handler = createPublicIngestionRouteHandler(deps);
    const cases = [
      [request(undefined, { method: "GET" }), { formId: "contact" }, 405, "METHOD_NOT_ALLOWED"],
      [request(), { formId: "unknown" }, 404, "FORM_NOT_FOUND"],
      [request(body(), { headers: { origin: "https://attacker.test" } }), { formId: "contact" }, 403, "ORIGIN_REJECTED"],
      [request(body({ email: undefined, phone: undefined })), { formId: "contact" }, 400, "INVALID_SUBMISSION"],
    ] as const;

    for (const [input, context, status, code] of cases) {
      const response = await handler.handle(input, context);
      expect(response.status).toBe(status);
      await expect(response.json()).resolves.toMatchObject({ error: { code } });
    }
    expect(deps.ingestion.ingest).not.toHaveBeenCalled();
  });

  it.each([
    ["TURNSTILE_REJECTED", 400],
    ["TURNSTILE_HOSTNAME_MISMATCH", 400],
    ["TURNSTILE_ACTION_MISMATCH", 400],
    ["TURNSTILE_TIMEOUT", 503],
    ["TURNSTILE_UNAVAILABLE", 503],
  ] as const)("maps %s to a bounded public error", async (safeCode, status) => {
    const deps = dependencies({
      turnstile: { verify: vi.fn(async () => ({ ok: false as const, safeCode })) },
    });
    const response = await createPublicIngestionRouteHandler(deps).handle(request(), { formId: "contact" });

    expect(response.status).toBe(status);
    await expect(response.json()).resolves.toMatchObject({ error: { code: safeCode } });
    expect(deps.ingestion.ingest).not.toHaveBeenCalled();
  });

  it("returns a generic temporary failure for unknown persistence faults", async () => {
    const deps = dependencies({
      ingestion: {
        ingest: vi.fn(async () => {
          throw new Error("database credential private detail user@example.test");
        }),
      },
    });
    const response = await createPublicIngestionRouteHandler(deps).handle(request(), { formId: "contact" });

    expect(response.status).toBe(503);
    const text = await response.text();
    expect(text).toContain("INGESTION_UNAVAILABLE");
    expect(text).not.toMatch(/database|credential|user@example/);
  });

  it("uses standard web primitives without importing Next.js transport objects", async () => {
    const source = await readFile(resolve("packages/next/src/ingestion/public-route.ts"), "utf8");
    expect(source).not.toMatch(/from ["']next|NextRequest|NextResponse/);
  });
});
