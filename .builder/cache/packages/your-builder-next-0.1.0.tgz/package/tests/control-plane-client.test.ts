import { createHash } from "node:crypto";

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  InstallationClientError,
  createInstallationClient,
  loadInstallationClientConfig,
  parseInstallationClientConfig,
} from "../src/control-plane/index.js";

const INSTALLATION_ID = "11111111-1111-4111-8111-111111111111";
const KEY_ID = "key-2026-07";
const PRIVATE_JWK = {
  kty: "OKP",
  crv: "Ed25519",
  alg: "EdDSA",
  x: "11qYAYKxCrfVS_7TyWQHOg7hcvPapiMlrwIaaPcHURo",
  d: "nWGxne_9WmC6hEr0kuwsxERJxWl7MmkZcDusAxyuf2A",
} as const;

function validConfig() {
  return {
    controlPlaneUrl: "https://control.example.com",
    installationId: INSTALLATION_ID,
    keyId: KEY_ID,
    privateJwk: PRIVATE_JWK,
  };
}

describe("installation client configuration", () => {
  it("parses only a strict private Ed25519 JWK and a safe control-plane URL", () => {
    expect(parseInstallationClientConfig(validConfig())).toEqual(validConfig());
    expect(
      parseInstallationClientConfig({
        ...validConfig(),
        controlPlaneUrl: "http://127.0.0.1:3001/",
      }),
    ).toMatchObject({ controlPlaneUrl: "http://127.0.0.1:3001" });
  });

  it.each([
    ["public URL", { controlPlaneUrl: "http://control.example.com" }],
    ["credentials", { controlPlaneUrl: "https://user:pass@control.example.com" }],
    ["query", { controlPlaneUrl: "https://control.example.com?secret=value" }],
    ["hash", { controlPlaneUrl: "https://control.example.com/#value" }],
    ["installation ID", { installationId: "not-a-uuid" }],
    ["key ID", { keyId: "bad key" }],
    ["public JWK", { privateJwk: { ...PRIVATE_JWK, d: undefined } }],
    ["extra JWK field", { privateJwk: { ...PRIVATE_JWK, kid: "secret-label" } }],
  ])("rejects invalid %s without exposing the input", (_label, override) => {
    const secret = "do-not-leak-this-value";
    expect(() =>
      parseInstallationClientConfig({ ...validConfig(), ...override, secret }),
    ).toThrowError(expect.objectContaining({ code: "invalid_installation_config" }));
    try {
      parseInstallationClientConfig({ ...validConfig(), ...override, secret });
    } catch (error) {
      expect(String(error)).not.toContain(secret);
      expect(JSON.stringify(error)).not.toContain(PRIVATE_JWK.d);
    }
  });

  it("loads server-only names and rejects browser-prefixed aliases", () => {
    expect(
      loadInstallationClientConfig({
        BUILDER_CONTROL_PLANE_URL: "https://control.example.com",
        BUILDER_INSTALLATION_ID: INSTALLATION_ID,
        BUILDER_INSTALLATION_KEY_ID: KEY_ID,
        BUILDER_INSTALLATION_PRIVATE_JWK: JSON.stringify(PRIVATE_JWK),
      }),
    ).toEqual(validConfig());

    expect(() =>
      loadInstallationClientConfig({
        NEXT_PUBLIC_BUILDER_CONTROL_PLANE_URL: "https://control.example.com",
        NEXT_PUBLIC_BUILDER_INSTALLATION_ID: INSTALLATION_ID,
        NEXT_PUBLIC_BUILDER_INSTALLATION_KEY_ID: KEY_ID,
        NEXT_PUBLIC_BUILDER_INSTALLATION_PRIVATE_JWK: JSON.stringify(PRIVATE_JWK),
      }),
    ).toThrowError(expect.objectContaining({ code: "invalid_installation_config" }));
  });

  it("rejects unknown top-level configuration fields", () => {
    expect(() =>
      parseInstallationClientConfig({ ...validConfig(), unexpected: true }),
    ).toThrowError(expect.objectContaining({ code: "invalid_installation_config" }));
  });

  it("rejects a private JWK whose public coordinate does not derive from its private scalar", () => {
    const mismatchedPublicCoordinate = "D7s9xYp8U4N1gQ3mR6aF2vC5kL0jH8bW9eT7uI4oPqA";

    expect(() =>
      parseInstallationClientConfig({
        ...validConfig(),
        privateJwk: { ...PRIVATE_JWK, x: mismatchedPublicCoordinate },
      }),
    ).toThrowError(expect.objectContaining({ code: "invalid_installation_config" }));

    try {
      parseInstallationClientConfig({
        ...validConfig(),
        privateJwk: { ...PRIVATE_JWK, x: mismatchedPublicCoordinate },
      });
    } catch (error) {
      expect(String(error)).not.toContain(PRIVATE_JWK.d);
      expect(String(error)).not.toContain(mismatchedPublicCoordinate);
    }
  });
});

describe("installation client", () => {
  it("shares the server command-pull boundary", async () => {
    const fetch = vi.fn<typeof globalThis.fetch>(async () => Response.json({ commands: [] }));
    const client = createInstallationClient(validConfig(), { fetch });

    await expect(client.pullCommands({ limit: 30, leaseSeconds: 30 })).resolves.toEqual([]);
    await expect(client.pullCommands({ limit: 31, leaseSeconds: 30 })).rejects.toMatchObject({
      code: "invalid_request",
    });
    expect(fetch).toHaveBeenCalledTimes(1);
  });

  it("serializes once, signs the exact bytes, and refreshes retry authentication", async () => {
    const bodies: Uint8Array[] = [];
    const headers: Headers[] = [];
    const fetch = vi
      .fn<typeof globalThis.fetch>()
      .mockImplementationOnce(async (_url, init) => {
        bodies.push(new Uint8Array(await new Response(init?.body).arrayBuffer()));
        headers.push(new Headers(init?.headers));
        return Response.json({ error: "temporarily_unavailable" }, { status: 503 });
      })
      .mockImplementationOnce(async (_url, init) => {
        bodies.push(new Uint8Array(await new Response(init?.body).arrayBuffer()));
        headers.push(new Headers(init?.headers));
        return Response.json({ commands: [] });
      });
    const times = [
      new Date("2026-07-16T12:00:00.000Z"),
      new Date("2026-07-16T12:00:01.000Z"),
    ];
    const nonces = [
      "AQIDBAUGBwgJCgsMDQ4PEA",
      "ERITFBUWFxgZGhscHR4fIA",
    ];
    const client = createInstallationClient(validConfig(), {
      fetch,
      now: () => times.shift()!,
      nonce: () => nonces.shift()!,
      maxAttempts: 2,
    });

    await expect(client.pullCommands({ limit: 10, leaseSeconds: 30 })).resolves.toEqual([]);

    expect(fetch).toHaveBeenCalledTimes(2);
    expect(Buffer.from(bodies[0]!)).toEqual(Buffer.from(bodies[1]!));
    expect(new TextDecoder().decode(bodies[0])).toBe('{"limit":10,"leaseSeconds":30}');
    expect(headers.map((value) => value.get("x-builder-installation-id"))).toEqual([
      INSTALLATION_ID,
      INSTALLATION_ID,
    ]);
    expect(headers.map((value) => value.get("x-builder-timestamp"))).toEqual([
      "2026-07-16T12:00:00.000Z",
      "2026-07-16T12:00:01.000Z",
    ]);
    expect(headers.map((value) => value.get("x-builder-nonce"))).toEqual([
      "AQIDBAUGBwgJCgsMDQ4PEA",
      "ERITFBUWFxgZGhscHR4fIA",
    ]);
    expect(headers[0]!.get("x-builder-signature")).not.toBe(
      headers[1]!.get("x-builder-signature"),
    );
    expect(
      createHash("sha256").update(bodies[0]!).digest("base64url"),
    ).toBe("hLW23LGkOgeceC4b7mxPr1_KUSDxZS42go3m0yDv6lo");
  });

  it("accepts the complete bounded command envelope", async () => {
    const command = {
      id: "22222222-2222-4222-8222-222222222222",
      type: "module.install",
      version: 1,
      payload: { moduleId: "reviews" },
      idempotencyKey: "install-reviews-v1",
      createdAt: "2026-07-16T11:59:00.000Z",
      leaseToken: "33333333-3333-4333-8333-333333333333",
      attempt: 2,
      leaseExpiresAt: "2026-07-16T12:00:30.000Z",
    };
    const client = createInstallationClient(validConfig(), {
      fetch: vi.fn(async () => Response.json({ commands: [command] })),
      now: () => new Date("2026-07-16T12:00:00.000Z"),
      nonce: () => "AQIDBAUGBwgJCgsMDQ4PEA",
    });

    await expect(client.pullCommands({ limit: 1, leaseSeconds: 30 })).resolves.toEqual([
      command,
    ]);
  });

  it.each([
    ["missing lease token", { commands: [{ id: INSTALLATION_ID }] }],
    ["unbounded command list", { commands: Array.from({ length: 101 }, () => ({})) }],
    ["wrong acknowledgment", { accepted: "yes" }],
  ])("rejects %s with a stable error and no raw response", async (_label, responseBody) => {
    const rawSecret = "raw-server-secret";
    const client = createInstallationClient(validConfig(), {
      fetch: vi.fn(async () =>
        Response.json({ ...responseBody, rawSecret }, { status: 200 }),
      ),
      now: () => new Date("2026-07-16T12:00:00.000Z"),
      nonce: () => "AQIDBAUGBwgJCgsMDQ4PEA",
      maxAttempts: 1,
    });

    const request = _label === "wrong acknowledgment"
      ? client.acknowledgeResult({
          commandId: "22222222-2222-4222-8222-222222222222",
          attempt: 1,
          leaseToken: "33333333-3333-4333-8333-333333333333",
          outcome: "failed",
          errorCode: "UNSUPPORTED_COMMAND_TYPE",
          evidence: { version: 1, codes: [], metrics: {}, flags: {}, digests: {} },
        })
      : client.pullCommands({ limit: 1, leaseSeconds: 30 });

    await expect(request).rejects.toMatchObject({
      name: "InstallationClientError",
      code: "invalid_response",
    });
    await request.catch((error: InstallationClientError) => {
      expect(error.message).not.toContain(rawSecret);
      expect(JSON.stringify(error)).not.toContain(rawSecret);
    });
  });

  it("rejects an unsafe health report before making a request", async () => {
    const fetch = vi.fn<typeof globalThis.fetch>();
    const client = createInstallationClient(validConfig(), { fetch });

    await expect(
      client.reportHealth({
        manifestVersion: 1,
        packages: {},
        schemas: {},
        worker: { status: "healthy" },
        queues: {},
        integrations: {},
        entitlementSnapshotAgeSeconds: null,
        backupAgeSeconds: null,
        errorCodes: [],
        secret: "must-not-leave-process",
      } as never),
    ).rejects.toMatchObject({ code: "invalid_request" });
    expect(fetch).not.toHaveBeenCalled();
  });

  it("accepts the bounded health acknowledgment containing only accepted/reportId", async () => {
    const fetch = vi.fn<typeof globalThis.fetch>(async () =>
      Response.json({
        accepted: true,
        reportId: "55555555-5555-4555-8555-555555555555",
      }),
    );
    const client = createInstallationClient(validConfig(), {
      fetch,
      now: () => new Date("2026-07-16T12:00:00.000Z"),
      nonce: () => "AQIDBAUGBwgJCgsMDQ4PEA",
    });

    await expect(client.reportHealth({
      manifestVersion: 1,
      packages: {},
      schemas: {},
      worker: { status: "healthy" },
      queues: {},
      integrations: {},
      entitlementSnapshotAgeSeconds: null,
      backupAgeSeconds: null,
      errorCodes: [],
    })).resolves.toBeUndefined();
  });

  it("rejects a malformed rotation key before making a request", async () => {
    const fetch = vi.fn<typeof globalThis.fetch>();
    const client = createInstallationClient(validConfig(), { fetch });

    await expect(
      client.rotateCredential({
        previousKeyId: KEY_ID,
        newKeyId: "next-key",
        publicJwk: { ...PRIVATE_JWK },
        overlapSeconds: 300,
      }),
    ).rejects.toMatchObject({ code: "invalid_request" });
    expect(fetch).not.toHaveBeenCalled();
  });

  it("sends previousKeyId in the exact signed rotation body", async () => {
    const publicJwk = {
      kty: "OKP",
      crv: "Ed25519",
      alg: "EdDSA",
      x: "D7s9xYp8U4N1gQ3mR6aF2vC5kL0jH8bW9eT7uI4oPqA",
    } as const;
    let body = "";
    const fetch = vi.fn<typeof globalThis.fetch>(async (_url, init) => {
      body = await new Response(init?.body).text();
      return Response.json({ acceptedKeyId: "next-key" });
    });
    const client = createInstallationClient(validConfig(), {
      fetch,
      now: () => new Date("2026-07-16T12:00:00.000Z"),
      nonce: () => "AQIDBAUGBwgJCgsMDQ4PEA",
    });

    await expect(client.rotateCredential({
      previousKeyId: KEY_ID,
      newKeyId: "next-key",
      publicJwk,
      overlapSeconds: 300,
    })).resolves.toEqual({ acceptedKeyId: "next-key" });

    expect(body).toBe(JSON.stringify({
      previousKeyId: KEY_ID,
      newKeyId: "next-key",
      publicJwk,
      overlapSeconds: 300,
    }));
  });

  it("rejects rotation when the configured signer is neither previousKeyId nor newKeyId", async () => {
    const fetch = vi.fn<typeof globalThis.fetch>();
    const client = createInstallationClient(validConfig(), { fetch });

    await expect(client.rotateCredential({
      previousKeyId: "unrelated-previous-key",
      newKeyId: "next-key",
      publicJwk: {
        kty: "OKP",
        crv: "Ed25519",
        alg: "EdDSA",
        x: "D7s9xYp8U4N1gQ3mR6aF2vC5kL0jH8bW9eT7uI4oPqA",
      },
      overlapSeconds: 300,
    })).rejects.toMatchObject({ code: "invalid_request" });
    expect(fetch).not.toHaveBeenCalled();
  });
});
