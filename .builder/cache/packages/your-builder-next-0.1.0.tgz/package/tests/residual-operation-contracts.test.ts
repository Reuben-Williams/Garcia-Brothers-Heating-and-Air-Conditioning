// @vitest-environment node

import { describe, expect, it } from "vitest";

import { RESIDUAL_OPERATION_LIMITS } from "../src/operations/index.js";

describe("residual browser-safe operation contracts", () => {
  it("publishes the frozen request limits without importing server implementations", () => {
    expect(RESIDUAL_OPERATION_LIMITS).toEqual({
      maxBulkRecords: 100,
      maxSavedViewClauses: 20,
      maxSearchLength: 200,
    });
  });
});
