// @vitest-environment node

import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

import {
  GROWTH_HEALTH_CONTRACT_VERSION,
  isSanitizedGrowthHealthProjection,
  type SanitizedGrowthHealthProjection,
} from "../src/health/index.js";

const projection = {
  version: 1,
  siteId: "11111111-1111-4111-8111-111111111111",
  kind: "entitlement_snapshot",
  status: "degraded",
  checkedAt: "2026-07-18T12:00:00.000Z",
  observedVersion: "2.0.0",
  queueAgeSeconds: null,
  snapshotAgeSeconds: 90,
  safeErrorCode: "snapshot_stale",
} as const satisfies SanitizedGrowthHealthProjection;

describe("Next growth health contracts", () => {
  it("accepts an exact sanitized projection", () => {
    expect(GROWTH_HEALTH_CONTRACT_VERSION).toBe(1);
    expect(isSanitizedGrowthHealthProjection(projection)).toBe(true);
  });

  it.each([
    { ...projection, customerEmail: "private@example.com" },
    { ...projection, ipAddress: "203.0.113.2" },
    { ...projection, turnstileToken: "secret" },
    { ...projection, safeErrorCode: "contains spaces" },
    { ...projection, snapshotAgeSeconds: -1 },
  ])("rejects unsafe or malformed health data", (value) => {
    expect(isSanitizedGrowthHealthProjection(value)).toBe(false);
  });

  it("keeps the health subpath free of React and HTTP runtime imports", () => {
    const source = readFileSync(
      fileURLToPath(new URL("../src/health/contracts.ts", import.meta.url)),
      "utf8",
    );
    expect(source).not.toMatch(/from ["']react/);
    expect(source).not.toMatch(/next\/server/);
  });
});
