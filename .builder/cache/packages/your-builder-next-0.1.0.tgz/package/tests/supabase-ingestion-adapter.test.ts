// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  PublicIngestionRpcError,
  createSupabasePublicIngestionService,
  type TrustedPublicIngestionCommand,
} from "../src/ingestion/server/index.js";

const RECEIPT_ID = "33333333-3333-4333-8333-333333333333";

function command(): TrustedPublicIngestionCommand {
  return {
    version: 1,
    siteId: "11111111-1111-4111-8111-111111111111",
    formId: "contact",
    idempotencyKey: "22222222-2222-4222-8222-222222222222",
    submittedAt: "2026-07-18T12:07:30.000Z",
    zipCode: "19713",
    locale: "en-US",
    payload: {
      firstName: "Synthetic",
      lastName: "Customer",
      email: "user@example.test",
      service: "ac-repair",
      urgency: "high",
      message: "No cooling",
    },
    consentEvidence: {
      policyVersion: "privacy-v1",
      purpose: "service_request",
      languageDigest: "d".repeat(64),
      source: "public_form",
      capturedAt: "2026-07-18T12:07:30.000Z",
    },
    securityReceiptId: RECEIPT_ID,
    requestFingerprint: "c".repeat(64),
    rateLimits: [
      {
        bucketKeyHmac: "a".repeat(64),
        windowStartedAt: "2026-07-18T12:00:00.000Z",
        windowEndsAt: "2026-07-18T13:00:00.000Z",
        limit: 20,
      },
      {
        bucketKeyHmac: "b".repeat(64),
        windowStartedAt: "2026-07-18T12:00:00.000Z",
        windowEndsAt: "2026-07-18T12:15:00.000Z",
        limit: 5,
      },
    ],
  };
}

describe("Supabase public ingestion RPC adapter", () => {
  it.each(["accepted", "replayed"] as const)("passes the trusted command and maps %s output", async (result) => {
    const rpc = vi.fn(async () => ({
      data: {
        version: 1,
        accepted: true,
        receiptId: RECEIPT_ID,
        result,
        contactId: "must-not-escape",
        enhanced: true,
      },
      error: null,
    }));
    const service = createSupabasePublicIngestionService({ rpc });
    const input = command();

    await expect(service.ingest(input)).resolves.toEqual({
      version: 1,
      accepted: true,
      receiptId: RECEIPT_ID,
      result,
    });
    expect(rpc).toHaveBeenCalledWith("builder_ingest_form_submission_v1", { p_request: input });
  });

  it("maps database errors to a stable safe failure without exposing details", async () => {
    const service = createSupabasePublicIngestionService({
      rpc: vi.fn(async () => ({
        data: null,
        error: { code: "22023", message: "private row and user@example.test" },
      })),
    });

    const promise = service.ingest(command());
    await expect(promise).rejects.toBeInstanceOf(PublicIngestionRpcError);
    await expect(service.ingest(command())).rejects.toMatchObject({
      safeCode: "INGESTION_RPC_UNAVAILABLE",
      message: "Public ingestion is temporarily unavailable.",
    });
  });

  it.each([
    null,
    { version: 2, accepted: true, receiptId: RECEIPT_ID, result: "accepted" },
    { version: 1, accepted: false, receiptId: RECEIPT_ID, result: "accepted" },
    { version: 1, accepted: true, receiptId: "not-a-uuid", result: "accepted" },
    { version: 1, accepted: true, receiptId: RECEIPT_ID, result: "enhanced" },
  ])("rejects malformed RPC output without returning provider data %#", async (data) => {
    const service = createSupabasePublicIngestionService({
      rpc: vi.fn(async () => ({ data, error: null })),
    });

    await expect(service.ingest(command())).rejects.toMatchObject({
      safeCode: "INGESTION_RPC_INVALID_RESPONSE",
      message: "Public ingestion returned an invalid response.",
    });
  });
});
