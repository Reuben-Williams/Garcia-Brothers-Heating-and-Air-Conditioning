import { describe, expect, it } from "vitest";

import {
  MAX_QUERY_PAGE_SIZE,
  MAX_QUERY_SEARCH_LENGTH,
  QUERY_CONTRACT_VERSION,
  QUERY_PROJECTION_STATUSES,
} from "../src/queries/index.js";

describe("browser-safe query contracts", () => {
  it("freezes bounded versioned projection constants", () => {
    expect(QUERY_CONTRACT_VERSION).toBe(1);
    expect(MAX_QUERY_PAGE_SIZE).toBe(100);
    expect(MAX_QUERY_SEARCH_LENGTH).toBe(200);
    expect(QUERY_PROJECTION_STATUSES).toEqual([
      "allowed",
      "read_only",
      "restricted",
      "stale",
      "not_found",
    ]);
  });
});
