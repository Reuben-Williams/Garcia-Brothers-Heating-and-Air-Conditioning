// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  QueryRpcError,
  createSupabaseQueryPersistence,
  mapStoredLeadSource,
  mapStoredLeadUrgency,
  type QueryRpcClient,
} from "../src/queries/server/index.js";
import { ALLOWED_QUERY_RPC_FIXTURES } from "./fixtures/query-rpc-fixtures.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const MEMBER_ID = "22222222-2222-4222-8222-222222222222";
const RECORD_ID = "33333333-3333-4333-8333-333333333333";
const CUSTOMER_ID = "44444444-4444-4444-8444-444444444444";
const SORT_CURSOR_VALUE = { version: 1, sortValue: "2026-07-18T10:00:00.000Z", id: RECORD_ID };
const CREATED_CURSOR_VALUE = { version: 1, createdAt: "2026-07-18T10:00:00.000Z", id: RECORD_ID };
const RECEIVED_CURSOR_VALUE = { version: 1, receivedAt: "2026-07-18T10:00:00.000Z", id: RECORD_ID };
const opaque = (value: object) => Buffer.from(JSON.stringify(value)).toString("base64url");

function client(data: unknown, error: unknown = null): QueryRpcClient {
  return { rpc: vi.fn(async () => ({ data, error })) };
}

describe("Supabase query persistence", () => {
  it.each([
    ["listLeads", "builder_list_leads_v1", { search: "ana", limit: 25, cursor: opaque(SORT_CURSOR_VALUE) }, { search: "ana", limit: 25, cursor: SORT_CURSOR_VALUE }],
    ["getLeadDetail", "builder_get_lead_detail_v1", { leadId: RECORD_ID }, { leadId: RECORD_ID }],
    ["listCustomers", "builder_list_customers_v1", { search: "ana", filter: { version: 1, conjunction: "all", clauses: [] }, limit: 25, cursor: opaque(SORT_CURSOR_VALUE) }, { search: "ana", segment: { version: 1, conjunction: "all", clauses: [] }, limit: 25, cursor: SORT_CURSOR_VALUE }],
    ["getCustomerDetail", "builder_get_customer_detail_v1", { customerId: RECORD_ID }, { customerId: RECORD_ID }],
    ["getDashboardFacts", "builder_get_dashboard_facts_v1", {}, {}],
    ["listFormSubmissions", "builder_list_form_submissions_v1", { resultCodes: ["enhanced"], limit: 25, cursor: opaque(RECEIVED_CURSOR_VALUE) }, { resultCodes: ["enhanced"], limit: 25, cursor: RECEIVED_CURSOR_VALUE }],
    ["getFormSubmissionDetail", "builder_get_form_submission_detail_v1", { submissionId: RECORD_ID }, { submissionId: RECORD_ID }],
    ["listInAppNotifications", "builder_list_in_app_notifications_v1", { unreadOnly: true, limit: 25, cursor: opaque(CREATED_CURSOR_VALUE) }, { unreadOnly: true, limit: 25, cursor: CREATED_CURSOR_VALUE }],
    ["listAssignmentMembers", "builder_list_assignment_members_v1", { purpose: "lead_assignment" }, { purpose: "lead_assignment" }],
    ["listMemberInvitations", "builder_list_member_invitations_v1", { limit: 25, cursor: opaque(CREATED_CURSOR_VALUE) }, { limit: 25, cursor: CREATED_CURSOR_VALUE }],
  ] as const)("maps %s to the frozen %s RPC with trusted identity", async (method, rpcName, input, expectedRequest) => {
    const rpc = client({ version: 1, status: "restricted", providerDetail: "private" });
    const persistence = createSupabaseQueryPersistence(rpc);

    const result = await (persistence[method] as Function)({
      siteId: SITE_ID,
      actorId: MEMBER_ID,
      ...input,
    });

    expect(rpc.rpc).toHaveBeenCalledWith(rpcName, {
      p_request: { version: 1, siteId: SITE_ID, actorId: MEMBER_ID, ...expectedRequest },
    });
    expect(result).toEqual({ version: 1, status: "restricted" });
    expect(JSON.stringify(result)).not.toContain("providerDetail");
  });

  it("strictly projects an allowed lead detail and translates stored source and urgency", async () => {
    const rpc = client({
      version: 1,
      status: "allowed",
      lead: {
          id: RECORD_ID,
          contactId: CUSTOMER_ID,
          source: "public_form",
          service: "ac_repair",
          urgency: "high",
          priority: "urgent",
          status: "new",
          summary: "Needs cooling repair",
          version: 3,
          createdAt: "2026-07-18T10:00:00.000Z",
          updatedAt: "2026-07-18T11:00:00.000Z",
          providerToken: "must-not-escape",
      },
      customer: { id: CUSTOMER_ID, displayName: "Ana M.", lifecycleState: "active", preferredContactMethod: "phone", version: 2 },
      identities: [], tags: [], tasks: [],
      serviceEvents: [{ id: RECORD_ID, eventKind: "appointment.scheduled", purpose: "follow_up", occurredAt: "2026-07-18T10:00:00.000Z", source: "integration", createdAt: "2026-07-18T10:00:00.000Z" }],
      timeline: [],
      submission: { id: RECORD_ID, formId: "contact", source: "public_form", receivedAt: "2026-07-18T10:00:00.000Z", payload: { privateNote: "sensitive-submission-payload" }, resultCode: "enhanced" },
    });

    const result = await createSupabaseQueryPersistence(rpc).getLeadDetail({
      siteId: SITE_ID,
      actorId: MEMBER_ID,
      leadId: RECORD_ID,
    });

    expect(result).toMatchObject({
      version: 1,
      status: "allowed",
      data: { lead: { source: "website_form", urgency: "urgent" } },
    });
    expect(JSON.stringify(result)).not.toContain("providerToken");
    expect(JSON.stringify(result)).not.toContain("sensitive-submission-payload");
    expect(mapStoredLeadSource("public_form")).toBe("website_form");
    expect(mapStoredLeadUrgency("normal")).toBe("standard");
    expect(mapStoredLeadUrgency("high")).toBe("urgent");
    expect(mapStoredLeadUrgency("emergency")).toBe("emergency");
  });

  it("converts SQL keyset cursors to opaque browser cursors", async () => {
    const persistence = createSupabaseQueryPersistence(client({
      version: 1,
      status: "allowed",
      items: [],
      nextCursor: SORT_CURSOR_VALUE,
    }));
    const result = await persistence.listLeads({ siteId: SITE_ID, actorId: MEMBER_ID, limit: 25 });
    expect(result).toEqual({
      version: 1,
      status: "allowed",
      data: { items: [], nextCursor: opaque(SORT_CURSOR_VALUE) },
    });
    expect(JSON.stringify(result)).not.toContain("sortValue");
  });

  it.each([
    ["listCustomers", { siteId: SITE_ID, actorId: MEMBER_ID, limit: 25 }, ALLOWED_QUERY_RPC_FIXTURES.customerList, "allowed"],
    ["getCustomerDetail", { siteId: SITE_ID, actorId: MEMBER_ID, customerId: RECORD_ID }, ALLOWED_QUERY_RPC_FIXTURES.customerDetail, "read_only"],
    ["getDashboardFacts", { siteId: SITE_ID, actorId: MEMBER_ID }, ALLOWED_QUERY_RPC_FIXTURES.dashboard, "stale"],
    ["listFormSubmissions", { siteId: SITE_ID, actorId: MEMBER_ID, limit: 25 }, ALLOWED_QUERY_RPC_FIXTURES.submissionList, "allowed"],
    ["getFormSubmissionDetail", { siteId: SITE_ID, actorId: MEMBER_ID, submissionId: RECORD_ID }, ALLOWED_QUERY_RPC_FIXTURES.submissionDetail, "allowed"],
    ["listInAppNotifications", { siteId: SITE_ID, actorId: MEMBER_ID, limit: 25 }, ALLOWED_QUERY_RPC_FIXTURES.notifications, "allowed"],
    ["listAssignmentMembers", { siteId: SITE_ID, actorId: MEMBER_ID, purpose: "lead_assignment" }, ALLOWED_QUERY_RPC_FIXTURES.assignmentMembers, "allowed"],
    ["listMemberInvitations", { siteId: SITE_ID, actorId: MEMBER_ID, limit: 25 }, ALLOWED_QUERY_RPC_FIXTURES.invitations, "allowed"],
  ] as const)("strictly projects the allowed %s SQL shape", async (method, input, fixture, status) => {
    const persistence = createSupabaseQueryPersistence(client(fixture));
    const result = await (persistence[method] as Function)(input);
    expect(result).toMatchObject({ version: 1, status, data: expect.any(Object) });
    expect(JSON.stringify(result)).not.toMatch(/providerToken|canonicalEmailDigest|tokenHash/);
  });

  it("rejects malformed success data and maps provider failures to stable safe errors", async () => {
    const malformed = createSupabaseQueryPersistence(client({ version: 1, status: "allowed", data: { items: "nope" } }));
    const unavailable = createSupabaseQueryPersistence(client(null, { code: "XX000", message: "private SQL" }));

    await expect(malformed.listLeads({ siteId: SITE_ID, actorId: MEMBER_ID, limit: 25 }))
      .rejects.toEqual(new QueryRpcError("QUERY_RPC_INVALID_RESPONSE"));
    await expect(unavailable.listLeads({ siteId: SITE_ID, actorId: MEMBER_ID, limit: 25 }))
      .rejects.toEqual(new QueryRpcError("QUERY_RPC_UNAVAILABLE"));
  });

  it("maps authorization SQLSTATE to a restricted projection without record-existence leakage", async () => {
    const persistence = createSupabaseQueryPersistence(client(null, { code: "42501", message: "private" }));
    await expect(persistence.getLeadDetail({ siteId: SITE_ID, actorId: MEMBER_ID, leadId: RECORD_ID }))
      .resolves.toEqual({ version: 1, status: "not_found" });
  });
});
