"use client";

import { createSupabaseResidualOperationalPersistence } from "../../src/operations/server/index.js";

export const residualOperationalServerValue = createSupabaseResidualOperationalPersistence;
