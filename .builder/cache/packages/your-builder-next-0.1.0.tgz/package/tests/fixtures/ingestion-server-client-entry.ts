"use client";

export { createPublicIngestionRouteHandler } from "../../src/ingestion/server/index.js";
