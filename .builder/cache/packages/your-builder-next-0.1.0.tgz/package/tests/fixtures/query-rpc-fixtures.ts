export const QUERY_FIXTURE_IDS = Object.freeze({
  site: "11111111-1111-4111-8111-111111111111",
  actor: "22222222-2222-4222-8222-222222222222",
  record: "33333333-3333-4333-8333-333333333333",
  related: "44444444-4444-4444-8444-444444444444",
});

const at = "2026-07-18T10:00:00.000Z";
const { record, related } = QUERY_FIXTURE_IDS;

export const ALLOWED_QUERY_RPC_FIXTURES = Object.freeze({
  customerList: {
    version: 1, status: "allowed",
    items: [{ id: record, displayName: "Ana M.", lifecycleState: "active", preferredContactMethod: "phone", serviceZipCode: "07105", latestActivityAt: at, version: 2, createdAt: at, updatedAt: at }],
    nextCursor: null,
  },
  customerDetail: {
    version: 1, status: "read_only",
    customer: { id: record, displayName: "Ana M.", lifecycleState: "active", preferredContactMethod: "phone", serviceZipCode: "07105", version: 2, createdAt: at, updatedAt: at },
    identities: [{ id: related, kind: "phone", value: "+19735550123", verificationState: "verified", source: "correction", createdAt: at }],
    preferences: [{ key: "contact_window", value: { period: "morning" }, version: 1, updatedAt: at }],
    suppressions: [], tags: [],
    leads: [{ id: related, source: "import", service: "ac_repair", urgency: "normal", status: "new", version: 1, createdAt: at, updatedAt: at }],
    serviceEvents: [], mergeSuggestions: [], exports: [], deletionRequests: [],
  },
  dashboard: {
    version: 1, status: "stale",
    facts: {
      leads: { status: "allowed", newCount: 2, agingCount: 1, unassignedCount: 1 },
      customers: { status: "restricted" },
      tasks: { status: "allowed", dueTodayCount: 1, overdueCount: 0 },
      notifications: { status: "allowed", unreadCount: 3 },
      baseSubmissions: { status: "allowed", recentCount: 4, spamReviewCount: 1 },
      health: { status: "allowed", items: [{ checkKind: "database", status: "ok", observedVersion: "1", queueAgeSeconds: 0, snapshotAgeSeconds: 2, safeCode: "ok", observedAt: at }] },
    },
  },
  submissionList: {
    version: 1, status: "allowed",
    items: [{ id: record, formId: "contact", source: "website_form", zipCode: "07105", locale: "en-US", receivedAt: at, currentResult: { id: related, version: 1, resultCode: "enhanced", contactId: related, leadId: record, safeMetadata: {}, createdAt: at } }],
    nextCursor: null,
  },
  submissionDetail: {
    version: 1, status: "allowed",
    submission: { id: record, formId: "contact", payload: { service: "ac_repair" }, source: "website_form", zipCode: "07105", locale: "en-US", receivedAt: at, createdAt: at },
    consents: [{ id: related, policyVersion: "v1", purpose: "service_request", languageDigest: "a".repeat(64), source: "website_form", capturedAt: at }],
    events: [{ id: related, eventKind: "review", actorId: QUERY_FIXTURE_IDS.actor, metadata: {}, createdAt: at }],
    results: [{ id: related, version: 1, resultCode: "base_only", safeMetadata: {}, createdAt: at }],
  },
  notifications: {
    version: 1, status: "allowed",
    items: [{ id: record, eventType: "lead.created", resourceType: "lead", resourceId: related, previewText: "New AC repair lead", readAt: null, createdAt: at }],
    unreadCount: 1, nextCursor: null,
  },
  assignmentMembers: {
    version: 1, status: "allowed",
    items: [{ id: QUERY_FIXTURE_IDS.actor, role: "editor", displayLabel: "Growth Manager" }],
  },
  invitations: {
    version: 1, status: "allowed",
    items: [{ id: record, templateId: "growth_staff_v1", templateVersion: 1, invitedBy: QUERY_FIXTURE_IDS.actor, state: "pending", expiresAt: "2026-07-25T10:00:00.000Z", acceptedBy: null, acceptedAt: null, revokedAt: null, version: 1, createdAt: at, updatedAt: at }],
    nextCursor: null,
  },
});
