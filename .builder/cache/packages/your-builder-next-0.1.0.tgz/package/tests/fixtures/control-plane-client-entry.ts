"use client";

export { createInstallationClient } from "../../src/control-plane/index.js";
