// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  QueryAuthorizationError,
  createAssignmentMemberListQueryRouteHandler,
  createCustomerDetailQueryRouteHandler,
  createCustomerListQueryRouteHandler,
  createDashboardFactsQueryRouteHandler,
  createFormSubmissionDetailQueryRouteHandler,
  createFormSubmissionListQueryRouteHandler,
  createInAppNotificationListQueryRouteHandler,
  createLeadDetailQueryRouteHandler,
  createLeadListQueryRouteHandler,
  createMemberInvitationListQueryRouteHandler,
  type QueryRouteDependencies,
} from "../src/queries/server/index.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const MEMBER_ID = "22222222-2222-4222-8222-222222222222";
const RECORD_ID = "33333333-3333-4333-8333-333333333333";
const CURSOR = Buffer.from(JSON.stringify({
  version: 1,
  sortValue: "2026-07-18T10:00:00.000Z",
  id: RECORD_ID,
})).toString("base64url");

function dependencies(overrides: Partial<QueryRouteDependencies> = {}): QueryRouteDependencies {
  const restricted = async () => ({ version: 1 as const, status: "restricted" as const });
  return {
    siteId: SITE_ID,
    now: () => new Date("2026-07-18T12:00:00.000Z"),
    authorizer: {
      authorize: vi.fn(async (_request, requirement) => ({
        siteId: SITE_ID,
        memberId: MEMBER_ID,
        role: "owner" as const,
        scope: requirement.allowedScopes[0]!,
        entitlementVerification: "current" as const,
      })),
      requireRecentAal2: vi.fn(async () => ({ verifiedAt: "2026-07-18T11:55:00.000Z" })),
    },
    persistence: {
      listLeads: vi.fn(restricted),
      getLeadDetail: vi.fn(restricted),
      listCustomers: vi.fn(restricted),
      getCustomerDetail: vi.fn(restricted),
      getDashboardFacts: vi.fn(restricted),
      listFormSubmissions: vi.fn(restricted),
      getFormSubmissionDetail: vi.fn(restricted),
      listInAppNotifications: vi.fn(restricted),
      listAssignmentMembers: vi.fn(restricted),
      listMemberInvitations: vi.fn(restricted),
    },
    ...overrides,
  };
}

function request(body: Record<string, unknown> = {}, method = "POST"): Request {
  return new Request("https://site.test/api/builder/queries", {
    method,
    headers: { "content-type": "application/json", origin: "https://site.test", "sec-fetch-site": "same-origin" },
    body: method === "POST" ? JSON.stringify(body) : undefined,
  });
}

describe("authenticated query route handlers", () => {
  it("binds lead search to the configured site and authenticated actor", async () => {
    const deps = dependencies();
    const response = await createLeadListQueryRouteHandler(deps).handle(request({
      search: "  Ana  ",
      limit: 25,
      cursor: CURSOR,
      sort: "updated_at",
      direction: "desc",
    }));

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "leads.read",
      allowedScopes: ["site", "assigned"],
      accessMode: "growth_leads_read",
    });
    expect(deps.persistence.listLeads).toHaveBeenCalledWith({
      siteId: SITE_ID,
      actorId: MEMBER_ID,
      search: "Ana",
      limit: 25,
      cursor: CURSOR,
      sort: "updated_at",
      direction: "desc",
    });
    expect(response.headers.get("cache-control")).toBe("no-store");
  });

  it.each([
    ["lead detail", createLeadDetailQueryRouteHandler, "getLeadDetail", { leadId: RECORD_ID }],
    ["customer detail", createCustomerDetailQueryRouteHandler, "getCustomerDetail", { customerId: RECORD_ID }],
    ["submission detail", createFormSubmissionDetailQueryRouteHandler, "getFormSubmissionDetail", { submissionId: RECORD_ID }],
  ] as const)("binds %s record identity from route params", async (_name, factory, method, params) => {
    const deps = dependencies();
    const response = await (factory(deps).handle as Function)(request(), params);
    expect(response.status).toBe(200);
    expect(deps.persistence[method]).toHaveBeenCalledWith(expect.objectContaining({
      siteId: SITE_ID,
      actorId: MEMBER_ID,
      ...params,
    }));
  });

  it("exposes all seven remaining frozen list/facts route factories", async () => {
    const cases = [
      [createCustomerListQueryRouteHandler, "listCustomers", { limit: 20 }],
      [createDashboardFactsQueryRouteHandler, "getDashboardFacts", {}],
      [createFormSubmissionListQueryRouteHandler, "listFormSubmissions", { limit: 20 }],
      [createInAppNotificationListQueryRouteHandler, "listInAppNotifications", { limit: 20 }],
      [createAssignmentMemberListQueryRouteHandler, "listAssignmentMembers", { purpose: "lead_assignment" }],
      [createMemberInvitationListQueryRouteHandler, "listMemberInvitations", { limit: 20 }],
    ] as const;

    for (const [factory, method, body] of cases) {
      const deps = dependencies();
      const response = await factory(deps).handle(request(body));
      expect(response.status).toBe(200);
      expect(deps.persistence[method]).toHaveBeenCalledOnce();
    }
  });

  it("requires owner/editor base policy and recent AAL2 for invitation visibility", async () => {
    const base = dependencies();
    await createFormSubmissionListQueryRouteHandler(base).handle(request({ limit: 20 }));
    expect(base.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      allowedRoles: ["owner", "editor"],
      allowedScopes: ["site"],
      accessMode: "base_submission_read",
    });

    const invitations = dependencies();
    await createMemberInvitationListQueryRouteHandler(invitations).handle(request({ limit: 20 }));
    expect(invitations.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "members.manage",
      allowedRoles: ["owner"],
      allowedScopes: ["site"],
      accessMode: "member_invitation_read",
    });
    expect(invitations.authorizer.requireRecentAal2).toHaveBeenCalledOnce();
  });

  it.each([
    [{ limit: 101 }, "INVALID_REQUEST"],
    [{ search: "x".repeat(201), limit: 20 }, "INVALID_REQUEST"],
    [{ limit: 20, cursor: "{raw-json-cursor}" }, "INVALID_REQUEST"],
    [{ limit: 20, cursor: "AAAAAAAAAAAAAAAA" }, "INVALID_REQUEST"],
    [{ limit: 20, siteId: SITE_ID }, "INVALID_REQUEST"],
    [{ limit: 20, actorId: MEMBER_ID }, "INVALID_REQUEST"],
  ])("rejects unbounded or client-asserted search input", async (body, code) => {
    const deps = dependencies();
    const response = await createLeadListQueryRouteHandler(deps).handle(request(body));
    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({ error: { code } });
    expect(deps.authorizer.authorize).not.toHaveBeenCalled();
    expect(deps.persistence.listLeads).not.toHaveBeenCalled();
  });

  it("requires POST and maps authorization failures to bounded safe responses", async () => {
    const deps = dependencies({
      authorizer: {
        authorize: vi.fn(async () => { throw new QueryAuthorizationError("SITE_ACCESS_DENIED"); }),
        requireRecentAal2: vi.fn(async () => ({ verifiedAt: "2026-07-18T11:55:00.000Z" })),
      },
    });
    const method = await createLeadListQueryRouteHandler(deps).handle(request({}, "GET"));
    const denied = await createLeadListQueryRouteHandler(deps).handle(request({ limit: 20 }));
    expect(method.status).toBe(405);
    expect(denied.status).toBe(404);
    await expect(denied.json()).resolves.toEqual({ error: { code: "NOT_FOUND", message: "The requested data is not available." } });
  });
});
