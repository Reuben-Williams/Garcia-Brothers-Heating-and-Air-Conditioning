// @vitest-environment node

import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { describe, expect, it } from "vitest";

describe("query server boundary", () => {
  it("keeps query contracts browser-safe and query implementations server-only", async () => {
    const browserEntry = await readFile(resolve("packages/next/src/queries/index.ts"), "utf8");
    const contracts = await readFile(resolve("packages/next/src/queries/contracts.ts"), "utf8");
    const serverEntry = await readFile(resolve("packages/next/src/queries/server/index.ts"), "utf8");
    const rootEntry = await readFile(resolve("packages/next/src/index.tsx"), "utf8");
    const packageManifest = JSON.parse(await readFile(resolve("packages/next/package.json"), "utf8"));

    expect(browserEntry).toBe('export * from "./contracts.js";\n');
    expect(browserEntry).not.toContain("server-only");
    expect(contracts).not.toMatch(/Supabase|RpcClient|Authorizer|RouteHandler|service_role|secret/i);
    expect(serverEntry.startsWith('import "server-only";')).toBe(true);
    expect(rootEntry).not.toContain("./queries");
    expect(packageManifest.exports["./queries"]).toEqual({
      types: "./src/queries/index.ts",
      default: "./src/queries/index.ts",
    });
    expect(packageManifest.exports["./queries/server"]).toEqual({
      types: "./src/queries/server/index.ts",
      default: "./src/queries/server/index.ts",
    });
    expect(serverEntry).toContain("../supabase-queries.js");
    expect(serverEntry).toContain("../route-handlers.js");
  });

  it("poisons client imports of query routes and RPC adapters", async () => {
    await expect(import("./fixtures/queries-server-client-entry.js")).rejects.toThrow(
      "This module cannot be imported from a Client Component module",
    );
  });
});
