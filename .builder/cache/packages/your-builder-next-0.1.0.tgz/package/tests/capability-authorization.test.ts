import { describe, expect, it, vi } from "vitest";

import { requireSiteCapability } from "../src/entitlements/capability-authorization.js";

describe("requireSiteCapability", () => {
  it("uses the site check when no resource is requested", async () => {
    const checkSite = vi.fn(async () => true);
    const checkRecord = vi.fn(async () => false);

    await expect(
      requireSiteCapability({
        siteId: "site-1",
        capability: "dashboard.read",
        checkSite,
        checkRecord,
      }),
    ).resolves.toBeUndefined();

    expect(checkSite).toHaveBeenCalledWith("site-1", "dashboard.read");
    expect(checkRecord).not.toHaveBeenCalled();
  });

  it("uses the record check with the exact resource identity", async () => {
    const checkSite = vi.fn(async () => false);
    const checkRecord = vi.fn(async () => true);

    await expect(
      requireSiteCapability({
        siteId: "site-1",
        capability: "leads.read",
        resource: { type: "lead", id: "lead-1" },
        checkSite,
        checkRecord,
      }),
    ).resolves.toBeUndefined();

    expect(checkRecord).toHaveBeenCalledWith("site-1", "leads.read", "lead", "lead-1");
    expect(checkSite).not.toHaveBeenCalled();
  });

  it("denies failed checks with the stable 403 response", async () => {
    const denied = requireSiteCapability({
      siteId: "site-1",
      capability: "messages.send",
      checkSite: async () => false,
      checkRecord: async () => false,
    });

    await expect(denied).rejects.toMatchObject({ status: 403 });
    await denied.catch(async (error: Response) => {
      expect(error).toBeInstanceOf(Response);
      expect(await error.text()).toBe("Capability denied");
    });
  });
});
