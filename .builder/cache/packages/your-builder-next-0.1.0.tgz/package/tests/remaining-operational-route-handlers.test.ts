// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  OperationalAuthorizationError,
  createCustomerDeletionRouteHandler,
  createCustomerExportRouteHandler,
  createCustomerMergeExecuteRouteHandler,
  createCustomerMergeReviewRouteHandler,
  createCustomerProfileUpdateRouteHandler,
  createMemberInvitationAcceptRouteHandler,
  createMemberInvitationRevokeRouteHandler,
  createMemberInvitationRouteHandler,
  createNotificationReadRouteHandler,
  type OperationalRouteDependencies,
} from "../src/operations/server/index.js";
import type { OperationalMutationResult, OperationalResourceType } from "../src/operations/index.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const MEMBER_ID = "22222222-2222-4222-8222-222222222222";
const USER_ID = "33333333-3333-4333-8333-333333333333";
const CUSTOMER_ID = "44444444-4444-4444-8444-444444444444";
const RESOURCE_ID = "55555555-5555-4555-8555-555555555555";
const COMMAND_ID = "66666666-6666-4666-8666-666666666666";
const TOKEN = "opaque-invitation-token";
const TOKEN_HASH = "a".repeat(64);
const EMAIL_DIGEST = "b".repeat(64);
const AAL2_AT = "2026-07-18T12:00:00.000Z";
const NOW = "2026-07-18T12:30:00.000Z";

function applied(resourceType: OperationalResourceType, resourceId = RESOURCE_ID, version = 1): OperationalMutationResult {
  return { status: "applied", resourceType, resourceId, version, replayed: false };
}

function dependencies(overrides: Partial<OperationalRouteDependencies> = {}): OperationalRouteDependencies {
  return {
    siteId: SITE_ID,
    allowedServices: [],
    now: () => new Date(NOW),
    authorizer: {
      authorize: vi.fn(async (_request, requirement) => ({
        siteId: SITE_ID,
        memberId: MEMBER_ID,
        role: "owner" as const,
        scope: requirement.allowedScopes[0]!,
        entitlementVerification: "current" as const,
        entitlementMode: requirement.entitlementMode,
      })),
      requireRecentAal2: vi.fn(async () => ({ verifiedAt: AAL2_AT })),
      requireAuthenticatedUser: vi.fn(async () => ({
        siteId: SITE_ID,
        userId: USER_ID,
        email: " Invitee@Example.test ",
        entitlementVerification: "current" as const,
        entitlementMode: "operational_write" as const,
      })),
    },
    invitationSecrets: {
      digestCanonicalEmail: vi.fn(async () => EMAIL_DIGEST),
      generateToken: vi.fn(async () => TOKEN),
      hashToken: vi.fn(async () => TOKEN_HASH),
    },
    persistence: {
      createManualLead: vi.fn(async () => applied("lead")),
      applyLeadCommand: vi.fn(async () => applied("lead")),
      createLeadTask: vi.fn(async () => applied("task")),
      recordLeadServiceEvent: vi.fn(async () => applied("service_event")),
      reviewFormSubmission: vi.fn(async () => applied("form_submission")),
      importFormSubmission: vi.fn(async () => applied("lead")),
      updateCustomerProfile: vi.fn(async () => applied("customer", CUSTOMER_ID, 4)),
      reviewCustomerMerge: vi.fn(async () => applied("merge_suggestion", RESOURCE_ID, 3)),
      executeCustomerMerge: vi.fn(async () => applied("customer", CUSTOMER_ID, 5)),
      requestCustomerExport: vi.fn(async () => applied("data_export")),
      requestCustomerDeletion: vi.fn(async () => applied("deletion_request")),
      markNotificationRead: vi.fn(async () => applied("notification")),
      createMemberInvitation: vi.fn(async () => applied("member_invitation")),
      revokeMemberInvitation: vi.fn(async () => applied("member_invitation", RESOURCE_ID, 2)),
      acceptMemberInvitation: vi.fn(async () => applied("member", MEMBER_ID)),
    },
    ...overrides,
  };
}

function request(
  body: Record<string, unknown>,
  options: { origin?: string; fetchSite?: string; headerId?: string } = {},
): Request {
  return new Request("https://site.test/api/builder/operations", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      origin: options.origin ?? "https://site.test",
      "sec-fetch-site": options.fetchSite ?? "same-origin",
      "x-idempotency-key": options.headerId ?? String(body.idempotencyKey ?? ""),
    },
    body: JSON.stringify(body),
  });
}

describe("remaining authenticated operational route handlers", () => {
  it("updates a bounded customer profile with trusted site and actor context", async () => {
    const deps = dependencies();
    const response = await createCustomerProfileUpdateRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 3,
      patch: {
        displayName: " Ana Morales ",
        preferredContactMethod: "phone",
        serviceAreaZip: "07105",
      },
    }), { customerId: CUSTOMER_ID });

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "customers.update",
      allowedScopes: ["site", "assigned"],
      entitlementMode: "operational_write",
      resource: { type: "customer", id: CUSTOMER_ID },
    });
    expect(deps.persistence.updateCustomerProfile).toHaveBeenCalledWith({
      siteId: SITE_ID,
      actor: { type: "member", id: MEMBER_ID },
      idempotencyKey: COMMAND_ID,
      expectedVersion: 3,
      customerId: CUSTOMER_ID,
      patch: {
        displayName: "Ana Morales",
        preferredContactMethod: "phone",
        serviceAreaZip: "07105",
      },
    });
  });

  it("reviews a merge only with site-scoped customer update access", async () => {
    const deps = dependencies();
    const response = await createCustomerMergeReviewRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 2,
      decision: "accept",
    }), { suggestionId: RESOURCE_ID });

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "customers.update",
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
      resource: { type: "merge_suggestion", id: RESOURCE_ID },
    });
    expect(deps.persistence.reviewCustomerMerge).toHaveBeenCalledWith({
      siteId: SITE_ID,
      actor: { type: "member", id: MEMBER_ID },
      idempotencyKey: COMMAND_ID,
      expectedVersion: 2,
      suggestionId: RESOURCE_ID,
      decision: "accept",
    });
  });

  it("executes an accepted merge as a separate version-checked site command", async () => {
    const deps = dependencies();
    const response = await createCustomerMergeExecuteRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedSuggestionVersion: 3,
      sourceId: RESOURCE_ID,
      targetId: CUSTOMER_ID,
      expectedSourceVersion: 2,
      expectedTargetVersion: 4,
    }), { suggestionId: RESOURCE_ID });

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "customers.update",
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
      resource: { type: "merge_suggestion", id: RESOURCE_ID },
    });
    expect(deps.persistence.executeCustomerMerge).toHaveBeenCalledWith({
      siteId: SITE_ID,
      actor: { type: "member", id: MEMBER_ID },
      idempotencyKey: COMMAND_ID,
      suggestionId: RESOURCE_ID,
      expectedSuggestionVersion: 3,
      sourceId: RESOURCE_ID,
      targetId: CUSTOMER_ID,
      expectedSourceVersion: 2,
      expectedTargetVersion: 4,
    });
  });

  it("requests a bounded customer export after recent AAL2", async () => {
    const deps = dependencies();
    const response = await createCustomerExportRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      customerIds: [CUSTOMER_ID],
      filter: { lifecycleState: ["active", "inactive"] },
    }));

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "customers.export",
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
    });
    expect(deps.authorizer.requireRecentAal2).toHaveBeenCalledOnce();
    expect(deps.persistence.requestCustomerExport).toHaveBeenCalledWith({
      siteId: SITE_ID,
      actor: { type: "member", id: MEMBER_ID },
      idempotencyKey: COMMAND_ID,
      customerIds: [CUSTOMER_ID],
      filter: { lifecycleState: ["active", "inactive"] },
      aal2VerifiedAt: AAL2_AT,
    });
  });

  it("keeps customer deletion owner-only and AAL2 protected", async () => {
    const deps = dependencies();
    const response = await createCustomerDeletionRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      reason: "Customer verified the deletion request.",
    }), { customerId: CUSTOMER_ID });

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "customers.deleteRequest",
      allowedRoles: ["owner"],
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
      resource: { type: "customer", id: CUSTOMER_ID },
    });
    expect(deps.authorizer.requireRecentAal2).toHaveBeenCalledOnce();
    expect(deps.persistence.requestCustomerDeletion).toHaveBeenCalledWith(expect.objectContaining({
      siteId: SITE_ID,
      actor: { type: "member", id: MEMBER_ID },
      customerId: CUSTOMER_ID,
      reason: "Customer verified the deletion request.",
      aal2VerifiedAt: AAL2_AT,
    }));
  });

  it("marks only the current member's notification read with a server timestamp", async () => {
    const deps = dependencies();
    const response = await createNotificationReadRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
    }), { notificationId: RESOURCE_ID });

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "dashboard.read",
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
      resource: { type: "notification", id: RESOURCE_ID },
    });
    expect(deps.persistence.markNotificationRead).toHaveBeenCalledWith({
      siteId: SITE_ID,
      notificationId: RESOURCE_ID,
      recipientMemberId: MEMBER_ID,
      readAt: NOW,
      idempotencyKey: COMMAND_ID,
    });
  });

  it.each([
    ["manager", "growth_manager_v1"],
    ["staff", "growth_staff_v1"],
    ["read-only", "growth_read_only_v1"],
  ] as const)("creates a %s invitation without passing raw email or token to persistence", async (template, templateId) => {
    const deps = dependencies();
    const response = await createMemberInvitationRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      email: " Staff@Example.test ",
      template,
    }));

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "members.manage",
      allowedRoles: ["owner"],
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
    });
    expect(deps.invitationSecrets.digestCanonicalEmail).toHaveBeenCalledWith("staff@example.test");
    expect(deps.persistence.createMemberInvitation).toHaveBeenCalledWith({
      siteId: SITE_ID,
      actorId: MEMBER_ID,
      idempotencyKey: COMMAND_ID,
      canonicalEmailDigest: EMAIL_DIGEST,
      tokenHash: TOKEN_HASH,
      templateId,
      templateVersion: 1,
      expiresAt: "2026-07-25T12:30:00.000Z",
      aal2VerifiedAt: AAL2_AT,
    });
    expect(JSON.stringify(vi.mocked(deps.persistence.createMemberInvitation).mock.calls)).not.toContain("Staff@Example.test");
    expect(JSON.stringify(vi.mocked(deps.persistence.createMemberInvitation).mock.calls)).not.toContain(TOKEN);
    await expect(response.json()).resolves.toEqual({
      result: "applied",
      invitation: { id: RESOURCE_ID, token: TOKEN },
      version: 1,
      replayed: false,
    });
  });

  it("reuses the deterministic invitation token and hash for an exact site-scoped retry", async () => {
    const deterministicToken = `invite-${COMMAND_ID}`;
    const deps = dependencies({
      invitationSecrets: {
        digestCanonicalEmail: vi.fn(async () => EMAIL_DIGEST),
        generateToken: vi.fn(async (idempotencyKey) => `invite-${idempotencyKey}`),
        hashToken: vi.fn(async (token) => token === deterministicToken ? TOKEN_HASH : "c".repeat(64)),
      },
    });
    vi.mocked(deps.persistence.createMemberInvitation)
      .mockResolvedValueOnce(applied("member_invitation", RESOURCE_ID, 1))
      .mockResolvedValueOnce({
        status: "applied",
        resourceType: "member_invitation",
        resourceId: RESOURCE_ID,
        version: 1,
        replayed: true,
      });

    const body = {
      idempotencyKey: COMMAND_ID,
      email: "staff@example.test",
      template: "staff",
    };
    const first = await createMemberInvitationRouteHandler(deps).handle(request(body));
    const retry = await createMemberInvitationRouteHandler(deps).handle(request(body));

    expect(deps.siteId).toBe(SITE_ID);
    expect(deps.invitationSecrets.generateToken).toHaveBeenNthCalledWith(1, COMMAND_ID);
    expect(deps.invitationSecrets.generateToken).toHaveBeenNthCalledWith(2, COMMAND_ID);
    expect(deps.invitationSecrets.hashToken).toHaveBeenNthCalledWith(1, deterministicToken);
    expect(deps.invitationSecrets.hashToken).toHaveBeenNthCalledWith(2, deterministicToken);
    expect(vi.mocked(deps.persistence.createMemberInvitation).mock.calls[0]?.[0].tokenHash).toBe(TOKEN_HASH);
    expect(vi.mocked(deps.persistence.createMemberInvitation).mock.calls[1]?.[0].tokenHash).toBe(TOKEN_HASH);
    await expect(first.json()).resolves.toMatchObject({
      result: "applied",
      invitation: { id: RESOURCE_ID, token: deterministicToken },
      replayed: false,
    });
    await expect(retry.json()).resolves.toMatchObject({
      result: "applied",
      invitation: { id: RESOURCE_ID, token: deterministicToken },
      replayed: true,
    });
  });

  it("revokes an invitation after owner authorization and recent AAL2", async () => {
    const deps = dependencies();
    const response = await createMemberInvitationRevokeRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 1,
      reason: "Access is no longer required.",
    }), { invitationId: RESOURCE_ID });

    expect(response.status).toBe(200);
    expect(deps.authorizer.requireRecentAal2).toHaveBeenCalledOnce();
    expect(deps.persistence.revokeMemberInvitation).toHaveBeenCalledWith({
      siteId: SITE_ID,
      actorId: MEMBER_ID,
      invitationId: RESOURCE_ID,
      expectedVersion: 1,
      reason: "Access is no longer required.",
      idempotencyKey: COMMAND_ID,
      aal2VerifiedAt: AAL2_AT,
    });
  });

  it("accepts using only token hash, authenticated user ID, and canonical email digest", async () => {
    const deps = dependencies();
    const response = await createMemberInvitationAcceptRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      token: TOKEN,
    }));

    expect(response.status).toBe(200);
    expect(deps.authorizer.requireAuthenticatedUser).toHaveBeenCalledOnce();
    expect(deps.invitationSecrets.digestCanonicalEmail).toHaveBeenCalledWith("invitee@example.test");
    expect(deps.persistence.acceptMemberInvitation).toHaveBeenCalledWith({
      siteId: SITE_ID,
      authenticatedUserId: USER_ID,
      canonicalEmailDigest: EMAIL_DIGEST,
      tokenHash: TOKEN_HASH,
      idempotencyKey: COMMAND_ID,
    });
    const serialized = JSON.stringify(vi.mocked(deps.persistence.acceptMemberInvitation).mock.calls);
    expect(serialized).not.toContain("Invitee@Example.test");
    expect(serialized).not.toContain(TOKEN);
  });

  it("rejects cross-origin requests before authorization or persistence", async () => {
    const deps = dependencies();
    const response = await createCustomerExportRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
    }, { origin: "https://attacker.test", fetchSite: "cross-site" }));

    expect(response.status).toBe(403);
    await expect(response.json()).resolves.toMatchObject({ error: { code: "ORIGIN_REJECTED" } });
    expect(deps.authorizer.authorize).not.toHaveBeenCalled();
    expect(deps.persistence.requestCustomerExport).not.toHaveBeenCalled();
  });

  it("fails closed before persistence for stale entitlement, missing acceptance email, and AAL2 denial", async () => {
    const stale = dependencies();
    vi.mocked(stale.authorizer.authorize).mockResolvedValueOnce({
      siteId: SITE_ID,
      memberId: MEMBER_ID,
      role: "owner",
      scope: "site",
      entitlementVerification: "stale",
      entitlementMode: "operational_write",
    });
    expect((await createCustomerProfileUpdateRouteHandler(stale).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 1,
      patch: { displayName: "Ana" },
    }), { customerId: CUSTOMER_ID })).status).toBe(409);
    expect(stale.persistence.updateCustomerProfile).not.toHaveBeenCalled();

    const noEmail = dependencies();
    vi.mocked(noEmail.authorizer.requireAuthenticatedUser).mockResolvedValueOnce({
      siteId: SITE_ID,
      userId: USER_ID,
      email: null,
      entitlementVerification: "current",
      entitlementMode: "operational_write",
    });
    expect((await createMemberInvitationAcceptRouteHandler(noEmail).handle(request({
      idempotencyKey: COMMAND_ID,
      token: TOKEN,
    }))).status).toBe(401);
    expect(noEmail.persistence.acceptMemberInvitation).not.toHaveBeenCalled();

    const aal2 = dependencies();
    vi.mocked(aal2.authorizer.requireRecentAal2).mockRejectedValueOnce(
      new OperationalAuthorizationError("AAL2_REQUIRED"),
    );
    expect((await createMemberInvitationRouteHandler(aal2).handle(request({
      idempotencyKey: COMMAND_ID,
      email: "staff@example.test",
      template: "staff",
    }))).status).toBe(403);
    expect(aal2.persistence.createMemberInvitation).not.toHaveBeenCalled();
  });

  it("rejects unbounded export filters and client-owned trusted fields", async () => {
    const deps = dependencies();
    const tooManyCustomers = Array.from({ length: 101 }, () => CUSTOMER_ID);
    expect((await createCustomerExportRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      customerIds: tooManyCustomers,
    }))).status).toBe(400);

    expect((await createMemberInvitationRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      email: "staff@example.test",
      template: "staff",
      tokenHash: TOKEN_HASH,
    }))).status).toBe(400);

    expect((await createMemberInvitationAcceptRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      token: TOKEN,
      authenticatedUserId: USER_ID,
    }))).status).toBe(400);
    expect(deps.persistence.requestCustomerExport).not.toHaveBeenCalled();
    expect(deps.persistence.createMemberInvitation).not.toHaveBeenCalled();
    expect(deps.persistence.acceptMemberInvitation).not.toHaveBeenCalled();
  });
});
