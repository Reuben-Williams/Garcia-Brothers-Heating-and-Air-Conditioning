import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { createInMemoryAdapter, defineBuilderSite } from "@your-builder/core";
import {
  BuilderPreviewBridge,
  applyPageContentToDocument,
  BuilderProvider,
  EditableImage,
  EditableIcon,
  EditableLink,
  EditableNextImage,
  EditableText,
  createBuilderRouteHandlers,
  loadBuilderPageContent,
} from "@your-builder/next";

describe("Next integration editable components", () => {
  it("renders fallback content for public visitors when no published content exists", () => {
    const html = renderToStaticMarkup(
      <BuilderProvider siteId="demo-site" mode="public" content={{ path: "/", regions: {} }}>
        <EditableText id="home.hero.title" fallback="Fallback headline" />
        <EditableImage id="home.hero.image" fallback="/images/hero.jpg" alt="Hero" />
        <EditableLink id="home.cta" fallbackHref="/contact" fallbackLabel="Contact us" />
      </BuilderProvider>,
    );

    expect(html).toContain("Fallback headline");
    expect(html).toContain('src="/images/hero.jpg"');
    expect(html).toContain('href="/contact"');
  });

  it("adds stable editable metadata only in editor mode", () => {
    const html = renderToStaticMarkup(
      <BuilderProvider
        siteId="demo-site"
        mode="editor"
        content={{
          path: "/",
          regions: {
            "home.hero.title": { type: "text", value: "Edited headline" },
          },
        }}
      >
        <EditableText id="home.hero.title" fallback="Fallback headline" />
      </BuilderProvider>,
    );

    expect(html).toContain("Edited headline");
    expect(html).toContain('data-builder-region="home.hero.title"');
    expect(html).toContain('data-builder-kind="text"');
  });

  it("provides a preview bridge component for editor iframe click and navigation messages", () => {
    const html = renderToStaticMarkup(<BuilderPreviewBridge siteId="demo-site" />);

    expect(html).toContain("data-builder-preview-bridge");
    expect(html).toContain('data-builder-site-id="demo-site"');
    expect(BuilderPreviewBridge.toString()).toContain("createBuilderPreviewMessage");
    expect(BuilderPreviewBridge.toString()).toContain('type: "builder:ready"');
  });

  it("renders stable metadata for responsive Next image render props", () => {
    const html = renderToStaticMarkup(
      <BuilderProvider
        siteId="demo-site"
        mode="editor"
        content={{
          path: "/",
          regions: {
            "home.hero.image": { type: "image", src: "/images/edited.jpg", alt: "Edited hero" },
          },
        }}
      >
        <EditableNextImage id="home.hero.image" fallback="/images/hero.jpg" alt="Hero">
          {(image) => <img src={image.src} alt={image.alt} width={1200} height={800} {...image.editorProps} />}
        </EditableNextImage>
      </BuilderProvider>,
    );

    expect(html).toContain('src="/images/edited.jpg"');
    expect(html).toContain('alt="Edited hero"');
    expect(html).toContain('data-builder-region="home.hero.image"');
    expect(html).toContain('data-builder-kind="image"');
  });

  it("renders editable icons with stable metadata and fallback-safe values", () => {
    const html = renderToStaticMarkup(
      <BuilderProvider
        siteId="demo-site"
        mode="editor"
        content={{
          path: "/",
          regions: {
            "home.services.card.icon": { type: "icon", icon: "mail", label: "Email" },
          },
        }}
      >
        <EditableIcon id="home.services.card.icon" fallback="work" label="Service icon" />
      </BuilderProvider>,
    );

    expect(html).toContain("mail");
    expect(html).toContain('aria-label="Email"');
    expect(html).toContain('class="material-symbols-outlined"');
    expect(html).toContain('data-builder-region="home.services.card.icon"');
    expect(html).toContain('data-builder-kind="icon"');
  });

  it("preview bridge source selects the deepest editable region before parent links", () => {
    const source = BuilderPreviewBridge.toString();
    expect(source).toContain("data-builder-entry-id");
    expect(source).toContain('type: "builder:select-entry"');
    expect(source).toContain("const deepestRegion = matches.at(-1)");
    expect(source).toContain("if (deepestRegion)");
    expect(source).toContain("readRegionSelection");
    expect(source).toContain("event.shiftKey");
    expect(source).toContain('selectionMode: event.shiftKey ? "toggle" : "replace"');
    expect(source).toContain("data-builder-selected");
    expect(source).toContain("window.getSelection()?.removeAllRanges()");
    expect(source).toContain('type: "builder:clear-selection"');
  });

  it("applies stored text, rich text, links, and images to an annotated legacy page", () => {
    document.body.innerHTML = `
      <h1 data-builder-region="hero.title" data-builder-kind="text">Fallback</h1>
      <p data-builder-region="hero.body" data-builder-kind="richText">Fallback body</p>
      <a data-builder-region="hero.cta" data-builder-kind="link" href="/old">Old</a>
      <img data-builder-region="hero.image" data-builder-kind="image" src="/old.jpg" alt="Old alt" />
    `;
    applyPageContentToDocument(document, {
      path: "/",
      regions: {
        "hero.title": { type: "text", value: "Updated" },
        "hero.body": { type: "richText", value: "Updated body" },
        "hero.cta": { type: "link", label: "Book service", href: "/contact" },
        "hero.image": { type: "image", src: "/projects/project-01.png", alt: "Condenser" },
      },
    });
    expect(document.querySelector("h1")?.textContent).toBe("Updated");
    expect(document.querySelector("p")?.textContent).toBe("Updated body");
    expect(document.querySelector("a")?.getAttribute("href")).toBe("/contact");
    expect(document.querySelector("img")?.getAttribute("src")).toBe("/projects/project-01.png");
  });

  it("applies target-aware presentation fields and approved section ordering", () => {
    document.body.innerHTML = `
      <input data-builder-region="forms.contact.message.placeholder" data-builder-kind="text" data-builder-target="placeholder" placeholder="Old" />
      <div data-builder-region="collections.services" data-builder-kind="sections">
        <article data-builder-item-id="heating">Heating
          <div data-builder-region="collections.services.heating.features" data-builder-kind="sections">
            <span data-builder-item-id="diagnostics">Diagnostics</span>
          </div>
        </article>
        <article data-builder-item-id="cooling">Cooling</article>
        <article data-builder-item-id="air-quality">Air quality</article>
      </div>
    `;

    applyPageContentToDocument(document, {
      path: "/contact",
      regions: {
        "forms.contact.message.placeholder": { type: "text", value: "Describe the problem" },
        "collections.services": { type: "sections", value: ["cooling", "heating"] },
      },
    });

    expect(document.querySelector("input")?.getAttribute("placeholder")).toBe("Describe the problem");
    expect(Array.from(document.querySelectorAll("article")).map((item) => [item.dataset.builderItemId, item.hidden])).toEqual([
      ["cooling", false],
      ["heating", false],
      ["air-quality", true],
    ]);
    expect(document.querySelector('[data-builder-item-id="diagnostics"]')?.parentElement?.dataset.builderRegion).toBe("collections.services.heating.features");
  });

  it("updates an icon link through its explicit label target without removing the icon", () => {
    document.body.innerHTML = `
      <a data-builder-region="global.business.phone" data-builder-kind="link" href="tel:+15550000000">
        <svg data-icon="phone"></svg>
        <span data-builder-link-label>Old phone</span>
      </a>
    `;

    applyPageContentToDocument(document, {
      path: "/",
      regions: {
        "global.business.phone": { type: "link", label: "(551) 379-0300", href: "tel:+15513790300" },
      },
    });

    expect(document.querySelector("svg")).not.toBeNull();
    expect(document.querySelector("[data-builder-link-label]")?.textContent).toBe("(551) 379-0300");
    expect(document.querySelector("a")?.getAttribute("href")).toBe("tel:+15513790300");
  });

  it("loads draft or published content with fallback protection", async () => {
    const adapter = createInMemoryAdapter();
    await adapter.saveDraft({
      siteId: "demo-site",
      pagePath: "/",
      regionId: "home.hero.title",
      value: { type: "text", value: "Draft title" },
      userId: "owner-1",
    });

    const draft = await loadBuilderPageContent({
      adapter,
      siteId: "demo-site",
      pagePath: "/",
      mode: "draft",
      fallback: { path: "/", regions: { "home.hero.title": { type: "text", value: "Fallback title" } } },
    });

    expect(draft.regions["home.hero.title"]).toEqual({ type: "text", value: "Draft title" });
  });

  it("exposes content, audit, and media route handlers for editor clients", async () => {
    const adapter = createInMemoryAdapter();
    const site = defineBuilderSite({
      siteId: "demo-site",
      adapter: "memory",
      editor: { path: "/admin/editor", protected: true },
      pages: [{ path: "/", label: "Home", regions: [{ id: "home.hero.title", kind: "text" }] }],
      sections: {},
    });
    const handlers = createBuilderRouteHandlers({ site, adapter, getUserId: () => "owner-1" });

    await handlers.POST(
      new Request("https://client.example/api/builder", {
        method: "POST",
        body: JSON.stringify({
          pagePath: "/",
          regionId: "home.hero.title",
          value: { type: "text", value: "Edited title" },
        }),
      }),
    );

    const auditResponse = await handlers.GET(new Request("https://client.example/api/builder?resource=audit&path=/"));
    const audit = await auditResponse.json();

    expect(audit).toEqual([
      expect.objectContaining({
        action: "draft.saved",
        regionId: "home.hero.title",
        after: { type: "text", value: "Edited title" },
      }),
    ]);

    const mediaResponse = await handlers.POST(
      new Request("https://client.example/api/builder?resource=media", {
        method: "POST",
        body: JSON.stringify({
          path: "campaign/upload.jpg",
          url: "https://cdn.example/upload.jpg",
          alt: "Uploaded image",
          label: "Upload",
          mimeType: "image/jpeg",
        }),
      }),
    );

    expect(await mediaResponse.json()).toEqual(expect.objectContaining({ url: "https://cdn.example/upload.jpg" }));
  });

  it("stores global edits canonically and merges them into every page response", async () => {
    const adapter = createInMemoryAdapter();
    const site = defineBuilderSite({
      siteId: "demo-site",
      adapter: "memory",
      globalRegions: [{ id: "global.business.phone", kind: "link" }],
      pages: [
        { path: "/", label: "Home", regions: [] },
        { path: "/about", label: "About", regions: [] },
      ],
      sections: {},
    });
    const handlers = createBuilderRouteHandlers({ site, adapter, getUserId: () => "owner-1" });

    await handlers.POST(new Request("https://client.example/api/builder", {
      method: "POST",
      body: JSON.stringify({
        pagePath: "/about",
        regionId: "global.business.phone",
        value: { type: "link", label: "Call us", href: "tel:+15551234567" },
      }),
    }));
    await handlers.PUT(new Request("https://client.example/api/builder", {
      method: "PUT",
      body: JSON.stringify({ pagePath: "/about" }),
    }));

    const response = await handlers.GET(new Request("https://client.example/api/builder?path=/&mode=published"));
    await expect(response.json()).resolves.toMatchObject({
      path: "/",
      regions: { "global.business.phone": { type: "link", label: "Call us", href: "tel:+15551234567" } },
    });
  });
});
