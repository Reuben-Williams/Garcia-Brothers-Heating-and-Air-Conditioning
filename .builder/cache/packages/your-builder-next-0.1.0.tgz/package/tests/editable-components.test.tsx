import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { createInMemoryAdapter, defineBuilderSite } from "@your-builder/core";
import {
  BuilderPreviewBridge,
  BuilderProvider,
  EditableImage,
  EditableIcon,
  EditableLink,
  EditableNextImage,
  EditableText,
  createBuilderRouteHandlers,
  loadBuilderPageContent,
} from "@your-builder/next";

describe("Next integration editable components", () => {
  it("renders fallback content for public visitors when no published content exists", () => {
    const html = renderToStaticMarkup(
      <BuilderProvider siteId="demo-site" mode="public" content={{ path: "/", regions: {} }}>
        <EditableText id="home.hero.title" fallback="Fallback headline" />
        <EditableImage id="home.hero.image" fallback="/images/hero.jpg" alt="Hero" />
        <EditableLink id="home.cta" fallbackHref="/contact" fallbackLabel="Contact us" />
      </BuilderProvider>,
    );

    expect(html).toContain("Fallback headline");
    expect(html).toContain('src="/images/hero.jpg"');
    expect(html).toContain('href="/contact"');
  });

  it("adds stable editable metadata only in editor mode", () => {
    const html = renderToStaticMarkup(
      <BuilderProvider
        siteId="demo-site"
        mode="editor"
        content={{
          path: "/",
          regions: {
            "home.hero.title": { type: "text", value: "Edited headline" },
          },
        }}
      >
        <EditableText id="home.hero.title" fallback="Fallback headline" />
      </BuilderProvider>,
    );

    expect(html).toContain("Edited headline");
    expect(html).toContain('data-builder-region="home.hero.title"');
    expect(html).toContain('data-builder-kind="text"');
  });

  it("provides a preview bridge component for editor iframe click and navigation messages", () => {
    const html = renderToStaticMarkup(<BuilderPreviewBridge siteId="demo-site" />);

    expect(html).toContain("data-builder-preview-bridge");
    expect(html).toContain('data-builder-site-id="demo-site"');
    expect(BuilderPreviewBridge.toString()).toContain("createBuilderPreviewMessage");
    expect(BuilderPreviewBridge.toString()).toContain('type: "builder:ready"');
  });

  it("renders stable metadata for responsive Next image render props", () => {
    const html = renderToStaticMarkup(
      <BuilderProvider
        siteId="demo-site"
        mode="editor"
        content={{
          path: "/",
          regions: {
            "home.hero.image": { type: "image", src: "/images/edited.jpg", alt: "Edited hero" },
          },
        }}
      >
        <EditableNextImage id="home.hero.image" fallback="/images/hero.jpg" alt="Hero">
          {(image) => <img src={image.src} alt={image.alt} width={1200} height={800} {...image.editorProps} />}
        </EditableNextImage>
      </BuilderProvider>,
    );

    expect(html).toContain('src="/images/edited.jpg"');
    expect(html).toContain('alt="Edited hero"');
    expect(html).toContain('data-builder-region="home.hero.image"');
    expect(html).toContain('data-builder-kind="image"');
  });

  it("renders editable icons with stable metadata and fallback-safe values", () => {
    const html = renderToStaticMarkup(
      <BuilderProvider
        siteId="demo-site"
        mode="editor"
        content={{
          path: "/",
          regions: {
            "home.services.card.icon": { type: "icon", icon: "mail", label: "Email" },
          },
        }}
      >
        <EditableIcon id="home.services.card.icon" fallback="work" label="Service icon" />
      </BuilderProvider>,
    );

    expect(html).toContain("mail");
    expect(html).toContain('aria-label="Email"');
    expect(html).toContain('class="material-symbols-outlined"');
    expect(html).toContain('data-builder-region="home.services.card.icon"');
    expect(html).toContain('data-builder-kind="icon"');
  });

  it("preview bridge source selects the deepest editable region before parent links", () => {
    expect(BuilderPreviewBridge.toString()).toContain("data-builder-entry-id");
    expect(BuilderPreviewBridge.toString()).toContain('type: "builder:select-entry"');
    expect(BuilderPreviewBridge.toString()).toContain("const deepestRegion = matches.at(-1)");
    expect(BuilderPreviewBridge.toString()).toContain("if (deepestRegion)");
  });

  it("loads draft or published content with fallback protection", async () => {
    const adapter = createInMemoryAdapter();
    await adapter.saveDraft({
      siteId: "demo-site",
      pagePath: "/",
      regionId: "home.hero.title",
      value: { type: "text", value: "Draft title" },
      userId: "owner-1",
    });

    const draft = await loadBuilderPageContent({
      adapter,
      siteId: "demo-site",
      pagePath: "/",
      mode: "draft",
      fallback: { path: "/", regions: { "home.hero.title": { type: "text", value: "Fallback title" } } },
    });

    expect(draft.regions["home.hero.title"]).toEqual({ type: "text", value: "Draft title" });
  });

  it("exposes content, audit, and media route handlers for editor clients", async () => {
    const adapter = createInMemoryAdapter();
    const site = defineBuilderSite({
      siteId: "demo-site",
      adapter: "memory",
      editor: { path: "/admin/editor", protected: true },
      pages: [{ path: "/", label: "Home", regions: [{ id: "home.hero.title", kind: "text" }] }],
      sections: {},
    });
    const handlers = createBuilderRouteHandlers({ site, adapter, getUserId: () => "owner-1" });

    await handlers.POST(
      new Request("https://client.example/api/builder", {
        method: "POST",
        body: JSON.stringify({
          pagePath: "/",
          regionId: "home.hero.title",
          value: { type: "text", value: "Edited title" },
        }),
      }),
    );

    const auditResponse = await handlers.GET(new Request("https://client.example/api/builder?resource=audit&path=/"));
    const audit = await auditResponse.json();

    expect(audit).toEqual([
      expect.objectContaining({
        action: "draft.saved",
        regionId: "home.hero.title",
        after: { type: "text", value: "Edited title" },
      }),
    ]);

    const mediaResponse = await handlers.POST(
      new Request("https://client.example/api/builder?resource=media", {
        method: "POST",
        body: JSON.stringify({
          path: "campaign/upload.jpg",
          url: "https://cdn.example/upload.jpg",
          alt: "Uploaded image",
          label: "Upload",
          mimeType: "image/jpeg",
        }),
      }),
    );

    expect(await mediaResponse.json()).toEqual(expect.objectContaining({ url: "https://cdn.example/upload.jpg" }));
  });
});
