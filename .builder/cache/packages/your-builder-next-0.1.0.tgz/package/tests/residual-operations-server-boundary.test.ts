// @vitest-environment node

import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { describe, expect, it } from "vitest";

describe("residual operation server boundary", () => {
  it("poisons residual RPC adapters imported from a client module", async () => {
    await expect(import("./fixtures/residual-operations-server-client-entry.js")).rejects.toThrow(
      "This module cannot be imported from a Client Component module",
    );
  });

  it("keeps residual contracts browser-safe and persistence server-only", async () => {
    const browserEntry = await readFile(resolve("packages/next/src/operations/index.ts"), "utf8");
    const serverEntry = await readFile(resolve("packages/next/src/operations/server/index.ts"), "utf8");

    expect(browserEntry).toContain('./residual-contracts.js');
    expect(browserEntry).not.toContain("server-only");
    expect(serverEntry.startsWith('import "server-only";')).toBe(true);
    expect(serverEntry).toContain("residual-supabase-operations.js");
    expect(serverEntry).toContain("residual-route-handlers.js");
  });
});
