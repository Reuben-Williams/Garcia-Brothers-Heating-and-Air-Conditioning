import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import * as controlPlane from "../src/control-plane/index.js";

describe("direct scheduled invocation", () => {
  it("awaits the runtime directly in-process", async () => {
    const run = (controlPlane as Record<string, unknown>).runScheduledInvocation as
      | ((runtime: { runScheduled(): Promise<unknown> }, options: { timeoutSeconds: number }) => Promise<unknown>)
      | undefined;
    const result = { pulled: 0, acknowledged: 0, healthReported: true };
    const runtime = { runScheduled: vi.fn(async () => result) };

    expect(run).toBeTypeOf("function");
    await expect(run?.(runtime, { timeoutSeconds: 90 })).resolves.toEqual(result);
    expect(runtime.runScheduled).toHaveBeenCalledOnce();
  });

  it("fails with a bounded timeout code", async () => {
    vi.useFakeTimers();
    const run = (controlPlane as Record<string, unknown>).runScheduledInvocation as
      | ((runtime: {
          runScheduled(options?: { signal?: AbortSignal }): Promise<unknown>;
        }, options: { timeoutSeconds: number }) => Promise<unknown>)
      | undefined;
    let receivedSignal: AbortSignal | undefined;
    const runtime = {
      runScheduled: vi.fn((options?: { signal?: AbortSignal }) => {
        receivedSignal = options?.signal;
        return new Promise(() => undefined);
      }),
    };

    expect(run).toBeTypeOf("function");
    const pending = run?.(runtime, { timeoutSeconds: 1 });
    const rejection = expect(pending).rejects.toMatchObject({
      code: "site_installation_invocation_timeout",
    });
    await vi.advanceTimersByTimeAsync(1_000);
    await rejection;
    expect(receivedSignal?.aborted).toBe(true);
    vi.useRealTimers();
  });

  it("contains no HTTP trigger or shared-secret transport", async () => {
    const source = await readFile(
      resolve("packages/next/src/control-plane/scheduled-invocation.ts"),
      "utf8",
    ).catch(() => "");

    expect(source).not.toBe("");
    expect(source).not.toMatch(/\bfetch\b|http route|trigger secret|replay nonce/i);
  });
});
