import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import * as controlPlane from "../src/control-plane/index.js";

const SITE_ID = "10000000-0000-4000-8000-000000000001";
const INSTALLATION_ID = "20000000-0000-4000-8000-000000000001";
const MIXED_CASE_SITE_ID = "ABCDEFAB-CDEF-4ABC-8DEF-ABCDEFABCDEF";

describe("site data-plane identity", () => {
  it("brands an exact local UUID and rejects the central installation UUID", () => {
    const parse = (controlPlane as Record<string, unknown>).parseSiteDataPlaneSiteUuid as
      | ((value: unknown, options?: { centralInstallationId?: string }) => string)
      | undefined;

    expect(parse).toBeTypeOf("function");
    expect(parse?.(SITE_ID, { centralInstallationId: INSTALLATION_ID })).toBe(SITE_ID);
    expect(() => parse?.(INSTALLATION_ID, { centralInstallationId: INSTALLATION_ID }))
      .toThrow("site_data_plane_identity_mismatch");
    expect(() => parse?.("not-a-uuid")).toThrow("site_data_plane_identity_mismatch");
    expect(parse?.(MIXED_CASE_SITE_ID)).toBe(MIXED_CASE_SITE_ID.toLowerCase());
  });

  it("requires the exact reviewed lower-kebab site key", () => {
    const parse = (controlPlane as Record<string, unknown>).parseExpectedSiteKey as
      | ((value: unknown) => string)
      | undefined;

    expect(parse).toBeTypeOf("function");
    expect(parse?.("reviewed-site-1")).toBe("reviewed-site-1");
    expect(() => parse?.("Reviewed Site")).toThrow("site_data_plane_identity_mismatch");
    expect(() => parse?.(`a${"b".repeat(128)}`)).toThrow("site_data_plane_identity_mismatch");
  });

  it("loads only the exact identity envelope from the server-only RPC", async () => {
    const rpc = vi.fn(async () => ({
      data: { version: 1, siteId: SITE_ID, siteKey: "reviewed-site" },
      error: null,
    }));
    const createStore = (controlPlane as Record<string, unknown>)
      .createSupabaseSiteDataPlaneIdentityStore as
      | ((client: { rpc: typeof rpc }) => { getSiteIdentity(siteId: string): Promise<unknown> })
      | undefined;

    expect(createStore).toBeTypeOf("function");
    await expect(createStore?.({ rpc }).getSiteIdentity(SITE_ID)).resolves.toEqual({
      siteId: SITE_ID,
      siteKey: "reviewed-site",
    });
    expect(rpc).toHaveBeenCalledWith("builder_get_runtime_site_identity", {
      p_site_id: SITE_ID,
    });
  });

  it("normalizes UUID casing returned by the identity RPC", async () => {
    const rpc = vi.fn(async () => ({
      data: { version: 1, siteId: MIXED_CASE_SITE_ID, siteKey: "reviewed-site" },
      error: null,
    }));
    const createStore = (controlPlane as Record<string, unknown>)
      .createSupabaseSiteDataPlaneIdentityStore as
      | ((client: { rpc: typeof rpc }) => {
          getSiteIdentity(siteId: string): Promise<{ siteId: string; siteKey: string }>;
        })
      | undefined;
    const store = createStore?.({ rpc });

    await expect(store?.getSiteIdentity(MIXED_CASE_SITE_ID)).resolves.toEqual({
      siteId: MIXED_CASE_SITE_ID.toLowerCase(),
      siteKey: "reviewed-site",
    });
    expect(rpc).toHaveBeenCalledWith("builder_get_runtime_site_identity", {
      p_site_id: MIXED_CASE_SITE_ID.toLowerCase(),
    });
  });

  it.each([
    ["missing row", null],
    ["unknown field", { version: 1, siteId: SITE_ID, siteKey: "reviewed-site", name: "no" }],
    ["wrong version", { version: 2, siteId: SITE_ID, siteKey: "reviewed-site" }],
    ["invalid UUID", { version: 1, siteId: "bad", siteKey: "reviewed-site" }],
    ["invalid key", { version: 1, siteId: SITE_ID, siteKey: "Reviewed Site" }],
  ])("fails closed for %s", async (_label, data) => {
    const createStore = (controlPlane as Record<string, unknown>)
      .createSupabaseSiteDataPlaneIdentityStore as
      | ((client: { rpc: (name: string, args: Record<string, unknown>) => Promise<unknown> }) => {
          getSiteIdentity(siteId: string): Promise<unknown>;
        })
      | undefined;
    const store = createStore?.({ rpc: async () => ({ data, error: null }) });

    expect(createStore).toBeTypeOf("function");
    await expect(store?.getSiteIdentity(SITE_ID)).rejects.toMatchObject({
      code: "site_data_plane_identity_mismatch",
    });
  });
});
