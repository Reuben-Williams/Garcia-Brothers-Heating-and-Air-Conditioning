// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  OperationalAuthorizationError,
  createBulkLeadOperationRouteHandler,
  createCustomerPreferenceClearRouteHandler,
  createCustomerPreferenceSetRouteHandler,
  createCustomerSuppressionSetRouteHandler,
  createLeadsExportRouteHandler,
  createRecordTagRouteHandler,
  createSavedViewRemoveRouteHandler,
  createSavedViewSaveRouteHandler,
  type ResidualOperationalRouteDependencies,
} from "../src/operations/server/index.js";
import type {
  OperationalMutationResult,
  OperationalResourceType,
  ResidualBulkLeadRecord,
} from "../src/operations/index.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const MEMBER_ID = "22222222-2222-4222-8222-222222222222";
const RESOURCE_ID = "33333333-3333-4333-8333-333333333333";
const CUSTOMER_ID = "44444444-4444-4444-8444-444444444444";
const TAG_ID = "55555555-5555-4555-8555-555555555555";
const COMMAND_ID = "66666666-6666-4666-8666-666666666666";
const AAL2_AT = "2026-07-18T12:00:00.000Z";

function applied(resourceType: OperationalResourceType, resourceId = RESOURCE_ID): OperationalMutationResult {
  return { status: "applied", resourceType, resourceId, version: 2, replayed: false };
}

function dependencies(): ResidualOperationalRouteDependencies {
  return {
    siteId: SITE_ID,
    authorizer: {
      authorize: vi.fn(async (_request, requirement) => ({
        siteId: SITE_ID,
        memberId: MEMBER_ID,
        role: "owner" as const,
        scope: requirement.allowedScopes[0]!,
        entitlementVerification: "current" as const,
        entitlementMode: requirement.entitlementMode,
      })),
      requireRecentAal2: vi.fn(async () => ({ verifiedAt: AAL2_AT })),
      requireAuthenticatedUser: vi.fn(),
    },
    persistence: {
      bulkApplyLeads: vi.fn(async ({ records }) => ({
        requestedCount: records.length,
        results: records.map((record: ResidualBulkLeadRecord, index: number) => index === 0
          ? { leadId: record.leadId, status: "applied" as const, version: record.expectedVersion + 1 }
          : { leadId: record.leadId, status: "denied" as const, reason: "not_authorized" as const }),
      })),
      saveView: vi.fn(async () => applied("saved_view")),
      removeSavedView: vi.fn(async () => applied("saved_view")),
      setCustomerPreference: vi.fn(async () => applied("customer_preference", CUSTOMER_ID)),
      clearCustomerPreference: vi.fn(async () => applied("customer_preference", CUSTOMER_ID)),
      setCustomerSuppression: vi.fn(async () => applied("customer_suppression")),
      setRecordTag: vi.fn(async () => applied("record_tag")),
      requestLeadsExport: vi.fn(async () => applied("data_export")),
    },
  };
}

function request(body: Record<string, unknown>, origin = "https://site.test"): Request {
  return new Request("https://site.test/api/builder/operations/residual", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      origin,
      "sec-fetch-site": origin === "https://site.test" ? "same-origin" : "cross-site",
      "x-idempotency-key": String(body.idempotencyKey ?? ""),
    },
    body: JSON.stringify(body),
  });
}

describe("residual operational route handlers", () => {
  it("binds trusted site and actor and returns every mixed bulk record", async () => {
    const deps = dependencies();
    const secondLeadId = "77777777-7777-4777-8777-777777777777";
    const records = [
      { leadId: RESOURCE_ID, expectedVersion: 1 },
      { leadId: secondLeadId, expectedVersion: 2 },
    ];
    const response = await createBulkLeadOperationRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      action: "status",
      records,
      status: "contacted",
    }));

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "leads.update",
      allowedScopes: ["site", "assigned"],
      entitlementMode: "operational_write",
    });
    expect(deps.persistence.bulkApplyLeads).toHaveBeenCalledWith({
      siteId: SITE_ID,
      actor: { type: "member", id: MEMBER_ID },
      idempotencyKey: COMMAND_ID,
      action: "status",
      records,
      status: "contacted",
    });
    await expect(response.json()).resolves.toEqual({
      result: "completed",
      requestedCount: 2,
      results: [
        { leadId: RESOURCE_ID, status: "applied", version: 2 },
        { leadId: secondLeadId, status: "denied", reason: "not_authorized" },
      ],
    });
  });

  it("requires site-scoped assignment capability for bulk assignment", async () => {
    const deps = dependencies();
    await createBulkLeadOperationRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      action: "assignment",
      records: [{ leadId: RESOURCE_ID, expectedVersion: 1 }],
      assigneeId: MEMBER_ID,
    }));

    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "leads.assign",
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
    });
  });

  it("authorizes private saved views by domain read and shared views by site update plus AAL2", async () => {
    const privateDeps = dependencies();
    const filter = { version: 1, conjunction: "all", clauses: [{ field: "status", operator: "equals", value: "new" }] };
    await createSavedViewSaveRouteHandler(privateDeps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 0,
      viewId: RESOURCE_ID,
      domain: "leads",
      name: "My new leads",
      shared: false,
      filter,
    }));
    expect(privateDeps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "leads.read",
      allowedScopes: ["site", "assigned"],
      entitlementMode: "operational_write",
    });
    expect(privateDeps.authorizer.requireRecentAal2).not.toHaveBeenCalled();

    const sharedDeps = dependencies();
    await createSavedViewSaveRouteHandler(sharedDeps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 1,
      viewId: RESOURCE_ID,
      domain: "customers",
      name: "Shared Newark customers",
      shared: true,
      filter: { version: 1, conjunction: "all", clauses: [{ field: "service_area_zip", operator: "equals", value: "07105" }] },
    }));
    expect(sharedDeps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "customers.update",
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
      resource: { type: "saved_view", id: RESOURCE_ID },
    });
    expect(sharedDeps.authorizer.requireRecentAal2).toHaveBeenCalledOnce();
    expect(sharedDeps.persistence.saveView).toHaveBeenCalledWith(expect.objectContaining({
      siteId: SITE_ID,
      actor: { type: "member", id: MEMBER_ID },
      aal2VerifiedAt: AAL2_AT,
    }));
  });

  it("accepts the derived lead filters exposed by the reusable workspace", async () => {
    const deps = dependencies();
    const response = await createSavedViewSaveRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 0,
      viewId: RESOURCE_ID,
      domain: "leads",
      name: "Estimate follow-up",
      shared: false,
      filter: {
        version: 1,
        conjunction: "all",
        clauses: [
          { field: "unassigned", operator: "equals", value: true },
          { field: "estimate_scheduled", operator: "equals", value: true },
        ],
      },
    }));

    expect(response.status).toBe(200);
    expect(deps.persistence.saveView).toHaveBeenCalledWith(expect.objectContaining({
      filter: expect.objectContaining({
        clauses: expect.arrayContaining([
          expect.objectContaining({ field: "unassigned" }),
          expect.objectContaining({ field: "estimate_scheduled" }),
        ]),
      }),
    }));
  });

  it("removes a shared saved view with domain update scope and recent AAL2", async () => {
    const deps = dependencies();
    await createSavedViewRemoveRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 2,
      domain: "leads",
      shared: true,
    }), { viewId: RESOURCE_ID });

    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "leads.update",
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
      resource: { type: "saved_view", id: RESOURCE_ID },
    });
    expect(deps.authorizer.requireRecentAal2).toHaveBeenCalledOnce();
  });

  it("requires AAL2 for existing-view mutations even when request visibility is private", async () => {
    const updateDeps = dependencies();
    await createSavedViewSaveRouteHandler(updateDeps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 1,
      viewId: RESOURCE_ID,
      domain: "leads",
      name: "Private view",
      shared: false,
      filter: { version: 1, conjunction: "all", clauses: [] },
    }));
    expect(updateDeps.authorizer.requireRecentAal2).toHaveBeenCalledOnce();

    const removeDeps = dependencies();
    await createSavedViewRemoveRouteHandler(removeDeps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 1,
      domain: "leads",
      shared: false,
    }), { viewId: RESOURCE_ID });
    expect(removeDeps.authorizer.requireRecentAal2).toHaveBeenCalledOnce();
  });

  it("maps customer settings and record tags to their exact parent authorization", async () => {
    const preferenceDeps = dependencies();
    await createCustomerPreferenceSetRouteHandler(preferenceDeps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 1,
      key: "appointment_window",
      value: { period: "morning" },
    }), { customerId: CUSTOMER_ID });
    expect(preferenceDeps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "customers.update",
      allowedScopes: ["site", "assigned"],
      entitlementMode: "operational_write",
      resource: { type: "customer", id: CUSTOMER_ID },
    });

    const clearDeps = dependencies();
    await createCustomerPreferenceClearRouteHandler(clearDeps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 2,
      key: "appointment_window",
    }), { customerId: CUSTOMER_ID });
    expect(clearDeps.persistence.clearCustomerPreference).toHaveBeenCalledWith(expect.objectContaining({
      customerId: CUSTOMER_ID,
      key: "appointment_window",
      expectedVersion: 2,
    }));

    const suppressionDeps = dependencies();
    await createCustomerSuppressionSetRouteHandler(suppressionDeps).handle(request({
      idempotencyKey: COMMAND_ID,
      suppressionId: RESOURCE_ID,
      channel: "email",
      reason: "manual",
      active: true,
    }), { customerId: CUSTOMER_ID });
    expect(suppressionDeps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "customers.update",
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
      resource: { type: "customer", id: CUSTOMER_ID },
    });
    expect(suppressionDeps.persistence.setCustomerSuppression).toHaveBeenCalledWith(expect.objectContaining({
      suppressionId: RESOURCE_ID,
      active: true,
    }));

    const tagDeps = dependencies();
    await createRecordTagRouteHandler(tagDeps).handle(request({
      idempotencyKey: COMMAND_ID,
      tagId: TAG_ID,
      action: "remove",
    }), { recordType: "lead", recordId: RESOURCE_ID });
    expect(tagDeps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "leads.update",
      allowedScopes: ["site", "assigned"],
      entitlementMode: "operational_write",
      resource: { type: "lead", id: RESOURCE_ID },
    });
  });

  it("requires site-scoped leads export and recent AAL2", async () => {
    const deps = dependencies();
    await createLeadsExportRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      filter: {
        search: " boiler repair ",
        statuses: ["new"],
        assigneeIds: [MEMBER_ID],
        sources: ["phone"],
        unassigned: false,
      },
    }));

    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "leads.export",
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
    });
    expect(deps.authorizer.requireRecentAal2).toHaveBeenCalledOnce();
    expect(deps.persistence.requestLeadsExport).toHaveBeenCalledWith({
      siteId: SITE_ID,
      actor: { type: "member", id: MEMBER_ID },
      idempotencyKey: COMMAND_ID,
      filter: {
        search: "boiler repair",
        statuses: ["new"],
        assigneeIds: [MEMBER_ID],
        sources: ["phone"],
        unassigned: false,
      },
      aal2VerifiedAt: AAL2_AT,
    });
  });

  it("rejects unbounded, unknown, cross-origin, and client-owned trusted input before persistence", async () => {
    const deps = dependencies();
    const tooManyRecords = Array.from({ length: 101 }, (_, index) => ({
      leadId: `${String(index).padStart(8, "0")}-1111-4111-8111-111111111111`,
      expectedVersion: 1,
    }));
    expect((await createBulkLeadOperationRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      action: "status",
      records: tooManyRecords,
      status: "won",
    }))).status).toBe(400);

    expect((await createBulkLeadOperationRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      action: "status",
      records: [{ leadId: "77777777-7777-7777-8777-777777777777", expectedVersion: 1 }],
      status: "won",
    }))).status).toBe(400);

    expect((await createSavedViewSaveRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 0,
      domain: "leads",
      name: "Invalid",
      shared: false,
      filter: { version: 1, conjunction: "all", clauses: Array.from({ length: 21 }, () => ({ field: "status", operator: "equals", value: "new" })) },
    }))).status).toBe(400);

    expect((await createSavedViewSaveRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 0,
      viewId: RESOURCE_ID,
      domain: "leads",
      name: "Invalid tag filter",
      shared: false,
      filter: { version: 1, conjunction: "all", clauses: [{ field: "tag_id", operator: "equals", value: TAG_ID }] },
    }))).status).toBe(400);

    expect((await createSavedViewSaveRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 0,
      viewId: RESOURCE_ID,
      domain: "leads",
      name: "Invalid object filter",
      shared: false,
      filter: { version: 1, conjunction: "all", clauses: [{ field: "status", operator: "equals", value: { status: "new" } }] },
    }))).status).toBe(400);

    expect((await createLeadsExportRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      filter: { search: "x".repeat(201) },
    }))).status).toBe(400);

    expect((await createCustomerPreferenceSetRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 0,
      key: "appointment_window",
      value: "morning",
      siteId: SITE_ID,
    }), { customerId: CUSTOMER_ID })).status).toBe(400);

    expect((await createRecordTagRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      tagId: TAG_ID,
      action: "add",
    }, "https://attacker.test"), { recordType: "lead", recordId: RESOURCE_ID })).status).toBe(403);
    expect(deps.persistence.bulkApplyLeads).not.toHaveBeenCalled();
    expect(deps.persistence.saveView).not.toHaveBeenCalled();
    expect(deps.persistence.requestLeadsExport).not.toHaveBeenCalled();
    expect(deps.persistence.setCustomerPreference).not.toHaveBeenCalled();
    expect(deps.persistence.setRecordTag).not.toHaveBeenCalled();
  });

  it("returns the stable AAL2 error before shared-view or export persistence", async () => {
    const deps = dependencies();
    vi.mocked(deps.authorizer.requireRecentAal2).mockRejectedValue(
      new OperationalAuthorizationError("AAL2_REQUIRED"),
    );

    const response = await createLeadsExportRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      filter: {},
    }));

    expect(response.status).toBe(403);
    await expect(response.json()).resolves.toEqual({
      error: { code: "AAL2_REQUIRED", message: "Recent verification is required for this operation." },
    });
    expect(deps.persistence.requestLeadsExport).not.toHaveBeenCalled();
  });
});
