// @vitest-environment node

import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  CLOUDFLARE_TURNSTILE_TEST_KEYS,
  createCloudflareTurnstileVerifier,
} from "../src/ingestion/server/index.js";

const IDEMPOTENCY_KEY = "11111111-1111-4111-8111-111111111111";

function jsonResponse(body: unknown, init: ResponseInit = {}) {
  return new Response(JSON.stringify(body), {
    status: 200,
    headers: { "content-type": "application/json" },
    ...init,
  });
}

function verifier(fetchImplementation: typeof fetch) {
  return createCloudflareTurnstileVerifier({
    secret: "server-side-turnstile-secret",
    expectedHostname: "garciabrothers.test",
    expectedAction: "contact_form",
    timeoutMs: 2_000,
    fetch: fetchImplementation,
  });
}

afterEach(() => {
  vi.useRealTimers();
});

describe("Cloudflare Turnstile Siteverify adapter", () => {
  it("posts the token, trusted remote address, and stable UUID idempotency key as JSON", async () => {
    const fetchImplementation = vi.fn<typeof fetch>(async () => jsonResponse({
      success: true,
      hostname: "garciabrothers.test",
      action: "contact_form",
      challenge_ts: "2026-07-18T12:00:00.000Z",
    }));
    const adapter = verifier(fetchImplementation);

    await expect(adapter.verify({
      token: "test-token",
      remoteAddress: "203.0.113.10",
      idempotencyKey: IDEMPOTENCY_KEY,
    })).resolves.toEqual({ ok: true, safeCode: "TURNSTILE_VERIFIED" });

    expect(fetchImplementation).toHaveBeenCalledOnce();
    const [url, init] = fetchImplementation.mock.calls[0]!;
    expect(url).toBe("https://challenges.cloudflare.com/turnstile/v0/siteverify");
    expect(init).toMatchObject({
      method: "POST",
      headers: { "content-type": "application/json" },
      cache: "no-store",
    });
    expect(init?.signal).toBeInstanceOf(AbortSignal);
    expect(JSON.parse(String(init?.body))).toEqual({
      secret: "server-side-turnstile-secret",
      response: "test-token",
      remoteip: "203.0.113.10",
      idempotency_key: IDEMPOTENCY_KEY,
    });
  });

  it.each([
    [{ success: false, "error-codes": ["invalid-input-response"] }, "TURNSTILE_REJECTED"],
    [{ success: true, hostname: "attacker.test", action: "contact_form" }, "TURNSTILE_HOSTNAME_MISMATCH"],
    [{ success: true, hostname: "garciabrothers.test", action: "login" }, "TURNSTILE_ACTION_MISMATCH"],
  ] as const)("maps verification mismatch %# to a safe result", async (providerBody, safeCode) => {
    const result = await verifier(async () => jsonResponse(providerBody)).verify({
      token: "test-token",
      remoteAddress: "203.0.113.10",
      idempotencyKey: IDEMPOTENCY_KEY,
    });

    expect(result).toEqual({ ok: false, safeCode });
    expect(JSON.stringify(result)).not.toMatch(/secret|provider-detail|attacker|login/);
  });

  it.each([
    ["invalid-input-secret"],
    ["missing-input-secret"],
    ["internal-error"],
    ["unrecognized-provider-code"],
  ])("maps provider/configuration failure %s to temporary unavailability", async (providerCode) => {
    const result = await verifier(async () => jsonResponse({
      success: false,
      "error-codes": [providerCode, "private-provider-detail"],
    })).verify({
      token: "test-token",
      remoteAddress: "203.0.113.10",
      idempotencyKey: IDEMPOTENCY_KEY,
    });

    expect(result).toEqual({ ok: false, safeCode: "TURNSTILE_UNAVAILABLE" });
    expect(JSON.stringify(result)).not.toContain(providerCode);
  });

  it.each([
    [async () => new Response("upstream details", { status: 503 }), "TURNSTILE_UNAVAILABLE"],
    [async () => new Response("not-json", { status: 200 }), "TURNSTILE_UNAVAILABLE"],
    [async () => jsonResponse({ success: "yes" }), "TURNSTILE_UNAVAILABLE"],
    [async () => jsonResponse({ success: true, hostname: "x".repeat(20_000), action: "contact_form" }), "TURNSTILE_UNAVAILABLE"],
  ] as const)("fails closed for unavailable or malformed provider response %#", async (fetchImplementation, safeCode) => {
    await expect(verifier(fetchImplementation as typeof fetch).verify({
      token: "test-token",
      remoteAddress: "203.0.113.10",
      idempotencyKey: IDEMPOTENCY_KEY,
    })).resolves.toEqual({ ok: false, safeCode });
  });

  it("aborts Siteverify at the configured timeout", async () => {
    vi.useFakeTimers();
    const fetchImplementation = vi.fn<typeof fetch>(async (_url, init) => new Promise<Response>((_resolve, reject) => {
      init?.signal?.addEventListener("abort", () => reject(init.signal?.reason), { once: true });
    }));
    const pending = verifier(fetchImplementation).verify({
      token: "test-token",
      remoteAddress: "203.0.113.10",
      idempotencyKey: IDEMPOTENCY_KEY,
    });

    await vi.advanceTimersByTimeAsync(2_000);
    await expect(pending).resolves.toEqual({ ok: false, safeCode: "TURNSTILE_TIMEOUT" });
  });

  it("rejects invalid verification inputs before fetch and publishes only official test fixtures", async () => {
    const fetchImplementation = vi.fn<typeof fetch>();
    const adapter = verifier(fetchImplementation);
    await expect(adapter.verify({
      token: "x".repeat(2_049),
      remoteAddress: "203.0.113.10",
      idempotencyKey: "not-a-uuid",
    })).resolves.toEqual({ ok: false, safeCode: "TURNSTILE_REJECTED" });
    expect(fetchImplementation).not.toHaveBeenCalled();

    expect(CLOUDFLARE_TURNSTILE_TEST_KEYS).toEqual({
      alwaysPass: {
        siteKey: "1x00000000000000000000AA",
        secretKey: "1x0000000000000000000000000000000AA",
      },
      alwaysFail: {
        siteKey: "2x00000000000000000000AB",
        secretKey: "2x0000000000000000000000000000000AA",
      },
      duplicate: {
        siteKey: "1x00000000000000000000AA",
        secretKey: "3x0000000000000000000000000000000AA",
      },
      dummyToken: "XXXX.DUMMY.TOKEN.XXXX",
    });
  });
});
