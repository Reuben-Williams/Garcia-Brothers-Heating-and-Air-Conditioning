import { generateKeyPairSync } from "node:crypto";

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import * as controlPlane from "../src/control-plane/index.js";

const SITE_ID = "10000000-0000-4000-8000-000000000001";
const INSTALLATION_ID = "20000000-0000-4000-8000-000000000001";
const OWNER = "30000000-0000-4000-8000-000000000001";
const COMMAND_ID = "40000000-0000-4000-8000-000000000001";

function privateJwk(): JsonWebKey {
  const { privateKey } = generateKeyPairSync("ed25519");
  return { ...privateKey.export({ format: "jwk" }), alg: "EdDSA" };
}

describe("Supabase site runtime composition", () => {
  it("loads strict config and constructs all durable site-data-plane stores", async () => {
    const calls: string[] = [];
    const rpc = vi.fn(async (name: string) => {
      calls.push(name);
      switch (name) {
        case "builder_get_runtime_site_identity":
          return { data: { version: 1, siteId: SITE_ID, siteKey: "reviewed-site" }, error: null };
        case "builder_acquire_installation_worker_lease":
        case "builder_renew_installation_worker_lease":
          return {
            data: {
              version: 1,
              acquired: true,
              siteId: SITE_ID,
              installationId: INSTALLATION_ID,
              leaseOwner: OWNER,
              fencingToken: "1",
              leaseExpiresAt: "2026-07-19T12:02:00.000Z",
            },
            error: null,
          };
        case "builder_reserve_command_receipt":
          return {
            data: {
              status: "acquired",
              leaseToken: "60000000-0000-4000-8000-000000000001",
              leaseExpiresAt: "2026-07-19T12:01:00.000Z",
            },
            error: null,
          };
        case "builder_complete_command_receipt":
        case "builder_release_installation_worker_lease":
          return { data: true, error: null };
        default:
          throw new Error(`unexpected RPC ${name}`);
      }
    });
    const client = {
      pullCommands: vi.fn(async () => [{
        id: COMMAND_ID,
        type: "unsupported.before-subplan-3",
        version: 1,
        payload: {},
        idempotencyKey: "unsupported-before-subplan-3-v1",
        createdAt: "2026-07-19T12:00:00.000Z",
        leaseToken: "50000000-0000-4000-8000-000000000001",
        attempt: 1,
        leaseExpiresAt: "2026-07-19T12:01:00.000Z",
      }]),
      acknowledgeResult: vi.fn(async () => undefined),
      reportHealth: vi.fn(async () => undefined),
    };
    const installationManifest = {
      version: 1 as const,
      packages: { next: "0.1.0" },
      schemas: { posts: 1 },
      routes: ["/"],
    };
    const createMarker = (controlPlane as Record<string, unknown>).createSiteRuntimeMarker as
      | ((input: Record<string, unknown>) => unknown)
      | undefined;
    const createRuntime = (controlPlane as Record<string, unknown>)
      .createSupabaseSiteInstallationRuntime as
      | ((input: Record<string, unknown>, options?: Record<string, unknown>) => {
          runScheduled(): Promise<unknown>;
        })
      | undefined;

    expect(createMarker).toBeTypeOf("function");
    expect(createRuntime).toBeTypeOf("function");
    const marker = createMarker!({
      siteDataPlaneSiteId: SITE_ID,
      expectedSiteKey: "reviewed-site",
      installationManifest,
      handlers: [],
      leaseSeconds: 120,
      invocationTimeoutSeconds: 90,
      workerVersion: null,
      reachabilityEvidenceRevision: null,
    });
    const runtime = createRuntime!({
      env: {
        BUILDER_CONTROL_PLANE_URL: "https://control.example.test",
        BUILDER_INSTALLATION_ID: INSTALLATION_ID,
        BUILDER_INSTALLATION_KEY_ID: "key-1",
        BUILDER_INSTALLATION_PRIVATE_JWK: JSON.stringify(privateJwk()),
        SUPABASE_SERVICE_ROLE_KEY: "must-not-enter-runtime-health",
      },
      marker,
      installationManifest,
      handlers: [],
      healthSource: {
        probeDurableStore: async () => true,
        readQueues: async () => ({ commands: { depth: 0, oldestAgeSeconds: null, deadLetters: 0 } }),
        probeIntegrations: async () => ({}),
      },
      supabaseClient: { rpc },
    }, {
      leaseOwner: () => OWNER,
      now: () => new Date("2026-07-19T12:00:00.000Z"),
      installationClientFactory: () => client,
    });

    await expect(runtime.runScheduled()).resolves.toEqual({
      pulled: 1,
      acknowledged: 1,
      healthReported: true,
    });
    expect(calls).toEqual([
      "builder_get_runtime_site_identity",
      "builder_acquire_installation_worker_lease",
      "builder_renew_installation_worker_lease",
      "builder_reserve_command_receipt",
      "builder_renew_installation_worker_lease",
      "builder_complete_command_receipt",
      "builder_renew_installation_worker_lease",
      "builder_release_installation_worker_lease",
    ]);
    expect(client.acknowledgeResult).toHaveBeenCalledWith(expect.objectContaining({
      outcome: "failed",
      errorCode: "UNSUPPORTED_COMMAND_TYPE",
    }));
    expect(JSON.stringify(client.reportHealth.mock.calls)).not.toContain("must-not-enter-runtime-health");
  });

  it("rejects marker drift before any RPC", () => {
    const rpc = vi.fn();
    const createRuntime = (controlPlane as Record<string, unknown>)
      .createSupabaseSiteInstallationRuntime as
      | ((input: Record<string, unknown>) => unknown)
      | undefined;

    expect(createRuntime).toBeTypeOf("function");
    expect(() => createRuntime?.({
      env: {},
      marker: {
        version: 1,
        siteDataPlaneSiteId: SITE_ID,
        expectedSiteKey: "reviewed-site",
        installationManifestSha256: "a".repeat(64),
        configLoaderContract: "installation-client-config-v1",
        durableStoreContract: "supabase-command-receipts-v1",
        leaseContract: "site-installation-run-lease-v1",
        leaseSeconds: 120,
        invocationTimeoutSeconds: 90,
        scheduledInvocationContract: "direct-in-process-v1",
        handlerRegistrySha256: "b".repeat(64),
        reachabilityEvidenceRevision: null,
      },
      installationManifest: { version: 1, packages: {}, schemas: {}, routes: [] },
      handlers: [],
      healthSource: {},
      supabaseClient: { rpc },
    })).toThrow("site_runtime_marker_mismatch");
    expect(rpc).not.toHaveBeenCalled();
  });
});
