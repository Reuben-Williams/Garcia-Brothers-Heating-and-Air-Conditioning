import { describe, expect, it } from "vitest";
import { createBuilderPreviewMessage } from "@your-builder/core";
import {
  PreviewSessionError,
  issuePreviewSession,
  validatePreviewMessageEvent,
  verifyPreviewCsrf,
  verifyPreviewSession,
} from "../src/auth/preview-session.js";

const secret = "preview-secret-that-is-long-enough-for-tests";

describe("preview sessions", () => {
  it("round trips a site, user, origin, generation, and expiry bound session", async () => {
    const token = await issuePreviewSession({
      siteKey: "assembly",
      userId: "user-1",
      generation: 3,
      allowedOrigins: ["https://assembly.example"],
      csrfToken: "csrf-1",
      secret,
      now: 1_000,
      ttlSeconds: 120,
    });

    await expect(
      verifyPreviewSession(token, {
        secret,
        siteKey: "assembly",
        userId: "user-1",
        generation: 3,
        origin: "https://assembly.example",
        now: 1_100,
      }),
    ).resolves.toMatchObject({ siteKey: "assembly", userId: "user-1", expiresAt: 1_120 });
  });

  it.each([
    ["wrong site", { siteKey: "other" }],
    ["revoked generation", { generation: 4 }],
    ["wrong origin", { origin: "https://evil.example" }],
    ["expired", { now: 1_121 }],
  ])("rejects %s", async (_label, override) => {
    const token = await issuePreviewSession({
      siteKey: "assembly",
      userId: "user-1",
      generation: 3,
      allowedOrigins: ["https://assembly.example"],
      csrfToken: "csrf-1",
      secret,
      now: 1_000,
      ttlSeconds: 120,
    });

    await expect(
      verifyPreviewSession(token, {
        secret,
        siteKey: "assembly",
        userId: "user-1",
        generation: 3,
        origin: "https://assembly.example",
        now: 1_100,
        ...override,
      }),
    ).rejects.toBeInstanceOf(PreviewSessionError);
  });

  it("rejects a missing or mismatched CSRF token", () => {
    expect(() => verifyPreviewCsrf("csrf-1", "csrf-2")).toThrowError(PreviewSessionError);
    expect(() => verifyPreviewCsrf("csrf-1", null)).toThrowError(PreviewSessionError);
    expect(() => verifyPreviewCsrf("csrf-1", "csrf-1")).not.toThrow();
  });

  it("validates message origin, source, protocol, site, and page", () => {
    const source = {} as Window;
    const message = createBuilderPreviewMessage("assembly", {
      type: "builder:ready",
      pagePath: "/about",
    });

    expect(
      validatePreviewMessageEvent(
        { origin: "https://assembly.example", source, data: message },
        {
          expectedOrigin: "https://assembly.example",
          expectedSource: source,
          siteKey: "assembly",
          pagePath: "/about",
        },
      ),
    ).toEqual(message);

    expect(() =>
      validatePreviewMessageEvent(
        { origin: "https://evil.example", source, data: message },
        {
          expectedOrigin: "https://assembly.example",
          expectedSource: source,
          siteKey: "assembly",
          pagePath: "/about",
        },
      ),
    ).toThrowError(PreviewSessionError);
  });
});
