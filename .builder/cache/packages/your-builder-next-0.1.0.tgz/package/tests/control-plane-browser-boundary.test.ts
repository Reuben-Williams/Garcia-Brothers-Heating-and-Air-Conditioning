import { readdir, readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { describe, expect, it } from "vitest";

describe("control-plane browser boundary", () => {
  it("poisons a client entry through the server-only package", async () => {
    await expect(import("./fixtures/control-plane-client-entry.js")).rejects.toThrow(
      "This module cannot be imported from a Client Component module",
    );
  });

  it("keeps the root export browser-safe and the subpath explicitly server-only", async () => {
    const root = await readFile(resolve("packages/next/src/index.tsx"), "utf8");
    const controlPlane = await readFile(
      resolve("packages/next/src/control-plane/index.ts"),
      "utf8",
    );
    const installationWorker = await readFile(
      resolve("packages/next/src/installation-worker.ts"),
      "utf8",
    );
    const packageManifest = JSON.parse(
      await readFile(resolve("packages/next/package.json"), "utf8"),
    );

    expect(root.startsWith('"use client";')).toBe(true);
    expect(root).not.toContain("./control-plane");
    expect(controlPlane.startsWith('import "server-only";')).toBe(true);
    expect(installationWorker.startsWith('import "server-only";')).toBe(true);
    expect(packageManifest.exports["./control-plane"]).toEqual({
      types: "./src/control-plane/index.ts",
      default: "./src/control-plane/index.ts",
    });
    expect(packageManifest.exports["./installation-worker"]).toEqual({
      types: "./src/installation-worker.ts",
      default: "./src/installation-worker.ts",
    });

    for (const serverModule of [
      "site-runtime.ts",
      "site-health.ts",
      "site-data-plane-identity.ts",
      "site-run-lease.ts",
      "runtime-marker.ts",
      "scheduled-invocation.ts",
    ]) {
      const source = await readFile(
        resolve("packages/next/src/control-plane", serverModule),
        "utf8",
      );
      expect(source.startsWith('import "server-only";')).toBe(true);
      expect(root).not.toContain(serverModule.replace(/\.ts$/, ""));
    }
  });

  it("keeps ordinary example and public-page sources independent of the control-plane subpath", async () => {
    async function sourceFiles(directory: string, excludeApi = false): Promise<string[]> {
      const entries = await readdir(directory, { withFileTypes: true });
      const nested = await Promise.all(entries.map(async (entry) => {
        if (excludeApi && entry.isDirectory() && entry.name === "api") return [];
        const path = resolve(directory, entry.name);
        if (entry.isDirectory()) return sourceFiles(path, false);
        return /\.tsx?$/.test(entry.name) ? [path] : [];
      }));
      return nested.flat();
    }

    const files = [
      ...(await sourceFiles(resolve("examples"))),
      ...(await sourceFiles(resolve("apps/control-plane/app"), true)),
    ];
    const offenders = [];
    for (const file of files) {
      const source = await readFile(file, "utf8");
      if (
        source.includes("@your-builder/next/control-plane") ||
        source.includes("packages/next/src/control-plane")
      ) {
        offenders.push(file);
      }
    }

    expect(offenders).toEqual([]);
  });
});
