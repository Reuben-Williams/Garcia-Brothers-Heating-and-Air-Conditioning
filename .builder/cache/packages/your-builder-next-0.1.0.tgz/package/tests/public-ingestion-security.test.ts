// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import * as ingestionServer from "../src/ingestion/server/index.js";
import {
  PublicIngestionRequestError,
  createHmacFingerprintService,
  createNetlifyTrustedNetworkAdapter,
  createVercelTrustedNetworkAdapter,
  validatePublicIngestionRequest,
} from "../src/ingestion/server/index.js";

const IDEMPOTENCY_KEY = "11111111-1111-4111-8111-111111111111";
const CONSENT_TEXT = "I agree to be contacted about this request.";

function validBody(overrides: Record<string, unknown> = {}) {
  return {
    firstName: "  Synthetic  ",
    lastName: " Customer ",
    email: " USER@Example.Test ",
    phone: "(302) 555-0100",
    zipCode: "19713",
    serviceId: "ac-repair",
    urgency: "urgent",
    message: "  The system is not cooling.  ",
    consentAcknowledged: true,
    consentPolicyVersion: "privacy-v1",
    consentAcknowledgement: CONSENT_TEXT,
    turnstileToken: "test-turnstile-token",
    idempotencyKey: IDEMPOTENCY_KEY,
    ...overrides,
  };
}

function jsonRequest(body: unknown, init: RequestInit = {}) {
  return new Request("https://garciabrothers.test/api/builder/forms/contact/submit", {
    ...init,
    method: "POST",
    headers: {
      "content-type": "application/json; charset=utf-8",
      origin: "https://garciabrothers.test",
      "sec-fetch-site": "same-origin",
      ...init.headers,
    },
    body: typeof body === "string" ? body : JSON.stringify(body),
  });
}

const validationOptions = {
  allowedOrigins: ["https://garciabrothers.test"],
  allowedServiceIds: ["ac-repair", "heating-repair"],
  consentPolicy: {
    version: "privacy-v1",
    acknowledgementText: CONSENT_TEXT,
  },
  maxBodyBytes: 16_384,
};

describe("public ingestion request validation", () => {
  it("accepts bounded same-origin JSON and returns normalized fields", async () => {
    const result = await validatePublicIngestionRequest(jsonRequest(validBody()), validationOptions);

    expect(result).toEqual({
      firstName: "Synthetic",
      lastName: "Customer",
      email: "user@example.test",
      phone: "+13025550100",
      zipCode: "19713",
      serviceId: "ac-repair",
      urgency: "urgent",
      message: "The system is not cooling.",
      consentAcknowledged: true,
      consentPolicyVersion: "privacy-v1",
      turnstileToken: "test-turnstile-token",
      idempotencyKey: IDEMPOTENCY_KEY,
    });
  });

  it.each([
    ["missing origin", { headers: { origin: "" } }, "ORIGIN_REQUIRED", 403],
    ["cross origin", { headers: { origin: "https://attacker.test" } }, "ORIGIN_REJECTED", 403],
    ["cross-site fetch metadata", { headers: { "sec-fetch-site": "cross-site" } }, "ORIGIN_REJECTED", 403],
    ["wrong media type", { headers: { "content-type": "text/plain" } }, "JSON_REQUIRED", 415],
  ])("rejects %s before parsing the body", async (_label, init, safeCode, status) => {
    await expect(validatePublicIngestionRequest(jsonRequest(validBody(), init), validationOptions))
      .rejects.toMatchObject({ safeCode, status });
  });

  it("rejects a streamed body that exceeds the byte limit without trusting content-length", async () => {
    const request = jsonRequest(validBody({ message: "x".repeat(2_000) }));

    await expect(validatePublicIngestionRequest(request, {
      ...validationOptions,
      maxBodyBytes: 512,
    })).rejects.toMatchObject({ safeCode: "REQUEST_TOO_LARGE", status: 413 });
  });

  it("uses stable safe errors for malformed JSON and invalid schema", async () => {
    await expect(validatePublicIngestionRequest(jsonRequest("{"), validationOptions))
      .rejects.toMatchObject({ safeCode: "INVALID_JSON", status: 400 });

    const invalidBodies = [
      validBody({ email: undefined, phone: undefined }),
      validBody({ email: undefined, phone: 302_555_0100 }),
      validBody({ email: "not-an-email" }),
      validBody({ phone: "123" }),
      validBody({ zipCode: "not-a-zip" }),
      validBody({ serviceId: "unreviewed-service" }),
      validBody({ consentAcknowledged: false }),
      validBody({ consentPolicyVersion: "privacy-v0" }),
      validBody({ consentPolicyVersion: " privacy-v1 " }),
      validBody({ consentAcknowledgement: "I agree to something else." }),
      validBody({ consentAcknowledgement: ` ${CONSENT_TEXT} ` }),
      validBody({ message: "x".repeat(2_001) }),
      validBody({ idempotencyKey: "submission-1" }),
      validBody({ turnstileToken: "x".repeat(2_049) }),
      { ...validBody(), unexpected: "field" },
    ];

    for (const body of invalidBodies) {
      await expect(validatePublicIngestionRequest(jsonRequest(body), validationOptions))
        .rejects.toBeInstanceOf(PublicIngestionRequestError);
      await expect(validatePublicIngestionRequest(jsonRequest(body), validationOptions))
        .rejects.toMatchObject({ safeCode: "INVALID_SUBMISSION", status: 400 });
    }
  });
});

describe("trusted host network context", () => {
  it("does not expose a configurable forwarding-header adapter", () => {
    expect(ingestionServer).not.toHaveProperty("createTrustedHeaderNetworkAdapter");
  });

  it("uses only Netlify's platform boundary header and ignores arbitrary forwarding headers", async () => {
    const adapter = createNetlifyTrustedNetworkAdapter();
    const request = jsonRequest(validBody(), {
      headers: {
        origin: "https://garciabrothers.test",
        "content-type": "application/json",
        "x-nf-client-connection-ip": "203.0.113.10",
        "x-forwarded-for": "198.51.100.9",
        forwarded: "for=198.51.100.8",
        "cf-connecting-ip": "198.51.100.7",
      },
    });

    await expect(adapter.resolve(request)).resolves.toEqual({ address: "203.0.113.10" });
  });

  it("uses Vercel's protected forwarding boundary and rejects a multiple-address value", async () => {
    const adapter = createVercelTrustedNetworkAdapter();
    await expect(adapter.resolve(jsonRequest(validBody(), {
      headers: {
        "x-forwarded-for": "203.0.113.11",
        forwarded: "for=198.51.100.8",
        "cf-connecting-ip": "198.51.100.7",
      },
    }))).resolves.toEqual({ address: "203.0.113.11" });

    await expect(adapter.resolve(jsonRequest(validBody(), {
      headers: { "x-forwarded-for": "203.0.113.11, 198.51.100.8" },
    }))).rejects.toMatchObject({ safeCode: "NETWORK_CONTEXT_REJECTED" });
  });

  it("canonicalizes a single IPv6 address and rejects missing, multiple, or malformed values", async () => {
    const adapter = createNetlifyTrustedNetworkAdapter();
    await expect(adapter.resolve(jsonRequest(validBody(), {
      headers: { "x-nf-client-connection-ip": "2001:0DB8:0:0:0:0:0:1" },
    }))).resolves.toEqual({ address: "2001:db8::1" });

    for (const value of [undefined, "203.0.113.10, 198.51.100.7", "not-an-ip"]) {
      const invalidRequest = value
        ? jsonRequest(validBody(), { headers: { "x-nf-client-connection-ip": value } })
        : jsonRequest(validBody());
      await expect(adapter.resolve(invalidRequest))
        .rejects.toMatchObject({ safeCode: "NETWORK_CONTEXT_REJECTED" });
    }
  });
});

describe("public ingestion HMAC fingerprints", () => {
  it("normalizes equivalent network and identity values into deterministic non-reversible digests", () => {
    const fingerprints = createHmacFingerprintService({
      keyId: "site-key-2026-07",
      secret: "a-site-scoped-rotating-secret-with-32-bytes-minimum",
    });

    const first = fingerprints.create({
      networkAddress: "2001:0DB8:0:0:0:0:0:1",
      email: " USER@Example.Test ",
      phone: "(302) 555-0100",
    });
    const second = fingerprints.create({
      networkAddress: "2001:db8::1",
      email: "user@example.test",
      phone: "+1 302 555 0100",
    });

    expect(first).toEqual(second);
    expect(first.keyId).toBe("site-key-2026-07");
    expect(first.networkFingerprint).toMatch(/^[a-f0-9]{64}$/);
    expect(first.identityFingerprint).toMatch(/^[a-f0-9]{64}$/);
    expect(JSON.stringify(first)).not.toMatch(/2001|example|302555/);
  });

  it("uses domain separation and changes digests when the rotating key changes", () => {
    const input = {
      networkAddress: "203.0.113.10",
      email: "user@example.test",
    };
    const current = createHmacFingerprintService({
      keyId: "current",
      secret: "current-site-secret-that-is-at-least-32-bytes",
    }).create(input);
    const rotated = createHmacFingerprintService({
      keyId: "rotated",
      secret: "rotated-site-secret-that-is-at-least-32-bytes",
    }).create(input);

    expect(current.networkFingerprint).not.toBe(current.identityFingerprint);
    expect(rotated.networkFingerprint).not.toBe(current.networkFingerprint);
    expect(rotated.identityFingerprint).not.toBe(current.identityFingerprint);
  });

  it("copies injected key bytes so caller mutation cannot change later fingerprints", () => {
    const secret = new TextEncoder().encode("site-secret-bytes-that-are-at-least-32-bytes-long");
    const service = createHmacFingerprintService({ keyId: "stable", secret });
    const input = { networkAddress: "203.0.113.10", email: "user@example.test" };
    const before = service.create(input);

    secret.fill(0);

    expect(service.create(input)).toEqual(before);
  });

  it("creates a stable hex request fingerprint from canonical normalized submission data", () => {
    const service = createHmacFingerprintService({
      keyId: "stable",
      secret: "site-secret-bytes-that-are-at-least-32-bytes-long",
    });

    const first = service.createRequestFingerprint({
      formId: "contact",
      payload: { firstName: "Synthetic", message: "No cooling" },
      locale: "en-US",
    });
    const reordered = service.createRequestFingerprint({
      locale: "en-US",
      payload: { message: "No cooling", firstName: "Synthetic" },
      formId: "contact",
    });
    const changed = service.createRequestFingerprint({
      formId: "contact",
      payload: { firstName: "Synthetic", message: "No heat" },
      locale: "en-US",
    });

    expect(first).toMatch(/^[a-f0-9]{64}$/);
    expect(reordered).toBe(first);
    expect(changed).not.toBe(first);
  });
});
