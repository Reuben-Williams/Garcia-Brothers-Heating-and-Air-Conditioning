import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  createSiteCommandExecutor,
  type SiteCommandHandler,
} from "../src/control-plane/command-executor.js";
import {
  createMemorySiteCommandReceiptStore,
  createSupabaseSiteCommandReceiptStore,
  type SiteCommandReceiptStore,
} from "../src/control-plane/idempotency-store.js";

const SITE_ID = "10000000-0000-4000-8000-000000000001";
const COMMAND_ID = "20000000-0000-4000-8000-000000000001";
const INSTALLATION_ID = "30000000-0000-4000-8000-000000000001";
const LEASE_OWNER = "40000000-0000-4000-8000-000000000001";

function executionContext(
  signal = new AbortController().signal,
  validateLease = vi.fn(async () => undefined),
) {
  return {
    signal,
    validateLease,
    lease: {
      siteId: SITE_ID,
      installationId: INSTALLATION_ID,
      leaseOwner: LEASE_OWNER,
      fencingToken: "7",
      leaseExpiresAt: "2026-07-19T12:02:00.000Z",
    },
  };
}

function command(overrides: Partial<{
  id: string;
  type: string;
  version: number;
  payload: Record<string, unknown>;
  idempotencyKey: string;
}> = {}) {
  return {
    id: COMMAND_ID,
    type: "module.configure",
    version: 1,
    payload: { moduleId: "growth.reviews" },
    idempotencyKey: "configure-growth-reviews-v1",
    ...overrides,
  };
}

function handler(overrides: Partial<SiteCommandHandler<{ moduleId: string }>> = {}) {
  return {
    type: "module.configure",
    version: 1,
    idempotency: "commandId",
    validate: vi.fn((payload: unknown) => {
      if (
        !payload ||
        typeof payload !== "object" ||
        (payload as Record<string, unknown>).moduleId !== "growth.reviews"
      ) {
        throw new TypeError("invalid module payload");
      }
      return { moduleId: "growth.reviews" };
    }),
    execute: vi.fn(async () => ({
      resultCode: "MODULE_CONFIGURED",
      evidence: { codes: ["CONFIG_CREATED"] },
    })),
    ...overrides,
  } satisfies SiteCommandHandler<{ moduleId: string }>;
}

describe("site command executor", () => {
  it("passes the abort signal and positive fencing lease context to the handler", async () => {
    const context = executionContext();
    const registered = handler();
    const executor = createSiteCommandExecutor({
      siteId: SITE_ID,
      handlers: [registered],
      store: createMemorySiteCommandReceiptStore(),
    });

    await expect(executor.execute(command(), context)).resolves.toMatchObject({
      outcome: "succeeded",
    });
    expect(registered.execute).toHaveBeenCalledWith({
      commandId: COMMAND_ID,
      idempotencyKey: "configure-growth-reviews-v1",
      payload: { moduleId: "growth.reviews" },
      signal: context.signal,
      lease: context.lease,
    });
  });

  it("does not complete a receipt when the handler returns after its signal is aborted", async () => {
    const abort = new AbortController();
    let finish: (() => void) | undefined;
    const handlerFinished = new Promise<void>((resolve) => {
      finish = resolve;
    });
    const registered = handler({
      execute: vi.fn(async () => {
        await handlerFinished;
        return { resultCode: "MODULE_CONFIGURED", evidence: {} };
      }),
    });
    const durableStore = createMemorySiteCommandReceiptStore();
    const complete = vi.spyOn(durableStore, "complete");
    const executor = createSiteCommandExecutor({
      siteId: SITE_ID,
      handlers: [registered],
      store: durableStore,
    });
    const leaseLost = Object.assign(new Error("site_installation_lease_lost"), {
      code: "site_installation_lease_lost",
    });

    const pending = executor.execute(command(), executionContext(abort.signal));
    await vi.waitFor(() => expect(registered.execute).toHaveBeenCalledOnce());
    abort.abort(leaseLost);
    finish?.();

    await expect(pending).rejects.toBe(leaseLost);
    expect(complete).not.toHaveBeenCalled();
  });

  it("validates lease ownership after handler effects and before completing the receipt", async () => {
    const events: string[] = [];
    const registered = handler({
      execute: vi.fn(async () => {
        events.push("handler");
        return { resultCode: "MODULE_CONFIGURED", evidence: {} };
      }),
    });
    const durableStore = createMemorySiteCommandReceiptStore();
    const complete = durableStore.complete.bind(durableStore);
    durableStore.complete = vi.fn(async (input) => {
      events.push("complete");
      return complete(input);
    });
    const validateLease = vi.fn(async () => {
      events.push("validate");
    });
    const executor = createSiteCommandExecutor({
      siteId: SITE_ID,
      handlers: [registered],
      store: durableStore,
    });

    await expect(executor.execute(
      command(),
      executionContext(new AbortController().signal, validateLease),
    )).resolves.toMatchObject({ outcome: "succeeded" });

    expect(events).toEqual(["handler", "validate", "complete"]);
    expect(validateLease).toHaveBeenCalledOnce();
  });

  it("rejects handlers that do not declare command-ID idempotency", () => {
    const registered = { ...handler(), idempotency: undefined } as unknown as SiteCommandHandler;

    expect(() => createSiteCommandExecutor({
      siteId: SITE_ID,
      handlers: [registered],
      store: createMemorySiteCommandReceiptStore(),
    })).toThrow("Site command handlers must be idempotent on commandId");
  });

  it.each([
    ["unknown type", command({ type: "module.remove" }), "UNSUPPORTED_COMMAND_TYPE"],
    ["unknown version", command({ version: 2 }), "UNSUPPORTED_COMMAND_VERSION"],
  ])("rejects %s before executing effects", async (_label, input, errorCode) => {
    const registered = handler();
    const executor = createSiteCommandExecutor({
      siteId: SITE_ID,
      handlers: [registered],
      store: createMemorySiteCommandReceiptStore(),
    });

    await expect(executor.execute(input, executionContext())).resolves.toMatchObject({
      outcome: "failed",
      errorCode,
    });
    expect(registered.validate).not.toHaveBeenCalled();
    expect(registered.execute).not.toHaveBeenCalled();
  });

  it("validates payloads before effects and stores the terminal denial", async () => {
    const registered = handler();
    const store = createMemorySiteCommandReceiptStore();
    const executor = createSiteCommandExecutor({ siteId: SITE_ID, handlers: [registered], store });

    const result = await executor.execute(
      command({ payload: { moduleId: "growth.unknown" } }),
      executionContext(),
    );

    expect(result).toMatchObject({ outcome: "failed", errorCode: "INVALID_COMMAND_PAYLOAD" });
    expect(registered.validate).toHaveBeenCalledOnce();
    expect(registered.execute).not.toHaveBeenCalled();
    await expect(store.find({
      siteId: SITE_ID,
      commandId: COMMAND_ID,
      idempotencyKey: "configure-growth-reviews-v1",
    })).resolves.toMatchObject({ result });
  });

  it("replays a stored sanitized result without re-executing", async () => {
    const registered = handler();
    const executor = createSiteCommandExecutor({
      siteId: SITE_ID,
      handlers: [registered],
      store: createMemorySiteCommandReceiptStore(),
    });

    const first = await executor.execute(command(), executionContext());
    const replay = await executor.execute(command(), executionContext());

    expect(replay).toEqual(first);
    expect(registered.validate).toHaveBeenCalledOnce();
    expect(registered.execute).toHaveBeenCalledOnce();
  });

  it("allowlists evidence and never persists handler secrets", async () => {
    const sha256 = "a".repeat(64);
    const registered = handler({
      execute: vi.fn(async () => ({
        resultCode: "MODULE_CONFIGURED",
        evidence: {
          codes: ["CONFIG_CREATED", "unsafe code"],
          metrics: { rowsCreated: 2, invalid: -1 },
          flags: { defaultDisabled: true, token: "do-not-store" },
          digests: { configuration: sha256, raw: "do-not-store" },
          email: "owner@example.test",
          secret: "do-not-store",
        },
      })),
    });
    const store = createMemorySiteCommandReceiptStore();
    const executor = createSiteCommandExecutor({ siteId: SITE_ID, handlers: [registered], store });

    const result = await executor.execute(command(), executionContext());

    expect(result).toEqual({
      outcome: "succeeded",
      resultCode: "MODULE_CONFIGURED",
      evidence: {
        version: 1,
        codes: ["CONFIG_CREATED"],
        metrics: { rowsCreated: 2 },
        flags: { defaultDisabled: true },
        digests: { configuration: sha256 },
      },
    });
    expect(JSON.stringify(await store.find({
      siteId: SITE_ID,
      commandId: COMMAND_ID,
      idempotencyKey: "configure-growth-reviews-v1",
    }))).not.toContain("do-not-store");
    expect(JSON.stringify(result)).not.toContain("owner@example.test");
  });

  it("fails closed when an idempotency key is reused for different payload", async () => {
    const registered = handler();
    const executor = createSiteCommandExecutor({
      siteId: SITE_ID,
      handlers: [registered],
      store: createMemorySiteCommandReceiptStore(),
    });

    await executor.execute(command(), executionContext());
    const conflict = await executor.execute(command({
      id: "20000000-0000-4000-8000-000000000002",
      payload: { moduleId: "growth.unknown" },
    }), executionContext());

    expect(conflict).toMatchObject({ outcome: "failed", errorCode: "IDEMPOTENCY_CONFLICT" });
    expect(registered.execute).toHaveBeenCalledOnce();
  });

  it("runs an automatic compensator once and replays its stored result", async () => {
    const compensate = vi.fn(async () => ({ resultCode: "MODULE_CONFIGURATION_REMOVED" }));
    const registered = handler({ compensate });
    const executor = createSiteCommandExecutor({
      siteId: SITE_ID,
      handlers: [registered],
      store: createMemorySiteCommandReceiptStore(),
    });
    const compensation = command({
      id: "20000000-0000-4000-8000-000000000003",
      type: "module.configure.compensate",
      idempotencyKey: "configure-growth-reviews-v1-compensate",
      payload: {
        commandId: COMMAND_ID,
        evidence: {
          version: 1,
          codes: ["CONFIG_CREATED"],
          metrics: {},
          flags: { defaultDisabled: true },
          digests: {},
        },
      },
    });

    const context = executionContext();
    const first = await executor.execute(compensation, context);
    const replay = await executor.execute(compensation, context);

    expect(first).toEqual({
      outcome: "succeeded",
      resultCode: "MODULE_CONFIGURATION_REMOVED",
      evidence: { version: 1, codes: [], metrics: {}, flags: {}, digests: {} },
    });
    expect(replay).toEqual(first);
    expect(compensate).toHaveBeenCalledOnce();
    expect(compensate).toHaveBeenCalledWith({
      commandId: COMMAND_ID,
      evidence: {
        version: 1,
        codes: ["CONFIG_CREATED"],
        metrics: {},
        flags: { defaultDisabled: true },
        digests: {},
      },
      signal: context.signal,
      lease: context.lease,
    });
    expect(registered.execute).not.toHaveBeenCalled();
  });

  it("reacquires a transient retry after retryAt under the same identity", async () => {
    let currentTime = new Date("2026-07-16T12:00:00.000Z");
    const registered = handler({
      execute: vi.fn()
        .mockResolvedValueOnce({
          outcome: "retry",
          errorCode: "DEPENDENCY_UNAVAILABLE",
          retryAt: "2026-07-16T12:01:00.000Z",
          evidence: { codes: ["SAFE_TO_RETRY"] },
        })
        .mockResolvedValueOnce({
          resultCode: "MODULE_CONFIGURED",
          evidence: { codes: ["CONFIG_CREATED"] },
        }),
    });
    const store = createMemorySiteCommandReceiptStore({
      now: () => currentTime,
      leaseSeconds: 30,
    });
    const executor = createSiteCommandExecutor({
      siteId: SITE_ID,
      handlers: [registered],
      store,
      now: () => currentTime,
    });

    const first = await executor.execute(command(), executionContext());
    const earlyReplay = await executor.execute(command(), executionContext());
    currentTime = new Date("2026-07-16T12:01:00.000Z");
    const recovered = await executor.execute(command(), executionContext());

    expect(first).toMatchObject({ outcome: "retry", errorCode: "DEPENDENCY_UNAVAILABLE" });
    expect(earlyReplay).toEqual(first);
    expect(recovered).toMatchObject({ outcome: "succeeded", resultCode: "MODULE_CONFIGURED" });
    expect(registered.execute).toHaveBeenCalledTimes(2);
    expect(registered.execute).toHaveBeenNthCalledWith(1, expect.objectContaining({
      commandId: COMMAND_ID,
      idempotencyKey: "configure-growth-reviews-v1",
    }));
    expect(registered.execute).toHaveBeenNthCalledWith(2, expect.objectContaining({
      commandId: COMMAND_ID,
      idempotencyKey: "configure-growth-reviews-v1",
    }));
  });

  it("recovers an expired reservation with the same command ID after a crash", async () => {
    let currentTime = new Date("2026-07-16T12:00:00.000Z");
    const durableEffects = new Set<string>();
    let effectCount = 0;
    const registered = handler({
      execute: vi.fn(async ({ commandId }) => {
        if (!durableEffects.has(commandId)) {
          durableEffects.add(commandId);
          effectCount += 1;
        }
        return {
          resultCode: "MODULE_CONFIGURED",
          evidence: { codes: ["CONFIG_CREATED"] },
        };
      }),
    });
    const durableStore = createMemorySiteCommandReceiptStore({
      now: () => currentTime,
      leaseSeconds: 30,
    });
    let injectCrash = true;
    const crashStore: SiteCommandReceiptStore = {
      reserve: (input) => durableStore.reserve(input),
      complete: async (input) => {
        if (injectCrash) {
          injectCrash = false;
          throw new Error("simulated crash after site effect");
        }
        return durableStore.complete(input);
      },
      find: (input) => durableStore.find(input),
    };
    const executor = createSiteCommandExecutor({
      siteId: SITE_ID,
      handlers: [registered],
      store: crashStore,
      now: () => currentTime,
    });

    await expect(executor.execute(command(), executionContext())).rejects.toThrow("simulated crash");
    await expect(executor.execute(command(), executionContext())).resolves.toMatchObject({
      outcome: "retry",
      errorCode: "COMMAND_IN_PROGRESS",
    });
    currentTime = new Date("2026-07-16T12:00:31.000Z");
    await expect(executor.execute(command(), executionContext())).resolves.toMatchObject({
      outcome: "succeeded",
      resultCode: "MODULE_CONFIGURED",
    });

    expect(registered.execute).toHaveBeenCalledTimes(2);
    expect(registered.execute).toHaveBeenNthCalledWith(1, expect.objectContaining({ commandId: COMMAND_ID }));
    expect(registered.execute).toHaveBeenNthCalledWith(2, expect.objectContaining({ commandId: COMMAND_ID }));
    expect(effectCount).toBe(1);
  });
});

describe("Supabase site command receipt store", () => {
  it("uses atomic receipt RPCs and returns persisted replay results", async () => {
    const leaseToken = "30000000-0000-4000-8000-000000000001";
    const persisted = {
      outcome: "succeeded" as const,
      resultCode: "MODULE_CONFIGURED",
      evidence: { version: 1 as const, codes: [], metrics: {}, flags: {}, digests: {} },
    };
    let reserveCount = 0;
    const rpc = vi.fn(async (name: string) => {
      if (name === "builder_reserve_command_receipt") {
        reserveCount += 1;
        return {
          data: reserveCount === 1
            ? {
                status: "acquired",
                leaseToken,
                leaseExpiresAt: "2026-07-16T12:00:30.000Z",
              }
            : { status: "replay", result: persisted },
          error: null,
        };
      }
      return { data: true, error: null };
    });
    const store = createSupabaseSiteCommandReceiptStore({ rpc });
    const receipt = {
      siteId: SITE_ID,
      commandId: COMMAND_ID,
      idempotencyKey: "configure-growth-reviews-v1",
      type: "module.configure",
      version: 1,
      payloadHash: "a".repeat(64),
    };

    await expect(store.reserve(receipt)).resolves.toEqual({
      status: "acquired",
      leaseToken,
      leaseExpiresAt: "2026-07-16T12:00:30.000Z",
    });
    await expect(store.complete({ ...receipt, leaseToken, result: persisted })).resolves.toBe(true);
    await expect(store.reserve(receipt)).resolves.toEqual({ status: "replay", result: persisted });

    expect(rpc).toHaveBeenNthCalledWith(1, "builder_reserve_command_receipt", {
      p_site_id: SITE_ID,
      p_command_id: COMMAND_ID,
      p_idempotency_key: "configure-growth-reviews-v1",
      p_command_type: "module.configure",
      p_command_version: 1,
      p_payload_hash: "a".repeat(64),
      p_lease_seconds: 30,
    });
    expect(rpc).toHaveBeenNthCalledWith(2, "builder_complete_command_receipt", {
      p_site_id: SITE_ID,
      p_command_id: COMMAND_ID,
      p_idempotency_key: "configure-growth-reviews-v1",
      p_command_type: "module.configure",
      p_command_version: 1,
      p_payload_hash: "a".repeat(64),
      p_lease_token: leaseToken,
      p_result: persisted,
    });
    expect(rpc).toHaveBeenNthCalledWith(3, "builder_reserve_command_receipt", {
      p_site_id: SITE_ID,
      p_command_id: COMMAND_ID,
      p_idempotency_key: "configure-growth-reviews-v1",
      p_command_type: "module.configure",
      p_command_version: 1,
      p_payload_hash: "a".repeat(64),
      p_lease_seconds: 30,
    });
  });
});
