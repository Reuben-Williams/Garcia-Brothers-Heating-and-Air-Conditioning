import { describe, expect, it } from "vitest";
import {
  BuilderAuthError,
  requireBuilderMember,
  type BuilderMembershipLookup,
} from "../src/auth/require-member.js";

const claimsClient = (sub?: string) => ({
  auth: {
    getClaims: async () => ({
      data: sub ? { claims: { sub } } : null,
      error: sub ? null : new Error("missing session"),
    }),
  },
});

describe("requireBuilderMember", () => {
  it("rejects a request without verified auth claims", async () => {
    const lookup: BuilderMembershipLookup = async () => null;

    await expect(
      requireBuilderMember({ client: claimsClient(), siteKey: "assembly", lookup }),
    ).rejects.toMatchObject({ code: "AUTH_REQUIRED", status: 401 });
  });

  it("rejects users who do not belong to the requested site", async () => {
    const lookup: BuilderMembershipLookup = async () => null;

    await expect(
      requireBuilderMember({ client: claimsClient("user-1"), siteKey: "assembly", lookup }),
    ).rejects.toMatchObject({ code: "SITE_ACCESS_DENIED", status: 403 });
  });

  it("enforces allowed roles using server-loaded membership", async () => {
    const lookup: BuilderMembershipLookup = async () => ({
      siteId: "site-uuid",
      siteKey: "assembly",
      userId: "user-1",
      email: "owner@example.com",
      role: "viewer",
      previewGeneration: 4,
    });

    await expect(
      requireBuilderMember({
        client: claimsClient("user-1"),
        siteKey: "assembly",
        lookup,
        allowedRoles: ["owner", "editor"],
      }),
    ).rejects.toBeInstanceOf(BuilderAuthError);
  });

  it("returns the trusted membership for an allowed role", async () => {
    const lookup: BuilderMembershipLookup = async (siteKey, userId) => ({
      siteId: "site-uuid",
      siteKey,
      userId,
      email: "editor@example.com",
      role: "editor",
      previewGeneration: 7,
    });

    await expect(
      requireBuilderMember({
        client: claimsClient("user-1"),
        siteKey: "assembly",
        lookup,
        allowedRoles: ["owner", "editor"],
      }),
    ).resolves.toMatchObject({ userId: "user-1", role: "editor", previewGeneration: 7 });
  });
});
