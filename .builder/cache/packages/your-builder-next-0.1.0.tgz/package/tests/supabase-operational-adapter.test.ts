// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  OperationalRpcError,
  createSupabaseOperationalPersistence,
  type OperationalRpcClient,
} from "../src/operations/server/index.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const MEMBER_ID = "22222222-2222-4222-8222-222222222222";
const RESOURCE_ID = "33333333-3333-4333-8333-333333333333";
const COMMAND_ID = "44444444-4444-4444-8444-444444444444";

function client(data: unknown, error: unknown = null): OperationalRpcClient {
  return { rpc: vi.fn(async () => ({ data, error })) };
}

const actor = { type: "member" as const, id: MEMBER_ID };
const importCommand = {
  siteId: SITE_ID,
  actor,
  idempotencyKey: COMMAND_ID,
  submissionId: RESOURCE_ID,
  expectedLatestResultVersion: 2,
  aal2VerifiedAt: "2026-07-18T12:00:00.000Z",
};

describe("Supabase operational persistence", () => {
  it.each([
    [
      "createManualLead",
      "builder_create_manual_lead_v1",
      {
        siteId: SITE_ID,
        actor,
        idempotencyKey: COMMAND_ID,
        source: "phone",
        firstName: "Ana",
        lastName: "Morales",
        phone: "+19735550123",
        zipCode: "07105",
        service: "ac_repair",
        urgency: "urgent",
      },
      undefined,
      {
        version: 1,
        commandId: COMMAND_ID,
        siteId: SITE_ID,
        actorId: MEMBER_ID,
        idempotencyKey: COMMAND_ID,
        source: "phone",
        firstName: "Ana",
        lastName: "Morales",
        phone: "+19735550123",
        zipCode: "07105",
        service: "ac_repair",
        urgency: "urgent",
      },
    ],
    [
      "applyLeadCommand",
      "builder_apply_lead_command_v1",
      {
        siteId: SITE_ID,
        actor,
        idempotencyKey: COMMAND_ID,
        expectedVersion: 3,
        leadId: RESOURCE_ID,
        to: "contacted",
      },
      "status",
      {
        version: 1,
        commandId: COMMAND_ID,
        siteId: SITE_ID,
        actorId: MEMBER_ID,
        idempotencyKey: COMMAND_ID,
        expectedVersion: 3,
        leadId: RESOURCE_ID,
        action: "status",
        status: "contacted",
      },
    ],
    [
      "reviewFormSubmission",
      "builder_review_form_submission_v1",
      {
        siteId: SITE_ID,
        actor,
        idempotencyKey: COMMAND_ID,
        expectedVersion: 2,
        submissionId: RESOURCE_ID,
        reasonCode: "confirmed_spam",
      },
      "spam",
      {
        version: 1,
        commandId: COMMAND_ID,
        siteId: SITE_ID,
        actorId: MEMBER_ID,
        idempotencyKey: COMMAND_ID,
        expectedVersion: 2,
        submissionId: RESOURCE_ID,
        action: "spam",
        reasonCode: "confirmed_spam",
      },
    ],
    [
      "importFormSubmission",
      "builder_import_form_submission_v1",
      {
        siteId: SITE_ID,
        actor,
        idempotencyKey: COMMAND_ID,
        submissionId: RESOURCE_ID,
        expectedLatestResultVersion: 2,
        aal2VerifiedAt: "2026-07-18T12:00:00.000Z",
      },
      undefined,
      {
        version: 1,
        commandId: COMMAND_ID,
        siteId: SITE_ID,
        actorId: MEMBER_ID,
        idempotencyKey: COMMAND_ID,
        submissionId: RESOURCE_ID,
        expectedLatestResultVersion: 2,
        aal2VerifiedAt: "2026-07-18T12:00:00.000Z",
      },
    ],
  ] as const)("maps %s to %s with a server-built request", async (method, rpcName, command, operation, expectedRequest) => {
    const rpc = client({
      status: operation === "spam" ? "applied" : operation === undefined && method === "importFormSubmission" ? "imported" : operation === undefined ? "created" : "applied",
      leadId: RESOURCE_ID,
      submissionId: RESOURCE_ID,
      version: 4,
      resultVersion: 4,
      privateEmail: "must-not-escape@example.test",
    });
    const persistence = createSupabaseOperationalPersistence(rpc);

    const result = operation
      ? await (persistence[method] as Function)({ operation, command })
      : await (persistence[method] as Function)(command);

    expect(rpc.rpc).toHaveBeenCalledWith(rpcName, {
      p_request: expectedRequest,
    });
    expect(result).toEqual({
      status: "applied",
      resourceType: method === "reviewFormSubmission" ? "form_submission" : "lead",
      resourceId: RESOURCE_ID,
      version: 4,
      replayed: false,
    });
    expect(JSON.stringify(result)).not.toContain("privateEmail");
  });

  it("maps task and service-event parent versions without changing the frozen domain commands", async () => {
    const rpc = client({
      status: "created",
      taskId: RESOURCE_ID,
      serviceEventId: RESOURCE_ID,
      version: 1,
    });
    const persistence = createSupabaseOperationalPersistence(rpc);
    const task = {
      siteId: SITE_ID,
      actor,
      idempotencyKey: COMMAND_ID,
      relatedType: "lead" as const,
      relatedId: RESOURCE_ID,
      leadId: RESOURCE_ID,
      title: "Call customer",
      authorizationParents: [{ type: "lead" as const, id: RESOURCE_ID }],
      selfAssignmentIntent: true,
    };

    await persistence.createLeadTask({ expectedLeadVersion: 3, command: task });
    expect(rpc.rpc).toHaveBeenLastCalledWith("builder_create_lead_task_v1", {
      p_request: {
        version: 1,
        commandId: COMMAND_ID,
        siteId: SITE_ID,
        actorId: MEMBER_ID,
        idempotencyKey: COMMAND_ID,
        expectedVersion: 3,
        leadId: RESOURCE_ID,
        title: "Call customer",
      },
    });

    const serviceEvent = {
      siteId: SITE_ID,
      idempotencyKey: COMMAND_ID,
      contactId: RESOURCE_ID,
      leadId: RESOURCE_ID,
      kind: "appointment.scheduled" as const,
      purpose: "estimate" as const,
      occurredAt: "2026-07-18T12:00:00.000Z",
      correlationId: COMMAND_ID,
      origin: { type: "manual" as const, actor },
    };
    await persistence.recordLeadServiceEvent({ expectedLeadVersion: 3, command: serviceEvent });
    expect(rpc.rpc).toHaveBeenLastCalledWith("builder_record_lead_service_event_v1", {
      p_request: {
        version: 1,
        commandId: COMMAND_ID,
        siteId: SITE_ID,
        actorId: MEMBER_ID,
        idempotencyKey: COMMAND_ID,
        expectedVersion: 3,
        leadId: RESOURCE_ID,
        eventKind: "appointment.scheduled",
        purpose: "estimate",
        occurredAt: "2026-07-18T12:00:00.000Z",
      },
    });
  });

  it("projects SQL conflict and replay outcomes without returning private fields", async () => {
    const conflict = createSupabaseOperationalPersistence(client({ status: "conflict", version: 1, sql: "private" }));
    const replay = createSupabaseOperationalPersistence(client({ status: "replayed", leadId: RESOURCE_ID, version: 4, private: "secret" }));
    const command = {
      siteId: SITE_ID,
      actor,
      idempotencyKey: COMMAND_ID,
      expectedVersion: 2,
      leadId: RESOURCE_ID,
      to: "contacted" as const,
    };

    await expect(conflict.applyLeadCommand({ operation: "status", command })).resolves.toEqual({
      status: "conflict",
      expectedVersion: 2,
    });
    await expect(replay.applyLeadCommand({ operation: "status", command })).resolves.toEqual({
      status: "applied",
      resourceType: "lead",
      resourceId: RESOURCE_ID,
      version: 4,
      replayed: true,
    });
  });

  it.each([
    ["42501", "not_authorized"],
    ["22023", "invalid_request"],
  ] as const)("maps SQLSTATE %s to a safe denied result", async (code, reason) => {
    const persistence = createSupabaseOperationalPersistence(client(null, {
      code,
      message: "private SQL detail secret@example.test",
    }));
    await expect(persistence.importFormSubmission(importCommand)).resolves.toEqual({ status: "denied", reason });
  });

  it("maps provider errors and malformed output to safe errors without leaking details", async () => {
    const failed = createSupabaseOperationalPersistence(client(null, { message: "SQL email secret@example.test" }));
    const malformed = createSupabaseOperationalPersistence(client({ status: "created", leadId: "not-a-uuid" }));

    await expect(failed.importFormSubmission(importCommand)).rejects.toEqual(
      new OperationalRpcError("OPERATION_RPC_UNAVAILABLE"),
    );
    await expect(malformed.importFormSubmission(importCommand)).rejects.toEqual(
      new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE"),
    );
    await expect(failed.importFormSubmission(importCommand)).rejects.not.toThrow("secret@example.test");
  });
});
