// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  OperationalRpcError,
  createSupabaseOperationalPersistence,
  type OperationalRpcClient,
} from "../src/operations/server/index.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const MEMBER_ID = "22222222-2222-4222-8222-222222222222";
const RESOURCE_ID = "33333333-3333-4333-8333-333333333333";
const COMMAND_ID = "44444444-4444-4444-8444-444444444444";
const AAL2_AT = "2026-07-18T12:00:00.000Z";
const EMAIL_DIGEST = "b".repeat(64);
const TOKEN_HASH = "a".repeat(64);

function client(data: unknown, error: unknown = null): OperationalRpcClient {
  return { rpc: vi.fn(async () => ({ data, error })) };
}

const actor = { type: "member" as const, id: MEMBER_ID };

describe("remaining Supabase operational adapters", () => {
  it.each([
    ["updateCustomerProfile", "builder_update_customer_profile_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID, expectedVersion: 2, customerId: RESOURCE_ID,
      patch: { displayName: "Ana", preferredContactMethod: "phone", serviceAreaZip: "07105" },
    }, {
      version: 1, commandId: COMMAND_ID, siteId: SITE_ID, actorId: MEMBER_ID, idempotencyKey: COMMAND_ID,
      expectedVersion: 2, customerId: RESOURCE_ID,
      patch: { displayName: "Ana", preferredContactMethod: "phone", serviceAreaZip: "07105" },
    }, "customer"],
    ["reviewCustomerMerge", "builder_review_customer_merge_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID, expectedVersion: 2,
      suggestionId: RESOURCE_ID, decision: "accept",
    }, {
      version: 1, commandId: COMMAND_ID, siteId: SITE_ID, actorId: MEMBER_ID, idempotencyKey: COMMAND_ID,
      expectedVersion: 2, suggestionId: RESOURCE_ID, decision: "accept",
    }, "merge_suggestion"],
    ["executeCustomerMerge", "builder_execute_customer_merge_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID, suggestionId: RESOURCE_ID,
      expectedSuggestionVersion: 3, sourceId: "55555555-5555-4555-8555-555555555555",
      targetId: RESOURCE_ID, expectedSourceVersion: 2, expectedTargetVersion: 4,
    }, {
      version: 1, commandId: COMMAND_ID, siteId: SITE_ID, actorId: MEMBER_ID, idempotencyKey: COMMAND_ID,
      suggestionId: RESOURCE_ID, expectedSuggestionVersion: 3,
      sourceId: "55555555-5555-4555-8555-555555555555", targetId: RESOURCE_ID,
      expectedSourceVersion: 2, expectedTargetVersion: 4,
    }, "customer"],
    ["requestCustomerExport", "builder_request_customer_export_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID, customerIds: [RESOURCE_ID],
      filter: { lifecycleState: ["active"] }, aal2VerifiedAt: AAL2_AT,
    }, {
      version: 1, commandId: COMMAND_ID, siteId: SITE_ID, actorId: MEMBER_ID, idempotencyKey: COMMAND_ID,
      filters: { lifecycleState: ["active"], customerIds: [RESOURCE_ID] }, aal2VerifiedAt: AAL2_AT,
    }, "data_export"],
    ["requestCustomerDeletion", "builder_request_customer_deletion_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID, customerId: RESOURCE_ID,
      reason: "Verified request", aal2VerifiedAt: AAL2_AT,
    }, {
      version: 1, commandId: COMMAND_ID, siteId: SITE_ID, actorId: MEMBER_ID, idempotencyKey: COMMAND_ID,
      customerId: RESOURCE_ID, reason: "Verified request", aal2VerifiedAt: AAL2_AT,
    }, "deletion_request"],
    ["markNotificationRead", "builder_mark_notification_read_v1", {
      siteId: SITE_ID, notificationId: RESOURCE_ID, recipientMemberId: MEMBER_ID,
      readAt: AAL2_AT, idempotencyKey: COMMAND_ID,
    }, {
      version: 1, commandId: COMMAND_ID, siteId: SITE_ID, actorId: MEMBER_ID, idempotencyKey: COMMAND_ID,
      notificationId: RESOURCE_ID, readAt: AAL2_AT,
    }, "notification"],
    ["createMemberInvitation", "builder_create_member_invitation_v1", {
      siteId: SITE_ID, actorId: MEMBER_ID, idempotencyKey: COMMAND_ID,
      canonicalEmailDigest: EMAIL_DIGEST, tokenHash: TOKEN_HASH, templateId: "growth_staff_v1",
      templateVersion: 1, expiresAt: "2026-07-25T12:00:00.000Z", aal2VerifiedAt: AAL2_AT,
    }, {
      version: 1, commandId: COMMAND_ID, siteId: SITE_ID, actorId: MEMBER_ID, idempotencyKey: COMMAND_ID,
      canonicalEmailDigest: EMAIL_DIGEST, tokenHash: TOKEN_HASH, templateId: "growth_staff_v1",
      templateVersion: 1, expiresAt: "2026-07-25T12:00:00.000Z", aal2VerifiedAt: AAL2_AT,
    }, "member_invitation"],
    ["revokeMemberInvitation", "builder_revoke_member_invitation_v1", {
      siteId: SITE_ID, actorId: MEMBER_ID, invitationId: RESOURCE_ID, expectedVersion: 1,
      reason: "No longer required", idempotencyKey: COMMAND_ID, aal2VerifiedAt: AAL2_AT,
    }, {
      version: 1, commandId: COMMAND_ID, siteId: SITE_ID, actorId: MEMBER_ID, idempotencyKey: COMMAND_ID,
      invitationId: RESOURCE_ID, expectedVersion: 1, reason: "No longer required", aal2VerifiedAt: AAL2_AT,
    }, "member_invitation"],
    ["acceptMemberInvitation", "builder_accept_member_invitation_v1", {
      siteId: SITE_ID, authenticatedUserId: MEMBER_ID, canonicalEmailDigest: EMAIL_DIGEST,
      tokenHash: TOKEN_HASH, idempotencyKey: COMMAND_ID,
    }, {
      version: 1, commandId: COMMAND_ID, siteId: SITE_ID, authenticatedUserId: MEMBER_ID,
      canonicalEmailDigest: EMAIL_DIGEST, tokenHash: TOKEN_HASH, idempotencyKey: COMMAND_ID,
    }, "member"],
  ] as const)("maps %s to %s without leaking provider fields", async (method, rpcName, command, expected, resourceType) => {
    const rpc = client({
      status: "applied",
      customerId: RESOURCE_ID,
      suggestionId: RESOURCE_ID,
      exportId: RESOURCE_ID,
      deletionRequestId: RESOURCE_ID,
      notificationId: RESOURCE_ID,
      invitationId: RESOURCE_ID,
      memberId: RESOURCE_ID,
      version: 3,
      privateEmail: "secret@example.test",
    });
    const persistence = createSupabaseOperationalPersistence(rpc);

    const result = await (persistence[method] as Function)(command);

    expect(rpc.rpc).toHaveBeenCalledWith(rpcName, { p_request: expected });
    expect(result).toEqual({
      status: "applied",
      resourceType,
      resourceId: RESOURCE_ID,
      version: 3,
      replayed: false,
    });
    expect(JSON.stringify(result)).not.toContain("privateEmail");
  });

  it("sends no raw email or invitation token to the RPC client", async () => {
    const rpc = client({ status: "created", invitationId: RESOURCE_ID, version: 1 });
    const persistence = createSupabaseOperationalPersistence(rpc);
    await persistence.createMemberInvitation({
      siteId: SITE_ID,
      actorId: MEMBER_ID,
      idempotencyKey: COMMAND_ID,
      canonicalEmailDigest: EMAIL_DIGEST,
      tokenHash: TOKEN_HASH,
      templateId: "growth_staff_v1",
      templateVersion: 1,
      expiresAt: "2026-07-25T12:00:00.000Z",
      aal2VerifiedAt: AAL2_AT,
    });

    const serialized = JSON.stringify(vi.mocked(rpc.rpc).mock.calls);
    expect(serialized).not.toMatch(/secret@example|opaque-invitation-token/);
  });

  it.each([
    ["short digest", "abc", TOKEN_HASH],
    ["uppercase digest", "B".repeat(64), TOKEN_HASH],
    ["short token hash", EMAIL_DIGEST, "abc"],
    ["uppercase token hash", EMAIL_DIGEST, "A".repeat(64)],
  ])("rejects %s before invoking the invitation RPC", async (_name, canonicalEmailDigest, tokenHash) => {
    const rpc = client({ status: "created", invitationId: RESOURCE_ID, version: 1 });
    const persistence = createSupabaseOperationalPersistence(rpc);

    await expect(persistence.createMemberInvitation({
      siteId: SITE_ID,
      actorId: MEMBER_ID,
      idempotencyKey: COMMAND_ID,
      canonicalEmailDigest,
      tokenHash,
      templateId: "growth_staff_v1",
      templateVersion: 1,
      expiresAt: "2026-07-25T12:00:00.000Z",
      aal2VerifiedAt: AAL2_AT,
    })).rejects.toEqual(new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE"));
    expect(rpc.rpc).not.toHaveBeenCalled();
  });

  it("maps malformed remaining-operation responses to the stable safe error", async () => {
    const persistence = createSupabaseOperationalPersistence(client({ status: "applied", customerId: "not-a-uuid" }));
    await expect(persistence.updateCustomerProfile({
      siteId: SITE_ID,
      actor,
      idempotencyKey: COMMAND_ID,
      expectedVersion: 1,
      customerId: RESOURCE_ID,
      patch: { displayName: "Ana" },
    })).rejects.toEqual(new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE"));
  });
});
