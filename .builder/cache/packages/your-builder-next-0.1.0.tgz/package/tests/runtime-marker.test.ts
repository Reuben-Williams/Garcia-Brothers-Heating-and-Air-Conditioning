import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import * as controlPlane from "../src/control-plane/index.js";

const marker = {
  version: 1 as const,
  siteDataPlaneSiteId: "10000000-0000-4000-8000-000000000001",
  expectedSiteKey: "reviewed-site",
  installationManifestSha256: "a".repeat(64),
  configLoaderContract: "installation-client-config-v1" as const,
  durableStoreContract: "supabase-command-receipts-v1" as const,
  leaseContract: "site-installation-run-lease-v1" as const,
  leaseSeconds: 120,
  invocationTimeoutSeconds: 90,
  scheduledInvocationContract: "direct-in-process-v1" as const,
  handlerRegistrySha256: "b".repeat(64),
  workerVersion: "1.2.3",
  reachabilityEvidenceRevision: "deploy-abc123",
};

describe("site runtime marker", () => {
  it("generates manifest and handler-registry digests from reviewed inputs", () => {
    const create = (controlPlane as Record<string, unknown>).createSiteRuntimeMarker as
      | ((input: Record<string, unknown>) => Record<string, unknown>)
      | undefined;
    const registryDigest = (controlPlane as Record<string, unknown>).siteCommandHandlerRegistrySha256 as
      | ((handlers: readonly unknown[]) => string)
      | undefined;
    const handlers = [{
      type: "module.configure",
      version: 1,
      idempotency: "commandId",
      validate: () => ({}),
      execute: async () => ({ resultCode: "OK", evidence: {} }),
    }];
    const installationManifest = {
      version: 1,
      packages: { next: "0.1.0" },
      schemas: { posts: 1 },
      routes: ["/"],
      workerVersion: "1.2.3",
    };

    expect(create).toBeTypeOf("function");
    expect(registryDigest).toBeTypeOf("function");
    expect(create?.({
      siteDataPlaneSiteId: marker.siteDataPlaneSiteId,
      expectedSiteKey: marker.expectedSiteKey,
      installationManifest,
      handlers,
      leaseSeconds: 120,
      invocationTimeoutSeconds: 90,
      workerVersion: "1.2.3",
      reachabilityEvidenceRevision: "deploy-abc123",
    })).toEqual({
      ...marker,
      installationManifestSha256: expect.stringMatching(/^[a-f0-9]{64}$/),
      handlerRegistrySha256: registryDigest?.(handlers),
    });
  });

  it("accepts only the exact reviewed contract", () => {
    const parse = (controlPlane as Record<string, unknown>).parseSiteRuntimeMarker as
      | ((value: unknown) => unknown)
      | undefined;

    expect(parse).toBeTypeOf("function");
    expect(parse?.(marker)).toEqual(marker);
    expect(() => parse?.({ ...marker, controlPlaneUrl: "https://secret.example" }))
      .toThrow("invalid_site_runtime_marker");
  });

  it.each([
    ["invalid local UUID", { ...marker, siteDataPlaneSiteId: "central-installation" }],
    ["invalid site key", { ...marker, expectedSiteKey: "Reviewed Site" }],
    ["short lease", { ...marker, leaseSeconds: 59 }],
    ["long lease", { ...marker, leaseSeconds: 301 }],
    ["deadline equal to lease", { ...marker, invocationTimeoutSeconds: 120 }],
    ["noncanonical digest", { ...marker, handlerRegistrySha256: "B".repeat(64) }],
    ["worker without reachability", { ...marker, reachabilityEvidenceRevision: null }],
  ])("rejects %s", (_label, value) => {
    const parse = (controlPlane as Record<string, unknown>).parseSiteRuntimeMarker as
      | ((input: unknown) => unknown)
      | undefined;

    expect(parse).toBeTypeOf("function");
    expect(() => parse?.(value)).toThrow("invalid_site_runtime_marker");
  });

  it("allows an unreached runtime only when workerVersion is omitted", () => {
    const parse = (controlPlane as Record<string, unknown>).parseSiteRuntimeMarker as
      | ((value: unknown) => unknown)
      | undefined;
    const { workerVersion: _workerVersion, ...withoutWorker } = marker;

    expect(parse).toBeTypeOf("function");
    expect(parse?.({ ...withoutWorker, reachabilityEvidenceRevision: null })).toEqual({
      ...withoutWorker,
      reachabilityEvidenceRevision: null,
    });
  });

  it("rejects serialized markers larger than 32 KiB", () => {
    const parse = (controlPlane as Record<string, unknown>).parseSiteRuntimeMarker as
      | ((value: unknown) => unknown)
      | undefined;

    expect(parse).toBeTypeOf("function");
    expect(() => parse?.({
      ...marker,
      reachabilityEvidenceRevision: `deploy-${"x".repeat(33_000)}`,
    })).toThrow("invalid_site_runtime_marker");
  });
});
