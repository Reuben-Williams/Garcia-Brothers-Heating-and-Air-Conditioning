import { describe, expect, it, vi } from "vitest";
import { ContentConflictError } from "@your-builder/content";
import { createPostRouteHandlers, type PostRouteRepository } from "../src/content/post-route-handlers.js";

const member = {
  siteId: "site-uuid",
  siteKey: "assembly",
  userId: "user-1",
  email: "editor@example.com",
  role: "editor" as const,
  previewGeneration: 1,
};

function repository(): PostRouteRepository {
  return {
    listPosts: vi.fn(async () => []),
    getPost: vi.fn(async () => null),
    createPost: vi.fn(async (_context, payload) => ({ entryId: "entry-1", ...payload })),
    transitionPost: vi.fn(async (_context, operation) => ({ operation })),
    listVersions: vi.fn(async () => []),
    duplicatePost: vi.fn(async () => ({ entryId: "entry-copy" })),
    listTaxonomies: vi.fn(async () => []),
    saveTaxonomy: vi.fn(async (_context, payload) => payload),
  };
}

const jsonRequest = (url: string, method: string, body: unknown, headers?: HeadersInit) =>
  new Request(url, {
    method,
    headers: { "content-type": "application/json", ...headers },
    body: JSON.stringify(body),
  });

describe("post route handlers", () => {
  it("derives the site and user from the trusted request context", async () => {
    const repo = repository();
    const handlers = createPostRouteHandlers({
      repository: repo,
      resolveContext: async () => member,
    });

    const response = await handlers.handle(
      jsonRequest("https://site.test/api/builder/posts", "POST", { title: "Road repairs" }),
      ["posts"],
    );

    expect(response.status).toBe(201);
    expect(repo.createPost).toHaveBeenCalledWith(member, { title: "Road repairs" });
  });

  it("rejects request-supplied tenant identity", async () => {
    const repo = repository();
    const handlers = createPostRouteHandlers({ repository: repo, resolveContext: async () => member });

    const response = await handlers.handle(
      jsonRequest("https://site.test/api/builder/posts", "POST", {
        title: "Road repairs",
        siteId: "attacker-site",
      }),
      ["posts"],
    );

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({ error: { code: "TENANT_IDENTITY_FORBIDDEN" } });
    expect(repo.createPost).not.toHaveBeenCalled();
  });

  it("prevents contributors from publishing", async () => {
    const repo = repository();
    const handlers = createPostRouteHandlers({
      repository: repo,
      resolveContext: async () => ({ ...member, role: "contributor" }),
    });

    const response = await handlers.handle(
      jsonRequest(
        "https://site.test/api/builder/posts/entry-1/publish",
        "POST",
        { expectedDraftVersionId: "draft-1", expectedPublishedVersionId: null },
        { "x-idempotency-key": "publish-request-1" },
      ),
      ["posts", "entry-1", "publish"],
    );

    expect(response.status).toBe(403);
    expect(repo.transitionPost).not.toHaveBeenCalled();
  });

  it("runs CSRF and rate-limit hooks before a mutation", async () => {
    const repo = repository();
    const verifyCsrf = vi.fn(async () => undefined);
    const rateLimit = vi.fn(async () => undefined);
    const handlers = createPostRouteHandlers({
      repository: repo,
      resolveContext: async () => member,
      verifyCsrf,
      rateLimit,
    });
    const request = jsonRequest(
      "https://site.test/api/builder/posts/entry-1/publish",
      "POST",
      { expectedDraftVersionId: "draft-1", expectedPublishedVersionId: null },
      { "x-idempotency-key": "publish-request-1" },
    );

    const response = await handlers.handle(request, ["posts", "entry-1", "publish"]);

    expect(response.status).toBe(200);
    expect(verifyCsrf).toHaveBeenCalledWith(request, member);
    expect(rateLimit).toHaveBeenCalledWith(request, member, "post.publish");
  });

  it("returns a stable conflict payload", async () => {
    const repo = repository();
    vi.mocked(repo.transitionPost).mockRejectedValueOnce(new ContentConflictError("Draft changed"));
    const handlers = createPostRouteHandlers({ repository: repo, resolveContext: async () => member });

    const response = await handlers.handle(
      jsonRequest(
        "https://site.test/api/builder/posts/entry-1/publish",
        "POST",
        { expectedDraftVersionId: "draft-1", expectedPublishedVersionId: null },
        { "x-idempotency-key": "publish-request-1" },
      ),
      ["posts", "entry-1", "publish"],
    );

    expect(response.status).toBe(409);
    await expect(response.json()).resolves.toEqual({
      error: { code: "CONTENT_VERSION_CONFLICT", message: "Draft changed" },
    });
  });

  it("requires an idempotency key for lifecycle transitions", async () => {
    const handlers = createPostRouteHandlers({ repository: repository(), resolveContext: async () => member });
    const response = await handlers.handle(
      jsonRequest("https://site.test/api/builder/posts/entry-1/archive", "POST", {}),
      ["posts", "entry-1", "archive"],
    );

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({ error: { code: "IDEMPOTENCY_KEY_REQUIRED" } });
  });
});
