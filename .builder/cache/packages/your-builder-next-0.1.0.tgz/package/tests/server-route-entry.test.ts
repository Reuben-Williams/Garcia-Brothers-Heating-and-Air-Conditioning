import { describe, expect, it } from "vitest";

import { createInMemoryAdapter, defineBuilderSite } from "@your-builder/core";
import { createBuilderRouteHandlers } from "@your-builder/next/routes";

describe("server route-handler entry point", () => {
  it("creates builder handlers without importing the client component entry", async () => {
    const site = defineBuilderSite({
      siteId: "server-route-contract",
      adapter: "memory",
      pages: [{ path: "/", label: "Home", regions: [] }],
      sections: {},
    });
    const handlers = createBuilderRouteHandlers({ site, adapter: createInMemoryAdapter() });

    const response = await handlers.GET(new Request("http://fixture.test/api/builder?path=/"));

    expect(response.status).toBe(200);
    expect(await response.json()).toEqual({ path: "/", regions: {} });
  });
});
