// @vitest-environment node

import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { describe, expect, it } from "vitest";

describe("ingestion server boundary", () => {
  it("poisons client imports of provider and route implementations", async () => {
    await expect(import("./fixtures/ingestion-server-client-entry.js")).rejects.toThrow(
      "This module cannot be imported from a Client Component module",
    );
  });

  it("keeps contracts transport-neutral and exposes implementations only from the server subpath", async () => {
    const contractsEntry = await readFile(resolve("packages/next/src/ingestion/index.ts"), "utf8");
    const serverEntry = await readFile(resolve("packages/next/src/ingestion/server/index.ts"), "utf8");
    const rootEntry = await readFile(resolve("packages/next/src/index.tsx"), "utf8");
    const packageManifest = JSON.parse(await readFile(resolve("packages/next/package.json"), "utf8"));

    expect(contractsEntry).toBe('export * from "./contracts.js";\n');
    expect(contractsEntry).not.toContain("server-only");
    expect(serverEntry.startsWith('import "server-only";')).toBe(true);
    expect(serverEntry).not.toContain("./contracts");
    expect(rootEntry).not.toContain("./ingestion");
    expect(packageManifest.exports["./ingestion"]).toEqual({
      types: "./src/ingestion/index.ts",
      default: "./src/ingestion/index.ts",
    });
    expect(packageManifest.exports["./ingestion/server"]).toEqual({
      types: "./src/ingestion/server/index.ts",
      default: "./src/ingestion/server/index.ts",
    });
  });
});
