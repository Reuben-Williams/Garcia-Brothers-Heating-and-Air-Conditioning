// @vitest-environment node

import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

import {
  GROWTH_INGESTION_CONTRACT_VERSION,
  type GrowthIngestionCommand,
  type GrowthIngestionOutcome,
  type PublicIngestionAcceptance,
} from "../src/ingestion/index.js";

describe("Next growth ingestion contracts", () => {
  it("defines transport-neutral verified input and generic persistence outcomes", () => {
    const command: GrowthIngestionCommand<{ name: string }, { evidenceId: string }> = {
      version: 1,
      siteId: "11111111-1111-4111-8111-111111111111",
      formId: "service-request",
      idempotencyKey: "submission-0001",
      submittedAt: "2026-07-18T12:00:00.000Z",
      zipCode: "19713",
      payload: { name: "Synthetic Customer" },
      consentEvidence: { evidenceId: "consent-0001" },
      securityReceiptId: "33333333-3333-4333-8333-333333333333",
    };
    const outcome: GrowthIngestionOutcome<{ id: string }, { leadId: string }> = {
      kind: "enhanced",
      baseSubmission: { id: "base-1" },
      enhancedResult: { leadId: "lead-1" },
    };
    const response: PublicIngestionAcceptance = {
      version: 1,
      accepted: true,
      receiptId: "44444444-4444-4444-8444-444444444444",
      result: "accepted",
    };

    expect(GROWTH_INGESTION_CONTRACT_VERSION).toBe(1);
    expect(command.securityReceiptId).toBeTruthy();
    expect(outcome.kind).toBe("enhanced");
    expect(response).not.toHaveProperty("enhanced");
    expect(response).not.toHaveProperty("contactId");
  });

  it("represents base-only, safe review, and replay without HTTP objects", () => {
    const outcomes: readonly GrowthIngestionOutcome<{ id: string }, never>[] = [
      { kind: "base_only", baseSubmission: { id: "base-1" }, safeCode: "growth_unavailable" },
      { kind: "review", baseSubmission: { id: "base-2" }, safeCode: "identity_conflict" },
      { kind: "replay", baseSubmission: { id: "base-3" }, safeCode: "accepted" },
    ];

    expect(outcomes.map((outcome) => outcome.kind)).toEqual(["base_only", "review", "replay"]);
    const source = readFileSync(
      fileURLToPath(new URL("../src/ingestion/contracts.ts", import.meta.url)),
      "utf8",
    );
    expect(source).not.toMatch(/\bRequest\b|\bResponse\b|NextRequest|NextResponse/);
    expect(source).not.toMatch(/turnstileToken|ipAddress|trustedNetwork/);
    expect(source).not.toMatch(/from ["']react/);
  });
});
