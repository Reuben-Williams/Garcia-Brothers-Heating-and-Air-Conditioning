import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import type { PublishedPost } from "@your-builder/content";
import { PostCollection, loadPostCollection, loadPostEntry } from "@your-builder/next/content";

const fallback: PublishedPost = {
  entryId: "06a80923-d9a6-4e46-8e7b-c7a475f7a915",
  versionId: "cc507952-6095-4813-87ec-fcd70bf0baea",
  slug: "fallback-notice",
  title: "Fallback notice",
  excerpt: "Fallback excerpt",
  categoryKeys: ["notice"],
  tagKeys: [],
  displayDate: "2026-07-10T12:00:00.000Z",
  versionPublishedAt: "2026-07-10T12:00:00.000Z",
  expiresAt: null,
  featured: false,
  pinned: false,
};

const query = {
  categoryKeys: ["notice"], tagKeys: [], entryIds: [], featuredOnly: false,
  pinnedFirst: false, limit: 4, orderBy: "displayDate" as const, orderDirection: "desc" as const,
};

describe("post source cutover rendering", () => {
  it("keeps typed fallback authoritative before cutover", async () => {
    const repository = { listPublishedPosts: vi.fn().mockResolvedValue([{ ...fallback, title: "Live" }]) };
    const result = await loadPostCollection({
      siteKey: "assembly",
      scope: { key: "announcements", contentSource: "fallback", entryIds: [fallback.entryId] },
      fallbackEntries: [fallback], query, repository,
    });
    expect(result).toEqual({ status: "ready", posts: [fallback] });
    expect(repository.listPublishedPosts).not.toHaveBeenCalled();
  });

  it("loads authorized drafts in preview mode without changing the public fallback source", async () => {
    const draft = { ...fallback, versionId: "52a8e601-b402-4c8b-afdd-4b8e79cb79f6", title: "Draft headline" };
    const repository = {
      listPublishedPosts: vi.fn(),
      listDraftPosts: vi.fn().mockResolvedValue([draft]),
    };
    const result = await loadPostCollection({
      siteKey: "assembly",
      scope: { key: "announcements", contentSource: "fallback", entryIds: [fallback.entryId] },
      fallbackEntries: [fallback],
      query,
      repository,
      previewMode: true,
    });

    expect(result).toEqual({ status: "ready", posts: [draft] });
    expect(repository.listDraftPosts).toHaveBeenCalledWith("assembly", query);
    expect(repository.listPublishedPosts).not.toHaveBeenCalled();
  });

  it("fails closed after cutover instead of resurrecting fallback posts", async () => {
    const result = await loadPostCollection({
      siteKey: "assembly",
      scope: { key: "announcements", contentSource: "live", entryIds: [fallback.entryId] },
      fallbackEntries: [fallback], query,
      repository: { listPublishedPosts: vi.fn().mockRejectedValue(new Error("offline")) },
    });
    expect(result).toEqual({ status: "unavailable", posts: [] });
  });

  it("distinguishes a successful empty live result from an outage", async () => {
    const html = renderToStaticMarkup(
      await PostCollection({
        id: "home.announcements", siteKey: "assembly",
        scope: { key: "announcements", contentSource: "live", entryIds: [] },
        fallbackEntries: [], query,
        repository: { listPublishedPosts: vi.fn().mockResolvedValue([]) },
        render: (post) => <article>{post.title}</article>,
        renderEmpty: () => <p>No announcements.</p>,
        renderUnavailable: () => <p>Announcements temporarily unavailable.</p>,
      }),
    );
    expect(html).toContain("No announcements.");
    expect(html).not.toContain("temporarily unavailable");
  });

  it("adds stable entry metadata directly to site-owned cards in preview mode", async () => {
    const html = renderToStaticMarkup(
      await PostCollection({
        id: "home.announcements", siteKey: "assembly",
        scope: { key: "announcements", contentSource: "fallback", entryIds: [fallback.entryId] },
        fallbackEntries: [fallback], query,
        repository: { listPublishedPosts: vi.fn() },
        render: (post) => <article>{post.title}</article>,
        renderEmpty: () => null,
        renderUnavailable: () => null,
        previewMode: true,
      }),
    );

    expect(html).toContain(`data-builder-entry-id="${fallback.entryId}"`);
    expect(html).toContain('data-builder-content-type="post"');
    expect(html).toContain('data-builder-region="home.announcements"');
    expect(html.match(/<article/g)).toHaveLength(1);
  });

  it("returns a 503 contract for live detail outages", async () => {
    const result = await loadPostEntry({
      siteKey: "assembly", slug: fallback.slug,
      scopes: [{ key: "announcements", contentSource: "live", entryIds: [fallback.entryId] }],
      fallbackEntries: [fallback],
      repository: { getPublishedPostBySlug: vi.fn().mockRejectedValue(new Error("offline")) },
    });
    expect(result).toMatchObject({ status: "unavailable", httpStatus: 503, retryAfter: 60 });
  });

  it("loads an authorized draft detail before evaluating the fallback source", async () => {
    const draft = { ...fallback, title: "Draft detail" };
    const result = await loadPostEntry({
      siteKey: "assembly",
      slug: fallback.slug,
      scopes: [{ key: "announcements", contentSource: "fallback", entryIds: [fallback.entryId] }],
      fallbackEntries: [fallback],
      repository: {
        getPublishedPostBySlug: vi.fn(),
        getDraftPostBySlug: vi.fn().mockResolvedValue(draft),
      },
      previewMode: true,
    });
    expect(result).toEqual({ status: "ready", post: draft });
  });
});
