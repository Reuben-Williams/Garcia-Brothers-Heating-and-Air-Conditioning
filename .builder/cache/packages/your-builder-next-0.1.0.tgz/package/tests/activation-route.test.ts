import { describe, expect, it, vi } from "vitest";
import type { InstallationClient } from "../src/control-plane/installation-client.js";
import {
  createActivationRouteHandler,
  type ActivationRouteDependencies,
} from "../src/entitlements/activation-route.js";

vi.mock("server-only", () => ({}));

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const INSTALLATION_ID = "22222222-2222-4222-8222-222222222222";
const COMMAND_ID = "33333333-3333-4333-8333-333333333333";
const CENTRAL_REQUEST_ID = "44444444-4444-4444-8444-444444444444";
const CORRELATION_ID = "55555555-5555-4555-8555-555555555555";

const member = {
  siteId: SITE_ID,
  siteKey: "assembly",
  userId: "owner-1",
  email: "owner@example.test",
  role: "owner" as const,
  previewGeneration: 1,
};

function dependencies(overrides: Partial<ActivationRouteDependencies> = {}): ActivationRouteDependencies {
  return {
    resolveContext: vi.fn(async () => member),
    verifyCsrf: vi.fn(async () => undefined),
    rateLimit: vi.fn(async () => undefined),
    installationId: INSTALLATION_ID,
    loadSnapshot: vi.fn(async () => ({
      status: "fresh" as const,
      siteId: SITE_ID,
      installationId: INSTALLATION_ID,
      moduleState: "available" as const,
    })),
    installationClient: {
      requestActivation: vi.fn(async () => ({
        requestId: CENTRAL_REQUEST_ID,
        moduleId: "growth.leads" as const,
        status: "requested" as const,
        entitlementState: "requested" as const,
        idempotent: false,
      })),
    } as Pick<InstallationClient, "requestActivation">,
    now: () => new Date("2026-01-15T12:00:00.000Z"),
    correlationId: () => CORRELATION_ID,
    audit: vi.fn(async () => undefined),
    ...overrides,
  };
}

function request(method: "POST" | "DELETE", body: Record<string, unknown>) {
  return new Request("https://site.test/api/builder/entitlements/activation", {
    method,
    headers: {
      "content-type": "application/json",
      "x-builder-csrf": "csrf-1",
      "x-idempotency-key": String(body.requestId ?? ""),
    },
    body: JSON.stringify(body),
  });
}

const body = {
  siteId: SITE_ID,
  moduleId: "growth.leads",
  requestId: COMMAND_ID,
  note: "Please enable this for our front desk.",
};

describe("activation route", () => {
  it("authorizes the owner, verifies the site binding, and signs a create request", async () => {
    const deps = dependencies();
    const response = await createActivationRouteHandler(deps).handle(request("POST", body));

    expect(response.status).toBe(200);
    expect(deps.verifyCsrf).toHaveBeenCalledWith(expect.any(Request), member);
    expect(deps.rateLimit).toHaveBeenCalledWith(expect.any(Request), member, "billing.manage");
    expect(deps.installationClient.requestActivation).toHaveBeenCalledWith({
      commandId: COMMAND_ID,
      action: "create",
      moduleId: "growth.leads",
    });
    await expect(response.json()).resolves.toEqual({
      state: "requested",
      requestId: CENTRAL_REQUEST_ID,
      updatedAt: "2026-01-15T12:00:00.000Z",
      withdrawalAllowed: true,
      correlationId: CORRELATION_ID,
    });
    expect(deps.audit).toHaveBeenCalledWith(expect.objectContaining({
      correlationId: CORRELATION_ID,
      siteId: SITE_ID,
      actorId: "owner-1",
      action: "create",
      note: body.note,
    }));
  });

  it("rejects non-owners before calling the installation client", async () => {
    const deps = dependencies({ resolveContext: async () => ({ ...member, role: "editor" }) });
    const response = await createActivationRouteHandler(deps).handle(request("POST", body));
    expect(response.status).toBe(403);
    expect(deps.installationClient.requestActivation).not.toHaveBeenCalled();
  });

  it.each([
    [{ status: "stale", siteId: SITE_ID, installationId: INSTALLATION_ID, moduleState: "available" }, "ENTITLEMENT_SNAPSHOT_STALE"],
    [{ status: "fresh", siteId: "99999999-9999-4999-8999-999999999999", installationId: INSTALLATION_ID, moduleState: "available" }, "ENTITLEMENT_SCOPE_MISMATCH"],
    [{ status: "fresh", siteId: SITE_ID, installationId: "99999999-9999-4999-8999-999999999999", moduleState: "available" }, "ENTITLEMENT_SCOPE_MISMATCH"],
  ] as const)("fails closed for an invalid snapshot boundary", async (snapshot, code) => {
    const deps = dependencies({ loadSnapshot: async () => snapshot });
    const response = await createActivationRouteHandler(deps).handle(request("POST", body));
    expect(response.status).toBe(409);
    await expect(response.json()).resolves.toMatchObject({ error: { code } });
    expect(deps.installationClient.requestActivation).not.toHaveBeenCalled();
  });

  it("returns an idempotent duplicate as the current requested state", async () => {
    const deps = dependencies();
    vi.mocked(deps.installationClient.requestActivation).mockResolvedValueOnce({
      requestId: CENTRAL_REQUEST_ID,
      moduleId: "growth.leads",
      status: "requested",
      entitlementState: "requested",
      idempotent: true,
    });
    const response = await createActivationRouteHandler(deps).handle(request("POST", body));
    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toMatchObject({ state: "requested", requestId: CENTRAL_REQUEST_ID });
  });

  it("allows withdrawal only while the snapshot is requested", async () => {
    const deniedDeps = dependencies();
    const denied = await createActivationRouteHandler(deniedDeps).handle(request("DELETE", body));
    expect(denied.status).toBe(409);
    expect(deniedDeps.installationClient.requestActivation).not.toHaveBeenCalled();

    const allowedDeps = dependencies({
      loadSnapshot: async () => ({
        status: "fresh",
        siteId: SITE_ID,
        installationId: INSTALLATION_ID,
        moduleState: "requested",
      }),
    });
    vi.mocked(allowedDeps.installationClient.requestActivation).mockResolvedValueOnce({
      requestId: CENTRAL_REQUEST_ID,
      moduleId: "growth.leads",
      status: "withdrawn",
      entitlementState: "request_withdrawn",
      idempotent: false,
    });
    const allowed = await createActivationRouteHandler(allowedDeps).handle(request("DELETE", body));
    expect(allowed.status).toBe(200);
    expect(allowedDeps.installationClient.requestActivation).toHaveBeenCalledWith({
      commandId: COMMAND_ID,
      action: "withdraw",
      moduleId: "growth.leads",
    });
    await expect(allowed.json()).resolves.toMatchObject({ state: "request_withdrawn", withdrawalAllowed: false });
  });

  it("returns a generic correlated error without exposing control-plane details", async () => {
    const deps = dependencies();
    vi.mocked(deps.installationClient.requestActivation).mockRejectedValueOnce(
      new Error("private installation credential detail"),
    );
    const response = await createActivationRouteHandler(deps).handle(request("POST", body));
    expect(response.status).toBe(503);
    const text = await response.text();
    expect(text).toContain("ACTIVATION_UNAVAILABLE");
    expect(text).toContain(CORRELATION_ID);
    expect(text).not.toContain("credential");
  });

  it("enforces the exact route, JSON media type, idempotency binding, and body limit", async () => {
    const deps = dependencies();
    const wrongTarget = request("POST", body);
    Object.defineProperty(wrongTarget, "url", { value: "https://site.test/api/builder/entitlements/activation?debug=1" });
    expect((await createActivationRouteHandler(deps).handle(wrongTarget)).status).toBe(400);

    const wrongMedia = new Request("https://site.test/api/builder/entitlements/activation", {
      method: "POST",
      headers: { "content-type": "text/plain", "x-idempotency-key": COMMAND_ID },
      body: JSON.stringify(body),
    });
    expect((await createActivationRouteHandler(deps).handle(wrongMedia)).status).toBe(415);

    const mismatchedKey = new Request("https://site.test/api/builder/entitlements/activation", {
      method: "POST",
      headers: { "content-type": "application/json", "x-idempotency-key": CORRELATION_ID },
      body: JSON.stringify(body),
    });
    const mismatchResponse = await createActivationRouteHandler(deps).handle(mismatchedKey);
    expect(mismatchResponse.status).toBe(400);
    await expect(mismatchResponse.json()).resolves.toMatchObject({ error: { code: "IDEMPOTENCY_KEY_MISMATCH" } });

    const oversized = request("POST", { ...body, note: "x".repeat(9_000) });
    expect((await createActivationRouteHandler(deps).handle(oversized)).status).toBe(413);
    expect(deps.installationClient.requestActivation).not.toHaveBeenCalled();
  });
});
