import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  CommandExecutionConflictError,
  CommandExecutionOwnershipError,
  createInstallationWorker,
  type CommandExecutionResult,
  type CommandExecutionStore,
  type InstallationCommandEnvelope,
} from "../src/control-plane/index.js";

const INSTALLATION_ID = "11111111-1111-4111-8111-111111111111";
const NOW = new Date("2026-07-16T12:00:00.000Z");

function command(override: Partial<InstallationCommandEnvelope> = {}): InstallationCommandEnvelope {
  return {
    id: "22222222-2222-4222-8222-222222222222",
    type: "module.install",
    version: 1,
    payload: { moduleId: "reviews" },
    idempotencyKey: "install-reviews-v1",
    createdAt: "2026-07-16T11:59:00.000Z",
    leaseToken: "33333333-3333-4333-8333-333333333333",
    attempt: 1,
    leaseExpiresAt: "2026-07-16T12:00:30.000Z",
    ...override,
  };
}

function result(outcome: "succeeded" | "failed" | "retry" = "succeeded"): CommandExecutionResult {
  const evidence = { version: 1 as const, codes: [], metrics: {}, flags: {}, digests: {} };
  if (outcome === "succeeded") return { outcome, resultCode: "MODULE_INSTALLED", evidence };
  if (outcome === "failed") return { outcome, errorCode: "MODULE_INSTALL_FAILED", evidence };
  return {
    outcome,
    errorCode: "MODULE_INSTALL_RETRY",
    retryAt: "2026-07-16T12:01:00.000Z",
    evidence,
  };
}

function store(overrides: Partial<CommandExecutionStore> = {}): CommandExecutionStore {
  return {
    reserve: vi.fn(async () => ({ status: "acquired" as const, generation: 1 })),
    complete: vi.fn(async () => true),
    release: vi.fn(async () => true),
    ...overrides,
  };
}

function worker(input: {
  commands: InstallationCommandEnvelope[];
  store: CommandExecutionStore;
  execute?: (input: {
    commandId: string;
    idempotencyKey: string;
    attempt: number;
    payload: Record<string, unknown>;
  }) => Promise<CommandExecutionResult>;
  acknowledgeResult?: ReturnType<typeof vi.fn>;
  now?: () => Date;
  executionToken?: () => string;
}) {
  const acknowledgeResult = input.acknowledgeResult ?? vi.fn(async () => undefined);
  const execute = vi.fn(input.execute ?? (async () => result()));
  return {
    execute,
    acknowledgeResult,
    value: createInstallationWorker({
      installationId: INSTALLATION_ID,
      client: { pullCommands: vi.fn(async () => input.commands), acknowledgeResult },
      store: input.store,
      handlers: [{ type: "module.install", version: 1, execute }],
      now: input.now ?? (() => NOW),
      executionToken: input.executionToken ?? (() => "execution-token-1"),
      reservationSeconds: 20,
    }),
  };
}

describe("installation command worker", () => {
  it("reserves with attempt ownership before executing and completes before ack", async () => {
    const events: string[] = [];
    const executionStore = store({
      reserve: vi.fn(async () => {
        events.push("reserve");
        return { status: "acquired" as const, generation: 7 };
      }),
      complete: vi.fn(async () => {
        events.push("complete");
        return true;
      }),
    });
    const acknowledgeResult = vi.fn(async () => events.push("ack"));
    const subject = worker({
      commands: [command()],
      store: executionStore,
      execute: async (handlerInput) => {
        events.push("execute");
        expect(handlerInput).toMatchObject({
          commandId: command().id,
          idempotencyKey: command().idempotencyKey,
          attempt: 1,
        });
        return result();
      },
      acknowledgeResult,
    });

    await subject.value.runOnce();

    expect(events).toEqual(["reserve", "execute", "complete", "ack"]);
    expect(executionStore.reserve).toHaveBeenCalledWith({
      installationId: INSTALLATION_ID,
      idempotencyKey: command().idempotencyKey,
      commandId: command().id,
      semanticDigest: expect.stringMatching(/^[a-f0-9]{64}$/),
      attempt: 1,
      executionToken: "execution-token-1",
      reservationExpiresAt: "2026-07-16T12:00:20.000Z",
    });
    expect(executionStore.complete).toHaveBeenCalledWith(expect.objectContaining({
      generation: 7,
      executionToken: "execution-token-1",
      attempt: 1,
      result: result(),
    }));
  });

  it("bounds ownership expiry by the command lease", async () => {
    const executionStore = store();
    const subject = worker({
      commands: [command({ leaseExpiresAt: "2026-07-16T12:00:05.000Z" })],
      store: executionStore,
    });

    await subject.value.runOnce();

    expect(executionStore.reserve).toHaveBeenCalledWith(expect.objectContaining({
      reservationExpiresAt: "2026-07-16T12:00:05.000Z",
    }));
  });

  it.each([
    ["at the exact boundary", "2026-07-16T12:00:00.000Z"],
    ["after expiry", "2026-07-16T11:59:59.999Z"],
  ])("skips a command whose lease is expired %s before reserving", async (_label, leaseExpiresAt) => {
    const executionStore = store();
    const subject = worker({
      commands: [command({ leaseExpiresAt })],
      store: executionStore,
    });

    await expect(subject.value.runOnce()).resolves.toEqual({ pulled: 1, acknowledged: 0 });
    expect(executionStore.reserve).not.toHaveBeenCalled();
    expect(executionStore.complete).not.toHaveBeenCalled();
    expect(subject.execute).not.toHaveBeenCalled();
    expect(subject.acknowledgeResult).not.toHaveBeenCalled();
  });

  it("does not execute or ack an unexpired in-progress attempt", async () => {
    const subject = worker({
      commands: [command()],
      store: store({ reserve: vi.fn(async () => ({ status: "in_progress" as const })) }),
    });

    await expect(subject.value.runOnce()).resolves.toEqual({ pulled: 1, acknowledged: 0 });
    expect(subject.execute).not.toHaveBeenCalled();
    expect(subject.acknowledgeResult).not.toHaveBeenCalled();
  });

  it("reuses a completed retry result for the same attempt after a lost ack", async () => {
    const persisted = result("retry");
    const subject = worker({
      commands: [command()],
      store: store({
        reserve: vi.fn(async () => ({ status: "attempt_completed" as const, result: persisted })),
      }),
    });

    await subject.value.runOnce();

    expect(subject.execute).not.toHaveBeenCalled();
    expect(subject.acknowledgeResult).toHaveBeenCalledWith({
      commandId: command().id,
      attempt: 1,
      leaseToken: command().leaseToken,
      ...persisted,
    });
  });

  it("executes a higher attempt after a persisted retry result", async () => {
    const executionStore = store({
      reserve: vi.fn(async () => ({ status: "acquired" as const, generation: 2 })),
    });
    const subject = worker({
      commands: [command({ attempt: 2 })],
      store: executionStore,
    });

    await subject.value.runOnce();

    expect(subject.execute).toHaveBeenCalledWith(expect.objectContaining({ attempt: 2 }));
    expect(executionStore.complete).toHaveBeenCalledWith(expect.objectContaining({ attempt: 2 }));
  });

  it.each(["succeeded", "failed"] as const)(
    "reuses a terminal %s result across later attempts",
    async (outcome) => {
      const persisted = result(outcome);
      const subject = worker({
        commands: [command({ attempt: 4 })],
        store: store({
          reserve: vi.fn(async () => ({ status: "terminal_completed" as const, result: persisted })),
        }),
      });

      await subject.value.runOnce();

      expect(subject.execute).not.toHaveBeenCalled();
      expect(subject.acknowledgeResult).toHaveBeenCalledWith(expect.objectContaining({
        attempt: 4,
        ...persisted,
      }));
    },
  );

  it("fails closed when type or version changes under one idempotency key", async () => {
    const digests: string[] = [];
    const executionStore = store({
      reserve: vi.fn(async (input) => {
        digests.push(input.semanticDigest);
        return digests.length < 3
          ? { status: "in_progress" as const }
          : { status: "conflict" as const };
      }),
    });
    const subject = worker({
      commands: [
        command(),
        command({ type: "module.remove" }),
        command({ version: 2 }),
      ],
      store: executionStore,
    });

    await expect(subject.value.runOnce()).rejects.toBeInstanceOf(CommandExecutionConflictError);
    expect(new Set(digests).size).toBe(3);
  });

  it("rejects completion by a stale owner and does not acknowledge it", async () => {
    const executionStore = store({ complete: vi.fn(async () => false) });
    const subject = worker({ commands: [command()], store: executionStore });

    await expect(subject.value.runOnce()).rejects.toBeInstanceOf(CommandExecutionOwnershipError);
    expect(subject.acknowledgeResult).not.toHaveBeenCalled();
  });

  it.each([
    ["unknown type", command({ type: "module.remove" }), "UNSUPPORTED_COMMAND_TYPE"],
    ["unknown version", command({ version: 2 }), "UNSUPPORTED_COMMAND_VERSION"],
  ])("terminally persists and acknowledges %s", async (_label, nextCommand, errorCode) => {
    const executionStore = store();
    const subject = worker({ commands: [nextCommand], store: executionStore });

    await subject.value.runOnce();

    expect(subject.execute).not.toHaveBeenCalled();
    expect(executionStore.complete).toHaveBeenCalledWith(expect.objectContaining({
      result: expect.objectContaining({ outcome: "failed", errorCode }),
    }));
    expect(subject.acknowledgeResult).toHaveBeenCalledWith(expect.objectContaining({ errorCode }));
  });

  it("reclaims an expired crash reservation through a new generation", async () => {
    const executionStore = store({
      reserve: vi.fn()
        .mockResolvedValueOnce({ status: "in_progress" as const })
        .mockResolvedValueOnce({ status: "acquired" as const, generation: 9 }),
    });
    const subject = worker({ commands: [command()], store: executionStore });

    await subject.value.runOnce();
    await subject.value.runOnce();

    expect(subject.execute).toHaveBeenCalledOnce();
    expect(executionStore.complete).toHaveBeenCalledWith(expect.objectContaining({ generation: 9 }));
  });

  it("exposes a wake hook with no executable command input", async () => {
    const subject = worker({ commands: [], store: store() });
    expect(subject.value.wake.length).toBe(0);
    await subject.value.wake();
  });
});
