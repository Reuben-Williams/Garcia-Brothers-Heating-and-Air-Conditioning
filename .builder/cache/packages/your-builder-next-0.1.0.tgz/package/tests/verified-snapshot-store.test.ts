// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import type { EntitlementSnapshot } from "@your-builder/entitlements";
import {
  VERIFIED_SNAPSHOT_STORE_RPC,
  VerifiedSnapshotStoreError,
  createSupabaseVerifiedSnapshotStore,
} from "../src/entitlements/verified-snapshot-store.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const INSTALLATION_ID = "22222222-2222-4222-8222-222222222222";
const SNAPSHOT_ID = "33333333-3333-4333-8333-333333333333";
const DIGEST = "a".repeat(64);

function snapshot(sequence = 9): EntitlementSnapshot {
  const module = { state: "active" as const, moduleVersion: "1.0.0", setupComplete: true };
  return {
    version: 1,
    siteId: SITE_ID,
    installationId: INSTALLATION_ID,
    issuedAt: "2026-07-18T12:00:00.000Z",
    expiresAt: "2026-07-19T12:00:00.000Z",
    sequence,
    modules: {
      "core.website": module,
      "growth.dashboard": module,
      "growth.leads": module,
      "growth.customers": module,
      "growth.messaging": module,
      "growth.automations": module,
      "growth.reviews": module,
      "growth.projects": module,
      "growth.ai": module,
      "growth.chat": module,
    },
    incidentOverrides: [],
  };
}

function receipt(status: "stored" | "replayed") {
  return {
    version: 1,
    status,
    snapshotId: SNAPSHOT_ID,
    siteId: SITE_ID,
    installationId: INSTALLATION_ID,
    sequence: 9,
    digest: DIGEST,
  };
}

describe("verified entitlement snapshot RPC store", () => {
  it("sends the entire verified snapshot through the versioned service RPC", async () => {
    const rpc = vi.fn(async () => ({ data: receipt("stored"), error: null }));
    const store = createSupabaseVerifiedSnapshotStore({ rpc });
    const value = snapshot();

    await expect(store(value)).resolves.toEqual(receipt("stored"));
    expect(rpc).toHaveBeenCalledWith(VERIFIED_SNAPSHOT_STORE_RPC, { p_snapshot: value });
  });

  it("accepts the original bounded receipt for an identical replay", async () => {
    const rpc = vi.fn(async () => ({ data: receipt("replayed"), error: null }));
    const store = createSupabaseVerifiedSnapshotStore({ rpc });

    await expect(store(snapshot())).resolves.toMatchObject({
      status: "replayed",
      sequence: 9,
      digest: DIGEST,
      snapshotId: SNAPSHOT_ID,
    });
  });

  it.each([
    { ...receipt("stored"), sequence: 8 },
    { ...receipt("stored"), siteId: "44444444-4444-4444-8444-444444444444" },
    { ...receipt("stored"), digest: "not-a-digest" },
    { ...receipt("stored"), status: "conflict" },
  ])("rejects a malformed or mismatched receipt", async (data) => {
    const store = createSupabaseVerifiedSnapshotStore({
      rpc: async () => ({ data, error: null }),
    });

    await expect(store(snapshot())).rejects.toMatchObject({
      code: "verified_snapshot_store_failed",
    });
  });

  it("sanitizes database failures", async () => {
    const store = createSupabaseVerifiedSnapshotStore({
      rpc: async () => ({ data: null, error: { message: "private database detail" } }),
    });

    const error = await store(snapshot()).catch((caught: unknown) => caught);
    expect(error).toBeInstanceOf(VerifiedSnapshotStoreError);
    expect(error).toMatchObject({ code: "verified_snapshot_store_failed" });
    expect(String(error)).not.toContain("private database detail");
  });
});
