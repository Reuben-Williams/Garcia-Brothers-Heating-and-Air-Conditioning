import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import * as controlPlane from "../src/control-plane/index.js";

const manifest = {
  version: 1 as const,
  packages: { next: "0.1.0" },
  schemas: { posts: 1 },
  routes: ["/"],
  workerVersion: "1.2.3",
};

function builder() {
  const build = (controlPlane as Record<string, unknown>).buildSiteHealthReport as
    | ((input: Record<string, unknown>) => Promise<Record<string, unknown>>)
    | undefined;
  expect(build).toBeTypeOf("function");
  return build!;
}

function healthySource() {
  return {
    probeDurableStore: vi.fn(async () => true),
    readQueues: vi.fn(async () => ({
      commands: { depth: 2, oldestAgeSeconds: 15, deadLetters: 0 },
    })),
    probeIntegrations: vi.fn(async () => ({ crm: "degraded" as const })),
  };
}

describe("truthful site health", () => {
  it("derives manifest facts and reports healthy only after all runtime proofs succeed", async () => {
    const source = healthySource();

    await expect(builder()({
      installationManifest: manifest,
      workerVersion: "1.2.3",
      runtimeInitialized: true,
      scheduledExecutionSucceeded: true,
      healthSource: source,
      runtimeErrorCodes: [],
    })).resolves.toEqual({
      manifestVersion: 1,
      packages: manifest.packages,
      schemas: manifest.schemas,
      worker: { version: "1.2.3", status: "healthy" },
      queues: { commands: { depth: 2, oldestAgeSeconds: 15, deadLetters: 0 } },
      integrations: { crm: "degraded" },
      entitlementSnapshotAgeSeconds: null,
      backupAgeSeconds: null,
      errorCodes: [],
    });
    expect(source.probeDurableStore).toHaveBeenCalledOnce();
    expect(source.readQueues).toHaveBeenCalledOnce();
    expect(source.probeIntegrations).toHaveBeenCalledOnce();
  });

  it("never invents zero queues or connected integrations when sources are unavailable", async () => {
    const health = await builder()({
      installationManifest: manifest,
      workerVersion: "1.2.3",
      runtimeInitialized: true,
      scheduledExecutionSucceeded: true,
      healthSource: {
        probeDurableStore: async () => false,
        readQueues: async () => {
          throw new Error("queue secret owner@example.test");
        },
        probeIntegrations: async () => {
          throw new Error("provider token abc123");
        },
      },
      runtimeErrorCodes: [],
    });

    expect(health).toMatchObject({
      worker: { status: "degraded" },
      queues: {},
      integrations: {},
      entitlementSnapshotAgeSeconds: null,
      backupAgeSeconds: null,
      errorCodes: [
        "DURABLE_STORE_UNAVAILABLE",
        "QUEUE_SOURCE_UNAVAILABLE",
        "INTEGRATION_SOURCE_UNAVAILABLE",
      ],
    });
    expect(health.worker).not.toHaveProperty("version");
    expect(JSON.stringify(health)).not.toContain("secret");
    expect(JSON.stringify(health)).not.toContain("token");
    expect(JSON.stringify(health)).not.toContain("owner@example.test");
  });

  it("keeps entitlement and backup ages null until authoritative adapters are configured", async () => {
    const health = await builder()({
      installationManifest: manifest,
      workerVersion: "1.2.3",
      runtimeInitialized: true,
      scheduledExecutionSucceeded: true,
      healthSource: healthySource(),
      runtimeErrorCodes: [],
    });

    expect(health.entitlementSnapshotAgeSeconds).toBeNull();
    expect(health.backupAgeSeconds).toBeNull();
  });

  it("omits worker version when the reviewed manifest omitted it", async () => {
    const { workerVersion: _workerVersion, ...withoutWorker } = manifest;
    const health = await builder()({
      installationManifest: withoutWorker,
      workerVersion: "1.2.3",
      runtimeInitialized: true,
      scheduledExecutionSucceeded: true,
      healthSource: healthySource(),
      runtimeErrorCodes: [],
    });

    expect(health.worker).toEqual({ status: "healthy" });
  });

  it("includes only bounded safe runtime error codes", async () => {
    const health = await builder()({
      installationManifest: manifest,
      workerVersion: "1.2.3",
      runtimeInitialized: true,
      scheduledExecutionSucceeded: false,
      healthSource: healthySource(),
      runtimeErrorCodes: [
        "COMMAND_EXECUTION_FAILED",
        "raw exception: owner@example.test",
        "A".repeat(65),
        "COMMAND_EXECUTION_FAILED",
      ],
    });

    expect(health.errorCodes).toEqual(["COMMAND_EXECUTION_FAILED"]);
    expect(health.worker).toEqual({ status: "degraded" });
  });
});
