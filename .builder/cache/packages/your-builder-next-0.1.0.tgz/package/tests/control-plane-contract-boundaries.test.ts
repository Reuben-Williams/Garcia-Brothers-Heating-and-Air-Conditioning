import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  InstallationClientError,
  validateCommandExecutionResult,
  validateSanitizedHealthReport,
  type CommandExecutionResult,
  type SanitizedHealthReport,
} from "../src/control-plane/index.js";

const EMPTY_EVIDENCE = {
  version: 1 as const,
  codes: [],
  metrics: {},
  flags: {},
  digests: {},
};

function succeeded(evidence: unknown = EMPTY_EVIDENCE): CommandExecutionResult {
  return {
    outcome: "succeeded",
    resultCode: "COMMAND_OK",
    evidence,
  } as CommandExecutionResult;
}

function health(override: Partial<SanitizedHealthReport> = {}): SanitizedHealthReport {
  return {
    manifestVersion: 1,
    packages: {},
    schemas: {},
    worker: { status: "healthy" },
    queues: {},
    integrations: {},
    entitlementSnapshotAgeSeconds: null,
    backupAgeSeconds: null,
    errorCodes: [],
    ...override,
  };
}

function expectInvalidResult(value: unknown): void {
  expect(() => validateCommandExecutionResult(value)).toThrowError(
    expect.objectContaining<Partial<InstallationClientError>>({ code: "invalid_request" }),
  );
}

function expectInvalidHealth(value: unknown): void {
  expect(() => validateSanitizedHealthReport(value)).toThrowError(
    expect.objectContaining<Partial<InstallationClientError>>({ code: "invalid_request" }),
  );
}

describe("SQL-compatible command result boundaries", () => {
  it("accepts exact bounded evidence at the SQL maxima", () => {
    expect(validateCommandExecutionResult(succeeded({
      version: 1,
      codes: ["A".repeat(64)],
      metrics: { ["m".repeat(64)]: 1_000_000_000 },
      flags: { ["f".repeat(64)]: true },
      digests: { ["d".repeat(64)]: "a".repeat(64) },
    }))).toMatchObject({ outcome: "succeeded" });
  });

  it.each([
    ["extra evidence key", { ...EMPTY_EVIDENCE, extra: true }],
    ["long code", { ...EMPTY_EVIDENCE, codes: ["A".repeat(65)] }],
    ["unsafe code", { ...EMPTY_EVIDENCE, codes: ["not safe"] }],
    ["long metric key", { ...EMPTY_EVIDENCE, metrics: { ["m".repeat(65)]: 1 } }],
    ["negative metric", { ...EMPTY_EVIDENCE, metrics: { count: -1 } }],
    ["fractional metric", { ...EMPTY_EVIDENCE, metrics: { count: 1.5 } }],
    ["oversized metric", { ...EMPTY_EVIDENCE, metrics: { count: 1_000_000_001 } }],
    ["nonboolean flag", { ...EMPTY_EVIDENCE, flags: { enabled: 1 } }],
    ["uppercase digest", { ...EMPTY_EVIDENCE, digests: { content: "A".repeat(64) } }],
    ["short digest", { ...EMPTY_EVIDENCE, digests: { content: "a".repeat(63) } }],
  ])("rejects %s", (_label, evidence) => expectInvalidResult(succeeded(evidence)));

  it("requires exact discriminated outcome fields and 64-character codes", () => {
    expectInvalidResult({ ...succeeded(), errorCode: "MUST_NOT_EXIST" });
    expectInvalidResult({ ...succeeded(), resultCode: "A".repeat(65) });
    expectInvalidResult({
      outcome: "retry",
      errorCode: "RETRY",
      retryAt: "2026-07-16T12:01:00.000Z",
      evidence: EMPTY_EVIDENCE,
      resultCode: "MUST_NOT_EXIST",
    });
  });
});

describe("SQL-compatible health boundaries", () => {
  it("uses the shared trust validator instead of maintaining a second health schema", async () => {
    const source = await readFile(
      resolve("packages/next/src/control-plane/installation-client.ts"),
      "utf8",
    );

    expect(source).toContain("parseSanitizedHealthReport");
    expect(source).not.toContain("FORBIDDEN_HEALTH_KEY_PATTERN");
    expect(source).not.toContain("function hasForbiddenHealthKey");
  });

  it("accepts SQL package, worker, code, and integer maxima", () => {
    expect(validateSanitizedHealthReport(health({
      packages: { ["p".repeat(128)]: "v".repeat(128) },
      schemas: { ["s".repeat(128)]: 9_999_999_999 },
      worker: { status: "healthy", version: "w".repeat(128) },
      queues: {
        ["q".repeat(128)]: {
          depth: 9_999_999_999,
          oldestAgeSeconds: 9_999_999_999,
          deadLetters: 9_999_999_999,
        },
      },
      errorCodes: ["E".repeat(64)],
    }))).toMatchObject({ manifestVersion: 1 });
  });

  it.each([
    ["api_key", { packages: { api_key: "1" } }],
    ["privateKey", { packages: { privateKey: "1" } }],
    ["nested authorization", {
      queues: { jobs: { depth: 0, oldestAgeSeconds: null, deadLetters: 0, authorization: 1 } },
    }],
  ])("rejects recursively forbidden key segment %s", (_label, override) => {
    expectInvalidHealth(health(override as Partial<SanitizedHealthReport>));
  });

  it("does not reject benign words that merely contain a forbidden substring", () => {
    expect(validateSanitizedHealthReport(health({
      packages: { keyboardLayout: "1.0.0", monkey: "1.0.0" },
    }))).toMatchObject({ packages: { keyboardLayout: "1.0.0" } });
  });

  it.each([
    ["package key", { packages: { ["p".repeat(129)]: "1" } }],
    ["package value pattern", { packages: { package: "scope/name" } }],
    ["schema integer", { schemas: { content: 10_000_000_000 } }],
    ["worker shape", { worker: { status: "healthy", extra: true } }],
    ["worker version pattern", { worker: { status: "healthy", version: "bad version" } }],
    ["queue shape", { queues: { jobs: { depth: 0, oldestAgeSeconds: null } } }],
    ["queue integer", {
      queues: { jobs: { depth: 10_000_000_000, oldestAgeSeconds: null, deadLetters: 0 } },
    }],
    ["error code length", { errorCodes: ["E".repeat(65)] }],
  ])("rejects out-of-contract %s", (_label, override) => {
    expectInvalidHealth(health(override as Partial<SanitizedHealthReport>));
  });

  it("uses PostgreSQL jsonb text size rather than compact JSON size", () => {
    const packages: Record<string, string> = {};
    for (let index = 0; index < 239; index += 1) {
      packages[`package${String(index).padStart(3, "0")}`] = "v".repeat(120);
    }
    const report = health({ packages });
    expect(Buffer.byteLength(JSON.stringify(report), "utf8")).toBeLessThanOrEqual(32_768);
    expectInvalidHealth(report);
  });
});
