// @vitest-environment node

import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { describe, expect, it } from "vitest";

describe("operational server boundary", () => {
  it("poisons client imports of authenticated routes and RPC adapters", async () => {
    await expect(import("./fixtures/operations-server-client-entry.js")).rejects.toThrow(
      "This module cannot be imported from a Client Component module",
    );
  });

  it("keeps generic transport types browser-safe and server implementations isolated", async () => {
    const browserEntry = await readFile(resolve("packages/next/src/operations/index.ts"), "utf8");
    const contracts = await readFile(resolve("packages/next/src/operations/contracts.ts"), "utf8");
    const serverEntry = await readFile(resolve("packages/next/src/operations/server/index.ts"), "utf8");
    const rootEntry = await readFile(resolve("packages/next/src/index.tsx"), "utf8");
    const packageManifest = JSON.parse(await readFile(resolve("packages/next/package.json"), "utf8"));

    expect(browserEntry).toBe([
      'export * from "./contracts.js";',
      'export * from "./residual-contracts.js";',
      "",
    ].join("\n"));
    expect(browserEntry).not.toContain("server-only");
    expect(contracts).not.toMatch(/Supabase|RpcClient|Authorizer|RouteHandler|service_role|secret/i);
    expect(serverEntry.startsWith('import "server-only";')).toBe(true);
    expect(rootEntry).not.toContain("./operations");
    expect(packageManifest.exports["./operations"]).toEqual({
      types: "./src/operations/index.ts",
      default: "./src/operations/index.ts",
    });
    expect(packageManifest.exports["./operations/server"]).toEqual({
      types: "./src/operations/server/index.ts",
      default: "./src/operations/server/index.ts",
    });
    expect(browserEntry).not.toMatch(/tokenHash|canonicalEmailDigest|service.role/i);
    expect(serverEntry).toContain("../supabase-operations.js");
  });
});
