// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  OperationalRpcError,
  createSupabaseResidualOperationalPersistence,
  type OperationalRpcClient,
} from "../src/operations/server/index.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const MEMBER_ID = "22222222-2222-4222-8222-222222222222";
const RESOURCE_ID = "33333333-3333-4333-8333-333333333333";
const COMMAND_ID = "44444444-4444-4444-8444-444444444444";
const CUSTOMER_ID = "55555555-5555-4555-8555-555555555555";
const TAG_ID = "66666666-6666-4666-8666-666666666666";
const AAL2_AT = "2026-07-18T12:00:00.000Z";
const actor = { type: "member" as const, id: MEMBER_ID };

function client(data: unknown, error: unknown = null): OperationalRpcClient {
  return { rpc: vi.fn(async () => ({ data, error })) };
}

const base = {
  version: 1,
  commandId: COMMAND_ID,
  siteId: SITE_ID,
  actorId: MEMBER_ID,
  idempotencyKey: COMMAND_ID,
};

describe("residual Supabase operational persistence", () => {
  it("uses the exact bulk RPC payload and maps mixed results in request order", async () => {
    const secondLeadId = "77777777-7777-4777-8777-777777777777";
    const thirdLeadId = "88888888-8888-4888-8888-888888888888";
    const rpc = client({
      status: "applied",
      results: [
        { leadId: RESOURCE_ID, status: "applied", resultVersion: 4 },
        { leadId: secondLeadId, status: "denied", reason: "invalid_transition" },
        { leadId: thirdLeadId, status: "conflict", expectedVersion: 2, actualVersion: 3 },
      ],
    });
    const persistence = createSupabaseResidualOperationalPersistence(rpc);
    const records = [
      { leadId: RESOURCE_ID, expectedVersion: 3 },
      { leadId: secondLeadId, expectedVersion: 1 },
      { leadId: thirdLeadId, expectedVersion: 2 },
    ];

    await expect(persistence.bulkApplyLeads({
      siteId: SITE_ID,
      actor,
      idempotencyKey: COMMAND_ID,
      action: "status",
      records,
      status: "won",
    })).resolves.toEqual({
      requestedCount: 3,
      results: [
        { leadId: RESOURCE_ID, status: "applied", version: 4 },
        { leadId: secondLeadId, status: "denied", reason: "invalid_request" },
        { leadId: thirdLeadId, status: "conflict", expectedVersion: 2, actualVersion: 3 },
      ],
    });
    expect(rpc.rpc).toHaveBeenCalledWith("builder_bulk_apply_leads_v1", {
      p_request: {
        ...base,
        operation: "status",
        records: records.map(({ leadId, expectedVersion }) => ({ id: leadId, expectedVersion })),
        status: "won",
      },
    });
  });

  it.each([
    ["saveView", "builder_save_view_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID, expectedVersion: 0, viewId: RESOURCE_ID,
      domain: "leads", name: "Hot leads", shared: true,
      filter: { version: 1, conjunction: "all", clauses: [{ field: "status", operator: "equals", value: "new" }] },
      aal2VerifiedAt: AAL2_AT,
    }, {
      ...base, expectedVersion: 0, viewId: RESOURCE_ID, domain: "leads", name: "Hot leads", visibility: "site",
      filterAst: { version: 1, conjunction: "all", clauses: [{ field: "status", operator: "equals", value: "new" }] },
    }, "saved_view", "viewId", 3],
    ["removeSavedView", "builder_remove_saved_view_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID, expectedVersion: 2,
      viewId: RESOURCE_ID, domain: "customers", shared: false,
    }, {
      ...base, expectedVersion: 2, viewId: RESOURCE_ID,
    }, "saved_view", "viewId", 3],
    ["setCustomerPreference", "builder_set_customer_preference_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID, expectedVersion: 1,
      customerId: CUSTOMER_ID, key: "appointment_window", value: { period: "morning" },
    }, {
      ...base, expectedVersion: 1, customerId: CUSTOMER_ID,
      key: "appointment_window", value: { period: "morning" },
    }, "customer_preference", "customerId", 3],
    ["clearCustomerPreference", "builder_clear_customer_preference_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID, expectedVersion: 2,
      customerId: CUSTOMER_ID, key: "appointment_window",
    }, {
      ...base, expectedVersion: 2, customerId: CUSTOMER_ID, key: "appointment_window",
    }, "customer_preference", "customerId", 3],
    ["setCustomerSuppression", "builder_set_customer_suppression_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID, customerId: CUSTOMER_ID, suppressionId: RESOURCE_ID,
      channel: "email", reason: "manual", active: true,
    }, {
      ...base, customerId: CUSTOMER_ID, suppressionId: RESOURCE_ID, operation: "suppress",
      channel: "email", reason: "manual", expectedState: "absent",
    }, "customer_suppression", "suppressionId", undefined],
    ["setRecordTag", "builder_set_record_tag_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID, recordType: "lead",
      recordId: RESOURCE_ID, tagId: TAG_ID, action: "add",
    }, {
      ...base, resourceType: "lead", resourceId: RESOURCE_ID, tagId: TAG_ID, operation: "add",
    }, "record_tag", "resourceId", undefined],
    ["requestLeadsExport", "builder_request_leads_export_v1", {
      siteId: SITE_ID, actor, idempotencyKey: COMMAND_ID,
      filter: { search: "boiler", statuses: ["new"], assigneeIds: [MEMBER_ID] },
      aal2VerifiedAt: AAL2_AT,
    }, {
      ...base, filters: { query: "boiler", statuses: ["new"], assigneeIds: [MEMBER_ID] },
    }, "data_export", "exportId", undefined],
  ] as const)("maps %s to exact RPC %s and a bounded result", async (method, rpcName, command, expected, resourceType, idKey, resultVersion) => {
    const rpc = client({
      status: "applied",
      [idKey]: RESOURCE_ID,
      version: 1,
      ...(resultVersion === undefined ? {} : { resultVersion }),
      privateValue: "hidden",
    });
    const persistence = createSupabaseResidualOperationalPersistence(rpc);

    const result = await (persistence[method] as Function)(command);

    expect(rpc.rpc).toHaveBeenCalledWith(rpcName, { p_request: expected });
    expect(result).toEqual({
      status: "applied",
      resourceType,
      resourceId: RESOURCE_ID,
      ...(resultVersion === undefined ? {} : { version: resultVersion }),
      replayed: false,
    });
    expect(JSON.stringify(result)).not.toContain("privateValue");
  });

  it("rejects malformed or incomplete bulk results with the stable safe error", async () => {
    const persistence = createSupabaseResidualOperationalPersistence(client({
      status: "applied",
      results: [],
    }));

    await expect(persistence.bulkApplyLeads({
      siteId: SITE_ID,
      actor,
      idempotencyKey: COMMAND_ID,
      action: "tag",
      records: [{ leadId: RESOURCE_ID, expectedVersion: 1 }],
      tagId: TAG_ID,
      tagAction: "add",
    })).rejects.toEqual(new OperationalRpcError("OPERATION_RPC_INVALID_RESPONSE"));
  });

  it("maps a top-level bulk authorization denial to every requested record", async () => {
    const secondLeadId = "77777777-7777-4777-8777-777777777777";
    const persistence = createSupabaseResidualOperationalPersistence(client(null, { code: "42501" }));

    await expect(persistence.bulkApplyLeads({
      siteId: SITE_ID,
      actor,
      idempotencyKey: COMMAND_ID,
      action: "assignment",
      records: [
        { leadId: RESOURCE_ID, expectedVersion: 1 },
        { leadId: secondLeadId, expectedVersion: 2 },
      ],
      assigneeId: MEMBER_ID,
    })).resolves.toEqual({
      requestedCount: 2,
      results: [
        { leadId: RESOURCE_ID, status: "denied", reason: "not_authorized" },
        { leadId: secondLeadId, status: "denied", reason: "not_authorized" },
      ],
    });
  });
});
