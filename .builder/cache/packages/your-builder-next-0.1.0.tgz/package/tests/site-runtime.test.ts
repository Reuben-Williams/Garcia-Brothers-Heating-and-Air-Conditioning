import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import * as controlPlane from "../src/control-plane/index.js";

const SITE_ID = "10000000-0000-4000-8000-000000000001";
const INSTALLATION_ID = "20000000-0000-4000-8000-000000000001";
const COMMAND_ID = "40000000-0000-4000-8000-000000000001";
const manifest = {
  version: 1 as const,
  packages: { next: "0.1.0" },
  schemas: { posts: 1 },
  routes: ["/"],
  workerVersion: "1.2.3",
};

function healthSource() {
  return {
    probeDurableStore: vi.fn(async () => true),
    readQueues: vi.fn(async () => ({ commands: { depth: 0, oldestAgeSeconds: null, deadLetters: 0 } })),
    probeIntegrations: vi.fn(async () => ({ controlPlane: "connected" as const })),
  };
}

function lease(acquired = true, owner = "30000000-0000-4000-8000-000000000001") {
  return {
    version: 1 as const,
    acquired,
    siteId: SITE_ID,
    installationId: INSTALLATION_ID,
    leaseOwner: acquired ? owner : null,
    fencingToken: acquired ? "7" : null,
    leaseExpiresAt: acquired ? "2026-07-19T12:02:00.000Z" : null,
  };
}

function setup(options: {
  commands?: unknown[];
  pullCommands?: () => Promise<unknown[]>;
  acquire?: () => Promise<ReturnType<typeof lease>>;
  identity?: { siteId: string; siteKey: string };
  renew?: ReturnType<typeof lease>[];
  handlers?: unknown[];
} = {}) {
  const reports: unknown[] = [];
  const client = {
    pullCommands: vi.fn(options.pullCommands ?? (async () => options.commands ?? [])),
    acknowledgeResult: vi.fn(async () => undefined),
    reportHealth: vi.fn(async (report: unknown) => { reports.push(report); }),
  };
  const identityStore = {
    getSiteIdentity: vi.fn(async () => options.identity ?? ({ siteId: SITE_ID, siteKey: "reviewed-site" })),
  };
  const leaseOwner = "30000000-0000-4000-8000-000000000001";
  const renewals = [...(options.renew ?? [lease(true, leaseOwner)])];
  const runLeaseStore = {
    acquire: vi.fn(options.acquire ?? (async () => lease(true, leaseOwner))),
    renew: vi.fn(async () => renewals.shift() ?? lease(true, leaseOwner)),
    release: vi.fn(async () => true),
  };
  const receiptStore = controlPlane.createMemorySiteCommandReceiptStore();
  const createRuntime = (controlPlane as Record<string, unknown>).createSiteInstallationRuntime as
    | ((input: Record<string, unknown>, options?: Record<string, unknown>) => {
        runScheduled(options?: { signal?: AbortSignal }): Promise<{
          pulled: number;
          acknowledged: number;
          healthReported: boolean;
        }>;
      })
    | undefined;
  expect(createRuntime).toBeTypeOf("function");
  const runtime = createRuntime!({
    config: {
      controlPlaneUrl: "https://control.example.test",
      installationId: INSTALLATION_ID,
      keyId: "key-1",
      privateJwk: {},
    },
    siteDataPlaneSiteId: SITE_ID,
    expectedSiteKey: "reviewed-site",
    installationManifest: manifest,
    workerVersion: "1.2.3",
    receiptStore,
    runLeaseStore,
    identityStore,
    handlers: options.handlers ?? [],
    healthSource: healthSource(),
  }, {
    leaseSeconds: 120,
    leaseOwner: () => leaseOwner,
    now: () => new Date("2026-07-19T12:00:00.000Z"),
    installationClientFactory: () => client,
  });
  return { runtime, client, identityStore, runLeaseStore, receiptStore, reports };
}

describe("site installation runtime", () => {
  it("reports truthful health on a no-command scheduled run", async () => {
    const state = setup();

    await expect(state.runtime.runScheduled()).resolves.toEqual({
      pulled: 0,
      acknowledged: 0,
      healthReported: true,
    });
    expect(state.identityStore.getSiteIdentity).toHaveBeenCalledWith(SITE_ID);
    expect(state.runLeaseStore.acquire).toHaveBeenCalledWith({
      siteId: SITE_ID,
      expectedSiteKey: "reviewed-site",
      installationId: INSTALLATION_ID,
      leaseOwner: "30000000-0000-4000-8000-000000000001",
      leaseSeconds: 120,
    });
    expect(state.client.pullCommands).toHaveBeenCalledOnce();
    expect(state.runLeaseStore.renew).toHaveBeenCalledOnce();
    expect(state.client.reportHealth).toHaveBeenCalledOnce();
    expect(state.reports[0]).toMatchObject({ worker: { status: "healthy", version: "1.2.3" } });
    expect(state.runLeaseStore.release).toHaveBeenCalledWith(expect.objectContaining({
      siteId: SITE_ID,
      expectedSiteKey: "reviewed-site",
      installationId: INSTALLATION_ID,
      fencingToken: "7",
    }));
  });

  it("executes through the durable receipt executor and acknowledges only its bounded result", async () => {
    const execute = vi.fn(async () => ({
      resultCode: "MODULE_CONFIGURED",
      evidence: { codes: ["CONFIG_CREATED"], secret: "never-persist" },
    }));
    const state = setup({
      commands: [{
        id: COMMAND_ID,
        type: "module.configure",
        version: 1,
        payload: { moduleId: "growth.leads" },
        idempotencyKey: "configure-growth-leads-v1",
        createdAt: "2026-07-19T12:00:00.000Z",
        leaseToken: "50000000-0000-4000-8000-000000000001",
        attempt: 1,
        leaseExpiresAt: "2026-07-19T12:01:00.000Z",
      }],
      renew: [lease(), lease()],
      handlers: [{
        type: "module.configure",
        version: 1,
        idempotency: "commandId",
        validate: (value: unknown) => value,
        execute,
      }],
    });

    await expect(state.runtime.runScheduled()).resolves.toEqual({
      pulled: 1,
      acknowledged: 1,
      healthReported: true,
    });
    expect(execute).toHaveBeenCalledWith(expect.objectContaining({
      commandId: COMMAND_ID,
      idempotencyKey: "configure-growth-leads-v1",
      payload: { moduleId: "growth.leads" },
      signal: expect.any(AbortSignal),
      lease: expect.objectContaining({ fencingToken: "7" }),
    }));
    expect(state.client.acknowledgeResult).toHaveBeenCalledWith({
      commandId: COMMAND_ID,
      attempt: 1,
      leaseToken: "50000000-0000-4000-8000-000000000001",
      outcome: "succeeded",
      resultCode: "MODULE_CONFIGURED",
      evidence: {
        version: 1,
        codes: ["CONFIG_CREATED"],
        metrics: {},
        flags: {},
        digests: {},
      },
    });
    expect(JSON.stringify(state.client.acknowledgeResult.mock.calls)).not.toContain("never-persist");
    expect(state.runLeaseStore.renew).toHaveBeenCalledTimes(3);
  });

  it("propagates scheduled timeout and the fencing context into an active handler", async () => {
    vi.useFakeTimers();
    vi.setSystemTime("2026-07-19T12:00:00.000Z");
    let received: Record<string, unknown> | undefined;
    let finish: (() => void) | undefined;
    const handlerFinished = new Promise<void>((resolve) => {
      finish = resolve;
    });
    const execute = vi.fn(async (handlerInput: Record<string, unknown>) => {
      received = handlerInput;
      await handlerFinished;
      return { resultCode: "MODULE_CONFIGURED", evidence: {} };
    });
    const state = setup({
      commands: [{
        id: COMMAND_ID,
        type: "module.configure",
        version: 1,
        payload: { moduleId: "growth.leads" },
        idempotencyKey: "configure-growth-leads-v1",
        createdAt: "2026-07-19T12:00:00.000Z",
        leaseToken: "50000000-0000-4000-8000-000000000001",
        attempt: 1,
        leaseExpiresAt: "2026-07-19T12:01:00.000Z",
      }],
      handlers: [{
        type: "module.configure",
        version: 1,
        idempotency: "commandId",
        validate: (value: unknown) => value,
        execute,
      }],
    });

    const pending = controlPlane.runScheduledInvocation(state.runtime, { timeoutSeconds: 1 });
    const rejection = expect(pending).rejects.toMatchObject({
      code: "site_installation_invocation_timeout",
    });
    await vi.waitFor(() => expect(execute).toHaveBeenCalledOnce());
    await vi.advanceTimersByTimeAsync(1_000);
    await rejection;

    const signal = received?.signal as AbortSignal | undefined;
    const leaseContext = received?.lease as Record<string, unknown> | undefined;
    const observed = {
      aborted: signal?.aborted,
      reason: signal?.reason,
      leaseContext,
    };
    finish?.();
    await vi.waitFor(() => expect(state.runLeaseStore.release).toHaveBeenCalledOnce());

    expect(observed.aborted).toBe(true);
    expect(observed.reason).toMatchObject({ code: "site_installation_invocation_timeout" });
    expect(observed.leaseContext).toMatchObject({
      siteId: SITE_ID,
      installationId: INSTALLATION_ID,
      leaseOwner: "30000000-0000-4000-8000-000000000001",
      fencingToken: "7",
    });
    expect(state.client.acknowledgeResult).not.toHaveBeenCalled();
    vi.useRealTimers();
  });

  it("aborts an active handler when heartbeat renewal loses the lease", async () => {
    vi.useFakeTimers();
    vi.setSystemTime("2026-07-19T12:00:00.000Z");
    const invocationAbort = new AbortController();
    let receivedSignal: AbortSignal | undefined;
    let receivedLease: Record<string, unknown> | undefined;
    let finish: (() => void) | undefined;
    const handlerFinished = new Promise<void>((resolve) => {
      finish = resolve;
    });
    const execute = vi.fn(async (handlerInput: Record<string, unknown>) => {
      receivedSignal = handlerInput.signal as AbortSignal | undefined;
      receivedLease = handlerInput.lease as Record<string, unknown> | undefined;
      await handlerFinished;
      return { resultCode: "MODULE_CONFIGURED", evidence: {} };
    });
    const state = setup({
      commands: [{
        id: COMMAND_ID,
        type: "module.configure",
        version: 1,
        payload: { moduleId: "growth.leads" },
        idempotencyKey: "configure-growth-leads-v1",
        createdAt: "2026-07-19T12:00:00.000Z",
        leaseToken: "50000000-0000-4000-8000-000000000001",
        attempt: 1,
        leaseExpiresAt: "2026-07-19T12:01:00.000Z",
      }],
      renew: [lease(), lease(false)],
      handlers: [{
        type: "module.configure",
        version: 1,
        idempotency: "commandId",
        validate: (value: unknown) => value,
        execute,
      }],
    });

    const pending = state.runtime.runScheduled({ signal: invocationAbort.signal });
    await vi.waitFor(() => expect(execute).toHaveBeenCalledOnce());
    await vi.advanceTimersByTimeAsync(40_000);
    const observed = {
      aborted: receivedSignal?.aborted,
      reason: receivedSignal?.reason,
      lease: receivedLease,
    };
    if (!receivedSignal?.aborted) invocationAbort.abort();
    finish?.();

    await expect(pending).rejects.toMatchObject({ code: "site_installation_lease_lost" });
    expect(observed.aborted).toBe(true);
    expect(observed.reason).toMatchObject({ code: "site_installation_lease_lost" });
    expect(observed.lease).toMatchObject({ fencingToken: "7" });
    expect(state.runLeaseStore.renew).toHaveBeenCalledTimes(2);
    expect(state.client.acknowledgeResult).not.toHaveBeenCalled();
    expect(state.client.reportHealth).not.toHaveBeenCalled();
    vi.useRealTimers();
  });

  it("rejects unknown commands through an explicitly empty handler registry", async () => {
    const state = setup({
      commands: [{
        id: COMMAND_ID,
        type: "module.provision",
        version: 1,
        payload: {},
        idempotencyKey: "provision-v1",
        createdAt: "2026-07-19T12:00:00.000Z",
        leaseToken: "50000000-0000-4000-8000-000000000001",
        attempt: 1,
        leaseExpiresAt: "2026-07-19T12:01:00.000Z",
      }],
      renew: [lease(), lease()],
    });

    await expect(state.runtime.runScheduled()).resolves.toMatchObject({ acknowledged: 1 });
    expect(state.client.acknowledgeResult).toHaveBeenCalledWith(expect.objectContaining({
      outcome: "failed",
      errorCode: "UNSUPPORTED_COMMAND_TYPE",
    }));
  });

  it("fails identity before pull, receipt, lease, acknowledgment, or health mutation", async () => {
    const state = setup({ identity: { siteId: SITE_ID, siteKey: "changed-site" } });
    const reserve = vi.spyOn(state.receiptStore, "reserve");

    await expect(state.runtime.runScheduled()).rejects.toMatchObject({
      code: "site_data_plane_identity_mismatch",
    });
    expect(reserve).not.toHaveBeenCalled();
    expect(state.runLeaseStore.acquire).not.toHaveBeenCalled();
    expect(state.client.pullCommands).not.toHaveBeenCalled();
    expect(state.client.acknowledgeResult).not.toHaveBeenCalled();
    expect(state.client.reportHealth).not.toHaveBeenCalled();
  });

  it("stops before acknowledgment and health when lease renewal loses ownership", async () => {
    const state = setup({
      commands: [{
        id: COMMAND_ID,
        type: "unknown",
        version: 1,
        payload: {},
        idempotencyKey: "unknown-v1",
        createdAt: "2026-07-19T12:00:00.000Z",
        leaseToken: "50000000-0000-4000-8000-000000000001",
        attempt: 1,
        leaseExpiresAt: "2026-07-19T12:01:00.000Z",
      }],
      renew: [lease(false)],
    });

    await expect(state.runtime.runScheduled()).rejects.toMatchObject({
      code: "site_installation_lease_lost",
    });
    expect(state.client.acknowledgeResult).not.toHaveBeenCalled();
    expect(state.client.reportHealth).not.toHaveBeenCalled();
    expect(state.runLeaseStore.release).toHaveBeenCalledOnce();
  });

  it("stops all later handlers, renewal, acknowledgment, and health after abort", async () => {
    let resolveHandler: ((value: {
      resultCode: string;
      evidence: Record<string, unknown>;
    }) => void) | undefined;
    const handlerResult = new Promise<{
      resultCode: string;
      evidence: Record<string, unknown>;
    }>((resolve) => {
      resolveHandler = resolve;
    });
    const execute = vi.fn(async () => handlerResult);
    const command = (id: string) => ({
      id,
      type: "module.configure",
      version: 1,
      payload: { moduleId: "growth.leads" },
      idempotencyKey: `configure-${id}`,
      createdAt: "2026-07-19T12:00:00.000Z",
      leaseToken: "50000000-0000-4000-8000-000000000001",
      attempt: 1,
      leaseExpiresAt: "2026-07-19T12:01:00.000Z",
    });
    const state = setup({
      commands: [
        command("40000000-0000-4000-8000-000000000001"),
        command("40000000-0000-4000-8000-000000000002"),
      ],
      handlers: [{
        type: "module.configure",
        version: 1,
        idempotency: "commandId",
        validate: (value: unknown) => value,
        execute,
      }],
    });
    const abort = new AbortController();

    const pending = state.runtime.runScheduled({ signal: abort.signal });
    await vi.waitFor(() => expect(execute).toHaveBeenCalledOnce());
    abort.abort();
    resolveHandler?.({ resultCode: "MODULE_CONFIGURED", evidence: {} });

    await expect(pending).rejects.toMatchObject({
      code: "site_installation_invocation_aborted",
    });
    expect(execute).toHaveBeenCalledOnce();
    expect(state.runLeaseStore.renew).toHaveBeenCalledOnce();
    expect(state.client.acknowledgeResult).not.toHaveBeenCalled();
    expect(state.client.reportHealth).not.toHaveBeenCalled();
    expect(state.runLeaseStore.release).toHaveBeenCalledOnce();
  });

  it("releases a lease acquired while the invocation is being aborted", async () => {
    let resolveAcquire: ((value: ReturnType<typeof lease>) => void) | undefined;
    const acquireResult = new Promise<ReturnType<typeof lease>>((resolve) => {
      resolveAcquire = resolve;
    });
    const state = setup({ acquire: () => acquireResult });
    const abort = new AbortController();

    const pending = state.runtime.runScheduled({ signal: abort.signal });
    await vi.waitFor(() => expect(state.runLeaseStore.acquire).toHaveBeenCalledOnce());
    abort.abort();
    resolveAcquire?.(lease());

    await expect(pending).rejects.toMatchObject({
      code: "site_installation_invocation_aborted",
    });
    expect(state.client.pullCommands).not.toHaveBeenCalled();
    expect(state.runLeaseStore.renew).not.toHaveBeenCalled();
    expect(state.client.acknowledgeResult).not.toHaveBeenCalled();
    expect(state.client.reportHealth).not.toHaveBeenCalled();
    expect(state.runLeaseStore.release).toHaveBeenCalledOnce();
  });

  it("rejects a central installation UUID substituted as the local site UUID", () => {
    const createRuntime = (controlPlane as Record<string, unknown>).createSiteInstallationRuntime as
      | ((input: Record<string, unknown>) => unknown)
      | undefined;

    expect(createRuntime).toBeTypeOf("function");
    expect(() => createRuntime?.({
      config: {
        controlPlaneUrl: "https://control.example.test",
        installationId: INSTALLATION_ID,
        keyId: "key-1",
        privateJwk: {},
      },
      siteDataPlaneSiteId: INSTALLATION_ID,
      expectedSiteKey: "reviewed-site",
      installationManifest: manifest,
      workerVersion: null,
      receiptStore: {},
      runLeaseStore: {},
      identityStore: {},
      handlers: [],
      healthSource: {},
    })).toThrow("site_data_plane_identity_mismatch");
  });
});
