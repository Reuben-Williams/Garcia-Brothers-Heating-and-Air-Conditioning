import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import * as controlPlane from "../src/control-plane/index.js";

const SITE_ID = "10000000-0000-4000-8000-000000000001";
const INSTALLATION_ID = "20000000-0000-4000-8000-000000000001";
const OWNER = "30000000-0000-4000-8000-000000000001";
const EXPIRES_AT = "2026-07-19T12:02:00.000Z";
const MIXED_SITE_ID = "ABCDEFAB-CDEF-4ABC-8DEF-ABCDEFABCDEF";
const MIXED_INSTALLATION_ID = "ABCDEFAC-CDEF-4ABC-8DEF-ABCDEFABCDEF";
const MIXED_OWNER = "ABCDEFAD-CDEF-4ABC-8DEF-ABCDEFABCDEF";

function acquired(fencingToken: unknown = "9007199254740993") {
  return {
    version: 1,
    acquired: true,
    siteId: SITE_ID,
    installationId: INSTALLATION_ID,
    leaseOwner: OWNER,
    fencingToken,
    leaseExpiresAt: EXPIRES_AT,
  };
}

function createStore(rpc: ReturnType<typeof vi.fn>) {
  const factory = (controlPlane as Record<string, unknown>)
    .createSupabaseSiteInstallationRunLeaseStore as
    | ((client: { rpc: typeof rpc }) => {
        acquire(input: Record<string, unknown>): Promise<unknown>;
        renew(input: Record<string, unknown>): Promise<unknown>;
        release(input: Record<string, unknown>): Promise<boolean>;
      })
    | undefined;
  expect(factory).toBeTypeOf("function");
  return factory?.({ rpc });
}

describe("site installation run lease store", () => {
  it("uses exact acquire, renew, and release RPC arguments without numeric token coercion", async () => {
    const rpc = vi.fn()
      .mockResolvedValueOnce({ data: acquired(), error: null })
      .mockResolvedValueOnce({ data: acquired(), error: null })
      .mockResolvedValueOnce({ data: true, error: null });
    const store = createStore(rpc)!;
    const identity = {
      siteId: SITE_ID,
      expectedSiteKey: "reviewed-site",
      installationId: INSTALLATION_ID,
      leaseOwner: OWNER,
    };

    await expect(store.acquire({ ...identity, leaseSeconds: 120 })).resolves.toEqual(acquired());
    await expect(store.renew({
      ...identity,
      fencingToken: "9007199254740993",
      leaseSeconds: 120,
    })).resolves.toEqual(acquired());
    await expect(store.release({ ...identity, fencingToken: "9007199254740993" })).resolves.toBe(true);

    expect(rpc).toHaveBeenNthCalledWith(1, "builder_acquire_installation_worker_lease", {
      p_site_id: SITE_ID,
      p_expected_site_key: "reviewed-site",
      p_installation_id: INSTALLATION_ID,
      p_lease_owner: OWNER,
      p_lease_seconds: 120,
    });
    expect(rpc).toHaveBeenNthCalledWith(2, "builder_renew_installation_worker_lease", {
      p_site_id: SITE_ID,
      p_expected_site_key: "reviewed-site",
      p_installation_id: INSTALLATION_ID,
      p_lease_owner: OWNER,
      p_fencing_token: "9007199254740993",
      p_lease_seconds: 120,
    });
    expect(rpc).toHaveBeenNthCalledWith(3, "builder_release_installation_worker_lease", {
      p_site_id: SITE_ID,
      p_expected_site_key: "reviewed-site",
      p_installation_id: INSTALLATION_ID,
      p_lease_owner: OWNER,
      p_fencing_token: "9007199254740993",
    });
  });

  it("accepts only a redacted unsuccessful envelope", async () => {
    const rpc = vi.fn(async () => ({
      data: {
        version: 1,
        acquired: false,
        siteId: SITE_ID,
        installationId: INSTALLATION_ID,
        leaseOwner: null,
        fencingToken: null,
        leaseExpiresAt: null,
      },
      error: null,
    }));

    await expect(createStore(rpc)?.acquire({
      siteId: SITE_ID,
      expectedSiteKey: "reviewed-site",
      installationId: INSTALLATION_ID,
      leaseOwner: OWNER,
      leaseSeconds: 60,
    })).resolves.toMatchObject({ acquired: false, leaseOwner: null, fencingToken: null });
  });

  it.each([59, 301, 120.5])("rejects lease duration %s before RPC", async (leaseSeconds) => {
    const rpc = vi.fn();
    const store = createStore(rpc)!;

    await expect(store.acquire({
      siteId: SITE_ID,
      expectedSiteKey: "reviewed-site",
      installationId: INSTALLATION_ID,
      leaseOwner: OWNER,
      leaseSeconds,
    })).rejects.toMatchObject({ code: "site_installation_run_lease_error" });
    expect(rpc).not.toHaveBeenCalled();
  });

  it.each([
    ["zero", "0"],
    ["JSON number", 9_007_199_254_740_991],
    ["leading zero", "01"],
    ["sign", "+1"],
    ["fraction", "1.5"],
    ["exponent", "1e3"],
    ["overflow", "9223372036854775808"],
  ])("rejects %s fencing tokens", async (_label, fencingToken) => {
    const rpc = vi.fn(async () => ({ data: acquired(fencingToken), error: null }));
    const store = createStore(rpc)!;

    await expect(store.acquire({
      siteId: SITE_ID,
      expectedSiteKey: "reviewed-site",
      installationId: INSTALLATION_ID,
      leaseOwner: OWNER,
      leaseSeconds: 120,
    })).rejects.toMatchObject({ code: "site_installation_run_lease_error" });
  });

  it("rejects malformed owner correlation and invalid release responses", async () => {
    const malformed = { ...acquired(), leaseOwner: "40000000-0000-4000-8000-000000000001" };
    const rpc = vi.fn()
      .mockResolvedValueOnce({ data: malformed, error: null })
      .mockResolvedValueOnce({ data: "true", error: null });
    const store = createStore(rpc)!;
    const identity = {
      siteId: SITE_ID,
      expectedSiteKey: "reviewed-site",
      installationId: INSTALLATION_ID,
      leaseOwner: OWNER,
    };

    await expect(store.acquire({ ...identity, leaseSeconds: 120 }))
      .rejects.toMatchObject({ code: "site_installation_run_lease_error" });
    await expect(store.release({ ...identity, fencingToken: "1" }))
      .rejects.toMatchObject({ code: "site_installation_run_lease_error" });
  });

  it("normalizes UUID casing at the lease RPC boundary", async () => {
    const normalized = {
      version: 1,
      acquired: true,
      siteId: MIXED_SITE_ID,
      installationId: MIXED_INSTALLATION_ID,
      leaseOwner: MIXED_OWNER,
      fencingToken: "1",
      leaseExpiresAt: EXPIRES_AT,
    };
    const rpc = vi.fn(async () => ({ data: normalized, error: null }));
    const store = createStore(rpc)!;

    await expect(store.acquire({
      siteId: MIXED_SITE_ID,
      expectedSiteKey: "reviewed-site",
      installationId: MIXED_INSTALLATION_ID,
      leaseOwner: MIXED_OWNER,
      leaseSeconds: 120,
    })).resolves.toMatchObject({
      siteId: MIXED_SITE_ID.toLowerCase(),
      installationId: MIXED_INSTALLATION_ID.toLowerCase(),
      leaseOwner: MIXED_OWNER.toLowerCase(),
    });
    expect(rpc).toHaveBeenCalledWith("builder_acquire_installation_worker_lease", {
      p_site_id: MIXED_SITE_ID.toLowerCase(),
      p_expected_site_key: "reviewed-site",
      p_installation_id: MIXED_INSTALLATION_ID.toLowerCase(),
      p_lease_owner: MIXED_OWNER.toLowerCase(),
      p_lease_seconds: 120,
    });
  });
});
