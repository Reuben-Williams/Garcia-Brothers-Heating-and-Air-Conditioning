// @vitest-environment node

import { exportJWK, generateKeyPair } from "jose";
import { beforeAll, describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import type { EntitlementSnapshot } from "@your-builder/entitlements";
import type { GrowthCapability } from "@your-builder/core";
import { signEntitlementSnapshot } from "@your-builder/entitlements/server";
import { requireModuleAccess } from "../src/entitlements/require-module.js";
import type { VerifiedSnapshotStoreReceipt } from "../src/entitlements/verified-snapshot-store.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const INSTALLATION_ID = "22222222-2222-4222-8222-222222222222";
const KEY_ID = "entitlements-2026-07";
const NOW = new Date("2026-07-17T12:00:00.000Z");

let privateJwk: JsonWebKey;
let publicJwk: JsonWebKey;

function snapshot(
  incidents: EntitlementSnapshot["incidentOverrides"] = [],
  leadsState: EntitlementSnapshot["modules"]["growth.leads"]["state"] = "active",
): EntitlementSnapshot {
  const module = { state: "active" as const, moduleVersion: "1.0.0", setupComplete: true };
  return {
    version: 1,
    siteId: SITE_ID,
    installationId: INSTALLATION_ID,
    issuedAt: "2026-07-17T12:00:00.000Z",
    expiresAt: "2026-07-18T12:00:00.000Z",
    sequence: 1,
    modules: {
      "core.website": module,
      "growth.dashboard": module,
      "growth.leads": { ...module, state: leadsState },
      "growth.customers": module,
      "growth.messaging": module,
      "growth.automations": module,
      "growth.reviews": module,
      "growth.projects": module,
      "growth.ai": module,
      "growth.chat": module,
    },
    incidentOverrides: incidents,
  };
}

beforeAll(async () => {
  const pair = await generateKeyPair("Ed25519", { extractable: true });
  privateJwk = { ...(await exportJWK(pair.privateKey)), alg: "EdDSA" };
  publicJwk = { ...(await exportJWK(pair.publicKey)), alg: "EdDSA" };
});

async function authorize(input: {
  value?: EntitlementSnapshot;
  siteId?: string;
  checkSite?: (siteId: string, capability: GrowthCapability) => Promise<boolean>;
  persistVerifiedSnapshot?: (snapshot: EntitlementSnapshot) => Promise<VerifiedSnapshotStoreReceipt>;
  action?: "read" | "write" | "outbound" | "export" | "setup" | "repair";
}) {
  const token = await signEntitlementSnapshot({ snapshot: input.value ?? snapshot(), keyId: KEY_ID, privateJwk });
  return requireModuleAccess({
    token,
    siteId: input.siteId ?? SITE_ID,
    installationId: INSTALLATION_ID,
    moduleId: "growth.leads",
    action: input.action ?? "read",
    capability: "leads.read",
    resolveSigningKey: async (keyId) => ({ keyId, status: "active", publicJwk }),
    persistVerifiedSnapshot: input.persistVerifiedSnapshot ?? (async (verified) => ({
      version: 1,
      status: "stored",
      snapshotId: "33333333-3333-4333-8333-333333333333",
      siteId: verified.siteId,
      installationId: verified.installationId,
      sequence: verified.sequence,
      digest: "a".repeat(64),
    })),
    checkSite: input.checkSite ?? (async () => true),
    checkRecord: async () => false,
    now: NOW,
  });
}

describe("requireModuleAccess", () => {
  it("requires both a valid module entitlement and the site capability", async () => {
    await expect(authorize({})).resolves.toMatchObject({ siteId: SITE_ID, sequence: 1 });
  });

  it("denies an incident-blocked module before checking capability", async () => {
    const checkSite = vi.fn(async () => true);
    const persistVerifiedSnapshot = vi.fn(async (verified: EntitlementSnapshot) => ({
      version: 1 as const,
      status: "stored" as const,
      snapshotId: "33333333-3333-4333-8333-333333333333",
      siteId: verified.siteId,
      installationId: verified.installationId,
      sequence: verified.sequence,
      digest: "a".repeat(64),
    }));
    const denied = authorize({
      value: snapshot([{ moduleId: "growth.leads", mode: "blocked", reasonCode: "SECURITY_EVENT" }]),
      checkSite,
      persistVerifiedSnapshot,
    });
    await expect(denied).rejects.toMatchObject({ status: 403 });
    expect(persistVerifiedSnapshot).toHaveBeenCalledOnce();
    expect(checkSite).not.toHaveBeenCalled();
  });

  it("persists an incident read-only override before denying writes", async () => {
    const persistVerifiedSnapshot = vi.fn(async (verified: EntitlementSnapshot) => ({
      version: 1 as const,
      status: "stored" as const,
      snapshotId: "33333333-3333-4333-8333-333333333333",
      siteId: verified.siteId,
      installationId: verified.installationId,
      sequence: verified.sequence,
      digest: "a".repeat(64),
    }));

    await expect(authorize({
      value: snapshot([{ moduleId: "growth.leads", mode: "read_only", reasonCode: "INCIDENT_42" }]),
      action: "write",
      persistVerifiedSnapshot,
    })).rejects.toMatchObject({ status: 403 });
    expect(persistVerifiedSnapshot).toHaveBeenCalledOnce();
  });

  it.each([
    ["suspended", "write"],
    ["terminated", "read"],
  ] as const)("persists a newer %s deny state before returning denial", async (state, action) => {
    const calls: string[] = [];
    const value = snapshot([], state);
    const token = await signEntitlementSnapshot({ snapshot: value, keyId: KEY_ID, privateJwk });

    const denied = requireModuleAccess({
      token,
      siteId: SITE_ID,
      installationId: INSTALLATION_ID,
      moduleId: "growth.leads",
      action,
      capability: "leads.read",
      resolveSigningKey: async (keyId) => {
        calls.push("verify");
        return { keyId, status: "active", publicJwk };
      },
      persistVerifiedSnapshot: async (verified) => {
        calls.push(`persist:${verified.modules["growth.leads"].state}`);
        return {
          version: 1,
          status: "stored",
          snapshotId: "33333333-3333-4333-8333-333333333333",
          siteId: verified.siteId,
          installationId: verified.installationId,
          sequence: verified.sequence,
          digest: "a".repeat(64),
        };
      },
      checkSite: async () => {
        calls.push("capability");
        return true;
      },
      checkRecord: async () => false,
      now: NOW,
    });

    await expect(denied).rejects.toMatchObject({ status: 403 });
    expect(calls).toEqual(["verify", `persist:${state}`]);
  });

  it("allows an identical persisted replay before capability evaluation", async () => {
    const calls: string[] = [];

    await expect(authorize({
      persistVerifiedSnapshot: async (verified) => {
        calls.push("persist:replayed");
        return {
          version: 1,
          status: "replayed",
          snapshotId: "33333333-3333-4333-8333-333333333333",
          siteId: verified.siteId,
          installationId: verified.installationId,
          sequence: verified.sequence,
          digest: "a".repeat(64),
        };
      },
      checkSite: async () => {
        calls.push("capability");
        return true;
      },
    })).resolves.toMatchObject({ sequence: 1 });
    expect(calls).toEqual(["persist:replayed", "capability"]);
  });

  it("fails closed with a sanitized health code when persistence fails", async () => {
    const denied = authorize({
      persistVerifiedSnapshot: async () => {
        throw new Error("private database detail");
      },
    });

    const error = await denied.then(
      () => null,
      (caught: unknown) => caught,
    );
    expect(error).toBeInstanceOf(Response);
    if (!(error instanceof Response)) throw new Error("Expected module access to reject with a Response");
    expect(error).toMatchObject({ status: 503 });
    expect(error.headers.get("x-builder-health-code")).toBe("verified_snapshot_store_failed");
    expect(await error.text()).not.toContain("private database detail");
  });

  it("never persists an invalid JWS", async () => {
    const persistVerifiedSnapshot = vi.fn();

    await expect(requireModuleAccess({
      token: "not-a-jws",
      siteId: SITE_ID,
      installationId: INSTALLATION_ID,
      moduleId: "growth.leads",
      action: "read",
      capability: "leads.read",
      resolveSigningKey: async () => null,
      persistVerifiedSnapshot,
      checkSite: async () => true,
      checkRecord: async () => false,
      now: NOW,
    })).rejects.toMatchObject({ code: "invalid_token" });
    expect(persistVerifiedSnapshot).not.toHaveBeenCalled();
  });

  it("denies a missing capability after entitlement verification", async () => {
    await expect(authorize({ checkSite: async () => false })).rejects.toMatchObject({ status: 403 });
  });

  it("rejects a correctly signed snapshot from another site", async () => {
    await expect(authorize({ siteId: "33333333-3333-4333-8333-333333333333" }))
      .rejects.toMatchObject({ code: "scope_mismatch" });
  });
});
