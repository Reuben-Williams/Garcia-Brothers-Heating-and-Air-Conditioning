// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  OperationalAuthorizationError,
  createLeadAssignmentRouteHandler,
  createLeadNoteRouteHandler,
  createLeadPriorityRouteHandler,
  createLeadServiceEventRouteHandler,
  createLeadStatusRouteHandler,
  createLeadTaskRouteHandler,
  createManualLeadRouteHandler,
  createReviewedSubmissionImportRouteHandler,
  createSubmissionRestoreRouteHandler,
  createSubmissionSpamRouteHandler,
  type OperationalRouteDependencies,
} from "../src/operations/server/index.js";
import type { OperationalMutationResult, OperationalResourceType } from "../src/operations/index.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const MEMBER_ID = "22222222-2222-4222-8222-222222222222";
const LEAD_ID = "33333333-3333-4333-8333-333333333333";
const CONTACT_ID = "44444444-4444-4444-8444-444444444444";
const ASSIGNEE_ID = "55555555-5555-4555-8555-555555555555";
const COMMAND_ID = "66666666-6666-4666-8666-666666666666";
const SUBMISSION_ID = "77777777-7777-4777-8777-777777777777";
const AAL2_AT = "2026-07-18T12:00:00.000Z";
const SHA256_HEX = "a".repeat(64);

function applied(
  resourceType: OperationalResourceType,
  resourceId: string,
  version?: number,
): OperationalMutationResult {
  return {
    status: "applied",
    resourceType,
    resourceId,
    ...(version === undefined ? {} : { version }),
    replayed: false,
  };
}

function dependencies(overrides: Partial<OperationalRouteDependencies> = {}): OperationalRouteDependencies {
  return {
    siteId: SITE_ID,
    allowedServices: ["ac_repair", "heating_repair"],
    now: () => new Date(AAL2_AT),
    invitationSecrets: {
      digestCanonicalEmail: vi.fn(async () => SHA256_HEX),
      generateToken: vi.fn(async () => "opaque-invitation-token"),
      hashToken: vi.fn(async () => SHA256_HEX),
    },
    authorizer: {
      authorize: vi.fn(async (_request, requirement) => ({
        siteId: SITE_ID,
        memberId: MEMBER_ID,
        role: "owner" as const,
        scope: requirement.allowedScopes[0]!,
        entitlementVerification: "current" as const,
        entitlementMode: requirement.entitlementMode,
      })),
      requireRecentAal2: vi.fn(async () => ({ verifiedAt: AAL2_AT })),
      requireAuthenticatedUser: vi.fn(async () => ({
        siteId: SITE_ID,
        userId: MEMBER_ID,
        email: "member@example.test",
        entitlementVerification: "current" as const,
        entitlementMode: "operational_write" as const,
      })),
    },
    persistence: {
      createManualLead: vi.fn(async () => applied("lead", LEAD_ID, 1)),
      applyLeadCommand: vi.fn(async () => applied("lead", LEAD_ID, 4)),
      createLeadTask: vi.fn(async () => applied("task", ASSIGNEE_ID)),
      recordLeadServiceEvent: vi.fn(async () => applied("service_event", ASSIGNEE_ID)),
      reviewFormSubmission: vi.fn(async () => applied("form_submission", SUBMISSION_ID, 3)),
      importFormSubmission: vi.fn(async () => applied("lead", LEAD_ID, 1)),
      updateCustomerProfile: vi.fn(async () => applied("customer", CONTACT_ID, 1)),
      reviewCustomerMerge: vi.fn(async () => applied("merge_suggestion", CONTACT_ID, 1)),
      executeCustomerMerge: vi.fn(async () => applied("customer", CONTACT_ID, 2)),
      requestCustomerExport: vi.fn(async () => applied("data_export", CONTACT_ID, 1)),
      requestCustomerDeletion: vi.fn(async () => applied("deletion_request", CONTACT_ID, 1)),
      markNotificationRead: vi.fn(async () => applied("notification", CONTACT_ID, 1)),
      createMemberInvitation: vi.fn(async () => applied("member_invitation", CONTACT_ID, 1)),
      revokeMemberInvitation: vi.fn(async () => applied("member_invitation", CONTACT_ID, 1)),
      acceptMemberInvitation: vi.fn(async () => applied("member", MEMBER_ID, 1)),
    },
    ...overrides,
  };
}

function request(body: Record<string, unknown>, options: { contentType?: string; headerId?: string; method?: string } = {}) {
  return new Request("https://site.test/api/builder/operations", {
    method: options.method ?? "POST",
    headers: {
      "content-type": options.contentType ?? "application/json",
      origin: "https://site.test",
      "sec-fetch-site": "same-origin",
      "x-idempotency-key": options.headerId ?? String(body.idempotencyKey ?? ""),
    },
    body: JSON.stringify(body),
  });
}

const versioned = { idempotencyKey: COMMAND_ID, expectedVersion: 3 };

describe("authenticated operational route handlers", () => {
  it("creates a manual lead from bounded client fields and trusted actor/site identity", async () => {
    const deps = dependencies();
    const response = await createManualLeadRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      source: "phone",
      firstName: " Ana ",
      lastName: " Morales ",
      phone: "+1 (973) 555-0123",
      zipCode: "07105",
      service: "ac_repair",
      urgency: "urgent",
      notes: " Called the office. ",
      assigneeId: ASSIGNEE_ID,
    }));

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "leads.create",
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
    });
    expect(deps.persistence.createManualLead).toHaveBeenCalledWith({
      siteId: SITE_ID,
      actor: { type: "member", id: MEMBER_ID },
      idempotencyKey: COMMAND_ID,
      source: "phone",
      firstName: "Ana",
      lastName: "Morales",
      phone: "+19735550123",
      zipCode: "07105",
      service: "ac_repair",
      urgency: "urgent",
      notes: "Called the office.",
      assigneeId: ASSIGNEE_ID,
    });
    await expect(response.json()).resolves.toEqual({
      result: "applied",
      resource: { type: "lead", id: LEAD_ID },
      version: 1,
      replayed: false,
    });
  });

  it.each([
    ["status", createLeadStatusRouteHandler, { ...versioned, to: "contacted" }, { operation: "status", command: { ...versioned, leadId: LEAD_ID, to: "contacted" } }, "leads.update", ["site", "assigned"]],
    ["priority", createLeadPriorityRouteHandler, { ...versioned, priority: "high" }, { operation: "priority", command: { ...versioned, leadId: LEAD_ID, priority: "high" } }, "leads.update", ["site", "assigned"]],
    ["note", createLeadNoteRouteHandler, { ...versioned, body: "Customer requested a morning call." }, { operation: "note", command: { ...versioned, leadId: LEAD_ID, body: "Customer requested a morning call." } }, "leads.update", ["site", "assigned"]],
    ["assignment", createLeadAssignmentRouteHandler, { ...versioned, assigneeId: ASSIGNEE_ID }, { operation: "assignment", command: { ...versioned, leadId: LEAD_ID, assigneeId: ASSIGNEE_ID } }, "leads.assign", ["site"]],
  ] as const)("maps the %s route to the frozen lead command", async (_name, factory, body, expected, capability, scopes) => {
    const deps = dependencies();
    const response = await factory(deps).handle(request(body), { leadId: LEAD_ID });

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability,
      allowedScopes: scopes,
      entitlementMode: "operational_write",
      resource: { type: "lead", id: LEAD_ID },
    });
    expect(deps.persistence.applyLeadCommand).toHaveBeenCalledWith({
      operation: expected.operation,
      command: {
        siteId: SITE_ID,
        actor: { type: "member", id: MEMBER_ID },
        ...expected.command,
      },
    });
  });

  it("creates a lead task with server-owned parent edges and assigned-scope self-assignment", async () => {
    const deps = dependencies();
    vi.mocked(deps.authorizer.authorize).mockResolvedValueOnce({
      siteId: SITE_ID,
      memberId: MEMBER_ID,
      role: "editor",
      scope: "assigned",
      entitlementVerification: "current",
      entitlementMode: "operational_write",
    });
    const response = await createLeadTaskRouteHandler(deps).handle(request({
      ...versioned,
      title: "Call customer",
      priority: "high",
      dueAt: "2026-07-19T13:00:00.000Z",
    }), { leadId: LEAD_ID });

    expect(response.status).toBe(200);
    expect(deps.persistence.createLeadTask).toHaveBeenCalledWith({
      expectedLeadVersion: 3,
      command: {
        siteId: SITE_ID,
        actor: { type: "member", id: MEMBER_ID },
        idempotencyKey: COMMAND_ID,
        relatedType: "lead",
        relatedId: LEAD_ID,
        leadId: LEAD_ID,
        title: "Call customer",
        assigneeId: MEMBER_ID,
        priority: "high",
        dueAt: "2026-07-19T13:00:00.000Z",
        authorizationParents: [{ type: "lead", id: LEAD_ID }],
        selfAssignmentIntent: true,
      },
    });
  });

  it("records a manual service event with a server-owned origin", async () => {
    const deps = dependencies();
    const response = await createLeadServiceEventRouteHandler(deps).handle(request({
      ...versioned,
      contactId: CONTACT_ID,
      kind: "appointment.scheduled",
      purpose: "estimate",
      scheduledAt: "2026-07-20T15:00:00.000Z",
      occurredAt: "2026-07-18T12:30:00.000Z",
      correlationId: COMMAND_ID,
    }), { leadId: LEAD_ID });

    expect(response.status).toBe(200);
    expect(deps.persistence.recordLeadServiceEvent).toHaveBeenCalledWith({
      expectedLeadVersion: 3,
      command: {
        siteId: SITE_ID,
        contactId: CONTACT_ID,
        leadId: LEAD_ID,
        kind: "appointment.scheduled",
        purpose: "estimate",
        scheduledAt: "2026-07-20T15:00:00.000Z",
        origin: { type: "manual", actor: { type: "member", id: MEMBER_ID } },
        occurredAt: "2026-07-18T12:30:00.000Z",
        correlationId: COMMAND_ID,
        idempotencyKey: COMMAND_ID,
      },
    });
  });

  it.each([
    ["spam", createSubmissionSpamRouteHandler, { ...versioned, reasonCode: "confirmed_spam" }],
    ["restore", createSubmissionRestoreRouteHandler, versioned],
  ] as const)("runs %s review under base-submission owner/editor policy", async (operation, factory, body) => {
    const deps = dependencies();
    const response = await factory(deps).handle(request(body), { submissionId: SUBMISSION_ID });

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      allowedRoles: ["owner", "editor"],
      allowedScopes: ["site"],
      entitlementMode: "base_submission_review",
      resource: { type: "form_submission", id: SUBMISSION_ID },
    });
    expect(deps.persistence.reviewFormSubmission).toHaveBeenCalledWith({
      operation,
      command: {
        siteId: SITE_ID,
        actor: { type: "member", id: MEMBER_ID },
        submissionId: SUBMISSION_ID,
        ...body,
      },
    });
    expect(deps.authorizer.requireRecentAal2).not.toHaveBeenCalled();
  });

  it("accepts review version zero for a submission with no prior review events", async () => {
    const deps = dependencies();
    const response = await createSubmissionSpamRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedVersion: 0,
      reasonCode: "confirmed_spam",
    }), { submissionId: SUBMISSION_ID });

    expect(response.status).toBe(200);
    expect(deps.persistence.reviewFormSubmission).toHaveBeenCalledWith(expect.objectContaining({
      command: expect.objectContaining({ expectedVersion: 0 }),
    }));
  });

  it("requires recent AAL2 and uses its server timestamp for reviewed import", async () => {
    const deps = dependencies();
    const response = await createReviewedSubmissionImportRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      expectedLatestResultVersion: 2,
    }), { submissionId: SUBMISSION_ID });

    expect(response.status).toBe(200);
    expect(deps.authorizer.authorize).toHaveBeenCalledWith(expect.any(Request), {
      siteId: SITE_ID,
      capability: "leads.create",
      allowedRoles: ["owner"],
      allowedScopes: ["site"],
      entitlementMode: "operational_write",
      resource: { type: "form_submission", id: SUBMISSION_ID },
    });
    expect(deps.authorizer.requireRecentAal2).toHaveBeenCalledOnce();
    expect(deps.persistence.importFormSubmission).toHaveBeenCalledWith({
      siteId: SITE_ID,
      actor: { type: "member", id: MEMBER_ID },
      submissionId: SUBMISSION_ID,
      expectedLatestResultVersion: 2,
      aal2VerifiedAt: AAL2_AT,
      idempotencyKey: COMMAND_ID,
    });
  });

  it("rejects client-owned site, actor, parent, origin, and AAL2 fields", async () => {
    const cases = [
      [createManualLeadRouteHandler, { idempotencyKey: COMMAND_ID, siteId: SITE_ID }],
      [createLeadTaskRouteHandler, { ...versioned, title: "Call", authorizationParents: [] }],
      [createLeadServiceEventRouteHandler, { ...versioned, origin: { type: "integration" } }],
      [createReviewedSubmissionImportRouteHandler, { idempotencyKey: COMMAND_ID, expectedLatestResultVersion: 2, aal2VerifiedAt: AAL2_AT }],
    ] as const;
    for (const [factory, body] of cases) {
      const deps = dependencies();
      const response = await (factory(deps).handle as Function)(request(body), { leadId: LEAD_ID, submissionId: SUBMISSION_ID });
      expect(response.status).toBe(400);
      expect(deps.authorizer.authorize).not.toHaveBeenCalled();
    }
  });

  it("enforces JSON, bounded bodies, positive expected versions, and matching UUID idempotency", async () => {
    const deps = dependencies();
    const handler = createLeadNoteRouteHandler(deps);
    const badVersion = await handler.handle(request({ ...versioned, expectedVersion: 0, body: "note" }), { leadId: LEAD_ID });
    expect(badVersion.status).toBe(400);

    const mismatch = await handler.handle(request({ ...versioned, body: "note" }, { headerId: ASSIGNEE_ID }), { leadId: LEAD_ID });
    expect(mismatch.status).toBe(400);
    await expect(mismatch.json()).resolves.toMatchObject({ error: { code: "IDEMPOTENCY_KEY_MISMATCH" } });

    const wrongMedia = await handler.handle(request({ ...versioned, body: "note" }, { contentType: "text/plain" }), { leadId: LEAD_ID });
    expect(wrongMedia.status).toBe(415);

    const oversized = await handler.handle(request({ ...versioned, body: "x".repeat(17_000) }), { leadId: LEAD_ID });
    expect(oversized.status).toBe(413);
    expect(deps.persistence.applyLeadCommand).not.toHaveBeenCalled();
  });

  it("fails authorization, site, scope, entitlement, and AAL2 checks before persistence", async () => {
    const deniedDeps = dependencies();
    vi.mocked(deniedDeps.authorizer.authorize).mockRejectedValueOnce(
      new OperationalAuthorizationError("AUTH_REQUIRED"),
    );
    const denied = await createLeadStatusRouteHandler(deniedDeps).handle(
      request({ ...versioned, to: "contacted" }),
      { leadId: LEAD_ID },
    );
    expect(denied.status).toBe(401);

    const wrongSiteDeps = dependencies();
    vi.mocked(wrongSiteDeps.authorizer.authorize).mockResolvedValueOnce({
      siteId: ASSIGNEE_ID,
      memberId: MEMBER_ID,
      role: "owner",
      scope: "site",
      entitlementVerification: "current",
      entitlementMode: "operational_write",
    });
    const wrongSite = await createLeadStatusRouteHandler(wrongSiteDeps).handle(
      request({ ...versioned, to: "contacted" }),
      { leadId: LEAD_ID },
    );
    expect(wrongSite.status).toBe(403);

    const restrictedDeps = dependencies();
    vi.mocked(restrictedDeps.authorizer.authorize).mockResolvedValueOnce({
      siteId: SITE_ID,
      memberId: MEMBER_ID,
      role: "owner",
      scope: "site",
      entitlementVerification: "current",
      entitlementMode: "base_submission_review",
    });
    const restricted = await createLeadStatusRouteHandler(restrictedDeps).handle(
      request({ ...versioned, to: "contacted" }),
      { leadId: LEAD_ID },
    );
    expect(restricted.status).toBe(409);

    const staleDeps = dependencies();
    vi.mocked(staleDeps.authorizer.authorize).mockResolvedValueOnce({
      siteId: SITE_ID,
      memberId: MEMBER_ID,
      role: "owner",
      scope: "site",
      entitlementVerification: "stale",
      entitlementMode: "operational_write",
    });
    const stale = await createLeadStatusRouteHandler(staleDeps).handle(
      request({ ...versioned, to: "contacted" }),
      { leadId: LEAD_ID },
    );
    expect(stale.status).toBe(409);
    expect(staleDeps.persistence.applyLeadCommand).not.toHaveBeenCalled();

    const aal2Deps = dependencies();
    vi.mocked(aal2Deps.authorizer.requireRecentAal2).mockRejectedValueOnce(
      new OperationalAuthorizationError("AAL2_REQUIRED"),
    );
    const aal2 = await createReviewedSubmissionImportRouteHandler(aal2Deps).handle(
      request({ idempotencyKey: COMMAND_ID, expectedLatestResultVersion: 2 }),
      { submissionId: SUBMISSION_ID },
    );
    expect(aal2.status).toBe(403);
    expect(aal2Deps.persistence.importFormSubmission).not.toHaveBeenCalled();
  });

  it("maps conflict and denied persistence outcomes to generic envelopes", async () => {
    const conflictDeps = dependencies();
    vi.mocked(conflictDeps.persistence.applyLeadCommand).mockResolvedValueOnce({
      status: "conflict",
      expectedVersion: 3,
      actualVersion: 4,
    });
    const conflict = await createLeadStatusRouteHandler(conflictDeps).handle(
      request({ ...versioned, to: "contacted" }),
      { leadId: LEAD_ID },
    );
    expect(conflict.status).toBe(409);
    await expect(conflict.json()).resolves.toEqual({ result: "conflict", expectedVersion: 3, actualVersion: 4 });

    const deniedDeps = dependencies();
    vi.mocked(deniedDeps.persistence.applyLeadCommand).mockResolvedValueOnce({
      status: "denied",
      reason: "not_found",
    });
    const denied = await createLeadStatusRouteHandler(deniedDeps).handle(
      request({ ...versioned, to: "contacted" }),
      { leadId: LEAD_ID },
    );
    expect(denied.status).toBe(403);
    await expect(denied.json()).resolves.toEqual({ result: "denied", code: "OPERATION_DENIED" });
  });

  it("returns a generic unavailable error without leaking PII or SQL/provider details", async () => {
    const deps = dependencies();
    vi.mocked(deps.persistence.createManualLead).mockRejectedValueOnce(
      new Error("duplicate customer secret@example.test from SQL function private_schema.fn"),
    );
    const response = await createManualLeadRouteHandler(deps).handle(request({
      idempotencyKey: COMMAND_ID,
      source: "phone",
      firstName: "Ana",
      lastName: "Morales",
      phone: "+19735550123",
      zipCode: "07105",
      service: "ac_repair",
      urgency: "standard",
    }));
    const text = await response.text();
    expect(response.status).toBe(503);
    expect(text).toContain("OPERATION_UNAVAILABLE");
    expect(text).not.toContain("secret@example.test");
    expect(text).not.toContain("private_schema");
  });
});
