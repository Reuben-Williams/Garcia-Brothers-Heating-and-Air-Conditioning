import { describe, expect, it } from "vitest";

import * as commandRegistryModule from "../src/provisioning/command-registry.js";

const api = commandRegistryModule as Record<string, unknown>;

type CompensationMode = "none" | "automatic" | "operator_runbook";

interface ProvisioningStepDefinition {
  readonly type: string;
  readonly version: number;
  readonly compensation: CompensationMode;
  readonly validate: (payload: unknown) => Record<string, unknown>;
  readonly compensate?: (input: unknown) => unknown;
  readonly operatorRunbookId?: string;
}

interface ProvisioningCommandRegistry {
  readonly definitions: readonly ProvisioningStepDefinition[];
  readonly get: (type: string, version: number) => ProvisioningStepDefinition | undefined;
}

type RegistryErrorCode =
  | "DUPLICATE_COMMAND"
  | "INVALID_COMMAND_TYPE"
  | "INVALID_COMMAND_VERSION"
  | "MISSING_COMPENSATOR"
  | "MISSING_RUNBOOK_ID";

const createRegistry = () =>
  api.createProvisioningCommandRegistry as (
    definitions: readonly ProvisioningStepDefinition[],
  ) => ProvisioningCommandRegistry;

function step(
  overrides: Partial<ProvisioningStepDefinition> = {},
): ProvisioningStepDefinition {
  return {
    type: "configure-growth-leads",
    version: 1,
    compensation: "none",
    validate: (payload) => payload as Record<string, unknown>,
    ...overrides,
  };
}

function expectRegistryError(
  definitions: readonly ProvisioningStepDefinition[],
  code: RegistryErrorCode,
): void {
  expect(() => createRegistry()(definitions)).toThrow(
    expect.objectContaining({ code }),
  );
}

describe("provisioning command registry", () => {
  it("creates a frozen versioned registry with deterministic lookups", () => {
    expect(typeof api.createProvisioningCommandRegistry).toBe("function");
    const first = step();
    const second = step({ type: "seed-disabled-template", version: 2 });

    const registry = createRegistry()([first, second]);

    expect(registry.definitions).toEqual([first, second]);
    expect(registry.get(first.type, first.version)).toEqual(first);
    expect(registry.get(second.type, second.version)).toEqual(second);
    expect(registry.get(second.type, 1)).toBeUndefined();
    expect(Object.isFrozen(registry)).toBe(true);
    expect(Object.isFrozen(registry.definitions)).toBe(true);
    expect(registry.definitions[0]).not.toBe(first);
    expect(Object.isFrozen(registry.definitions[0])).toBe(true);
  });

  it("rejects duplicate command type and version pairs", () => {
    expectRegistryError([
      step(),
      step({ compensation: "operator_runbook", operatorRunbookId: "growth-leads-recovery" }),
    ], "DUPLICATE_COMMAND");

    expect(() => createRegistry()([step(), step({ version: 2 })])).not.toThrow();
  });

  it.each([0, -1, 1.5, Number.NaN, Number.POSITIVE_INFINITY])(
    "rejects invalid command version %s",
    (version) => {
      expectRegistryError([step({ version })], "INVALID_COMMAND_VERSION");
    },
  );

  it("rejects blank command types", () => {
    expectRegistryError([step({ type: "   " })], "INVALID_COMMAND_TYPE");
  });

  it("rejects automatic compensation without a compensator", () => {
    expectRegistryError([
      step({ compensation: "automatic", compensate: undefined }),
    ], "MISSING_COMPENSATOR");

    expect(() => createRegistry()([
      step({ compensation: "automatic", compensate: () => ({ resultCode: "REMOVED" }) }),
    ])).not.toThrow();
  });

  it.each([undefined, "", "   "])(
    "rejects operator-runbook compensation without a non-empty runbook ID",
    (operatorRunbookId) => {
      expectRegistryError([
        step({ compensation: "operator_runbook", operatorRunbookId }),
      ], "MISSING_RUNBOOK_ID");
    },
  );
});
