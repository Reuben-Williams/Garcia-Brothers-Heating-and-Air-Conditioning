// @vitest-environment node

import { exportJWK, generateKeyPair } from "jose";
import { beforeAll, describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  EntitlementSnapshotError,
  signEntitlementSnapshot,
  verifyEntitlementSnapshot,
} from "../src/server/index.js";
import {
  isEntitlementSnapshot,
  type EntitlementSnapshot,
} from "../src/entitlements/snapshot-contract.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const INSTALLATION_ID = "22222222-2222-4222-8222-222222222222";
const NOW = new Date("2026-07-17T12:00:00.000Z");

let privateJwk: JsonWebKey;
let publicJwk: JsonWebKey;

function snapshot(overrides: Partial<EntitlementSnapshot> = {}): EntitlementSnapshot {
  const module = { state: "active" as const, moduleVersion: "1.0.0", setupComplete: true };
  return {
    version: 1,
    siteId: SITE_ID,
    installationId: INSTALLATION_ID,
    issuedAt: "2026-07-17T12:00:00.000Z",
    expiresAt: "2026-07-18T12:00:00.000Z",
    sequence: 7,
    modules: {
      "core.website": module,
      "growth.dashboard": module,
      "growth.leads": module,
      "growth.customers": module,
      "growth.messaging": module,
      "growth.automations": module,
      "growth.reviews": module,
      "growth.projects": module,
      "growth.ai": module,
      "growth.chat": module,
    },
    incidentOverrides: [],
    ...overrides,
  };
}

async function token(value = snapshot(), keyId = "entitlements-2026-07"): Promise<string> {
  return await signEntitlementSnapshot({ snapshot: value, keyId, privateJwk });
}

function canonicalModules(
  moduleId: keyof EntitlementSnapshot["modules"] = "growth.leads",
  state: "active" | "grace_period" = "grace_period",
  graceExpiresAt: unknown = "2026-07-20T12:00:00.000Z",
): EntitlementSnapshot["modules"] {
  const source = snapshot().modules;
  const modules = Object.fromEntries(
    Object.entries(source).map(([id, module]) => [id, { ...module, graceExpiresAt: null }]),
  ) as EntitlementSnapshot["modules"];
  return {
    ...modules,
    [moduleId]: {
      ...modules[moduleId],
      state,
      graceExpiresAt,
    },
  } as EntitlementSnapshot["modules"];
}

const activeKey = async (keyId: string) => keyId === "entitlements-2026-07"
  ? { keyId, status: "active" as const, publicJwk }
  : null;

beforeAll(async () => {
  const pair = await generateKeyPair("Ed25519", { extractable: true });
  privateJwk = { ...(await exportJWK(pair.privateKey)), alg: "EdDSA" };
  publicJwk = { ...(await exportJWK(pair.publicKey)), alg: "EdDSA" };
});

describe("signed entitlement snapshots", () => {
  it("round-trips an exact active-key EdDSA snapshot", async () => {
    await expect(verifyEntitlementSnapshot({
      token: await token(),
      expectedSiteId: SITE_ID,
      expectedInstallationId: INSTALLATION_ID,
      resolveSigningKey: activeKey,
      now: NOW,
    })).resolves.toEqual(snapshot());
  });

  it("accepts canonical grace deadlines while retaining legacy V1 compatibility", () => {
    expect(isEntitlementSnapshot(snapshot())).toBe(true);
    expect(isEntitlementSnapshot(snapshot({ modules: canonicalModules() }))).toBe(true);
  });

  it.each([
    ["a null grace-period deadline", canonicalModules("growth.leads", "grace_period", null)],
    ["a malformed grace-period deadline", canonicalModules("growth.leads", "grace_period", "2026-07-20")],
    ["a non-null active deadline", canonicalModules("growth.leads", "active", "2026-07-20T12:00:00.000Z")],
  ])("rejects %s in a canonical module payload", (_label, modules) => {
    expect(isEntitlementSnapshot(snapshot({ modules }))).toBe(false);
  });

  it.each([
    ["site", { expectedSiteId: "33333333-3333-4333-8333-333333333333" }],
    ["installation", { expectedInstallationId: "44444444-4444-4444-8444-444444444444" }],
  ])("rejects a snapshot for the wrong %s", async (_label, scope) => {
    await expect(verifyEntitlementSnapshot({
      token: await token(),
      expectedSiteId: SITE_ID,
      expectedInstallationId: INSTALLATION_ID,
      resolveSigningKey: activeKey,
      now: NOW,
      ...scope,
    })).rejects.toMatchObject({ code: "scope_mismatch" });
  });

  it("rejects an altered compact JWS payload", async () => {
    const signed = await token();
    const [header, payload, signature] = signed.split(".");
    const altered = `${header}.${payload!.slice(0, -1)}A.${signature}`;
    await expect(verifyEntitlementSnapshot({
      token: altered,
      expectedSiteId: SITE_ID,
      expectedInstallationId: INSTALLATION_ID,
      resolveSigningKey: activeKey,
      now: NOW,
    })).rejects.toBeInstanceOf(EntitlementSnapshotError);
  });

  it.each(["unknown", "retired", "revoked"] as const)("rejects a %s signing key", async (status) => {
    await expect(verifyEntitlementSnapshot({
      token: await token(),
      expectedSiteId: SITE_ID,
      expectedInstallationId: INSTALLATION_ID,
      resolveSigningKey: async (keyId) => status === "unknown"
        ? null
        : { keyId, status, publicJwk },
      now: NOW,
    })).rejects.toMatchObject({ code: "signing_key_unavailable" });
  });

  it("rejects future-issued and over-24-hour snapshots", async () => {
    const future = snapshot({
      issuedAt: "2026-07-17T12:00:01.000Z",
      expiresAt: "2026-07-18T12:00:01.000Z",
    });
    const overlong = snapshot({ expiresAt: "2026-07-18T12:00:00.001Z" });

    for (const value of [future, overlong]) {
      await expect(verifyEntitlementSnapshot({
        token: await token(value),
        expectedSiteId: SITE_ID,
        expectedInstallationId: INSTALLATION_ID,
        resolveSigningKey: activeKey,
        now: NOW,
      })).rejects.toMatchObject({ code: "invalid_timing" });
    }
  });

  it("rejects malformed modules and incident overrides before signing", async () => {
    await expect(signEntitlementSnapshot({
      snapshot: snapshot({ modules: { "growth.unknown": { state: "active", moduleVersion: "1", setupComplete: true } } as never }),
      keyId: "entitlements-2026-07",
      privateJwk,
    })).rejects.toMatchObject({ code: "invalid_snapshot" });
  });
});
