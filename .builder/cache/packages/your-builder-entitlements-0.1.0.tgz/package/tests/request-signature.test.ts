import { describe, expect, it, vi } from "vitest";

import {
  InstallationRequestVerificationError,
  canonicalInstallationRequest,
  signInstallationRequest,
  verifyInstallationRequest,
  type InstallationRequestHeaders,
  type NonceConsumer,
  type PublicKeyResolver,
} from "@your-builder/entitlements/trust";

const INSTALLATION_ID = "11111111-1111-4111-8111-111111111111";
const OTHER_INSTALLATION_ID = "22222222-2222-4222-8222-222222222222";
const KEY_ID = "key-2026-07";
const TIMESTAMP = "2026-07-16T12:00:00.000Z";
const NONCE = "AQIDBAUGBwgJCgsMDQ4PEA";
const PATH = "/api/platform/v1/installations/commands/pull?limit=10";
const BODY = new TextEncoder().encode('{"action":"pull","items":[1,2]}');

// RFC 8032 test-vector key material, represented as JWK for jose/Web Crypto.
const PRIVATE_JWK: JsonWebKey = {
  kty: "OKP",
  crv: "Ed25519",
  alg: "EdDSA",
  x: "11qYAYKxCrfVS_7TyWQHOg7hcvPapiMlrwIaaPcHURo",
  d: "nWGxne_9WmC6hEr0kuwsxERJxWl7MmkZcDusAxyuf2A",
};

const PUBLIC_JWK: JsonWebKey = {
  kty: "OKP",
  crv: "Ed25519",
  alg: "EdDSA",
  x: "11qYAYKxCrfVS_7TyWQHOg7hcvPapiMlrwIaaPcHURo",
};

const EXPECTED_DIGEST = "oL--el-43BacCFGDLdfkqYS6unClovL5GANX413qxMQ";
const EXPECTED_SIGNATURE =
  "yZi8988a4K0Ha4ZZMjKtsc1U27xsehO_hzQZqULyNQrBAykCOH_PZC1zjFOoqCPjn3oqULzc3fuuu4GVacI_Cw";

function resolver(publicJwk: JsonWebKey | null = PUBLIC_JWK): PublicKeyResolver {
  return vi.fn(async () => publicJwk);
}

function nonceConsumer(result = true): NonceConsumer {
  return vi.fn(async () => result);
}

async function signedHeaders(
  overrides: Partial<{
    installationId: string;
    keyId: string;
    method: string;
    path: string;
    timestamp: string;
    nonce: string;
    bodyBytes: Uint8Array;
    privateJwk: JsonWebKey;
  }> = {},
): Promise<InstallationRequestHeaders> {
  return signInstallationRequest({
    installationId: INSTALLATION_ID,
    keyId: KEY_ID,
    method: "POST",
    path: PATH,
    timestamp: TIMESTAMP,
    nonce: NONCE,
    bodyBytes: BODY,
    privateJwk: PRIVATE_JWK,
    ...overrides,
  });
}

function expectVerificationCode(promise: Promise<unknown>, code: string) {
  return expect(promise).rejects.toMatchObject({
    name: "InstallationRequestVerificationError",
    code,
  });
}

describe("canonicalInstallationRequest", () => {
  it("matches the approved seven-line canonical request and fixed Ed25519 vector", async () => {
    const canonical = canonicalInstallationRequest({
      installationId: INSTALLATION_ID,
      method: "post",
      path: PATH,
      timestamp: TIMESTAMP,
      nonce: NONCE,
      bodyBytes: BODY,
    });

    expect(canonical).toBe(
      [
        "builder-installation-v1",
        INSTALLATION_ID,
        "POST",
        PATH,
        TIMESTAMP,
        NONCE,
        EXPECTED_DIGEST,
      ].join("\n"),
    );

    await expect(signedHeaders()).resolves.toEqual({
      installationId: INSTALLATION_ID,
      keyId: KEY_ID,
      timestamp: TIMESTAMP,
      nonce: NONCE,
      signature: EXPECTED_SIGNATURE,
    });
  });

  it("hashes the exact raw body bytes without parsing or normalization", () => {
    const bytes = Uint8Array.from([0x7b, 0x0a, 0x20, 0x22, 0xff, 0x22, 0x3a, 0x31, 0x7d, 0x0a]);
    const canonical = canonicalInstallationRequest({
      installationId: INSTALLATION_ID,
      method: "POST",
      path: PATH,
      timestamp: TIMESTAMP,
      nonce: NONCE,
      bodyBytes: bytes,
    });

    expect(canonical.split("\n").at(-1)).toBe("YqE1cynLQF2k-A0Eem5C6_16HN8Kljg-BM-IaydaU9g");
  });
});

describe("verifyInstallationRequest", () => {
  it("accepts the fixed vector and consumes its nonce exactly once after key resolution", async () => {
    const headers = await signedHeaders();
    const events: string[] = [];
    const resolvePublicKey: PublicKeyResolver = vi.fn(async (installationId, keyId) => {
      events.push(`resolve:${installationId}:${keyId}`);
      return PUBLIC_JWK;
    });
    const consumeNonce: NonceConsumer = vi.fn(async (installationId, nonce, expiresAt) => {
      events.push(`consume:${installationId}:${nonce}:${expiresAt.toISOString()}`);
      return true;
    });

    await expect(
      verifyInstallationRequest({
        headers,
        method: "POST",
        path: PATH,
        bodyBytes: BODY,
        now: new Date(TIMESTAMP),
        resolvePublicKey,
        consumeNonce,
      }),
    ).resolves.toEqual({
      installationId: INSTALLATION_ID,
      keyId: KEY_ID,
      timestamp: TIMESTAMP,
      nonce: NONCE,
    });
    expect(events).toEqual([
      `resolve:${INSTALLATION_ID}:${KEY_ID}`,
      `consume:${INSTALLATION_ID}:${NONCE}:2026-07-16T12:05:00.000Z`,
    ]);
  });

  it.each([
    ["method", { method: "PUT" }],
    ["path", { path: `${PATH}&cursor=next` }],
    ["body", { bodyBytes: new TextEncoder().encode('{"action":"push","items":[1,2]}') }],
  ])("rejects an altered %s before consuming the nonce", async (_label, altered) => {
    const consumeNonce = nonceConsumer();
    await expectVerificationCode(
      verifyInstallationRequest({
        headers: await signedHeaders(),
        method: "POST",
        path: PATH,
        bodyBytes: BODY,
        now: new Date(TIMESTAMP),
        resolvePublicKey: resolver(),
        consumeNonce,
        ...altered,
      }),
      "invalid_signature",
    );
    expect(consumeNonce).not.toHaveBeenCalled();
  });

  it("rejects the wrong installation ID before consuming the nonce", async () => {
    const consumeNonce = nonceConsumer();
    const headers = { ...(await signedHeaders()), installationId: OTHER_INSTALLATION_ID };

    await expectVerificationCode(
      verifyInstallationRequest({
        headers,
        method: "POST",
        path: PATH,
        bodyBytes: BODY,
        now: new Date(TIMESTAMP),
        resolvePublicKey: resolver(),
        consumeNonce,
      }),
      "invalid_signature",
    );
    expect(consumeNonce).not.toHaveBeenCalled();
  });

  it("rejects timestamps older than five minutes before resolving a key", async () => {
    const resolvePublicKey = resolver();
    await expectVerificationCode(
      verifyInstallationRequest({
        headers: await signedHeaders(),
        method: "POST",
        path: PATH,
        bodyBytes: BODY,
        now: new Date("2026-07-16T12:05:00.001Z"),
        resolvePublicKey,
        consumeNonce: nonceConsumer(),
      }),
      "timestamp_out_of_range",
    );
    expect(resolvePublicKey).not.toHaveBeenCalled();
  });

  it("rejects timestamps more than five minutes in the future", async () => {
    const resolvePublicKey = resolver();
    await expectVerificationCode(
      verifyInstallationRequest({
        headers: await signedHeaders(),
        method: "POST",
        path: PATH,
        bodyBytes: BODY,
        now: new Date("2026-07-16T11:54:59.999Z"),
        resolvePublicKey,
        consumeNonce: nonceConsumer(),
      }),
      "timestamp_out_of_range",
    );
    expect(resolvePublicKey).not.toHaveBeenCalled();
  });

  it("accepts timestamps exactly on both five-minute boundaries", async () => {
    const headers = await signedHeaders();
    for (const now of ["2026-07-16T11:55:00.000Z", "2026-07-16T12:05:00.000Z"]) {
      await expect(
        verifyInstallationRequest({
          headers,
          method: "POST",
          path: PATH,
          bodyBytes: BODY,
          now: new Date(now),
          resolvePublicKey: resolver(),
          consumeNonce: nonceConsumer(),
        }),
      ).resolves.toMatchObject({ installationId: INSTALLATION_ID });
    }
  });

  it("rejects a duplicate nonce when atomic consumption returns false", async () => {
    const consumeNonce = nonceConsumer(false);
    await expectVerificationCode(
      verifyInstallationRequest({
        headers: await signedHeaders(),
        method: "POST",
        path: PATH,
        bodyBytes: BODY,
        now: new Date(TIMESTAMP),
        resolvePublicKey: resolver(),
        consumeNonce,
      }),
      "nonce_replayed",
    );
    expect(consumeNonce).toHaveBeenCalledOnce();
  });

  it("does not accept when atomic nonce consumption fails", async () => {
    const storageError = new Error("nonce store unavailable");
    const consumeNonce: NonceConsumer = vi.fn(async () => {
      throw storageError;
    });

    await expect(
      verifyInstallationRequest({
        headers: await signedHeaders(),
        method: "POST",
        path: PATH,
        bodyBytes: BODY,
        now: new Date(TIMESTAMP),
        resolvePublicKey: resolver(),
        consumeNonce,
      }),
    ).rejects.toBe(storageError);
  });

  it("rejects an unknown key ID before consuming the nonce", async () => {
    const consumeNonce = nonceConsumer();
    await expectVerificationCode(
      verifyInstallationRequest({
        headers: await signedHeaders({ keyId: "unknown-key" }),
        method: "POST",
        path: PATH,
        bodyBytes: BODY,
        now: new Date(TIMESTAMP),
        resolvePublicKey: resolver(null),
        consumeNonce,
      }),
      "unknown_key",
    );
    expect(consumeNonce).not.toHaveBeenCalled();
  });

  it.each([
    ["timestamp", { timestamp: "2026-07-16 12:00:00Z" }, "malformed_timestamp"],
    ["timestamp", { timestamp: "not-a-date" }, "malformed_timestamp"],
    ["nonce", { nonce: "short" }, "malformed_nonce"],
    ["nonce", { nonce: "AQIDBAUGBwgJCgsMDQ4PE+" }, "malformed_nonce"],
    ["signature", { signature: "not+base64url" }, "malformed_signature"],
    ["signature", { signature: "AA" }, "malformed_signature"],
  ])("rejects a malformed %s", async (_label, headerOverride, code) => {
    const consumeNonce = nonceConsumer();
    const headers = { ...(await signedHeaders()), ...headerOverride };
    await expectVerificationCode(
      verifyInstallationRequest({
        headers,
        method: "POST",
        path: PATH,
        bodyBytes: BODY,
        now: new Date(TIMESTAMP),
        resolvePublicKey: resolver(),
        consumeNonce,
      }),
      code,
    );
    expect(consumeNonce).not.toHaveBeenCalled();
  });

  it.each([
    ["private key presented as public", PRIVATE_JWK],
    ["wrong curve", { ...PUBLIC_JWK, crv: "X25519" }],
    ["wrong algorithm", { ...PUBLIC_JWK, alg: "ECDH-ES" }],
    ["malformed public coordinate", { ...PUBLIC_JWK, x: "AA" }],
  ])("rejects an invalid public JWK: %s", async (_label, publicJwk) => {
    const consumeNonce = nonceConsumer();
    await expectVerificationCode(
      verifyInstallationRequest({
        headers: await signedHeaders(),
        method: "POST",
        path: PATH,
        bodyBytes: BODY,
        now: new Date(TIMESTAMP),
        resolvePublicKey: resolver(publicJwk),
        consumeNonce,
      }),
      "invalid_public_key",
    );
    expect(consumeNonce).not.toHaveBeenCalled();
  });

  it("exposes a typed verification error without retaining request or key material", () => {
    const error = new InstallationRequestVerificationError("invalid_signature", "Invalid signature");

    expect(error).toMatchObject({
      name: "InstallationRequestVerificationError",
      code: "invalid_signature",
      message: "Invalid signature",
    });
    expect(JSON.stringify(error)).not.toContain("privateJwk");
  });
});
