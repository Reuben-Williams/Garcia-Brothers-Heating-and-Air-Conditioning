import { describe, expect, it } from "vitest";

import * as entitlementsModule from "@your-builder/entitlements";

const api = entitlementsModule as Record<string, unknown>;

const EXPECTED_ACCESS = {
  available: { demo: true, repair: "request_only", read: "none", write: "none", outbound: "none", export: "none" },
  requested: { demo: true, repair: "request_only", read: "none", write: "none", outbound: "none", export: "none" },
  request_withdrawn: { demo: true, repair: "request_only", read: "none", write: "none", outbound: "none", export: "none" },
  trial_expired: { demo: true, repair: "request_only", read: "none", write: "none", outbound: "none", export: "none" },
  provisioning: { demo: true, repair: "provisioning", read: "none", write: "provisioning_commands", outbound: "none", export: "none" },
  provisioning_error: { demo: true, repair: "provisioning", read: "none", write: "provisioning_commands", outbound: "none", export: "none" },
  setup_required: { demo: true, repair: "setup", read: "setup_records", write: "setup_actions", outbound: "test_destinations", export: "full" },
  trialing: { demo: true, repair: "normal", read: "operational", write: "operational", outbound: "operational", export: "full" },
  active: { demo: false, repair: "normal", read: "operational", write: "operational", outbound: "operational", export: "full" },
  payment_attention: { demo: false, repair: "billing_reconnect", read: "operational", write: "operational", outbound: "operational", export: "full" },
  grace_period: { demo: false, repair: "billing_reconnect", read: "operational", write: "operational", outbound: "operational", export: "full" },
  suspended: { demo: false, repair: "billing_reconnect", read: "operational", write: "repair_notes", outbound: "none", export: "full" },
  offboarding: { demo: false, repair: "offboarding", read: "operational", write: "offboarding_actions", outbound: "none", export: "full" },
  termination_failed: { demo: false, repair: "offboarding", read: "operational", write: "offboarding_actions", outbound: "none", export: "full" },
  terminated: { demo: false, repair: "reactivation", read: "none", write: "none", outbound: "none", export: "completed_only" },
} as const;

type State = keyof typeof EXPECTED_ACCESS;
type AccessPolicy = (typeof EXPECTED_ACCESS)[State];

const resolveAccess = () =>
  api.resolveEntitlementAccess as (input: {
    state: State;
    now: string;
    graceDeadline?: string | null;
  }) => AccessPolicy;

describe("entitlement access policy", () => {
  it("defines an exact, frozen access row for every entitlement state", () => {
    expect(api.ENTITLEMENT_ACCESS).toEqual(EXPECTED_ACCESS);

    const access = api.ENTITLEMENT_ACCESS as Record<State, AccessPolicy>;
    for (const state of Object.keys(EXPECTED_ACCESS) as State[]) {
      expect(Object.isFrozen(access[state]), state).toBe(true);
    }
    expect(Object.isFrozen(access)).toBe(true);
  });

  it("returns the unchanged row for every non-grace state", () => {
    expect(typeof api.resolveEntitlementAccess).toBe("function");

    for (const state of Object.keys(EXPECTED_ACCESS) as State[]) {
      if (state === "grace_period") continue;
      expect(
        resolveAccess()({
          state,
          now: "2026-07-17T12:00:00.000Z",
          graceDeadline: "2020-01-01T00:00:00.000Z",
        }),
      ).toBe((api.ENTITLEMENT_ACCESS as Record<State, AccessPolicy>)[state]);
    }
  });

  it("allows grace-period operations only before the deadline", () => {
    expect(
      resolveAccess()({
        state: "grace_period",
        now: "2026-07-17T12:00:00.000Z",
        graceDeadline: "2026-07-17T12:00:00.001Z",
      }),
    ).toBe((api.ENTITLEMENT_ACCESS as Record<State, AccessPolicy>).grace_period);

    expect(
      resolveAccess()({
        state: "grace_period",
        now: "2026-07-17T12:00:00.000Z",
        graceDeadline: "2026-07-17T12:00:00.000Z",
      }),
    ).toEqual({
      ...EXPECTED_ACCESS.grace_period,
      write: "none",
      outbound: "none",
    });
  });

  it.each([undefined, null, "", "not-a-time"])(
    "fails closed when a grace deadline is missing or invalid: %j",
    (graceDeadline) => {
      const decision = resolveAccess()({
        state: "grace_period",
        now: "2026-07-17T12:00:00.000Z",
        graceDeadline,
      });

      expect(decision).toEqual({
        ...EXPECTED_ACCESS.grace_period,
        write: "none",
        outbound: "none",
      });
      expect(Object.isFrozen(decision)).toBe(true);
    },
  );

  it("rejects an invalid control-plane time instead of making an unsafe decision", () => {
    expect(() =>
      resolveAccess()({
        state: "grace_period",
        now: "not-a-time",
        graceDeadline: "2026-07-17T13:00:00.000Z",
      }),
    ).toThrow(expect.objectContaining({ code: "invalid_time" }));
  });
});
