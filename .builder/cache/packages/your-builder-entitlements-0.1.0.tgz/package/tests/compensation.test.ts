import { describe, expect, it } from "vitest";

import * as entitlementsModule from "@your-builder/entitlements";

const api = entitlementsModule as Record<string, unknown>;

interface Step {
  readonly id: string;
  readonly order: number;
  readonly status:
    | "pending"
    | "running"
    | "succeeded"
    | "failed"
    | "compensated"
    | "compensation_failed"
    | "skipped";
  readonly commandId: string;
  readonly idempotencyKey: string;
  readonly attempts: number;
  readonly retryAt: string | null;
  readonly compensation: "none" | "automatic" | "operator_runbook";
  readonly runbookId: string | null;
  readonly compensationCommandId: string;
  readonly compensationIdempotencyKey: string;
}

const nextCompensation = () =>
  api.nextCompensationAction as (steps: readonly Step[]) => Record<string, unknown>;

const failureDisposition = () =>
  api.provisioningFailureDisposition as (input: {
    readonly kind: "new_module" | "upgrade";
    readonly previousEntitlementState: "provisioning" | "active";
    readonly currentModuleVersion: string | null;
    readonly compensationStatus: "succeeded" | "failed";
    readonly cleanupConfirmation: "pending" | "confirmed" | "failed";
  }) => Record<string, unknown>;

function step(overrides: Partial<Step> = {}): Step {
  return {
    id: "step-1",
    order: 1,
    status: "succeeded",
    commandId: "command-1",
    idempotencyKey: "provision:run-1:step-1",
    attempts: 1,
    retryAt: null,
    compensation: "automatic",
    runbookId: null,
    compensationCommandId: "compensation-command-1",
    compensationIdempotencyKey: "provision:run-1:step-1:compensate",
    ...overrides,
  };
}

describe("provisioning compensation", () => {
  it("compensates successful automatic steps in reverse order", () => {
    expect(typeof api.nextCompensationAction).toBe("function");

    expect(
      nextCompensation()([
        step(),
        step({ id: "step-2", order: 2, compensation: "none" }),
        step({
          id: "step-3",
          order: 3,
          compensationCommandId: "compensation-command-3",
          compensationIdempotencyKey: "provision:run-1:step-3:compensate",
        }),
      ]),
    ).toEqual({
      type: "compensate",
      stepId: "step-3",
      commandId: "compensation-command-3",
      idempotencyKey: "provision:run-1:step-3:compensate",
    });
  });

  it("pauses at an operator-runbook step before compensating earlier work", () => {
    expect(
      nextCompensation()([
        step(),
        step({
          id: "step-2",
          order: 2,
          compensation: "operator_runbook",
          runbookId: "provisioning/manual-customer-export-cleanup",
        }),
      ]),
    ).toEqual({
      type: "pause_operator",
      stepId: "step-2",
      runbookId: "provisioning/manual-customer-export-cleanup",
    });
  });

  it("records a non-compensable successful step as skipped before earlier work", () => {
    expect(
      nextCompensation()([
        step(),
        step({ id: "step-2", order: 2, compensation: "none" }),
      ]),
    ).toEqual({ type: "skip_compensation", stepId: "step-2" });
  });

  it("moves failed new activation through offboarding before termination", () => {
    expect(typeof api.provisioningFailureDisposition).toBe("function");

    expect(
      failureDisposition()({
        kind: "new_module",
        previousEntitlementState: "provisioning",
        currentModuleVersion: null,
        compensationStatus: "succeeded",
        cleanupConfirmation: "pending",
      }),
    ).toEqual({
      entitlementState: "offboarding",
      preservedModuleVersion: null,
      incidentMode: null,
      requiresCleanupConfirmation: true,
    });
  });

  it("terminates a failed new activation only after cleanup confirmation", () => {
    expect(
      failureDisposition()({
        kind: "new_module",
        previousEntitlementState: "provisioning",
        currentModuleVersion: null,
        compensationStatus: "succeeded",
        cleanupConfirmation: "confirmed",
      }),
    ).toEqual({
      entitlementState: "terminated",
      preservedModuleVersion: null,
      incidentMode: null,
      requiresCleanupConfirmation: false,
    });
  });

  it("marks failed cleanup as termination failed", () => {
    expect(
      failureDisposition()({
        kind: "new_module",
        previousEntitlementState: "provisioning",
        currentModuleVersion: null,
        compensationStatus: "failed",
        cleanupConfirmation: "failed",
      }),
    ).toEqual({
      entitlementState: "termination_failed",
      preservedModuleVersion: null,
      incidentMode: null,
      requiresCleanupConfirmation: false,
    });
  });

  it("preserves the installed version in read-only mode when an upgrade fails", () => {
    expect(
      failureDisposition()({
        kind: "upgrade",
        previousEntitlementState: "active",
        currentModuleVersion: "1.4.0",
        compensationStatus: "failed",
        cleanupConfirmation: "pending",
      }),
    ).toEqual({
      entitlementState: "active",
      preservedModuleVersion: "1.4.0",
      incidentMode: "read_only",
      requiresCleanupConfirmation: false,
    });
  });
});
