// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import {
  createEntitlementSnapshotCache,
  decideSnapshotAccess,
} from "../src/server/index.js";
import type { EntitlementSnapshot } from "../src/entitlements/snapshot-contract.js";

const SITE_ID = "11111111-1111-4111-8111-111111111111";
const INSTALLATION_ID = "22222222-2222-4222-8222-222222222222";

function snapshot(input: {
  sequence?: number;
  issuedAt?: string;
  expiresAt?: string;
  state?: "active" | "setup_required" | "suspended";
  incidents?: EntitlementSnapshot["incidentOverrides"];
} = {}): EntitlementSnapshot {
  const module = {
    state: input.state ?? "active",
    moduleVersion: "1.0.0",
    setupComplete: input.state !== "setup_required",
  } as const;
  return {
    version: 1,
    siteId: SITE_ID,
    installationId: INSTALLATION_ID,
    issuedAt: input.issuedAt ?? "2026-07-17T00:00:00.000Z",
    expiresAt: input.expiresAt ?? "2026-07-18T00:00:00.000Z",
    sequence: input.sequence ?? 1,
    modules: {
      "core.website": module,
      "growth.dashboard": module,
      "growth.leads": module,
      "growth.customers": module,
      "growth.messaging": module,
      "growth.automations": module,
      "growth.reviews": module,
      "growth.projects": module,
      "growth.ai": module,
      "growth.chat": module,
    },
    incidentOverrides: input.incidents ?? [],
  };
}

describe("entitlement snapshot outage behavior", () => {
  it("fails closed when no verified snapshot exists", () => {
    for (const action of ["read", "write", "outbound", "export"] as const) {
      expect(decideSnapshotAccess({
        snapshot: null,
        moduleId: "growth.leads",
        action,
        now: new Date("2026-07-17T12:00:00.000Z"),
      })).toMatchObject({ allowed: false, reason: "snapshot_missing" });
    }
  });

  it("uses the state access policy while the snapshot is fresh", () => {
    expect(decideSnapshotAccess({ snapshot: snapshot(), moduleId: "growth.leads", action: "write", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: true, reason: "current" });
    expect(decideSnapshotAccess({ snapshot: snapshot({ state: "suspended" }), moduleId: "growth.leads", action: "outbound", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: false, reason: "state_policy" });
  });

  it("turns an expired operational snapshot read-only and pauses outbound work", () => {
    const stale = snapshot({ expiresAt: "2026-07-17T10:00:00.000Z" });
    expect(decideSnapshotAccess({ snapshot: stale, moduleId: "growth.leads", action: "read", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: true, reason: "stale_read_only" });
    expect(decideSnapshotAccess({ snapshot: stale, moduleId: "growth.leads", action: "write", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: false, reason: "snapshot_stale" });
    expect(decideSnapshotAccess({ snapshot: stale, moduleId: "growth.leads", action: "outbound", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: false, reason: "snapshot_stale" });
    expect(decideSnapshotAccess({ snapshot: stale, moduleId: "growth.leads", action: "export", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: true, reason: "stale_read_only" });
  });

  it("keeps setup actions available while stale when state policy permits them", () => {
    const staleSetup = snapshot({ state: "setup_required", expiresAt: "2026-07-17T10:00:00.000Z" });
    expect(decideSnapshotAccess({ snapshot: staleSetup, moduleId: "growth.leads", action: "setup", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: true, reason: "stale_repair" });
  });

  it("applies module and wildcard incident overrides before state access", () => {
    const readOnly = snapshot({ incidents: [{ moduleId: "growth.leads", mode: "read_only", reasonCode: "INCIDENT_42" }] });
    const blocked = snapshot({ incidents: [{ moduleId: "*", mode: "blocked", reasonCode: "SECURITY_EVENT" }] });
    expect(decideSnapshotAccess({ snapshot: readOnly, moduleId: "growth.leads", action: "write", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: false, reason: "incident_read_only" });
    expect(decideSnapshotAccess({ snapshot: readOnly, moduleId: "growth.leads", action: "read", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: true });
    expect(decideSnapshotAccess({ snapshot: blocked, moduleId: "growth.reviews", action: "read", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: false, reason: "incident_blocked" });
  });

  it("rejects rollback snapshots and restores writes with a newer fresh sequence", () => {
    const cache = createEntitlementSnapshotCache({ siteId: SITE_ID, installationId: INSTALLATION_ID });
    expect(cache.accept(snapshot({ sequence: 3, expiresAt: "2026-07-17T10:00:00.000Z" }))).toBe(true);
    expect(cache.accept(snapshot({ sequence: 2 }))).toBe(false);
    expect(cache.decide({ moduleId: "growth.leads", action: "write", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: false, reason: "snapshot_stale" });
    expect(cache.accept(snapshot({ sequence: 4 }))).toBe(true);
    expect(cache.decide({ moduleId: "growth.leads", action: "write", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: true, reason: "current" });
  });

  it("denies an unknown module even when the cached snapshot is current", () => {
    expect(decideSnapshotAccess({ snapshot: snapshot(), moduleId: "growth.unknown" as never, action: "read", now: new Date("2026-07-17T12:00:00.000Z") }))
      .toMatchObject({ allowed: false, reason: "module_missing" });
  });
});
