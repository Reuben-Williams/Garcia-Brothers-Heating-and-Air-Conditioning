import { describe, expect, it } from "vitest";

import * as trust from "../src/trust/index.js";

const marker = {
  version: 1 as const,
  siteDataPlaneSiteId: "10000000-0000-4000-8000-000000000001",
  expectedSiteKey: "reviewed-site",
  installationManifestSha256: "a".repeat(64),
  configLoaderContract: "installation-client-config-v1" as const,
  durableStoreContract: "supabase-command-receipts-v1" as const,
  leaseContract: "site-installation-run-lease-v1" as const,
  leaseSeconds: 120,
  invocationTimeoutSeconds: 90,
  scheduledInvocationContract: "direct-in-process-v1" as const,
  handlerRegistrySha256: "b".repeat(64),
  workerVersion: "1.2.3",
  reachabilityEvidenceRevision: "deploy-abc123",
};

describe("site runtime marker trust contract", () => {
  it("parses the exact reviewed runtime marker from the shared trust package", () => {
    const parse = (trust as Record<string, unknown>).parseSiteRuntimeMarker as
      | ((value: unknown) => unknown)
      | undefined;

    expect(parse).toBeTypeOf("function");
    expect(parse?.(marker)).toEqual(marker);
  });

  it.each([
    ["unknown field", { ...marker, controlPlaneUrl: "https://secret.example" }],
    ["invalid local UUID", { ...marker, siteDataPlaneSiteId: "central-installation" }],
    ["invalid site key", { ...marker, expectedSiteKey: "Reviewed Site" }],
    ["short lease", { ...marker, leaseSeconds: 59 }],
    ["deadline equal to lease", { ...marker, invocationTimeoutSeconds: 120 }],
    ["noncanonical digest", { ...marker, handlerRegistrySha256: "B".repeat(64) }],
    ["worker without reachability", { ...marker, reachabilityEvidenceRevision: null }],
    ["oversized marker", {
      ...marker,
      reachabilityEvidenceRevision: `deploy-${"x".repeat(33_000)}`,
    }],
  ])("rejects %s", (_label, value) => {
    const parse = (trust as Record<string, unknown>).parseSiteRuntimeMarker as
      | ((input: unknown) => unknown)
      | undefined;

    expect(parse).toBeTypeOf("function");
    expect(() => parse?.(value)).toThrow("invalid_site_runtime_marker");
  });
});
