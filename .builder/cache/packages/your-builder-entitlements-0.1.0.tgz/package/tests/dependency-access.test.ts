import { describe, expect, it } from "vitest";

import {
  ENTITLEMENT_STATES,
  canExecuteRepairDirective,
  resolveDependentGrowthAccess,
  type EntitlementState,
  type GrowthActionSets,
  type ModuleDependencyAccessInput,
} from "../src/index.js";

const NOW = "2026-07-18T12:00:00.000Z";
const UNEXPIRED_GRACE = "2026-07-18T12:00:01.000Z";

const POLICY_VALUES: Record<
  EntitlementState,
  readonly [
    "none" | "setup_records" | "operational",
    "none" | "provisioning_commands" | "setup_actions" | "operational" | "repair_notes" | "offboarding_actions",
    "none" | "test_destinations" | "operational",
    "none" | "full" | "completed_only",
  ]
> = {
  available: ["none", "none", "none", "none"],
  requested: ["none", "none", "none", "none"],
  request_withdrawn: ["none", "none", "none", "none"],
  trialing: ["operational", "operational", "operational", "full"],
  trial_expired: ["none", "none", "none", "none"],
  provisioning: ["none", "provisioning_commands", "none", "none"],
  provisioning_error: ["none", "provisioning_commands", "none", "none"],
  setup_required: ["setup_records", "setup_actions", "test_destinations", "full"],
  active: ["operational", "operational", "operational", "full"],
  payment_attention: ["operational", "operational", "operational", "full"],
  grace_period: ["operational", "operational", "operational", "full"],
  suspended: ["operational", "repair_notes", "none", "full"],
  offboarding: ["operational", "offboarding_actions", "none", "full"],
  termination_failed: ["operational", "offboarding_actions", "none", "full"],
  terminated: ["none", "none", "none", "completed_only"],
};

const READ = {
  none: [],
  setup_records: ["setup.read"],
  operational: ["operational.read"],
} as const;
const WRITE = {
  none: [],
  provisioning_commands: ["provisioning.command"],
  setup_actions: ["setup.action"],
  operational: ["operational.write"],
  repair_notes: ["repair.note"],
  offboarding_actions: ["offboarding.action"],
} as const;
const OUTBOUND = {
  none: [],
  test_destinations: ["outbound.test"],
  operational: ["outbound.operational"],
} as const;
const EXPORT = {
  none: [],
  full: ["export.completed", "export.current"],
  completed_only: ["export.completed"],
} as const;

function expectedActions(state: EntitlementState): GrowthActionSets {
  const [read, write, outbound, exportPolicy] = POLICY_VALUES[state];
  return {
    read: READ[read],
    write: WRITE[write],
    outbound: OUTBOUND[outbound],
    export: EXPORT[exportPolicy],
  };
}

function intersection(left: readonly string[], right: readonly string[]): readonly string[] {
  return left.filter((action) => right.includes(action)).sort();
}

function input(
  state: EntitlementState,
  overrides: Partial<ModuleDependencyAccessInput> = {},
): ModuleDependencyAccessInput {
  return {
    state,
    now: NOW,
    graceDeadline: state === "grace_period" ? UNEXPIRED_GRACE : null,
    snapshot: { kind: "fresh" },
    ...overrides,
  };
}

describe("Customers plus Leads entitlement dependency access", () => {
  it("resolves all 225 state pairs with exact explicit action intersections", () => {
    const visited = new Set<string>();

    for (const customersState of ENTITLEMENT_STATES) {
      for (const leadsState of ENTITLEMENT_STATES) {
        const result = resolveDependentGrowthAccess({
          customers: input(customersState),
          leads: input(leadsState),
        });
        visited.add(`${customersState}:${leadsState}`);

        const customers = expectedActions(customersState);
        const leads = expectedActions(leadsState);
        expect(result.customers.actions).toEqual(customers);
        expect(result.leads.actions).toEqual(leads);
        expect(result.sharedActions).toEqual({
          read: intersection(customers.read, leads.read),
          write: intersection(customers.write, leads.write),
          outbound: intersection(customers.outbound, leads.outbound),
          export: intersection(customers.export, leads.export),
        });
        expect(result.enhancedIngestion).toBe(
          customers.write.includes("operational.write") &&
          leads.write.includes("operational.write"),
        );
      }
    }

    expect(visited.size).toBe(225);
  });

  it("expires grace from wall-clock time even inside a valid cache outage window", () => {
    const result = resolveDependentGrowthAccess({
      customers: input("grace_period", {
        graceDeadline: "2026-07-18T11:59:59.000Z",
        snapshot: { kind: "cached", outageDeadline: "2026-07-18T13:00:00.000Z" },
      }),
      leads: input("active", {
        snapshot: { kind: "cached", outageDeadline: "2026-07-18T13:00:00.000Z" },
      }),
    });

    expect(result.sharedActions.read).toEqual(["operational.read"]);
    expect(result.sharedActions.write).toEqual([]);
    expect(result.sharedActions.outbound).toEqual([]);
    expect(result.sharedActions.export).toEqual(["export.completed", "export.current"]);
    expect(result.enhancedIngestion).toBe(false);
  });

  it.each([
    ["missing", false],
    ["invalid_signature", false],
    ["unknown", false],
    ["inconsistent", false],
  ] as const)("fails %s snapshots closed without prior valid evidence", (kind, priorValid) => {
    const result = resolveDependentGrowthAccess({
      customers: input("active", { snapshot: { kind, priorValid } }),
      leads: input("active"),
    });

    expect(result.customers.snapshotMode).toBe("denied");
    expect(result.customers.actions).toEqual({ read: [], write: [], outbound: [], export: [] });
    expect(result.customers.healthAlert).toBe(true);
    expect(result.sharedActions).toEqual({ read: [], write: [], outbound: [], export: [] });
  });

  it.each([
    { kind: "stale", priorValid: true } as const,
    { kind: "invalid_signature", priorValid: true } as const,
    { kind: "cached", outageDeadline: "2026-07-18T11:59:59.000Z" } as const,
  ])("limits a prior-valid $kind snapshot to existing read", (snapshot) => {
    const result = resolveDependentGrowthAccess({
      customers: input("active", { snapshot }),
      leads: input("active", { snapshot }),
    });

    expect(result.customers.snapshotMode).toBe("stale_read_only");
    expect(result.sharedActions).toEqual({
      read: ["operational.read"],
      write: [],
      outbound: [],
      export: [],
    });
    expect(result.healthAlert).toBe(true);
  });

  it("applies blocked and read-only incident overrides before intersection", () => {
    const blocked = resolveDependentGrowthAccess({
      customers: input("active", { incidentMode: "blocked" }),
      leads: input("active"),
    });
    const readOnly = resolveDependentGrowthAccess({
      customers: input("active", { incidentMode: "read_only" }),
      leads: input("active"),
    });

    expect(blocked.sharedActions).toEqual({ read: [], write: [], outbound: [], export: [] });
    expect(readOnly.sharedActions).toEqual({
      read: ["operational.read"],
      write: [],
      outbound: [],
      export: ["export.completed", "export.current"],
    });
  });

  it("keeps repair directives module-local instead of intersecting them", () => {
    const result = resolveDependentGrowthAccess({
      customers: input("setup_required"),
      leads: input("terminated"),
    });

    expect(result.customers.repair).toBe("setup");
    expect(result.leads.repair).toBe("reactivation");
    expect(result).not.toHaveProperty("sharedRepair");
  });

  it("authorizes each module-local repair directive against the required actor", () => {
    expect(canExecuteRepairDirective("request_only", {
      siteOwner: true,
      billingManage: true,
      provisioningOperator: false,
      offboardingOperator: false,
    })).toBe(true);
    expect(canExecuteRepairDirective("billing_reconnect", {
      siteOwner: true,
      billingManage: false,
      provisioningOperator: false,
      offboardingOperator: false,
    })).toBe(false);
    expect(canExecuteRepairDirective("provisioning", {
      siteOwner: false,
      billingManage: false,
      provisioningOperator: true,
      offboardingOperator: false,
    })).toBe(true);
    expect(canExecuteRepairDirective("setup", {
      siteOwner: true,
      billingManage: false,
      provisioningOperator: false,
      offboardingOperator: false,
    })).toBe(true);
    expect(canExecuteRepairDirective("offboarding", {
      siteOwner: false,
      billingManage: false,
      provisioningOperator: false,
      offboardingOperator: true,
    })).toBe(true);
    expect(canExecuteRepairDirective("reactivation", {
      siteOwner: true,
      billingManage: true,
      provisioningOperator: false,
      offboardingOperator: false,
    })).toBe(true);
    expect(canExecuteRepairDirective("normal", {
      siteOwner: true,
      billingManage: true,
      provisioningOperator: true,
      offboardingOperator: true,
    })).toBe(false);
  });

  it.each([
    ["active", "suspended", ["operational.read"], [], ["export.completed", "export.current"]],
    ["active", "setup_required", [], [], ["export.completed", "export.current"]],
    ["active", "terminated", [], [], ["export.completed"]],
    ["offboarding", "active", ["operational.read"], [], ["export.completed", "export.current"]],
  ] as const)(
    "resolves exact mixed state %s/%s",
    (customers, leads, read, write, exportActions) => {
      const result = resolveDependentGrowthAccess({
        customers: input(customers),
        leads: input(leads),
      });

      expect(result.sharedActions.read).toEqual(read);
      expect(result.sharedActions.write).toEqual(write);
      expect(result.sharedActions.export).toEqual(exportActions);
    },
  );

  it("is total and fail-closed for an invalid evaluation time", () => {
    const result = resolveDependentGrowthAccess({
      customers: input("active", { now: "not-a-time" }),
      leads: input("active"),
    });

    expect(result.customers.snapshotMode).toBe("denied");
    expect(result.sharedActions).toEqual({ read: [], write: [], outbound: [], export: [] });
  });
});
