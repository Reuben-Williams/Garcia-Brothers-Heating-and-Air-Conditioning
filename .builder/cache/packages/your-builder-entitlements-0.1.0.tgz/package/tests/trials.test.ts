import { describe, expect, it } from "vitest";

import * as entitlementsModule from "@your-builder/entitlements";

const api = entitlementsModule as Record<string, unknown>;

interface TrialEvidence {
  readonly trialDurationDays: number;
  readonly trialStartedAt: string | null;
  readonly trialExpiresAt: string | null;
  readonly trialScheduleVersion: number;
}

const createPending = () =>
  api.createPendingTrialEvidence as (input: {
    trialDurationDays: number;
    currentScheduleVersion: number;
  }) => TrialEvidence;
const startTrial = () =>
  api.startTrial as (input: {
    trialDurationDays: number;
    startedAt: string;
    currentScheduleVersion: number;
  }) => TrialEvidence;
const extendTrial = () =>
  api.extendTrial as (input: {
    evidence: TrialEvidence;
    newExpiresAt: string;
  }) => TrialEvidence;
const evaluateExpiry = () =>
  api.evaluateTrialExpiry as (input: {
    evidence: TrialEvidence;
    expectedScheduleVersion: number;
    now: string;
  }) => Readonly<Record<string, unknown>>;

describe("durable trial evidence", () => {
  it("keeps timestamps null before the entitlement enters trialing", () => {
    expect(typeof api.createPendingTrialEvidence).toBe("function");
    const evidence = createPending()({
      trialDurationDays: 14,
      currentScheduleVersion: 3,
    });

    expect(evidence).toEqual({
      trialDurationDays: 14,
      trialStartedAt: null,
      trialExpiresAt: null,
      trialScheduleVersion: 3,
    });
    expect(Object.isFrozen(evidence)).toBe(true);
  });

  it("starts the clock atomically from control-plane time and increments the schedule version", () => {
    expect(typeof api.startTrial).toBe("function");
    const evidence = startTrial()({
      trialDurationDays: 14,
      startedAt: "2026-07-17T12:00:00.000Z",
      currentScheduleVersion: 3,
    });

    expect(evidence).toEqual({
      trialDurationDays: 14,
      trialStartedAt: "2026-07-17T12:00:00.000Z",
      trialExpiresAt: "2026-07-31T12:00:00.000Z",
      trialScheduleVersion: 4,
    });
    expect(Object.isFrozen(evidence)).toBe(true);
  });

  it("extends only the expiry and schedule version while preserving original evidence", () => {
    expect(typeof api.extendTrial).toBe("function");
    const original = startTrial()({
      trialDurationDays: 14,
      startedAt: "2026-07-17T12:00:00.000Z",
      currentScheduleVersion: 3,
    });

    const extended = extendTrial()({
      evidence: original,
      newExpiresAt: "2026-08-07T12:00:00.000Z",
    });

    expect(extended).toEqual({
      trialDurationDays: 14,
      trialStartedAt: "2026-07-17T12:00:00.000Z",
      trialExpiresAt: "2026-08-07T12:00:00.000Z",
      trialScheduleVersion: 5,
    });
    expect(original.trialExpiresAt).toBe("2026-07-31T12:00:00.000Z");
    expect(extended).not.toBe(original);
    expect(Object.isFrozen(extended)).toBe(true);
  });

  it("makes a stale expiry command an explicit no-op", () => {
    expect(typeof api.evaluateTrialExpiry).toBe("function");
    const evidence = startTrial()({
      trialDurationDays: 14,
      startedAt: "2026-07-17T12:00:00.000Z",
      currentScheduleVersion: 3,
    });
    const extended = extendTrial()({
      evidence,
      newExpiresAt: "2026-08-07T12:00:00.000Z",
    });

    expect(
      evaluateExpiry()({
        evidence: extended,
        expectedScheduleVersion: 4,
        now: "2026-08-08T12:00:00.000Z",
      }),
    ).toEqual({
      status: "stale",
      expectedScheduleVersion: 4,
      actualScheduleVersion: 5,
    });
  });

  it("distinguishes a current command that is not due from one that must expire", () => {
    const evidence = startTrial()({
      trialDurationDays: 14,
      startedAt: "2026-07-17T12:00:00.000Z",
      currentScheduleVersion: 0,
    });

    expect(
      evaluateExpiry()({
        evidence,
        expectedScheduleVersion: 1,
        now: "2026-07-31T11:59:59.999Z",
      }),
    ).toEqual({ status: "not_due", trialExpiresAt: "2026-07-31T12:00:00.000Z" });
    expect(
      evaluateExpiry()({
        evidence,
        expectedScheduleVersion: 1,
        now: "2026-07-31T12:00:00.000Z",
      }),
    ).toEqual({
      status: "expired",
      trialExpiresAt: "2026-07-31T12:00:00.000Z",
      trialScheduleVersion: 1,
    });
  });

  it("rejects invalid durations, versions, timestamps, and non-extension dates", () => {
    for (const trialDurationDays of [0, -1, 1.5]) {
      expect(() =>
        startTrial()({
          trialDurationDays,
          startedAt: "2026-07-17T12:00:00.000Z",
          currentScheduleVersion: 0,
        }),
      ).toThrow(expect.objectContaining({ code: "invalid_trial" }));
    }
    expect(() =>
      startTrial()({
        trialDurationDays: 14,
        startedAt: "not-a-time",
        currentScheduleVersion: 0,
      }),
    ).toThrow(expect.objectContaining({ code: "invalid_trial" }));
    expect(() =>
      startTrial()({
        trialDurationDays: 14,
        startedAt: "2026-07-17T12:00:00.000Z",
        currentScheduleVersion: -1,
      }),
    ).toThrow(expect.objectContaining({ code: "invalid_trial" }));

    const evidence = startTrial()({
      trialDurationDays: 14,
      startedAt: "2026-07-17T12:00:00.000Z",
      currentScheduleVersion: 0,
    });
    expect(() =>
      extendTrial()({ evidence, newExpiresAt: "2026-07-31T12:00:00.000Z" }),
    ).toThrow(expect.objectContaining({ code: "invalid_trial" }));
  });
});
