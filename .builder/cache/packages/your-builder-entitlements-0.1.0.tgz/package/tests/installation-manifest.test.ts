import { createHash } from "node:crypto";

import { describe, expect, it } from "vitest";

import * as trust from "../src/trust/index.js";

const manifest = {
  version: 1 as const,
  packages: {
    "@your-builder/next": "0.1.0",
    "@your-builder/core": "0.1.0",
  },
  schemas: { posts: 1, growth: 2 },
  routes: ["/", "/posts/[slug]"],
  workerVersion: "1.2.3",
};

describe("installation manifest trust contract", () => {
  it("parses the reviewed manifest and preserves optional workerVersion", () => {
    const parse = (trust as Record<string, unknown>).parseInstallationManifest as
      | ((value: unknown) => unknown)
      | undefined;

    expect(parse).toBeTypeOf("function");
    expect(parse?.(manifest)).toEqual(manifest);
    expect(parse?.({
      version: 1,
      packages: {},
      schemas: {},
      routes: [],
    })).toEqual({ version: 1, packages: {}, schemas: {}, routes: [] });
  });

  it.each([
    ["unknown field", { ...manifest, secret: "no" }],
    ["duplicate route", { ...manifest, routes: ["/", "/"] }],
    ["query route", { ...manifest, routes: ["/?token=no"] }],
    ["invalid package", { ...manifest, packages: { "Bad Package": "1.0.0" } }],
    ["unsafe schema", { ...manifest, schemas: { posts: Number.MAX_SAFE_INTEGER } }],
    ["empty worker version", { ...manifest, workerVersion: "" }],
  ])("rejects %s", (_label, value) => {
    const parse = (trust as Record<string, unknown>).parseInstallationManifest as
      | ((input: unknown) => unknown)
      | undefined;

    expect(parse).toBeTypeOf("function");
    expect(() => parse?.(value)).toThrow("invalid_installation_manifest");
  });

  it("canonicalizes maps independently of insertion order and returns a lowercase SHA-256", () => {
    const canonicalize = (trust as Record<string, unknown>).canonicalInstallationManifest as
      | ((value: unknown) => string)
      | undefined;
    const digest = (trust as Record<string, unknown>).installationManifestSha256 as
      | ((value: unknown) => string)
      | undefined;
    const reordered = {
      ...manifest,
      packages: {
        "@your-builder/core": "0.1.0",
        "@your-builder/next": "0.1.0",
      },
      schemas: { growth: 2, posts: 1 },
    };

    expect(canonicalize).toBeTypeOf("function");
    expect(digest).toBeTypeOf("function");
    expect(canonicalize?.(reordered)).toBe(canonicalize?.(manifest));
    expect(digest?.(reordered)).toBe(digest?.(manifest));
    expect(digest?.(manifest)).toBe(
      createHash("sha256").update(canonicalize?.(manifest) ?? "", "utf8").digest("hex"),
    );
  });
});
