import { describe, expect, it } from "vitest";

import * as entitlementsModule from "@your-builder/entitlements";

const api = entitlementsModule as Record<string, unknown>;

interface ResolutionInput {
  base: boolean;
  billing: boolean;
  trial: boolean;
  manualOverride: boolean;
  terminated: boolean;
  graceExpired: boolean;
  securitySuspended: boolean;
  incidentSuspended: boolean;
}

const resolveEntitlement = () =>
  api.resolveEntitlement as (input: ResolutionInput) =>
    | { readonly allowed: false; readonly reason: "incident" | "security" | "contract" }
    | { readonly allowed: boolean; readonly source: "manual_override" | "trial" | "billing" | "base" };

const baseline = (overrides: Partial<ResolutionInput> = {}): ResolutionInput => ({
  base: false,
  billing: false,
  trial: false,
  manualOverride: false,
  terminated: false,
  graceExpired: false,
  securitySuspended: false,
  incidentSuspended: false,
  ...overrides,
});

describe("entitlement precedence", () => {
  it.each([
    ["incident override beats security suspension", baseline({ incidentSuspended: true, securitySuspended: true, manualOverride: true }), { allowed: false, reason: "incident" }],
    ["security suspension beats termination and grants", baseline({ securitySuspended: true, terminated: true, trial: true }), { allowed: false, reason: "security" }],
    ["termination beats a trial", baseline({ terminated: true, trial: true }), { allowed: false, reason: "contract" }],
    ["expired grace beats a manual override", baseline({ graceExpired: true, manualOverride: true }), { allowed: false, reason: "contract" }],
    ["manual override beats a trial", baseline({ manualOverride: true, trial: true, billing: true, base: true }), { allowed: true, source: "manual_override" }],
    ["trial beats billing", baseline({ trial: true, billing: true, base: true }), { allowed: true, source: "trial" }],
    ["billing beats base", baseline({ billing: true, base: true }), { allowed: true, source: "billing" }],
    ["base permits base access", baseline({ base: true }), { allowed: true, source: "base" }],
    ["missing grants deny base access", baseline(), { allowed: false, source: "base" }],
  ] as const)("%s", (_label, input, expected) => {
    expect(typeof api.resolveEntitlement).toBe("function");
    const result = resolveEntitlement()(input);
    expect(result).toEqual(expected);
    expect(Object.isFrozen(result)).toBe(true);
  });
});
