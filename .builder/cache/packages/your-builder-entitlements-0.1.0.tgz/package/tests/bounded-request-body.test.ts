// @vitest-environment node

import { describe, expect, it, vi } from "vitest";

import * as trustModule from "@your-builder/entitlements/trust";

const trust = trustModule as Record<string, unknown>;

type BodyRequest = {
  headers: Pick<Headers, "get">;
  body: ReadableStream<Uint8Array> | null;
};

function reader(): (
  request: BodyRequest,
  maxBytes: number,
) => Promise<Uint8Array> {
  expect(typeof trust.readBoundedRequestBody).toBe("function");
  return trust.readBoundedRequestBody as (
    request: BodyRequest,
    maxBytes: number,
  ) => Promise<Uint8Array>;
}

describe("readBoundedRequestBody", () => {
  it("rejects an oversized declared length without opening the body stream", async () => {
    const getReader = vi.fn();
    const request = {
      headers: new Headers({ "content-length": "9" }),
      body: { getReader } as unknown as ReadableStream<Uint8Array>,
    };

    await expect(reader()(request, 8)).rejects.toMatchObject({
      code: "payload_too_large",
    });
    expect(getReader).not.toHaveBeenCalled();
  });

  it("cancels an oversized streaming body at the first chunk over the cap", async () => {
    const cancel = vi.fn();
    const chunks = [
      new Uint8Array([1, 2, 3]),
      new Uint8Array([4, 5, 6]),
    ];
    const body = new ReadableStream<Uint8Array>({
      pull(controller) {
        const chunk = chunks.shift();
        if (chunk) controller.enqueue(chunk);
        else controller.close();
      },
      cancel,
    });

    await expect(
      reader()({ headers: new Headers(), body }, 5),
    ).rejects.toMatchObject({ code: "payload_too_large" });
    expect(cancel).toHaveBeenCalledOnce();
  });

  it("returns the exact bytes across chunk boundaries at the cap", async () => {
    const expected = new Uint8Array([0, 255, 1, 2, 3]);
    const body = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(expected.subarray(0, 2));
        controller.enqueue(expected.subarray(2));
        controller.close();
      },
    });

    await expect(
      reader()(
        { headers: new Headers({ "content-length": "5" }), body },
        5,
      ),
    ).resolves.toEqual(expected);
  });
});
