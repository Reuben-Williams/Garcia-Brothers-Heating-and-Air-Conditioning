import { describe, expect, it } from "vitest";

import * as entitlementsModule from "@your-builder/entitlements";

const api = entitlementsModule as Record<string, unknown>;

type ActivationMode = "trial" | "paid_new" | "paid_upgrade" | "manual_grant";
type IntendedState = "trialing" | "active";
type ExpectedState = "available" | "requested" | "trial_expired" | "provisioning_error" | "active" | "payment_attention" | "grace_period";

interface ActivationCommandInput {
  readonly commandId: string;
  readonly idempotencyKey: string;
  readonly entitlementId: string;
  readonly expectedState: ExpectedState;
  readonly expectedVersion: number;
  readonly activationMode: ActivationMode;
  readonly intendedSuccessfulState: IntendedState;
  readonly trialDurationDays: number | null;
  readonly actorId: string;
  readonly source: string;
  readonly reason: string;
  readonly requestedAt: string;
}

const createCommand = () =>
  api.createActivationCommand as (
    input: ActivationCommandInput,
  ) => Readonly<ActivationCommandInput & { trialStartedAt: null; trialExpiresAt: null }>;

function command(
  overrides: Partial<ActivationCommandInput> = {},
): ActivationCommandInput {
  return {
    commandId: "activation-command-1",
    idempotencyKey: "activate-entitlement-1-v2",
    entitlementId: "entitlement-1",
    expectedState: "requested",
    expectedVersion: 2,
    activationMode: "trial",
    intendedSuccessfulState: "trialing",
    trialDurationDays: 14,
    actorId: "operator-1",
    source: "operator",
    reason: "Approved trial",
    requestedAt: "2026-07-17T12:00:00.000Z",
    ...overrides,
  };
}

describe("activation commands", () => {
  it("creates a frozen trial command with expected-state, CAS, and idempotency evidence", () => {
    expect(typeof api.createActivationCommand).toBe("function");
    const result = createCommand()(command());

    expect(result).toEqual({
      ...command(),
      trialStartedAt: null,
      trialExpiresAt: null,
    });
    expect(Object.isFrozen(result)).toBe(true);
  });

  it.each([
    ["paid_new", "requested"],
    ["manual_grant", "available"],
    ["paid_upgrade", "active"],
    ["paid_upgrade", "payment_attention"],
    ["paid_upgrade", "grace_period"],
  ] as const)("accepts valid %s activation from %s", (activationMode, expectedState) => {
    const result = createCommand()(
      command({
        activationMode,
        expectedState,
        intendedSuccessfulState: "active",
        trialDurationDays: null,
      }),
    );

    expect(result.activationMode).toBe(activationMode);
    expect(result.intendedSuccessfulState).toBe("active");
  });

  it.each([
    ["trial target", { intendedSuccessfulState: "active" }],
    ["missing trial duration", { trialDurationDays: null }],
    ["paid target", { activationMode: "paid_new", intendedSuccessfulState: "trialing", trialDurationDays: null }],
    ["paid trial duration", { activationMode: "paid_new", intendedSuccessfulState: "active", trialDurationDays: 14 }],
    ["upgrade source state", { activationMode: "paid_upgrade", intendedSuccessfulState: "active", trialDurationDays: null, expectedState: "requested" }],
    ["new activation source state", { activationMode: "manual_grant", intendedSuccessfulState: "active", trialDurationDays: null, expectedState: "active" }],
  ] as const)("rejects an invalid %s combination", (_label, override) => {
    expect(() => createCommand()(command(override))).toThrow(
      expect.objectContaining({ code: "invalid_activation_command" }),
    );
  });

  it("rejects missing identity/audit fields, invalid versions, and invalid timestamps", () => {
    for (const override of [
      { commandId: "" },
      { idempotencyKey: "" },
      { entitlementId: "" },
      { actorId: "" },
      { source: "" },
      { reason: "" },
      { expectedVersion: -1 },
      { expectedVersion: 1.5 },
      { requestedAt: "not-a-time" },
    ] satisfies Array<Partial<ActivationCommandInput>>) {
      expect(() => createCommand()(command(override))).toThrow(
        expect.objectContaining({ code: "invalid_activation_command" }),
      );
    }
  });
});
