// @vitest-environment node

import { describe, expect, it } from "vitest";

import * as trustModule from "@your-builder/entitlements/trust";

const PUBLIC_X = "11qYAYKxCrfVS_7TyWQHOg7hcvPapiMlrwIaaPcHURo";

const trust = trustModule as Record<string, unknown>;

describe("installation request HTTP headers", () => {
  it("exports the frozen installation header names", () => {
    expect(trust.INSTALLATION_REQUEST_HEADER_NAMES).toEqual({
      installationId: "x-builder-installation-id",
      keyId: "x-builder-key-id",
      timestamp: "x-builder-timestamp",
      nonce: "x-builder-nonce",
      signature: "x-builder-signature",
    });
    expect(Object.isFrozen(trust.INSTALLATION_REQUEST_HEADER_NAMES)).toBe(true);
  });

  it("exports the frozen registration proof header name", () => {
    expect(trust.REGISTRATION_REQUEST_HEADER_NAMES).toEqual({
      proof: "x-builder-registration-proof",
    });
    expect(Object.isFrozen(trust.REGISTRATION_REQUEST_HEADER_NAMES)).toBe(true);
  });

  it("extracts all signed-request headers with the shared names", () => {
    expect(typeof trust.readInstallationRequestHeaders).toBe("function");
    const readHeaders = trust.readInstallationRequestHeaders as (
      headers: Headers,
    ) => Record<string, string> | null;
    const headers = new Headers({
      "x-builder-installation-id": "11111111-1111-4111-8111-111111111111",
      "x-builder-key-id": "key-2026-07",
      "x-builder-timestamp": "2026-07-16T12:00:00.000Z",
      "x-builder-nonce": "AQIDBAUGBwgJCgsMDQ4PEA",
      "x-builder-signature": "signature",
    });

    expect(readHeaders(headers)).toEqual({
      installationId: "11111111-1111-4111-8111-111111111111",
      keyId: "key-2026-07",
      timestamp: "2026-07-16T12:00:00.000Z",
      nonce: "AQIDBAUGBwgJCgsMDQ4PEA",
      signature: "signature",
    });
  });

  it("returns null when any signed-request header is missing", () => {
    expect(typeof trust.readInstallationRequestHeaders).toBe("function");
    const readHeaders = trust.readInstallationRequestHeaders as (
      headers: Headers,
    ) => Record<string, string> | null;

    expect(
      readHeaders(
        new Headers({
          "x-builder-installation-id": "11111111-1111-4111-8111-111111111111",
          "x-builder-key-id": "key-2026-07",
          "x-builder-timestamp": "2026-07-16T12:00:00.000Z",
          "x-builder-nonce": "AQIDBAUGBwgJCgsMDQ4PEA",
        }),
      ),
    ).toBeNull();
  });
});

describe("normalizeExportedEd25519PublicJwk", () => {
  it("adds the EdDSA algorithm to jose's standard exported public JWK", () => {
    expect(typeof trust.normalizeExportedEd25519PublicJwk).toBe("function");
    const normalize = trust.normalizeExportedEd25519PublicJwk as (
      value: unknown,
    ) => Record<string, string>;

    expect(
      normalize({ kty: "OKP", crv: "Ed25519", x: PUBLIC_X }),
    ).toEqual({
      kty: "OKP",
      crv: "Ed25519",
      alg: "EdDSA",
      x: PUBLIC_X,
    });
  });

  it.each([
    ["private material", { kty: "OKP", crv: "Ed25519", x: PUBLIC_X, d: "secret" }],
    ["unknown fields", { kty: "OKP", crv: "Ed25519", x: PUBLIC_X, use: "sig" }],
    ["wrong curve", { kty: "OKP", crv: "X25519", x: PUBLIC_X }],
    ["short coordinate", { kty: "OKP", crv: "Ed25519", x: "AA" }],
  ])("rejects %s", (_label, value) => {
    expect(typeof trust.normalizeExportedEd25519PublicJwk).toBe("function");
    const normalize = trust.normalizeExportedEd25519PublicJwk as (
      value: unknown,
    ) => unknown;

    expect(() => normalize(value)).toThrow(TypeError);
  });
});
