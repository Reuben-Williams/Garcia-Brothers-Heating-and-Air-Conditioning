// @vitest-environment node

import { generateKeyPairSync } from "node:crypto";

import { describe, expect, it } from "vitest";

import * as trustModule from "@your-builder/entitlements/trust";

const PRIVATE_JWK: JsonWebKey = {
  kty: "OKP",
  crv: "Ed25519",
  alg: "EdDSA",
  x: "11qYAYKxCrfVS_7TyWQHOg7hcvPapiMlrwIaaPcHURo",
  d: "nWGxne_9WmC6hEr0kuwsxERJxWl7MmkZcDusAxyuf2A",
};
const PUBLIC_JWK: JsonWebKey = {
  kty: "OKP",
  crv: "Ed25519",
  alg: "EdDSA",
  x: "11qYAYKxCrfVS_7TyWQHOg7hcvPapiMlrwIaaPcHURo",
};
const BODY = new TextEncoder().encode('{"hello":"world"}\n');
const CANONICAL = [
  "builder-registration-v1",
  "POST",
  "/api/platform/v1/installations/register",
  "akfDG3t8O5odvJYGafRnTOCIyPydmk9-n8w_aoH3uGw",
].join("\n");
const SIGNATURE =
  "jLgtiYKk7uaLwIYIiU86LPa5-eJWEWaadz5AXZZXF8DyD9rJQk5jF0hWlUbb4kENM77_HvxTtxzZg1HIoOKGBg";

const trust = trustModule as Record<string, unknown>;

describe("registration proof of possession", () => {
  it("matches the fixed canonical and Ed25519 signature vector", async () => {
    expect(typeof trust.canonicalRegistrationProof).toBe("function");
    expect(typeof trust.signRegistrationProof).toBe("function");
    expect(typeof trust.verifyRegistrationProof).toBe("function");

    const canonical = trust.canonicalRegistrationProof as (
      bodyBytes: Uint8Array,
    ) => string;
    const sign = trust.signRegistrationProof as (input: {
      bodyBytes: Uint8Array;
      privateJwk: JsonWebKey;
    }) => Promise<string>;
    const verify = trust.verifyRegistrationProof as (input: {
      bodyBytes: Uint8Array;
      publicJwk: JsonWebKey;
      proof: string;
    }) => Promise<boolean>;

    expect(canonical(BODY)).toBe(CANONICAL);
    await expect(sign({ bodyBytes: BODY, privateJwk: PRIVATE_JWK })).resolves.toBe(
      SIGNATURE,
    );
    await expect(
      verify({ bodyBytes: BODY, publicJwk: PUBLIC_JWK, proof: SIGNATURE }),
    ).resolves.toBe(true);
  });

  it("signs a standard jose private JWK export without an alg field", async () => {
    const sign = trust.signRegistrationProof as (input: {
      bodyBytes: Uint8Array;
      privateJwk: JsonWebKey;
    }) => Promise<string>;
    const { alg: _alg, ...standardJosePrivateJwk } = PRIVATE_JWK;

    await expect(
      sign({ bodyBytes: BODY, privateJwk: standardJosePrivateJwk }),
    ).resolves.toBe(SIGNATURE);
  });

  it("rejects a proof when the exact raw body is changed", async () => {
    const verify = trust.verifyRegistrationProof as (input: {
      bodyBytes: Uint8Array;
      publicJwk: JsonWebKey;
      proof: string;
    }) => Promise<boolean>;

    await expect(
      verify({
        bodyBytes: new TextEncoder().encode('{"hello": "world"}\n'),
        publicJwk: PUBLIC_JWK,
        proof: SIGNATURE,
      }),
    ).resolves.toBe(false);
  });

  it("rejects a proof made by a different key", async () => {
    const sign = trust.signRegistrationProof as (input: {
      bodyBytes: Uint8Array;
      privateJwk: JsonWebKey;
    }) => Promise<string>;
    const verify = trust.verifyRegistrationProof as (input: {
      bodyBytes: Uint8Array;
      publicJwk: JsonWebKey;
      proof: string;
    }) => Promise<boolean>;
    const otherKeyPair = generateKeyPairSync("ed25519");
    const otherPrivateJwk: JsonWebKey = {
      ...otherKeyPair.privateKey.export({ format: "jwk" }),
      alg: "EdDSA",
    };

    const otherProof = await sign({ bodyBytes: BODY, privateJwk: otherPrivateJwk });

    await expect(
      verify({ bodyBytes: BODY, publicJwk: PUBLIC_JWK, proof: otherProof }),
    ).resolves.toBe(false);
  });

  it.each(["", "not-base64url", `${SIGNATURE}A`])(
    "returns false for malformed proof %j",
    async (proof) => {
      const verify = trust.verifyRegistrationProof as (input: {
        bodyBytes: Uint8Array;
        publicJwk: JsonWebKey;
        proof: string;
      }) => Promise<boolean>;

      await expect(
        verify({ bodyBytes: BODY, publicJwk: PUBLIC_JWK, proof }),
      ).resolves.toBe(false);
    },
  );
});
