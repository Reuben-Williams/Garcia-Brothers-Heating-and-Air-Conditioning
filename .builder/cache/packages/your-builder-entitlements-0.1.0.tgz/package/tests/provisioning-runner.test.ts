import { describe, expect, it } from "vitest";

import * as entitlementsModule from "@your-builder/entitlements";

const api = entitlementsModule as Record<string, unknown>;

interface Run {
  readonly id: string;
  readonly status:
    | "pending"
    | "running"
    | "compensating"
    | "succeeded"
    | "failed"
    | "compensation_failed";
  readonly kind: "new_module" | "upgrade";
  readonly currentModuleVersion: string | null;
  readonly targetModuleVersion: string;
}

interface Step {
  readonly id: string;
  readonly order: number;
  readonly status:
    | "pending"
    | "running"
    | "succeeded"
    | "failed"
    | "compensated"
    | "compensation_failed"
    | "skipped";
  readonly commandId: string;
  readonly idempotencyKey: string;
  readonly attempts: number;
  readonly retryAt: string | null;
  readonly compensation: "none" | "automatic" | "operator_runbook";
  readonly runbookId: string | null;
  readonly compensationCommandId?: string;
  readonly compensationIdempotencyKey?: string;
}

type Action =
  | { readonly type: "execute"; readonly stepId: string; readonly commandId: string; readonly idempotencyKey: string }
  | { readonly type: "await_acknowledgement"; readonly stepId: string; readonly commandId: string; readonly idempotencyKey: string }
  | { readonly type: "wait"; readonly stepId: string; readonly retryAt: string }
  | { readonly type: "begin_compensation"; readonly failedStepId: string }
  | { readonly type: string };

const nextAction = () =>
  api.nextProvisioningAction as (
    run: Run,
    steps: readonly Step[],
    now?: string,
  ) => Action;

const applyResult = () =>
  api.applyProvisioningStepResult as (
    current: Step,
    result:
      | { readonly outcome: "succeeded"; readonly resultCode: string; readonly evidence: Record<string, unknown> }
      | { readonly outcome: "retry"; readonly errorCode: string; readonly retryAt: string }
      | { readonly outcome: "failed"; readonly errorCode: string },
  ) => Step & { readonly resultCode?: string; readonly lastErrorCode?: string };

function run(overrides: Partial<Run> = {}): Run {
  return {
    id: "run-1",
    status: "running",
    kind: "new_module",
    currentModuleVersion: null,
    targetModuleVersion: "1.0.0",
    ...overrides,
  };
}

function step(overrides: Partial<Step> = {}): Step {
  return {
    id: "step-1",
    order: 1,
    status: "pending",
    commandId: "command-1",
    idempotencyKey: "provision:run-1:step-1",
    attempts: 0,
    retryAt: null,
    compensation: "automatic",
    runbookId: null,
    ...overrides,
  };
}

describe("provisioning runner", () => {
  it("executes the first pending step with its durable command identity", () => {
    expect(typeof api.nextProvisioningAction).toBe("function");

    expect(nextAction()(run(), [step()], "2026-07-17T12:00:00.000Z")).toEqual({
      type: "execute",
      stepId: "step-1",
      commandId: "command-1",
      idempotencyKey: "provision:run-1:step-1",
    });
  });

  it("waits for an ambiguous running step without changing its command identity", () => {
    expect(
      nextAction()(
        run(),
        [step({ status: "running", attempts: 1 })],
        "2026-07-17T12:00:00.000Z",
      ),
    ).toEqual({
      type: "await_acknowledgement",
      stepId: "step-1",
      commandId: "command-1",
      idempotencyKey: "provision:run-1:step-1",
    });
  });

  it("records a transient retry without replacing durable command identity", () => {
    expect(typeof api.applyProvisioningStepResult).toBe("function");

    expect(
      applyResult()(
        step({ status: "running", attempts: 1 }),
        {
          outcome: "retry",
          errorCode: "SITE_TEMPORARILY_UNAVAILABLE",
          retryAt: "2026-07-17T12:05:00.000Z",
        },
      ),
    ).toEqual({
      ...step({ status: "failed", attempts: 1 }),
      retryAt: "2026-07-17T12:05:00.000Z",
      lastErrorCode: "SITE_TEMPORARILY_UNAVAILABLE",
    });
  });

  it("waits until a transient retry is due", () => {
    expect(
      nextAction()(
        run(),
        [step({ status: "failed", attempts: 1, retryAt: "2026-07-17T12:05:00.000Z" })],
        "2026-07-17T12:04:59.000Z",
      ),
    ).toEqual({
      type: "wait",
      stepId: "step-1",
      retryAt: "2026-07-17T12:05:00.000Z",
    });
  });

  it("replays a due failed step before advancing to later work", () => {
    expect(
      nextAction()(
        run(),
        [
          step({ status: "failed", attempts: 1, retryAt: "2026-07-17T12:05:00.000Z" }),
          step({
            id: "step-2",
            order: 2,
            commandId: "command-2",
            idempotencyKey: "provision:run-1:step-2",
          }),
        ],
        "2026-07-17T12:05:00.000Z",
      ),
    ).toEqual({
      type: "execute",
      stepId: "step-1",
      commandId: "command-1",
      idempotencyKey: "provision:run-1:step-1",
    });
  });

  it("begins compensation after a permanent step failure", () => {
    expect(
      nextAction()(
        run(),
        [step({ status: "failed", attempts: 1, retryAt: null })],
        "2026-07-17T12:05:00.000Z",
      ),
    ).toEqual({ type: "begin_compensation", failedStepId: "step-1" });
  });

  it("continues compensation in reverse order once the run is compensating", () => {
    expect(
      nextAction()(
        run({ status: "compensating" }),
        [
          step({ status: "succeeded" }),
          step({
            id: "step-2",
            order: 2,
            status: "succeeded",
            commandId: "command-2",
            idempotencyKey: "provision:run-1:step-2",
            compensationCommandId: "compensation-command-2",
            compensationIdempotencyKey: "provision:run-1:step-2:compensate",
          }),
        ],
      ),
    ).toEqual({
      type: "compensate",
      stepId: "step-2",
      commandId: "compensation-command-2",
      idempotencyKey: "provision:run-1:step-2:compensate",
    });
  });

  it("completes a run after every forward step succeeds", () => {
    expect(nextAction()(run(), [step({ status: "succeeded" })])).toEqual({
      type: "complete",
    });
  });
});
