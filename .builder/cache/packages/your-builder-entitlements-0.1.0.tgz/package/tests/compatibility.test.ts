import { describe, expect, it } from "vitest";

import * as compatibilityModule from "../src/provisioning/compatibility.js";

const api = compatibilityModule as Record<string, unknown>;

interface InstallationCompatibilityManifest {
  readonly manifestVersion: number;
  readonly packages: Readonly<Record<string, string>>;
  readonly schemas: Readonly<Record<string, number>>;
  readonly routes: readonly string[];
  readonly workerVersion?: string;
  readonly modules: Readonly<Record<string, string>>;
}

interface CompatibilityRequirement {
  readonly manifestVersion: 1;
  readonly packages: Readonly<Record<string, string>>;
  readonly schemas: Readonly<Record<string, number>>;
  readonly routes: readonly string[];
  readonly minimumWorkerVersion?: string;
  readonly moduleDependencies?: Readonly<Record<string, string>>;
}

type CompatibilityIssueCode =
  | "UNSUPPORTED_MANIFEST_VERSION"
  | "MISSING_PACKAGE"
  | "PACKAGE_VERSION_TOO_OLD"
  | "MISSING_SCHEMA"
  | "SCHEMA_VERSION_TOO_OLD"
  | "MISSING_WORKER"
  | "WORKER_VERSION_TOO_OLD"
  | "MISSING_ROUTE"
  | "MODULE_DEPENDENCY_MISMATCH";

interface CompatibilityIssue {
  readonly code: CompatibilityIssueCode;
  readonly component: string;
  readonly installed: string | number | null;
  readonly required: string | number;
  readonly upgradeInstruction: string;
}

interface CompatibilityResult {
  readonly compatible: boolean;
  readonly issues: readonly CompatibilityIssue[];
}

const checkCompatibility = () =>
  api.checkInstallationCompatibility as (
    installation: InstallationCompatibilityManifest,
    requirement: CompatibilityRequirement,
  ) => CompatibilityResult;

function installation(
  overrides: Partial<InstallationCompatibilityManifest> = {},
): InstallationCompatibilityManifest {
  return {
    manifestVersion: 1,
    packages: { "@your-builder/core": "2.4.0" },
    schemas: { content: 7 },
    routes: ["/admin/editor/leads"],
    workerVersion: "1.8.0",
    modules: { "growth.customers": "3.2.0" },
    ...overrides,
  };
}

function requirement(
  overrides: Partial<CompatibilityRequirement> = {},
): CompatibilityRequirement {
  return {
    manifestVersion: 1,
    packages: { "@your-builder/core": "2.3.0" },
    schemas: { content: 6 },
    routes: ["/admin/editor/leads"],
    minimumWorkerVersion: "1.7.0",
    moduleDependencies: { "growth.customers": "3.1.0" },
    ...overrides,
  };
}

describe("installation compatibility", () => {
  it("returns a frozen compatible result without mutating the installation manifest", () => {
    expect(typeof api.checkInstallationCompatibility).toBe("function");
    const input = installation();
    const before = structuredClone(input);

    const result = checkCompatibility()(input, requirement());

    expect(result).toEqual({ compatible: true, issues: [] });
    expect(input).toEqual(before);
    expect(Object.isFrozen(result)).toBe(true);
    expect(Object.isFrozen(result.issues)).toBe(true);
  });

  it("fails closed on a manifest major mismatch before inspecting other evidence", () => {
    const result = checkCompatibility()(
      installation({
        manifestVersion: 2,
        packages: {},
        schemas: {},
        routes: [],
        modules: {},
      }),
      requirement(),
    );

    expect(result).toEqual({
      compatible: false,
      issues: [{
        code: "UNSUPPORTED_MANIFEST_VERSION",
        component: "manifest",
        installed: 2,
        required: 1,
        upgradeInstruction: "Upgrade the installation compatibility manifest to major version 1.",
      }],
    });
  });

  it("reports missing and too-old packages with installed and required evidence", () => {
    const result = checkCompatibility()(
      installation({ packages: { "@your-builder/core": "2.2.9" } }),
      requirement({
        packages: {
          "@your-builder/core": "2.3.0",
          "@your-builder/next": "1.5.0",
        },
      }),
    );

    expect(result.issues).toEqual([
      {
        code: "PACKAGE_VERSION_TOO_OLD",
        component: "@your-builder/core",
        installed: "2.2.9",
        required: "2.3.0",
        upgradeInstruction: "Upgrade package @your-builder/core to version 2.3.0 or newer.",
      },
      {
        code: "MISSING_PACKAGE",
        component: "@your-builder/next",
        installed: null,
        required: "1.5.0",
        upgradeInstruction: "Install package @your-builder/next at version 1.5.0 or newer.",
      },
    ]);
  });

  it("reports missing and too-old schemas", () => {
    const result = checkCompatibility()(
      installation({ schemas: { content: 5 } }),
      requirement({ schemas: { content: 6, provisioning: 2 } }),
    );

    expect(result.issues).toEqual([
      expect.objectContaining({
        code: "SCHEMA_VERSION_TOO_OLD",
        component: "content",
        installed: 5,
        required: 6,
      }),
      expect.objectContaining({
        code: "MISSING_SCHEMA",
        component: "provisioning",
        installed: null,
        required: 2,
      }),
    ]);
  });

  it("reports a missing or too-old worker", () => {
    const missing = checkCompatibility()(
      installation({ workerVersion: undefined }),
      requirement({ minimumWorkerVersion: "1.7.0" }),
    );
    const old = checkCompatibility()(
      installation({ workerVersion: "1.6.9" }),
      requirement({ minimumWorkerVersion: "1.7.0" }),
    );

    expect(missing.issues).toEqual([
      expect.objectContaining({ code: "MISSING_WORKER", installed: null, required: "1.7.0" }),
    ]);
    expect(old.issues).toEqual([
      expect.objectContaining({ code: "WORKER_VERSION_TOO_OLD", installed: "1.6.9", required: "1.7.0" }),
    ]);
  });

  it("reports missing routes and module dependency mismatches", () => {
    const result = checkCompatibility()(
      installation({
        routes: ["/admin/editor/leads"],
        modules: { "growth.customers": "3.0.9" },
      }),
      requirement({
        routes: ["/admin/editor/leads", "/admin/editor/projects"],
        moduleDependencies: {
          "growth.customers": "3.1.0",
          "growth.messaging": "1.0.0",
        },
      }),
    );

    expect(result.issues).toEqual([
      expect.objectContaining({
        code: "MISSING_ROUTE",
        component: "/admin/editor/projects",
        installed: null,
        required: "/admin/editor/projects",
      }),
      expect.objectContaining({
        code: "MODULE_DEPENDENCY_MISMATCH",
        component: "growth.customers",
        installed: "3.0.9",
        required: "3.1.0",
      }),
      expect.objectContaining({
        code: "MODULE_DEPENDENCY_MISMATCH",
        component: "growth.messaging",
        installed: null,
        required: "1.0.0",
      }),
    ]);
  });

  it("uses SemVer precedence for prereleases and ignores build metadata", () => {
    const prerelease = checkCompatibility()(
      installation({ packages: { core: "1.0.0-beta.11" } }),
      requirement({ packages: { core: "1.0.0-rc.1" } }),
    );
    const buildMetadata = checkCompatibility()(
      installation({ packages: { core: "1.0.0+site.9" } }),
      requirement({ packages: { core: "1.0.0+release.2" } }),
    );

    expect(prerelease.issues).toEqual([
      expect.objectContaining({ code: "PACKAGE_VERSION_TOO_OLD" }),
    ]);
    expect(buildMetadata).toEqual({ compatible: true, issues: [] });
  });
});
