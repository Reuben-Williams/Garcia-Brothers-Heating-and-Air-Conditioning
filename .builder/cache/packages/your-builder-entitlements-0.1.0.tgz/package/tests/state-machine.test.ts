import { describe, expect, it } from "vitest";

import * as entitlementsModule from "@your-builder/entitlements";

const api = entitlementsModule as Record<string, unknown>;

const STATES = [
  "available",
  "requested",
  "request_withdrawn",
  "trialing",
  "trial_expired",
  "provisioning",
  "provisioning_error",
  "setup_required",
  "active",
  "payment_attention",
  "grace_period",
  "suspended",
  "offboarding",
  "termination_failed",
  "terminated",
] as const;

type State = (typeof STATES)[number];

const APPROVED: Readonly<Record<State, readonly State[]>> = {
  available: ["requested", "provisioning"],
  requested: ["request_withdrawn", "provisioning"],
  request_withdrawn: ["requested"],
  provisioning: ["setup_required", "trialing", "active", "provisioning_error"],
  provisioning_error: ["provisioning", "request_withdrawn", "offboarding"],
  setup_required: ["trialing", "active", "suspended", "offboarding"],
  trialing: ["active", "trial_expired", "suspended", "offboarding"],
  trial_expired: ["available", "requested", "provisioning", "offboarding"],
  active: ["payment_attention", "grace_period", "suspended", "offboarding"],
  payment_attention: ["active", "grace_period", "suspended", "offboarding"],
  grace_period: ["active", "suspended", "offboarding"],
  suspended: ["active", "grace_period", "offboarding"],
  offboarding: ["terminated", "termination_failed"],
  termination_failed: ["offboarding", "terminated"],
  terminated: [],
};

interface RecordInput {
  readonly id: string;
  readonly state: State;
  readonly version: number;
  readonly updatedAt: string;
}

interface TransitionInput {
  readonly entitlement: RecordInput;
  readonly toState: State;
  readonly expectedState: State;
  readonly expectedVersion: number;
  readonly commandId: string;
  readonly idempotencyKey: string;
  readonly actorId: string;
  readonly source: string;
  readonly reason: string;
  readonly occurredAt: string;
}

const canTransition = () =>
  api.canTransitionEntitlement as (from: State, to: State) => boolean;
const transition = () =>
  api.transitionEntitlement as (input: TransitionInput) => {
    readonly entitlement: RecordInput;
    readonly event: Record<string, unknown>;
  };

function input(overrides: Partial<TransitionInput> = {}): TransitionInput {
  return {
    entitlement: {
      id: "entitlement-1",
      state: "requested",
      version: 7,
      updatedAt: "2026-07-17T12:00:00.000Z",
    },
    toState: "provisioning",
    expectedState: "requested",
    expectedVersion: 7,
    commandId: "command-1",
    idempotencyKey: "activate-entitlement-1-v7",
    actorId: "operator-1",
    source: "operator",
    reason: "Approved activation request",
    occurredAt: "2026-07-17T12:05:00.000Z",
    ...overrides,
  };
}

describe("entitlement state machine", () => {
  it("exports the exact state list and transition table", () => {
    expect(api.ENTITLEMENT_STATES).toEqual(STATES);
    expect(api.ENTITLEMENT_TRANSITIONS).toEqual(APPROVED);
  });

  it("accepts every approved transition and rejects every other state pair", () => {
    expect(typeof api.canTransitionEntitlement).toBe("function");

    for (const from of STATES) {
      for (const to of STATES) {
        expect(canTransition()(from, to), `${from} -> ${to}`).toBe(
          APPROVED[from].includes(to),
        );
      }
    }
  });

  it("returns a new frozen record and append-only audit event without mutating input", () => {
    expect(typeof api.transitionEntitlement).toBe("function");
    const transitionInput = input();
    const original = structuredClone(transitionInput.entitlement);

    const result = transition()(transitionInput);

    expect(result.entitlement).toEqual({
      id: "entitlement-1",
      state: "provisioning",
      version: 8,
      updatedAt: "2026-07-17T12:05:00.000Z",
    });
    expect(result.event).toEqual({
      entitlementId: "entitlement-1",
      fromState: "requested",
      toState: "provisioning",
      expectedState: "requested",
      expectedVersion: 7,
      resultingVersion: 8,
      commandId: "command-1",
      idempotencyKey: "activate-entitlement-1-v7",
      actorId: "operator-1",
      source: "operator",
      reason: "Approved activation request",
      occurredAt: "2026-07-17T12:05:00.000Z",
    });
    expect(transitionInput.entitlement).toEqual(original);
    expect(result.entitlement).not.toBe(transitionInput.entitlement);
    expect(Object.isFrozen(result)).toBe(true);
    expect(Object.isFrozen(result.entitlement)).toBe(true);
    expect(Object.isFrozen(result.event)).toBe(true);
  });

  it("fails closed on expected-state and expected-version mismatches", () => {
    expect(() =>
      transition()(input({ expectedState: "available" })),
    ).toThrow(expect.objectContaining({ code: "expected_state_mismatch" }));
    expect(() =>
      transition()(input({ expectedVersion: 6 })),
    ).toThrow(expect.objectContaining({ code: "expected_version_mismatch" }));
  });

  it("rejects disallowed transitions and incomplete command audit metadata", () => {
    expect(() =>
      transition()(input({ toState: "active" })),
    ).toThrow(expect.objectContaining({ code: "transition_not_allowed" }));

    for (const override of [
      { commandId: "" },
      { idempotencyKey: "" },
      { actorId: "" },
      { source: "" },
      { reason: "" },
      { occurredAt: "not-a-time" },
    ] satisfies Array<Partial<TransitionInput>>) {
      expect(() => transition()(input(override))).toThrow(
        expect.objectContaining({ code: "invalid_command" }),
      );
    }
  });
});
