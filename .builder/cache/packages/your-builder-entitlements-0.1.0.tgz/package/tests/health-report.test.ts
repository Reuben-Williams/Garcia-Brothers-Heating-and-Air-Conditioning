// @vitest-environment node

import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { describe, expect, it } from "vitest";

import {
  HealthReportValidationError,
  assertSanitizedHealthReport,
  parseSanitizedHealthReport,
  type SanitizedHealthReport,
} from "@your-builder/entitlements/trust";

function health(
  override: Partial<SanitizedHealthReport> = {},
): SanitizedHealthReport {
  return {
    manifestVersion: 1,
    packages: {},
    schemas: {},
    worker: { status: "healthy" },
    queues: {},
    integrations: {},
    entitlementSnapshotAgeSeconds: null,
    backupAgeSeconds: null,
    errorCodes: [],
    ...override,
  };
}

describe("sanitized health report contract", () => {
  it("exports health parsing from the trust subpath without widening the package root", async () => {
    const trust = await readFile(resolve("packages/entitlements/src/trust/index.ts"), "utf8");
    const root = await readFile(resolve("packages/entitlements/src/index.ts"), "utf8");

    expect(trust).toContain('export * from "./health-report.js"');
    expect(root).not.toContain("health-report");
    expect(root).not.toContain("./trust");
  });

  it("parses the exact SQL-compatible shape and returns the original value", () => {
    const report = health({
      packages: { core: "1.0.0", keyboardLayout: "2.0.0", monkeyCount: "3.0.0" },
      schemas: { content: 9_999_999_999 },
      worker: { version: "1.0.0+worker", status: "degraded" },
      queues: {
        publish: {
          depth: 9_999_999_999,
          oldestAgeSeconds: null,
          deadLetters: 0,
        },
      },
      integrations: { github: "connected" },
      entitlementSnapshotAgeSeconds: 30,
      backupAgeSeconds: 60,
      errorCodes: ["QUEUE_DELAYED"],
    });

    expect(parseSanitizedHealthReport(report)).toBe(report);
    expect(() => assertSanitizedHealthReport(report)).not.toThrow();
  });

  it.each([
    ["unknown top-level field", { ...health(), region: "us-east" }],
    ["missing top-level field", (() => {
      const { backupAgeSeconds: _removed, ...report } = health();
      return report;
    })()],
    ["fractional schema version", health({ schemas: { content: 1.5 } })],
    ["eleven-digit schema version", health({ schemas: { content: 10_000_000_000 } })],
    ["invalid package identifier", health({ packages: { "bad key": "1.0.0" } })],
    ["invalid package version", health({ packages: { core: "bad version" } })],
    ["empty worker version", health({ worker: { status: "healthy", version: "" } })],
    ["extra worker field", health({ worker: { status: "healthy", region: "east" } as never })],
    ["missing queue field", health({
      queues: { publish: { depth: 0, oldestAgeSeconds: null } as never },
    })],
    ["extra queue field", health({
      queues: {
        publish: { depth: 0, oldestAgeSeconds: null, deadLetters: 0, latency: 1 } as never,
      },
    })],
    ["invalid integration status", health({ integrations: { github: "unknown" as never } })],
    ["too many error codes", health({
      errorCodes: Array.from({ length: 65 }, (_, index) => `ERROR_${index}`),
    })],
    ["unsafe error code", health({ errorCodes: ["queue delayed"] })],
  ])("rejects %s", (_label, report) => {
    expect(() => parseSanitizedHealthReport(report)).toThrow(HealthReportValidationError);
  });

  it.each([
    ["api_key", health({ packages: { api_key: "1.0.0" } })],
    ["privateKey", health({ packages: { privateKey: "1.0.0" } })],
    ["authorization", health({
      queues: {
        publish: {
          depth: 0,
          oldestAgeSeconds: null,
          deadLetters: 0,
          authorization: true,
        } as never,
      },
    })],
    ["attachment", health({ integrations: { attachment: "connected" } })],
  ])("rejects recursively forbidden key segment %s", (_label, report) => {
    expect(() => assertSanitizedHealthReport(report)).toThrow(HealthReportValidationError);
  });

  it("uses PostgreSQL jsonb text UTF-8 size at the 32 KiB boundary", () => {
    const packages: Record<string, string> = {};
    for (let index = 0; index < 239; index += 1) {
      packages[`package${String(index).padStart(3, "0")}`] = "v".repeat(120);
    }
    const report = health({ packages });

    expect(Buffer.byteLength(JSON.stringify(report), "utf8")).toBeLessThanOrEqual(32_768);
    expect(() => parseSanitizedHealthReport(report)).toThrow(HealthReportValidationError);
  });
});
