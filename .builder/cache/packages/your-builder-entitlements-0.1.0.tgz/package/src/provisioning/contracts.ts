export type ProvisioningRunStatus =
  | "pending"
  | "running"
  | "compensating"
  | "succeeded"
  | "failed"
  | "compensation_failed";

export type ProvisioningStepStatus =
  | "pending"
  | "running"
  | "succeeded"
  | "failed"
  | "compensated"
  | "compensation_failed"
  | "skipped";

export type CompensationMode = "none" | "automatic" | "operator_runbook";

export interface InstallationCompatibilityManifest {
  readonly manifestVersion: number;
  readonly packages: Readonly<Record<string, string>>;
  readonly schemas: Readonly<Record<string, number>>;
  readonly routes: readonly string[];
  readonly workerVersion?: string;
  readonly modules: Readonly<Record<string, string>>;
}

export interface CompatibilityRequirement {
  readonly manifestVersion: 1;
  readonly packages: Readonly<Record<string, string>>;
  readonly schemas: Readonly<Record<string, number>>;
  readonly routes: readonly string[];
  readonly minimumWorkerVersion?: string;
  readonly moduleDependencies?: Readonly<Record<string, string>>;
}

export type CompatibilityIssueCode =
  | "UNSUPPORTED_MANIFEST_VERSION"
  | "MISSING_PACKAGE"
  | "PACKAGE_VERSION_TOO_OLD"
  | "MISSING_SCHEMA"
  | "SCHEMA_VERSION_TOO_OLD"
  | "MISSING_WORKER"
  | "WORKER_VERSION_TOO_OLD"
  | "MISSING_ROUTE"
  | "MODULE_DEPENDENCY_MISMATCH";

export interface CompatibilityIssue {
  readonly code: CompatibilityIssueCode;
  readonly component: string;
  readonly installed: string | number | null;
  readonly required: string | number;
  readonly upgradeInstruction: string;
}

export interface CompatibilityResult {
  readonly compatible: boolean;
  readonly issues: readonly CompatibilityIssue[];
}

export interface ProvisioningCompensationInput<TPayload> {
  readonly payload: TPayload;
  readonly evidence: Readonly<Record<string, unknown>>;
}

export type ProvisioningCompensator<TPayload> = (
  input: ProvisioningCompensationInput<TPayload>,
) => unknown | Promise<unknown>;

export interface ProvisioningStepDefinition<
  TPayload = Record<string, unknown>,
> {
  readonly type: string;
  readonly version: number;
  readonly compensation: CompensationMode;
  readonly validate: (payload: unknown) => TPayload;
  readonly compensate?: ProvisioningCompensator<TPayload>;
  readonly operatorRunbookId?: string;
}
