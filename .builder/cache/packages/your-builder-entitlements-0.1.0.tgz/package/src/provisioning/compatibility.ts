import type {
  CompatibilityIssue,
  CompatibilityRequirement,
  CompatibilityResult,
  InstallationCompatibilityManifest,
} from "./contracts.js";

interface SemanticVersion {
  readonly major: bigint;
  readonly minor: bigint;
  readonly patch: bigint;
  readonly prerelease: readonly string[];
}

const SEMANTIC_VERSION =
  /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;

export class CompatibilityValidationError extends Error {
  readonly code = "INVALID_COMPATIBILITY_REQUIREMENT" as const;

  constructor(message: string) {
    super(message);
    this.name = "CompatibilityValidationError";
  }
}

export function checkInstallationCompatibility(
  installation: InstallationCompatibilityManifest,
  requirement: CompatibilityRequirement,
): CompatibilityResult {
  if (installation.manifestVersion !== requirement.manifestVersion) {
    return result([issue(
      "UNSUPPORTED_MANIFEST_VERSION",
      "manifest",
      installation.manifestVersion,
      requirement.manifestVersion,
      `Upgrade the installation compatibility manifest to major version ${requirement.manifestVersion}.`,
    )]);
  }

  const issues: CompatibilityIssue[] = [];

  for (const [packageName, minimumVersion] of Object.entries(requirement.packages)) {
    assertRequiredSemanticVersion("package", packageName, minimumVersion);
    const installedVersion = installation.packages[packageName];
    if (installedVersion === undefined) {
      issues.push(issue(
        "MISSING_PACKAGE",
        packageName,
        null,
        minimumVersion,
        `Install package ${packageName} at version ${minimumVersion} or newer.`,
      ));
    } else if (!isSemanticVersionAtLeast(installedVersion, minimumVersion)) {
      issues.push(issue(
        "PACKAGE_VERSION_TOO_OLD",
        packageName,
        installedVersion,
        minimumVersion,
        `Upgrade package ${packageName} to version ${minimumVersion} or newer.`,
      ));
    }
  }

  for (const [schemaName, minimumVersion] of Object.entries(requirement.schemas)) {
    assertRequiredSchemaVersion(schemaName, minimumVersion);
    const installedVersion = installation.schemas[schemaName];
    if (installedVersion === undefined) {
      issues.push(issue(
        "MISSING_SCHEMA",
        schemaName,
        null,
        minimumVersion,
        `Apply schema ${schemaName} through version ${minimumVersion}.`,
      ));
    } else if (!Number.isSafeInteger(installedVersion) || installedVersion < minimumVersion) {
      issues.push(issue(
        "SCHEMA_VERSION_TOO_OLD",
        schemaName,
        installedVersion,
        minimumVersion,
        `Upgrade schema ${schemaName} to version ${minimumVersion} or newer.`,
      ));
    }
  }

  if (requirement.minimumWorkerVersion !== undefined) {
    assertRequiredSemanticVersion("worker", "worker", requirement.minimumWorkerVersion);
    if (installation.workerVersion === undefined) {
      issues.push(issue(
        "MISSING_WORKER",
        "worker",
        null,
        requirement.minimumWorkerVersion,
        `Install the provisioning worker at version ${requirement.minimumWorkerVersion} or newer.`,
      ));
    } else if (!isSemanticVersionAtLeast(
      installation.workerVersion,
      requirement.minimumWorkerVersion,
    )) {
      issues.push(issue(
        "WORKER_VERSION_TOO_OLD",
        "worker",
        installation.workerVersion,
        requirement.minimumWorkerVersion,
        `Upgrade the provisioning worker to version ${requirement.minimumWorkerVersion} or newer.`,
      ));
    }
  }

  const installedRoutes = new Set(installation.routes);
  for (const route of requirement.routes) {
    if (!installedRoutes.has(route)) {
      issues.push(issue(
        "MISSING_ROUTE",
        route,
        null,
        route,
        `Register required route ${route}.`,
      ));
    }
  }

  for (const [moduleId, minimumVersion] of Object.entries(
    requirement.moduleDependencies ?? {},
  )) {
    assertRequiredSemanticVersion("module", moduleId, minimumVersion);
    const installedVersion = installation.modules[moduleId];
    if (
      installedVersion === undefined ||
      !isSemanticVersionAtLeast(installedVersion, minimumVersion)
    ) {
      issues.push(issue(
        "MODULE_DEPENDENCY_MISMATCH",
        moduleId,
        installedVersion ?? null,
        minimumVersion,
        installedVersion === undefined
          ? `Install module ${moduleId} at version ${minimumVersion} or newer.`
          : `Upgrade module ${moduleId} to version ${minimumVersion} or newer.`,
      ));
    }
  }

  return result(issues);
}

function result(issues: readonly CompatibilityIssue[]): CompatibilityResult {
  const frozenIssues = Object.freeze(issues.map((entry) => Object.freeze(entry)));
  return Object.freeze({ compatible: frozenIssues.length === 0, issues: frozenIssues });
}

function issue(
  code: CompatibilityIssue["code"],
  component: string,
  installed: CompatibilityIssue["installed"],
  required: CompatibilityIssue["required"],
  upgradeInstruction: string,
): CompatibilityIssue {
  return { code, component, installed, required, upgradeInstruction };
}

function assertRequiredSchemaVersion(name: string, version: number): void {
  if (!Number.isSafeInteger(version) || version < 0) {
    throw new CompatibilityValidationError(
      `Schema ${name} requires a non-negative safe integer version.`,
    );
  }
}

function assertRequiredSemanticVersion(
  kind: "package" | "worker" | "module",
  name: string,
  version: string,
): void {
  if (parseSemanticVersion(version) === null) {
    throw new CompatibilityValidationError(
      `${kind} ${name} requires a valid semantic version.`,
    );
  }
}

function isSemanticVersionAtLeast(installed: string, required: string): boolean {
  const installedVersion = parseSemanticVersion(installed);
  const requiredVersion = parseSemanticVersion(required);
  if (installedVersion === null || requiredVersion === null) return false;
  return compareSemanticVersions(installedVersion, requiredVersion) >= 0;
}

function parseSemanticVersion(value: string): SemanticVersion | null {
  const match = SEMANTIC_VERSION.exec(value);
  if (!match) return null;

  return {
    major: BigInt(match[1]),
    minor: BigInt(match[2]),
    patch: BigInt(match[3]),
    prerelease: match[4]?.split(".") ?? [],
  };
}

function compareSemanticVersions(left: SemanticVersion, right: SemanticVersion): number {
  for (const [leftPart, rightPart] of [
    [left.major, right.major],
    [left.minor, right.minor],
    [left.patch, right.patch],
  ] as const) {
    if (leftPart < rightPart) return -1;
    if (leftPart > rightPart) return 1;
  }

  if (left.prerelease.length === 0 && right.prerelease.length === 0) return 0;
  if (left.prerelease.length === 0) return 1;
  if (right.prerelease.length === 0) return -1;

  const length = Math.max(left.prerelease.length, right.prerelease.length);
  for (let index = 0; index < length; index += 1) {
    const leftIdentifier = left.prerelease[index];
    const rightIdentifier = right.prerelease[index];
    if (leftIdentifier === undefined) return -1;
    if (rightIdentifier === undefined) return 1;
    if (leftIdentifier === rightIdentifier) continue;

    const leftNumeric = /^\d+$/.test(leftIdentifier);
    const rightNumeric = /^\d+$/.test(rightIdentifier);
    if (leftNumeric && rightNumeric) {
      return BigInt(leftIdentifier) < BigInt(rightIdentifier) ? -1 : 1;
    }
    if (leftNumeric) return -1;
    if (rightNumeric) return 1;
    return leftIdentifier < rightIdentifier ? -1 : 1;
  }

  return 0;
}
