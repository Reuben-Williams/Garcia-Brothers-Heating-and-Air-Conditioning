import type { ProvisioningStepDefinition } from "./contracts.js";

export type ProvisioningCommandRegistryErrorCode =
  | "DUPLICATE_COMMAND"
  | "INVALID_COMMAND_TYPE"
  | "INVALID_COMMAND_VERSION"
  | "MISSING_COMPENSATOR"
  | "MISSING_RUNBOOK_ID";

export class ProvisioningCommandRegistryError extends Error {
  constructor(
    readonly code: ProvisioningCommandRegistryErrorCode,
    message: string,
  ) {
    super(message);
    this.name = "ProvisioningCommandRegistryError";
  }
}

export interface ProvisioningCommandRegistry {
  readonly definitions: readonly ProvisioningStepDefinition[];
  readonly get: (
    type: string,
    version: number,
  ) => ProvisioningStepDefinition | undefined;
}

export function createProvisioningCommandRegistry(
  definitions: readonly ProvisioningStepDefinition[],
): ProvisioningCommandRegistry {
  const snapshots: ProvisioningStepDefinition[] = [];
  const byType = new Map<string, Map<number, ProvisioningStepDefinition>>();

  for (const definition of definitions) {
    validateDefinition(definition);
    const versions = byType.get(definition.type) ?? new Map();
    if (versions.has(definition.version)) {
      invalid(
        "DUPLICATE_COMMAND",
        `Command ${definition.type} version ${definition.version} is registered more than once.`,
      );
    }

    const snapshot = Object.freeze({ ...definition });
    versions.set(snapshot.version, snapshot);
    byType.set(snapshot.type, versions);
    snapshots.push(snapshot);
  }

  const registryDefinitions = Object.freeze(snapshots);
  return Object.freeze({
    definitions: registryDefinitions,
    get: (type: string, version: number) => byType.get(type)?.get(version),
  });
}

function validateDefinition(definition: ProvisioningStepDefinition): void {
  if (typeof definition.type !== "string" || definition.type.trim().length === 0) {
    invalid("INVALID_COMMAND_TYPE", "Command type must be a non-empty string.");
  }
  if (!Number.isSafeInteger(definition.version) || definition.version <= 0) {
    invalid(
      "INVALID_COMMAND_VERSION",
      `Command ${definition.type} must declare a positive integer version.`,
    );
  }
  if (definition.compensation === "automatic" && typeof definition.compensate !== "function") {
    invalid(
      "MISSING_COMPENSATOR",
      `Command ${definition.type} version ${definition.version} requires a compensator.`,
    );
  }
  if (
    definition.compensation === "operator_runbook" &&
    (typeof definition.operatorRunbookId !== "string" ||
      definition.operatorRunbookId.trim().length === 0)
  ) {
    invalid(
      "MISSING_RUNBOOK_ID",
      `Command ${definition.type} version ${definition.version} requires an operator runbook ID.`,
    );
  }
}

function invalid(
  code: ProvisioningCommandRegistryErrorCode,
  message: string,
): never {
  throw new ProvisioningCommandRegistryError(code, message);
}
