import type { ProvisioningStepDecisionRecord } from "./runner.js";

export type CompensationAction =
  | {
      readonly type: "compensate";
      readonly stepId: string;
      readonly commandId: string;
      readonly idempotencyKey: string;
    }
  | { readonly type: "skip_compensation"; readonly stepId: string }
  | {
      readonly type: "pause_operator";
      readonly stepId: string;
      readonly runbookId: string;
    }
  | { readonly type: "complete_compensation" };

export function nextCompensationAction(
  steps: readonly ProvisioningStepDecisionRecord[],
): CompensationAction {
  const next = [...steps]
    .sort((left, right) => right.order - left.order)
    .find(
      (step) =>
        (step.status === "succeeded" || step.status === "compensation_failed"),
    );

  if (!next) return Object.freeze({ type: "complete_compensation" as const });
  if (next.compensation === "none") {
    return Object.freeze({ type: "skip_compensation" as const, stepId: next.id });
  }
  if (next.compensation === "operator_runbook") {
    if (!next.runbookId) throw new TypeError("Operator compensation requires a runbook ID");
    return Object.freeze({
      type: "pause_operator" as const,
      stepId: next.id,
      runbookId: next.runbookId,
    });
  }
  if (!next.compensationCommandId || !next.compensationIdempotencyKey) {
    throw new TypeError("Automatic compensation requires durable command identity");
  }

  return Object.freeze({
    type: "compensate" as const,
    stepId: next.id,
    commandId: next.compensationCommandId,
    idempotencyKey: next.compensationIdempotencyKey,
  });
}

export interface ProvisioningFailureInput {
  readonly kind: "new_module" | "upgrade";
  readonly previousEntitlementState: "provisioning" | "active";
  readonly currentModuleVersion: string | null;
  readonly compensationStatus: "succeeded" | "failed";
  readonly cleanupConfirmation: "pending" | "confirmed" | "failed";
}

export interface ProvisioningFailureDisposition {
  readonly entitlementState:
    | "offboarding"
    | "terminated"
    | "termination_failed"
    | "active";
  readonly preservedModuleVersion: string | null;
  readonly incidentMode: "read_only" | null;
  readonly requiresCleanupConfirmation: boolean;
}

export function provisioningFailureDisposition(
  input: ProvisioningFailureInput,
): ProvisioningFailureDisposition {
  if (input.kind === "new_module" && input.cleanupConfirmation === "pending") {
    return Object.freeze({
      entitlementState: "offboarding" as const,
      preservedModuleVersion: null,
      incidentMode: null,
      requiresCleanupConfirmation: true,
    });
  }
  if (input.kind === "new_module" && input.cleanupConfirmation === "confirmed") {
    return Object.freeze({
      entitlementState: "terminated" as const,
      preservedModuleVersion: null,
      incidentMode: null,
      requiresCleanupConfirmation: false,
    });
  }
  if (input.kind === "new_module" && input.cleanupConfirmation === "failed") {
    return Object.freeze({
      entitlementState: "termination_failed" as const,
      preservedModuleVersion: null,
      incidentMode: null,
      requiresCleanupConfirmation: false,
    });
  }
  if (input.kind === "upgrade") {
    if (!input.currentModuleVersion) {
      throw new TypeError("Upgrade recovery requires the installed module version");
    }
    return Object.freeze({
      entitlementState: "active" as const,
      preservedModuleVersion: input.currentModuleVersion,
      incidentMode: "read_only" as const,
      requiresCleanupConfirmation: false,
    });
  }
  throw new TypeError("Unsupported provisioning failure disposition");
}
