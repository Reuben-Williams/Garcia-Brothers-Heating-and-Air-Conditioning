import {
  nextCompensationAction,
  type CompensationAction,
} from "./compensation.js";

export interface ProvisioningRunDecisionRecord {
  readonly id: string;
  readonly status:
    | "pending"
    | "running"
    | "compensating"
    | "succeeded"
    | "failed"
    | "compensation_failed";
  readonly kind: "new_module" | "upgrade";
  readonly currentModuleVersion: string | null;
  readonly targetModuleVersion: string;
}

export interface ProvisioningStepDecisionRecord {
  readonly id: string;
  readonly order: number;
  readonly status:
    | "pending"
    | "running"
    | "succeeded"
    | "failed"
    | "compensated"
    | "compensation_failed"
    | "skipped";
  readonly commandId: string;
  readonly idempotencyKey: string;
  readonly attempts: number;
  readonly retryAt: string | null;
  readonly compensation: "none" | "automatic" | "operator_runbook";
  readonly runbookId: string | null;
  readonly compensationCommandId?: string;
  readonly compensationIdempotencyKey?: string;
  readonly resultCode?: string;
  readonly lastErrorCode?: string;
  readonly evidence?: Readonly<Record<string, unknown>>;
}

export type ProvisioningStepResult =
  | {
      readonly outcome: "succeeded";
      readonly resultCode: string;
      readonly evidence: Readonly<Record<string, unknown>>;
    }
  | { readonly outcome: "retry"; readonly errorCode: string; readonly retryAt: string }
  | { readonly outcome: "failed"; readonly errorCode: string };

export type ProvisioningAction =
  | CompensationAction
  | {
      readonly type: "await_acknowledgement";
      readonly stepId: string;
      readonly commandId: string;
      readonly idempotencyKey: string;
    }
  | {
      readonly type: "execute";
      readonly stepId: string;
      readonly commandId: string;
      readonly idempotencyKey: string;
    }
  | { readonly type: "wait"; readonly stepId: string; readonly retryAt: string }
  | { readonly type: "begin_compensation"; readonly failedStepId: string }
  | { readonly type: "complete" };

export function nextProvisioningAction(
  run: ProvisioningRunDecisionRecord,
  steps: readonly ProvisioningStepDecisionRecord[],
  _now = new Date().toISOString(),
): ProvisioningAction {
  if (run.status === "compensating") {
    return nextCompensationAction(steps);
  }

  const ordered = [...steps].sort((left, right) => left.order - right.order);
  const current = ordered.find(
    (candidate) => !["succeeded", "compensated", "skipped"].includes(candidate.status),
  );
  if (current?.status === "running") {
    return Object.freeze({
      type: "await_acknowledgement" as const,
      stepId: current.id,
      commandId: current.commandId,
      idempotencyKey: current.idempotencyKey,
    });
  }
  if (current?.status === "failed" && current.retryAt) {
    if (Date.parse(current.retryAt) > Date.parse(_now)) {
      return Object.freeze({
        type: "wait" as const,
        stepId: current.id,
        retryAt: current.retryAt,
      });
    }
    return Object.freeze({
      type: "execute" as const,
      stepId: current.id,
      commandId: current.commandId,
      idempotencyKey: current.idempotencyKey,
    });
  }
  if (current?.status === "failed") {
    return Object.freeze({
      type: "begin_compensation" as const,
      failedStepId: current.id,
    });
  }

  return current?.status === "pending"
    ? Object.freeze({
        type: "execute" as const,
        stepId: current.id,
        commandId: current.commandId,
        idempotencyKey: current.idempotencyKey,
      })
    : Object.freeze({ type: "complete" as const });
}

export function applyProvisioningStepResult(
  current: ProvisioningStepDecisionRecord,
  result: ProvisioningStepResult,
): ProvisioningStepDecisionRecord {
  if (result.outcome === "succeeded") {
    return Object.freeze({
      ...current,
      status: "succeeded" as const,
      retryAt: null,
      resultCode: result.resultCode,
      evidence: Object.freeze({ ...result.evidence }),
    });
  }

  return Object.freeze({
    ...current,
    status: "failed" as const,
    retryAt: result.outcome === "retry" ? result.retryAt : null,
    lastErrorCode: result.errorCode,
  });
}
