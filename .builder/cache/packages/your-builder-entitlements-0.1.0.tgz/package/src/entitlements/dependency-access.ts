import {
  ENTITLEMENT_ACCESS,
  resolveEntitlementAccess,
  type EntitlementAccessPolicy,
} from "./access-policy.js";
import type { EntitlementState } from "./states.js";

export type GrowthReadAction = "setup.read" | "operational.read";
export type GrowthWriteAction =
  | "provisioning.command"
  | "setup.action"
  | "operational.write"
  | "repair.note"
  | "offboarding.action";
export type GrowthOutboundAction = "outbound.test" | "outbound.operational";
export type GrowthExportAction = "export.completed" | "export.current";

export interface GrowthActionSets {
  readonly read: readonly GrowthReadAction[];
  readonly write: readonly GrowthWriteAction[];
  readonly outbound: readonly GrowthOutboundAction[];
  readonly export: readonly GrowthExportAction[];
}

export type DependencySnapshotResolution =
  | { readonly kind: "fresh" }
  | { readonly kind: "cached"; readonly outageDeadline: string }
  | { readonly kind: "stale"; readonly priorValid: true }
  | {
      readonly kind: "missing" | "invalid_signature" | "unknown" | "inconsistent";
      readonly priorValid: boolean;
    };

export interface ModuleDependencyAccessInput {
  readonly state: EntitlementState;
  readonly now: string;
  readonly graceDeadline?: string | null;
  readonly snapshot: DependencySnapshotResolution;
  readonly incidentMode?: "read_only" | "blocked" | null;
}

export interface ResolvedModuleDependencyAccess {
  readonly state: EntitlementState;
  readonly actions: GrowthActionSets;
  readonly repair: EntitlementAccessPolicy["repair"];
  readonly snapshotMode: "current" | "cached" | "stale_read_only" | "denied";
  readonly healthAlert: boolean;
}

export interface DependentGrowthAccess {
  readonly customers: ResolvedModuleDependencyAccess;
  readonly leads: ResolvedModuleDependencyAccess;
  readonly sharedActions: GrowthActionSets;
  readonly enhancedIngestion: boolean;
  readonly healthAlert: boolean;
}

export interface RepairActorAuthorization {
  readonly siteOwner: boolean;
  readonly billingManage: boolean;
  readonly provisioningOperator: boolean;
  readonly offboardingOperator: boolean;
}

export function canExecuteRepairDirective(
  directive: EntitlementAccessPolicy["repair"],
  actor: RepairActorAuthorization,
): boolean {
  switch (directive) {
    case "request_only":
    case "billing_reconnect":
    case "reactivation":
      return actor.siteOwner && actor.billingManage;
    case "provisioning":
      return actor.provisioningOperator;
    case "setup":
      return actor.siteOwner;
    case "offboarding":
      return actor.siteOwner || actor.offboardingOperator;
    case "normal":
      return false;
  }
}

const EMPTY_READ = Object.freeze([]) as readonly GrowthReadAction[];
const EMPTY_WRITE = Object.freeze([]) as readonly GrowthWriteAction[];
const EMPTY_OUTBOUND = Object.freeze([]) as readonly GrowthOutboundAction[];
const EMPTY_EXPORT = Object.freeze([]) as readonly GrowthExportAction[];

const READ_ACTIONS = Object.freeze({
  none: EMPTY_READ,
  setup_records: Object.freeze(["setup.read"]),
  operational: Object.freeze(["operational.read"]),
} satisfies Record<EntitlementAccessPolicy["read"], readonly GrowthReadAction[]>);

const WRITE_ACTIONS = Object.freeze({
  none: EMPTY_WRITE,
  provisioning_commands: Object.freeze(["provisioning.command"]),
  setup_actions: Object.freeze(["setup.action"]),
  operational: Object.freeze(["operational.write"]),
  repair_notes: Object.freeze(["repair.note"]),
  offboarding_actions: Object.freeze(["offboarding.action"]),
} satisfies Record<EntitlementAccessPolicy["write"], readonly GrowthWriteAction[]>);

const OUTBOUND_ACTIONS = Object.freeze({
  none: EMPTY_OUTBOUND,
  test_destinations: Object.freeze(["outbound.test"]),
  operational: Object.freeze(["outbound.operational"]),
} satisfies Record<EntitlementAccessPolicy["outbound"], readonly GrowthOutboundAction[]>);

const EXPORT_ACTIONS = Object.freeze({
  none: EMPTY_EXPORT,
  completed_only: Object.freeze(["export.completed"]),
  full: Object.freeze(["export.completed", "export.current"]),
} satisfies Record<EntitlementAccessPolicy["export"], readonly GrowthExportAction[]>);

const NO_ACTIONS: GrowthActionSets = Object.freeze({
  read: EMPTY_READ,
  write: EMPTY_WRITE,
  outbound: EMPTY_OUTBOUND,
  export: EMPTY_EXPORT,
});

function actionsForPolicy(policy: EntitlementAccessPolicy): GrowthActionSets {
  return Object.freeze({
    read: READ_ACTIONS[policy.read],
    write: WRITE_ACTIONS[policy.write],
    outbound: OUTBOUND_ACTIONS[policy.outbound],
    export: EXPORT_ACTIONS[policy.export],
  });
}

function parseCanonicalTimestamp(value: string): number | null {
  const milliseconds = Date.parse(value);
  return Number.isFinite(milliseconds) && new Date(milliseconds).toISOString() === value
    ? milliseconds
    : null;
}

function staleActions(actions: GrowthActionSets): GrowthActionSets {
  return Object.freeze({
    read: actions.read,
    write: EMPTY_WRITE,
    outbound: EMPTY_OUTBOUND,
    export: EMPTY_EXPORT,
  });
}

function incidentReadOnlyActions(actions: GrowthActionSets): GrowthActionSets {
  return Object.freeze({
    read: actions.read,
    write: EMPTY_WRITE,
    outbound: EMPTY_OUTBOUND,
    export: actions.export,
  });
}

function resolveModule(input: ModuleDependencyAccessInput): ResolvedModuleDependencyAccess {
  const repair = ENTITLEMENT_ACCESS[input.state].repair;
  const now = parseCanonicalTimestamp(input.now);
  if (now === null) {
    return Object.freeze({
      state: input.state,
      actions: NO_ACTIONS,
      repair,
      snapshotMode: "denied",
      healthAlert: true,
    });
  }

  let actions: GrowthActionSets;
  try {
    actions = actionsForPolicy(resolveEntitlementAccess({
      state: input.state,
      now: input.now,
      graceDeadline: input.graceDeadline,
    }));
  } catch {
    actions = NO_ACTIONS;
  }

  let snapshotMode: ResolvedModuleDependencyAccess["snapshotMode"];
  let healthAlert = false;
  switch (input.snapshot.kind) {
    case "fresh":
      snapshotMode = "current";
      break;
    case "cached": {
      const outageDeadline = parseCanonicalTimestamp(input.snapshot.outageDeadline);
      if (outageDeadline !== null && now < outageDeadline) {
        snapshotMode = "cached";
      } else {
        snapshotMode = "stale_read_only";
        actions = staleActions(actions);
        healthAlert = true;
      }
      break;
    }
    case "stale":
      snapshotMode = "stale_read_only";
      actions = staleActions(actions);
      healthAlert = true;
      break;
    default:
      healthAlert = true;
      if (input.snapshot.priorValid) {
        snapshotMode = "stale_read_only";
        actions = staleActions(actions);
      } else {
        snapshotMode = "denied";
        actions = NO_ACTIONS;
      }
  }

  if (input.incidentMode === "blocked") {
    actions = NO_ACTIONS;
    healthAlert = true;
  } else if (input.incidentMode === "read_only") {
    actions = incidentReadOnlyActions(actions);
    healthAlert = true;
  }

  return Object.freeze({
    state: input.state,
    actions,
    repair,
    snapshotMode,
    healthAlert,
  });
}

function intersect<Action extends string>(
  left: readonly Action[],
  right: readonly Action[],
): readonly Action[] {
  const rightActions = new Set(right);
  return Object.freeze(left.filter((action) => rightActions.has(action)));
}

function intersectActions(left: GrowthActionSets, right: GrowthActionSets): GrowthActionSets {
  return Object.freeze({
    read: intersect(left.read, right.read),
    write: intersect(left.write, right.write),
    outbound: intersect(left.outbound, right.outbound),
    export: intersect(left.export, right.export),
  });
}

export function resolveDependentGrowthAccess(input: {
  readonly customers: ModuleDependencyAccessInput;
  readonly leads: ModuleDependencyAccessInput;
}): DependentGrowthAccess {
  const customers = resolveModule(input.customers);
  const leads = resolveModule(input.leads);
  const sharedActions = intersectActions(customers.actions, leads.actions);
  return Object.freeze({
    customers,
    leads,
    sharedActions,
    enhancedIngestion: sharedActions.write.includes("operational.write"),
    healthAlert: customers.healthAlert || leads.healthAlert,
  });
}
