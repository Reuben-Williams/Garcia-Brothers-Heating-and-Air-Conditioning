const MILLISECONDS_PER_DAY = 86_400_000;

export interface TrialEvidence {
  readonly trialDurationDays: number;
  readonly trialStartedAt: string | null;
  readonly trialExpiresAt: string | null;
  readonly trialScheduleVersion: number;
}

export interface CreatePendingTrialEvidenceInput {
  readonly trialDurationDays: number;
  readonly currentScheduleVersion: number;
}

export interface StartTrialInput extends CreatePendingTrialEvidenceInput {
  readonly startedAt: string;
}

export interface ExtendTrialInput {
  readonly evidence: TrialEvidence;
  readonly newExpiresAt: string;
}

export interface EvaluateTrialExpiryInput {
  readonly evidence: TrialEvidence;
  readonly expectedScheduleVersion: number;
  readonly now: string;
}

export type TrialExpiryDecision =
  | Readonly<{
      status: "stale";
      expectedScheduleVersion: number;
      actualScheduleVersion: number;
    }>
  | Readonly<{ status: "not_due"; trialExpiresAt: string }>
  | Readonly<{
      status: "expired";
      trialExpiresAt: string;
      trialScheduleVersion: number;
    }>;

export class TrialValidationError extends Error {
  readonly code = "invalid_trial" as const;

  constructor(message: string) {
    super(message);
    this.name = "TrialValidationError";
  }
}

export function createPendingTrialEvidence(
  input: CreatePendingTrialEvidenceInput,
): TrialEvidence {
  assertDuration(input.trialDurationDays);
  assertScheduleVersion(input.currentScheduleVersion);

  return Object.freeze({
    trialDurationDays: input.trialDurationDays,
    trialStartedAt: null,
    trialExpiresAt: null,
    trialScheduleVersion: input.currentScheduleVersion,
  });
}

export function startTrial(input: StartTrialInput): TrialEvidence {
  assertDuration(input.trialDurationDays);
  assertScheduleVersion(input.currentScheduleVersion);
  const startedAt = parseCanonicalTimestamp(input.startedAt, "startedAt");
  const expiresAt = startedAt + input.trialDurationDays * MILLISECONDS_PER_DAY;
  const scheduleVersion = incrementVersion(input.currentScheduleVersion);

  return Object.freeze({
    trialDurationDays: input.trialDurationDays,
    trialStartedAt: input.startedAt,
    trialExpiresAt: new Date(expiresAt).toISOString(),
    trialScheduleVersion: scheduleVersion,
  });
}

export function extendTrial(input: ExtendTrialInput): TrialEvidence {
  assertStartedEvidence(input.evidence);
  const currentExpiry = parseCanonicalTimestamp(
    input.evidence.trialExpiresAt,
    "trialExpiresAt",
  );
  const newExpiry = parseCanonicalTimestamp(input.newExpiresAt, "newExpiresAt");
  if (newExpiry <= currentExpiry) {
    throw new TrialValidationError(
      "newExpiresAt must be later than the current trial expiry.",
    );
  }

  return Object.freeze({
    trialDurationDays: input.evidence.trialDurationDays,
    trialStartedAt: input.evidence.trialStartedAt,
    trialExpiresAt: input.newExpiresAt,
    trialScheduleVersion: incrementVersion(input.evidence.trialScheduleVersion),
  });
}

export function evaluateTrialExpiry(
  input: EvaluateTrialExpiryInput,
): TrialExpiryDecision {
  assertStartedEvidence(input.evidence);
  assertScheduleVersion(input.expectedScheduleVersion);

  if (input.expectedScheduleVersion !== input.evidence.trialScheduleVersion) {
    return Object.freeze({
      status: "stale",
      expectedScheduleVersion: input.expectedScheduleVersion,
      actualScheduleVersion: input.evidence.trialScheduleVersion,
    });
  }

  const now = parseCanonicalTimestamp(input.now, "now");
  const expiresAt = parseCanonicalTimestamp(
    input.evidence.trialExpiresAt,
    "trialExpiresAt",
  );
  if (now < expiresAt) {
    return Object.freeze({
      status: "not_due",
      trialExpiresAt: input.evidence.trialExpiresAt,
    });
  }
  return Object.freeze({
    status: "expired",
    trialExpiresAt: input.evidence.trialExpiresAt,
    trialScheduleVersion: input.evidence.trialScheduleVersion,
  });
}

function assertStartedEvidence(
  evidence: TrialEvidence,
): asserts evidence is TrialEvidence & {
  readonly trialStartedAt: string;
  readonly trialExpiresAt: string;
} {
  assertDuration(evidence.trialDurationDays);
  assertScheduleVersion(evidence.trialScheduleVersion);
  const startedAt = parseCanonicalTimestamp(evidence.trialStartedAt, "trialStartedAt");
  const expiresAt = parseCanonicalTimestamp(evidence.trialExpiresAt, "trialExpiresAt");
  if (expiresAt <= startedAt) {
    throw new TrialValidationError("Trial expiry must be later than trial start.");
  }
}

function assertDuration(value: number): void {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new TrialValidationError("trialDurationDays must be a positive integer.");
  }
}

function assertScheduleVersion(value: number): void {
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new TrialValidationError(
      "Trial schedule versions must be non-negative safe integers.",
    );
  }
}

function incrementVersion(value: number): number {
  const next = value + 1;
  assertScheduleVersion(next);
  return next;
}

function parseCanonicalTimestamp(
  value: string | null,
  field: string,
): number {
  if (typeof value !== "string") {
    throw new TrialValidationError(`${field} must be a canonical ISO-8601 timestamp.`);
  }
  const milliseconds = Date.parse(value);
  if (!Number.isFinite(milliseconds) || new Date(milliseconds).toISOString() !== value) {
    throw new TrialValidationError(`${field} must be a canonical ISO-8601 timestamp.`);
  }
  return milliseconds;
}
