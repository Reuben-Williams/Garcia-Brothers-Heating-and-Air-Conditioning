import type { EntitlementState } from "./states.js";

export interface EntitlementAccessPolicy {
  readonly demo: boolean;
  readonly repair:
    | "request_only"
    | "provisioning"
    | "setup"
    | "normal"
    | "billing_reconnect"
    | "offboarding"
    | "reactivation";
  readonly read: "none" | "setup_records" | "operational";
  readonly write:
    | "none"
    | "provisioning_commands"
    | "setup_actions"
    | "operational"
    | "repair_notes"
    | "offboarding_actions";
  readonly outbound: "none" | "test_destinations" | "operational";
  readonly export: "none" | "full" | "completed_only";
}

function policy(value: EntitlementAccessPolicy): EntitlementAccessPolicy {
  return Object.freeze(value);
}

export const ENTITLEMENT_ACCESS: Readonly<
  Record<EntitlementState, EntitlementAccessPolicy>
> = Object.freeze({
  available: policy({ demo: true, repair: "request_only", read: "none", write: "none", outbound: "none", export: "none" }),
  requested: policy({ demo: true, repair: "request_only", read: "none", write: "none", outbound: "none", export: "none" }),
  request_withdrawn: policy({ demo: true, repair: "request_only", read: "none", write: "none", outbound: "none", export: "none" }),
  trial_expired: policy({ demo: true, repair: "request_only", read: "none", write: "none", outbound: "none", export: "none" }),
  provisioning: policy({ demo: true, repair: "provisioning", read: "none", write: "provisioning_commands", outbound: "none", export: "none" }),
  provisioning_error: policy({ demo: true, repair: "provisioning", read: "none", write: "provisioning_commands", outbound: "none", export: "none" }),
  setup_required: policy({ demo: true, repair: "setup", read: "setup_records", write: "setup_actions", outbound: "test_destinations", export: "full" }),
  trialing: policy({ demo: true, repair: "normal", read: "operational", write: "operational", outbound: "operational", export: "full" }),
  active: policy({ demo: false, repair: "normal", read: "operational", write: "operational", outbound: "operational", export: "full" }),
  payment_attention: policy({ demo: false, repair: "billing_reconnect", read: "operational", write: "operational", outbound: "operational", export: "full" }),
  grace_period: policy({ demo: false, repair: "billing_reconnect", read: "operational", write: "operational", outbound: "operational", export: "full" }),
  suspended: policy({ demo: false, repair: "billing_reconnect", read: "operational", write: "repair_notes", outbound: "none", export: "full" }),
  offboarding: policy({ demo: false, repair: "offboarding", read: "operational", write: "offboarding_actions", outbound: "none", export: "full" }),
  termination_failed: policy({ demo: false, repair: "offboarding", read: "operational", write: "offboarding_actions", outbound: "none", export: "full" }),
  terminated: policy({ demo: false, repair: "reactivation", read: "none", write: "none", outbound: "none", export: "completed_only" }),
});

const EXPIRED_GRACE_ACCESS = policy({
  ...ENTITLEMENT_ACCESS.grace_period,
  write: "none",
  outbound: "none",
});

export interface ResolveEntitlementAccessInput {
  readonly state: EntitlementState;
  readonly now: string;
  readonly graceDeadline?: string | null;
}

export class EntitlementAccessError extends Error {
  readonly code = "invalid_time" as const;

  constructor(message: string) {
    super(message);
    this.name = "EntitlementAccessError";
  }
}

export function resolveEntitlementAccess(
  input: ResolveEntitlementAccessInput,
): EntitlementAccessPolicy {
  const now = parseCanonicalTimestamp(input.now);
  if (now === null) {
    throw new EntitlementAccessError("now must be a canonical ISO-8601 timestamp.");
  }

  const basePolicy = ENTITLEMENT_ACCESS[input.state];
  if (!basePolicy) {
    return EXPIRED_GRACE_ACCESS;
  }
  if (input.state !== "grace_period") {
    return basePolicy;
  }

  const graceDeadline = parseCanonicalTimestamp(input.graceDeadline);
  return graceDeadline !== null && now < graceDeadline
    ? basePolicy
    : EXPIRED_GRACE_ACCESS;
}

function parseCanonicalTimestamp(value: string | null | undefined): number | null {
  if (typeof value !== "string") return null;
  const milliseconds = Date.parse(value);
  if (!Number.isFinite(milliseconds)) return null;
  return new Date(milliseconds).toISOString() === value ? milliseconds : null;
}
