import { MODULE_IDS, type GrowthModuleId } from "@your-builder/feature-registry";
import { ENTITLEMENT_STATES, type EntitlementState } from "./states.js";

export const ENTITLEMENT_SNAPSHOT_VERSION = 1 as const;

export interface EntitlementSnapshotModule {
  readonly state: EntitlementState;
  readonly moduleVersion: string;
  readonly setupComplete: boolean;
  readonly graceExpiresAt?: string | null;
}

export interface EntitlementIncidentOverride {
  readonly moduleId: GrowthModuleId | "*";
  readonly mode: "read_only" | "blocked";
  readonly reasonCode: string;
}

export interface EntitlementSnapshot {
  readonly version: typeof ENTITLEMENT_SNAPSHOT_VERSION;
  readonly siteId: string;
  readonly installationId: string;
  readonly issuedAt: string;
  readonly expiresAt: string;
  readonly sequence: number;
  readonly modules: Readonly<Record<GrowthModuleId, EntitlementSnapshotModule>>;
  readonly incidentOverrides: readonly EntitlementIncidentOverride[];
}

const MODULE_IDS_SET = new Set<string>(Object.values(MODULE_IDS));
const STATE_SET = new Set<string>(ENTITLEMENT_STATES);
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const VERSION_PATTERN = /^[A-Za-z0-9][A-Za-z0-9.+_-]{0,63}$/;
const REASON_PATTERN = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,63}$/;

function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
}

function hasExactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  const actual = Object.keys(value).sort();
  const expected = [...keys].sort();
  return actual.length === expected.length && actual.every((key, index) => key === expected[index]);
}

function isIsoTimestamp(value: unknown): value is string {
  if (typeof value !== "string") return false;
  const date = new Date(value);
  return !Number.isNaN(date.valueOf()) && date.toISOString() === value;
}

export function isEntitlementSnapshot(value: unknown): value is EntitlementSnapshot {
  if (!isPlainRecord(value) || !hasExactKeys(value, [
    "version", "siteId", "installationId", "issuedAt", "expiresAt", "sequence", "modules", "incidentOverrides",
  ])) return false;

  if (value.version !== ENTITLEMENT_SNAPSHOT_VERSION
    || typeof value.siteId !== "string" || !UUID_PATTERN.test(value.siteId)
    || typeof value.installationId !== "string" || !UUID_PATTERN.test(value.installationId)
    || !isIsoTimestamp(value.issuedAt) || !isIsoTimestamp(value.expiresAt)
    || !Number.isSafeInteger(value.sequence) || Number(value.sequence) < 1
    || !isPlainRecord(value.modules)
    || !hasExactKeys(value.modules, Object.values(MODULE_IDS))
    || !Array.isArray(value.incidentOverrides) || value.incidentOverrides.length > 100) return false;

  for (const [moduleId, moduleValue] of Object.entries(value.modules)) {
    if (!MODULE_IDS_SET.has(moduleId) || !isPlainRecord(moduleValue)) return false;

    const isLegacyModule = hasExactKeys(moduleValue, ["state", "moduleVersion", "setupComplete"]);
    const isCanonicalModule = hasExactKeys(moduleValue, ["state", "moduleVersion", "setupComplete", "graceExpiresAt"]);
    if ((!isLegacyModule && !isCanonicalModule)
      || typeof moduleValue.state !== "string" || !STATE_SET.has(moduleValue.state)
      || typeof moduleValue.moduleVersion !== "string" || !VERSION_PATTERN.test(moduleValue.moduleVersion)
      || typeof moduleValue.setupComplete !== "boolean") return false;

    if (isCanonicalModule && (
      moduleValue.state === "grace_period"
        ? !isIsoTimestamp(moduleValue.graceExpiresAt)
        : moduleValue.graceExpiresAt !== null
    )) return false;
  }

  for (const incident of value.incidentOverrides) {
    if (!isPlainRecord(incident) || !hasExactKeys(incident, ["moduleId", "mode", "reasonCode"])
      || typeof incident.moduleId !== "string" || (incident.moduleId !== "*" && !MODULE_IDS_SET.has(incident.moduleId))
      || (incident.mode !== "read_only" && incident.mode !== "blocked")
      || typeof incident.reasonCode !== "string" || !REASON_PATTERN.test(incident.reasonCode)) return false;
  }

  return true;
}

export function isEntitlementSnapshotTimingValid(snapshot: EntitlementSnapshot, now: Date): boolean {
  const issuedAt = new Date(snapshot.issuedAt).valueOf();
  const expiresAt = new Date(snapshot.expiresAt).valueOf();
  return issuedAt <= now.valueOf() && expiresAt > issuedAt && expiresAt - issuedAt <= 24 * 60 * 60 * 1000;
}
