export const ENTITLEMENT_STATES = Object.freeze([
  "available",
  "requested",
  "request_withdrawn",
  "trialing",
  "trial_expired",
  "provisioning",
  "provisioning_error",
  "setup_required",
  "active",
  "payment_attention",
  "grace_period",
  "suspended",
  "offboarding",
  "termination_failed",
  "terminated",
] as const);

export type EntitlementState = (typeof ENTITLEMENT_STATES)[number];

const stateSet: ReadonlySet<string> = new Set(ENTITLEMENT_STATES);

export function isEntitlementState(value: unknown): value is EntitlementState {
  return typeof value === "string" && stateSet.has(value);
}
