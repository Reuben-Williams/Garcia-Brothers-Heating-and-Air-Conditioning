import type { EntitlementState } from "./states.js";

export const ACTIVATION_MODES = Object.freeze([
  "trial",
  "paid_new",
  "paid_upgrade",
  "manual_grant",
] as const);

export type ActivationMode = (typeof ACTIVATION_MODES)[number];
export type ActivationSuccessfulState = "trialing" | "active";

export interface ActivationCommandInput {
  readonly commandId: string;
  readonly idempotencyKey: string;
  readonly entitlementId: string;
  readonly expectedState: EntitlementState;
  readonly expectedVersion: number;
  readonly activationMode: ActivationMode;
  readonly intendedSuccessfulState: ActivationSuccessfulState;
  readonly trialDurationDays: number | null;
  readonly actorId: string;
  readonly source: string;
  readonly reason: string;
  readonly requestedAt: string;
}

export interface ActivationCommand extends ActivationCommandInput {
  readonly trialStartedAt: null;
  readonly trialExpiresAt: null;
}

export class ActivationCommandValidationError extends Error {
  readonly code = "invalid_activation_command" as const;

  constructor(message: string) {
    super(message);
    this.name = "ActivationCommandValidationError";
  }
}

const NEW_ACTIVATION_STATES: ReadonlySet<EntitlementState> = new Set([
  "available",
  "requested",
  "trial_expired",
  "provisioning_error",
]);
const UPGRADE_STATES: ReadonlySet<EntitlementState> = new Set([
  "active",
  "payment_attention",
  "grace_period",
]);

export function createActivationCommand(
  input: ActivationCommandInput,
): ActivationCommand {
  assertAuditFields(input);
  assertActivationCombination(input);

  return Object.freeze({
    ...input,
    trialStartedAt: null,
    trialExpiresAt: null,
  });
}

function assertAuditFields(input: ActivationCommandInput): void {
  for (const [name, value] of [
    ["commandId", input.commandId],
    ["idempotencyKey", input.idempotencyKey],
    ["entitlementId", input.entitlementId],
    ["actorId", input.actorId],
    ["source", input.source],
  ] as const) {
    if (!hasText(value, 128)) {
      invalid(`${name} is required and must not exceed 128 characters.`);
    }
  }
  if (!hasText(input.reason, 2_000)) {
    invalid("Reason is required and must not exceed 2,000 characters.");
  }
  if (!Number.isSafeInteger(input.expectedVersion) || input.expectedVersion < 0) {
    invalid("expectedVersion must be a non-negative safe integer.");
  }
  if (!isCanonicalTimestamp(input.requestedAt)) {
    invalid("requestedAt must be a canonical ISO-8601 timestamp.");
  }
}

function assertActivationCombination(input: ActivationCommandInput): void {
  if (input.activationMode === "trial") {
    if (input.intendedSuccessfulState !== "trialing") {
      invalid("Trial activation must target trialing.");
    }
    if (
      input.trialDurationDays === null ||
      !Number.isSafeInteger(input.trialDurationDays) ||
      input.trialDurationDays <= 0
    ) {
      invalid("Trial activation requires a positive integer trialDurationDays.");
    }
    if (!NEW_ACTIVATION_STATES.has(input.expectedState)) {
      invalid("Trial activation cannot start from the expected entitlement state.");
    }
    return;
  }

  if (input.intendedSuccessfulState !== "active") {
    invalid("Paid and manual activation must target active.");
  }
  if (input.trialDurationDays !== null) {
    invalid("Only trial activation may carry trialDurationDays.");
  }
  const validExpectedState =
    input.activationMode === "paid_upgrade"
      ? UPGRADE_STATES.has(input.expectedState)
      : NEW_ACTIVATION_STATES.has(input.expectedState);
  if (!validExpectedState) {
    invalid(`${input.activationMode} cannot start from the expected entitlement state.`);
  }
}

function hasText(value: string, maximumLength: number): boolean {
  return value.trim().length > 0 && value.length <= maximumLength;
}

function isCanonicalTimestamp(value: string): boolean {
  const milliseconds = Date.parse(value);
  return Number.isFinite(milliseconds) && new Date(milliseconds).toISOString() === value;
}

function invalid(message: string): never {
  throw new ActivationCommandValidationError(message);
}
