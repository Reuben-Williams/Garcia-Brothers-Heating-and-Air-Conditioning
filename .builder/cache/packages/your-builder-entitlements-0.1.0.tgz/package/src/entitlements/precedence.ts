export type EntitlementGrantSource =
  | "base"
  | "billing"
  | "trial"
  | "manual_override";

export interface EntitlementResolutionInput {
  readonly base: boolean;
  readonly billing: boolean;
  readonly trial: boolean;
  readonly manualOverride: boolean;
  readonly terminated: boolean;
  readonly graceExpired: boolean;
  readonly securitySuspended: boolean;
  readonly incidentSuspended: boolean;
}

export type EntitlementResolution =
  | Readonly<{ allowed: false; reason: "incident" | "security" | "contract" }>
  | Readonly<{ allowed: boolean; source: EntitlementGrantSource }>;

export function resolveEntitlement(
  input: EntitlementResolutionInput,
): EntitlementResolution {
  if (input.incidentSuspended) {
    return Object.freeze({ allowed: false, reason: "incident" });
  }
  if (input.securitySuspended) {
    return Object.freeze({ allowed: false, reason: "security" });
  }
  if (input.terminated || input.graceExpired) {
    return Object.freeze({ allowed: false, reason: "contract" });
  }
  if (input.manualOverride) {
    return Object.freeze({ allowed: true, source: "manual_override" });
  }
  if (input.trial) {
    return Object.freeze({ allowed: true, source: "trial" });
  }
  if (input.billing) {
    return Object.freeze({ allowed: true, source: "billing" });
  }
  return Object.freeze({ allowed: input.base, source: "base" });
}
