import type { EntitlementState } from "./states.js";

export const ENTITLEMENT_TRANSITIONS: Readonly<
  Record<EntitlementState, readonly EntitlementState[]>
> = Object.freeze({
  available: transitionTargets("requested", "provisioning"),
  requested: transitionTargets("request_withdrawn", "provisioning"),
  request_withdrawn: transitionTargets("requested"),
  provisioning: transitionTargets(
    "setup_required",
    "trialing",
    "active",
    "provisioning_error",
  ),
  provisioning_error: transitionTargets(
    "provisioning",
    "request_withdrawn",
    "offboarding",
  ),
  setup_required: transitionTargets(
    "trialing",
    "active",
    "suspended",
    "offboarding",
  ),
  trialing: transitionTargets(
    "active",
    "trial_expired",
    "suspended",
    "offboarding",
  ),
  trial_expired: transitionTargets(
    "available",
    "requested",
    "provisioning",
    "offboarding",
  ),
  active: transitionTargets(
    "payment_attention",
    "grace_period",
    "suspended",
    "offboarding",
  ),
  payment_attention: transitionTargets(
    "active",
    "grace_period",
    "suspended",
    "offboarding",
  ),
  grace_period: transitionTargets("active", "suspended", "offboarding"),
  suspended: transitionTargets("active", "grace_period", "offboarding"),
  offboarding: transitionTargets("terminated", "termination_failed"),
  termination_failed: transitionTargets("offboarding", "terminated"),
  terminated: transitionTargets(),
});

function transitionTargets<const T extends readonly EntitlementState[]>(
  ...states: T
): T {
  return Object.freeze(states) as T;
}

export interface EntitlementRecord {
  readonly id: string;
  readonly state: EntitlementState;
  readonly version: number;
  readonly updatedAt: string;
}

export interface EntitlementTransitionEvent {
  readonly entitlementId: string;
  readonly fromState: EntitlementState;
  readonly toState: EntitlementState;
  readonly expectedState: EntitlementState;
  readonly expectedVersion: number;
  readonly resultingVersion: number;
  readonly commandId: string;
  readonly idempotencyKey: string;
  readonly actorId: string;
  readonly source: string;
  readonly reason: string;
  readonly occurredAt: string;
}

export interface TransitionEntitlementInput {
  readonly entitlement: EntitlementRecord;
  readonly toState: EntitlementState;
  readonly expectedState: EntitlementState;
  readonly expectedVersion: number;
  readonly commandId: string;
  readonly idempotencyKey: string;
  readonly actorId: string;
  readonly source: string;
  readonly reason: string;
  readonly occurredAt: string;
}

export interface EntitlementTransitionResult {
  readonly entitlement: EntitlementRecord;
  readonly event: EntitlementTransitionEvent;
}

export type EntitlementTransitionErrorCode =
  | "expected_state_mismatch"
  | "expected_version_mismatch"
  | "transition_not_allowed"
  | "invalid_command";

export class EntitlementTransitionError extends Error {
  readonly code: EntitlementTransitionErrorCode;

  constructor(code: EntitlementTransitionErrorCode, message: string) {
    super(message);
    this.name = "EntitlementTransitionError";
    this.code = code;
  }
}

export function canTransitionEntitlement(
  fromState: EntitlementState,
  toState: EntitlementState,
): boolean {
  return ENTITLEMENT_TRANSITIONS[fromState]?.includes(toState) ?? false;
}

export function transitionEntitlement(
  input: TransitionEntitlementInput,
): EntitlementTransitionResult {
  if (input.entitlement.state !== input.expectedState) {
    throw new EntitlementTransitionError(
      "expected_state_mismatch",
      `Expected entitlement state ${input.expectedState}, received ${input.entitlement.state}.`,
    );
  }
  if (input.entitlement.version !== input.expectedVersion) {
    throw new EntitlementTransitionError(
      "expected_version_mismatch",
      `Expected entitlement version ${input.expectedVersion}, received ${input.entitlement.version}.`,
    );
  }

  assertValidTransitionCommand(input);

  if (!canTransitionEntitlement(input.entitlement.state, input.toState)) {
    throw new EntitlementTransitionError(
      "transition_not_allowed",
      `Transition ${input.entitlement.state} -> ${input.toState} is not allowed.`,
    );
  }

  const resultingVersion = input.entitlement.version + 1;
  if (!Number.isSafeInteger(resultingVersion)) {
    throw new EntitlementTransitionError(
      "invalid_command",
      "The resulting entitlement version must be a safe integer.",
    );
  }

  const entitlement: EntitlementRecord = Object.freeze({
    id: input.entitlement.id,
    state: input.toState,
    version: resultingVersion,
    updatedAt: input.occurredAt,
  });
  const event: EntitlementTransitionEvent = Object.freeze({
    entitlementId: input.entitlement.id,
    fromState: input.entitlement.state,
    toState: input.toState,
    expectedState: input.expectedState,
    expectedVersion: input.expectedVersion,
    resultingVersion,
    commandId: input.commandId,
    idempotencyKey: input.idempotencyKey,
    actorId: input.actorId,
    source: input.source,
    reason: input.reason,
    occurredAt: input.occurredAt,
  });

  return Object.freeze({ entitlement, event });
}

function assertValidTransitionCommand(input: TransitionEntitlementInput): void {
  if (!isSafeInteger(input.entitlement.version) || !isSafeInteger(input.expectedVersion)) {
    invalidCommand("Entitlement versions must be non-negative safe integers.");
  }
  if (!hasText(input.entitlement.id, 128)) {
    invalidCommand("Entitlement ID is required and must not exceed 128 characters.");
  }
  for (const [name, value] of [
    ["commandId", input.commandId],
    ["idempotencyKey", input.idempotencyKey],
    ["actorId", input.actorId],
    ["source", input.source],
  ] as const) {
    if (!hasText(value, 128)) {
      invalidCommand(`${name} is required and must not exceed 128 characters.`);
    }
  }
  if (!hasText(input.reason, 2_000)) {
    invalidCommand("Reason is required and must not exceed 2,000 characters.");
  }
  if (!isCanonicalTimestamp(input.occurredAt)) {
    invalidCommand("occurredAt must be a canonical ISO-8601 timestamp.");
  }
}

function hasText(value: string, maximumLength: number): boolean {
  return value.trim().length > 0 && value.length <= maximumLength;
}

function isSafeInteger(value: number): boolean {
  return Number.isSafeInteger(value) && value >= 0;
}

function isCanonicalTimestamp(value: string): boolean {
  const milliseconds = Date.parse(value);
  return Number.isFinite(milliseconds) && new Date(milliseconds).toISOString() === value;
}

function invalidCommand(message: string): never {
  throw new EntitlementTransitionError("invalid_command", message);
}
