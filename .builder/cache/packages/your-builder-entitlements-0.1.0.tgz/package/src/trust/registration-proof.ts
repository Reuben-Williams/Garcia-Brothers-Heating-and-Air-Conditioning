import { createHash } from "node:crypto";

import { importJWK } from "jose";

const CANONICAL_VERSION = "builder-registration-v1";
const REGISTRATION_METHOD = "POST";
const REGISTRATION_PATH = "/api/platform/v1/installations/register";
const BASE64URL_PATTERN = /^[A-Za-z0-9_-]+$/;
const encoder = new TextEncoder();

function isBytes(value: unknown): value is Uint8Array {
  return Object.prototype.toString.call(value) === "[object Uint8Array]";
}

function decodedBase64UrlLength(value: string): number {
  if (!BASE64URL_PATTERN.test(value)) return -1;
  try {
    const bytes = Buffer.from(value, "base64url");
    return bytes.toString("base64url") === value ? bytes.byteLength : -1;
  } catch {
    return -1;
  }
}

function isEd25519Jwk(jwk: JsonWebKey, includePrivate: boolean): boolean {
  const fields = Object.keys(jwk).sort().join(",");
  const hasExpectedFields = includePrivate
    ? fields === "crv,d,kty,x" || fields === "alg,crv,d,kty,x"
    : fields === "alg,crv,kty,x";
  return (
    hasExpectedFields &&
    jwk.kty === "OKP" &&
    jwk.crv === "Ed25519" &&
    (includePrivate
      ? jwk.alg === undefined || jwk.alg === "EdDSA"
      : jwk.alg === "EdDSA") &&
    typeof jwk.x === "string" &&
    decodedBase64UrlLength(jwk.x) === 32 &&
    (includePrivate
      ? typeof jwk.d === "string" && decodedBase64UrlLength(jwk.d) === 32
      : jwk.d === undefined)
  );
}

async function importEd25519Jwk(jwk: JsonWebKey): Promise<CryptoKey> {
  return (await importJWK(jwk, "EdDSA")) as CryptoKey;
}

export function canonicalRegistrationProof(bodyBytes: Uint8Array): string {
  if (!isBytes(bodyBytes)) {
    throw new TypeError("Registration body must be Uint8Array data");
  }
  const digest = createHash("sha256").update(bodyBytes).digest("base64url");
  return [
    CANONICAL_VERSION,
    REGISTRATION_METHOD,
    REGISTRATION_PATH,
    digest,
  ].join("\n");
}

export async function signRegistrationProof(input: {
  bodyBytes: Uint8Array;
  privateJwk: JsonWebKey;
}): Promise<string> {
  if (!isEd25519Jwk(input.privateJwk, true)) {
    throw new TypeError("Private JWK must be an exact Ed25519 EdDSA key");
  }
  const canonical = canonicalRegistrationProof(input.bodyBytes);
  try {
    const privateKey = await importEd25519Jwk(input.privateJwk);
    const signature = await crypto.subtle.sign(
      "Ed25519",
      privateKey,
      encoder.encode(canonical),
    );
    return Buffer.from(signature).toString("base64url");
  } catch {
    throw new TypeError("Private JWK could not sign a registration proof");
  }
}

export async function verifyRegistrationProof(input: {
  bodyBytes: Uint8Array;
  publicJwk: JsonWebKey;
  proof: string;
}): Promise<boolean> {
  if (
    !isBytes(input.bodyBytes) ||
    !isEd25519Jwk(input.publicJwk, false) ||
    decodedBase64UrlLength(input.proof) !== 64
  ) {
    return false;
  }

  try {
    const publicKey = await importEd25519Jwk(input.publicJwk);
    return await crypto.subtle.verify(
      "Ed25519",
      publicKey,
      Buffer.from(input.proof, "base64url"),
      encoder.encode(canonicalRegistrationProof(input.bodyBytes)),
    );
  } catch {
    return false;
  }
}
