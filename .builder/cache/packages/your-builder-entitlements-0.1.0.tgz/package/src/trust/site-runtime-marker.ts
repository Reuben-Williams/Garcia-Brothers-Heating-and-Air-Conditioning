const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const SITE_KEY_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const SHA256_PATTERN = /^[a-f0-9]{64}$/;
const VERSION_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._+:-]{0,127}$/;
const REVISION_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:/+@-]{0,127}$/;
const MAX_MARKER_BYTES = 32_768;

export interface SiteRuntimeMarker {
  version: 1;
  siteDataPlaneSiteId: string;
  expectedSiteKey: string;
  installationManifestSha256: string;
  configLoaderContract: "installation-client-config-v1";
  durableStoreContract: "supabase-command-receipts-v1";
  leaseContract: "site-installation-run-lease-v1";
  leaseSeconds: number;
  invocationTimeoutSeconds: number;
  scheduledInvocationContract: "direct-in-process-v1";
  handlerRegistrySha256: string;
  workerVersion?: string;
  reachabilityEvidenceRevision: string | null;
}

export class SiteRuntimeMarkerValidationError extends Error {
  readonly code = "invalid_site_runtime_marker";

  constructor() {
    super("invalid_site_runtime_marker");
    this.name = "SiteRuntimeMarkerValidationError";
  }
}

function invalid(): never {
  throw new SiteRuntimeMarkerValidationError();
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function hasExactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join(",") === [...keys].sort().join(",");
}

function isBounded(value: unknown): boolean {
  try {
    return new TextEncoder().encode(JSON.stringify(value)).byteLength <= MAX_MARKER_BYTES;
  } catch {
    return false;
  }
}

export function parseSiteRuntimeMarker(value: unknown): SiteRuntimeMarker {
  if (!isRecord(value) || !isBounded(value)) return invalid();
  const keys = value.workerVersion === undefined
    ? [
        "version",
        "siteDataPlaneSiteId",
        "expectedSiteKey",
        "installationManifestSha256",
        "configLoaderContract",
        "durableStoreContract",
        "leaseContract",
        "leaseSeconds",
        "invocationTimeoutSeconds",
        "scheduledInvocationContract",
        "handlerRegistrySha256",
        "reachabilityEvidenceRevision",
      ]
    : [
        "version",
        "siteDataPlaneSiteId",
        "expectedSiteKey",
        "installationManifestSha256",
        "configLoaderContract",
        "durableStoreContract",
        "leaseContract",
        "leaseSeconds",
        "invocationTimeoutSeconds",
        "scheduledInvocationContract",
        "handlerRegistrySha256",
        "workerVersion",
        "reachabilityEvidenceRevision",
      ];
  if (
    !hasExactKeys(value, keys) ||
    value.version !== 1 ||
    typeof value.siteDataPlaneSiteId !== "string" ||
    !UUID_PATTERN.test(value.siteDataPlaneSiteId) ||
    typeof value.expectedSiteKey !== "string" ||
    value.expectedSiteKey.length > 128 ||
    !SITE_KEY_PATTERN.test(value.expectedSiteKey) ||
    typeof value.installationManifestSha256 !== "string" ||
    !SHA256_PATTERN.test(value.installationManifestSha256) ||
    value.configLoaderContract !== "installation-client-config-v1" ||
    value.durableStoreContract !== "supabase-command-receipts-v1" ||
    value.leaseContract !== "site-installation-run-lease-v1" ||
    !Number.isSafeInteger(value.leaseSeconds) ||
    (value.leaseSeconds as number) < 60 ||
    (value.leaseSeconds as number) > 300 ||
    !Number.isSafeInteger(value.invocationTimeoutSeconds) ||
    (value.invocationTimeoutSeconds as number) < 1 ||
    (value.invocationTimeoutSeconds as number) >= (value.leaseSeconds as number) ||
    value.scheduledInvocationContract !== "direct-in-process-v1" ||
    typeof value.handlerRegistrySha256 !== "string" ||
    !SHA256_PATTERN.test(value.handlerRegistrySha256) ||
    (value.workerVersion !== undefined &&
      (typeof value.workerVersion !== "string" || !VERSION_PATTERN.test(value.workerVersion))) ||
    !(value.reachabilityEvidenceRevision === null ||
      (typeof value.reachabilityEvidenceRevision === "string" &&
        REVISION_PATTERN.test(value.reachabilityEvidenceRevision))) ||
    (value.workerVersion !== undefined && value.reachabilityEvidenceRevision === null)
  ) {
    return invalid();
  }
  return value as unknown as SiteRuntimeMarker;
}
