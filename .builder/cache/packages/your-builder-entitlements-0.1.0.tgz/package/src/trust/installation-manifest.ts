import { createHash } from "node:crypto";

const SAFE_IDENTIFIER_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:/+@-]*$/;
const PACKAGE_NAME_PATTERN = /^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*$/;
const VERSION_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._+:-]*$/;
const ROUTE_PATTERN = /^\/(?!\/)[^\s?#\\\u0000-\u001f\u007f]*$/;
const MAX_MANIFEST_ENTRIES = 256;
const MAX_JSONB_BYTES = 32_768;

export interface InstallationManifestInput {
  version: 1;
  packages: Record<string, string>;
  schemas: Record<string, number>;
  routes: readonly string[];
  workerVersion?: string;
}

export class InstallationManifestValidationError extends Error {
  readonly code = "invalid_installation_manifest";

  constructor() {
    super("invalid_installation_manifest");
    this.name = "InstallationManifestValidationError";
  }
}

function invalid(): never {
  throw new InstallationManifestValidationError();
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function hasExactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join(",") === [...keys].sort().join(",");
}

function isSafeRecord(
  value: unknown,
  isValue: (entry: unknown) => boolean,
  keyPattern: RegExp = SAFE_IDENTIFIER_PATTERN,
): boolean {
  return isRecord(value) &&
    Object.keys(value).length <= MAX_MANIFEST_ENTRIES &&
    Object.entries(value).every(
      ([key, entry]) => key.length <= 128 && keyPattern.test(key) && isValue(entry),
    );
}

function canonicalJson(value: unknown): string {
  if (value === null || typeof value === "string" || typeof value === "boolean") {
    return JSON.stringify(value);
  }
  if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (isRecord(value)) {
    return `{${Object.keys(value).sort().map((key) =>
      `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
  }
  return invalid();
}

function isBounded(value: unknown): boolean {
  try {
    return new TextEncoder().encode(canonicalJson(value)).byteLength <= MAX_JSONB_BYTES;
  } catch {
    return false;
  }
}

export function parseInstallationManifest(value: unknown): InstallationManifestInput {
  if (!isRecord(value)) return invalid();
  const keys = value.workerVersion === undefined
    ? ["version", "packages", "schemas", "routes"]
    : ["version", "packages", "schemas", "routes", "workerVersion"];
  if (
    !hasExactKeys(value, keys) ||
    !isBounded(value) ||
    value.version !== 1 ||
    !isSafeRecord(
      value.packages,
      (entry) => typeof entry === "string" && entry.length <= 64 && VERSION_PATTERN.test(entry),
      PACKAGE_NAME_PATTERN,
    ) ||
    !isSafeRecord(
      value.schemas,
      (entry) => Number.isSafeInteger(entry) && (entry as number) >= 0 && (entry as number) <= 1_000_000,
    ) ||
    !Array.isArray(value.routes) ||
    value.routes.length > MAX_MANIFEST_ENTRIES ||
    !value.routes.every((route) =>
      typeof route === "string" && route.length <= 2_048 && ROUTE_PATTERN.test(route)) ||
    new Set(value.routes).size !== value.routes.length ||
    (value.workerVersion !== undefined &&
      (typeof value.workerVersion !== "string" ||
        value.workerVersion.length > 64 ||
        !VERSION_PATTERN.test(value.workerVersion)))
  ) {
    return invalid();
  }
  return value as unknown as InstallationManifestInput;
}

export function canonicalInstallationManifest(value: unknown): string {
  return canonicalJson(parseInstallationManifest(value));
}

export function installationManifestSha256(value: unknown): string {
  return createHash("sha256")
    .update(canonicalInstallationManifest(value), "utf8")
    .digest("hex");
}
