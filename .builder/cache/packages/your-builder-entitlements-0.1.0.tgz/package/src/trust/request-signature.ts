import { createHash } from "node:crypto";

import { importJWK } from "jose";

import {
  InstallationRequestVerificationError,
  type CanonicalInstallationRequestInput,
  type InstallationRequestVerificationErrorCode,
  type SignInstallationRequestInput,
  type VerifiedInstallationRequest,
  type VerifyInstallationRequestInput,
} from "./contracts.js";

const CANONICAL_VERSION = "builder-installation-v1";
const CLOCK_SKEW_MS = 300_000;
const MAX_BODY_BYTES = 16 * 1024 * 1024;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const TOKEN_PATTERN = /^[A-Za-z0-9._:-]{1,128}$/;
const METHOD_PATTERN = /^[A-Z!#$%&'*+.^_`|~-]{1,32}$/;
const NONCE_PATTERN = /^[A-Za-z0-9_-]{22,128}$/;
const BASE64URL_PATTERN = /^[A-Za-z0-9_-]+$/;
const STRICT_TIMESTAMP_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
const encoder = new TextEncoder();

function fail(code: InstallationRequestVerificationErrorCode, message: string): never {
  throw new InstallationRequestVerificationError(code, message);
}

function decodedBase64UrlLength(value: string): number {
  if (!BASE64URL_PATTERN.test(value)) {
    return -1;
  }

  const padding = (4 - (value.length % 4)) % 4;
  try {
    return Buffer.from(`${value}${"=".repeat(padding)}`, "base64url").byteLength;
  } catch {
    return -1;
  }
}

function validateInstallationId(value: string): void {
  if (!UUID_PATTERN.test(value)) {
    fail("malformed_installation_id", "Installation ID must be a UUID");
  }
}

function validateKeyId(value: string): void {
  if (!TOKEN_PATTERN.test(value)) {
    fail("malformed_key_id", "Key ID is malformed");
  }
}

function validateMethod(value: string): string {
  const method = value.toUpperCase();
  if (!METHOD_PATTERN.test(method)) {
    fail("malformed_method", "HTTP method is malformed");
  }
  return method;
}

function validatePath(value: string): void {
  if (value.length === 0 || value.length > 4_096 || !value.startsWith("/") || /[\r\n]/.test(value)) {
    fail("malformed_path", "Request path is malformed");
  }
}

function parseTimestamp(value: string): number {
  if (!STRICT_TIMESTAMP_PATTERN.test(value)) {
    fail("malformed_timestamp", "Timestamp must be canonical UTC ISO-8601");
  }
  const timestamp = Date.parse(value);
  if (!Number.isFinite(timestamp) || new Date(timestamp).toISOString() !== value) {
    fail("malformed_timestamp", "Timestamp is invalid");
  }
  return timestamp;
}

function validateNonce(value: string): void {
  if (!NONCE_PATTERN.test(value) || decodedBase64UrlLength(value) < 16) {
    fail("malformed_nonce", "Nonce must contain at least 128 bits of base64url data");
  }
}

function validateBody(bodyBytes: Uint8Array): void {
  if (
    Object.prototype.toString.call(bodyBytes) !== "[object Uint8Array]" ||
    bodyBytes.byteLength > MAX_BODY_BYTES
  ) {
    throw new TypeError("Request body must be Uint8Array data no larger than 16 MiB");
  }
}

function validateSignature(value: string): void {
  if (value.length !== 86 || decodedBase64UrlLength(value) !== 64) {
    fail("malformed_signature", "Signature must be a 64-byte base64url value");
  }
}

function validateEd25519Jwk(jwk: JsonWebKey, includePrivate: boolean): void {
  const hasExpectedPublicFields =
    jwk.kty === "OKP" &&
    jwk.crv === "Ed25519" &&
    (jwk.alg === undefined || jwk.alg === "EdDSA") &&
    typeof jwk.x === "string" &&
    decodedBase64UrlLength(jwk.x) === 32;
  const hasExpectedPrivateField =
    includePrivate
      ? typeof jwk.d === "string" && decodedBase64UrlLength(jwk.d) === 32
      : jwk.d === undefined;

  if (!hasExpectedPublicFields || !hasExpectedPrivateField) {
    if (includePrivate) {
      throw new TypeError("Private JWK must be an Ed25519 EdDSA key");
    }
    fail("invalid_public_key", "Public JWK must be a public Ed25519 EdDSA key");
  }
}

async function importEd25519Jwk(jwk: JsonWebKey): Promise<CryptoKey> {
  // jose's return type also covers symmetric JWKs; validation above limits this path to OKP keys.
  return (await importJWK(jwk, "EdDSA")) as CryptoKey;
}

function validateCanonicalInput(input: CanonicalInstallationRequestInput): string {
  validateInstallationId(input.installationId);
  const method = validateMethod(input.method);
  validatePath(input.path);
  parseTimestamp(input.timestamp);
  validateNonce(input.nonce);
  validateBody(input.bodyBytes);
  return method;
}

export function canonicalInstallationRequest(input: CanonicalInstallationRequestInput): string {
  const method = validateCanonicalInput(input);
  const digest = createHash("sha256").update(input.bodyBytes).digest("base64url");
  return [
    CANONICAL_VERSION,
    input.installationId,
    method,
    input.path,
    input.timestamp,
    input.nonce,
    digest,
  ].join("\n");
}

export async function signInstallationRequest(
  input: SignInstallationRequestInput,
): Promise<import("./contracts.js").InstallationRequestHeaders> {
  validateKeyId(input.keyId);
  validateEd25519Jwk(input.privateJwk, true);
  const canonical = canonicalInstallationRequest(input);

  try {
    const privateKey = await importEd25519Jwk(input.privateJwk);
    const signature = await crypto.subtle.sign("Ed25519", privateKey, encoder.encode(canonical));
    return {
      installationId: input.installationId,
      keyId: input.keyId,
      timestamp: input.timestamp,
      nonce: input.nonce,
      signature: Buffer.from(signature).toString("base64url"),
    };
  } catch {
    throw new TypeError("Private JWK could not sign an Ed25519 request");
  }
}

export async function verifyInstallationRequest(
  input: VerifyInstallationRequestInput,
): Promise<VerifiedInstallationRequest> {
  const { headers } = input;
  validateInstallationId(headers.installationId);
  validateKeyId(headers.keyId);
  validateMethod(input.method);
  validatePath(input.path);
  validateNonce(headers.nonce);
  validateSignature(headers.signature);
  validateBody(input.bodyBytes);

  const timestamp = parseTimestamp(headers.timestamp);
  const now = input.now ?? new Date();
  const nowMs = now.getTime();
  if (!Number.isFinite(nowMs)) {
    throw new TypeError("Verification time must be valid");
  }
  if (Math.abs(nowMs - timestamp) > CLOCK_SKEW_MS) {
    fail("timestamp_out_of_range", "Timestamp is outside the five-minute acceptance window");
  }

  const publicJwk = await input.resolvePublicKey(headers.installationId, headers.keyId);
  if (publicJwk === null) {
    fail("unknown_key", "Installation key is unknown");
  }
  validateEd25519Jwk(publicJwk, false);

  const canonical = canonicalInstallationRequest({
    installationId: headers.installationId,
    method: input.method,
    path: input.path,
    timestamp: headers.timestamp,
    nonce: headers.nonce,
    bodyBytes: input.bodyBytes,
  });

  let verified = false;
  try {
    const publicKey = await importEd25519Jwk(publicJwk);
    verified = await crypto.subtle.verify(
      "Ed25519",
      publicKey,
      Buffer.from(headers.signature, "base64url"),
      encoder.encode(canonical),
    );
  } catch {
    fail("invalid_public_key", "Public JWK could not verify Ed25519 signatures");
  }
  if (!verified) {
    fail("invalid_signature", "Installation request signature is invalid");
  }

  const expiresAt = new Date(timestamp + CLOCK_SKEW_MS);
  const consumed = await input.consumeNonce(headers.installationId, headers.nonce, expiresAt);
  if (!consumed) {
    fail("nonce_replayed", "Installation request nonce was already consumed");
  }

  return {
    installationId: headers.installationId,
    keyId: headers.keyId,
    timestamp: headers.timestamp,
    nonce: headers.nonce,
  };
}
