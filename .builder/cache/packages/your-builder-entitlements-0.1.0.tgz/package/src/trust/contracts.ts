// Thirty maximum-size payloads leave 64 KiB for the bounded public envelopes.
export const MAX_INSTALLATION_COMMAND_PULL_LIMIT = 30;

export interface InstallationRequestHeaders {
  installationId: string;
  keyId: string;
  timestamp: string;
  nonce: string;
  signature: string;
}

export interface PublicEd25519Jwk {
  kty: "OKP";
  crv: "Ed25519";
  alg: "EdDSA";
  x: string;
}

export interface CanonicalInstallationRequestInput {
  installationId: string;
  method: string;
  path: string;
  timestamp: string;
  nonce: string;
  bodyBytes: Uint8Array;
}

export interface SignInstallationRequestInput extends CanonicalInstallationRequestInput {
  keyId: string;
  privateJwk: JsonWebKey;
}

export type PublicKeyResolver = (
  installationId: string,
  keyId: string,
) => JsonWebKey | null | Promise<JsonWebKey | null>;

export type NonceConsumer = (
  installationId: string,
  nonce: string,
  expiresAt: Date,
) => boolean | Promise<boolean>;

export interface VerifyInstallationRequestInput {
  headers: InstallationRequestHeaders;
  method: string;
  path: string;
  bodyBytes: Uint8Array;
  resolvePublicKey: PublicKeyResolver;
  consumeNonce: NonceConsumer;
  now?: Date;
}

export interface VerifiedInstallationRequest {
  installationId: string;
  keyId: string;
  timestamp: string;
  nonce: string;
}

export type InstallationRequestVerificationErrorCode =
  | "malformed_installation_id"
  | "malformed_key_id"
  | "malformed_method"
  | "malformed_path"
  | "malformed_timestamp"
  | "malformed_nonce"
  | "malformed_signature"
  | "timestamp_out_of_range"
  | "unknown_key"
  | "invalid_public_key"
  | "invalid_signature"
  | "nonce_replayed";

export class InstallationRequestVerificationError extends Error {
  readonly code: InstallationRequestVerificationErrorCode;

  constructor(code: InstallationRequestVerificationErrorCode, message: string) {
    super(message);
    this.name = "InstallationRequestVerificationError";
    this.code = code;
  }
}
