const MAX_REPORT_BYTES = 32_768;
const MAX_SAFE_INTEGER_10_DIGITS = 9_999_999_999;
const SAFE_IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._:/+@-]*$/;
const PACKAGE_IDENTIFIER =
  /^(?:@[a-z0-9][a-z0-9._-]*\/[a-z0-9][a-z0-9._-]*|[A-Za-z0-9][A-Za-z0-9._:/+@-]*)$/;
const VERSION = /^[A-Za-z0-9][A-Za-z0-9._+:-]*$/;
const ERROR_CODE = /^[A-Z][A-Z0-9_]*$/;
const FORBIDDEN_KEY_SEGMENT =
  /(^|[^a-z0-9])(body|message|email|phone|address|token|secret|key|authorization|cookie|attachment|export)([^a-z0-9]|$)/;

export interface SanitizedHealthReport {
  manifestVersion: 1;
  packages: Record<string, string>;
  schemas: Record<string, number>;
  worker: {
    version?: string;
    status: "healthy" | "degraded" | "stopped";
  };
  queues: Record<
    string,
    { depth: number; oldestAgeSeconds: number | null; deadLetters: number }
  >;
  integrations: Record<string, "connected" | "degraded" | "disconnected">;
  entitlementSnapshotAgeSeconds: number | null;
  backupAgeSeconds: number | null;
  errorCodes: readonly string[];
}

export class HealthReportValidationError extends Error {
  constructor() {
    super("invalid_health_report");
    this.name = "HealthReportValidationError";
  }
}

function invalid(): never {
  throw new HealthReportValidationError();
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && !Array.isArray(value) && typeof value === "object";
}

function hasExactKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).sort().join(",") === [...keys].sort().join(",");
}

function isSafeIdentifier(value: string, maximumLength = 128): boolean {
  return value.length >= 1 && value.length <= maximumLength && SAFE_IDENTIFIER.test(value);
}

function isNonnegativeSqlInteger(value: unknown): value is number {
  return Number.isSafeInteger(value) &&
    (value as number) >= 0 &&
    (value as number) <= MAX_SAFE_INTEGER_10_DIGITS;
}

function hasForbiddenJsonKey(value: unknown): boolean {
  if (Array.isArray(value)) return value.some(hasForbiddenJsonKey);
  if (!isRecord(value)) return false;

  return Object.entries(value).some(([key, child]) => {
    const normalized = key.replace(/([a-z0-9])([A-Z])/g, "$1_$2").toLowerCase();
    return FORBIDDEN_KEY_SEGMENT.test(normalized) || hasForbiddenJsonKey(child);
  });
}

function postgresJsonbText(value: unknown): string {
  if (value === null || typeof value === "boolean" || typeof value === "string") {
    return JSON.stringify(value);
  }
  if (typeof value === "number" && Number.isFinite(value)) {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return `[${value.map(postgresJsonbText).join(", ")}]`;
  }
  if (isRecord(value)) {
    return `{${Object.entries(value)
      .map(([key, child]) => `${JSON.stringify(key)}: ${postgresJsonbText(child)}`)
      .join(", ")}}`;
  }
  return invalid();
}

function isWithinSerializedLimit(value: unknown): boolean {
  try {
    return new TextEncoder().encode(postgresJsonbText(value)).byteLength <= MAX_REPORT_BYTES;
  } catch {
    return false;
  }
}

function isSafeRecord(
  value: unknown,
  validateValue: (entry: unknown) => boolean,
  keyPattern: RegExp = SAFE_IDENTIFIER,
): value is Record<string, unknown> {
  return isRecord(value) && Object.entries(value).every(
    ([key, entry]) =>
      key.length >= 1 && key.length <= 128 && keyPattern.test(key) && validateValue(entry),
  );
}

export function parseSanitizedHealthReport(value: unknown): SanitizedHealthReport {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, [
      "manifestVersion",
      "packages",
      "schemas",
      "worker",
      "queues",
      "integrations",
      "entitlementSnapshotAgeSeconds",
      "backupAgeSeconds",
      "errorCodes",
    ]) ||
    !isWithinSerializedLimit(value) ||
    hasForbiddenJsonKey(value) ||
    value.manifestVersion !== 1 ||
    !isSafeRecord(value.packages, (entry) =>
      typeof entry === "string" &&
      entry.length <= 128 &&
      VERSION.test(entry),
      PACKAGE_IDENTIFIER,
    ) ||
    !isSafeRecord(value.schemas, isNonnegativeSqlInteger) ||
    !isRecord(value.worker) ||
    !hasExactKeys(
      value.worker,
      value.worker.version === undefined ? ["status"] : ["status", "version"],
    ) ||
    !["healthy", "degraded", "stopped"].includes(String(value.worker.status)) ||
    (value.worker.version !== undefined &&
      (typeof value.worker.version !== "string" ||
        value.worker.version.length < 1 ||
        value.worker.version.length > 128 ||
        !VERSION.test(value.worker.version))) ||
    !isSafeRecord(value.queues, (entry) =>
      isRecord(entry) &&
      hasExactKeys(entry, ["depth", "oldestAgeSeconds", "deadLetters"]) &&
      isNonnegativeSqlInteger(entry.depth) &&
      (entry.oldestAgeSeconds === null || isNonnegativeSqlInteger(entry.oldestAgeSeconds)) &&
      isNonnegativeSqlInteger(entry.deadLetters),
    ) ||
    !isSafeRecord(value.integrations, (entry) =>
      entry === "connected" || entry === "degraded" || entry === "disconnected",
    ) ||
    !(value.entitlementSnapshotAgeSeconds === null ||
      isNonnegativeSqlInteger(value.entitlementSnapshotAgeSeconds)) ||
    !(value.backupAgeSeconds === null || isNonnegativeSqlInteger(value.backupAgeSeconds)) ||
    !Array.isArray(value.errorCodes) ||
    value.errorCodes.length > 64 ||
    !value.errorCodes.every((code) =>
      typeof code === "string" &&
      code.length >= 1 &&
      code.length <= 64 &&
      ERROR_CODE.test(code),
    )
  ) {
    return invalid();
  }

  return value as unknown as SanitizedHealthReport;
}

export function assertSanitizedHealthReport(
  value: unknown,
): asserts value is SanitizedHealthReport {
  parseSanitizedHealthReport(value);
}
