import type { PublicEd25519Jwk } from "./contracts.js";

const BASE64URL_PATTERN = /^[A-Za-z0-9_-]+$/;

function decodedBase64UrlLength(value: string): number {
  if (!BASE64URL_PATTERN.test(value)) return -1;

  try {
    return Buffer.from(value, "base64url").byteLength;
  } catch {
    return -1;
  }
}

export function normalizeExportedEd25519PublicJwk(
  value: unknown,
): PublicEd25519Jwk {
  if (!value || Array.isArray(value) || typeof value !== "object") {
    throw new TypeError("Exported public JWK must be an Ed25519 key");
  }

  const record = value as Record<string, unknown>;
  const keys = Object.keys(record).sort();
  if (
    keys.length !== 3 ||
    keys[0] !== "crv" ||
    keys[1] !== "kty" ||
    keys[2] !== "x" ||
    record.kty !== "OKP" ||
    record.crv !== "Ed25519" ||
    typeof record.x !== "string" ||
    decodedBase64UrlLength(record.x) !== 32
  ) {
    throw new TypeError("Exported public JWK must be an Ed25519 key");
  }

  return {
    kty: "OKP",
    crv: "Ed25519",
    alg: "EdDSA",
    x: record.x,
  };
}
