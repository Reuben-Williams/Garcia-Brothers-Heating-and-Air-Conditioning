import type { InstallationRequestHeaders } from "./contracts.js";

export const INSTALLATION_REQUEST_HEADER_NAMES = Object.freeze({
  installationId: "x-builder-installation-id",
  keyId: "x-builder-key-id",
  timestamp: "x-builder-timestamp",
  nonce: "x-builder-nonce",
  signature: "x-builder-signature",
} as const satisfies Readonly<Record<keyof InstallationRequestHeaders, string>>);

export const REGISTRATION_REQUEST_HEADER_NAMES = Object.freeze({
  proof: "x-builder-registration-proof",
} as const);

export type RequestBodyReadErrorCode =
  | "invalid_content_length"
  | "payload_too_large"
  | "body_unavailable";

export class RequestBodyReadError extends Error {
  constructor(public readonly code: RequestBodyReadErrorCode) {
    super(code);
    this.name = "RequestBodyReadError";
  }
}

export async function readBoundedRequestBody(
  request: {
    headers: Pick<Headers, "get">;
    body: ReadableStream<Uint8Array> | null;
  },
  maxBytes: number,
): Promise<Uint8Array> {
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 0) {
    throw new TypeError("Body byte limit must be a non-negative safe integer");
  }

  const contentLength = request.headers.get("content-length");
  if (contentLength !== null) {
    if (!/^(0|[1-9]\d*)$/.test(contentLength)) {
      throw new RequestBodyReadError("invalid_content_length");
    }
    if (BigInt(contentLength) > BigInt(maxBytes)) {
      throw new RequestBodyReadError("payload_too_large");
    }
  }

  if (request.body === null) return new Uint8Array();

  const chunks: Uint8Array[] = [];
  let totalBytes = 0;
  const reader = request.body.getReader();
  try {
    while (true) {
      let result: ReadableStreamReadResult<Uint8Array>;
      try {
        result = await reader.read();
      } catch {
        throw new RequestBodyReadError("body_unavailable");
      }
      if (result.done) break;

      totalBytes += result.value.byteLength;
      if (totalBytes > maxBytes) {
        await reader.cancel().catch(() => undefined);
        throw new RequestBodyReadError("payload_too_large");
      }
      chunks.push(result.value);
    }
  } finally {
    reader.releaseLock();
  }

  const bodyBytes = new Uint8Array(totalBytes);
  let offset = 0;
  for (const chunk of chunks) {
    bodyBytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bodyBytes;
}

export function readInstallationRequestHeaders(
  headers: Pick<Headers, "get">,
): InstallationRequestHeaders | null {
  const installationId = headers.get(INSTALLATION_REQUEST_HEADER_NAMES.installationId);
  const keyId = headers.get(INSTALLATION_REQUEST_HEADER_NAMES.keyId);
  const timestamp = headers.get(INSTALLATION_REQUEST_HEADER_NAMES.timestamp);
  const nonce = headers.get(INSTALLATION_REQUEST_HEADER_NAMES.nonce);
  const signature = headers.get(INSTALLATION_REQUEST_HEADER_NAMES.signature);

  if (
    installationId === null ||
    keyId === null ||
    timestamp === null ||
    nonce === null ||
    signature === null
  ) {
    return null;
  }

  return { installationId, keyId, timestamp, nonce, signature };
}
