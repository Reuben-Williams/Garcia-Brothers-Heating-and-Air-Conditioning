import "server-only";

import type { GrowthModuleId } from "@your-builder/feature-registry";
import { ENTITLEMENT_ACCESS } from "../entitlements/access-policy.js";
import type { EntitlementSnapshot } from "../entitlements/snapshot-contract.js";

export type EntitlementSnapshotAction = "read" | "write" | "outbound" | "export" | "setup" | "repair";

export type EntitlementSnapshotDecisionReason =
  | "current"
  | "state_policy"
  | "snapshot_missing"
  | "snapshot_stale"
  | "stale_read_only"
  | "stale_repair"
  | "incident_read_only"
  | "incident_blocked"
  | "module_missing";

export interface EntitlementSnapshotDecision {
  readonly allowed: boolean;
  readonly reason: EntitlementSnapshotDecisionReason;
  readonly state?: EntitlementSnapshot["modules"][GrowthModuleId]["state"];
  readonly stale: boolean;
}

export interface DecideSnapshotAccessInput {
  readonly snapshot: EntitlementSnapshot | null;
  readonly moduleId: GrowthModuleId;
  readonly action: EntitlementSnapshotAction;
  readonly now?: Date;
}

function freshPolicyAllows(
  policy: (typeof ENTITLEMENT_ACCESS)[keyof typeof ENTITLEMENT_ACCESS],
  action: EntitlementSnapshotAction,
): boolean {
  switch (action) {
    case "read": return policy.read !== "none";
    case "write": return policy.write === "operational";
    case "outbound": return policy.outbound !== "none";
    case "export": return policy.export !== "none";
    case "setup": return policy.write === "setup_actions";
    case "repair": return !["request_only", "normal"].includes(policy.repair);
  }
}

export function decideSnapshotAccess(input: DecideSnapshotAccessInput): EntitlementSnapshotDecision {
  const snapshot = input.snapshot;
  if (!snapshot) return { allowed: false, reason: "snapshot_missing", stale: false };

  const module = snapshot.modules[input.moduleId];
  if (!module) return { allowed: false, reason: "module_missing", stale: false };

  const incident = snapshot.incidentOverrides.find((override) => override.moduleId === input.moduleId)
    ?? snapshot.incidentOverrides.find((override) => override.moduleId === "*");
  if (incident?.mode === "blocked") {
    return { allowed: false, reason: "incident_blocked", state: module.state, stale: false };
  }
  if (incident?.mode === "read_only" && !["read", "export"].includes(input.action)) {
    return { allowed: false, reason: "incident_read_only", state: module.state, stale: false };
  }

  const policy = ENTITLEMENT_ACCESS[module.state];
  const stale = new Date(snapshot.expiresAt).valueOf() <= (input.now ?? new Date()).valueOf();
  if (!stale) {
    return {
      allowed: freshPolicyAllows(policy, input.action),
      reason: freshPolicyAllows(policy, input.action) ? "current" : "state_policy",
      state: module.state,
      stale: false,
    };
  }

  if (input.action === "read" && policy.read !== "none") {
    return { allowed: true, reason: "stale_read_only", state: module.state, stale: true };
  }
  if (input.action === "export" && policy.export !== "none") {
    return { allowed: true, reason: "stale_read_only", state: module.state, stale: true };
  }
  if (input.action === "setup" && policy.write === "setup_actions") {
    return { allowed: true, reason: "stale_repair", state: module.state, stale: true };
  }
  if (input.action === "repair" && !["request_only", "normal"].includes(policy.repair)) {
    return { allowed: true, reason: "stale_repair", state: module.state, stale: true };
  }
  return { allowed: false, reason: "snapshot_stale", state: module.state, stale: true };
}

export interface EntitlementSnapshotCache {
  readonly accept: (snapshot: EntitlementSnapshot) => boolean;
  readonly current: () => EntitlementSnapshot | null;
  readonly clear: () => void;
  readonly decide: (input: Omit<DecideSnapshotAccessInput, "snapshot">) => EntitlementSnapshotDecision;
}

export function createEntitlementSnapshotCache(scope: {
  readonly siteId: string;
  readonly installationId: string;
}): EntitlementSnapshotCache {
  let cached: EntitlementSnapshot | null = null;
  return {
    accept(snapshot) {
      if (snapshot.siteId !== scope.siteId || snapshot.installationId !== scope.installationId
        || (cached !== null && snapshot.sequence <= cached.sequence)) return false;
      cached = snapshot;
      return true;
    },
    current: () => cached,
    clear: () => { cached = null; },
    decide: (input) => decideSnapshotAccess({ ...input, snapshot: cached }),
  };
}
