import "server-only";

import {
  CompactSign,
  compactVerify,
  decodeProtectedHeader,
  importJWK,
  type JWK,
} from "jose";
import {
  isEntitlementSnapshot,
  isEntitlementSnapshotTimingValid,
  type EntitlementSnapshot,
} from "../entitlements/snapshot-contract.js";

const SNAPSHOT_TYPE = "builder-entitlements+jwt";
const KEY_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$/;

export type EntitlementSnapshotErrorCode =
  | "invalid_snapshot"
  | "invalid_token"
  | "invalid_timing"
  | "scope_mismatch"
  | "signing_key_unavailable";

export class EntitlementSnapshotError extends Error {
  readonly code: EntitlementSnapshotErrorCode;

  constructor(code: EntitlementSnapshotErrorCode, message: string) {
    super(message);
    this.name = "EntitlementSnapshotError";
    this.code = code;
  }
}

export interface EntitlementSnapshotSigningKey {
  readonly keyId: string;
  readonly status: "active" | "retired" | "revoked";
  readonly publicJwk: JWK;
}

export interface SignEntitlementSnapshotInput {
  readonly snapshot: EntitlementSnapshot;
  readonly keyId: string;
  readonly privateJwk: JWK;
}

export interface VerifyEntitlementSnapshotInput {
  readonly token: string;
  readonly expectedSiteId: string;
  readonly expectedInstallationId: string;
  readonly resolveSigningKey: (keyId: string) => Promise<EntitlementSnapshotSigningKey | null>;
  readonly now?: Date;
}

export async function signEntitlementSnapshot(input: SignEntitlementSnapshotInput): Promise<string> {
  if (!isEntitlementSnapshot(input.snapshot)) {
    throw new EntitlementSnapshotError("invalid_snapshot", "The entitlement snapshot is invalid.");
  }
  if (!KEY_ID_PATTERN.test(input.keyId)) {
    throw new EntitlementSnapshotError("invalid_snapshot", "The entitlement signing key identifier is invalid.");
  }

  try {
    const key = await importJWK(input.privateJwk, "EdDSA");
    return await new CompactSign(new TextEncoder().encode(JSON.stringify(input.snapshot)))
      .setProtectedHeader({ alg: "EdDSA", kid: input.keyId, typ: SNAPSHOT_TYPE })
      .sign(key);
  } catch (error) {
    if (error instanceof EntitlementSnapshotError) throw error;
    throw new EntitlementSnapshotError("invalid_snapshot", "The entitlement snapshot could not be signed.");
  }
}

export async function verifyEntitlementSnapshot(input: VerifyEntitlementSnapshotInput): Promise<EntitlementSnapshot> {
  try {
    const header = decodeProtectedHeader(input.token);
    if (header.alg !== "EdDSA" || header.typ !== SNAPSHOT_TYPE
      || typeof header.kid !== "string" || !KEY_ID_PATTERN.test(header.kid)) {
      throw new EntitlementSnapshotError("invalid_token", "The entitlement snapshot header is invalid.");
    }

    const signingKey = await input.resolveSigningKey(header.kid);
    if (!signingKey || signingKey.keyId !== header.kid || signingKey.status !== "active") {
      throw new EntitlementSnapshotError("signing_key_unavailable", "The entitlement signing key is unavailable.");
    }

    const key = await importJWK(signingKey.publicJwk, "EdDSA");
    const { payload } = await compactVerify(input.token, key, {
      algorithms: ["EdDSA"],
    });
    const parsed: unknown = JSON.parse(new TextDecoder().decode(payload));
    if (!isEntitlementSnapshot(parsed)) {
      throw new EntitlementSnapshotError("invalid_snapshot", "The entitlement snapshot payload is invalid.");
    }
    if (parsed.siteId !== input.expectedSiteId || parsed.installationId !== input.expectedInstallationId) {
      throw new EntitlementSnapshotError("scope_mismatch", "The entitlement snapshot scope does not match this installation.");
    }
    if (!isEntitlementSnapshotTimingValid(parsed, input.now ?? new Date())) {
      throw new EntitlementSnapshotError("invalid_timing", "The entitlement snapshot timing is invalid.");
    }
    return parsed;
  } catch (error) {
    if (error instanceof EntitlementSnapshotError) throw error;
    throw new EntitlementSnapshotError("invalid_token", "The entitlement snapshot token is invalid.");
  }
}
